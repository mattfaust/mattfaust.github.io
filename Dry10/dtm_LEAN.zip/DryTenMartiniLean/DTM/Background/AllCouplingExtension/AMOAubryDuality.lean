import DTM.Background.AllCouplingExtension.MagneticDOSDuality
import DTM.NewResults.Continuation.OneSeedContinuation
import Mathlib.Topology.MetricSpace.Lipschitz
import DTM.Background.EmpiricalIDS.AMOEmpiricalBridge

/-!
# Label-preserving Aubry duality and every positive coupling

The concrete root-fixing magnetic unitary supplies spectral scaling. The
independently proved root-measure scaling supplies the IDS, so the label is
preserved rather than merely a spectral interval being rescaled.

The final conclusion remains conditional on arbitrarily small seed gaps.
Duality removes the restriction target <= 1; it does not construct the seed.
A single fixed seed s only gives the reciprocal window [s,1/s].
-/

noncomputable section
namespace CriticalDTM

open Set

/-- Full complex spectral membership scales by the positive coupling. The
phases on the two sides may be independently chosen. -/
theorem almostMathieuOperator_spectrum_aubry {α : ℝ} (hα : Irrational α)
    {lam : ℝ} (hlam : 0 < lam) (θ φ : ℝ) (E : ℂ) :
    (lam : ℂ) * E ∈ spectrum ℂ (almostMathieuOperator α lam θ) ↔
      E ∈ spectrum ℂ (almostMathieuOperator α lam⁻¹ φ) := by
  rw [almostMathieuOperator_spectrum_eq_magnetic hα lam θ,
    almostMathieuOperator_spectrum_eq_magnetic hα lam⁻¹ φ]
  have hlc : (lam : ℂ) ≠ 0 := by exact_mod_cast hlam.ne'
  simpa only [Complex.ofReal_inv, mul_div_cancel_left₀ E hlc] using
    magnetic_spectrum_aubry α hlc ((lam : ℂ) * E)

/-- The real energy slice of the same exact operator identity. -/
theorem almostMathieuRealSpectrumSet_aubry_mul_iff {α : ℝ} (hα : Irrational α)
    {lam : ℝ} (hlam : 0 < lam) (θ φ E : ℝ) :
    lam * E ∈ almostMathieuRealSpectrumSet α lam θ ↔
      E ∈ almostMathieuRealSpectrumSet α lam⁻¹ φ := by
  change ((lam * E : ℝ) : ℂ) ∈ spectrum ℂ (almostMathieuOperator α lam θ) ↔
    (E : ℂ) ∈ spectrum ℂ (almostMathieuOperator α lam⁻¹ φ)
  simpa only [Complex.ofReal_mul] using
    almostMathieuOperator_spectrum_aubry hα hlam θ φ (E : ℂ)

theorem almostMathieuRealSpectrumSet_aubry_div_iff {α : ℝ} (hα : Irrational α)
    {lam : ℝ} (hlam : 0 < lam) (θ φ E : ℝ) :
    E ∈ almostMathieuRealSpectrumSet α lam θ ↔
      E / lam ∈ almostMathieuRealSpectrumSet α lam⁻¹ φ := by
  simpa only [mul_div_cancel₀ E hlam.ne'] using
    almostMathieuRealSpectrumSet_aubry_mul_iff hα hlam θ φ (E / lam)

/-- Positive scaling transports an entire bounded gap and preserves its
actual IDS label, not just the spectrum. -/
theorem amo_labelled_gap_aubry {α : ℝ} (hα : Irrational α)
    {lam : ℝ} (hlam : 0 < lam) (θ φ : ℝ) {label a b : ℝ}
    (hgap : IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam⁻¹ φ)
      (almostMathieuIDS α lam⁻¹) label a b) :
    IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam θ)
      (almostMathieuIDS α lam) label (lam * a) (lam * b) := by
  have hin {E : ℝ} (hE : E ∈ Ioo (lam * a) (lam * b)) : E / lam ∈ Ioo a b :=
    ⟨(lt_div_iff₀ hlam).mpr (by simpa only [mul_comm] using hE.1),
      (div_lt_iff₀ hlam).mpr (by simpa only [mul_comm] using hE.2)⟩
  refine ⟨⟨mul_lt_mul_of_pos_left hgap.1.endpoints_ordered hlam,
    (almostMathieuRealSpectrumSet_aubry_mul_iff hα hlam θ φ a).mpr hgap.1.left_mem,
    (almostMathieuRealSpectrumSet_aubry_mul_iff hα hlam θ φ b).mpr hgap.1.right_mem,
    ?_⟩, ?_⟩
  · intro E hE hspec
    exact hgap.1.interior_avoids (hin hE)
      ((almostMathieuRealSpectrumSet_aubry_div_iff hα hlam θ φ E).mp hspec)
  · intro E hE
    calc
      almostMathieuIDS α lam E = almostMathieuIDS α lam (lam * (E / lam)) := by
        rw [mul_div_cancel₀ E hlam.ne']
      _ = almostMathieuIDS α lam⁻¹ (E / lam) := almostMathieuIDS_aubry α hlam (E / lam)
      _ = label := hgap.2 (E / lam) (hin hE)

/-- Every prescribed gap at reciprocal coupling gives the same prescribed gap. -/
theorem amo_dryTenMartini_of_reciprocal {α : ℝ} (hα : Irrational α)
    {lam : ℝ} (hlam : 0 < lam) (h : AMODryTenMartini α lam⁻¹) :
    AMODryTenMartini α lam := by
  intro θ n hn
  obtain ⟨a, b, hgap⟩ := h 0 n hn
  exact ⟨lam * a, lam * b, amo_labelled_gap_aubry hα hlam θ 0 hgap⟩

/-- Duality fills in the supercritical couplings, using the already supplied
critical point rather than trying to derive it from duality itself. -/
theorem amo_all_positive_of_subcritical_and_critical {α : ℝ} (hα : Irrational α)
    (hopen : ∀ lam : ℝ, 0 < lam → lam ≤ 1 → AMODryTenMartini α lam) :
    ∀ lam : ℝ, 0 < lam → AMODryTenMartini α lam := by
  intro lam hlam
  by_cases hle : lam ≤ 1
  · exact hopen lam hlam hle
  · apply amo_dryTenMartini_of_reciprocal hα hlam
    exact hopen lam⁻¹ (inv_pos.mpr hlam)
      ((inv_le_one₀ hlam).mpr (le_of_lt (lt_of_not_ge hle)))

end CriticalDTM

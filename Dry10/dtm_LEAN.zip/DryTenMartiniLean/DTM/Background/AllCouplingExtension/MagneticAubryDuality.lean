import DTM.Background.Realization.MagneticTrace
import Mathlib.Algebra.Algebra.Spectrum.Basic

/-!
# Root-fixing magnetic Aubry duality at fixed flux

The action is the gauge-corrected quarter turn
`Jα u(j,k) = magneticPhase α (-(j*k)) * u(k,-j)`.
Its inverse uses the same phase and the opposite quarter turn. Both are
isometries of the actual lattice Hilbert space, not only maps of finite vectors.
The root-fixed intertwining gives the root moments without trace cyclicity.
-/

noncomputable section

namespace CriticalDTM

/-- The quarter turn used by the magnetic Aubry transform. -/
def magneticAubryRotation : Site ≃ Site where
  toFun s := (s.2, -s.1)
  invFun s := (-s.2, s.1)
  left_inv := by intro s; rcases s with ⟨j, k⟩; simp
  right_inv := by intro s; rcases s with ⟨j, k⟩; simp

/-- The concrete gauge-corrected quarter turn, with its explicit inverse. -/
def magneticAubryEquiv (α : ℝ) : MagneticHilbert ≃ₗᵢ[ℂ] MagneticHilbert where
  toFun := twistedVector magneticAubryRotation (fun s => magneticPhase α (-(s.1 * s.2)))
    (fun s => magneticPhase_norm α (-(s.1 * s.2)))
  invFun := twistedVector magneticAubryRotation.symm
    (fun s => magneticPhase α (-(s.1 * s.2)))
    (fun s => magneticPhase_norm α (-(s.1 * s.2)))
  left_inv := by
    intro u
    apply lp.ext
    funext s
    rcases s with ⟨j, k⟩
    simp [magneticAubryRotation, mul_comm, ← mul_assoc, ← magneticPhase_add,
      magneticPhase_zero]
  right_inv := by
    intro u
    apply lp.ext
    funext s
    rcases s with ⟨j, k⟩
    simp [magneticAubryRotation, mul_comm, ← mul_assoc, ← magneticPhase_add,
      magneticPhase_zero]
  map_add' := by
    intro u v
    apply lp.ext
    funext s
    simp [mul_add]
  map_smul' := by
    intro c u
    apply lp.ext
    funext s
    simp [mul_left_comm]
  norm_map' := twistedVector_norm magneticAubryRotation
    (fun s => magneticPhase α (-(s.1 * s.2)))
    (fun s => magneticPhase_norm α (-(s.1 * s.2)))

@[simp] theorem magneticAubryEquiv_apply (α : ℝ) (u : MagneticHilbert) (s : Site) :
    magneticAubryEquiv α u s = magneticPhase α (-(s.1 * s.2)) * u (s.2, -s.1) := rfl

@[simp] theorem magneticAubryEquiv_symm_apply (α : ℝ) (u : MagneticHilbert) (s : Site) :
    (magneticAubryEquiv α).symm u s =
      magneticPhase α (-(s.1 * s.2)) * u (-s.2, s.1) := rfl

/-- The physical root coordinate is unchanged. -/
@[simp] theorem magneticAubryEquiv_origin (α : ℝ) (u : MagneticHilbert) :
    magneticAubryEquiv α u origin = u origin := by
  simp [origin, magneticPhase_zero]

/-- The physical root vector, including its phase, is fixed. -/
@[simp] theorem magneticAubryEquiv_root (α : ℝ) :
    magneticAubryEquiv α hilbertRoot = hilbertRoot := by
  apply lp.ext
  funext s
  rcases s with ⟨j, k⟩
  by_cases h : (j, k) = origin
  · have h0 : j = 0 ∧ k = 0 := by simpa [origin, Prod.ext_iff] using h
    rcases h0 with ⟨rfl, rfl⟩
    simp [origin, magneticPhase_zero]
  · have h' : (k, -j) ≠ origin := by
      simpa [origin, Prod.ext_iff, and_comm] using h
    simp [latticeRoot, h, h']

/-- Exact duality for every nonzero complex coupling, at the same flux. -/
theorem magneticAubry_intertwines (α : ℝ) {z : ℂ} (hz : z ≠ 0) (u : MagneticHilbert) :
    magneticAubryEquiv α (hOperator α z u) =
      z • (hOperator α z⁻¹ (magneticAubryEquiv α u)) := by
  apply lp.ext
  funext s
  rcases s with ⟨j, k⟩
  simp only [magneticAubryEquiv_apply, hOperator_apply, hRow, east, west, north, south,
    lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  simp only [sub_eq_add_neg, neg_add, mul_add, add_mul, neg_mul, mul_neg,
    neg_neg, mul_one, one_mul, magneticPhase_add]
  have hj := magneticPhase_mul_neg α j
  field_simp [hz]
  linear_combination
    -(magneticPhase α (-(j * k)) * u (k + 1, -j)) * hj -
    (magneticPhase α (-(j * k)) * u (k + -1, -j)) * hj

/-- Power intertwining on arbitrary square-summable vectors. -/
theorem magneticAubry_intertwines_pow (α : ℝ) {z : ℂ} (hz : z ≠ 0)
    (k : ℕ) (u : MagneticHilbert) :
    magneticAubryEquiv α (((hOperator α z)^k) u) =
      z^k • (((hOperator α z⁻¹)^k) (magneticAubryEquiv α u)) := by
  induction k with
  | zero => simp
  | succ k ih =>
      rw [pow_succ', ContinuousLinearMap.mul_apply, magneticAubry_intertwines α hz, ih]
      simp only [map_smul, pow_succ', ContinuousLinearMap.mul_apply, smul_smul]

/-- Root moments follow from the fixed source and fixed root coordinate alone. -/
theorem magneticAubry_rootTrace_pow (α : ℝ) {z : ℂ} (hz : z ≠ 0) (k : ℕ) :
    rootTrace ((hOperator α z)^k) = z^k * rootTrace ((hOperator α z⁻¹)^k) := by
  have h := congrArg (fun u : MagneticHilbert => u origin)
    (magneticAubry_intertwines_pow α hz k hilbertRoot)
  simpa only [magneticAubryEquiv_origin, magneticAubryEquiv_root, lp.coeFn_smul,
    Pi.smul_apply, smul_eq_mul, rootTrace_apply] using h

/-- Conjugation by the concrete Hilbert-space unitary on bounded operators. -/
def magneticAubryOperatorEquiv (α : ℝ) :
    MagneticBoundedOperator ≃ₐ[ℂ] MagneticBoundedOperator where
  toFun A := (magneticAubryEquiv α).toContinuousLinearEquiv.toContinuousLinearMap.comp
    (A.comp (magneticAubryEquiv α).symm.toContinuousLinearEquiv.toContinuousLinearMap)
  invFun A := (magneticAubryEquiv α).symm.toContinuousLinearEquiv.toContinuousLinearMap.comp
    (A.comp (magneticAubryEquiv α).toContinuousLinearEquiv.toContinuousLinearMap)
  left_inv A := by ext u; simp
  right_inv A := by ext u; simp
  map_mul' A B := by ext u; simp
  map_add' A B := by ext u; simp
  commutes' c := by ext u; simp [Algebra.algebraMap_eq_smul_one]

@[simp] theorem magneticAubryOperatorEquiv_apply (α : ℝ)
    (A : MagneticBoundedOperator) (u : MagneticHilbert) :
    magneticAubryOperatorEquiv α A u =
      magneticAubryEquiv α (A ((magneticAubryEquiv α).symm u)) := rfl

theorem magneticAubry_conjugacy (α : ℝ) {z : ℂ} (hz : z ≠ 0) :
    magneticAubryOperatorEquiv α (hOperator α z) = z • hOperator α z⁻¹ := by
  apply ContinuousLinearMap.ext
  intro u
  simp only [magneticAubryOperatorEquiv_apply, magneticAubry_intertwines α hz,
    LinearIsometryEquiv.apply_symm_apply, ContinuousLinearMap.smul_apply]

/-- Full complex spectral membership under reciprocal coupling and energy scaling. -/
theorem magnetic_spectrum_aubry_mul (α : ℝ) {z : ℂ} (hz : z ≠ 0) (E : ℂ) :
    z * E ∈ spectrum ℂ (hOperator α z) ↔ E ∈ spectrum ℂ (hOperator α z⁻¹) := by
  rw [← AlgEquiv.spectrum_eq (magneticAubryOperatorEquiv α) (hOperator α z),
    magneticAubry_conjugacy α hz]
  simpa only [Units.smul_def, Units.val_mk0, smul_eq_mul] using
    (spectrum.smul_mem_smul_iff (a := hOperator α z⁻¹) (s := E) (r := Units.mk0 z hz))

/-- Fixed-flux Aubry duality, with energy divided by the original coupling. -/
theorem magnetic_spectrum_aubry (α : ℝ) {z : ℂ} (hz : z ≠ 0) (E : ℂ) :
    E ∈ spectrum ℂ (hOperator α z) ↔ E / z ∈ spectrum ℂ (hOperator α z⁻¹) := by
  simpa only [mul_div_cancel₀ E hz] using magnetic_spectrum_aubry_mul α hz (E / z)

end CriticalDTM

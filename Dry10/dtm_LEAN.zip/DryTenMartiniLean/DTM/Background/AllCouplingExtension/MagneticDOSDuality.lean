import DTM.Background.AllCouplingExtension.MagneticAubryDuality
import DTM.Background.Realization.AMOMagneticMeasureBridge
import DTM.Background.EmpiricalIDS.CompactMomentUniqueness

/-!
# Aubry scaling of the actual density-of-states measure

The origin-fixing magnetic Aubry unitary transports all root moments. Compact
moment uniqueness upgrades this to equality of the actual probability measures,
not just equality of spectral gap labels. Positive energy scaling then preserves
the strict lower mass at every energy, without an atom-free hypothesis.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set
open scoped ContinuousFunctionalCalculus

/-- The internal Hamiltonian has the elementary physical operator norm bound. -/
theorem magneticAlgebraHamiltonian_norm_le (α lam : ℝ) :
    ‖magneticAlgebraHamiltonian α lam‖ ≤ 2 + 2 * |lam| := by
  change ‖(magneticAlgebraHamiltonian α lam : MagneticBoundedOperator)‖ ≤ _
  rw [magneticAlgebraHamiltonian_coe]
  simpa only [Complex.norm_real, Real.norm_eq_abs] using hOperator_norm_le α (lam : ℂ)

/-- The actual root probability is concentrated in its elementary norm window. -/
theorem magneticRealSpectralMeasure_window (α lam : ℝ) :
    magneticRealSpectralMeasure α lam
      (Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|)) = 1 := by
  rw [magneticRealSpectralMeasure,
    Measure.map_apply continuous_subtype_val.measurable measurableSet_Icc]
  have hpre : (fun x : MagneticRealSpectrum α lam => (x : ℝ)) ⁻¹'
      Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|) = univ := by
    apply Set.eq_univ_of_forall
    intro x
    exact real_spectrum_subset_Icc_of_norm_le _
      (magneticAlgebraHamiltonian_norm_le α lam) x.property
  rw [hpre, measure_univ]

/-- Power moments of the existing measure are actual origin matrix elements. -/
theorem magneticRealSpectralMeasure_moment (α lam : ℝ) (k : ℕ) :
    (∫ x : ℝ, x ^ k ∂magneticRealSpectralMeasure α lam) =
      (rootTrace ((hOperator α (lam : ℂ)) ^ k)).re := by
  rw [magneticRealSpectralMeasure_integral_cfc α lam
      (fun x : ℝ => x ^ k) (continuous_id.pow k), magneticTraceReal_apply,
    magneticAlgebraHamiltonian_cfc_coe α lam (fun x : ℝ => x ^ k) (continuous_id.pow k),
    cfc_pow_id _ k (hOperator_isSelfAdjoint α lam)]

/-- Scaling the inverse-coupling probability puts it in the same compact window. -/
theorem magneticRealSpectralMeasure_inverse_map_window (α : ℝ) {lam : ℝ}
    (hlam : 0 < lam) :
    ((magneticRealSpectralMeasure α lam⁻¹).map (fun x : ℝ => lam * x))
      (Icc (-(2 + 2 * lam)) (2 + 2 * lam)) = 1 := by
  have hscale : Measurable (fun x : ℝ => lam * x) :=
    (continuous_const.mul continuous_id).measurable
  rw [magneticRealSpectralMeasure, Measure.map_map hscale continuous_subtype_val.measurable,
    Measure.map_apply (hscale.comp continuous_subtype_val.measurable) measurableSet_Icc]
  have hpre : ((fun x : ℝ => lam * x) ∘
      (fun x : MagneticRealSpectrum α lam⁻¹ => (x : ℝ))) ⁻¹'
        Icc (-(2 + 2 * lam)) (2 + 2 * lam) = univ := by
    apply Set.eq_univ_of_forall
    intro x
    have hx := real_spectrum_subset_Icc_of_norm_le _
      (magneticAlgebraHamiltonian_norm_le α lam⁻¹) x.property
    rw [abs_of_pos (inv_pos.mpr hlam)] at hx
    have hleft := mul_le_mul_of_nonneg_left hx.1 hlam.le
    have hright := mul_le_mul_of_nonneg_left hx.2 hlam.le
    have hinv : lam * lam⁻¹ = 1 := mul_inv_cancel₀ (ne_of_gt hlam)
    change -(2 + 2 * lam) ≤ lam * (x : ℝ) ∧ lam * (x : ℝ) ≤ 2 + 2 * lam
    constructor <;> nlinarith
  rw [hpre, measure_univ]

/-- Ordinary change of variables for every power moment of the scaled measure. -/
theorem magneticRealSpectralMeasure_map_moment (α lam scale : ℝ) (k : ℕ) :
    (∫ x : ℝ, x ^ k ∂(magneticRealSpectralMeasure α lam).map
      (fun x : ℝ => scale * x)) =
        scale ^ k * (rootTrace ((hOperator α (lam : ℂ)) ^ k)).re := by
  rw [integral_map (φ := fun x : ℝ => scale * x) (f := fun x : ℝ => x ^ k)
    (continuous_const.mul continuous_id).measurable.aemeasurable
    (continuous_id.pow k).aestronglyMeasurable]
  simp_rw [mul_pow]
  rw [integral_const_mul, magneticRealSpectralMeasure_moment]

/-- Global Aubry scaling of the actual root-state probability measure.
The proof transports concrete root moments and uses their compact support;
measure matching is a conclusion, not an assumption. -/
theorem magneticRealSpectralMeasure_aubry (α : ℝ) {lam : ℝ} (hlam : 0 < lam) :
    magneticRealSpectralMeasure α lam =
      (magneticRealSpectralMeasure α lam⁻¹).map (fun E : ℝ => lam * E) := by
  have hscale : Measurable (fun x : ℝ => lam * x) :=
    (continuous_const.mul continuous_id).measurable
  letI : IsProbabilityMeasure
      ((magneticRealSpectralMeasure α lam⁻¹).map (fun x : ℝ => lam * x)) :=
    isProbabilityMeasure_map hscale.aemeasurable
  let μ : ProbabilityMeasure ℝ := ⟨magneticRealSpectralMeasure α lam, inferInstance⟩
  let ν : ProbabilityMeasure ℝ :=
    ⟨(magneticRealSpectralMeasure α lam⁻¹).map (fun x : ℝ => lam * x), inferInstance⟩
  have hμ : (μ : Measure ℝ) (Icc (-(2 + 2 * lam)) (2 + 2 * lam)) = 1 := by
    simpa only [μ, abs_of_pos hlam] using magneticRealSpectralMeasure_window α lam
  have hν : (ν : Measure ℝ) (Icc (-(2 + 2 * lam)) (2 + 2 * lam)) = 1 :=
    magneticRealSpectralMeasure_inverse_map_window α hlam
  have heq : μ = ν := by
    apply probabilityMeasure_eq_of_compact_moments μ ν
      (-(2 + 2 * lam)) (2 + 2 * lam) hμ hν
    intro k
    change (∫ x : ℝ, x ^ k ∂magneticRealSpectralMeasure α lam) =
      ∫ x : ℝ, x ^ k ∂(magneticRealSpectralMeasure α lam⁻¹).map (fun x : ℝ => lam * x)
    rw [magneticRealSpectralMeasure_moment, magneticRealSpectralMeasure_map_moment]
    have h := congrArg Complex.re (magneticAubry_rootTrace_pow α
      (z := (lam : ℂ)) (Complex.ofReal_ne_zero.mpr (ne_of_gt hlam)) k)
    simpa only [← Complex.ofReal_inv, ← Complex.ofReal_pow, Complex.mul_re,
      Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero] using h
  exact congrArg (fun ρ : ProbabilityMeasure ℝ => (ρ : Measure ℝ)) heq

/-- Positive Aubry energy scaling preserves the strict lower mass at every
energy, including spectral energies and atoms. -/
theorem magneticLowerMass_aubry (α : ℝ) {lam : ℝ} (hlam : 0 < lam) (E : ℝ) :
    magneticLowerMass α lam (lam * E) = magneticLowerMass α lam⁻¹ E := by
  unfold magneticLowerMass
  rw [magneticRealSpectralMeasure_aubry α hlam,
    Measure.map_apply (f := fun x : ℝ => lam * x)
      (continuous_const.mul continuous_id).measurable measurableSet_Iio]
  have hpre : (fun x : ℝ => lam * x) ⁻¹' Iio (lam * E) = Iio E := by
    ext x
    exact mul_lt_mul_left hlam
  rw [hpre]

/-- The original phase-averaged almost Mathieu IDS obeys the same all-energy
scaling law, for every real frequency and every positive coupling. -/
theorem almostMathieuIDS_aubry (α : ℝ) {lam : ℝ} (hlam : 0 < lam) (E : ℝ) :
    almostMathieuIDS α lam (lam * E) = almostMathieuIDS α lam⁻¹ E := by
  simpa only [magneticLowerMass_eq_almostMathieuIDS] using magneticLowerMass_aubry α hlam E

end CriticalDTM

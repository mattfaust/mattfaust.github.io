import DTM.Background.Avalanche.AvalancheAMO
import DTM.Background.Avalanche.AvalancheScale
import DTM.Background.Transfer.AMOTransferShiftBounds

/-!
# Averaging the proved avalanche principle for actual AMO blocks

The bad set is an ordinary measurable subset of the normalized phase line;
its mass is measured on `(0,1]`. All pointwise functions below are actual
AMO transfer logarithms. No large-deviation assertion is assumed as a global
spectral input or claimed proved here.
-/

noncomputable section

open MeasureTheory Set
open scoped BigOperators

namespace CriticalDTM

/-- The normalized avalanche defect for `n+2` consecutive blocks of length `N`. -/
def amoAvalancheDefect (α lam : ℝ) (z : ℂ) (N n : ℕ) (x : ℝ) : ℝ :=
  (amoTransferLogNorm α lam z (2 * Real.pi * x) ((n + 2) * N) +
    (∑ j ∈ Finset.range n, amoTransferLogNorm α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N) -
    ∑ j ∈ Finset.range (n + 1), amoTransferLogNorm α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N)) /
      (((n + 2) * N : ℕ) : ℝ)

theorem amoAvalanche_shift_integrable (α lam : ℝ) (z : ℂ) (k : ℕ) (r : ℝ) :
    IntervalIntegrable (fun x => amoTransferLogNorm α lam z (2 * Real.pi * x + r) k)
      volume 0 1 :=
  ((continuous_amoTransferLogNorm_phase α lam z k).comp
    ((continuous_const.mul continuous_id).add continuous_const)).intervalIntegrable 0 1

theorem amoAvalanche_shift_integral (α lam : ℝ) (z : ℂ) (k : ℕ) (r : ℝ) :
    (∫ x in (0 : ℝ)..1, amoTransferLogNorm α lam z (2 * Real.pi * x + r) k) =
      amoTransferLogAverage α lam z k := by
  have h := intervalIntegral.integral_comp_mul_left (a := 0) (b := 1)
    (c := 2 * Real.pi) (fun θ => amoTransferLogNorm α lam z (θ + r) k) (by positivity)
  simp only [mul_zero, mul_one, amoTransferLogNorm_integral_shift] at h
  simpa only [amoTransferLogAverage, smul_eq_mul, div_eq_mul_inv, mul_comm] using h

theorem amoAvalanche_average_eq_mul_finite (α lam : ℝ) (z : ℂ) (k : ℕ) :
    amoTransferLogAverage α lam z k = (k : ℝ) * amoFiniteLyapunov α lam z k := by
  cases k with
  | zero => simp
  | succ k =>
      unfold amoFiniteLyapunov
      field_simp

/-- Exact phase integration, including all multiplicities and normalizations. -/
theorem amoAvalancheDefect_integral (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N) :
    (∫ x in (0 : ℝ)..1, amoAvalancheDefect α lam z N n x) =
      amoFiniteLyapunov α lam z ((n + 2) * N) +
        (n : ℝ) / (n + 2 : ℕ) * amoFiniteLyapunov α lam z N -
        (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z (2 * N) := by
  have h0 := amoAvalanche_shift_integrable α lam z ((n + 2) * N) 0
  simp only [add_zero] at h0
  have h1 : IntervalIntegrable (fun x => ∑ j ∈ Finset.range n,
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N) volume 0 1 := by
    convert IntervalIntegrable.sum (Finset.range n)
      (fun j _ => amoAvalanche_shift_integrable α lam z N
        (2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ))) using 1
    ext x
    simp only [Finset.sum_apply]
  have h2 : IntervalIntegrable (fun x => ∑ j ∈ Finset.range (n + 1),
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N)) volume 0 1 := by
    convert IntervalIntegrable.sum (Finset.range (n + 1))
      (fun j _ => amoAvalanche_shift_integrable α lam z (2 * N)
        (2 * Real.pi * α * ((j * N : ℕ) : ℝ))) using 1
    ext x
    simp only [Finset.sum_apply]
  unfold amoAvalancheDefect
  rw [intervalIntegral.integral_div, intervalIntegral.integral_sub (h0.add h1) h2,
    intervalIntegral.integral_add h0 h1,
    intervalIntegral.integral_finset_sum (fun j _ => amoAvalanche_shift_integrable α lam z N
      (2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ))),
    intervalIntegral.integral_finset_sum (fun j _ => amoAvalanche_shift_integrable α lam z (2 * N)
      (2 * Real.pi * α * ((j * N : ℕ) : ℝ)))]
  have hfirst := amoAvalanche_shift_integral α lam z ((n + 2) * N) 0
  simp only [add_zero] at hfirst
  rw [hfirst]
  simp_rw [amoAvalanche_shift_integral, amoAvalanche_average_eq_mul_finite]
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  have hmr : ((n + 2 : ℕ) : ℝ) ≠ 0 := by positivity
  push_cast
  field_simp
  ring

/-- The global bound uses nonnegativity of every actual transfer logarithm,
not a sum of unrelated absolute values. -/
theorem amoAvalancheDefect_abs_le (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N) (x : ℝ) :
    |amoAvalancheDefect α lam z N n x| ≤ 2 * Real.log (amoTransferBound lam z) := by
  have hB : 0 ≤ Real.log (amoTransferBound lam z) := Real.log_nonneg (amoTransferBound_one_le lam z)
  have h0 := amoTransferLogNorm_nonneg α lam z (2 * Real.pi * x) ((n + 2) * N)
  have hu0 := amoTransferLogNorm_le_mul_log_bound α lam z (2 * Real.pi * x) ((n + 2) * N)
  have h1 := Finset.sum_nonneg (s := Finset.range n) (fun j _ =>
    amoTransferLogNorm_nonneg α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N)
  have h2 := Finset.sum_nonneg (s := Finset.range (n + 1)) (fun j _ =>
    amoTransferLogNorm_nonneg α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N))
  have hu1 := Finset.sum_le_sum (s := Finset.range n) (fun j _ =>
    amoTransferLogNorm_le_mul_log_bound α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N)
  have hu2 := Finset.sum_le_sum (s := Finset.range (n + 1)) (fun j _ =>
    amoTransferLogNorm_le_mul_log_bound α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N))
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at hu1 hu2
  have hden : (0 : ℝ) < (((n + 2) * N : ℕ) : ℝ) := by positivity
  unfold amoAvalancheDefect
  rw [abs_div, abs_of_pos hden]
  apply (div_le_iff₀ hden).mpr
  apply abs_le.mpr
  push_cast at h0 h1 h2 hu0 hu1 hu2 ⊢
  have hNB : 0 ≤ (N : ℝ) * Real.log (amoTransferBound lam z) := mul_nonneg (Nat.cast_nonneg N) hB
  constructor <;> nlinarith

/-- The pointwise good-phase estimate is an application of the proved actual
matrix AP; the block and adjacent-pair identifications are also proved. -/
theorem amoAvalancheDefect_good (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N)
    (x : ℝ) {μ : ℝ} (hμ : 10000 ≤ μ)
    (hlarge : ∀ j < n + 2, μ ≤ amoTransferNorm (amoTransferProduct α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N))
    (hpair : ∀ j < n + 1,
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N +
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N -
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) ≤ Real.log μ / 2) :
    |amoAvalancheDefect α lam z N n x| ≤ 1000 / ((N : ℝ) * μ) := by
  have hp (j : ℕ) (hj : j < n + 1) := hpair j hj
  simp only [amoTransferLogNorm, ← amoTransferProduct_avalanche_pair] at hp
  have h := avalanche_principle_log (fun j => amoTransferProduct α lam z
    (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N) n
    (fun _ => amoTransferProduct_det α lam z _ N) hμ hlarge hp
  simp only [amoTransferProduct_avalanche_blocks, amoTransferProduct_avalanche_pair] at h
  have hden : (0 : ℝ) < (((n + 2) * N : ℕ) : ℝ) := by positivity
  unfold amoAvalancheDefect
  rw [abs_div, abs_of_pos hden]
  refine (div_le_div_of_nonneg_right h hden.le).trans_eq ?_
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  have hmr : ((n + 2 : ℕ) : ℝ) ≠ 0 := by positivity
  have hμr : μ ≠ 0 := by linarith
  push_cast
  field_simp
  ring

/-- Elementary good-set/bad-set integration on a probability space. -/
theorem amoAvalanche_integral_badset_bound {Ω : Type*} [MeasurableSpace Ω]
    (ν : Measure Ω) [IsProbabilityMeasure ν] (f : Ω → ℝ) {s : Set Ω}
    (hs : MeasurableSet s) {a b δ : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hδ : ν.real s ≤ δ) (hgood : ∀ x ∉ s, |f x| ≤ a) (hall : ∀ x, |f x| ≤ b) :
    |∫ x, f x ∂ν| ≤ a + b * δ := by
  classical
  have hi : Integrable (fun x => a + s.indicator (fun _ => b) x) ν :=
    (integrable_const a).add ((integrable_const b).indicator hs)
  have h := norm_integral_le_of_norm_le hi (Filter.Eventually.of_forall (fun x => by
    rw [Real.norm_eq_abs]
    by_cases hx : x ∈ s
    · simpa [hx] using (hall x).trans (show b ≤ a + b by linarith)
    · simpa [hx] using hgood x hx))
  rw [integral_add (integrable_const a) ((integrable_const b).indicator hs),
    integral_const, integral_indicator_const b hs] at h
  simp only [measureReal_univ_eq_one, one_smul, smul_eq_mul, Real.norm_eq_abs] at h
  nlinarith [mul_le_mul_of_nonneg_left hδ hb]

/-- Actual averaged AMO AP, with an explicit measurable bad set of phase mass
at most `δ`. The finite good-phase conditions are not a spectral assumption. -/
theorem amoFiniteLyapunov_avalanche_average (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N)
    {μ δ : ℝ} (hμ : 10000 ≤ μ) {s : Set ℝ} (hs : MeasurableSet s)
    (hδ : (volume.restrict (Ioc (0 : ℝ) 1)).real s ≤ δ)
    (hlarge : ∀ x ∉ s, ∀ j < n + 2, μ ≤ amoTransferNorm (amoTransferProduct α lam z
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N))
    (hpair : ∀ x ∉ s, ∀ j < n + 1,
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N +
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N -
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) ≤ Real.log μ / 2) :
    |amoFiniteLyapunov α lam z ((n + 2) * N) +
      (n : ℝ) / (n + 2 : ℕ) * amoFiniteLyapunov α lam z N -
      (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z (2 * N)| ≤
        1000 / ((N : ℝ) * μ) + 2 * Real.log (amoTransferBound lam z) * δ := by
  let ν : Measure ℝ := volume.restrict (Ioc (0 : ℝ) 1)
  haveI : IsProbabilityMeasure ν := ⟨by simp [ν]⟩
  have hμ0 : 0 < μ := by linarith
  have h := amoAvalanche_integral_badset_bound ν (amoAvalancheDefect α lam z N n) hs
    (show 0 ≤ 1000 / ((N : ℝ) * μ) by positivity)
    (show 0 ≤ 2 * Real.log (amoTransferBound lam z) from mul_nonneg (by norm_num)
      (Real.log_nonneg (amoTransferBound_one_le lam z))) hδ
    (fun x hx => amoAvalancheDefect_good α lam z N n hN x hμ (hlarge x hx) (hpair x hx))
    (amoAvalancheDefect_abs_le α lam z N n hN)
  rw [← amoAvalancheDefect_integral α lam z N n hN,
    intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)]
  exact h

end CriticalDTM

import DTM.Background.Transfer.AMOTransferShiftBounds

/-!
# The actual finite union of AMO avalanche bad phases

The two base bad sets use the actual normalized transfer logarithms. Their
shifted union has measure at most `2 (n+2) δ`, proved using unit-period
Lebesgue translation invariance and finite subadditivity.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace CriticalDTM

/-- Actual finite transfer logarithm in unit phase, normalized by length. -/
def amoAvalanchePhaseLog (α lam : ℝ) (z : ℂ) (N : ℕ) (x : ℝ) : ℝ :=
  amoTransferLogNorm α lam z (2 * Real.pi * x) N / (N : ℝ)

theorem continuous_amoAvalanchePhaseLog (α lam : ℝ) (z : ℂ) (N : ℕ) :
    Continuous (amoAvalanchePhaseLog α lam z N) :=
  ((continuous_amoTransferLogNorm_phase α lam z N).comp
    (continuous_const.mul continuous_id)).div_const (N : ℝ)

theorem amoAvalanchePhaseLog_periodic (α lam : ℝ) (z : ℂ) (N : ℕ) :
    Function.Periodic (amoAvalanchePhaseLog α lam z N) 1 := by
  intro x
  unfold amoAvalanchePhaseLog
  rw [show 2 * Real.pi * (x + 1) = 2 * Real.pi * x + 2 * Real.pi by ring]
  exact congrArg (fun u : ℝ => u / (N : ℝ))
    (amoTransferLogNorm_periodic α lam z N (2 * Real.pi * x))

/-- One finite-scale deviation set; it is not a spectral property. -/
def amoAvalancheBaseBadSet (α lam : ℝ) (z : ℂ) (N : ℕ) (κ : ℝ) : Set ℝ :=
  {x | κ < |amoAvalanchePhaseLog α lam z N x - amoFiniteLyapunov α lam z N|}

theorem measurableSet_amoAvalancheBaseBadSet (α lam : ℝ) (z : ℂ) (N : ℕ) (κ : ℝ) :
    MeasurableSet (amoAvalancheBaseBadSet α lam z N κ) :=
  (isOpen_lt continuous_const
    ((continuous_amoAvalanchePhaseLog α lam z N).sub continuous_const).abs).measurableSet

theorem amoAvalancheBaseBadSet_add_one (α lam : ℝ) (z : ℂ) (N : ℕ) (κ x : ℝ) :
    x + 1 ∈ amoAvalancheBaseBadSet α lam z N κ ↔ x ∈ amoAvalancheBaseBadSet α lam z N κ := by
  change κ < |amoAvalanchePhaseLog α lam z N (x + 1) - _| ↔ _
  rw [amoAvalanchePhaseLog_periodic]
  rfl

/-- Normalized Lebesgue mass of a periodic measurable set is shift invariant. -/
theorem amoAvalanche_periodic_set_shift_mass {s : Set ℝ} (hs : MeasurableSet s)
    (hp : ∀ x : ℝ, x + 1 ∈ s ↔ x ∈ s) (r : ℝ) :
    (volume.restrict (Ioc (0 : ℝ) 1)).real ((fun x => x + r) ⁻¹' s) =
      (volume.restrict (Ioc (0 : ℝ) 1)).real s := by
  classical
  have ht : MeasurableSet ((fun x => x + r) ⁻¹' s) :=
    hs.preimage (continuous_id.add continuous_const).measurable
  have hI (u : Set ℝ) (hu : MeasurableSet u) :
      (∫ x in (0 : ℝ)..1, u.indicator (fun _ => (1 : ℝ)) x) =
        (volume.restrict (Ioc (0 : ℝ) 1)).real u := by
    rw [intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)]
    simpa only [smul_eq_mul, mul_one] using
      (integral_indicator_const (μ := volume.restrict (Ioc (0 : ℝ) 1)) (1 : ℝ) hu)
  have hper : Function.Periodic (s.indicator (fun _ => (1 : ℝ))) 1 := by
    intro x
    by_cases hx : x ∈ s
    · have hx' := (hp x).mpr hx
      simp [hx, hx']
    · have hx' : x + 1 ∉ s := fun hh => hx ((hp x).mp hh)
      simp [hx, hx']
  calc
    (volume.restrict (Ioc (0 : ℝ) 1)).real ((fun x => x + r) ⁻¹' s) =
        ∫ x in (0 : ℝ)..1, ((fun x => x + r) ⁻¹' s).indicator (fun _ => (1 : ℝ)) x := (hI _ ht).symm
    _ = ∫ x in (0 : ℝ)..1, s.indicator (fun _ => (1 : ℝ)) (x + r) := by
      congr 1
    _ = ∫ x in (0 : ℝ)..1, s.indicator (fun _ => (1 : ℝ)) x := by
      rw [intervalIntegral.integral_comp_add_right]
      simpa only [zero_add, add_comm 1 r] using hper.intervalIntegral_add_eq r 0
    _ = _ := hI s hs

/-- The finite union for `n+2` consecutive `N`-blocks and `n+1` adjacent pairs. -/
def amoAvalancheBadSet (α lam : ℝ) (z : ℂ) (N n : ℕ) (κ : ℝ) : Set ℝ :=
  (⋃ j ∈ Finset.range (n + 2), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
    amoAvalancheBaseBadSet α lam z N κ) ∪
  (⋃ j ∈ Finset.range (n + 1), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
    amoAvalancheBaseBadSet α lam z (2 * N) κ)

theorem measurableSet_amoAvalancheBadSet (α lam : ℝ) (z : ℂ) (N n : ℕ) (κ : ℝ) :
    MeasurableSet (amoAvalancheBadSet α lam z N n κ) := by
  apply MeasurableSet.union
  · exact MeasurableSet.iUnion fun _ => MeasurableSet.iUnion fun _ =>
      (measurableSet_amoAvalancheBaseBadSet α lam z N κ).preimage
        (continuous_id.add continuous_const).measurable
  · exact MeasurableSet.iUnion fun _ => MeasurableSet.iUnion fun _ =>
      (measurableSet_amoAvalancheBaseBadSet α lam z (2 * N) κ).preimage
        (continuous_id.add continuous_const).measurable

/-- Two finite-scale exceptional masses control the actual shifted union. -/
theorem amoAvalancheBadSet_mass_le (α lam : ℝ) (z : ℂ) (N n : ℕ) (κ : ℝ) {δ : ℝ}
    (hN : (volume.restrict (Ioc (0 : ℝ) 1)).real (amoAvalancheBaseBadSet α lam z N κ) ≤ δ)
    (h2N : (volume.restrict (Ioc (0 : ℝ) 1)).real (amoAvalancheBaseBadSet α lam z (2 * N) κ) ≤ δ) :
    (volume.restrict (Ioc (0 : ℝ) 1)).real (amoAvalancheBadSet α lam z N n κ) ≤
      2 * (n + 2 : ℕ) * δ := by
  let ν : Measure ℝ := volume.restrict (Ioc (0 : ℝ) 1)
  have hs (k m : ℕ) (hk : ν.real (amoAvalancheBaseBadSet α lam z k κ) ≤ δ) :
      ν.real (⋃ j ∈ Finset.range m, (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
        amoAvalancheBaseBadSet α lam z k κ) ≤ (m : ℝ) * δ := by
    refine (measureReal_biUnion_finset_le (μ := ν) (Finset.range m) _).trans ?_
    calc
      (∑ j ∈ Finset.range m, ν.real ((fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
          amoAvalancheBaseBadSet α lam z k κ)) ≤ ∑ _j ∈ Finset.range m, δ := by
        apply Finset.sum_le_sum
        intro j _
        rw [show ν.real ((fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
          amoAvalancheBaseBadSet α lam z k κ) = ν.real (amoAvalancheBaseBadSet α lam z k κ) from
          amoAvalanche_periodic_set_shift_mass (measurableSet_amoAvalancheBaseBadSet α lam z k κ)
            (amoAvalancheBaseBadSet_add_one α lam z k κ) _]
        exact hk
      _ = _ := by simp
  have hδ : 0 ≤ δ := measureReal_nonneg.trans hN
  have hu := measureReal_union_le (μ := ν)
    (⋃ j ∈ Finset.range (n + 2), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
      amoAvalancheBaseBadSet α lam z N κ)
    (⋃ j ∈ Finset.range (n + 1), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
      amoAvalancheBaseBadSet α lam z (2 * N) κ)
  have h1 := hs N (n + 2) hN
  have h2 := hs (2 * N) (n + 1) h2N
  change ν.real _ ≤ _
  unfold amoAvalancheBadSet
  push_cast at hu h1 h2 ⊢
  linarith

/-- Outside this constructed union all the required block and pair deviations
are small. -/
theorem amoAvalancheBadSet_good (α lam : ℝ) (z : ℂ) (N n : ℕ) (κ x : ℝ)
    (hx : x ∉ amoAvalancheBadSet α lam z N n κ) :
    (∀ j < n + 2, |amoAvalanchePhaseLog α lam z N (x + α * ((j * N : ℕ) : ℝ)) -
      amoFiniteLyapunov α lam z N| ≤ κ) ∧
    (∀ j < n + 1, |amoAvalanchePhaseLog α lam z (2 * N) (x + α * ((j * N : ℕ) : ℝ)) -
      amoFiniteLyapunov α lam z (2 * N)| ≤ κ) := by
  simp only [amoAvalancheBadSet, mem_union, mem_iUnion, Finset.mem_range, mem_preimage,
    amoAvalancheBaseBadSet, mem_setOf_eq] at hx
  constructor
  · intro j hj
    exact le_of_not_gt (fun hh => hx (Or.inl ⟨j, hj, hh⟩))
  · intro j hj
    exact le_of_not_gt (fun hh => hx (Or.inr ⟨j, hj, hh⟩))

end CriticalDTM

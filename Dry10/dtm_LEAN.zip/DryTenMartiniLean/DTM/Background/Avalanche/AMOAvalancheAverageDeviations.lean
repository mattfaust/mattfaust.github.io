import DTM.Background.Avalanche.AMOAvalancheAverage
import DTM.Background.Avalanche.AMOAvalancheAverageBadSet

/-!
# Averaged AMO avalanche propagation from two finite deviation masses

This file constructs the finite shifted exceptional union and proves the
resulting finite-scale averaged estimate. Only the two stated finite
large-deviation masses remain hypotheses; no LDT or endpoint conclusion is
claimed here.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace CriticalDTM

/-- Small deviations at scales `N` and `2N` give the precise growth and
no-cancellation conditions needed by the proved finite AP. -/
theorem amoAvalanche_good_of_deviations (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N)
    (x : ℝ) {κ : ℝ} (hκ : 0 < κ)
    (hL : 400 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤ amoFiniteLyapunov α lam z (2 * N))
    (hdN : ∀ j < n + 2,
      |amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N / (N : ℝ) -
          amoFiniteLyapunov α lam z N| ≤ κ)
    (hd2N : ∀ j < n + 1,
      |amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) / ((2 * N : ℕ) : ℝ) -
          amoFiniteLyapunov α lam z (2 * N)| ≤ κ) :
    (∀ j < n + 2, Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2) ≤
      amoTransferNorm (amoTransferProduct α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N)) ∧
    (∀ j < n + 1,
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N +
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N -
      amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) ≤
          Real.log (Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) / 2) := by
  have hNr : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN
  have h2Nr : (0 : ℝ) < ((2 * N : ℕ) : ℝ) := by positivity
  have hLN := mul_le_mul_of_nonneg_left hL hNr.le
  have hL2N := mul_le_mul_of_nonneg_left hL2 hNr.le
  have hNκ : 0 ≤ (N : ℝ) * κ := mul_nonneg hNr.le hκ.le
  constructor
  · intro j hj
    have hlo : (amoFiniteLyapunov α lam z N - κ) * (N : ℝ) ≤
        amoTransferLogNorm α lam z
          (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N := by
      apply (le_div_iff₀ hNr).mp
      linarith [(abs_le.mp (hdN j hj)).1]
    apply (Real.log_le_log_iff (Real.exp_pos _)
      (amoTransferProduct_norm_pos α lam z _ N)).mp
    rw [Real.log_exp]
    change (N : ℝ) * amoFiniteLyapunov α lam z N / 2 ≤
      amoTransferLogNorm α lam z _ N
    nlinarith
  · intro j hj
    have hhi0 : amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N ≤
        (amoFiniteLyapunov α lam z N + κ) * (N : ℝ) := by
      apply (div_le_iff₀ hNr).mp
      linarith [(abs_le.mp (hdN j (by omega))).2]
    have hhi1 : amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N ≤
        (amoFiniteLyapunov α lam z N + κ) * (N : ℝ) := by
      apply (div_le_iff₀ hNr).mp
      linarith [(abs_le.mp (hdN (j + 1) (by omega))).2]
    have hlo2 : (amoFiniteLyapunov α lam z (2 * N) - κ) * ((2 * N : ℕ) : ℝ) ≤
        amoTransferLogNorm α lam z
          (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) := by
      apply (le_div_iff₀ h2Nr).mp
      linarith [(abs_le.mp (hd2N j hj)).1]
    rw [Real.log_exp]
    simp only [Nat.cast_mul, Nat.cast_ofNat] at hhi0 hhi1 hlo2 ⊢
    nlinarith

/-- The finite-scale averaged propagation estimate, including its endpoint
multiplicity correction. The block count is `m=n+2`. -/
theorem amoFiniteLyapunov_avalanche_of_deviation_masses
    (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N) {κ δ : ℝ} (hκ : 0 < κ)
    (hL : 400 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤ amoFiniteLyapunov α lam z (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2)
    (hbadN : (volume.restrict (Ioc (0 : ℝ) 1)).real (amoAvalancheBaseBadSet α lam z N κ) ≤ δ)
    (hbad2N : (volume.restrict (Ioc (0 : ℝ) 1)).real (amoAvalancheBaseBadSet α lam z (2 * N) κ) ≤ δ) :
    (|amoFiniteLyapunov α lam z ((n + 2) * N) +
      (n : ℝ) / (n + 2 : ℕ) * amoFiniteLyapunov α lam z N -
      (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
          4 * Real.log (amoTransferBound lam z) * (n + 2 : ℕ) * δ) ∧
    (|amoFiniteLyapunov α lam z ((n + 2) * N) + amoFiniteLyapunov α lam z N -
        2 * amoFiniteLyapunov α lam z (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
          4 * Real.log (amoTransferBound lam z) * (n + 2 : ℕ) * δ +
          2 * Real.log (amoTransferBound lam z) / (n + 2 : ℕ)) := by
  have hμ : 10000 ≤ Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2) := by
    have h := Real.exp_le_exp.mpr hscale
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 10000)] using h
  have hgood (x : ℝ) (hx : x ∉ amoAvalancheBadSet α lam z N n κ) :=
    amoAvalancheBadSet_good α lam z N n κ x hx
  have hphase (k j : ℕ) (x : ℝ) :
      amoAvalanchePhaseLog α lam z k (x + α * ((j * N : ℕ) : ℝ)) =
        amoTransferLogNorm α lam z
          (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) k / (k : ℝ) := by
    unfold amoAvalanchePhaseLog
    congr 2
    ring
  have hconditions (x : ℝ) (hx : x ∉ amoAvalancheBadSet α lam z N n κ) :=
    amoAvalanche_good_of_deviations α lam z N n hN x hκ hL hL2
      (fun j hj => by simpa only [hphase] using (hgood x hx).1 j hj)
      (fun j hj => by simpa only [hphase] using (hgood x hx).2 j hj)
  have havg := amoFiniteLyapunov_avalanche_average α lam z N n hN hμ
    (measurableSet_amoAvalancheBadSet α lam z N n κ)
    (amoAvalancheBadSet_mass_le α lam z N n κ hbadN hbad2N)
    (fun x hx => (hconditions x hx).1) (fun x hx => (hconditions x hx).2)
  have hweighted : |amoFiniteLyapunov α lam z ((n + 2) * N) +
      (n : ℝ) / (n + 2 : ℕ) * amoFiniteLyapunov α lam z N -
      (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
          4 * Real.log (amoTransferBound lam z) * (n + 2 : ℕ) * δ := by
    convert havg using 1
    ring
  refine ⟨hweighted, ?_⟩
  have hdiff : |amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)| ≤
      Real.log (amoTransferBound lam z) := by
    apply abs_le.mpr
    have h1 := amoFiniteLyapunov_nonneg α lam z N
    have h2 := amoFiniteLyapunov_nonneg α lam z (2 * N)
    have h3 := amoFiniteLyapunov_le_log_bound α lam z N
    have h4 := amoFiniteLyapunov_le_log_bound α lam z (2 * N)
    constructor <;> linarith
  have hm : (0 : ℝ) < ((n + 2 : ℕ) : ℝ) := by positivity
  have hcor : |(2 / (n + 2 : ℕ)) *
      (amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N))| ≤
      2 * Real.log (amoTransferBound lam z) / (n + 2 : ℕ) := by
    rw [abs_mul, abs_of_nonneg (show (0 : ℝ) ≤ 2 / (n + 2 : ℕ) by positivity)]
    calc
      _ ≤ (2 / (n + 2 : ℕ)) * Real.log (amoTransferBound lam z) :=
        mul_le_mul_of_nonneg_left hdiff (by positivity)
      _ = _ := by ring
  have heq : amoFiniteLyapunov α lam z ((n + 2) * N) + amoFiniteLyapunov α lam z N -
      2 * amoFiniteLyapunov α lam z (2 * N) =
      (amoFiniteLyapunov α lam z ((n + 2) * N) +
        (n : ℝ) / (n + 2 : ℕ) * amoFiniteLyapunov α lam z N -
        (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z (2 * N)) +
      (2 / (n + 2 : ℕ)) * (amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)) := by
    push_cast
    field_simp
    ring
  rw [heq]
  exact (abs_add _ _).trans (add_le_add hweighted hcor)

end CriticalDTM

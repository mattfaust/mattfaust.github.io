import DTM.Background.Avalanche.AvalanchePrinciple

/-!
# The finite avalanche principle for actual almost Mathieu transfer blocks

This specializes the proved finite matrix theorem to the actual receiving-row
transfer products. Both the full product and every adjacent pair are
identified with their physical phase-shifted transfer products.
-/

noncomputable section

open scoped BigOperators

namespace CriticalDTM

/-- Consecutive equal-length blocks are exactly the original transfer product,
with the original radian phase and receiving-row multiplication order. -/
theorem amoTransferProduct_avalanche_blocks (α lam : ℝ) (z : ℂ) (θ : ℝ) (m N : ℕ) :
    avalancheProduct (fun j => amoTransferProduct α lam z
      (θ + 2 * Real.pi * α * ((j * m : ℕ) : ℝ)) m) N =
        amoTransferProduct α lam z θ (N * m) := by
  induction N with
  | zero => simp [avalancheProduct]
  | succ N ih =>
      rw [avalancheProduct, ih]
      rw [show (N + 1) * m = m + N * m by ring, amoTransferProduct_add]

/-- Each adjacent pair of blocks is exactly a block of twice the length. -/
theorem amoTransferProduct_avalanche_pair (α lam : ℝ) (z : ℂ) (θ : ℝ) (m j : ℕ) :
    amoTransferProduct α lam z (θ + 2 * Real.pi * α * (((j + 1) * m : ℕ) : ℝ)) m *
      amoTransferProduct α lam z (θ + 2 * Real.pi * α * ((j * m : ℕ) : ℝ)) m =
        amoTransferProduct α lam z (θ + 2 * Real.pi * α * ((j * m : ℕ) : ℝ)) (2 * m) := by
  rw [show 2 * m = m + m by ring, amoTransferProduct_add]
  have hp : θ + 2 * Real.pi * α * (((j + 1) * m : ℕ) : ℝ) =
      (θ + 2 * Real.pi * α * ((j * m : ℕ) : ℝ)) + 2 * Real.pi * α * (m : ℝ) := by
    push_cast
    ring
  rw [hp]

end CriticalDTM

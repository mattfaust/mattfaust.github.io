import DTM.Background.Avalanche.AvalancheFinite

/-!
# Exact finite-product bookkeeping for the avalanche principle

These are algebraic identities for explicit singular-frame factorizations.
The frame estimate itself is proved in `AvalancheFinite`.
-/

noncomputable section

open Matrix
open scoped Matrix Matrix.L2OpNorm BigOperators

namespace CriticalDTM

/-- Later matrices multiply on the left; `n` denotes the number of factors. -/
def avalancheProduct (A : ℕ → AMOTransferMatrix) : ℕ → AMOTransferMatrix
  | 0 => 1
  | n + 1 => A n * avalancheProduct A n

@[simp] theorem avalancheProduct_det (A : ℕ → AMOTransferMatrix)
    (hA : ∀ j, (A j).det = 1) (n : ℕ) : (avalancheProduct A n).det = 1 := by
  induction n with
  | zero => simp [avalancheProduct]
  | succ n ih => simp [avalancheProduct, Matrix.det_mul, hA, ih]

theorem avalancheProduct_norm_pos (A : ℕ → AMOTransferMatrix)
    (hA : ∀ j, (A j).det = 1) (n : ℕ) : 0 < amoTransferNorm (avalancheProduct A n) :=
  zero_lt_one.trans_le (one_le_amoTransferNorm_of_det_one _ (avalancheProduct_det A hA n))

/-- The change between two consecutive singular frames. -/
def avalancheTransition (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ) (j : ℕ) :
    AMOTransferMatrix := star (V (j + 1) : AMOTransferMatrix) * (U j : AMOTransferMatrix)

theorem avalancheTransition_unitary (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ) (j : ℕ) :
    avalancheTransition U V j ∈ Matrix.unitaryGroup (Fin 2) ℂ :=
  (star (V (j + 1)) * U j).property

theorem avalanche_unitary_norm (U V : Matrix.unitaryGroup (Fin 2) ℂ)
    (M : AMOTransferMatrix) :
    amoTransferNorm ((U : AMOTransferMatrix) * M * star (V : AMOTransferMatrix)) =
      amoTransferNorm M := by
  change ‖(U : AMOTransferMatrix) * M * star (V : AMOTransferMatrix)‖ = ‖M‖
  rw [CStarRing.norm_mul_mem_unitary _ (unitary.star_mem V.property),
    CStarRing.norm_coe_unitary_mul]

theorem avalanche_norm_smul (s : ℝ) (hs : 0 ≤ s) (M : AMOTransferMatrix) :
    amoTransferNorm ((s : ℂ) • M) = s * amoTransferNorm M := by
  change ‖(s : ℂ) • M‖ = s * ‖M‖
  simp only [norm_smul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hs]

/-- Exact singular-frame factorization of the ordered product. -/
theorem avalanche_product_decomposition (A : ℕ → AMOTransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : AMOTransferMatrix) * avalancheDiagonal (δ j) * star (V j : AMOTransferMatrix)))
    (n : ℕ) :
    avalancheProduct A (n + 1) = ((∏ j ∈ Finset.range (n + 1), σ j : ℝ) : ℂ) •
      ((U n : AMOTransferMatrix) * avalancheFrameProduct δ (avalancheTransition U V) n *
        star (V 0 : AMOTransferMatrix)) := by
  induction n with
  | zero => simpa [avalancheProduct, avalancheFrameProduct] using hA 0
  | succ n ih =>
      rw [avalancheProduct, hA (n + 1), ih, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
      simp only [Finset.prod_range_succ, Complex.ofReal_mul, avalancheFrameProduct,
        avalancheTransition]
      congr 1
      · ring
      · simp only [mul_assoc]

/-- Exact norm factorization; the operator norm is unchanged by the two
external unitary factors. -/
theorem avalanche_product_norm_decomposition (A : ℕ → AMOTransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hσ : ∀ j, 0 ≤ σ j)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : AMOTransferMatrix) * avalancheDiagonal (δ j) * star (V j : AMOTransferMatrix)))
    (n : ℕ) :
    amoTransferNorm (avalancheProduct A (n + 1)) = (∏ j ∈ Finset.range (n + 1), σ j) *
      amoTransferNorm (avalancheFrameProduct δ (avalancheTransition U V) n) := by
  rw [avalanche_product_decomposition A σ δ U V hA n,
    avalanche_norm_smul _ (Finset.prod_nonneg (fun j _ => hσ j)), avalanche_unitary_norm]

/-- Exact adjacent-pair singular-frame factorization. -/
theorem avalanche_pair_decomposition (A : ℕ → AMOTransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : AMOTransferMatrix) * avalancheDiagonal (δ j) * star (V j : AMOTransferMatrix)))
    (j : ℕ) :
    A (j + 1) * A j = ((σ (j + 1) * σ j : ℝ) : ℂ) •
      ((U (j + 1) : AMOTransferMatrix) *
        (avalancheDiagonal (δ (j + 1)) * avalancheTransition U V j * avalancheDiagonal (δ j)) *
          star (V j : AMOTransferMatrix)) := by
  rw [hA (j + 1), hA j, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  simp only [Complex.ofReal_mul, avalancheTransition, mul_assoc]

/-- Exact adjacent-pair norm factorization. -/
theorem avalanche_pair_norm_decomposition (A : ℕ → AMOTransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hσ : ∀ j, 0 ≤ σ j)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : AMOTransferMatrix) * avalancheDiagonal (δ j) * star (V j : AMOTransferMatrix)))
    (j : ℕ) :
    amoTransferNorm (A (j + 1) * A j) = (σ (j + 1) * σ j) *
      amoTransferNorm (avalancheDiagonal (δ (j + 1)) * avalancheTransition U V j *
        avalancheDiagonal (δ j)) := by
  rw [avalanche_pair_decomposition A σ δ U V hA j,
    avalanche_norm_smul _ (mul_nonneg (hσ (j + 1)) (hσ j)), avalanche_unitary_norm]

/-- The multiplicity count that turns normalized logarithms into the
classical endpoint/interior avalanche expression. -/
theorem avalanche_log_multiplicity (l : ℕ → ℝ) (n : ℕ) :
    (∑ j ∈ Finset.range (n + 2), l j) + (∑ j ∈ Finset.range n, l (j + 1)) =
      ∑ j ∈ Finset.range (n + 1), (l (j + 1) + l j) := by
  induction n with
  | zero => simp [Finset.sum_range_succ, add_comm]
  | succ n ih =>
      simp only [Nat.succ_eq_add_one, Finset.sum_range_succ] at ih ⊢
      linarith

end CriticalDTM

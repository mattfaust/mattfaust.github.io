import DTM.Background.Avalanche.AvalancheFactorization
import DTM.Background.Avalanche.AvalancheSVD

/-!
# A proved finite two-by-two avalanche principle

For determinant-one complex matrices, the Euclidean singular frames are
constructed by the proved finite-dimensional SVD. No avalanche or spectral
estimate is assumed. With `t = μ⁻¹ᐟ²`, the hypotheses are the usual lower
bound `‖A_j‖ ≥ μ` and adjacent-pair no-cancellation at scale `μ⁻¹ᐟ²`.
The estimate holds for every finite number of matrices at least two.
-/

noncomputable section

open Matrix
open scoped Matrix Matrix.L2OpNorm BigOperators

namespace CriticalDTM

theorem avalancheDiagonal_eq_diagonal (δ : ℝ) :
    avalancheDiagonal δ = Matrix.diagonal ![(1 : ℂ), (δ : ℂ)] := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [avalancheDiagonal, Matrix.diagonal_apply]

/-- The small singular value is quantitatively small because the large one
is large; this is an arithmetic consequence, not an extra hypothesis. -/
theorem avalanche_inverse_square_le {t s : ℝ} (ht : 0 < t) (hs : 0 < s)
    (hlarge : 1 / t ^ 2 ≤ s) : (s⁻¹) ^ 2 ≤ t ^ 4 := by
  have hmul : 1 ≤ s * t ^ 2 := (div_le_iff₀ (pow_pos ht 2)).mp hlarge
  have hi : s⁻¹ ≤ t ^ 2 := (inv_le_iff_one_le_mul₀ hs).mpr (by nlinarith)
  have hpow := pow_le_pow_left₀ (inv_nonneg.mpr hs.le) hi 2
  convert hpow using 1
  ring

/-- The classical finite `SL(2,ℂ)` avalanche estimate in the genuine
Euclidean operator norm. There are `n+2` matrices, so the interior sum has
`n` terms and the adjacent-pair sum has `n+1` terms. The theorem has no
upper restriction on the finite length. -/
theorem avalanche_principle (A : ℕ → AMOTransferMatrix) (n : ℕ)
    (hdet : ∀ j, (A j).det = 1) {t : ℝ}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (hlarge : ∀ j < n + 2, 1 / t ^ 2 ≤ amoTransferNorm (A j))
    (hpair : ∀ j < n + 1,
      t * amoTransferNorm (A (j + 1)) * amoTransferNorm (A j) ≤
        amoTransferNorm (A (j + 1) * A j)) :
    |Real.log (amoTransferNorm (avalancheProduct A (n + 2))) +
      (∑ j ∈ Finset.range n, Real.log (amoTransferNorm (A (j + 1)))) -
      ∑ j ∈ Finset.range (n + 1), Real.log (amoTransferNorm (A (j + 1) * A j))| ≤
      1000 * (n + 2 : ℕ) * t ^ 2 := by
  classical
  let σ : ℕ → ℝ := fun j => amoTransferNorm (A j)
  let δ : ℕ → ℝ := fun j => (σ j)⁻¹ ^ 2
  have hσ (j : ℕ) : 0 < σ j :=
    zero_lt_one.trans_le (one_le_amoTransferNorm_of_det_one (A j) (hdet j))
  have hsvd (j : ℕ) : ∃ U V : Matrix.unitaryGroup (Fin 2) ℂ,
      A j = (σ j : ℂ) • ((U : AMOTransferMatrix) * avalancheDiagonal (δ j) *
        star (V : AMOTransferMatrix)) := by
    simpa only [σ, δ, avalancheDiagonal_eq_diagonal] using amoTransferMatrix_svd (A j) (hdet j)
  choose U V hfactor using hsvd
  let R := avalancheTransition U V
  have hδ (j : ℕ) (hj : j ≤ n + 1) : 0 ≤ δ j ∧ δ j ≤ t ^ 4 := by
    refine ⟨sq_nonneg _, ?_⟩
    exact avalanche_inverse_square_le ht (hσ j) (hlarge j (Nat.lt_succ_of_le hj))
  have hR (j : ℕ) (_hj : j < n + 1) : R j ∈ Matrix.unitaryGroup (Fin 2) ℂ :=
    avalancheTransition_unitary U V j
  have hpn (j : ℕ) : amoTransferNorm (A (j + 1) * A j) = (σ (j + 1) * σ j) *
      amoTransferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)) :=
    avalanche_pair_norm_decomposition A σ δ U V (fun j => (hσ j).le) hfactor j
  have hp (j : ℕ) (hj : j < n + 1) :
      t ≤ amoTransferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)) := by
    have hh := hpair j hj
    change t * σ (j + 1) * σ j ≤ _ at hh
    rw [hpn j] at hh
    apply (mul_le_mul_left (mul_pos (hσ (j + 1)) (hσ j))).mp
    nlinarith
  have hmain := avalanche_principle_in_frames δ R ht ht' (n + 1) hδ hR hp
  have hprod := avalanche_product_norm_decomposition A σ δ U V (fun j => (hσ j).le)
    hfactor (n + 1)
  have hsprod : 0 < ∏ j ∈ Finset.range (n + 2), σ j :=
    Finset.prod_pos (fun j _ => hσ j)
  have hframe0 : amoTransferNorm (avalancheFrameProduct δ R (n + 1)) ≠ 0 := by
    intro hz
    rw [hz, mul_zero] at hprod
    exact (avalancheProduct_norm_pos A hdet (n + 2)).ne' hprod
  have hlogprod : Real.log (amoTransferNorm (avalancheProduct A (n + 2))) =
      (∑ j ∈ Finset.range (n + 2), Real.log (σ j)) +
        Real.log (amoTransferNorm (avalancheFrameProduct δ R (n + 1))) := by
    rw [hprod, Real.log_mul hsprod.ne' hframe0,
      Real.log_prod _ _ (fun j _ => (hσ j).ne')]
  have hlogpair (j : ℕ) (hj : j < n + 1) :
      Real.log (amoTransferNorm (A (j + 1) * A j)) =
        (Real.log (σ (j + 1)) + Real.log (σ j)) +
          Real.log (amoTransferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j))) := by
    have hfp : 0 < amoTransferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)) :=
      ht.trans_le (hp j hj)
    rw [hpn j, Real.log_mul (mul_pos (hσ (j + 1)) (hσ j)).ne' hfp.ne',
      Real.log_mul (hσ (j + 1)).ne' (hσ j).ne']
  have hsum : (∑ j ∈ Finset.range (n + 1), Real.log (amoTransferNorm (A (j + 1) * A j))) =
      (∑ j ∈ Finset.range (n + 1), (Real.log (σ (j + 1)) + Real.log (σ j))) +
        ∑ j ∈ Finset.range (n + 1),
          Real.log (amoTransferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j))) := by
    rw [← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun j hj => hlogpair j (Finset.mem_range.mp hj))
  have heq : Real.log (amoTransferNorm (avalancheProduct A (n + 2))) +
      (∑ j ∈ Finset.range n, Real.log (amoTransferNorm (A (j + 1)))) -
      (∑ j ∈ Finset.range (n + 1), Real.log (amoTransferNorm (A (j + 1) * A j))) =
      Real.log (amoTransferNorm (avalancheFrameProduct δ R (n + 1))) -
        ∑ j ∈ Finset.range (n + 1),
          Real.log (amoTransferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j))) := by
    rw [hlogprod, hsum]
    have hm := avalanche_log_multiplicity (fun j => Real.log (σ j)) n
    change (∑ j ∈ Finset.range (n + 2), Real.log (σ j)) +
      Real.log (amoTransferNorm (avalancheFrameProduct δ R (n + 1))) +
      (∑ j ∈ Finset.range n, Real.log (σ (j + 1))) - _ = _
    linarith
  rw [heq]
  apply hmain.trans
  apply mul_le_mul_of_nonneg_right _ (sq_nonneg t)
  push_cast
  nlinarith [Nat.cast_nonneg (α := ℝ) n]

end CriticalDTM

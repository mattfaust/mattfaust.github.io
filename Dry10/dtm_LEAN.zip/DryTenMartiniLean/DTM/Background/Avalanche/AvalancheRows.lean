import DTM.Background.Transfer.AMOTransfer
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.Positivity

/-!
# Elementary row estimates for the finite two-dimensional avalanche principle

This file concerns ordinary complex rows of finite matrices. It does not
introduce a spectral assumption. The small second row is propagated by the
explicit update `(f,g) ↦ (a • f + b • g, δ • (c • f + d • g))`.
-/

noncomputable section

namespace CriticalDTM

/-- A relative error of at most one half gives twice that error for logarithms. -/
theorem avalanche_abs_log_sub_log_le {x y ε : ℝ}
    (hy : 0 < y) (hε : 0 ≤ ε) (hε' : ε ≤ 1 / 2)
    (hlo : (1 - ε) * y ≤ x) (hhi : x ≤ (1 + ε) * y) :
    |Real.log x - Real.log y| ≤ 2 * ε := by
  have hx : 0 < x := lt_of_lt_of_le (mul_pos (by linarith) hy) hlo
  have hlo' : 1 - ε ≤ x / y := (le_div_iff₀ hy).2 hlo
  have hhi' : x / y ≤ 1 + ε := (div_le_iff₀ hy).2 hhi
  have hu : 0 < x / y := div_pos hx hy
  have hinv : (x / y)⁻¹ ≤ 1 + 2 * ε := by
    apply (inv_le_iff_one_le_mul₀ hu).2
    have hp := mul_le_mul_of_nonneg_left hlo' (show 0 ≤ 1 + 2 * ε by positivity)
    nlinarith
  have hup := Real.log_le_sub_one_of_pos hu
  have hdown := Real.one_sub_inv_le_log_of_pos hu
  rw [Real.log_div hx.ne' hy.ne'] at hup hdown
  exact abs_le.mpr ⟨by linarith, by linarith⟩

/-- The explicit constants used in the two-row induction. -/
theorem avalanche_small_parameter {t : ℝ} (ht : 0 < t) (ht' : t ≤ 1 / 100) :
    0 ≤ 8 * t ^ 3 ∧ 8 * t ^ 3 ≤ t / 4 ∧
      8 * t ^ 3 ≤ 1 ∧ 16 * t ^ 2 ≤ 1 / 2 := by
  have ht0 : 0 ≤ t := ht.le
  have hsq : t ^ 2 ≤ (1 / 100 : ℝ) ^ 2 :=
    pow_le_pow_left₀ ht0 ht' 2
  have hc := mul_le_mul_of_nonneg_left hsq ht0
  constructor
  · positivity
  constructor
  · nlinarith
  constructor <;> nlinarith

section Rows

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]

/-- Upper and lower growth estimates for the large row, proved by the two
triangle inequalities. No nonzero-row hypothesis is needed. -/
theorem avalanche_large_row_bounds {a b : ℂ} {f g : E} {r : ℝ}
    (hb : ‖b‖ ≤ 1) (hg : ‖g‖ ≤ r * ‖f‖) :
    (‖a‖ - r) * ‖f‖ ≤ ‖a • f + b • g‖ ∧
      ‖a • f + b • g‖ ≤ (‖a‖ + r) * ‖f‖ := by
  have hbg : ‖b • g‖ ≤ r * ‖f‖ := by
    calc
      ‖b • g‖ = ‖b‖ * ‖g‖ := norm_smul _ _
      _ ≤ 1 * ‖g‖ := mul_le_mul_of_nonneg_right hb (norm_nonneg _)
      _ ≤ r * ‖f‖ := by simpa using hg
  have hlo := norm_le_add_norm_add (a • f) (b • g)
  have hhi := norm_add_le (a • f) (b • g)
  rw [norm_smul] at hlo hhi
  constructor <;> nlinarith

/-- One actual complex two-row update preserves the small-row estimate. -/
theorem avalanche_row_contraction {t δ : ℝ} {a b c d : ℂ} {f g : E}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ t ^ 4)
    (ha : t / 2 ≤ ‖a‖) (hb : ‖b‖ ≤ 1) (hc : ‖c‖ ≤ 1) (hd : ‖d‖ ≤ 1)
    (hg : ‖g‖ ≤ 8 * t ^ 3 * ‖f‖) :
    ‖(δ : ℂ) • (c • f + d • g)‖ ≤ 8 * t ^ 3 * ‖a • f + b • g‖ := by
  obtain ⟨hr0, hrt, hr1, _⟩ := avalanche_small_parameter ht ht'
  have hlarge := (avalanche_large_row_bounds (a := a) hb hg).1
  have hlarge' : (t / 4) * ‖f‖ ≤ ‖a • f + b • g‖ := by
    have hmul := mul_le_mul_of_nonneg_right
      (show t / 4 ≤ ‖a‖ - 8 * t ^ 3 by linarith) (norm_nonneg f)
    exact hmul.trans hlarge
  have hsmall : ‖c • f + d • g‖ ≤ 2 * ‖f‖ := by
    calc
      ‖c • f + d • g‖ ≤ ‖c‖ * ‖f‖ + ‖d‖ * ‖g‖ := by
        simpa only [norm_smul] using norm_add_le (c • f) (d • g)
      _ ≤ 1 * ‖f‖ + 1 * ‖g‖ := add_le_add
        (mul_le_mul_of_nonneg_right hc (norm_nonneg _))
        (mul_le_mul_of_nonneg_right hd (norm_nonneg _))
      _ ≤ 2 * ‖f‖ := by
        have hmul := mul_le_mul_of_nonneg_right hr1 (norm_nonneg f)
        nlinarith
  calc
    ‖(δ : ℂ) • (c • f + d • g)‖ = δ * ‖c • f + d • g‖ := by
      rw [norm_smul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hδ]
    _ ≤ t ^ 4 * (2 * ‖f‖) := mul_le_mul hδ' hsmall (norm_nonneg _) (by positivity)
    _ = (8 * t ^ 3) * ((t / 4) * ‖f‖) := by ring
    _ ≤ 8 * t ^ 3 * ‖a • f + b • g‖ := mul_le_mul_of_nonneg_left hlarge' hr0

/-- The large-row logarithm follows the dominant overlap with error at most
`32 t²`. This is the quantitative, non-assumed logarithm step. -/
theorem avalanche_large_row_log_error {t : ℝ} {a b : ℂ} {f g : E}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (ha : t / 2 ≤ ‖a‖) (hb : ‖b‖ ≤ 1)
    (hf : f ≠ 0) (hg : ‖g‖ ≤ 8 * t ^ 3 * ‖f‖) :
    |Real.log ‖a • f + b • g‖ - Real.log ‖f‖ - Real.log ‖a‖| ≤ 32 * t ^ 2 := by
  obtain ⟨_, _, _, hε⟩ := avalanche_small_parameter ht ht'
  have ha0 : 0 < ‖a‖ := lt_of_lt_of_le (by positivity) ha
  have hf0 : 0 < ‖f‖ := norm_pos_iff.mpr hf
  have hm := mul_le_mul_of_nonneg_left ha (show 0 ≤ 16 * t ^ 2 by positivity)
  have hr : 8 * t ^ 3 ≤ 16 * t ^ 2 * ‖a‖ := by nlinarith
  have hr' := mul_le_mul_of_nonneg_right hr (norm_nonneg f)
  obtain ⟨hlo, hhi⟩ := avalanche_large_row_bounds (a := a) hb hg
  have hlog := avalanche_abs_log_sub_log_le (mul_pos ha0 hf0)
    (show 0 ≤ 16 * t ^ 2 by positivity) hε
    (show (1 - 16 * t ^ 2) * (‖a‖ * ‖f‖) ≤ ‖a • f + b • g‖ by nlinarith)
    (show ‖a • f + b • g‖ ≤ (1 + 16 * t ^ 2) * (‖a‖ * ‖f‖) by nlinarith)
  rw [Real.log_mul ha0.ne' hf0.ne'] at hlog
  convert hlog using 1
  · congr 1
    ring
  · ring

end Rows

end CriticalDTM

import DTM.Background.Avalanche.AvalanchePrinciple

/-!
# The classical large-norm scale of the finite avalanche principle

The parameter is `μ`, and the error is `1000 N / μ`. This is a corollary of
the proved matrix estimate, including the elementary square-root change of
scale. There is no upper bound on the finite number of matrices.
-/

noncomputable section

open scoped BigOperators

namespace CriticalDTM

/-- The finite avalanche estimate at large-norm scale `μ ≥ 10000`. -/
theorem avalanche_principle_mu (A : ℕ → AMOTransferMatrix) (n : ℕ)
    (hdet : ∀ j, (A j).det = 1) {μ : ℝ} (hμ : 10000 ≤ μ)
    (hlarge : ∀ j < n + 2, μ ≤ amoTransferNorm (A j))
    (hpair : ∀ j < n + 1,
      amoTransferNorm (A (j + 1)) * amoTransferNorm (A j) ≤
        Real.sqrt μ * amoTransferNorm (A (j + 1) * A j)) :
    |Real.log (amoTransferNorm (avalancheProduct A (n + 2))) +
      (∑ j ∈ Finset.range n, Real.log (amoTransferNorm (A (j + 1)))) -
      ∑ j ∈ Finset.range (n + 1), Real.log (amoTransferNorm (A (j + 1) * A j))| ≤
      1000 * (n + 2 : ℕ) / μ := by
  have hμ0 : 0 < μ := by linarith
  have hs : 0 < Real.sqrt μ := Real.sqrt_pos.mpr hμ0
  have hs100 : 100 ≤ Real.sqrt μ := by
    nlinarith [Real.sq_sqrt hμ0.le]
  let t : ℝ := (Real.sqrt μ)⁻¹
  have ht : 0 < t := inv_pos.mpr hs
  have ht' : t ≤ 1 / 100 := by
    simpa [t, one_div] using (inv_le_inv₀ hs (show (0 : ℝ) < 100 by norm_num)).mpr hs100
  have ht2 : t ^ 2 = μ⁻¹ := by
    dsimp [t]
    rw [inv_pow, Real.sq_sqrt hμ0.le]
  have hl (j : ℕ) (hj : j < n + 2) : 1 / t ^ 2 ≤ amoTransferNorm (A j) := by
    simpa only [ht2, one_div, inv_inv] using hlarge j hj
  have hp (j : ℕ) (hj : j < n + 1) :
      t * amoTransferNorm (A (j + 1)) * amoTransferNorm (A j) ≤
        amoTransferNorm (A (j + 1) * A j) := by
    have hd : (amoTransferNorm (A (j + 1)) * amoTransferNorm (A j)) / Real.sqrt μ ≤
        amoTransferNorm (A (j + 1) * A j) :=
      (div_le_iff₀ hs).mpr (by nlinarith [hpair j hj])
    simpa [t, div_eq_mul_inv, mul_assoc, mul_comm, mul_left_comm] using hd
  have h := avalanche_principle A n hdet ht ht' hl hp
  simpa only [ht2, div_eq_mul_inv] using h

/-- The usual logarithmic no-cancellation formulation of the finite
`SL(2,ℂ)` avalanche principle. The singular-vector and growth estimates
needed to prove it have all been derived, not included among the hypotheses. -/
theorem avalanche_principle_log (A : ℕ → AMOTransferMatrix) (n : ℕ)
    (hdet : ∀ j, (A j).det = 1) {μ : ℝ} (hμ : 10000 ≤ μ)
    (hlarge : ∀ j < n + 2, μ ≤ amoTransferNorm (A j))
    (hpair : ∀ j < n + 1,
      Real.log (amoTransferNorm (A (j + 1))) + Real.log (amoTransferNorm (A j)) -
        Real.log (amoTransferNorm (A (j + 1) * A j)) ≤ Real.log μ / 2) :
    |Real.log (amoTransferNorm (avalancheProduct A (n + 2))) +
      (∑ j ∈ Finset.range n, Real.log (amoTransferNorm (A (j + 1)))) -
      ∑ j ∈ Finset.range (n + 1), Real.log (amoTransferNorm (A (j + 1) * A j))| ≤
      1000 * (n + 2 : ℕ) / μ := by
  apply avalanche_principle_mu A n hdet hμ hlarge
  intro j hj
  have hμ0 : 0 < μ := by linarith
  have hs : 0 < Real.sqrt μ := Real.sqrt_pos.mpr hμ0
  have hn (k : ℕ) : 0 < amoTransferNorm (A k) :=
    zero_lt_one.trans_le (one_le_amoTransferNorm_of_det_one (A k) (hdet k))
  have hdp : (A (j + 1) * A j).det = 1 := by simp [Matrix.det_mul, hdet]
  have hnp : 0 < amoTransferNorm (A (j + 1) * A j) :=
    zero_lt_one.trans_le (one_le_amoTransferNorm_of_det_one _ hdp)
  apply (Real.log_le_log_iff (mul_pos (hn (j + 1)) (hn j)) (mul_pos hs hnp)).mp
  rw [Real.log_mul (hn (j + 1)).ne' (hn j).ne', Real.log_mul hs.ne' hnp.ne',
    Real.log_sqrt hμ0.le]
  linarith [hpair j hj]

end CriticalDTM

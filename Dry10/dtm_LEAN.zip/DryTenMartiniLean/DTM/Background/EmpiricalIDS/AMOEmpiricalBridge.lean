import DTM.Background.EmpiricalIDS.AMOEmpiricalCDF
import DTM.Background.EmpiricalIDS.MatrixEmpiricalCounts
import DTM.Problem.Definitions.AMOProperty
import Mathlib.Topology.MetricSpace.Pseudo.Lemmas

/-!
# Literal finite-matrix counts and the existing Dry Ten Martini property

The finite matrix below is not a new operator definition: its entries are those
of the original operator in the ordinary site basis. This file proves equality
with the actual Dirichlet compression, identifies the characteristic-polynomial
root count with the finite Hermitian eigenvalue count (including multiplicities),
and transports the proved fixed-phase convergence to the existing IDS.

The final export expands the finite matrix and count expressions completely.
No new empirical IDS definition or unproved convergence hypothesis is introduced.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Topology Matrix

/-- The ordinary finite site-basis matrix is exactly the Dirichlet compression. -/
theorem amoFiniteMatrix_eq_site_matrix (α lam θ : ℝ) (N : ℕ) :
    amoFiniteMatrix α lam θ N =
      fun i j : Fin N =>
        almostMathieuOperator α lam θ (lp.single 2 (j.val : ℤ) (1 : ℂ)) (i.val : ℤ) := by
  ext i j
  have hentry : amoFiniteMatrix α lam θ N i j =
      amoFiniteOperator α lam θ N (EuclideanSpace.single j 1) i := by
    rw [← amoFiniteMatrix_toEuclideanCLM]
    change _ = (amoFiniteMatrix α lam θ N *ᵥ Pi.single j 1) i
    simp
  rw [hentry]
  change amoFiniteRestriction N
    (almostMathieuOperator α lam θ
      (amoFiniteEmbedding N (EuclideanSpace.single j 1))) i = _
  rw [amoFiniteRestriction_apply, amoFiniteEmbedding_single]

/-- Literal characteristic-polynomial root counts converge, for every fixed
phase, to the pre-existing IDS at each resolvent energy. -/
theorem tendsto_amoFinite_charpoly_count {α : ℝ} (hα : Irrational α)
    (lam θ E : ℝ)
    (hE : (E : ℂ) ∉ spectrum ℂ (almostMathieuOperator α lam θ)) :
    Tendsto
      (fun L : ℕ =>
        ((Multiset.countP (fun z : ℂ => z.re < E)
          (Polynomial.roots (Matrix.charpoly (fun i j : Fin (L + 1) =>
            almostMathieuOperator α lam θ
              (lp.single 2 (j.val : ℤ) (1 : ℂ)) (i.val : ℤ))))) : ℝ) / ((L + 1 : ℕ) : ℝ))
      atTop (𝓝 (almostMathieuIDS α lam E)) := by
  simp_rw [← amoFiniteMatrix_eq_site_matrix,
    (amoFiniteMatrix_isHermitian α lam θ _).charpoly_roots_countP_lt]
  exact tendsto_amoFinite_eigenvalue_count hα lam θ E hE

end CriticalDTM

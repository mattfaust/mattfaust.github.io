import DTM.Background.EmpiricalIDS.AMOFixedPhaseConvergence
import DTM.Background.Realization.AMOMagneticSpectrum

/-!
# Fixed-phase empirical eigenvalue counts

The finite spectral measure is the equally weighted measure at the actual
Dirichlet matrix eigenvalues, with multiplicity. Its lower-half-line mass is
therefore the ordinary normalized eigenvalue count. At an energy outside the
common irrational almost Mathieu spectrum, the limiting root measure assigns
zero mass to the boundary of this half-line. Portmanteau then turns fixed-phase
continuous-test convergence into convergence of the ordinary count.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set Filter
open scoped ENNReal Topology

/-- The lower mass of the actual finite empirical measure is exactly the
number of Dirichlet eigenvalues strictly below the energy, divided by dimension.
The phase is fixed; there is no phase integral in this formula. -/
theorem amoFiniteSpectralMeasure_Iio_toReal (α lam θ E : ℝ) (n : ℕ) :
    (amoFiniteSpectralMeasure α lam θ n (Iio E)).toReal =
      ((Finset.univ.filter (fun i : Fin (n + 1) =>
        amoFiniteEigenvalues α lam θ (n + 1) i < E)).card : ℝ) / ((n + 1 : ℕ) : ℝ) := by
  classical
  simp only [amoFiniteSpectralMeasure, Measure.smul_apply, Measure.finset_sum_apply,
    smul_eq_mul, Measure.dirac_apply' _ measurableSet_Iio, Set.indicator_apply,
    Set.mem_Iio, Pi.one_apply, Finset.sum_boole]
  rw [ENNReal.toReal_mul, ENNReal.toReal_inv, ENNReal.toReal_natCast,
    ENNReal.toReal_natCast, div_eq_mul_inv, mul_comm]

/-- A point outside the actual magnetic spectrum has zero root spectral mass.
Only spectral support is used, not a global assertion that the measure has no atoms. -/
theorem magneticRealSpectralMeasure_singleton_eq_zero_of_not_mem (α lam E : ℝ)
    (hE : E ∉ magneticRealSpectrumSet α lam) :
    magneticRealSpectralMeasure α lam {E} = 0 := by
  rw [magneticRealSpectrumSet_eq_algebraSpectrum] at hE
  rw [magneticRealSpectralMeasure,
    Measure.map_apply continuous_subtype_val.measurable (measurableSet_singleton E)]
  have hpre : (fun x : MagneticRealSpectrum α lam => (x : ℝ)) ⁻¹' {E} = ∅ := by
    apply Set.eq_empty_iff_forall_not_mem.mpr
    intro x hx
    apply hE
    have hxE : (x : ℝ) = E := hx
    exact hxE ▸ x.property
  rw [hpre, measure_empty]

private theorem tendsto_amoFinite_eigenvalue_count_of_integral_tendsto
    (α lam θ E : ℝ)
    (hconv : ∀ (f : ℝ → ℝ), Continuous f →
      Tendsto (fun n => ∫ x, f x ∂amoFiniteSpectralMeasure α lam θ n) atTop
        (𝓝 (∫ x, f x ∂magneticRealSpectralMeasure α lam)))
    (hE : E ∉ magneticRealSpectrumSet α lam) :
    Tendsto (fun n : ℕ =>
      ((Finset.univ.filter (fun i : Fin (n + 1) =>
        amoFiniteEigenvalues α lam θ (n + 1) i < E)).card : ℝ) / ((n + 1 : ℕ) : ℝ))
      atTop (𝓝 (almostMathieuIDS α lam E)) := by
  let μs : ℕ → ProbabilityMeasure ℝ := fun n =>
    ⟨amoFiniteSpectralMeasure α lam θ n, inferInstance⟩
  let μ : ProbabilityMeasure ℝ := ⟨magneticRealSpectralMeasure α lam, inferInstance⟩
  have hweak : Tendsto μs atTop (𝓝 μ) := by
    apply ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mpr
    intro f
    exact hconv f f.continuous
  have hboundary : (μ : Measure ℝ) (frontier (Iio E)) = 0 := by
    rw [frontier_Iio]
    exact magneticRealSpectralMeasure_singleton_eq_zero_of_not_mem α lam E hE
  have hmass := ProbabilityMeasure.tendsto_measure_of_null_frontier_of_tendsto'
    hweak hboundary
  have hreal := (ENNReal.continuousAt_toReal
    (measure_ne_top (magneticRealSpectralMeasure α lam) (Iio E))).tendsto.comp hmass
  change Tendsto (fun n => (amoFiniteSpectralMeasure α lam θ n (Iio E)).toReal)
    atTop (𝓝 (magneticLowerMass α lam E)) at hreal
  simpa only [amoFiniteSpectralMeasure_Iio_toReal,
    magneticLowerMass_eq_almostMathieuIDS] using hreal

/-- At every fixed phase, the normalized number of actual finite Dirichlet
matrix eigenvalues below an off-spectrum energy converges to the original IDS. -/
theorem tendsto_amoFinite_eigenvalue_count {α : ℝ} (hα : Irrational α)
    (lam θ E : ℝ) (hE : (E : ℂ) ∉ spectrum ℂ (almostMathieuOperator α lam θ)) :
    Tendsto (fun n : ℕ =>
      ((Finset.univ.filter (fun i : Fin (n + 1) =>
        amoFiniteEigenvalues α lam θ (n + 1) i < E)).card : ℝ) / ((n + 1 : ℕ) : ℝ))
      atTop (𝓝 (almostMathieuIDS α lam E)) := by
  apply tendsto_amoFinite_eigenvalue_count_of_integral_tendsto α lam θ E
  · exact fun f hf => tendsto_amoFiniteSpectralMeasure_fixed_phase hα lam θ f hf
  · change E ∉ almostMathieuRealSpectrumSet α lam θ at hE
    rwa [almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα lam θ] at hE

end CriticalDTM

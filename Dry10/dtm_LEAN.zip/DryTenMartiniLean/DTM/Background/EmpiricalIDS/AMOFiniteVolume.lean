import DTM.Background.Realization.AlmostMathieu
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.LinearAlgebra.Matrix.Spectrum

/-!
# The actual finite Dirichlet almost Mathieu matrices

The finite space has the physical sites `0,...,n-1`. Zero extension is an
isometric embedding into the pre-existing `ℓ²(ℤ, ℂ)`; its adjoint is coordinate
restriction. The finite operator is the compression of the actual AMO by these
maps. Its matrix has the original potential and the two unscaled nearest
neighbours. Length zero is allowed here, for the determinant initial condition;
normalized spectral tests use positive lengths.
-/

noncomputable section

namespace CriticalDTM

open scoped Matrix Matrix.L2OpNorm

abbrev AMOFiniteHilbert (n : ℕ) := EuclideanSpace ℂ (Fin n)
abbrev AMOFiniteBoundedOperator (n : ℕ) := AMOFiniteHilbert n →L[ℂ] AMOFiniteHilbert n

/-- Zero extension to the same physical integer lattice as the infinite AMO. -/
def amoFiniteExtend (n : ℕ) (u : AMOFiniteHilbert n) : AMOHilbert :=
  ∑ i : Fin n, lp.single 2 (i.val : ℤ) (u i)

@[simp] theorem amoFiniteExtend_apply_site (n : ℕ) (u : AMOFiniteHilbert n) (i : Fin n) :
    amoFiniteExtend n u (i.val : ℤ) = u i := by
  simp [amoFiniteExtend, lp.coeFn_sum, lp.coeFn_single, Pi.single_apply,
    Int.natCast_inj, Fin.val_inj]

theorem amoFiniteExtend_apply_outside (n : ℕ) (u : AMOFiniteHilbert n) (j : ℤ)
    (hj : j < 0 ∨ (n : ℤ) ≤ j) : amoFiniteExtend n u j = 0 := by
  simp only [amoFiniteExtend, lp.coeFn_sum, Finset.sum_apply]
  apply Finset.sum_eq_zero
  intro i _
  exact lp.single_apply_ne _ _ _ (by have := i.isLt; omega)

theorem amoFiniteExtend_inner (n : ℕ) (u v : AMOFiniteHilbert n) :
    @inner ℂ AMOHilbert _ (amoFiniteExtend n u) (amoFiniteExtend n v) =
      @inner ℂ (AMOFiniteHilbert n) _ u v := by
  conv_lhs => unfold amoFiniteExtend
  rw [sum_inner]
  simp only [lp.inner_single_left]
  change (∑ i : Fin n, @inner ℂ ℂ _ (u i) (amoFiniteExtend n v (i.val : ℤ))) = _
  simp only [amoFiniteExtend_apply_site, PiLp.inner_apply]

theorem amoFiniteExtend_norm (n : ℕ) (u : AMOFiniteHilbert n) :
    ‖amoFiniteExtend n u‖ = ‖u‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [← inner_self_eq_norm_sq (𝕜 := ℂ), ← inner_self_eq_norm_sq (𝕜 := ℂ)]
  rw [amoFiniteExtend_inner]

/-- The physical zero extension is an isometric linear embedding. -/
def amoFiniteEmbedding (n : ℕ) : AMOFiniteHilbert n →ₗᵢ[ℂ] AMOHilbert where
  toFun := amoFiniteExtend n
  map_add' u v := by simp [amoFiniteExtend, PiLp.add_apply, Finset.sum_add_distrib]
  map_smul' c u := by
    simp only [amoFiniteExtend, PiLp.smul_apply, Finset.smul_sum]
    apply Finset.sum_congr rfl
    intro i _
    exact lp.single_smul (E := fun _ : ℤ => ℂ) 2 (i.val : ℤ) c (u i)
  norm_map' := amoFiniteExtend_norm n

@[simp] theorem amoFiniteEmbedding_apply (n : ℕ) (u : AMOFiniteHilbert n) :
    amoFiniteEmbedding n u = amoFiniteExtend n u := rfl

@[simp] theorem amoFiniteEmbedding_single (n : ℕ) (i : Fin n) (c : ℂ) :
    amoFiniteEmbedding n (EuclideanSpace.single i c) = lp.single 2 (i.val : ℤ) c := by
  simp [amoFiniteEmbedding, amoFiniteExtend, EuclideanSpace.single_apply,
    apply_ite (lp.single 2 _), lp.single_zero]

/-- Coordinate restriction, defined as the adjoint of the actual embedding. -/
def amoFiniteRestriction (n : ℕ) : AMOHilbert →L[ℂ] AMOFiniteHilbert n :=
  ContinuousLinearMap.adjoint (amoFiniteEmbedding n).toContinuousLinearMap

@[simp] theorem amoFiniteRestriction_apply (n : ℕ) (u : AMOHilbert) (i : Fin n) :
    amoFiniteRestriction n u i = u (i.val : ℤ) := by
  have h := ContinuousLinearMap.adjoint_inner_right
    (amoFiniteEmbedding n).toContinuousLinearMap (EuclideanSpace.single i (1 : ℂ)) u
  simpa only [amoFiniteRestriction, LinearIsometry.coe_toContinuousLinearMap,
    amoFiniteEmbedding_single, EuclideanSpace.inner_single_left,
    lp.inner_single_left, RCLike.inner_apply, map_one, one_mul, mul_one] using h

theorem amoFiniteEmbedding_norm_le (n : ℕ) :
    ‖(amoFiniteEmbedding n).toContinuousLinearMap‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro u
  simp only [LinearIsometry.coe_toContinuousLinearMap, LinearIsometry.norm_map, one_mul, le_refl]

theorem amoFiniteRestriction_norm_le (n : ℕ) : ‖amoFiniteRestriction n‖ ≤ 1 := by
  simpa only [amoFiniteRestriction, LinearIsometryEquiv.norm_map] using
    amoFiniteEmbedding_norm_le n

/-- The finite Dirichlet operator is the actual infinite-operator compression. -/
def amoFiniteOperator (α lam θ : ℝ) (n : ℕ) : AMOFiniteBoundedOperator n :=
  (amoFiniteRestriction n).comp
    ((almostMathieuOperator α lam θ).comp (amoFiniteEmbedding n).toContinuousLinearMap)

@[simp] theorem amoFiniteOperator_apply (α lam θ : ℝ) (n : ℕ)
    (u : AMOFiniteHilbert n) (i : Fin n) :
    amoFiniteOperator α lam θ n u i =
      amoFiniteExtend n u ((i.val : ℤ) + 1) +
      amoFiniteExtend n u ((i.val : ℤ) - 1) +
      ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + θ) : ℝ) : ℂ) * u i := by
  simp [amoFiniteOperator]

theorem amoFiniteOperator_isSelfAdjoint (α lam θ : ℝ) (n : ℕ) :
    IsSelfAdjoint (amoFiniteOperator α lam θ n) := by
  exact (almostMathieuOperator_isSelfAdjoint α lam θ).adjoint_conj
    (amoFiniteEmbedding n).toContinuousLinearMap

theorem amoFiniteOperator_norm_le (α lam θ : ℝ) (n : ℕ) :
    ‖amoFiniteOperator α lam θ n‖ ≤ 2 + 2 * |lam| := by
  calc
    ‖amoFiniteOperator α lam θ n‖ ≤ ‖amoFiniteRestriction n‖ *
        (‖almostMathieuOperator α lam θ‖ * ‖(amoFiniteEmbedding n).toContinuousLinearMap‖) :=
      (ContinuousLinearMap.opNorm_comp_le _ _).trans
        (mul_le_mul_of_nonneg_left (ContinuousLinearMap.opNorm_comp_le _ _) (norm_nonneg _))
    _ ≤ 1 * ((2 + 2 * |lam|) * 1) :=
      mul_le_mul (amoFiniteRestriction_norm_le n)
        (mul_le_mul (almostMathieuOperator_norm_le α lam θ) (amoFiniteEmbedding_norm_le n)
          (norm_nonneg _) (by positivity))
        (mul_nonneg (norm_nonneg _) (norm_nonneg _)) zero_le_one
    _ = 2 + 2 * |lam| := by ring

/-- Matrix of the actual compression in the physical coordinate basis. -/
def amoFiniteMatrix (α lam θ : ℝ) (n : ℕ) : Matrix (Fin n) (Fin n) ℂ :=
  (Matrix.toEuclideanCLM (n := Fin n) (𝕜 := ℂ)).symm (amoFiniteOperator α lam θ n)

theorem amoFiniteMatrix_toEuclideanCLM (α lam θ : ℝ) (n : ℕ) :
    (Matrix.toEuclideanCLM (n := Fin n) (𝕜 := ℂ)) (amoFiniteMatrix α lam θ n) = amoFiniteOperator α lam θ n :=
  (Matrix.toEuclideanCLM (n := Fin n) (𝕜 := ℂ)).apply_symm_apply _

theorem amoFiniteMatrix_entry (α lam θ : ℝ) (n : ℕ) (i j : Fin n) :
    amoFiniteMatrix α lam θ n i j =
      (if i.val + 1 = j.val then 1 else 0) +
      (if j.val + 1 = i.val then 1 else 0) +
      (if i = j then ((2 * lam * Real.cos
        (2 * Real.pi * α * (i.val : ℝ) + θ) : ℝ) : ℂ) else 0) := by
  have he : amoFiniteMatrix α lam θ n i j =
      amoFiniteOperator α lam θ n (EuclideanSpace.single j 1) i := by
    rw [← amoFiniteMatrix_toEuclideanCLM]
    change _ = (amoFiniteMatrix α lam θ n *ᵥ Pi.single j 1) i
    simp
  rw [he, amoFiniteOperator_apply]
  change (amoFiniteEmbedding n (EuclideanSpace.single j 1)) ((i.val : ℤ) + 1) +
    (amoFiniteEmbedding n (EuclideanSpace.single j 1)) ((i.val : ℤ) - 1) + _ = _
  rw [amoFiniteEmbedding_single]
  have hplus : (i.val : ℤ) + 1 = (j.val : ℤ) ↔ i.val + 1 = j.val := by omega
  have hminus : (i.val : ℤ) - 1 = (j.val : ℤ) ↔ j.val + 1 = i.val := by omega
  simp [lp.coeFn_single, Pi.single_apply, EuclideanSpace.single_apply, hplus, hminus]

@[simp] theorem amoFiniteMatrix_diagonal (α lam θ : ℝ) (n : ℕ) (i : Fin n) :
    amoFiniteMatrix α lam θ n i i =
      ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + θ) : ℝ) : ℂ) := by
  simp [amoFiniteMatrix_entry]

theorem amoFiniteMatrix_isHermitian (α lam θ : ℝ) (n : ℕ) :
    (amoFiniteMatrix α lam θ n).IsHermitian := by
  change IsSelfAdjoint (amoFiniteMatrix α lam θ n)
  exact (amoFiniteOperator_isSelfAdjoint α lam θ n).map (Matrix.toEuclideanCLM (n := Fin n) (𝕜 := ℂ)).symm

theorem amoFiniteMatrix_norm_le (α lam θ : ℝ) (n : ℕ) :
    ‖amoFiniteMatrix α lam θ n‖ ≤ 2 + 2 * |lam| := by
  rw [Matrix.cstar_norm_def, amoFiniteMatrix_toEuclideanCLM]
  exact amoFiniteOperator_norm_le α lam θ n

theorem continuous_amoFiniteOperator_phase (α lam : ℝ) (n : ℕ) :
    Continuous (fun θ => amoFiniteOperator α lam θ n) := by
  unfold amoFiniteOperator
  exact continuous_const.clm_comp
    ((continuous_almostMathieuOperator_phase α lam).clm_comp continuous_const)

/-- Compression agrees with the infinite receiving row at every retained site. -/
theorem amoFiniteExtend_operator_apply (α lam θ : ℝ) (n : ℕ)
    (u : AMOFiniteHilbert n) (j : ℤ) (hj0 : 0 ≤ j) (hjn : j < (n : ℤ)) :
    amoFiniteExtend n (amoFiniteOperator α lam θ n u) j =
      almostMathieuOperator α lam θ (amoFiniteExtend n u) j := by
  let i : Fin n := ⟨j.toNat, by omega⟩
  have hi : (i.val : ℤ) = j := by dsimp [i]; omega
  rw [← hi, amoFiniteExtend_apply_site]
  simp [amoFiniteOperator]

/-- A power of degree `k` does not see either Dirichlet wall when its receiving
site is at least `k` sites from that wall. This is a statement about the actual
infinite operator, not about a hypothetical finite-volume limit. -/
theorem amoFiniteExtend_pow_apply_interior (α lam θ : ℝ) (n k : ℕ)
    (u : AMOFiniteHilbert n) (j : ℤ)
    (hj0 : (k : ℤ) ≤ j) (hjn : j + (k : ℤ) < (n : ℤ)) :
    amoFiniteExtend n (((amoFiniteOperator α lam θ n) ^ k) u) j =
      ((almostMathieuOperator α lam θ) ^ k) (amoFiniteExtend n u) j := by
  induction k generalizing j with
  | zero => simp
  | succ k ih =>
    rw [pow_succ', ContinuousLinearMap.mul_apply,
      amoFiniteExtend_operator_apply α lam θ n _ j (by omega) (by omega),
      pow_succ', ContinuousLinearMap.mul_apply]
    simp only [almostMathieuOperator_apply]
    rw [ih (j + 1) (by omega) (by omega), ih (j - 1) (by omega) (by omega),
      ih j (by omega) (by omega)]

/-- Interior diagonal moments of the genuine finite matrix are exactly the
corresponding diagonal moments of the pre-existing infinite AMO. -/
theorem amoFiniteOperator_pow_diagonal_interior (α lam θ : ℝ) (n k : ℕ) (i : Fin n)
    (hi0 : k ≤ i.val) (hin : i.val + k < n) :
    (((amoFiniteOperator α lam θ n) ^ k) (EuclideanSpace.single i 1)) i =
      (((almostMathieuOperator α lam θ) ^ k) (lp.single 2 (i.val : ℤ) 1)) (i.val : ℤ) := by
  have h := amoFiniteExtend_pow_apply_interior α lam θ n k
    (EuclideanSpace.single i 1) (i.val : ℤ) (by omega) (by omega)
  rw [amoFiniteExtend_apply_site] at h
  change (((amoFiniteOperator α lam θ n) ^ k) (EuclideanSpace.single i 1)) i =
    ((almostMathieuOperator α lam θ) ^ k)
      (amoFiniteEmbedding n (EuclideanSpace.single i 1)) (i.val : ℤ) at h
  simpa only [amoFiniteEmbedding_single] using h

end CriticalDTM

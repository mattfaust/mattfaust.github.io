import DTM.Background.EmpiricalIDS.AMOFiniteVolumeMoments
import DTM.Background.EmpiricalIDS.AMOFiniteVolumeSpectrum

/-!
# Empirical Dirichlet spectral measures and logarithmic determinants

The empirical probability is the equally weighted sum of Dirac masses at the
actual Hermitian Dirichlet matrix eigenvalues, counted with multiplicity. Its
continuous integrals equal the actual normalized finite CFC trace. Consequently
the previously proved finite-volume limit applies to this independently
constructed empirical measure.

At a nonreal energy all determinant factors are nonzero. The logarithm of the
absolute determinant is therefore a genuine finite sum of logarithms, and its
normalized phase average converges to the pre-existing spectral logarithmic
potential. No value of `Real.log 0` enters these conclusions.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Matrix ENNReal Polynomial ContinuousFunctionalCalculus Topology

local instance (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

/-- The physical-coordinate trace is the ordinary matrix trace, with exactly
the actual finite dimension as normalizer. -/
theorem amoFiniteTrace_toEuclideanCLM (n : ℕ) (M : Matrix (Fin (n + 1)) (Fin (n + 1)) ℂ) :
    amoFiniteTrace n ((Matrix.toEuclideanCLM (n := Fin (n + 1)) (𝕜 := ℂ)) M) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * Matrix.trace M := by
  rw [amoFiniteTrace_apply, Matrix.trace]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  change (M *ᵥ Pi.single i 1) i = M i i
  simp

theorem amoFiniteTrace_pow_eq_eigenvalues (α lam θ : ℝ) (n k : ℕ) :
    amoFiniteTrace n ((amoFiniteOperator α lam θ (n + 1)) ^ k) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (((amoFiniteEigenvalues α lam θ (n + 1) i) ^ k : ℝ) : ℂ) := by
  rw [← amoFiniteMatrix_toEuclideanCLM α lam θ (n + 1), ← map_pow,
    amoFiniteTrace_toEuclideanCLM, amoFiniteMatrix_trace_pow]
  simp only [Complex.ofReal_pow]

theorem amoFiniteTrace_aeval_eq_eigenvalues (α lam θ : ℝ) (n : ℕ) (p : ℝ[X]) :
    amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        ((p.eval (amoFiniteEigenvalues α lam θ (n + 1) i) : ℝ) : ℂ) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
    simp only [map_add, Polynomial.eval_add, Complex.ofReal_add,
      Finset.sum_add_distrib, mul_add, hp, hq]
  | monomial k c =>
    simp only [Polynomial.aeval_monomial, Algebra.algebraMap_eq_smul_one,
      smul_mul_assoc, one_mul, ContinuousLinearMap.map_smul_of_tower,
      Polynomial.eval_monomial, Complex.ofReal_mul, Complex.ofReal_pow]
    rw [amoFiniteTrace_pow_eq_eigenvalues, ← Complex.coe_smul]
    simp only [smul_eq_mul, Complex.ofReal_pow, ← Finset.mul_sum]
    ring

set_option maxHeartbeats 800000 in
set_option synthInstance.maxHeartbeats 80000 in
/-- The finite CFC trace is exactly the empirical eigenvalue test. This is
proved from actual matrix diagonalization and common-window approximation. -/
theorem amoFiniteTrace_cfc_eq_eigenvalues (α lam θ : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    amoFiniteTrace n (cfc f (amoFiniteOperator α lam θ (n + 1))) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (f (amoFiniteEigenvalues α lam θ (n + 1) i) : ℂ) := by
  apply sub_eq_zero.mp
  apply norm_eq_zero.mp
  apply le_antisymm _ (norm_nonneg _)
  apply le_of_forall_pos_le_add
  intro epsilon hepsilon
  have hepsilon2 : 0 < epsilon / 2 := by linarith
  let K : Set ℝ := Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|)
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K isCompact_Icc
    f hf.continuousOn (epsilon / 2) hepsilon2
  have hop : ‖cfc f (amoFiniteOperator α lam θ (n + 1)) -
      Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p‖ < epsilon / 2 := by
    apply norm_cfc_sub_polynomial_lt (A := AMOFiniteBoundedOperator (n + 1))
      f K hf.continuousOn p (epsilon / 2) hepsilon2 hp _
      (amoFiniteOperator_isSelfAdjoint α lam θ (n + 1))
    exact real_spectrum_subset_Icc_of_norm_le _ (amoFiniteOperator_norm_le α lam θ (n + 1))
  have htrace : ‖amoFiniteTrace n (cfc f (amoFiniteOperator α lam θ (n + 1))) -
      amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p)‖ ≤ epsilon / 2 := by
    rw [← map_sub]
    exact (norm_amoFiniteTrace_le n _).trans hop.le
  have heig : ‖amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p) -
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (f (amoFiniteEigenvalues α lam θ (n + 1) i) : ℂ)‖ ≤ epsilon / 2 := by
    rw [amoFiniteTrace_aeval_eq_eigenvalues, ← mul_sub, ← Finset.sum_sub_distrib]
    apply amoFinite_mean_norm_le
    intro i
    rw [← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs, abs_sub_comm]
    exact (hp _ (amoFiniteEigenvalues_mem_window α lam θ (n + 1) i)).le
  have htri := norm_sub_le_norm_sub_add_norm_sub
    (amoFiniteTrace n (cfc f (amoFiniteOperator α lam θ (n + 1))))
    (amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p))
    (((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
      (f (amoFiniteEigenvalues α lam θ (n + 1) i) : ℂ))
  linarith

/-- The independently constructed finite-volume empirical probability measure,
with eigenvalues repeated according to their true multiplicity. -/
def amoFiniteSpectralMeasure (α lam θ : ℝ) (n : ℕ) : Measure ℝ :=
  ((n + 1 : ℕ) : ℝ≥0∞)⁻¹ • ∑ i : Fin (n + 1),
    Measure.dirac (amoFiniteEigenvalues α lam θ (n + 1) i)

instance amoFiniteSpectralMeasure_isProbabilityMeasure (α lam θ : ℝ) (n : ℕ) :
    IsProbabilityMeasure (amoFiniteSpectralMeasure α lam θ n) := by
  constructor
  simp only [amoFiniteSpectralMeasure, Measure.smul_apply, Measure.finset_sum_apply,
    measure_univ, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul,
    mul_one, smul_eq_mul]
  exact ENNReal.inv_mul_cancel (by simp : ((n + 1 : ℕ) : ℝ≥0∞) ≠ 0) (by simp)

theorem amoFiniteSpectralMeasure_integral (α lam θ : ℝ) (n : ℕ) (f : ℝ → ℝ) :
    ∫ x, f x ∂amoFiniteSpectralMeasure α lam θ n =
      ((n + 1 : ℕ) : ℝ)⁻¹ * ∑ i : Fin (n + 1), f (amoFiniteEigenvalues α lam θ (n + 1) i) := by
  rw [amoFiniteSpectralMeasure, integral_smul_measure,
    integral_finset_sum_measure (fun _ _ => integrable_dirac)]
  simp only [integral_dirac, ENNReal.toReal_inv, ENNReal.toReal_natCast, smul_eq_mul]

theorem amoFiniteSpectralMeasure_integral_cfc (α lam θ : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂amoFiniteSpectralMeasure α lam θ n =
      amoFiniteTraceReal n (cfc f (amoFiniteOperator α lam θ (n + 1))) := by
  rw [amoFiniteSpectralMeasure_integral, amoFiniteTraceReal_apply,
    amoFiniteTrace_cfc_eq_eigenvalues α lam θ n f hf]
  have hcast : (((((n + 1 : ℕ) : ℝ)⁻¹ *
      ∑ i : Fin (n + 1), f (amoFiniteEigenvalues α lam θ (n + 1) i)) : ℝ) : ℂ) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (f (amoFiniteEigenvalues α lam θ (n + 1) i) : ℂ) := by
    push_cast
    rfl
  simpa only [Complex.ofReal_re] using congrArg Complex.re hcast

/-- Weak spectral-test convergence to the actual previously constructed
measure. No irrationality or almost-every-phase hypothesis is required. -/
theorem tendsto_integral_amoFiniteSpectralMeasure (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1,
      ∫ x, f x ∂amoFiniteSpectralMeasure α lam (2 * Real.pi * t) n) atTop
        (𝓝 (∫ x, f x ∂magneticRealSpectralMeasure α lam)) := by
  simp_rw [amoFiniteSpectralMeasure_integral_cfc α lam _ _ f hf]
  exact tendsto_integral_amoFiniteTraceReal_cfc α lam f hf

/-- The normalized determinant logarithm equals an actual empirical spectral
integral, not a redefined transfer Lyapunov exponent. -/
theorem amoFiniteSpectralMeasure_complexLogKernel (α lam θ : ℝ) (n : ℕ)
    {z : ℂ} (hz : z.im ≠ 0) :
    ∫ x, complexLogKernel z x ∂amoFiniteSpectralMeasure α lam θ n =
      Real.log ‖Matrix.det (z • (1 : Matrix (Fin (n + 1)) (Fin (n + 1)) ℂ) -
        amoFiniteMatrix α lam θ (n + 1))‖ / ((n + 1 : ℕ) : ℝ) := by
  rw [amoFiniteSpectralMeasure_integral, amoFiniteMatrix_log_det_sub α lam θ (n + 1) hz]
  rw [div_eq_mul_inv, mul_comm]

/-- Finite Dirichlet log determinants converge at every nonreal energy to the
pre-existing actual magnetic logarithmic potential. -/
theorem tendsto_integral_amoFinite_logDet (α lam : ℝ) {z : ℂ} (hz : z.im ≠ 0) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1,
      Real.log ‖Matrix.det (z • (1 : Matrix (Fin (n + 1)) (Fin (n + 1)) ℂ) -
        amoFiniteMatrix α lam (2 * Real.pi * t) (n + 1))‖ / ((n + 1 : ℕ) : ℝ)) atTop
      (𝓝 (magneticComplexLogPotential α lam z)) := by
  simp_rw [← amoFiniteSpectralMeasure_complexLogKernel α lam _ _ hz]
  exact tendsto_integral_amoFiniteSpectralMeasure α lam (complexLogKernel z)
    (complexLogKernel_continuous hz)

end CriticalDTM

import DTM.Background.EmpiricalIDS.AMOFiniteVolume
import DTM.Background.Realization.AMOPhaseCovariance
import DTM.Background.Realization.AMOMagneticMeasureBridge
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.Analysis.SpecificLimits.Basic

/-!
# Finite Dirichlet moments and continuous spectral tests

An exact interior receiving-row identity leaves at most `2k` boundary sites
for a moment of degree `k`. The uniform operator bound controls their error.
After the actual phase average, integer covariance identifies every bulk
coordinate with the pre-existing AMO root state. Thus the normalized moments
converge to the actual magnetic/AMO measure, not to an assumed finite-volume
limit. A common-window polynomial approximation gives continuous CFC tests.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Topology Polynomial ContinuousFunctionalCalculus

local instance (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

/-- The finite physical coordinate state. -/
def amoFiniteCoordinateState (n : ℕ) (i : Fin n) : AMOFiniteBoundedOperator n →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun A => A (EuclideanSpace.single i 1) i
      map_add' := by intro A B; simp
      map_smul' := by intro c A; simp }
    1 (fun A => by
      calc
        ‖A (EuclideanSpace.single i 1) i‖ ≤ ‖A (EuclideanSpace.single i 1)‖ :=
          PiLp.norm_apply_le _ _
        _ ≤ ‖A‖ * ‖EuclideanSpace.single i (1 : ℂ)‖ := A.le_opNorm _
        _ = 1 * ‖A‖ := by simp)

@[simp] theorem amoFiniteCoordinateState_apply (n : ℕ) (i : Fin n)
    (A : AMOFiniteBoundedOperator n) :
    amoFiniteCoordinateState n i A = A (EuclideanSpace.single i 1) i := rfl

theorem norm_amoFiniteCoordinateState_le (n : ℕ) (i : Fin n)
    (A : AMOFiniteBoundedOperator n) : ‖amoFiniteCoordinateState n i A‖ ≤ ‖A‖ := by
  calc
    _ ≤ ‖A (EuclideanSpace.single i 1)‖ := PiLp.norm_apply_le _ _
    _ ≤ ‖A‖ * ‖EuclideanSpace.single i (1 : ℂ)‖ := A.le_opNorm _
    _ = ‖A‖ := by simp

theorem amoFinite_mean_norm_le (n : ℕ) (a : Fin (n + 1) → ℂ) (C : ℝ)
    (ha : ∀ i, ‖a i‖ ≤ C) :
    ‖((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i, a i‖ ≤ C := by
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  calc
    _ ≤ ((n + 1 : ℕ) : ℝ)⁻¹ * (∑ _i : Fin (n + 1), C) :=
      mul_le_mul_of_nonneg_left
        ((norm_sum_le _ _).trans (Finset.sum_le_sum (fun i _ => ha i))) (by positivity)
    _ = C := by
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      rw [← mul_assoc, inv_mul_cancel₀ (by positivity : ((n + 1 : ℕ) : ℝ) ≠ 0), one_mul]

/-- Normalized physical-coordinate trace on the nonempty interval of length
`n+1`. It is the ordinary matrix trace divided by its actual dimension. -/
def amoFiniteTrace (n : ℕ) : AMOFiniteBoundedOperator (n + 1) →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun A => ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i, amoFiniteCoordinateState (n + 1) i A
      map_add' := by intro A B; simp [Finset.sum_add_distrib, mul_add]
      map_smul' := by intro c A; simp [Finset.mul_sum, mul_left_comm] }
    1 (fun A => by
      simpa only [one_mul] using amoFinite_mean_norm_le n _ ‖A‖
        (fun i => norm_amoFiniteCoordinateState_le (n + 1) i A))

@[simp] theorem amoFiniteTrace_apply (n : ℕ) (A : AMOFiniteBoundedOperator (n + 1)) :
    amoFiniteTrace n A =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i, amoFiniteCoordinateState (n + 1) i A := rfl

theorem norm_amoFiniteTrace_le (n : ℕ) (A : AMOFiniteBoundedOperator (n + 1)) :
    ‖amoFiniteTrace n A‖ ≤ ‖A‖ :=
  amoFinite_mean_norm_le n _ ‖A‖
    (fun i => norm_amoFiniteCoordinateState_le (n + 1) i A)

/-- The unit source at a physical integer site. -/
def amoCoordinateVector (j : ℤ) : AMOHilbert := lp.single 2 j (1 : ℂ)

@[simp] theorem amoCoordinateVector_norm (j : ℤ) : ‖amoCoordinateVector j‖ = 1 := by
  simp [amoCoordinateVector, lp.norm_single]

/-- The infinite physical coordinate state at an arbitrary retained site. -/
def amoCoordinateState (j : ℤ) : AMOBoundedOperator →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun A => A (amoCoordinateVector j) j
      map_add' := by intro A B; simp
      map_smul' := by intro c A; simp }
    1 (fun A => by
      calc
        ‖A (amoCoordinateVector j) j‖ ≤ ‖A (amoCoordinateVector j)‖ :=
          lp.norm_apply_le_norm (by norm_num) _ _
        _ ≤ ‖A‖ * ‖amoCoordinateVector j‖ := A.le_opNorm _
        _ = 1 * ‖A‖ := by simp [lp.norm_single])

@[simp] theorem amoCoordinateState_apply (j : ℤ) (A : AMOBoundedOperator) :
    amoCoordinateState j A = A (amoCoordinateVector j) j := rfl

theorem norm_amoCoordinateState_le (j : ℤ) (A : AMOBoundedOperator) :
    ‖amoCoordinateState j A‖ ≤ ‖A‖ := by
  calc
    _ ≤ ‖A (amoCoordinateVector j)‖ := lp.norm_apply_le_norm (by norm_num) _ _
    _ ≤ ‖A‖ * ‖amoCoordinateVector j‖ := A.le_opNorm _
    _ = ‖A‖ := by simp [lp.norm_single]

/-- Translation transports the coordinate source as well as the Hamiltonian. -/
theorem amoCoordinateState_pow_eq_root (α lam θ : ℝ) (j : ℤ) (k : ℕ) :
    amoCoordinateState j ((almostMathieuOperator α lam θ) ^ k) =
      amoRootState ((almostMathieuOperator α lam (θ + 2 * Real.pi * α * (j : ℝ))) ^ k) := by
  have hshift : amoIntegerShift j (amoCoordinateVector j) = amoRoot := by
    apply lp.ext
    funext q
    simp [amoRoot, amoCoordinateVector, lp.coeFn_single, Pi.single_apply]
  have hsemi : SemiconjBy (amoIntegerShift j) (almostMathieuOperator α lam θ)
      (almostMathieuOperator α lam (θ + 2 * Real.pi * α * (j : ℝ))) :=
    almostMathieuOperator_phase_intertwining α lam θ j
  have h := congrArg (fun A : AMOBoundedOperator => A (amoCoordinateVector j) 0)
    (hsemi.pow_right k)
  simpa only [ContinuousLinearMap.mul_apply, amoIntegerShift_apply, zero_add, hshift,
    amoCoordinateState_apply, amoRootState_apply] using h

theorem integral_amoCoordinateState_pow (α lam : ℝ) (j : ℤ) (k : ℕ) :
    (∫ t in (0 : ℝ)..1,
      amoCoordinateState j ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)) =
        rootTrace ((hOperator α (lam : ℂ)) ^ k) := by
  let f : ℝ → ℂ := fun t => amoRootState ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)
  have hf : Function.Periodic f 1 := by
    intro t
    dsimp [f]
    rw [show 2 * Real.pi * (t + 1) = 2 * Real.pi * t + 2 * Real.pi by ring,
      almostMathieuOperator_phase_periodic α lam]
  have heq (t : ℝ) :
      amoCoordinateState j ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k) =
        f (t + α * (j : ℝ)) := by
    rw [amoCoordinateState_pow_eq_root]
    congr 3
    ring
  simp_rw [heq]
  rw [intervalIntegral.integral_comp_add_right]
  have h := hf.intervalIntegral_add_eq (α * (j : ℝ)) 0
  simp only [zero_add] at h ⊢
  rw [add_comm (1 : ℝ), h]
  exact integral_amoRootState_pow α lam k

/-- There are at most `2k` sites whose radius-`k` receiving paths can meet a wall. -/
theorem amoFinite_boundary_card_le (n k : ℕ) :
    (Finset.univ.filter (fun i : Fin n => ¬ (k ≤ i.val ∧ i.val + k < n))).card ≤ 2 * k := by
  let L := Finset.univ.filter (fun i : Fin n => i.val < k)
  let R := Finset.univ.filter (fun i : Fin n => n ≤ i.val + k)
  have hL : L.card ≤ k := by
    have h := Finset.card_le_card_of_injOn (s := L) (t := Finset.range k)
      (fun i : Fin n => i.val) (by intro i hi; simpa [L] using hi)
      (by intro i _ j _ hij; exact Fin.ext hij)
    simpa using h
  have hR : R.card ≤ k := by
    have h := Finset.card_le_card_of_injOn (s := R) (t := Finset.range k)
      (fun i : Fin n => n - 1 - i.val) (by
        intro i hi
        have hi' : n ≤ i.val + k := (Finset.mem_filter.mp hi).2
        simp only [Finset.mem_range]
        have := i.isLt
        omega) (by
        intro i _ j _ hij
        dsimp only at hij
        apply Fin.ext
        have := i.isLt
        have := j.isLt
        omega)
    simpa using h
  have heq : Finset.univ.filter (fun i : Fin n => ¬ (k ≤ i.val ∧ i.val + k < n)) = L ∪ R := by
    ext i
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_union, L, R]
    omega
  rw [heq]
  exact (Finset.card_union_le L R).trans (by omega)

/-- Uniform boundary error for the normalized `k`th moment. -/
theorem norm_amoFiniteTrace_pow_sub_bulk_le (α lam θ : ℝ) (n k : ℕ) :
    ‖amoFiniteTrace n ((amoFiniteOperator α lam θ (n + 1)) ^ k) -
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        amoCoordinateState (i.val : ℤ) ((almostMathieuOperator α lam θ) ^ k)‖ ≤
      (4 * (k : ℝ) * (2 + 2 * |lam|) ^ k) / ((n + 1 : ℕ) : ℝ) := by
  let S := Finset.univ.filter (fun i : Fin (n + 1) => ¬ (k ≤ i.val ∧ i.val + k < n + 1))
  let d : Fin (n + 1) → ℂ := fun i =>
    amoFiniteCoordinateState (n + 1) i ((amoFiniteOperator α lam θ (n + 1)) ^ k) -
      amoCoordinateState (i.val : ℤ) ((almostMathieuOperator α lam θ) ^ k)
  have hnorm (i : Fin (n + 1)) : ‖d i‖ ≤ 2 * (2 + 2 * |lam|) ^ k := by
    have hf := (norm_amoFiniteCoordinateState_le (n + 1) i _).trans
      ((norm_pow_le _ k).trans (pow_le_pow_left₀ (norm_nonneg _)
        (amoFiniteOperator_norm_le α lam θ (n + 1)) k))
    have hi := (norm_amoCoordinateState_le (i.val : ℤ) _).trans
      ((norm_pow_le _ k).trans (pow_le_pow_left₀ (norm_nonneg _)
        (almostMathieuOperator_norm_le α lam θ) k))
    calc
      ‖d i‖ ≤ ‖amoFiniteCoordinateState (n + 1) i
          ((amoFiniteOperator α lam θ (n + 1)) ^ k)‖ +
          ‖amoCoordinateState (i.val : ℤ) ((almostMathieuOperator α lam θ) ^ k)‖ :=
        norm_sub_le _ _
      _ ≤ 2 * (2 + 2 * |lam|) ^ k := by linarith
  have hsum : (∑ i, d i) = ∑ i ∈ S, d i := by
    symm
    apply Finset.sum_subset (Finset.subset_univ _)
    intro i _ hi
    have hi' : k ≤ i.val ∧ i.val + k < n + 1 := by simpa [S] using hi
    exact sub_eq_zero.mpr (amoFiniteOperator_pow_diagonal_interior α lam θ (n + 1) k i hi'.1 hi'.2)
  have hbound : ‖∑ i, d i‖ ≤ 4 * (k : ℝ) * (2 + 2 * |lam|) ^ k := by
    rw [hsum]
    calc
      _ ≤ ∑ _i ∈ S, 2 * (2 + 2 * |lam|) ^ k :=
        (norm_sum_le _ _).trans (Finset.sum_le_sum (fun i _ => hnorm i))
      _ = (S.card : ℝ) * (2 * (2 + 2 * |lam|) ^ k) := by simp
      _ ≤ ((2 * k : ℕ) : ℝ) * (2 * (2 + 2 * |lam|) ^ k) :=
        mul_le_mul_of_nonneg_right (by exact_mod_cast amoFinite_boundary_card_le (n + 1) k)
          (by positivity)
      _ = _ := by push_cast; ring
  rw [amoFiniteTrace_apply, ← mul_sub, ← Finset.sum_sub_distrib]
  change ‖((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i, d i‖ ≤ _
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  calc
    _ ≤ ((n + 1 : ℕ) : ℝ)⁻¹ * (4 * (k : ℝ) * (2 + 2 * |lam|) ^ k) :=
      mul_le_mul_of_nonneg_left hbound (by positivity)
    _ = _ := by rw [div_eq_mul_inv, mul_comm]

theorem amoFiniteTrace_pow_intervalIntegrable (α lam : ℝ) (n k : ℕ) :
    IntervalIntegrable (fun t => amoFiniteTrace n
      ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) volume (0 : ℝ) 1 :=
  ((amoFiniteTrace n).continuous.comp
    (((continuous_amoFiniteOperator_phase α lam (n + 1)).comp
      (continuous_const.mul continuous_id)).pow k)).intervalIntegrable 0 1

theorem amoCoordinateState_pow_intervalIntegrable (α lam : ℝ) (j : ℤ) (k : ℕ) :
    IntervalIntegrable (fun t => amoCoordinateState j
      ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)) volume (0 : ℝ) 1 :=
  ((amoCoordinateState j).continuous.comp
    (((continuous_almostMathieuOperator_phase α lam).comp
      (continuous_const.mul continuous_id)).pow k)).intervalIntegrable 0 1

/-- The averaged finite Dirichlet moments converge to moments of the actual
magnetic measure, equivalently the actual phase-averaged AMO root measure. -/
theorem tendsto_integral_amoFiniteTrace_pow (α lam : ℝ) (k : ℕ) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1,
      amoFiniteTrace n ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) atTop
        (𝓝 (rootTrace ((hOperator α (lam : ℂ)) ^ k))) := by
  have hbound (n : ℕ) :
      ‖(∫ t in (0 : ℝ)..1,
        amoFiniteTrace n ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) -
          rootTrace ((hOperator α (lam : ℂ)) ^ k)‖ ≤
        (4 * (k : ℝ) * (2 + 2 * |lam|) ^ k) / ((n + 1 : ℕ) : ℝ) := by
    have hbulk : (∫ t in (0 : ℝ)..1, ((n + 1 : ℕ) : ℂ)⁻¹ *
        ∑ i : Fin (n + 1), amoCoordinateState (i.val : ℤ)
          ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)) =
        rootTrace ((hOperator α (lam : ℂ)) ^ k) := by
      rw [intervalIntegral.integral_const_mul, intervalIntegral.integral_finset_sum]
      · simp only [integral_amoCoordinateState_pow, Finset.sum_const, Finset.card_univ,
          Fintype.card_fin, nsmul_eq_mul]
        rw [← mul_assoc, inv_mul_cancel₀ (Nat.cast_ne_zero.mpr (Nat.succ_ne_zero n)), one_mul]
      · intro i _
        exact amoCoordinateState_pow_intervalIntegrable α lam _ k
    have hbulki : IntervalIntegrable (fun t => ((n + 1 : ℕ) : ℂ)⁻¹ *
        ∑ i : Fin (n + 1), amoCoordinateState (i.val : ℤ)
          ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)) volume (0 : ℝ) 1 := by
      simpa only [Finset.sum_apply] using
        ((IntervalIntegrable.sum Finset.univ (fun (i : Fin (n + 1)) _ =>
          amoCoordinateState_pow_intervalIntegrable α lam (i.val : ℤ) k)).const_mul
            (((n + 1 : ℕ) : ℂ)⁻¹))
    rw [← hbulk, ← intervalIntegral.integral_sub
      (amoFiniteTrace_pow_intervalIntegrable α lam n k) hbulki]
    have h := intervalIntegral.norm_integral_le_of_norm_le_const (a := (0 : ℝ)) (b := 1)
      (fun t _ => norm_amoFiniteTrace_pow_sub_bulk_le α lam (2 * Real.pi * t) n k)
    simpa using h
  apply tendsto_iff_norm_sub_tendsto_zero.mpr
  exact squeeze_zero (fun n => norm_nonneg _) hbound
    ((tendsto_add_atTop_iff_nat 1).2
      (tendsto_const_div_atTop_nhds_zero_nat (4 * (k : ℝ) * (2 + 2 * |lam|) ^ k)))

theorem amoFiniteTrace_aeval_intervalIntegrable (α lam : ℝ) (n : ℕ) (p : ℝ[X]) :
    IntervalIntegrable (fun t => amoFiniteTrace n
      (Polynomial.aeval (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p))
      volume (0 : ℝ) 1 :=
  ((amoFiniteTrace n).continuous.comp
    (p.continuous_aeval.comp ((continuous_amoFiniteOperator_phase α lam (n + 1)).comp
      (continuous_const.mul continuous_id)))).intervalIntegrable 0 1

theorem tendsto_integral_amoFiniteTrace_aeval (α lam : ℝ) (p : ℝ[X]) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1, amoFiniteTrace n
      (Polynomial.aeval (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p)) atTop
        (𝓝 (rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p))) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
    simp only [map_add]
    simp_rw [intervalIntegral.integral_add
      (amoFiniteTrace_aeval_intervalIntegrable α lam _ p)
      (amoFiniteTrace_aeval_intervalIntegrable α lam _ q)]
    exact hp.add hq
  | monomial k c =>
    simp only [Polynomial.aeval_monomial, Algebra.algebraMap_eq_smul_one,
      smul_mul_assoc, one_mul, Complex.coe_smul, map_smul, smul_eq_mul]
    simp only [ContinuousLinearMap.map_smul_of_tower, intervalIntegral.integral_smul]
    exact (tendsto_integral_amoFiniteTrace_pow α lam k).const_smul c

theorem continuous_amoFiniteTrace_cfc_phase (α lam : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    Continuous (fun θ => amoFiniteTrace n (cfc f (amoFiniteOperator α lam θ (n + 1)))) := by
  rw [continuous_iff_continuousAt]
  intro θ
  exact (amoFiniteTrace n).continuous.continuousAt.comp
    (continuousAt_cfc_of_continuous (fun θ => amoFiniteOperator α lam θ (n + 1)) θ
      (continuous_amoFiniteOperator_phase α lam (n + 1)).continuousAt f hf
      (Eventually.of_forall (fun θ => amoFiniteOperator_isSelfAdjoint α lam θ (n + 1))))

theorem amoFiniteTrace_cfc_intervalIntegrable (α lam : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    IntervalIntegrable (fun t => amoFiniteTrace n
      (cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)))) volume (0 : ℝ) 1 :=
  ((continuous_amoFiniteTrace_cfc_phase α lam n f hf).comp
    (continuous_const.mul continuous_id)).intervalIntegrable 0 1

set_option maxHeartbeats 800000 in
set_option synthInstance.maxHeartbeats 80000 in
/-- Actual finite Dirichlet normalized CFC traces converge, after phase average,
to the same continuous test of the pre-existing magnetic Hamiltonian. -/
theorem tendsto_integral_amoFiniteTrace_cfc (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1, amoFiniteTrace n
      (cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)))) atTop
        (𝓝 (rootTrace (cfc f (hOperator α (lam : ℂ))))) := by
  apply Metric.tendsto_nhds.mpr
  intro epsilon hepsilon
  have hepsilon3 : 0 < epsilon / 3 := by linarith
  let K : Set ℝ := Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|)
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K isCompact_Icc
    f hf.continuousOn (epsilon / 3) hepsilon3
  have hmag : ‖cfc f (hOperator α (lam : ℂ)) -
      Polynomial.aeval (hOperator α (lam : ℂ)) p‖ < epsilon / 3 := by
    apply norm_cfc_sub_polynomial_lt f K hf.continuousOn p (epsilon / 3) hepsilon3 hp
      _ (hOperator_isSelfAdjoint α lam)
    exact real_spectrum_subset_Icc_of_norm_le _ (by
      simpa only [Complex.norm_real, Real.norm_eq_abs] using hOperator_norm_le α (lam : ℂ))
  have hfinite (n : ℕ) (t : ℝ) :
      ‖cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) -
        Polynomial.aeval (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p‖ <
          epsilon / 3 := by
    apply norm_cfc_sub_polynomial_lt (A := AMOFiniteBoundedOperator (n + 1))
      f K hf.continuousOn p (epsilon / 3) hepsilon3 hp
      _ (amoFiniteOperator_isSelfAdjoint α lam _ (n + 1))
    exact real_spectrum_subset_Icc_of_norm_le _ (amoFiniteOperator_norm_le α lam _ (n + 1))
  have hmean (n : ℕ) :
      ‖(∫ t in (0 : ℝ)..1, amoFiniteTrace n
          (cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)))) -
        (∫ t in (0 : ℝ)..1, amoFiniteTrace n
          (Polynomial.aeval (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p))‖ ≤
            epsilon / 3 := by
    rw [← intervalIntegral.integral_sub (amoFiniteTrace_cfc_intervalIntegrable α lam n f hf)
      (amoFiniteTrace_aeval_intervalIntegrable α lam n p)]
    have h := intervalIntegral.norm_integral_le_of_norm_le_const (a := (0 : ℝ)) (b := 1)
      (f := fun t => amoFiniteTrace n
          (cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1))) -
        amoFiniteTrace n (Polynomial.aeval
          (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p))
      (C := epsilon / 3) (fun t _ => by
        dsimp only
        rw [← map_sub]
        exact (norm_amoFiniteTrace_le n _).trans (hfinite n t).le)
    simpa using h
  have hroot : ‖rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p) -
      rootTrace (cfc f (hOperator α (lam : ℂ)))‖ ≤ epsilon / 3 := by
    rw [norm_sub_rev, ← map_sub]
    exact (norm_rootTrace_le _).trans hmag.le
  filter_upwards [Metric.tendsto_nhds.mp
    (tendsto_integral_amoFiniteTrace_aeval α lam p) (epsilon / 3) hepsilon3] with n hn
  rw [dist_eq_norm] at hn ⊢
  have htriangle := norm_sub_le_norm_sub_add_norm_sub
    (∫ t in (0 : ℝ)..1, amoFiniteTrace n
      (cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1))))
    (∫ t in (0 : ℝ)..1, amoFiniteTrace n
      (Polynomial.aeval (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p))
    (rootTrace (cfc f (hOperator α (lam : ℂ))))
  have htriangle' := norm_sub_le_norm_sub_add_norm_sub
    (∫ t in (0 : ℝ)..1, amoFiniteTrace n
      (Polynomial.aeval (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) p))
    (rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p))
    (rootTrace (cfc f (hOperator α (lam : ℂ))))
  linarith [hmean n]

/-- Real trace convention used by spectral probability measures. -/
def amoFiniteTraceReal (n : ℕ) : AMOFiniteBoundedOperator (n + 1) →L[ℝ] ℝ :=
  Complex.reCLM.comp ((amoFiniteTrace n).restrictScalars ℝ)

@[simp] theorem amoFiniteTraceReal_apply (n : ℕ) (A : AMOFiniteBoundedOperator (n + 1)) :
    amoFiniteTraceReal n A = (amoFiniteTrace n A).re := rfl

/-- The target is the integral against the actual measure constructed earlier,
not a newly named finite density of states. -/
theorem tendsto_integral_amoFiniteTraceReal_cfc (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1, amoFiniteTraceReal n
      (cfc f (amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)))) atTop
        (𝓝 (∫ x, f x ∂magneticRealSpectralMeasure α lam)) := by
  have htarget : (rootTrace (cfc f (hOperator α (lam : ℂ)))).re =
      ∫ x, f x ∂magneticRealSpectralMeasure α lam := by
    rw [magneticRealSpectralMeasure_integral_eq_phase_average α lam f hf]
    simp_rw [amoRealSpectralMeasure_integral_cfc α lam _ f hf]
    exact (integral_amoRootStateReal_cfc α lam f hf).symm
  have h := Complex.continuous_re.continuousAt.tendsto.comp
    (tendsto_integral_amoFiniteTrace_cfc α lam f hf)
  rw [htarget] at h
  convert h using 1
  funext n
  exact Complex.reCLM.intervalIntegral_comp_comm
    (amoFiniteTrace_cfc_intervalIntegrable α lam n f hf)

end CriticalDTM

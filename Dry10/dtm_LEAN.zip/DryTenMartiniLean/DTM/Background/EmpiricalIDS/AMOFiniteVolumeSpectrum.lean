import DTM.Background.EmpiricalIDS.AMOFiniteVolume
import DTM.Background.Potential.AMOComplexPotential
import Mathlib.LinearAlgebra.Matrix.Trace

/-!
# The actual Dirichlet eigenvalues and determinant

Finite Hermitian diagonalization supplies real eigenvalues of the actual
Dirichlet compression, their common spectral window, moment traces and the
nonreal determinant product. Every logarithmic factor is proved nonzero.
-/

noncomputable section
namespace CriticalDTM

open Set
open scoped Matrix Matrix.L2OpNorm

/-- The real eigenvalues, counted with multiplicity, of the actual Dirichlet
matrix on the physical sites `0,...,n-1`. -/
def amoFiniteEigenvalues (α lam θ : ℝ) (n : ℕ) : Fin n → ℝ :=
  (amoFiniteMatrix_isHermitian α lam θ n).eigenvalues

theorem amoFiniteEigenvalues_mem_window (α lam θ : ℝ) (n : ℕ) (i : Fin n) :
    amoFiniteEigenvalues α lam θ n i ∈ Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|) := by
  letI : Nonempty (Fin n) := ⟨i⟩
  have hnorm : ‖amoFiniteEigenvalues α lam θ n i‖ ≤ ‖amoFiniteMatrix α lam θ n‖ :=
    spectrum.norm_le_norm_of_mem
      ((amoFiniteMatrix_isHermitian α lam θ n).eigenvalues_mem_spectrum_real i)
  exact abs_le.mp (hnorm.trans (amoFiniteMatrix_norm_le α lam θ n))

/-- Finite Hermitian diagonalization identifies every actual matrix moment
with the sum of the corresponding eigenvalue moments. -/
theorem amoFiniteMatrix_trace_pow (α lam θ : ℝ) (n k : ℕ) :
    Matrix.trace ((amoFiniteMatrix α lam θ n) ^ k) =
      ∑ i : Fin n, (amoFiniteEigenvalues α lam θ n i : ℂ) ^ k := by
  let hM := amoFiniteMatrix_isHermitian α lam θ n
  let U : (Matrix (Fin n) (Fin n) ℂ)ˣ := unitary.toUnits hM.eigenvectorUnitary
  have hdiag : amoFiniteMatrix α lam θ n =
      (U : Matrix (Fin n) (Fin n) ℂ) *
        Matrix.diagonal (fun i => (amoFiniteEigenvalues α lam θ n i : ℂ)) *
          (↑U⁻¹ : Matrix (Fin n) (Fin n) ℂ) := hM.spectral_theorem
  rw [hdiag, Units.conj_pow, Matrix.trace_units_conj, Matrix.diagonal_pow, Matrix.trace_diagonal]
  rfl

/-- The determinant factors over exactly the actual Dirichlet eigenvalues. -/
theorem amoFiniteMatrix_det_sub_eq_prod (α lam θ : ℝ) (n : ℕ) (z : ℂ) :
    Matrix.det (z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n) =
      ∏ i : Fin n, (z - (amoFiniteEigenvalues α lam θ n i : ℂ)) := by
  let hM := amoFiniteMatrix_isHermitian α lam θ n
  let U : (Matrix (Fin n) (Fin n) ℂ)ˣ := unitary.toUnits hM.eigenvectorUnitary
  let D : Matrix (Fin n) (Fin n) ℂ :=
    Matrix.diagonal (fun i => (amoFiniteEigenvalues α lam θ n i : ℂ))
  have hdiag : amoFiniteMatrix α lam θ n =
      (U : Matrix (Fin n) (Fin n) ℂ) * D * (↑U⁻¹ : Matrix (Fin n) (Fin n) ℂ) :=
    hM.spectral_theorem
  have hconj : z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n =
      (U : Matrix (Fin n) (Fin n) ℂ) * (z • 1 - D) *
        (↑U⁻¹ : Matrix (Fin n) (Fin n) ℂ) := by
    rw [mul_sub, sub_mul, mul_smul_comm, mul_one, smul_mul_assoc, Units.mul_inv, ← hdiag]
  rw [hconj, Matrix.det_units_conj]
  have heq : z • (1 : Matrix (Fin n) (Fin n) ℂ) - D =
      Matrix.diagonal (fun i => z - (amoFiniteEigenvalues α lam θ n i : ℂ)) := by
    ext i j
    by_cases hij : i = j <;> simp [D, Matrix.diagonal_apply, Matrix.one_apply, hij]
  rw [heq, Matrix.det_diagonal]

/-- The ordinary real logarithm is applied only to nonzero determinant factors. -/
theorem amoFiniteMatrix_log_det_sub (α lam θ : ℝ) (n : ℕ) {z : ℂ} (hz : z.im ≠ 0) :
    Real.log ‖Matrix.det (z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n)‖ =
      ∑ i : Fin n, complexLogKernel z (amoFiniteEigenvalues α lam θ n i) := by
  rw [amoFiniteMatrix_det_sub_eq_prod, norm_prod, Real.log_prod]
  · rfl
  · intro i _ h
    apply hz
    have heq := congrArg Complex.im (sub_eq_zero.mp (norm_eq_zero.mp h))
    simpa using heq

end CriticalDTM

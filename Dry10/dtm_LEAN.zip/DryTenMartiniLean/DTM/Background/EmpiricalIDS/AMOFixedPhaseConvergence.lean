import DTM.Background.EmpiricalIDS.AMOFiniteVolumeMeasure
import Mathlib.Algebra.GeomSum

/-!
# Fixed-phase empirical Dirichlet convergence

For an irrational frequency, each nonconstant magnetic character has a bounded
geometric orbit sum. The explicit paired magnetic/AMO polynomial span therefore
identifies fixed-phase bulk moments with the magnetic root moments. The finite
Dirichlet boundary estimate and common-window polynomial approximation give
convergence of every continuous test of the actual empirical eigenvalue measure.
No phase average is taken on the finite-volume side.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Topology Polynomial ContinuousFunctionalCalculus

local instance (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

private theorem magneticPhase_parameter_add (s t : ℝ) (k : ℤ) :
    magneticPhase (s + t) k = magneticPhase s k * magneticPhase t k := by
  simp only [magneticPhase, mul_add, add_mul, Complex.ofReal_add, Complex.exp_add]

private theorem magneticPhase_orbit_eq (α t : ℝ) (k : ℤ) (j : ℕ) :
    magneticPhase (t + α * (j : ℝ)) k =
      magneticPhase t k * magneticPhase α k ^ j := by
  induction j with
  | zero => simp
  | succ j ih =>
    rw [Nat.cast_succ, mul_add, mul_one, ← add_assoc,
      magneticPhase_parameter_add, ih, pow_succ, mul_assoc]

/-- Every nonconstant magnetic character has a bounded orbit sum. -/
theorem norm_sum_magneticPhase_orbit_le {α : ℝ} (hα : Irrational α)
    (t : ℝ) {k : ℤ} (hk : k ≠ 0) (n : ℕ) :
    ‖∑ i : Fin (n + 1), magneticPhase (t + α * (i.val : ℝ)) k‖ ≤
      2 / ‖magneticPhase α k - 1‖ := by
  simp_rw [magneticPhase_orbit_eq]
  rw [← Finset.mul_sum, norm_mul, magneticPhase_norm, one_mul,
    Fin.sum_univ_eq_sum_range, geom_sum_eq (magneticPhase_ne_one hα hk), norm_div]
  apply div_le_div_of_nonneg_right _ (norm_nonneg _)
  calc
    ‖magneticPhase α k ^ (n + 1) - 1‖ ≤ ‖magneticPhase α k ^ (n + 1)‖ + ‖(1 : ℂ)‖ :=
      norm_sub_le _ _
    _ = 2 := by norm_num [norm_pow, magneticPhase_norm]

/-- Irrational rotation averages of the explicit characters, at every phase. -/
theorem tendsto_magneticPhase_orbit_mean {α : ℝ} (hα : Irrational α)
    (t : ℝ) (k : ℤ) :
    Tendsto (fun n => ((n + 1 : ℕ) : ℂ)⁻¹ *
      ∑ i : Fin (n + 1), magneticPhase (t + α * (i.val : ℝ)) k) atTop
      (𝓝 (if k = 0 then 1 else 0)) := by
  by_cases hk : k = 0
  · subst k
    have heq (n : ℕ) : ((n + 1 : ℕ) : ℂ)⁻¹ *
        ∑ i : Fin (n + 1), magneticPhase (t + α * (i.val : ℝ)) 0 = 1 := by
      simp only [magneticPhase_zero, Finset.sum_const, Finset.card_univ,
        Fintype.card_fin, nsmul_eq_mul, mul_one]
      exact inv_mul_cancel₀ (Nat.cast_ne_zero.mpr (Nat.succ_ne_zero n))
    simpa only [heq, if_pos rfl] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (1 : ℂ)) atTop (𝓝 1))
  · rw [if_neg hk]
    apply tendsto_iff_norm_sub_tendsto_zero.mpr
    simp only [sub_zero]
    have hbound (n : ℕ) :
        ‖((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
          magneticPhase (t + α * (i.val : ℝ)) k‖ ≤
          (2 / ‖magneticPhase α k - 1‖) / ((n + 1 : ℕ) : ℝ) := by
      rw [norm_mul, norm_inv, Complex.norm_natCast]
      calc
        _ ≤ ((n + 1 : ℕ) : ℝ)⁻¹ * (2 / ‖magneticPhase α k - 1‖) :=
          mul_le_mul_of_nonneg_left (norm_sum_magneticPhase_orbit_le hα t hk n)
            (by positivity)
        _ = _ := by simp only [div_eq_mul_inv]; ring
    exact squeeze_zero (fun n => norm_nonneg _) hbound
      ((tendsto_add_atTop_iff_nat 1).2
        (tendsto_const_div_atTop_nhds_zero_nat (2 / ‖magneticPhase α k - 1‖)))

/-- On the explicit simultaneous polynomial span, fixed-phase orbit means
converge to the physical magnetic root functional. -/
theorem magneticAMOPolynomialSpace_root_orbit_mean {α : ℝ} (hα : Irrational α)
    (t : ℝ) {A : MagneticBoundedOperator × (ℝ → AMOBoundedOperator)}
    (hA : A ∈ magneticAMOPolynomialSpace α) :
    Tendsto (fun n => ((n + 1 : ℕ) : ℂ)⁻¹ *
      ∑ i : Fin (n + 1), amoRootState (A.2 (t + α * (i.val : ℝ)))) atTop
      (𝓝 (rootTrace A.1)) := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    by_cases ha : a.1 = 0
    · simpa only [amoRootState_amoMagneticMonomial, ha, if_pos rfl,
        rootTrace_magneticMonomial, origin, Prod.ext_iff, true_and] using
        tendsto_magneticPhase_orbit_mean hα t a.2
    · have ha' : a ≠ origin := by
        intro h
        exact ha (congrArg Prod.fst h)
      simp only [amoRootState_amoMagneticMonomial, if_neg ha, rootTrace_magneticMonomial,
        if_neg ha', Finset.sum_const_zero, mul_zero]
      exact tendsto_const_nhds
  | zero =>
    simpa only [Prod.fst_zero, Prod.snd_zero, Pi.zero_apply, map_zero,
      Finset.sum_const_zero, mul_zero] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℂ)) atTop (𝓝 0))
  | add A B hA hB ihA ihB =>
    simp only [Prod.fst_add, Prod.snd_add, Pi.add_apply, map_add,
      Finset.sum_add_distrib, mul_add]
    exact ihA.add ihB
  | smul c A hA ih =>
    simpa only [Prod.smul_fst, Prod.smul_snd, Pi.smul_apply, map_smul, smul_eq_mul,
      ← Finset.mul_sum, mul_left_comm] using ih.const_mul c

/-- Spatial bulk moments converge at each fixed physical radian phase. -/
theorem tendsto_amoCoordinateState_pow_mean {α : ℝ} (hα : Irrational α)
    (lam θ : ℝ) (k : ℕ) :
    Tendsto (fun n => ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
      amoCoordinateState (i.val : ℤ) ((almostMathieuOperator α lam θ) ^ k)) atTop
      (𝓝 (rootTrace ((hOperator α (lam : ℂ)) ^ k))) := by
  have h := magneticAMOPolynomialSpace_root_orbit_mean hα (θ / (2 * Real.pi))
    (magneticAMOPolynomialSpace_pow_mem α (magneticAMOHamiltonian_mem α lam) k)
  have hphase (j : ℕ) :
      θ + 2 * Real.pi * α * ((j : ℤ) : ℝ) =
        2 * Real.pi * (θ / (2 * Real.pi) + α * (j : ℝ)) := by
    push_cast
    field_simp
    ring
  simpa only [Prod.pow_fst, Prod.pow_snd, Pi.pow_apply,
    amoCoordinateState_pow_eq_root, hphase] using h

/-- Fixed-phase normalized finite Dirichlet moments converge; only the
explicit boundary error separates them from the bulk orbit means. -/
theorem tendsto_amoFiniteTrace_pow_fixed_phase {α : ℝ} (hα : Irrational α)
    (lam θ : ℝ) (k : ℕ) :
    Tendsto (fun n => amoFiniteTrace n ((amoFiniteOperator α lam θ (n + 1)) ^ k)) atTop
      (𝓝 (rootTrace ((hOperator α (lam : ℂ)) ^ k))) := by
  have herror : Tendsto (fun n =>
      amoFiniteTrace n ((amoFiniteOperator α lam θ (n + 1)) ^ k) -
        ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
          amoCoordinateState (i.val : ℤ) ((almostMathieuOperator α lam θ) ^ k))
      atTop (𝓝 0) := by
    apply tendsto_iff_norm_sub_tendsto_zero.mpr
    simp only [sub_zero]
    exact squeeze_zero (fun n => norm_nonneg _)
      (fun n => norm_amoFiniteTrace_pow_sub_bulk_le α lam θ n k)
      ((tendsto_add_atTop_iff_nat 1).2
        (tendsto_const_div_atTop_nhds_zero_nat (4 * (k : ℝ) * (2 + 2 * |lam|) ^ k)))
  simpa only [sub_add_cancel, zero_add] using
    herror.add (tendsto_amoCoordinateState_pow_mean hα lam θ k)

/-- Real polynomial tests converge without averaging the phase. -/
theorem tendsto_amoFiniteTrace_aeval_fixed_phase {α : ℝ} (hα : Irrational α)
    (lam θ : ℝ) (p : ℝ[X]) :
    Tendsto (fun n => amoFiniteTrace n
      (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p)) atTop
      (𝓝 (rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p))) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
    simp only [map_add]
    exact hp.add hq
  | monomial k c =>
    simp only [Polynomial.aeval_monomial, Algebra.algebraMap_eq_smul_one,
      smul_mul_assoc, one_mul, Complex.coe_smul, map_smul, smul_eq_mul]
    simp only [ContinuousLinearMap.map_smul_of_tower]
    exact (tendsto_amoFiniteTrace_pow_fixed_phase hα lam θ k).const_smul c

set_option maxHeartbeats 800000 in
set_option synthInstance.maxHeartbeats 80000 in
/-- Continuous normalized finite CFC traces converge at every fixed phase. -/
theorem tendsto_amoFiniteTrace_cfc_fixed_phase {α : ℝ} (hα : Irrational α)
    (lam θ : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Tendsto (fun n => amoFiniteTrace n
      (cfc f (amoFiniteOperator α lam θ (n + 1)))) atTop
      (𝓝 (rootTrace (cfc f (hOperator α (lam : ℂ))))) := by
  apply Metric.tendsto_nhds.mpr
  intro epsilon hepsilon
  have hepsilon3 : 0 < epsilon / 3 := by linarith
  let K : Set ℝ := Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|)
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K isCompact_Icc
    f hf.continuousOn (epsilon / 3) hepsilon3
  have hmag : ‖cfc f (hOperator α (lam : ℂ)) -
      Polynomial.aeval (hOperator α (lam : ℂ)) p‖ < epsilon / 3 := by
    apply norm_cfc_sub_polynomial_lt f K hf.continuousOn p (epsilon / 3) hepsilon3 hp
      _ (hOperator_isSelfAdjoint α lam)
    exact real_spectrum_subset_Icc_of_norm_le _ (by
      simpa only [Complex.norm_real, Real.norm_eq_abs] using hOperator_norm_le α (lam : ℂ))
  have hfinite (n : ℕ) :
      ‖cfc f (amoFiniteOperator α lam θ (n + 1)) -
        Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p‖ < epsilon / 3 := by
    apply norm_cfc_sub_polynomial_lt (A := AMOFiniteBoundedOperator (n + 1))
      f K hf.continuousOn p (epsilon / 3) hepsilon3 hp
      _ (amoFiniteOperator_isSelfAdjoint α lam θ (n + 1))
    exact real_spectrum_subset_Icc_of_norm_le _ (amoFiniteOperator_norm_le α lam θ (n + 1))
  have htrace (n : ℕ) :
      ‖amoFiniteTrace n (cfc f (amoFiniteOperator α lam θ (n + 1))) -
        amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p)‖ ≤
        epsilon / 3 := by
    rw [← map_sub]
    exact (norm_amoFiniteTrace_le n _).trans (hfinite n).le
  have hroot : ‖rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p) -
      rootTrace (cfc f (hOperator α (lam : ℂ)))‖ ≤ epsilon / 3 := by
    rw [norm_sub_rev, ← map_sub]
    exact (norm_rootTrace_le _).trans hmag.le
  filter_upwards [Metric.tendsto_nhds.mp
    (tendsto_amoFiniteTrace_aeval_fixed_phase hα lam θ p) (epsilon / 3) hepsilon3] with n hn
  rw [dist_eq_norm] at hn ⊢
  have htriangle := norm_sub_le_norm_sub_add_norm_sub
    (amoFiniteTrace n (cfc f (amoFiniteOperator α lam θ (n + 1))))
    (amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p))
    (rootTrace (cfc f (hOperator α (lam : ℂ))))
  have htriangle' := norm_sub_le_norm_sub_add_norm_sub
    (amoFiniteTrace n (Polynomial.aeval (amoFiniteOperator α lam θ (n + 1)) p))
    (rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p))
    (rootTrace (cfc f (hOperator α (lam : ℂ))))
  linarith [htrace n]

/-- At every fixed phase and irrational frequency, the literal empirical
Dirichlet eigenvalue probabilities converge on all continuous real tests to
the pre-existing magnetic spectral probability. -/
theorem tendsto_amoFiniteSpectralMeasure_fixed_phase {α : ℝ} (hα : Irrational α)
    (lam θ : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Tendsto (fun n => ∫ x, f x ∂amoFiniteSpectralMeasure α lam θ n) atTop
      (𝓝 (∫ x, f x ∂magneticRealSpectralMeasure α lam)) := by
  have htarget : (rootTrace (cfc f (hOperator α (lam : ℂ)))).re =
      ∫ x, f x ∂magneticRealSpectralMeasure α lam := by
    rw [magneticRealSpectralMeasure_integral_eq_phase_average α lam f hf]
    simp_rw [amoRealSpectralMeasure_integral_cfc α lam _ f hf]
    exact (integral_amoRootStateReal_cfc α lam f hf).symm
  simp_rw [amoFiniteSpectralMeasure_integral_cfc α lam θ _ f hf,
    amoFiniteTraceReal_apply]
  have h := Complex.continuous_re.continuousAt.tendsto.comp
    (tendsto_amoFiniteTrace_cfc_fixed_phase hα lam θ f hf)
  rwa [htarget] at h

end CriticalDTM

import DTM.Background.Support.CFCParameterContinuity
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
import Mathlib.MeasureTheory.Function.LocallyIntegrable

/-!
# Probability measures determined by their moments on a compact interval

A probability measure assigning mass one to a compact interval integrates every
continuous real function. Equality of all power moments therefore implies equality
of polynomial integrals. Uniform polynomial approximation then gives equality of
all bounded continuous tests, and Mathlib's finite-measure extensionality theorem
identifies the measures.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set
open scoped Polynomial

/-- Concentration on a compact interval makes every continuous real test integrable. -/
theorem integrable_continuous_of_probability_mass_Icc
    (μ : ProbabilityMeasure ℝ) (a b : ℝ)
    (hμ : (μ : Measure ℝ) (Icc a b) = 1)
    (f : ℝ → ℝ) (hf : Continuous f) : Integrable f (μ : Measure ℝ) := by
  have hae : ∀ᵐ x ∂(μ : Measure ℝ), x ∈ Icc a b :=
    (mem_ae_iff_prob_eq_one measurableSet_Icc).mpr hμ
  have hi : IntegrableOn f (Icc a b) (μ : Measure ℝ) :=
    ContinuousOn.integrableOn_compact isCompact_Icc hf.continuousOn
  simpa only [IntegrableOn, Measure.restrict_eq_self_of_ae_mem hae] using hi

/-- Probability measures concentrated on the same compact interval are equal if
all their power moments agree. No measure characterization is assumed. -/
theorem probabilityMeasure_eq_of_compact_moments
    (μ ν : ProbabilityMeasure ℝ) (a b : ℝ)
    (hμ : (μ : Measure ℝ) (Icc a b) = 1)
    (hν : (ν : Measure ℝ) (Icc a b) = 1)
    (hmom : ∀ k : ℕ,
      ∫ x : ℝ, x ^ k ∂(μ : Measure ℝ) = ∫ x : ℝ, x ^ k ∂(ν : Measure ℝ)) :
    μ = ν := by
  have hμae : ∀ᵐ x ∂(μ : Measure ℝ), x ∈ Icc a b :=
    (mem_ae_iff_prob_eq_one measurableSet_Icc).mpr hμ
  have hνae : ∀ᵐ x ∂(ν : Measure ℝ), x ∈ Icc a b :=
    (mem_ae_iff_prob_eq_one measurableSet_Icc).mpr hν
  have hpoly (p : ℝ[X]) :
      ∫ x, p.eval x ∂(μ : Measure ℝ) = ∫ x, p.eval x ∂(ν : Measure ℝ) := by
    induction p using Polynomial.induction_on' with
    | add p q hp hq =>
      simp only [Polynomial.eval_add]
      rw [integral_add
        (integrable_continuous_of_probability_mass_Icc μ a b hμ _ p.continuous)
        (integrable_continuous_of_probability_mass_Icc μ a b hμ _ q.continuous),
        integral_add
        (integrable_continuous_of_probability_mass_Icc ν a b hν _ p.continuous)
        (integrable_continuous_of_probability_mass_Icc ν a b hν _ q.continuous), hp, hq]
    | monomial k c =>
      simp only [Polynomial.eval_monomial, integral_const_mul, hmom]
  apply ProbabilityMeasure.toMeasure_injective
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  apply sub_eq_zero.mp
  apply norm_eq_zero.mp
  apply le_antisymm _ (norm_nonneg _)
  apply le_of_forall_pos_le_add
  intro epsilon hepsilon
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation (Icc a b) isCompact_Icc
    f f.continuous.continuousOn (epsilon / 2) (by linarith)
  have hμbound :
      ‖(∫ x, f x ∂(μ : Measure ℝ)) - ∫ x, p.eval x ∂(μ : Measure ℝ)‖ ≤ epsilon / 2 := by
    rw [← integral_sub
      (integrable_continuous_of_probability_mass_Icc μ a b hμ _ f.continuous)
      (integrable_continuous_of_probability_mass_Icc μ a b hμ _ p.continuous)]
    have h := norm_integral_le_of_norm_le_const (μ := (μ : Measure ℝ))
      (hμae.mono (fun x hx => (hp x hx).le))
    simpa using h
  have hνbound :
      ‖(∫ x, f x ∂(ν : Measure ℝ)) - ∫ x, p.eval x ∂(ν : Measure ℝ)‖ ≤ epsilon / 2 := by
    rw [← integral_sub
      (integrable_continuous_of_probability_mass_Icc ν a b hν _ f.continuous)
      (integrable_continuous_of_probability_mass_Icc ν a b hν _ p.continuous)]
    have h := norm_integral_le_of_norm_le_const (μ := (ν : Measure ℝ))
      (hνae.mono (fun x hx => (hp x hx).le))
    simpa using h
  calc
    _ ≤ ‖(∫ x, f x ∂(μ : Measure ℝ)) - ∫ x, p.eval x ∂(μ : Measure ℝ)‖ +
        ‖(∫ x, p.eval x ∂(μ : Measure ℝ)) - ∫ x, f x ∂(ν : Measure ℝ)‖ :=
      norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ = ‖(∫ x, f x ∂(μ : Measure ℝ)) - ∫ x, p.eval x ∂(μ : Measure ℝ)‖ +
        ‖(∫ x, f x ∂(ν : Measure ℝ)) - ∫ x, p.eval x ∂(ν : Measure ℝ)‖ := by
      rw [hpoly p, norm_sub_rev (∫ x, p.eval x ∂(ν : Measure ℝ))]
    _ ≤ epsilon / 2 + epsilon / 2 := add_le_add hμbound hνbound
    _ = 0 + epsilon := by linarith

end CriticalDTM

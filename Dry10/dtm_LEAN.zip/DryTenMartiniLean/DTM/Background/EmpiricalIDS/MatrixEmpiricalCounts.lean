import Mathlib.Algebra.Polynomial.Roots
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.LinearAlgebra.Matrix.Spectrum
import Mathlib.Probability.Distributions.Uniform

/-!
# Hermitian eigenvalue counts from characteristic-polynomial roots

The roots of a Hermitian matrix's characteristic polynomial are precisely Mathlib's
real eigenvalues, with algebraic multiplicity. Consequently an empirical count can
be written directly using the matrix and its characteristic polynomial, without
putting a choice of eigenvalues or a proof of Hermiticity into the count's definition.

For a nonempty multiset, Mathlib's `PMF.ofMultiset` gives the corresponding empirical
probability distribution. Its measure of a measurable set is the normalized count
of multiset entries in that set.

The matrix index type may be empty; the probability interpretation requires a
nonempty multiset. No project-specific definitions are used.
-/

open Polynomial
open scoped BigOperators ENNReal

namespace Matrix.IsHermitian

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {M : Matrix ι ι ℂ}
variable (hM : M.IsHermitian)

include hM

/-- Unitary diagonalization factors the characteristic polynomial into one linear
factor for each eigenvector, so repeated eigenvalues retain their multiplicity. -/
theorem charpoly_eq_prod_eigenvalues :
    M.charpoly = ∏ i, (X - C (hM.eigenvalues i : ℂ)) := by
  classical
  let U : Matrix ι ι ℂ := hM.eigenvectorUnitary
  let D : Matrix ι ι ℂ := diagonal (fun i => (hM.eigenvalues i : ℂ))
  let f : Matrix ι ι ℂ →+* Matrix ι ι (Polynomial ℂ) := Polynomial.C.mapMatrix
  have hU : U * star U = 1 := by simp [U]
  have hM' : M = U * D * star U := hM.spectral_theorem
  have hc : charmatrix M = f U * charmatrix D * f (star U) := by
    simp only [charmatrix, scalar_apply, ← smul_one_eq_diagonal]
    change X • 1 - f M = f U * (X • 1 - f D) * f (star U)
    simp only [mul_sub, sub_mul, Matrix.mul_smul, Matrix.smul_mul, mul_one,
      ← map_mul, hU, ← hM', map_one]
  rw [charpoly, hc, det_mul_right_comm, ← map_mul, hU, map_one, one_mul]
  simp [charmatrix, RingHom.mapMatrix_apply, diagonal_map C_0, scalar_apply,
    diagonal_sub, D]

/-- Characteristic-polynomial roots are the full eigenvalue multiset, not merely
the set of distinct eigenvalues. -/
theorem charpoly_roots_eq :
    M.charpoly.roots = Finset.univ.val.map (fun i => (hM.eigenvalues i : ℂ)) := by
  rw [hM.charpoly_eq_prod_eigenvalues, roots_prod]
  · simp only [roots_X_sub_C, Multiset.bind_singleton]
  · exact Finset.prod_ne_zero_iff.mpr fun i _ => X_sub_C_ne_zero _

open scoped Classical in
/-- Counting characteristic-polynomial roots below an energy counts eigenvalue
indices below that energy, retaining all multiplicities. -/
theorem charpoly_roots_countP_lt (E : ℝ) :
    M.charpoly.roots.countP (fun z => z.re < E) =
      (Finset.univ.filter (fun i => hM.eigenvalues i < E)).card := by
  rw [hM.charpoly_roots_eq, Multiset.countP_map]
  simp only [Complex.ofReal_re, Finset.card_def, Finset.filter_val]

end Matrix.IsHermitian

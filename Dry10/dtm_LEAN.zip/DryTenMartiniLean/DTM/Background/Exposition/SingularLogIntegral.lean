import DTM.Background.Potential.AMOLyapunovPotential

/-!
# Integrability of the actual singular real logarithm

The decreasing regularized integrals have a finite lower bound. Monotone
convergence for the nonnegative deficits gives an integrable almost-everywhere
limit, excludes an atom at the logarithmic singularity, and identifies the
intrinsic potential with the ordinary spectral integral.
-/

noncomputable section
namespace CriticalDTM
open MeasureTheory Set Filter
open scoped Topology ENNReal

/-- An antitone integrable sequence with nonnegative integrals has an
integrable finite limit almost everywhere. This is the real-valued form of
monotone convergence applied to `f 0 - f n`. -/
theorem exists_integrable_antitone_limit_of_nonneg_integrals
    {X : Type*} [MeasurableSpace X] (μ : Measure X) (f : ℕ → X → ℝ)
    (hm : ∀ n, Measurable (f n)) (hi : ∀ n, Integrable (f n) μ)
    (hanti : ∀ x, Antitone (fun n => f n x))
    (hpos : ∀ n, 0 ≤ ∫ x, f n x ∂μ) :
    ∃ F : X → ℝ, Integrable F μ ∧
      ∀ᵐ x ∂μ, Tendsto (fun n => f n x) atTop (𝓝 (F x)) := by
  let g : ℕ → X → ℝ := fun n x => f 0 x - f n x
  have hg0 (n : ℕ) (x : X) : 0 ≤ g n x := sub_nonneg.mpr (hanti x (Nat.zero_le n))
  have hgmono (x : X) : Monotone (fun n => g n x) :=
    fun n m hnm => sub_le_sub_left (hanti x hnm) _
  have hgm (n : ℕ) : Measurable (fun x => ENNReal.ofReal (g n x)) :=
    ((hm 0).sub (hm n)).ennreal_ofReal
  let G : X → ℝ≥0∞ := fun x => ⨆ n, ENNReal.ofReal (g n x)
  have hGm : Measurable G := Measurable.iSup hgm
  have hbound : ∫⁻ x, G x ∂μ ≤ ENNReal.ofReal (∫ x, f 0 x ∂μ) := by
    rw [show (∫⁻ x, G x ∂μ) = ⨆ n, ∫⁻ x, ENNReal.ofReal (g n x) ∂μ from
      lintegral_iSup hgm (fun n m hnm x => ENNReal.ofReal_le_ofReal (hgmono x hnm))]
    apply iSup_le
    intro n
    have hc := ofReal_integral_eq_lintegral_ofReal
      (show Integrable (fun x => g n x) μ from (hi 0).sub (hi n))
      (Eventually.of_forall (hg0 n))
    rw [← hc]
    dsimp only [g]
    rw [integral_sub (hi 0) (hi n)]
    exact ENNReal.ofReal_le_ofReal (sub_le_self _ (hpos n))
  have hGfinite : (∫⁻ x, G x ∂μ) ≠ ⊤ :=
    ne_top_of_le_ne_top ENNReal.ofReal_ne_top hbound
  have hGi : Integrable (fun x => (G x).toReal) μ :=
    integrable_toReal_of_lintegral_ne_top hGm.aemeasurable hGfinite
  refine ⟨fun x => f 0 x - (G x).toReal, (hi 0).sub hGi, ?_⟩
  filter_upwards [ae_lt_top hGm hGfinite] with x hx
  have hgLim : Tendsto (fun n => ENNReal.ofReal (g n x)) atTop (𝓝 (G x)) :=
    tendsto_atTop_iSup (fun n m hnm => ENNReal.ofReal_le_ofReal (hgmono x hnm))
  have hreal := (ENNReal.continuousAt_toReal hx.ne).tendsto.comp hgLim
  simp only [Function.comp_def, ENNReal.toReal_ofReal (hg0 _ _)] at hreal
  have hsub : Tendsto (fun n => f 0 x - g n x) atTop
      (𝓝 (f 0 x - (G x).toReal)) := tendsto_const_nhds.sub hreal
  simpa [g] using hsub

/-- Nonnegativity of the intrinsic potential bounds every regularized
spectral integral from below. -/
theorem magneticRegularizedLogPotential_nonneg (α lam E : ℝ) (n : ℕ) :
    0 ≤ magneticRegularizedLogPotential α n (lam, E) := by
  apply EReal.coe_le_coe_iff.mp
  exact (magneticTotalLogPotential_nonneg α lam E).trans
    (iInf_le (fun n => (magneticRegularizedLogPotential α n (lam, E) : EReal)) n)

/-- The singular real logarithm is integrable on the actual compact spectrum,
and its singular point has zero measure. No resolvent premise is imposed. -/
theorem magnetic_logKernel_integrable_and_ae_ne (α lam E : ℝ) :
    Integrable (fun x : MagneticRealSpectrum α lam => Real.log |E - (x : ℝ)|)
      (magneticSpectralMeasure α lam) ∧
    ∀ᵐ (x : MagneticRealSpectrum α lam) ∂magneticSpectralMeasure α lam, (x : ℝ) ≠ E := by
  let f : ℕ → MagneticRealSpectrum α lam → ℝ :=
    fun n x => regularizedLogKernel n (E - (x : ℝ))
  have hcont (n : ℕ) : Continuous (f n) :=
    (regularizedLogKernel_continuous n).comp
      (continuous_const.sub continuous_subtype_val)
  obtain ⟨F, hFi, hFlim⟩ := exists_integrable_antitone_limit_of_nonneg_integrals
    (magneticSpectralMeasure α lam) f (fun n => (hcont n).measurable)
    (fun n => magnetic_regularizedLogKernel_integrable α lam E n)
    (fun x => regularizedLogKernel_antitone (E - (x : ℝ)))
    (fun n => by
      rw [← magneticRegularizedLogPotential_eq_spectralIntegral]
      exact magneticRegularizedLogPotential_nonneg α lam E n)
  have hscale : Tendsto logRegularizationScale atTop (𝓝[>] (0 : ℝ)) :=
    tendsto_nhdsWithin_iff.mpr ⟨logRegularizationScale_tendsto,
      Eventually.of_forall (fun n => logRegularizationScale_pos n)⟩
  have hlogbot := Real.tendsto_log_nhdsGT_zero.comp hscale
  have hne : ∀ᵐ (x : MagneticRealSpectrum α lam) ∂magneticSpectralMeasure α lam, (x : ℝ) ≠ E := by
    filter_upwards [hFlim] with x hx hxe
    have hx' : Tendsto (fun n => Real.log (logRegularizationScale n)) atTop (𝓝 (F x)) := by
      simpa [f, regularizedLogKernel, hxe] using hx
    exact not_tendsto_nhds_of_tendsto_atBot hlogbot (F x) hx'
  have heq : F =ᵐ[magneticSpectralMeasure α lam]
      (fun x : MagneticRealSpectrum α lam => Real.log |E - (x : ℝ)|) := by
    filter_upwards [hFlim, hne] with x hx hxe
    have hlim : Tendsto (fun n => f n x) atTop (𝓝 (Real.log |E - (x : ℝ)|)) := by
      have h0 : Tendsto (fun n => |E - (x : ℝ)| + logRegularizationScale n) atTop
          (𝓝 |E - (x : ℝ)|) := by simpa using tendsto_const_nhds.add logRegularizationScale_tendsto
      have h := h0.log (abs_ne_zero.mpr (sub_ne_zero.mpr hxe.symm))
      simpa [f, regularizedLogKernel] using h
    exact tendsto_nhds_unique hx hlim
  exact ⟨(integrable_congr heq).mp hFi, hne⟩

/-- The additive regularized integrals converge to the ordinary singular
logarithmic integral, after its integrability and atom exclusion are proved. -/
theorem magneticRegularizedLogPotential_tendsto_singularIntegral (α lam E : ℝ) :
    Tendsto (fun n => magneticRegularizedLogPotential α n (lam, E)) atTop
      (𝓝 (∫ x : MagneticRealSpectrum α lam, Real.log |E - (x : ℝ)|
        ∂magneticSpectralMeasure α lam)) := by
  obtain ⟨hlogi, hne⟩ := magnetic_logKernel_integrable_and_ae_ne α lam E
  have hlim := integral_tendsto_of_tendsto_of_antitone
    (fun n => magnetic_regularizedLogKernel_integrable α lam E n) hlogi
    (Eventually.of_forall (fun x => regularizedLogKernel_antitone (E - (x : ℝ))))
    (show ∀ᵐ (x : MagneticRealSpectrum α lam) ∂magneticSpectralMeasure α lam,
      Tendsto (fun n => regularizedLogKernel n (E - (x : ℝ))) atTop
        (𝓝 (Real.log |E - (x : ℝ)|)) from by
      filter_upwards [hne] with x hx
      have h0 : Tendsto (fun n => |E - (x : ℝ)| + logRegularizationScale n) atTop
          (𝓝 |E - (x : ℝ)|) := by simpa using tendsto_const_nhds.add logRegularizationScale_tendsto
      have h := h0.log (abs_ne_zero.mpr (sub_ne_zero.mpr hx.symm))
      simpa [regularizedLogKernel] using h)
  simpa only [← magneticRegularizedLogPotential_eq_spectralIntegral] using hlim

/-- At every real energy, including the spectrum, the intrinsic global
potential is the finite ordinary logarithmic spectral integral. -/
theorem magneticTotalLogPotential_eq_singularIntegral (α lam E : ℝ) :
    magneticTotalLogPotential α (lam, E) =
      (↑(∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) : EReal) := by
  rw [magneticRealSpectralMeasure_integral_eq_subtype]
  apply iInf_eq_of_tendsto
  · intro n m hnm
    exact EReal.coe_le_coe_iff.mpr
      (magneticRegularizedLogPotential_antitone α (lam, E) hnm)
  · exact continuous_coe_real_ereal.continuousAt.tendsto.comp
      (magneticRegularizedLogPotential_tendsto_singularIntegral α lam E)

/-- Integrability on the physical real-line density-of-states measure. -/
theorem magnetic_realLogKernel_integrable (α lam E : ℝ) :
    Integrable (fun x : ℝ => Real.log |E - x|) (magneticRealSpectralMeasure α lam) := by
  have hm : Measurable (fun x : ℝ => Real.log |E - x|) :=
    (show Continuous (fun x : ℝ => |E - x|) from
      (continuous_const.sub continuous_id).abs).measurable.log
  unfold magneticRealSpectralMeasure
  exact (integrable_map_measure hm.aestronglyMeasurable
    continuous_subtype_val.measurable.aemeasurable).mpr
      (magnetic_logKernel_integrable_and_ae_ne α lam E).1

/-- The actual density-of-states measure has no atoms at any real energy.
This is derived from the finite logarithmic potential, without a resolvent
or irrational-frequency hypothesis. -/
theorem magneticRealSpectralMeasure_singleton_eq_zero (α lam E : ℝ) :
    magneticRealSpectralMeasure α lam {E} = 0 := by
  rw [magneticRealSpectralMeasure,
    Measure.map_apply continuous_subtype_val.measurable (measurableSet_singleton E)]
  have hne := (magnetic_logKernel_integrable_and_ae_ne α lam E).2
  have hzero := ae_iff.mp hne
  simpa only [ne_eq, not_not, Set.preimage, Set.mem_singleton_iff] using hzero

end CriticalDTM

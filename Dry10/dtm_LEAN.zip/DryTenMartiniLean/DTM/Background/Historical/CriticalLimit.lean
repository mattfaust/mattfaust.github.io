import Mathlib.Topology.Semicontinuous
import Mathlib.Topology.Sequences
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Tactic

/-!
# The terminal critical-limit argument

This file proves the real-analysis part of the manuscript's passage to critical
coupling.  The function `L` and the critical spectral set are explicit parameters:
the file does not identify them with the almost Mathieu Lyapunov exponent or
spectrum.  Their upper semicontinuity and spectral vanishing remain hypotheses.
The existence, label, and continuation of a particular gap remain outside this
module.
-/

open Filter Set
open scoped Topology

namespace CriticalDTM

/-- A fixed lower bound along a convergent sequence survives at an upper
semicontinuous limit.  No continuity or limit of the function values is assumed. -/
theorem lower_bound_at_upperSemicontinuous_limit
    {X : Type*} [TopologicalSpace X]
    {f : X → ℝ} {u : ℕ → X} {x : X} {c : ℝ}
    (hf : UpperSemicontinuousAt f x)
    (hu : Tendsto u atTop (𝓝 x))
    (hc : ∀ᶠ n in atTop, c ≤ f (u n)) :
    c ≤ f x := by
  by_contra h
  have hx : f x < c := lt_of_not_ge h
  have he : ∀ᶠ n in atTop, f (u n) < c := hu.eventually (hf c hx)
  obtain ⟨n, hn, hn'⟩ := (he.and hc).exists
  exact (not_lt_of_ge hn') hn

end CriticalDTM

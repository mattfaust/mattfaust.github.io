import DTM.Background.Historical.MagneticCriticalReduction

/-!
# Gluing the locally constructed Green zeros into a labelled branch

Pointwise labelled gaps and the explicit height-function inputs give positive
stationary maxima. Local constancy of the label and uniqueness of its gap
force the actual implicit-function branches to agree with a pointwise choice
of these maxima. Differentiability and continuity of the slope are proved,
rather than imposed on that choice.

The two label interfaces below are explicit temporary application interfaces;
they are not definitions of an IDS and are not invoked as axioms.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

/-- The label is locally constant in both real parameters at every point of
the actual joint resolvent domain. -/
def JointResolventLabelLocallyConstant (α : ℝ) (N : ℝ × ℝ → ℝ) : Prop :=
  ∀ p ∈ realJointResolventDomain α, ∀ᶠ q in 𝓝 p, N q = N p

/-- A real resolvent energy with the same label as an interior point of a
bounded gap belongs to that same gap. This is the precise gap-uniqueness
interface needed for gluing. -/
def LabelDeterminesMagneticGap (α : ℝ) (N : ℝ × ℝ → ℝ) : Prop :=
  ∀ t ∈ Ioo (0 : ℝ) 1, ∀ a b : ℝ,
    IsSpectralGap (magneticRealSpectrumSet α t) a b →
      ∀ x ∈ Ioo a b, ∀ y : ℝ,
        (y : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) →
          N (t, y) = N (t, x) → y ∈ Ioo a b

/-- A labelled stationary point always includes actual resolvent membership. -/
def IsLabelledMagneticStationaryPoint
    (α : ℝ) (N : ℝ × ℝ → ℝ) (label t E : ℝ) : Prop :=
  (E : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) ∧
    projectedGreen (hOperator α (t : ℂ)) hilbertRoot (E : ℂ) = 0 ∧
    N (t, E) = label

end CriticalDTM

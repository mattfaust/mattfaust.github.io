import DTM.NewResults.Calculus.MagneticPotential
import DTM.NewResults.Continuation.BranchRegularity
import DTM.Background.Historical.CriticalLimit

/-!
# Conditional critical gap opening with the local magnetic calculus discharged

The spectrum and trace-log potential here are the actual constructed
magnetic objects. The height monotonicity and energy bound are conclusions
of the checked operator/calculus modules, not assumptions.

The remaining inputs are explicit: a globally stationary C¹ branch in
bounded subcritical spectral gaps, its fixed label, a positive seed, a
function L agreeing with the actual trace-log potential on that branch,
the required semicontinuity and spectral vanishing of L, and the stated
continuity/local constancy/exterior-value properties of N. This theorem
does not rename either L or N as the AMO Lyapunov exponent or empirical IDS.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

/-- The real spectral set of the actual bounded magnetic Hamiltonian. -/
def magneticRealSpectrumSet (α lam : ℝ) : Set ℝ :=
  {E | (E : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ))}

theorem magneticRealSpectrumSet_isClosed (α lam : ℝ) :
    IsClosed (magneticRealSpectrumSet α lam) :=
  (spectrum.isClosed (𝕜 := ℂ) (hOperator α (lam : ℂ))).preimage
    Complex.ofRealCLM.continuous

end CriticalDTM

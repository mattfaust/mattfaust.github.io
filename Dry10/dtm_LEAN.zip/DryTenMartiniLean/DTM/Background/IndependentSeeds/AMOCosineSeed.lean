import DTM.Background.IndependentSeeds.FiniteSeedCenter
import DTM.Background.IndependentSeeds.FiniteSeedSynthesisLimits
import DTM.Background.IndependentSeeds.AMOFiniteSeedResiduals
import DTM.Background.IndependentSeeds.AMOResonantFrame
import DTM.Background.IndependentSeeds.AMOFrequencyReflection
import DTM.Background.IndependentSeeds.AMOSmallSeedCriterion

/-!
# Small-coupling cosine seeds from actual finite resonant vectors

The finite box has sites `[-q,2q]`, with `q=k+1`. Its two exact determinant
columns retain boundary sources of order `lam^(q+1)`, while the resonant
coupling is `lam^q / middleDet`. The continuous exact finite center and the
uniform Fourier limits discharge all inputs to the actual transfer-growth
criterion. No noncritical DTM or initially open gap is assumed.

For manuscript Theorem 3.7, the external input is [19]
Helffer--Kerdelhué--Sjöstrand, Le papillon de Hofstadter revisité (1990),
Théorème 2.2 and Proposition 2.5. The theorem
`amo_arbitrarily_small_labelled_seeds` proves the required conclusion:
for each nonzero label and each positive coupling bound, there is an open
labelled gap at some positive coupling below that bound. This finite-resonance
construction is a replacement proof of that seed conclusion; it does not
claim to formalize the full argument of the cited results.
-/

noncomputable section
namespace CriticalDTM

open Set Filter
open scoped Topology BoundedContinuousFunction

private theorem seedPhase_of_integer_resonance {α κ : ℝ} {n ℓ : ℤ}
    (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ)) :
    seedPhase ((n : ℝ) * (2 * Real.pi * α)) = (seedPhase κ)⁻¹ ^ 2 := by
  have hangle : -2 * Real.pi * α * (n : ℝ) = -((n : ℝ) * (2 * Real.pi * α)) := by ring
  have h : seedPhase (2 * κ) = seedPhase (-((n : ℝ) * (2 * Real.pi * α))) := by
    simpa only [seedPhase, hangle] using cosine_phase_resonance_exp_twice hres
  have hneg (x : ℝ) : seedPhase (-x) = (seedPhase x)⁻¹ := by
    simp [seedPhase, Complex.ofReal_neg, neg_mul, Complex.exp_neg]
  rw [two_mul, seedPhase_add, hneg] at h
  have hinv := congrArg Inv.inv h
  simpa only [_root_.mul_inv_rev, inv_inv, ← pow_two, inv_pow] using hinv.symm

/-- A genuine positive-exponent curve at each finite positive-order resonance.
The small interval is constructed and may depend on both frequency and order. -/
theorem amo_positive_lyapunov_curve_at_finite_resonance
    {α κ : ℝ} (hα : Irrational α) (hκ0 : 0 < κ) (hκpi : κ < Real.pi)
    (k : ℕ) {ℓ : ℤ}
    (hres : κ + Real.pi * α * (((k : ℤ) + 1 : ℤ) : ℝ) = Real.pi * (ℓ : ℝ)) :
    ∃ ε : ℝ, 0 < ε ∧ ε ≤ 1 ∧ ∃ e : ℝ → ℝ,
      ContinuousOn e (Ioo (0 : ℝ) ε) ∧
      Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (2 * Real.cos κ)) ∧
      ∀ lam ∈ Ioo (0 : ℝ) ε, 0 < amoLyapunov α lam (e lam : ℂ) := by
  let d : ℤ → ℝ := fun j => 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ))
  have hd0 : d 0 = 2 * Real.cos κ := by simp [d]
  obtain ⟨ε, hε, e, he0, _, hecont0, hecont, hcenter⟩ :=
    exists_cosine_seed_finite_center hα k hres
  change e 0 = 2 * Real.cos κ at he0
  change ∀ lam ∈ Ioo (-ε) ε,
    seedLeftDet d k lam (e lam) ≠ 0 ∧ seedMiddleDet d k lam (e lam) ≠ 0 ∧
      (e lam - d 0) * (seedLeftDet d k lam (e lam) * seedMiddleDet d k lam (e lam)) =
        lam ^ 2 * (seedLeftTailDet d k lam (e lam) * seedMiddleDet d k lam (e lam) +
          seedMiddleTailDet d k lam (e lam) * seedLeftDet d k lam (e lam)) at hcenter
  have h0 : (0 : ℝ) ∈ Ioo (-ε) ε := ⟨by linarith, hε⟩
  have hL0 : seedLeftDet d k 0 (d 0) ≠ 0 := by
    simpa only [he0, hd0] using (hcenter 0 h0).1
  have hM0 : seedMiddleDet d k 0 (d 0) ≠ 0 := by
    simpa only [he0, hd0] using (hcenter 0 h0).2.1
  have hlam : Tendsto (fun lam : ℝ => lam) (𝓝[>] (0 : ℝ)) (𝓝 0) :=
    tendsto_id'.mpr nhdsWithin_le_nhds
  have he : Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (d 0)) := by
    simpa only [he0, hd0] using hecont0.tendsto.mono_left nhdsWithin_le_nhds
  have hF := seedFiniteVector_synthesis_tendsto_one d k hlam he hL0 hM0
  have hG := seedReflectedFiniteVector_synthesis_tendsto_mode d k hlam he hL0 hM0
  have hcoeff := seed_normalized_coefficients_tendsto d k hlam he hL0 hM0
  have hu : Tendsto (fun lam : ℝ => lam ^ (k + 1)) (𝓝[>] (0 : ℝ)) (𝓝 0) := by
    simpa only [zero_pow (Nat.succ_ne_zero k)] using hlam.pow (k + 1)
  have hupos : ∀ᶠ lam : ℝ in 𝓝[>] (0 : ℝ), 0 < lam ^ (k + 1) := by
    filter_upwards [eventually_mem_nhdsWithin] with lam hlam
    exact pow_pos hlam _
  have hwindow₀ : ∀ᶠ lam : ℝ in 𝓝 0, lam ∈ Ioo (-ε) ε := Ioo_mem_nhds (by linarith) hε
  have hwindow : ∀ᶠ lam : ℝ in 𝓝[>] (0 : ℝ), lam ∈ Ioo (-ε) ε :=
    hwindow₀.filter_mono nhdsWithin_le_nhds
  have hreflect : ∀ j : ℤ, d ((k : ℤ) + 1 - j) = d j :=
    cosine_phase_resonance_reflection hres
  have hRF : ∀ᶠ lam : ℝ in 𝓝[>] (0 : ℝ), ∀ θ : ℝ,
      seedPhase κ * seedRealFourierSynthesis (seedFiniteVector d k lam (e lam))
          (θ + 2 * Real.pi * α) +
        seedPhase (-κ) * seedRealFourierSynthesis (seedFiniteVector d k lam (e lam))
          (θ - 2 * Real.pi * α) +
        ((2 * lam * Real.cos θ : ℝ) : ℂ) *
          seedRealFourierSynthesis (seedFiniteVector d k lam (e lam)) θ -
        (e lam : ℂ) * seedRealFourierSynthesis (seedFiniteVector d k lam (e lam)) θ =
      ((lam ^ (k + 1) : ℝ) : ℂ) *
        (((seedMiddleDet d k lam (e lam))⁻¹ : ℝ) * seedFourierMode ((k : ℤ) + 1) θ +
          ((lam / seedLeftDet d k lam (e lam) : ℝ) : ℂ) *
            seedFourierMode (-((k : ℤ) + 1) - 1) θ) := by
    filter_upwards [hwindow] with lam hlam
    obtain ⟨hL, hM, hc⟩ := hcenter lam hlam
    intro θ
    exact seedFiniteVector_fourier_residual α κ lam (e lam) d k (fun _ => rfl) hL hM
      (by simpa only [mul_assoc] using hc) θ
  have hRG : ∀ᶠ lam : ℝ in 𝓝[>] (0 : ℝ), ∀ θ : ℝ,
      seedPhase κ * seedRealFourierSynthesis (seedReflectedFiniteVector d k lam (e lam))
          (θ + 2 * Real.pi * α) +
        seedPhase (-κ) * seedRealFourierSynthesis (seedReflectedFiniteVector d k lam (e lam))
          (θ - 2 * Real.pi * α) +
        ((2 * lam * Real.cos θ : ℝ) : ℂ) *
          seedRealFourierSynthesis (seedReflectedFiniteVector d k lam (e lam)) θ -
        (e lam : ℂ) * seedRealFourierSynthesis (seedReflectedFiniteVector d k lam (e lam)) θ =
      ((lam ^ (k + 1) : ℝ) : ℂ) *
        (((seedMiddleDet d k lam (e lam))⁻¹ : ℝ) +
          ((lam / seedLeftDet d k lam (e lam) : ℝ) : ℂ) *
            seedFourierMode (2 * ((k : ℤ) + 1) + 1) θ) := by
    filter_upwards [hwindow] with lam hlam
    obtain ⟨hL, hM, hc⟩ := hcenter lam hlam
    intro θ
    exact seedReflectedFiniteVector_fourier_residual α κ lam (e lam) d k (fun _ => rfl)
      hreflect hL hM (by simpa only [mul_assoc] using hc) θ
  have hpos : ∀ᶠ lam : ℝ in 𝓝[>] (0 : ℝ), 0 < amoLyapunov α lam (e lam : ℂ) :=
    eventually_amoLyapunov_pos_of_resonant_fourier_residuals hκ0 hκpi
      (seedPhase_of_integer_resonance hres) hu hupos hcoeff.1 (inv_ne_zero hM0)
      hcoeff.2 hF hG hRF hRG
  obtain ⟨η, hη, hposball⟩ := Metric.eventually_nhds_iff.mp
    (eventually_nhdsWithin_iff.mp hpos)
  let δ : ℝ := min ε (min η 1)
  have hδ : 0 < δ := lt_min hε (lt_min hη zero_lt_one)
  have hδε : δ ≤ ε := min_le_left _ _
  have hδη : δ ≤ η := (min_le_right _ _).trans (min_le_left _ _)
  have hδ1 : δ ≤ 1 := (min_le_right _ _).trans (min_le_right _ _)
  refine ⟨δ, hδ, hδ1, e, ?_, ?_, ?_⟩
  · apply hecont.mono
    intro lam hlam
    exact ⟨(by linarith [hlam.1]), hlam.2.trans_le hδε⟩
  · simpa only [hd0] using he
  · intro lam hlam
    apply hposball (show dist lam 0 < η from ?_) hlam.1
    simpa only [Real.dist_eq, sub_zero, abs_of_pos hlam.1] using hlam.2.trans_le hδη

/-- Both signs of every integer label are covered. Negative labels use the
positive-order finite construction at the reflected frequency; the actual
transfer exponent is unchanged by that reflection. -/
theorem amo_positive_lyapunov_principal_curve {α : ℝ} (hα : Irrational α)
    {n : ℤ} (hn : n ≠ 0) :
    ∃ ε : ℝ, 0 < ε ∧ ε ≤ 1 ∧ ∃ e : ℝ → ℝ,
      ContinuousOn e (Ioo (0 : ℝ) ε) ∧
      Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (2 * Real.cos (amoPrincipalKappa α n))) ∧
      ∀ lam ∈ Ioo (0 : ℝ) ε, 0 < amoLyapunov α lam (e lam : ℂ) := by
  let κ : ℝ := amoPrincipalKappa α n
  have hκ0 : 0 < κ := amoPrincipalKappa_pos hα hn
  have hκpi : κ < Real.pi := amoPrincipalKappa_lt_pi hα hn
  by_cases hnpos : 0 < n
  · let k : ℕ := n.toNat - 1
    have hk : (k : ℤ) + 1 = n := by dsimp [k]; omega
    have hres : κ + Real.pi * α * (((k : ℤ) + 1 : ℤ) : ℝ) =
        Real.pi * ((Int.floor ((n : ℝ) * α) + 1 : ℤ) : ℝ) := by
      rw [hk]
      exact amoPrincipalKappa_resonance α n
    exact amo_positive_lyapunov_curve_at_finite_resonance hα hκ0 hκpi k hres
  · have hnneg : n < 0 := by omega
    let k : ℕ := (-n).toNat - 1
    have hk : (k : ℤ) + 1 = -n := by dsimp [k]; omega
    have hres : κ + Real.pi * (-α) * (((k : ℤ) + 1 : ℤ) : ℝ) =
        Real.pi * ((Int.floor ((n : ℝ) * α) + 1 : ℤ) : ℝ) := by
      calc
        _ = κ + Real.pi * α * (n : ℝ) := by rw [hk]; push_cast; ring
        _ = _ := amoPrincipalKappa_resonance α n
    obtain ⟨ε, hε0, hε1, e, hcont, hlim, hpos⟩ :=
      amo_positive_lyapunov_curve_at_finite_resonance hα.neg hκ0 hκpi k hres
    refine ⟨ε, hε0, hε1, e, hcont, hlim, ?_⟩
    intro lam hlam
    simpa only [amoLyapunov_neg_frequency] using hpos lam hlam

/-- Manuscript Theorem 3.7: for each nonzero label, positive seed couplings
exist below every positive bound. The actual spectral endpoints and IDS label
are included in the conclusion. This proves the seed input attributed to
Helffer--Kerdelhué--Sjöstrand [19], Théorème 2.2 and Proposition 2.5, using
finite resonant vectors rather than assuming a gap-opening theorem. -/
theorem amo_arbitrarily_small_labelled_seeds {α : ℝ} (hα : Irrational α) :
    ∀ n : ℤ, n ≠ 0 → ∀ δ : ℝ, 0 < δ →
      ∃ s : ℝ, 0 < s ∧ s < δ ∧ ∃ θ a b : ℝ,
        IsLabelledSpectralGap (almostMathieuRealSpectrumSet α s θ)
          (almostMathieuIDS α s) (arithmeticGapLabel α n) a b := by
  intro n hn δ hδ
  obtain ⟨ε, hε0, hε1, e, hcont, hlim, hpos⟩ :=
    amo_positive_lyapunov_principal_curve hα hn
  obtain ⟨s, hs0, hsδ, hgap⟩ :=
    amo_small_seeds_of_positive_lyapunov_curve hα hn hε0 hε1 e hcont hlim hpos δ hδ
  obtain ⟨a, b, hfull, _⟩ := hgap 0
  exact ⟨s, hs0, hsδ, 0, a, b, hfull⟩

end CriticalDTM

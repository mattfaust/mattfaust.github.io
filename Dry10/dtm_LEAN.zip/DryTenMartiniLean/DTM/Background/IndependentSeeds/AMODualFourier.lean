import DTM.Background.Transfer.AMOTransfer
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.Topology.ContinuousMap.Bounded.Normed

/-!
# Finite dual Fourier synthesis

Finite dual vectors are synthesized into genuine bounded continuous functions
of the original radian phase. The exact dual residual becomes the receiving-row
transfer residual, without taking a limit of finite-box spectra.
-/

noncomputable section
namespace CriticalDTM

open Matrix
open scoped Topology Matrix.L2OpNorm BoundedContinuousFunction

/-- An ordinary unit-modulus complex exponential with a real angle. -/
def seedPhase (x : ℝ) : ℂ := Complex.exp ((x : ℂ) * Complex.I)

@[simp] theorem seedPhase_zero : seedPhase 0 = 1 := by simp [seedPhase]

theorem seedPhase_add (x y : ℝ) : seedPhase (x + y) = seedPhase x * seedPhase y := by
  simp [seedPhase, add_mul, Complex.exp_add]

@[simp] theorem seedPhase_norm (x : ℝ) : ‖seedPhase x‖ = 1 := by
  simp [seedPhase, Complex.norm_exp]

theorem seedPhase_add_neg (x : ℝ) :
    seedPhase x + seedPhase (-x) = ((2 * Real.cos x : ℝ) : ℂ) := by
  unfold seedPhase
  rw [Complex.ofReal_neg, Complex.exp_mul_I, Complex.exp_mul_I,
    Complex.cos_neg, Complex.sin_neg]
  simp only [← Complex.ofReal_cos]
  push_cast
  ring

/-- A Fourier mode in radians, bundled in Mathlib's uniform-norm space. -/
def seedFourierMode (j : ℤ) : ℝ →ᵇ ℂ :=
  BoundedContinuousFunction.mkOfBound
    ⟨fun θ => seedPhase ((j : ℝ) * θ), by unfold seedPhase; fun_prop⟩ 2 (by
      intro x y
      calc
        dist (seedPhase ((j : ℝ) * x)) (seedPhase ((j : ℝ) * y)) ≤
          ‖seedPhase ((j : ℝ) * x)‖ + ‖seedPhase ((j : ℝ) * y)‖ :=
            dist_le_norm_add_norm _ _
        _ = 2 := by norm_num)

@[simp] theorem seedFourierMode_apply (j : ℤ) (θ : ℝ) :
    seedFourierMode j θ = seedPhase ((j : ℝ) * θ) := rfl

@[simp] theorem seedFourierMode_zero : seedFourierMode 0 = 1 := by
  ext θ
  simp

theorem seedFourierMode_shift (j : ℤ) (θ ω : ℝ) :
    seedFourierMode j (θ + ω) = seedFourierMode j θ * seedPhase ((j : ℝ) * ω) := by
  simp [seedFourierMode_apply, mul_add, seedPhase_add]

/-- Synthesis uses the actual finitely supported coefficients, with no formal
power-series convention. Its values have the uniform sup norm. -/
def seedFourierSynthesis : (ℤ →₀ ℂ) →ₗ[ℂ] (ℝ →ᵇ ℂ) :=
  Finsupp.linearCombination ℂ seedFourierMode

@[simp] theorem seedFourierSynthesis_single (j : ℤ) (a : ℂ) :
    seedFourierSynthesis (Finsupp.single j a) = a • seedFourierMode j :=
  Finsupp.linearCombination_single ℂ a j

/-- The actual dual Jacobi receiving row on finitely supported sequences:
onsite cosine has amplitude two; the two bonds have weight `lam`. -/
def seedDualOperator (α κ lam : ℝ) : (ℤ →₀ ℂ) →ₗ[ℂ] (ℤ →₀ ℂ) :=
  Finsupp.linearCombination ℂ (fun j : ℤ =>
    Finsupp.single (j - 1) (lam : ℂ) +
    Finsupp.single j ((2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ) +
    Finsupp.single (j + 1) (lam : ℂ))

/-- On a single Fourier mode the free receiving-row part is precisely the
onsite dual cosine. -/
theorem seedFourierMode_free_row (α κ θ : ℝ) (j : ℤ) :
    seedPhase κ * seedFourierMode j (θ + 2 * Real.pi * α) +
      seedPhase (-κ) * seedFourierMode j (θ - 2 * Real.pi * α) =
    ((2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ) *
      seedFourierMode j θ := by
  have hplus : seedPhase κ * seedFourierMode j (θ + 2 * Real.pi * α) =
      seedPhase (κ + 2 * Real.pi * α * (j : ℝ)) * seedFourierMode j θ := by
    simp only [seedFourierMode_apply, ← seedPhase_add]
    congr 1
    ring
  have hminus : seedPhase (-κ) * seedFourierMode j (θ - 2 * Real.pi * α) =
      seedPhase (-(κ + 2 * Real.pi * α * (j : ℝ))) * seedFourierMode j θ := by
    simp only [seedFourierMode_apply, ← seedPhase_add]
    congr 1
    ring
  rw [hplus, hminus, ← add_mul, seedPhase_add_neg]

/-- The hopping terms of the dual vector become multiplication by the
physical original cosine. -/
theorem seedFourierMode_bonds (lam θ : ℝ) (j : ℤ) :
    (lam : ℂ) * seedFourierMode (j - 1) θ +
      (lam : ℂ) * seedFourierMode (j + 1) θ =
      ((2 * lam * Real.cos θ : ℝ) : ℂ) * seedFourierMode j θ := by
  have hminus : seedFourierMode (j - 1) θ = seedPhase (-θ) * seedFourierMode j θ := by
    simp only [seedFourierMode_apply, ← seedPhase_add, Int.cast_sub, Int.cast_one]
    congr 1
    ring
  have hplus : seedFourierMode (j + 1) θ = seedPhase θ * seedFourierMode j θ := by
    simp only [seedFourierMode_apply, ← seedPhase_add, Int.cast_add, Int.cast_one]
    congr 1
    ring
  rw [hminus, hplus]
  have h := seedPhase_add_neg θ
  push_cast at h ⊢
  linear_combination ((lam : ℂ) * seedFourierMode j θ) * h

/-- Exact Fourier duality for finite vectors, including every boundary error
in the vector supplied to the left side. -/
theorem seedFourierSynthesis_dual (α κ lam : ℝ) (w : ℤ →₀ ℂ) (θ : ℝ) :
    seedFourierSynthesis (seedDualOperator α κ lam w) θ =
      seedPhase κ * seedFourierSynthesis w (θ + 2 * Real.pi * α) +
      seedPhase (-κ) * seedFourierSynthesis w (θ - 2 * Real.pi * α) +
      ((2 * lam * Real.cos θ : ℝ) : ℂ) * seedFourierSynthesis w θ := by
  induction w using Finsupp.induction_linear with
  | zero => simp
  | add w v hw hv =>
      simp only [map_add, BoundedContinuousFunction.add_apply]
      rw [hw, hv]
      ring
  | single j a =>
      simp only [seedDualOperator, Finsupp.linearCombination_single,
        map_smul, map_add, seedFourierSynthesis_single,
        BoundedContinuousFunction.add_apply, BoundedContinuousFunction.smul_apply, smul_eq_mul]
      have hf := seedFourierMode_free_row α κ θ j
      have hb := seedFourierMode_bonds lam θ j
      linear_combination a * hb - a * hf

/-- A proved finite dual residual produces the exact original scalar
receiving-row residual, with the original transfer convention. -/
theorem seedFourierSynthesis_residual (α κ lam E θ : ℝ) (w r : ℤ →₀ ℂ)
    (h : seedDualOperator α κ lam w - (E : ℂ) • w = r) :
    seedPhase κ * seedFourierSynthesis w (θ + 2 * Real.pi * α) +
      seedPhase (-κ) * seedFourierSynthesis w (θ - 2 * Real.pi * α) +
      ((2 * lam * Real.cos θ : ℝ) : ℂ) * seedFourierSynthesis w θ -
      (E : ℂ) * seedFourierSynthesis w θ = seedFourierSynthesis r θ := by
  have hh := congrArg (fun v => seedFourierSynthesis v θ) h
  simpa only [map_sub, map_smul, BoundedContinuousFunction.sub_apply,
    BoundedContinuousFunction.smul_apply, smul_eq_mul, seedFourierSynthesis_dual] using hh

end CriticalDTM

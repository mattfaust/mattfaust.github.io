import DTM.Background.IndependentSeeds.FiniteSeedVectors
import DTM.Background.IndependentSeeds.AMORealFourierSynthesis

/-!
# Exact Fourier residuals of the constructed finite resonant vectors

The finite determinant columns are the inputs to Fourier synthesis.
Both outer boundary sources are retained. Factoring `lam^(k+1)` leaves the
finite resonant coefficient `1 / middleDet` and the boundary coefficient
`lam / leftDet`; the latter tends to zero at the uncoupled point.
-/

noncomputable section
namespace CriticalDTM

open scoped BoundedContinuousFunction

/-- Exact normalized receiving row for the vector centered at site zero. -/
theorem seedFiniteVector_fourier_residual
    (α κ lam E : ℝ) (d : ℤ → ℝ) (k : ℕ)
    (hd : ∀ j : ℤ, d j = 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)))
    (hL : seedLeftDet d k lam E ≠ 0) (hM : seedMiddleDet d k lam E ≠ 0)
    (hcenter : (E - d 0) * seedLeftDet d k lam E * seedMiddleDet d k lam E =
      lam ^ 2 * (seedLeftTailDet d k lam E * seedMiddleDet d k lam E +
        seedMiddleTailDet d k lam E * seedLeftDet d k lam E)) (θ : ℝ) :
    seedPhase κ * seedRealFourierSynthesis (seedFiniteVector d k lam E)
        (θ + 2 * Real.pi * α) +
      seedPhase (-κ) * seedRealFourierSynthesis (seedFiniteVector d k lam E)
        (θ - 2 * Real.pi * α) +
      ((2 * lam * Real.cos θ : ℝ) : ℂ) *
        seedRealFourierSynthesis (seedFiniteVector d k lam E) θ -
      (E : ℂ) * seedRealFourierSynthesis (seedFiniteVector d k lam E) θ =
    ((lam ^ (k + 1) : ℝ) : ℂ) *
      (((seedMiddleDet d k lam E)⁻¹ : ℝ) * seedFourierMode ((k : ℤ) + 1) θ +
        ((lam / seedLeftDet d k lam E : ℝ) : ℂ) * seedFourierMode (-((k : ℤ) + 1) - 1) θ) := by
  let r : ℤ →₀ ℝ :=
    Finsupp.single ((k : ℤ) + 1) (lam ^ (k + 1) / seedMiddleDet d k lam E) +
      Finsupp.single (-((k : ℤ) + 1) - 1) (lam ^ (k + 2) / seedLeftDet d k lam E)
  have hrow (j : ℤ) : lam *
      (seedFiniteVector d k lam E (j - 1) + seedFiniteVector d k lam E (j + 1)) +
      (2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) - E) *
        seedFiniteVector d k lam E j = r j := by
    simpa only [seedFiniteResidual, hd, r, Finsupp.add_apply] using
      seedFiniteVector_residual d k lam E hL hM hcenter j
  have h := seedRealFourierSynthesis_residual α κ lam E θ (seedFiniteVector d k lam E) r hrow
  simp only [r, map_add, seedRealFourierSynthesis_single,
    BoundedContinuousFunction.add_apply, BoundedContinuousFunction.smul_apply,
    Complex.real_smul] at h
  push_cast at h ⊢
  simp only [div_eq_mul_inv, pow_succ] at h ⊢
  linear_combination h

/-- The reflected vector has the matching resonant coefficient and its own
outer boundary term at site `2(k+1)+1`, not a discarded finite-box error. -/
theorem seedReflectedFiniteVector_fourier_residual
    (α κ lam E : ℝ) (d : ℤ → ℝ) (k : ℕ)
    (hd : ∀ j : ℤ, d j = 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)))
    (hreflect : ∀ j : ℤ, d ((k : ℤ) + 1 - j) = d j)
    (hL : seedLeftDet d k lam E ≠ 0) (hM : seedMiddleDet d k lam E ≠ 0)
    (hcenter : (E - d 0) * seedLeftDet d k lam E * seedMiddleDet d k lam E =
      lam ^ 2 * (seedLeftTailDet d k lam E * seedMiddleDet d k lam E +
        seedMiddleTailDet d k lam E * seedLeftDet d k lam E)) (θ : ℝ) :
    seedPhase κ * seedRealFourierSynthesis (seedReflectedFiniteVector d k lam E)
        (θ + 2 * Real.pi * α) +
      seedPhase (-κ) * seedRealFourierSynthesis (seedReflectedFiniteVector d k lam E)
        (θ - 2 * Real.pi * α) +
      ((2 * lam * Real.cos θ : ℝ) : ℂ) *
        seedRealFourierSynthesis (seedReflectedFiniteVector d k lam E) θ -
      (E : ℂ) * seedRealFourierSynthesis (seedReflectedFiniteVector d k lam E) θ =
    ((lam ^ (k + 1) : ℝ) : ℂ) *
      (((seedMiddleDet d k lam E)⁻¹ : ℝ) +
        ((lam / seedLeftDet d k lam E : ℝ) : ℂ) * seedFourierMode (2 * ((k : ℤ) + 1) + 1) θ) := by
  let r : ℤ →₀ ℝ :=
    Finsupp.single 0 (lam ^ (k + 1) / seedMiddleDet d k lam E) +
      Finsupp.single (2 * ((k : ℤ) + 1) + 1) (lam ^ (k + 2) / seedLeftDet d k lam E)
  have hrow (j : ℤ) : lam *
      (seedReflectedFiniteVector d k lam E (j - 1) + seedReflectedFiniteVector d k lam E (j + 1)) +
      (2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) - E) *
        seedReflectedFiniteVector d k lam E j = r j := by
    simpa only [seedFiniteResidual, hd, r, Finsupp.add_apply] using
      seedReflectedFiniteVector_residual d k lam E hreflect hL hM hcenter j
  have h := seedRealFourierSynthesis_residual α κ lam E θ
    (seedReflectedFiniteVector d k lam E) r hrow
  simp only [r, map_add, seedRealFourierSynthesis_single,
    BoundedContinuousFunction.add_apply, BoundedContinuousFunction.smul_apply,
    Complex.real_smul, seedFourierMode_zero, BoundedContinuousFunction.coe_one, Pi.one_apply, mul_one] at h
  push_cast at h ⊢
  simp only [div_eq_mul_inv, pow_succ] at h ⊢
  linear_combination h

end CriticalDTM

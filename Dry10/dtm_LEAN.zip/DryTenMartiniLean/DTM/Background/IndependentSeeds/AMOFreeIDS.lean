import DTM.Background.AllCouplingExtension.MagneticDOSDuality
import DTM.Background.Labels.MagneticLabelStability
import DTM.Background.IndependentSeeds.UniformCosineDistribution

/-!
# The actual IDS at the free limit

The constructed magnetic spectral probabilities vary weakly continuously with
coupling and with an energy translation. Portmanteau therefore gives joint
continuity of their strict lower mass at every atom-free cut, including cuts
inside the spectrum. The free probability is identified by its actual root
moments with the pushforward of uniform phase under the cosine dispersion.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Topology ContinuousFunctionalCalculus

/-- The actual probability, translated so that the varying energy cut is zero. -/
def magneticShiftedSpectralProbability (α : ℝ) (p : ℝ × ℝ) : ProbabilityMeasure ℝ :=
  ⟨(magneticRealSpectralMeasure α p.1).map (fun x : ℝ => x - p.2),
    isProbabilityMeasure_map (continuous_id.sub continuous_const).measurable.aemeasurable⟩

/-- Translating the measure translates the same physical operator in the CFC. -/
theorem magneticShiftedSpectralProbability_integral (α : ℝ) (p : ℝ × ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    (∫ x, f x ∂(magneticShiftedSpectralProbability α p : Measure ℝ)) =
      (rootTrace (cfc f
        (hOperator α (p.1 : ℂ) - algebraMap ℝ MagneticBoundedOperator p.2))).re := by
  have hg : Continuous (fun x : ℝ => f (x - p.2)) :=
    hf.comp (continuous_id.sub continuous_const)
  rw [magneticShiftedSpectralProbability, ProbabilityMeasure.coe_mk,
    integral_map (φ := fun x : ℝ => x - p.2) (f := f)
      (continuous_id.sub continuous_const).measurable.aemeasurable
      hf.aestronglyMeasurable,
    magneticRealSpectralMeasure_integral_cfc α p.1 (fun x : ℝ => f (x - p.2)) hg,
    magneticTraceReal_apply,
    magneticAlgebraHamiltonian_cfc_coe α p.1 (fun x : ℝ => f (x - p.2)) hg,
    cfc_comp' f (fun x : ℝ => x - p.2) (hOperator α (p.1 : ℂ)) hf.continuousOn
      (continuous_id.sub continuous_const).continuousOn (hOperator_isSelfAdjoint α p.1),
    cfc_sub (fun x : ℝ => x) (fun _ : ℝ => p.2) (hOperator α (p.1 : ℂ))
      continuous_id.continuousOn continuous_const.continuousOn,
    cfc_id' ℝ (hOperator α (p.1 : ℂ)) (hOperator_isSelfAdjoint α p.1),
    cfc_const p.2 (hOperator α (p.1 : ℂ)) (hOperator_isSelfAdjoint α p.1)]

/-- Genuine joint weak continuity, requiring neither a gap nor atom-freeness. -/
theorem magneticShiftedSpectralProbability_continuous (α : ℝ) :
    Continuous (magneticShiftedSpectralProbability α) := by
  rw [continuous_iff_continuousAt]
  intro p
  apply ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mpr
  intro f
  simp_rw [magneticShiftedSpectralProbability_integral α _ f f.continuous]
  apply Complex.continuous_re.continuousAt.comp
  apply rootTrace.continuous.continuousAt.comp
  apply continuousAt_cfc_of_continuous
    (fun q : ℝ × ℝ => hOperator α (q.1 : ℂ) - algebraMap ℝ MagneticBoundedOperator q.2)
    p
    (((hOperator_continuous α).comp (Complex.continuous_ofReal.comp continuous_fst)).sub
      ((continuous_algebraMap ℝ MagneticBoundedOperator).comp continuous_snd)).continuousAt
    f f.continuous
  exact Eventually.of_forall (fun q =>
    (hOperator_isSelfAdjoint α q.1).sub
      ((show IsSelfAdjoint q.2 by simp [isSelfAdjoint_iff]).algebraMap MagneticBoundedOperator))

@[simp] theorem magneticShiftedSpectralProbability_Iio_zero (α : ℝ) (p : ℝ × ℝ) :
    (magneticShiftedSpectralProbability α p : Measure ℝ) (Iio 0) =
      magneticRealSpectralMeasure α p.1 (Iio p.2) := by
  rw [magneticShiftedSpectralProbability, ProbabilityMeasure.coe_mk,
    Measure.map_apply (f := fun x : ℝ => x - p.2)
      (continuous_id.sub continuous_const).measurable measurableSet_Iio]
  congr 1
  ext x
  simp only [mem_preimage, mem_Iio, sub_neg]

@[simp] theorem magneticShiftedSpectralProbability_singleton_zero (α : ℝ) (p : ℝ × ℝ) :
    (magneticShiftedSpectralProbability α p : Measure ℝ) {0} =
      magneticRealSpectralMeasure α p.1 {p.2} := by
  rw [magneticShiftedSpectralProbability, ProbabilityMeasure.coe_mk,
    Measure.map_apply (f := fun x : ℝ => x - p.2)
      (continuous_id.sub continuous_const).measurable (measurableSet_singleton 0)]
  congr 1
  ext x
  simp only [mem_preimage, mem_singleton_iff, sub_eq_zero]

/-- Joint continuity at an atom-free cut. The cut need not be a resolvent energy. -/
theorem continuousAt_magneticLowerMass_of_noAtom (α lam energy : ℝ)
    (hzero : magneticRealSpectralMeasure α lam {energy} = 0) :
    ContinuousAt (fun p : ℝ × ℝ => magneticLowerMass α p.1 p.2) (lam, energy) := by
  have hboundary :
      (magneticShiftedSpectralProbability α (lam, energy) : Measure ℝ)
        (frontier (Iio 0)) = 0 := by
    simpa only [frontier_Iio, magneticShiftedSpectralProbability_singleton_zero] using hzero
  have h := ProbabilityMeasure.tendsto_measure_of_null_frontier_of_tendsto'
    (magneticShiftedSpectralProbability_continuous α).continuousAt hboundary
  simp_rw [magneticShiftedSpectralProbability_Iio_zero] at h
  exact (ENNReal.tendsto_toReal (measure_ne_top _ _)).comp h

private theorem magneticAubry_rootTrace (α : ℝ) (A : MagneticBoundedOperator) :
    rootTrace (magneticAubryOperatorEquiv α A) = rootTrace A := by
  have hr : (magneticAubryEquiv α).symm hilbertRoot = hilbertRoot := by
    simpa only [LinearIsometryEquiv.symm_apply_apply] using
      (congrArg (magneticAubryEquiv α).symm (magneticAubryEquiv_root α)).symm
  simp only [rootTrace_apply, magneticAubryOperatorEquiv_apply, hr,
    magneticAubryEquiv_origin]

private theorem magneticAubry_free (α : ℝ) :
    magneticAubryOperatorEquiv 0 (hOperator α 0) =
      magneticMonomial 0 (0, 1) + magneticMonomial 0 (0, -1) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext s
  rcases s with ⟨j, k⟩
  simp [magneticAubryOperatorEquiv_apply, magneticAubryEquiv_apply,
    magneticAubryEquiv_symm_apply, hOperator_apply, hRow, east, west, north, south,
    magneticMonomial_apply, magneticPhase, add_comm, sub_eq_add_neg]

private theorem free_magnetic_rootTrace_pow (α : ℝ) (n : ℕ) :
    rootTrace ((hOperator α 0) ^ n) =
      rootTrace ((magneticMonomial 0 (0, 1) + magneticMonomial 0 (0, -1)) ^ n) := by
  rw [← magneticAubry_rootTrace 0 ((hOperator α 0) ^ n), map_pow,
    magneticAubry_free]

private theorem freePhase_sum (t : ℝ) :
    magneticPhase t 1 + magneticPhase t (-1) = (2 * Real.cos (2 * Real.pi * t) : ℝ) := by
  have h (x : ℝ) :
      Complex.exp ((x : ℂ) * Complex.I) + Complex.exp ((-x : ℂ) * Complex.I) =
        (2 * Real.cos x : ℝ) := by
    rw [Complex.exp_mul_I, Complex.exp_mul_I, Complex.cos_neg, Complex.sin_neg]
    simp only [← Complex.ofReal_cos]
    push_cast
    ring
  convert h (2 * Real.pi * t) using 1
  simp [magneticPhase]

private theorem free_amo_vertical_scalar (t : ℝ) :
    amoMagneticMonomial 0 t (0, 1) + amoMagneticMonomial 0 t (0, -1) =
      ((2 * Real.cos (2 * Real.pi * t) : ℝ) : ℂ) • (1 : AMOBoundedOperator) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext j
  simp only [ContinuousLinearMap.add_apply, lp.coeFn_add, Pi.add_apply,
    amoMagneticMonomial_apply, ContinuousLinearMap.smul_apply, lp.coeFn_smul,
    Pi.smul_apply, ContinuousLinearMap.one_apply, smul_eq_mul,
    Int.add_zero]
  have hz (k : ℤ) : magneticPhase 0 k = 1 := by simp [magneticPhase]
  simp only [hz, mul_one, ← add_mul, freePhase_sum]

/-- Free moments are the normalized cosine-dispersion moments. -/
theorem magneticRealSpectralMeasure_free_moment (α : ℝ) (n : ℕ) :
    (∫ x : ℝ, x ^ n ∂magneticRealSpectralMeasure α 0) =
      ∫ t in (0 : ℝ)..1, (2 * Real.cos (2 * Real.pi * t)) ^ n := by
  have hpair :
      (magneticMonomial 0 (0, 1) + magneticMonomial 0 (0, -1),
        fun t => amoMagneticMonomial 0 t (0, 1) + amoMagneticMonomial 0 t (0, -1)) ∈
          magneticAMOPolynomialSpace 0 :=
    (magneticAMOPolynomialSpace 0).add_mem
      (magneticAMOMonomial_mem 0 (0, 1)) (magneticAMOMonomial_mem 0 (0, -1))
  have hm := (magneticAMOPolynomialSpace_root_mean 0
    (magneticAMOPolynomialSpace_pow_mem 0 hpair n)).2
  have hfun (t : ℝ) :
      amoRootState
        ((amoMagneticMonomial 0 t (0, 1) + amoMagneticMonomial 0 t (0, -1))^n) =
          ((2 * Real.cos (2 * Real.pi * t)) ^ n : ℝ) := by
    rw [free_amo_vertical_scalar, smul_pow]
    simp only [one_pow, map_smul, smul_eq_mul, amoRootState_one, mul_one,
      Complex.ofReal_pow]
  change (∫ t in (0 : ℝ)..1,
      amoRootState ((amoMagneticMonomial 0 t (0, 1) + amoMagneticMonomial 0 t (0, -1))^n)) =
    rootTrace ((magneticMonomial 0 (0, 1) + magneticMonomial 0 (0, -1))^n) at hm
  simp_rw [hfun] at hm
  rw [intervalIntegral.integral_ofReal] at hm
  rw [magneticRealSpectralMeasure_moment]
  simp only [Complex.ofReal_zero]
  rw [free_magnetic_rootTrace_pow, ← hm]
  rfl

/-- The actual free root probability is the uniform cosine pushforward. -/
theorem magneticRealSpectralMeasure_free (α : ℝ) :
    magneticRealSpectralMeasure α 0 =
      (volume.restrict (Ioc (0 : ℝ) 1)).map
        (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)) := by
  letI : IsProbabilityMeasure (volume.restrict (Ioc (0 : ℝ) 1)) :=
    ⟨by simp [Real.volume_Ioc]⟩
  have hc : Continuous (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)) := by fun_prop
  let μ : ProbabilityMeasure ℝ := ⟨magneticRealSpectralMeasure α 0, inferInstance⟩
  let ν : ProbabilityMeasure ℝ :=
    ⟨(volume.restrict (Ioc (0 : ℝ) 1)).map
      (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)),
      isProbabilityMeasure_map hc.measurable.aemeasurable⟩
  have hμ : (μ : Measure ℝ) (Icc (-2) 2) = 1 := by
    simpa only [μ, abs_zero, mul_zero, add_zero] using magneticRealSpectralMeasure_window α 0
  have hν : (ν : Measure ℝ) (Icc (-2) 2) = 1 := by
    change ((volume.restrict (Ioc (0 : ℝ) 1)).map
      (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t))) (Icc (-2) 2) = 1
    rw [Measure.map_apply hc.measurable measurableSet_Icc]
    have hpre : (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)) ⁻¹' Icc (-2) 2 = univ := by
      apply Set.eq_univ_of_forall
      intro t
      have h := Real.cos_le_one (2 * Real.pi * t)
      have h' := Real.neg_one_le_cos (2 * Real.pi * t)
      change -2 ≤ 2 * Real.cos (2 * Real.pi * t) ∧ 2 * Real.cos (2 * Real.pi * t) ≤ 2
      constructor <;> linarith
    rw [hpre, measure_univ]
  have heq : μ = ν := by
    apply probabilityMeasure_eq_of_compact_moments μ ν (-2) 2 hμ hν
    intro n
    change (∫ x : ℝ, x ^ n ∂magneticRealSpectralMeasure α 0) =
      ∫ x : ℝ, x ^ n ∂(volume.restrict (Ioc (0 : ℝ) 1)).map
        (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t))
    rw [integral_map (φ := fun t : ℝ => 2 * Real.cos (2 * Real.pi * t))
      (f := fun x : ℝ => x ^ n) hc.measurable.aemeasurable
      (continuous_id.pow n).aestronglyMeasurable,
      magneticRealSpectralMeasure_free_moment,
      intervalIntegral.integral_of_le (show (0 : ℝ) ≤ 1 by norm_num)]
  exact congrArg (fun ρ : ProbabilityMeasure ℝ => (ρ : Measure ℝ)) heq

/-- The strict lower mass at an interior free cosine energy. -/
theorem magneticLowerMass_free_cos (α : ℝ) {κ : ℝ}
    (hκ0 : 0 < κ) (hκpi : κ < Real.pi) :
    magneticLowerMass α 0 (2 * Real.cos κ) = 1 - κ / Real.pi := by
  rw [magneticLowerMass, magneticRealSpectralMeasure_free,
    cosine_uniform_lower_tail hκ0 hκpi, ENNReal.toReal_ofReal]
  exact sub_nonneg.mpr (le_of_lt ((div_lt_one Real.pi_pos).mpr hκpi))

/-- The actual free spectral probability has no atom at an interior resonance. -/
theorem magneticRealSpectralMeasure_free_noAtom (α : ℝ) {κ : ℝ}
    (hκ0 : 0 < κ) (hκpi : κ < Real.pi) :
    magneticRealSpectralMeasure α 0 {2 * Real.cos κ} = 0 := by
  rw [magneticRealSpectralMeasure_free]
  exact cosine_uniform_singleton hκ0 hκpi

/-- Joint continuity at the free resonance, although it lies inside the free spectrum. -/
theorem continuousAt_magneticLowerMass_free_cos (α : ℝ) {κ : ℝ}
    (hκ0 : 0 < κ) (hκpi : κ < Real.pi) :
    ContinuousAt (fun p : ℝ × ℝ => magneticLowerMass α p.1 p.2) (0, 2 * Real.cos κ) :=
  continuousAt_magneticLowerMass_of_noAtom α 0 _
    (magneticRealSpectralMeasure_free_noAtom α hκ0 hκpi)

/-- The actual lower mass converges to the explicit free label along any joint net. -/
theorem magneticLowerMass_tendsto_free_cos
    {ι : Type*} {l : Filter ι} (α : ℝ) {κ : ℝ}
    (hκ0 : 0 < κ) (hκpi : κ < Real.pi) (p : ι → ℝ × ℝ)
    (hlim : Tendsto p l (𝓝 (0, 2 * Real.cos κ))) :
    Tendsto (fun i => magneticLowerMass α (p i).1 (p i).2) l (𝓝 (1 - κ / Real.pi)) := by
  have h := (continuousAt_magneticLowerMass_free_cos α hκ0 hκpi).tendsto.comp hlim
  simpa only [magneticLowerMass_free_cos α hκ0 hκpi] using h

/-- A connected genuine resolvent curve that approaches a free resonance carries
its explicit free label. In particular the limit point is not required to be in
the resolvent set. This identifies a label; existence of the curve is separate. -/
theorem magneticLowerMass_eq_free_of_resolvent_curve
    {X : Type*} [TopologicalSpace X] [PreconnectedSpace X]
    {ι : Type*} {l : Filter ι} [NeBot l]
    (α : ℝ) {κ : ℝ} (hκ0 : 0 < κ) (hκpi : κ < Real.pi)
    (p : X → ℝ × ℝ) (hcont : Continuous p)
    (hres : ∀ x, p x ∈ realJointResolventDomain α)
    (u : ι → X) (hlim : Tendsto (fun i => p (u i)) l (𝓝 (0, 2 * Real.cos κ)))
    (x : X) :
    magneticLowerMass α (p x).1 (p x).2 = 1 - κ / Real.pi := by
  have hfree := magneticLowerMass_tendsto_free_cos α hκ0 hκpi (fun i => p (u i)) hlim
  have heq : (fun i => magneticLowerMass α (p (u i)).1 (p (u i)).2) =ᶠ[l]
      (fun _ => magneticLowerMass α (p x).1 (p x).2) :=
    Eventually.of_forall (fun i =>
      magneticLowerMass_constant_on_resolvent_curve α p hcont hres (u i) x)
  have hconstant : Tendsto (fun i => magneticLowerMass α (p (u i)).1 (p (u i)).2) l
      (𝓝 (magneticLowerMass α (p x).1 (p x).2)) :=
    (tendsto_congr' heq).2 tendsto_const_nhds
  exact tendsto_nhds_unique hconstant hfree

end CriticalDTM

import DTM.Background.Transfer.AMOLyapunov

/-!
# Frequency reflection

Evenness of the physical cosine identifies the actual transfer products at
`(-α,-θ)` and `(α,θ)`. A change of variable in the normalized phase integral
identifies the actual Lyapunov exponents. This permits positive-order finite
resonance constructions to address negative integer labels as well.
-/

noncomputable section
namespace CriticalDTM

/-- Reflection of the phase leaves the actual cosine transfer unchanged. -/
theorem amoTransfer_neg_phase (lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransfer lam z (-θ) = amoTransfer lam z θ := by
  simp [amoTransfer, Real.cos_neg]

/-- An exact identity of the ordered products, not just their norms. -/
theorem amoTransferProduct_neg_frequency_neg_phase
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct (-α) lam z (-θ) n = amoTransferProduct α lam z θ n := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [amoTransferProduct_succ, amoTransferProduct_succ, ih]
      rw [show -θ + 2 * Real.pi * (-α) * (n : ℝ) =
        -(θ + 2 * Real.pi * α * (n : ℝ)) by ring, amoTransfer_neg_phase]

theorem amoTransferLogNorm_neg_frequency
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferLogNorm (-α) lam z θ n = amoTransferLogNorm α lam z (-θ) n := by
  unfold amoTransferLogNorm
  rw [← amoTransferProduct_neg_frequency_neg_phase α lam z (-θ) n]
  simp only [neg_neg]

/-- Normalized phase averages agree after reflection of the frequency. -/
theorem amoTransferLogAverage_neg_frequency (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoTransferLogAverage (-α) lam z n = amoTransferLogAverage α lam z n := by
  unfold amoTransferLogAverage
  simp_rw [amoTransferLogNorm_neg_frequency]
  congr 1
  rw [intervalIntegral.integral_comp_neg
    (f := fun θ => amoTransferLogNorm α lam z θ n)]
  simpa only [neg_zero, neg_add_cancel, zero_add] using
    (amoTransferLogNorm_periodic α lam z n).intervalIntegral_add_eq (- (2 * Real.pi)) 0

theorem amoFiniteLyapunov_neg_frequency (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoFiniteLyapunov (-α) lam z n = amoFiniteLyapunov α lam z n := by
  simp only [amoFiniteLyapunov, amoTransferLogAverage_neg_frequency]

/-- The exponent itself is unchanged, with no spectral or irrationality premise. -/
theorem amoLyapunov_neg_frequency (α lam : ℝ) (z : ℂ) :
    amoLyapunov (-α) lam z = amoLyapunov α lam z := by
  simp only [amoLyapunov, amoFiniteLyapunov_neg_frequency]

end CriticalDTM

import DTM.Background.SpectralVanishing.AMOSpectralLyapunov

/-!
# A uniform complex cone criterion for the actual AMO Lyapunov exponent

The cone is `‖v 1‖ ≤ ‖v 0‖` in `ℂ²`.  Entrywise closeness to the real
diagonal matrix with entries `1 + δ, 1 - δ` gives uniform expansion.
All transfer norms below are the Euclidean operator norms from `AMOTransfer`.
The conjugating frames are indexed by real phases: no periodicity or
measurability of a frame is assumed or used.
-/

noncomputable section

open Filter MeasureTheory Matrix
open scoped Topology Matrix Matrix.L2OpNorm

namespace CriticalDTM

/-- An exponential lower bound with a fixed multiplicative loss passes to
 the actual phase-averaged Fekete limit. -/
theorem log_le_amoLyapunov_of_uniform_power_lower_bound
    {α lam : ℝ} {z : ℂ} {r L : ℝ} (hr : 0 < r) (hL : 0 < L)
    (hgrowth : ∀ (θ : ℝ) (n : ℕ),
      r ^ n ≤ L * amoTransferNorm (amoTransferProduct α lam z θ n)) :
    Real.log r ≤ amoLyapunov α lam z := by
  have hlog (θ : ℝ) (n : ℕ) :
      (n : ℝ) * Real.log r - Real.log L ≤ amoTransferLogNorm α lam z θ n := by
    have h := Real.log_le_log (pow_pos hr n) (hgrowth θ n)
    rw [Real.log_pow, Real.log_mul (ne_of_gt hL)
      (ne_of_gt (amoTransferProduct_norm_pos α lam z θ n))] at h
    unfold amoTransferLogNorm
    linarith
  have havg (n : ℕ) :
      (n : ℝ) * Real.log r - Real.log L ≤ amoTransferLogAverage α lam z n := by
    have hint := intervalIntegral.integral_mono (by positivity : (0 : ℝ) ≤ 2 * Real.pi)
      (intervalIntegrable_const (c := (n : ℝ) * Real.log r - Real.log L))
      (amoTransferLogNorm_intervalIntegrable α lam z n 0 (2 * Real.pi))
      (fun θ => hlog θ n)
    have hperiod : 0 < 2 * Real.pi := by positivity
    unfold amoTransferLogAverage
    apply (le_div_iff₀ hperiod).mpr
    simpa only [intervalIntegral.integral_const, sub_zero, smul_eq_mul, mul_comm] using hint
  have hfinite : ∀ᶠ n : ℕ in atTop,
      Real.log r - Real.log L / (n : ℝ) ≤ amoFiniteLyapunov α lam z n := by
    filter_upwards [eventually_ge_atTop 1] with n hn
    have hn' : (0 : ℝ) < n := by exact_mod_cast (show 0 < n from hn)
    have h := div_le_div_of_nonneg_right (havg n) hn'.le
    simpa only [amoFiniteLyapunov, sub_div, mul_div_cancel_left₀ _ (ne_of_gt hn')] using h
  have hlim : Tendsto (fun n : ℕ => Real.log r - Real.log L / (n : ℝ))
      atTop (𝓝 (Real.log r)) := by
    simpa only [sub_zero] using
      (tendsto_const_div_atTop_nhds_zero_nat (Real.log L)).const_sub (Real.log r)
  exact le_of_tendsto_of_tendsto hlim (tendsto_amoFiniteLyapunov α lam z) hfinite

/-- The expanding coordinate cone, using complex absolute values. -/
def amoUnstableCone (v : Fin 2 → ℂ) : Prop := ‖v 1‖ ≤ ‖v 0‖

/-- The reference real hyperbolic diagonal, viewed as a complex matrix. -/
def amoHyperbolicDiagonal (δ : ℝ) : AMOTransferMatrix :=
  !![((1 + δ : ℝ) : ℂ), 0; 0, ((1 - δ : ℝ) : ℂ)]

/-- All four complex entries of the remainder are at most `δ / 16`. -/
def AMONearDiagonal (δ : ℝ) (C : AMOTransferMatrix) : Prop :=
  ∀ i j : Fin 2, ‖C i j - amoHyperbolicDiagonal δ i j‖ ≤ δ / 16

/-- One near-diagonal step preserves the complex cone and expands its
 first coordinate by at least `1 + 7 * δ / 8`. -/
theorem AMONearDiagonal.map_cone
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ ≤ 1 / 2)
    {C : AMOTransferMatrix} (hC : AMONearDiagonal δ C)
    {v : Fin 2 → ℂ} (hv : amoUnstableCone v) :
    amoUnstableCone (C *ᵥ v) ∧
      (1 + 7 * δ / 8) * ‖v 0‖ ≤ ‖(C *ᵥ v) 0‖ := by
  have h00 : ‖C 0 0 - ((1 + δ : ℝ) : ℂ)‖ ≤ δ / 16 := by
    simpa [amoHyperbolicDiagonal] using hC 0 0
  have h01 : ‖C 0 1‖ ≤ δ / 16 := by
    simpa [amoHyperbolicDiagonal] using hC 0 1
  have h10 : ‖C 1 0‖ ≤ δ / 16 := by
    simpa [amoHyperbolicDiagonal] using hC 1 0
  have h11 : ‖C 1 1 - ((1 - δ : ℝ) : ℂ)‖ ≤ δ / 16 := by
    simpa [amoHyperbolicDiagonal] using hC 1 1
  have hd0 : ‖((1 + δ : ℝ) : ℂ)‖ = 1 + δ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by linarith)]
  have hd1 : ‖((1 - δ : ℝ) : ℂ)‖ = 1 - δ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by linarith)]
  have h00' : 1 + δ - δ / 16 ≤ ‖C 0 0‖ := by
    have h := norm_sub_norm_le (((1 + δ : ℝ) : ℂ)) (C 0 0)
    rw [hd0, norm_sub_rev] at h
    linarith
  have h11' : ‖C 1 1‖ ≤ 1 - δ + δ / 16 := by
    have h := norm_add_le (C 1 1 - ((1 - δ : ℝ) : ℂ)) (((1 - δ : ℝ) : ℂ))
    rw [sub_add_cancel, hd1] at h
    linarith
  have hv' : ‖v 1‖ ≤ ‖v 0‖ := hv
  have hcross : ‖C 0 1 * v 1‖ ≤ δ / 16 * ‖v 0‖ := by
    rw [norm_mul]
    exact mul_le_mul h01 hv' (norm_nonneg _) (by positivity)
  have hmain := mul_le_mul_of_nonneg_right h00' (norm_nonneg (v 0))
  have hlower : (1 + 7 * δ / 8) * ‖v 0‖ ≤ ‖(C *ᵥ v) 0‖ := by
    have h := norm_sub_norm_le (C 0 0 * v 0) (-(C 0 1 * v 1))
    simp only [norm_neg, sub_neg_eq_add, norm_mul] at h
    simp only [norm_mul] at hcross
    simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_two]
    nlinarith
  have htail : ‖(C *ᵥ v) 1‖ ≤ (1 - 7 * δ / 8) * ‖v 0‖ := by
    have h10' := mul_le_mul_of_nonneg_right h10 (norm_nonneg (v 0))
    have h11'' := mul_le_mul h11' hv' (norm_nonneg (v 1))
      (show 0 ≤ 1 - δ + δ / 16 by linarith)
    have h := norm_add_le (C 1 0 * v 0) (C 1 1 * v 1)
    simp only [norm_mul] at h
    simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_two]
    nlinarith
  refine ⟨?_, hlower⟩
  unfold amoUnstableCone
  have hv0 := norm_nonneg (v 0)
  nlinarith

/-- A nonperiodic, real-phase ordered matrix product, with the same order
 and phase convention as the actual AMO transfer product. -/
def amoConeProduct (C : ℝ → AMOTransferMatrix) (ω θ : ℝ) : ℕ → AMOTransferMatrix
  | 0 => 1
  | n + 1 => C (θ + ω * (n : ℝ)) * amoConeProduct C ω θ n

@[simp] theorem amoConeProduct_zero (C : ℝ → AMOTransferMatrix) (ω θ : ℝ) :
    amoConeProduct C ω θ 0 = 1 := rfl

@[simp] theorem amoConeProduct_succ (C : ℝ → AMOTransferMatrix) (ω θ : ℝ) (n : ℕ) :
    amoConeProduct C ω θ (n + 1) =
      C (θ + ω * (n : ℝ)) * amoConeProduct C ω θ n := rfl

/-- Cone invariance and coordinate expansion iterate over arbitrary real
 phases, without imposing periodicity on the matrices. -/
theorem amoConeProduct_expands
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ ≤ 1 / 2)
    {C : ℝ → AMOTransferMatrix} (hC : ∀ θ, AMONearDiagonal δ (C θ))
    (ω θ : ℝ) {v : Fin 2 → ℂ} (hv : amoUnstableCone v) (n : ℕ) :
    amoUnstableCone (amoConeProduct C ω θ n *ᵥ v) ∧
      (1 + δ / 2) ^ n * ‖v 0‖ ≤ ‖(amoConeProduct C ω θ n *ᵥ v) 0‖ := by
  induction n with
  | zero => simpa using And.intro hv (le_refl ‖v 0‖)
  | succ n ih =>
      rw [amoConeProduct_succ, ← Matrix.mulVec_mulVec]
      obtain ⟨hcone, hexpand⟩ := (hC (θ + ω * (n : ℝ))).map_cone hδ0 hδ1 ih.1
      refine ⟨hcone, ?_⟩
      have hr : 0 ≤ 1 + δ / 2 := by linarith
      calc
        (1 + δ / 2) ^ (n + 1) * ‖v 0‖ =
            (1 + δ / 2) * ((1 + δ / 2) ^ n * ‖v 0‖) := by rw [pow_succ]; ring
        _ ≤ (1 + δ / 2) * ‖(amoConeProduct C ω θ n *ᵥ v) 0‖ :=
          mul_le_mul_of_nonneg_left ih.2 hr
        _ ≤ (1 + 7 * δ / 8) * ‖(amoConeProduct C ω θ n *ᵥ v) 0‖ :=
          mul_le_mul_of_nonneg_right (by linarith) (norm_nonneg _)
        _ ≤ _ := hexpand

/-- A near-diagonal product has an exponentially large entry and hence
 an exponentially large Euclidean operator norm. -/
theorem amoConeProduct_norm_lower_bound
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ ≤ 1 / 2)
    {C : ℝ → AMOTransferMatrix} (hC : ∀ θ, AMONearDiagonal δ (C θ))
    (ω θ : ℝ) (n : ℕ) :
    (1 + δ / 2) ^ n ≤ amoTransferNorm (amoConeProduct C ω θ n) := by
  have h := (amoConeProduct_expands hδ0 hδ1 hC ω θ
    (v := Pi.single 0 1) (by simp [amoUnstableCone]) n).2
  have hentry : (1 + δ / 2) ^ n ≤ ‖amoConeProduct C ω θ n 0 0‖ := by
    simpa only [Matrix.mulVec_single_one, Pi.single_eq_same, norm_one, mul_one] using h
  exact hentry.trans (norm_entry_le_amoTransferNorm _ 0 0)

/-- Scalar homogeneity for the explicitly chosen Euclidean operator norm. -/
theorem amoTransferNorm_smul (a : ℂ) (M : AMOTransferMatrix) :
    amoTransferNorm (a • M) = ‖a‖ * amoTransferNorm M := by
  change ‖a • M‖ = ‖a‖ * ‖M‖
  exact norm_smul a M

/-- Exact telescoping of a real-phase frame conjugacy, including its unit
 complex scalar.  The phase is never reduced modulo a period. -/
theorem amoTransferProduct_frame_identity
    {α lam : ℝ} {z ε : ℂ} {B C : ℝ → AMOTransferMatrix}
    (hframe : ∀ θ, amoTransfer lam z θ * B θ =
      ε • (B (θ + 2 * Real.pi * α) * C θ))
    (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ n * B θ =
      ε ^ n • (B (θ + 2 * Real.pi * α * (n : ℝ)) *
        amoConeProduct C (2 * Real.pi * α) θ n) := by
  induction n with
  | zero => simp
  | succ n ih =>
      have hphase : θ + 2 * Real.pi * α * (n : ℝ) + 2 * Real.pi * α =
          θ + 2 * Real.pi * α * ((n + 1 : ℕ) : ℝ) := by
        push_cast
        ring
      rw [amoTransferProduct_succ, mul_assoc, ih, Matrix.mul_smul,
        ← mul_assoc, hframe, Matrix.smul_mul, smul_smul, ← pow_succ,
        mul_assoc, hphase, amoConeProduct_succ]

/-- The loss from a uniformly bounded frame and its explicit left inverse
 is only `K²`, independent of the number of transfer steps. -/
theorem amoTransferProduct_norm_lower_bound_of_nearDiagonal_frame
    {α lam δ K : ℝ} {z ε : ℂ} {B Binv C : ℝ → AMOTransferMatrix}
    (hδ0 : 0 < δ) (hδ1 : δ ≤ 1 / 2) (hε : ‖ε‖ = 1)
    (hinv : ∀ θ, Binv θ * B θ = 1)
    (hB : ∀ θ, amoTransferNorm (B θ) ≤ K)
    (hBinv : ∀ θ, amoTransferNorm (Binv θ) ≤ K)
    (hframe : ∀ θ, amoTransfer lam z θ * B θ =
      ε • (B (θ + 2 * Real.pi * α) * C θ))
    (hC : ∀ θ, AMONearDiagonal δ (C θ))
    (θ : ℝ) (n : ℕ) :
    (1 + δ / 2) ^ n ≤ K ^ 2 * amoTransferNorm (amoTransferProduct α lam z θ n) := by
  have hK : 0 ≤ K := (amoTransferNorm_nonneg (B θ)).trans (hB θ)
  have hid : Binv (θ + 2 * Real.pi * α * (n : ℝ)) *
      (amoTransferProduct α lam z θ n * B θ) =
      ε ^ n • amoConeProduct C (2 * Real.pi * α) θ n := by
    rw [amoTransferProduct_frame_identity hframe, Matrix.mul_smul,
      ← mul_assoc, hinv, one_mul]
  have hnorm : amoTransferNorm (Binv (θ + 2 * Real.pi * α * (n : ℝ)) *
      (amoTransferProduct α lam z θ n * B θ)) =
      amoTransferNorm (amoConeProduct C (2 * Real.pi * α) θ n) := by
    rw [hid, amoTransferNorm_smul, norm_pow, hε, one_pow, one_mul]
  calc
    (1 + δ / 2) ^ n ≤ amoTransferNorm (amoConeProduct C (2 * Real.pi * α) θ n) :=
      amoConeProduct_norm_lower_bound hδ0 hδ1 hC _ _ _
    _ = amoTransferNorm (Binv (θ + 2 * Real.pi * α * (n : ℝ)) *
        (amoTransferProduct α lam z θ n * B θ)) := hnorm.symm
    _ ≤ amoTransferNorm (Binv (θ + 2 * Real.pi * α * (n : ℝ))) *
        amoTransferNorm (amoTransferProduct α lam z θ n * B θ) :=
      amoTransferNorm_mul_le _ _
    _ ≤ K * (amoTransferNorm (amoTransferProduct α lam z θ n) * K) := by
      apply mul_le_mul (hBinv _)
      · exact (amoTransferNorm_mul_le _ _).trans
          (mul_le_mul_of_nonneg_left (hB θ) (amoTransferNorm_nonneg _))
      · exact amoTransferNorm_nonneg _
      · exact hK
    _ = K ^ 2 * amoTransferNorm (amoTransferProduct α lam z θ n) := by ring

/-- A uniform near-diagonal frame gives a quantitative lower bound on the
 actual Fekete-limit Lyapunov exponent, not an auxiliary exponent. -/
theorem amoLyapunov_lower_bound_of_nearDiagonal_frame
    {α lam δ K : ℝ} {z ε : ℂ} {B Binv C : ℝ → AMOTransferMatrix}
    (hδ0 : 0 < δ) (hδ1 : δ ≤ 1 / 2) (hε : ‖ε‖ = 1)
    (hinv : ∀ θ, Binv θ * B θ = 1)
    (hB : ∀ θ, amoTransferNorm (B θ) ≤ K)
    (hBinv : ∀ θ, amoTransferNorm (Binv θ) ≤ K)
    (hframe : ∀ θ, amoTransfer lam z θ * B θ =
      ε • (B (θ + 2 * Real.pi * α) * C θ))
    (hC : ∀ θ, AMONearDiagonal δ (C θ)) :
    Real.log (1 + δ / 2) ≤ amoLyapunov α lam z := by
  have hgrowth := amoTransferProduct_norm_lower_bound_of_nearDiagonal_frame
    hδ0 hδ1 hε hinv hB hBinv hframe hC
  have hK : 0 < K ^ 2 := by
    have h := hgrowth 0 0
    simp only [pow_zero, amoTransferProduct_zero, amoTransferNorm_one, mul_one] at h
    exact zero_lt_one.trans_le h
  exact log_le_amoLyapunov_of_uniform_power_lower_bound (by linarith) hK hgrowth

/-- Positivity from a complex near-diagonal frame, with no arithmetic,
 spectral, periodicity, or resolvent premise. -/
theorem amoLyapunov_pos_of_nearDiagonal_frame
    {α lam δ K : ℝ} {z ε : ℂ} {B Binv C : ℝ → AMOTransferMatrix}
    (hδ0 : 0 < δ) (hδ1 : δ ≤ 1 / 2) (hε : ‖ε‖ = 1)
    (hinv : ∀ θ, Binv θ * B θ = 1)
    (hB : ∀ θ, amoTransferNorm (B θ) ≤ K)
    (hBinv : ∀ θ, amoTransferNorm (Binv θ) ≤ K)
    (hframe : ∀ θ, amoTransfer lam z θ * B θ =
      ε • (B (θ + 2 * Real.pi * α) * C θ))
    (hC : ∀ θ, AMONearDiagonal δ (C θ)) :
    0 < amoLyapunov α lam z :=
  (Real.log_pos (by linarith : 1 < 1 + δ / 2)).trans_le
    (amoLyapunov_lower_bound_of_nearDiagonal_frame hδ0 hδ1 hε hinv hB hBinv hframe hC)

end CriticalDTM

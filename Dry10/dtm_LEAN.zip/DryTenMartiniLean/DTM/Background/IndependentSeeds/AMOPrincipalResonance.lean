import DTM.Background.IndependentSeeds.CosineResonanceAlgebra
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-!
# Principal phases at a labelled cosine resonance

The principal angle `π * (1 - fract (n * α))` lies in `(0,π)` for every
nonzero integer label at irrational frequency. It has free lower-tail label
`fract (n * α)`. Reducing the unreduced angle modulo `π` contributes the
explicit sign `cos (π * (floor (n * α) + 1))`; that sign is retained in all
energy identities below.

The results are scalar phase arithmetic and finite diagonal separation.
They do not assert the opening or the label of a perturbed spectral gap.
-/

noncomputable section

namespace CriticalDTM

/-- The principal radian angle with free lower-tail label `fract (n * α)`. -/
def amoPrincipalKappa (α : ℝ) (n : ℤ) : ℝ :=
  Real.pi * (1 - Int.fract ((n : ℝ) * α))

theorem amoPrincipalKappa_mem_Ioo {α : ℝ} (hα : Irrational α)
    {n : ℤ} (hn : n ≠ 0) : amoPrincipalKappa α n ∈ Set.Ioo 0 Real.pi := by
  have hf0 : 0 < Int.fract ((n : ℝ) * α) :=
    Int.fract_pos.mpr ((hα.intCast_mul hn).ne_int _)
  have hf1 := Int.fract_lt_one ((n : ℝ) * α)
  change 0 < Real.pi * (1 - Int.fract ((n : ℝ) * α)) ∧
    Real.pi * (1 - Int.fract ((n : ℝ) * α)) < Real.pi
  constructor
  · exact mul_pos Real.pi_pos (sub_pos.mpr hf1)
  · nlinarith [Real.pi_pos]

theorem amoPrincipalKappa_pos {α : ℝ} (hα : Irrational α)
    {n : ℤ} (hn : n ≠ 0) : 0 < amoPrincipalKappa α n :=
  (amoPrincipalKappa_mem_Ioo hα hn).1

theorem amoPrincipalKappa_lt_pi {α : ℝ} (hα : Irrational α)
    {n : ℤ} (hn : n ≠ 0) : amoPrincipalKappa α n < Real.pi :=
  (amoPrincipalKappa_mem_Ioo hα hn).2

/-- The integer in the phase relation is the floor plus one, not the floor. -/
theorem amoPrincipalKappa_resonance (α : ℝ) (n : ℤ) :
    amoPrincipalKappa α n + Real.pi * α * (n : ℝ) =
      Real.pi * ((Int.floor ((n : ℝ) * α) + 1 : ℤ) : ℝ) := by
  simp only [amoPrincipalKappa, Int.fract, Int.cast_add, Int.cast_one]
  ring

/-- Arithmetic of the free lower-tail label; no spectral assertion is used. -/
theorem amoPrincipalKappa_label (α : ℝ) (n : ℤ) :
    1 - amoPrincipalKappa α n / Real.pi = Int.fract ((n : ℝ) * α) := by
  unfold amoPrincipalKappa
  field_simp

/-- The integer phase in a resonance contributes a genuine sign. -/
theorem cosine_phase_resonance_sign (ℓ : ℤ) :
    Real.cos (Real.pi * (ℓ : ℝ)) = 1 ∨
      Real.cos (Real.pi * (ℓ : ℝ)) = -1 := by
  have h := Real.abs_cos_int_mul_pi ℓ
  rw [mul_comm (ℓ : ℝ) Real.pi] at h
  rcases le_total 0 (Real.cos (Real.pi * (ℓ : ℝ))) with hp | hn
  · left
    rwa [abs_of_nonneg hp] at h
  · right
    rw [abs_of_nonpos hn] at h
    linarith

/-- Exact bridge from the principal or any resonant angle to the unreduced
cosine diagonal, including its integer-phase sign. -/
theorem cosine_phase_resonance_parity {α κ : ℝ} {n ℓ : ℤ}
    (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ)) (j : ℤ) :
    2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) =
      Real.cos (Real.pi * (ℓ : ℝ)) *
        (2 * Real.cos (Real.pi * α * ((2 * j - n : ℤ) : ℝ))) := by
  have hangle : κ + 2 * Real.pi * α * (j : ℝ) =
      Real.pi * (ℓ : ℝ) + Real.pi * α * ((2 * j - n : ℤ) : ℝ) := by
    calc
      _ = (κ + Real.pi * α * (n : ℝ)) +
          Real.pi * α * ((2 * j - n : ℤ) : ℝ) := by push_cast; ring
      _ = _ := by rw [hres]
  have hsin : Real.sin (Real.pi * (ℓ : ℝ)) = 0 := by
    simpa only [mul_comm] using Real.sin_int_mul_pi ℓ
  rw [hangle, Real.cos_add, hsin]
  ring

/-- The root energy is subject to the same sign as the whole diagonal. -/
theorem cosine_phase_resonance_energy {α κ : ℝ} {n ℓ : ℤ}
    (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ)) :
    2 * Real.cos κ = Real.cos (Real.pi * (ℓ : ℝ)) *
      (2 * Real.cos (Real.pi * α * (n : ℝ))) := by
  simpa using cosine_phase_resonance_parity hres 0

/-- Reflection is through the two physical resonant sites `0` and `n`. -/
theorem cosine_phase_resonance_reflection {α κ : ℝ} {n ℓ : ℤ}
    (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ)) (j : ℤ) :
    2 * Real.cos (κ + 2 * Real.pi * α * ((n - j : ℤ) : ℝ)) =
      2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) := by
  rw [cosine_phase_resonance_parity hres (n - j),
    cosine_phase_resonance_parity hres j]
  have hangle : Real.pi * α * ((2 * (n - j) - n : ℤ) : ℝ) =
      -(Real.pi * α * ((2 * j - n : ℤ) : ℝ)) := by push_cast; ring
  rw [hangle, Real.cos_neg]

/-- Reduction to the unreduced denominator retains exactly one parity sign. -/
theorem cosine_phase_resonance_denominator {α κ : ℝ} {n ℓ : ℤ}
    (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ)) (j : ℤ) :
    2 * Real.cos κ - 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) =
      Real.cos (Real.pi * (ℓ : ℝ)) *
        (2 * Real.cos (Real.pi * α * (n : ℝ)) -
          2 * Real.cos (Real.pi * α * ((2 * j - n : ℤ) : ℝ))) := by
  rw [cosine_phase_resonance_energy hres, cosine_phase_resonance_parity hres j]
  ring

/-- At irrational frequency, no site other than `0,n` has the root energy. -/
theorem cosine_phase_resonance_denominator_ne_zero {α κ : ℝ} (hα : Irrational α)
    {n ℓ j : ℤ} (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ))
    (hj : j ≠ 0) (hjn : j ≠ n) :
    2 * Real.cos κ - 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) ≠ 0 := by
  have hsign : Real.cos (Real.pi * (ℓ : ℝ)) ≠ 0 := by
    rcases cosine_phase_resonance_sign ℓ with h | h <;> rw [h] <;> norm_num
  rw [cosine_phase_resonance_denominator hres j]
  exact mul_ne_zero hsign (cosine_resonance_denominator_ne_zero hα hj
    (sub_ne_zero.mpr hjn.symm))

/-- Doubling the resonant phase removes its integer parity exactly. -/
theorem cosine_phase_resonance_exp_twice {α κ : ℝ} {n ℓ : ℤ}
    (hres : κ + Real.pi * α * (n : ℝ) = Real.pi * (ℓ : ℝ)) :
    Complex.exp (((2 * κ : ℝ) : ℂ) * Complex.I) =
      Complex.exp (((-2 * Real.pi * α * (n : ℝ) : ℝ) : ℂ) * Complex.I) := by
  have hangle : 2 * κ = -2 * Real.pi * α * (n : ℝ) + (ℓ : ℝ) * (2 * Real.pi) := by
    nlinarith [hres]
  have hperiod :
      Complex.exp (((((ℓ : ℝ) * (2 * Real.pi)) : ℝ) : ℂ) * Complex.I) = 1 := by
    simpa only [Complex.ofReal_mul, Complex.ofReal_ofNat, Complex.ofReal_intCast,
      mul_assoc] using Complex.exp_int_mul_two_pi_mul_I ℓ
  rw [hangle, Complex.ofReal_add, add_mul, Complex.exp_add, hperiod, mul_one]

end CriticalDTM

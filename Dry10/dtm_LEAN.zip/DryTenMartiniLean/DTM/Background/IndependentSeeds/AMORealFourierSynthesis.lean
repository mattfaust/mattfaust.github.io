import DTM.Background.IndependentSeeds.AMODualFourier

/-!
# Real finite Fourier synthesis and exact receiving rows

Real finitely supported coefficients are synthesized in Mathlib's bounded
continuous functions, hence in the uniform norm. The receiving-row residual
and lattice reflection are transported exactly, with no boundary terms dropped.
-/

noncomputable section
namespace CriticalDTM

open scoped BoundedContinuousFunction

/-- Fourier synthesis of real lattice coefficients into complex functions. -/
def seedRealFourierSynthesis : (ℤ →₀ ℝ) →ₗ[ℝ] (ℝ →ᵇ ℂ) :=
  Finsupp.linearCombination ℝ seedFourierMode

@[simp] theorem seedRealFourierSynthesis_single (j : ℤ) (a : ℝ) :
    seedRealFourierSynthesis (Finsupp.single j a) = a • seedFourierMode j :=
  Finsupp.linearCombination_single ℝ a j

/-- Coefficientwise inclusion of a real finite vector in the complex lattice. -/
def seedComplexify : (ℤ →₀ ℝ) →ₗ[ℝ] (ℤ →₀ ℂ) :=
  Finsupp.mapRange.linearMap Complex.ofRealAm.toLinearMap

@[simp] theorem seedComplexify_apply (w : ℤ →₀ ℝ) (j : ℤ) :
    seedComplexify w j = (w j : ℂ) := rfl

@[simp] theorem seedComplexify_single (j : ℤ) (a : ℝ) :
    seedComplexify (Finsupp.single j a) = Finsupp.single j (a : ℂ) :=
  Finsupp.mapRange_single (hf := Complex.ofRealAm.toLinearMap.map_zero)

/-- The real and complex synthesis conventions agree exactly. -/
theorem seedRealFourierSynthesis_eq_complex (w : ℤ →₀ ℝ) :
    seedRealFourierSynthesis w = seedFourierSynthesis (seedComplexify w) := by
  induction w using Finsupp.induction_linear with
  | zero => simp
  | add w v hw hv => simp only [map_add, hw, hv]
  | single j a =>
      ext θ
      simp only [seedRealFourierSynthesis_single, seedComplexify_single,
        seedFourierSynthesis_single, BoundedContinuousFunction.smul_apply,
        Complex.real_smul, smul_eq_mul]

/-- The complex finite dual operator has the expected receiving row. -/
theorem seedDualOperator_apply (α κ lam : ℝ) (w : ℤ →₀ ℂ) (j : ℤ) :
    seedDualOperator α κ lam w j =
      (lam : ℂ) * (w (j - 1) + w (j + 1)) +
        ((2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ) * w j := by
  induction w using Finsupp.induction_linear with
  | zero => simp
  | add w v hw hv =>
      simp only [map_add, Finsupp.add_apply, hw, hv]
      ring
  | single i a =>
      have hm : i - 1 = j ↔ i = j + 1 := by omega
      have hp : i + 1 = j ↔ i = j - 1 := by omega
      simp only [seedDualOperator, Finsupp.linearCombination_single,
        Finsupp.smul_apply, Finsupp.add_apply, Finsupp.single_apply, smul_eq_mul, hm, hp]
      by_cases hij : i = j
      · subst i
        simp only [if_neg (show j ≠ j + 1 by omega),
          if_neg (show j ≠ j - 1 by omega), if_pos (show j = j from rfl), if_true]
        ring
      · simp only [if_neg hij]
        split_ifs <;> ring

/-- An actual real whole-line row residual gives the exact original Fourier
receiving row, including its energy term. -/
theorem seedRealFourierSynthesis_residual (α κ lam E θ : ℝ) (w r : ℤ →₀ ℝ)
    (hrow : ∀ j : ℤ, lam * (w (j - 1) + w (j + 1)) +
      (2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ)) - E) * w j = r j) :
    seedPhase κ * seedRealFourierSynthesis w (θ + 2 * Real.pi * α) +
      seedPhase (-κ) * seedRealFourierSynthesis w (θ - 2 * Real.pi * α) +
      ((2 * lam * Real.cos θ - E : ℝ) : ℂ) * seedRealFourierSynthesis w θ =
        seedRealFourierSynthesis r θ := by
  have hres : seedDualOperator α κ lam (seedComplexify w) -
      (E : ℂ) • seedComplexify w = seedComplexify r := by
    ext j
    simp only [Finsupp.sub_apply, Finsupp.smul_apply, smul_eq_mul,
      seedDualOperator_apply, seedComplexify_apply]
    have h := congrArg (fun x : ℝ => (x : ℂ)) (hrow j)
    push_cast at h ⊢
    linear_combination h
  have h := seedFourierSynthesis_residual α κ lam E θ
    (seedComplexify w) (seedComplexify r) hres
  simp only [← seedRealFourierSynthesis_eq_complex] at h
  push_cast at h ⊢
  linear_combination h

/-- Reflection in lattice coordinates becomes reflection of the original
phase, multiplied by the mode at the reflecting endpoint. -/
theorem seedRealFourierSynthesis_reflection (q : ℤ) (w : ℤ →₀ ℝ) (θ : ℝ) :
    seedRealFourierSynthesis (Finsupp.mapDomain (fun j : ℤ => q - j) w) θ =
      seedFourierMode q θ * seedRealFourierSynthesis w (-θ) := by
  induction w using Finsupp.induction_linear with
  | zero => simp
  | add w v hw hv =>
      simp only [Finsupp.mapDomain_add, map_add, BoundedContinuousFunction.add_apply,
        hw, hv]
      ring
  | single j a =>
      simp only [Finsupp.mapDomain_single, seedRealFourierSynthesis_single,
        BoundedContinuousFunction.smul_apply, Complex.real_smul]
      have hmode : seedFourierMode (q - j) θ =
          seedFourierMode q θ * seedFourierMode j (-θ) := by
        simp only [seedFourierMode_apply, ← seedPhase_add, Int.cast_sub]
        congr 1
        ring
      rw [hmode]
      ring

/-- The same identity in the uniform-norm function space, not only pointwise. -/
theorem seedRealFourierSynthesis_reflection_bcf (q : ℤ) (w : ℤ →₀ ℝ) :
    seedRealFourierSynthesis (Finsupp.mapDomain (fun j : ℤ => q - j) w) =
      seedFourierMode q * (seedRealFourierSynthesis w).compContinuous
        ⟨fun θ : ℝ => -θ, continuous_neg⟩ := by
  ext θ
  exact seedRealFourierSynthesis_reflection q w θ

end CriticalDTM

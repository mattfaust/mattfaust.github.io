import DTM.Background.IndependentSeeds.AMODualFourier
import DTM.Background.IndependentSeeds.SeedFrameAlgebra
import DTM.Background.IndependentSeeds.SeedMatrixFunctions
import DTM.Background.IndependentSeeds.FirstOrderConjugacy
import DTM.Background.IndependentSeeds.AMOUniformFrame

/-!
# Exact finite Fourier residuals give a positive AMO exponent

Two uniformly convergent Fourier columns with exact resonant and small boundary
residuals determine a bounded complex frame. One explicit diagonal correction
removes the oscillatory first-order terms. A constant basis then exposes the
nonzero real hyperbolic coefficient and the actual transfer cone theorem applies.
No finite-volume spectral approximation or determinant normalization is used.
-/

noncomputable section

open Filter Matrix
open scoped Topology Matrix.L2OpNorm BoundedContinuousFunction

namespace CriticalDTM

private theorem resonantPhase_ne_zero (x : ℝ) : seedPhase x ≠ 0 :=
  Complex.exp_ne_zero _

private theorem resonantPhase_neg (x : ℝ) : seedPhase (-x) = (seedPhase x)⁻¹ := by
  simp [seedPhase, neg_mul, Complex.exp_neg]

private theorem resonantMode_neg (q : ℤ) (θ : ℝ) :
    seedFourierMode (-q) θ = (seedFourierMode q θ)⁻¹ := by
  simp [seedFourierMode_apply, resonantPhase_neg]

private theorem resonantMatrix_tendsto
    {ι : Type*} {l : Filter ι} {a b c d : ι → (ℝ →ᵇ ℂ)}
    {a₀ b₀ c₀ d₀ : ℝ →ᵇ ℂ}
    (ha : Tendsto a l (𝓝 a₀)) (hb : Tendsto b l (𝓝 b₀))
    (hc : Tendsto c l (𝓝 c₀)) (hd : Tendsto d l (𝓝 d₀)) :
    Tendsto (fun i => seedMatrixFunction (a i) (b i) (c i) (d i)) l
      (𝓝 (seedMatrixFunction a₀ b₀ c₀ d₀)) := by
  unfold seedMatrixFunction
  apply Tendsto.add
  · apply Tendsto.add
    · apply Tendsto.add
      · exact ha.smul tendsto_const_nhds
      · exact hb.smul tendsto_const_nhds
    · exact hc.smul tendsto_const_nhds
  · exact hd.smul tendsto_const_nhds

/-- The receiving-row frame assembled from two actual Fourier functions. -/
def seedResonantFrame (ω : ℝ) (p : ℂ) (F G : ℝ →ᵇ ℂ) : ℝ →ᵇ AMOTransferMatrix :=
  seedMatrixFunction F G (p⁻¹ • seedFunctionShift (-ω) F)
    (p⁻¹ • seedFunctionShift (-ω) G)

private def resonantFreeFrame (p : ℂ) (q : ℤ) : ℝ →ᵇ AMOTransferMatrix :=
  seedMatrixFunction 1 (seedFourierMode q) (p⁻¹ • 1) (p • seedFourierMode q)

private def resonantFreeInverse (p : ℂ) (q : ℤ) : ℝ →ᵇ AMOTransferMatrix :=
  seedMatrixFunction (BoundedContinuousFunction.const ℝ (p / (p - p⁻¹)))
    (BoundedContinuousFunction.const ℝ (-(1 / (p - p⁻¹))))
    ((-p⁻¹ / (p - p⁻¹)) • seedFourierMode (-q))
    ((1 / (p - p⁻¹)) • seedFourierMode (-q))

private theorem resonantFreeFrame_apply (p : ℂ) (q : ℤ) (θ : ℝ) :
    resonantFreeFrame p q θ = seedFreeFrame p (seedFourierMode q θ) := by
  simp [resonantFreeFrame, seedFreeFrame]

private theorem resonantFreeInverse_apply (p : ℂ) (q : ℤ) (θ : ℝ) :
    resonantFreeInverse p q θ = seedFreeFrameInverse p (seedFourierMode q θ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [resonantFreeInverse, seedFreeFrameInverse, resonantMode_neg, resonantPhase_neg] <;> ring

private theorem resonantFreeFrame_unit {p : ℂ}
    (hD : p - p⁻¹ ≠ 0) (q : ℤ) : IsUnit (resonantFreeFrame p q) := by
  apply seedFunction_isUnit_of_pointwise_inverse _ (resonantFreeInverse p q)
  · intro θ
    rw [resonantFreeFrame_apply, resonantFreeInverse_apply]
    exact seedFreeFrame_mul_inverse (resonantPhase_ne_zero _) hD
  · intro θ
    rw [resonantFreeFrame_apply, resonantFreeInverse_apply]
    exact seedFreeFrame_inverse_mul (resonantPhase_ne_zero _) hD

private theorem resonant_shift_unit (ω : ℝ) {B : ℝ →ᵇ AMOTransferMatrix}
    (hB : IsUnit B) : IsUnit (seedFunctionShift ω B) := by
  apply seedFunction_isUnit_of_pointwise_inverse _ (seedFunctionShift ω (Ring.inverse B))
  · intro θ
    have h := congrArg (fun f : ℝ →ᵇ AMOTransferMatrix => f (θ + ω))
      (Ring.mul_inverse_cancel B hB)
    exact h
  · intro θ
    have h := congrArg (fun f : ℝ →ᵇ AMOTransferMatrix => f (θ + ω))
      (Ring.inverse_mul_cancel B hB)
    exact h

private theorem resonantFree_shift_inverse {p : ℂ}
    (hD : p - p⁻¹ ≠ 0) (q : ℤ) (ω : ℝ) :
    Ring.inverse (seedFunctionShift ω (resonantFreeFrame p q)) =
      seedFunctionShift ω (resonantFreeInverse p q) := by
  apply left_inv_eq_right_inv
    (Ring.inverse_mul_cancel _ (resonant_shift_unit ω (resonantFreeFrame_unit hD q)))
  ext θ : 1
  change resonantFreeFrame p q (θ + ω) * resonantFreeInverse p q (θ + ω) = 1
  rw [resonantFreeFrame_apply, resonantFreeInverse_apply]
  exact seedFreeFrame_mul_inverse (resonantPhase_ne_zero _) hD

private theorem seedResonantFrame_free {p : ℂ} (hp : p ≠ 0) (q : ℤ) (ω : ℝ)
    (hres : seedPhase ((q : ℝ) * ω) = p⁻¹ ^ 2) :
    seedResonantFrame ω p 1 (seedFourierMode q) = resonantFreeFrame p q := by
  have hback (θ : ℝ) : p⁻¹ * seedFourierMode q (θ + -ω) =
      p * seedFourierMode q θ := by
    rw [seedFourierMode_shift, mul_neg, resonantPhase_neg, hres, inv_pow, inv_inv]
    field_simp [hp]
    ring
  ext θ : 1
  simp only [seedResonantFrame, resonantFreeFrame, seedMatrixFunction_apply,
    BoundedContinuousFunction.smul_apply, BoundedContinuousFunction.coe_one,
    Pi.one_apply, seedFunctionShift_apply, smul_eq_mul, mul_one, hback]

private theorem seedResonantFrame_tendsto
    {ι : Type*} {l : Filter ι} {F G : ι → (ℝ →ᵇ ℂ)}
    {p : ℂ} (hp : p ≠ 0) (q : ℤ) (ω : ℝ)
    (hres : seedPhase ((q : ℝ) * ω) = p⁻¹ ^ 2)
    (hF : Tendsto F l (𝓝 1)) (hG : Tendsto G l (𝓝 (seedFourierMode q))) :
    Tendsto (fun i => seedResonantFrame ω p (F i) (G i)) l
      (𝓝 (resonantFreeFrame p q)) := by
  have hF' := (continuous_seedFunctionShift (-ω)).tendsto _ |>.comp hF
  have hG' := (continuous_seedFunctionShift (-ω)).tendsto _ |>.comp hG
  have h := resonantMatrix_tendsto hF hG
    (tendsto_const_nhds (x := p⁻¹) |>.smul hF')
    (tendsto_const_nhds (x := p⁻¹) |>.smul hG')
  change Tendsto (fun i => seedResonantFrame ω p (F i) (G i)) l
    (𝓝 (seedResonantFrame ω p 1 (seedFourierMode q))) at h
  rwa [seedResonantFrame_free hp q ω hres] at h

private def resonantResidual (q L R : ℤ) (a b : ℝ) : ℝ →ᵇ AMOTransferMatrix :=
  seedMatrixFunction ((a : ℂ) • seedFourierMode q + (b : ℂ) • seedFourierMode L)
    ((a : ℂ) • 1 + (b : ℂ) • seedFourierMode R) 0 0

private def resonantGenerator (g : ℂ) (q : ℤ) : ℝ →ᵇ AMOTransferMatrix :=
  seedMatrixFunction (g • seedFourierMode q) (BoundedContinuousFunction.const ℝ g)
    (BoundedContinuousFunction.const ℝ (-g)) ((-g) • seedFourierMode (-q))

private def resonantCorrector (g : ℂ) (q : ℤ) (ρ : ℂ) : ℝ →ᵇ AMOTransferMatrix :=
  seedMatrixFunction ((-g / (1 - ρ)) • seedFourierMode q) 0 0
    ((g / (1 - ρ⁻¹)) • seedFourierMode (-q))

private theorem resonantCorrector_apply (g : ℂ) (q : ℤ) (ρ : ℂ) (θ : ℝ) :
    resonantCorrector g q ρ θ = seedDiagonalCorrector g (seedFourierMode q θ) ρ := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [resonantCorrector, seedDiagonalCorrector, resonantMode_neg, resonantPhase_neg] <;> ring

private theorem resonantCorrector_cancels (g : ℂ) (q : ℤ) (ω : ℝ) {ρ : ℂ}
    (hρ1 : ρ ≠ 1) (hres : seedPhase ((q : ℝ) * ω) = ρ) :
    resonantGenerator g q + resonantCorrector g q ρ -
        seedFunctionShift ω (resonantCorrector g q ρ) =
      BoundedContinuousFunction.const ℝ (!![0, g; -g, 0] : AMOTransferMatrix) := by
  ext θ : 1
  change resonantGenerator g q θ + resonantCorrector g q ρ θ -
    resonantCorrector g q ρ (θ + ω) = _
  rw [add_sub_assoc, resonantCorrector_apply, resonantCorrector_apply,
    seedFourierMode_shift, hres,
    seedDiagonalCorrector_difference hρ1]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [resonantGenerator, resonantMode_neg, resonantPhase_neg]

private theorem resonantRawGenerator {p : ℂ} (hp : p ≠ 0)
    (hD : p - p⁻¹ ≠ 0) (q L R : ℤ) (ω a : ℝ)
    (hres : seedPhase ((q : ℝ) * ω) = p⁻¹ ^ 2) :
    (-p⁻¹) • (Ring.inverse (seedFunctionShift ω (resonantFreeFrame p q)) *
      resonantResidual q L R a 0) = resonantGenerator (-(a : ℂ) / (p - p⁻¹)) q := by
  rw [resonantFree_shift_inverse hD q ω]
  ext θ : 1
  change (-p⁻¹) • (resonantFreeInverse p q (θ + ω) *
    resonantResidual q L R a 0 θ) = _
  have hR : resonantResidual q L R a 0 θ =
      (a : ℂ) • (!![seedFourierMode q θ, 1; 0, 0] : AMOTransferMatrix) := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [resonantResidual]
  rw [hR, mul_smul_comm, smul_comm (-p⁻¹) (a : ℂ), resonantFreeInverse_apply,
    seedFourierMode_shift, hres,
    seedFreeFrame_residual_generator (z := seedFourierMode q θ) hp (resonantPhase_ne_zero _) hD]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [resonantGenerator, resonantMode_neg, resonantPhase_neg] <;> ring

private theorem resonantFrame_receiving_row {p : ℂ} (hp : p ≠ 0)
    (ω lam E u a b : ℝ) (q L R : ℤ) (F G : ℝ →ᵇ ℂ) (θ : ℝ)
    (hF : p * F (θ + ω) + p⁻¹ * F (θ - ω) +
      ((2 * lam * Real.cos θ : ℝ) : ℂ) * F θ - (E : ℂ) * F θ =
        (u : ℂ) * ((a : ℂ) * seedFourierMode q θ + (b : ℂ) * seedFourierMode L θ))
    (hG : p * G (θ + ω) + p⁻¹ * G (θ - ω) +
      ((2 * lam * Real.cos θ : ℝ) : ℂ) * G θ - (E : ℂ) * G θ =
        (u : ℂ) * ((a : ℂ) + (b : ℂ) * seedFourierMode R θ)) :
    amoTransfer lam (E : ℂ) θ * seedResonantFrame ω p F G θ =
      p • seedResonantFrame ω p F G (θ + ω) -
        u • resonantResidual q L R a b θ := by
  simp only [sub_eq_add_neg, seedFourierMode_apply, Complex.ofReal_mul,
    Complex.ofReal_ofNat, Complex.ofReal_cos] at hF hG
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [amoTransfer, seedResonantFrame, resonantResidual, Matrix.mul_apply,
      Fin.sum_univ_two, Complex.real_smul, add_assoc]
  · linear_combination -hF
  · linear_combination -hG
  · exact (mul_inv_cancel_left₀ hp _).symm
  · exact (mul_inv_cancel_left₀ hp _).symm

private theorem resonantPhase_difference (κ : ℝ) :
    seedPhase κ - (seedPhase κ)⁻¹ = ((2 * Real.sin κ : ℝ) : ℂ) * Complex.I := by
  rw [← resonantPhase_neg]
  unfold seedPhase
  rw [Complex.ofReal_neg, Complex.exp_mul_I, Complex.exp_mul_I,
    Complex.cos_neg, Complex.sin_neg]
  simp only [← Complex.ofReal_sin]
  push_cast
  ring

private theorem resonant_coefficient (κ a : ℝ) :
    -(a : ℂ) / (seedPhase κ - (seedPhase κ)⁻¹) =
      ((a / (2 * Real.sin κ) : ℝ) : ℂ) * Complex.I := by
  rw [resonantPhase_difference]
  push_cast
  field_simp [Complex.I_ne_zero]
  ring_nf
  simp [Complex.I_sq]
  ring

private theorem resonant_multiplier_ne_one {p : ℂ} (hp : p ≠ 0)
    (hD : p - p⁻¹ ≠ 0) : p⁻¹ ^ 2 ≠ 1 := by
  intro h
  have h' := congrArg (fun z : ℂ => p * z) h
  have hi : p⁻¹ = p := by
    simpa only [pow_two, ← mul_assoc, mul_inv_cancel₀ hp, one_mul, mul_one] using h'
  exact hD (sub_eq_zero.mpr hi.symm)

private theorem resonant_basis_generator (c : ℝ) :
    seedHyperbolicBasisInverse * !![0, (c : ℂ) * Complex.I; -(c : ℂ) * Complex.I, 0] *
      seedHyperbolicBasis = amoHyperbolicGenerator c := by
  have hM : (!![0, (c : ℂ) * Complex.I; -(c : ℂ) * Complex.I, 0] : AMOTransferMatrix) =
      (c : ℂ) • (!![0, Complex.I; -Complex.I, 0] : AMOTransferMatrix) := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp
  rw [hM, mul_smul_comm, smul_mul_assoc, seedHyperbolicBasis_diagonalizes]
  ext i j
  fin_cases i <;> fin_cases j <;> simp [amoHyperbolicGenerator]

/-- Exact finite Fourier residuals, with a nonzero limiting resonant coefficient
and negligible normalized boundary coefficient, force a positive exponent for
the actual AMO transfer matrices. All function limits are in uniform norm. -/
theorem eventually_amoLyapunov_pos_of_resonant_fourier_residuals
    {ι : Type*} {l : Filter ι} {α κ a₀ : ℝ} {q L R : ℤ}
    {lam E u a b : ι → ℝ} {F G : ι → (ℝ →ᵇ ℂ)}
    (hκ : 0 < κ) (hκπ : κ < Real.pi)
    (hres : seedPhase ((q : ℝ) * (2 * Real.pi * α)) = (seedPhase κ)⁻¹ ^ 2)
    (hu : Tendsto u l (𝓝 0)) (hupos : ∀ᶠ i in l, 0 < u i)
    (ha : Tendsto a l (𝓝 a₀)) (ha₀ : a₀ ≠ 0) (hb : Tendsto b l (𝓝 0))
    (hF : Tendsto F l (𝓝 1)) (hG : Tendsto G l (𝓝 (seedFourierMode q)))
    (hRF : ∀ᶠ i in l, ∀ θ,
      seedPhase κ * F i (θ + 2 * Real.pi * α) +
        seedPhase (-κ) * F i (θ - 2 * Real.pi * α) +
        ((2 * lam i * Real.cos θ : ℝ) : ℂ) * F i θ - (E i : ℂ) * F i θ =
          (u i : ℂ) * ((a i : ℂ) * seedFourierMode q θ +
            (b i : ℂ) * seedFourierMode L θ))
    (hRG : ∀ᶠ i in l, ∀ θ,
      seedPhase κ * G i (θ + 2 * Real.pi * α) +
        seedPhase (-κ) * G i (θ - 2 * Real.pi * α) +
        ((2 * lam i * Real.cos θ : ℝ) : ℂ) * G i θ - (E i : ℂ) * G i θ =
          (u i : ℂ) * ((a i : ℂ) + (b i : ℂ) * seedFourierMode R θ)) :
    ∀ᶠ i in l, 0 < amoLyapunov α (lam i) (E i : ℂ) := by
  let ω : ℝ := 2 * Real.pi * α
  let p : ℂ := seedPhase κ
  have hp : p ≠ 0 := resonantPhase_ne_zero κ
  have hs : 0 < Real.sin κ := Real.sin_pos_of_pos_of_lt_pi hκ hκπ
  have hD : p - p⁻¹ ≠ 0 := by
    dsimp only [p]
    rw [resonantPhase_difference]
    exact mul_ne_zero (Complex.ofReal_ne_zero.mpr (mul_ne_zero two_ne_zero hs.ne'))
      Complex.I_ne_zero
  let g : ℂ := -(a₀ : ℂ) / (p - p⁻¹)
  let c : ℝ := a₀ / (2 * Real.sin κ)
  have hc : c ≠ 0 := div_ne_zero ha₀ (mul_ne_zero two_ne_zero hs.ne')
  have hg : g = (c : ℂ) * Complex.I := resonant_coefficient κ a₀
  let W : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i =>
    seedResonantFrame ω p (F i) (G i)
  let W₀ : ℝ →ᵇ AMOTransferMatrix := resonantFreeFrame p q
  have hWlim : Tendsto W l (𝓝 W₀) := seedResonantFrame_tendsto hp q ω hres hF hG
  have hW₀ : IsUnit W₀ := resonantFreeFrame_unit hD q
  have hWunit : ∀ᶠ i in l, IsUnit (W i) :=
    hWlim.eventually (Units.isOpen.mem_nhds hW₀)
  have hSWlim : Tendsto (fun i => seedFunctionShift ω (W i)) l
      (𝓝 (seedFunctionShift ω W₀)) :=
    (continuous_seedFunctionShift ω).tendsto _ |>.comp hWlim
  have hSW₀ : IsUnit (seedFunctionShift ω W₀) := resonant_shift_unit ω hW₀
  have hinvcont : ContinuousAt Ring.inverse (seedFunctionShift ω W₀) := by
    obtain ⟨v, hv⟩ := hSW₀
    rw [← hv]
    exact NormedRing.inverse_continuousAt v
  have hSWInvlim := hinvcont.tendsto.comp hSWlim
  let T : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => resonantResidual q L R (a i) (b i)
  have ha' : Tendsto (fun i => (a i : ℂ)) l (𝓝 (a₀ : ℂ)) :=
    Complex.continuous_ofReal.tendsto _ |>.comp ha
  have hb' : Tendsto (fun i => (b i : ℂ)) l (𝓝 (0 : ℂ)) := by
    simpa only [Complex.ofReal_zero] using Complex.continuous_ofReal.tendsto 0 |>.comp hb
  have hTlim : Tendsto T l (𝓝 (resonantResidual q L R a₀ 0)) := by
    apply resonantMatrix_tendsto
    · exact (ha'.smul tendsto_const_nhds).add (hb'.smul tendsto_const_nhds)
    · exact (ha'.smul tendsto_const_nhds).add (hb'.smul tendsto_const_nhds)
    · exact tendsto_const_nhds
    · exact tendsto_const_nhds
  let N : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i =>
    (-p⁻¹) • (Ring.inverse (seedFunctionShift ω (W i)) * T i)
  let C : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => 1 + u i • N i
  have hNlim : Tendsto N l (𝓝 (resonantGenerator g q)) := by
    have h := (tendsto_const_nhds (x := -p⁻¹)).smul (hSWInvlim.mul hTlim)
    change Tendsto N l (𝓝 ((-p⁻¹) •
      (Ring.inverse (seedFunctionShift ω W₀) * resonantResidual q L R a₀ 0))) at h
    simpa only [W₀, resonantRawGenerator hp hD q L R ω a₀ hres, g] using h
  have hunz : ∀ᶠ i in l, u i ≠ 0 := hupos.mono fun _ h => ne_of_gt h
  have hClim : Tendsto (fun i => (u i)⁻¹ • (C i - 1)) l
      (𝓝 (resonantGenerator g q)) := by
    apply (tendsto_congr' ?_).2 hNlim
    filter_upwards [hunz] with i hi
    simp only [C, add_sub_cancel_left, smul_smul, inv_mul_cancel₀ hi, one_smul]
  let X : ℝ →ᵇ AMOTransferMatrix := resonantCorrector g q (p⁻¹ ^ 2)
  let Xplus : ℝ →ᵇ AMOTransferMatrix := seedFunctionShift ω X
  let U : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => 1 + u i • X
  let V : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => 1 + u i • Xplus
  let Cnew : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => Ring.inverse (V i) * C i * U i
  have hcancel : resonantGenerator g q + X - Xplus =
      BoundedContinuousFunction.const ℝ (!![0, g; -g, 0] : AMOTransferMatrix) :=
    resonantCorrector_cancels g q ω (resonant_multiplier_ne_one hp hD) hres
  have hCnewlim : Tendsto (fun i => (u i)⁻¹ • (Cnew i - 1)) l
      (𝓝 (BoundedContinuousFunction.const ℝ (!![0, g; -g, 0] : AMOTransferMatrix))) := by
    have h := tendsto_firstOrderConjugacy_normalized hu hunz hClim X Xplus
    change Tendsto (fun i => (u i)⁻¹ • (Cnew i - 1)) l
      (𝓝 (resonantGenerator g q + X - Xplus)) at h
    rwa [hcancel] at h
  let Q : ℝ →ᵇ AMOTransferMatrix := BoundedContinuousFunction.const ℝ seedHyperbolicBasis
  let Qinv : ℝ →ᵇ AMOTransferMatrix :=
    BoundedContinuousFunction.const ℝ seedHyperbolicBasisInverse
  have hQinvQ : Qinv * Q = 1 := by ext θ : 1; exact seedHyperbolicBasis_inverse_mul
  have hQQinv : Q * Qinv = 1 := by ext θ : 1; exact seedHyperbolicBasis_mul_inverse
  let D : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => Qinv * Cnew i * Q
  have hDnorm (i : ι) : (u i)⁻¹ • (D i - 1) =
      Qinv * ((u i)⁻¹ • (Cnew i - 1)) * Q := by
    dsimp only [D]
    rw [mul_smul_comm, smul_mul_assoc]
    congr 1
    rw [mul_sub, sub_mul, mul_one, hQinvQ]
  have htarget : Qinv *
      BoundedContinuousFunction.const ℝ (!![0, g; -g, 0] : AMOTransferMatrix) * Q =
        BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c) := by
    ext θ : 1
    change seedHyperbolicBasisInverse * !![0, g; -g, 0] * seedHyperbolicBasis = _
    rw [hg]
    simpa only [neg_mul] using resonant_basis_generator c
  have hDlim : Tendsto (fun i => (u i)⁻¹ • (D i - 1)) l
      (𝓝 (BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c))) := by
    simpa only [← hDnorm, htarget] using (hCnewlim.const_mul Qinv).mul_const Q
  let B : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => W i * U i * Q
  let Binv : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i =>
    Qinv * Ring.inverse (U i) * Ring.inverse (W i)
  have hUunit : ∀ᶠ i in l, IsUnit (U i) := eventually_isUnit_one_add_smul hu X
  have hVunit : ∀ᶠ i in l, IsUnit (V i) := eventually_isUnit_one_add_smul hu Xplus
  have hinv : ∀ᶠ i in l, ∀ θ, Binv i θ * B i θ = 1 := by
    filter_upwards [hWunit, hUunit] with i hWi hUi
    have heq : Binv i * B i = 1 := by
      change (Qinv * Ring.inverse (U i) * Ring.inverse (W i)) * (W i * U i * Q) = 1
      calc
        _ = Qinv * (Ring.inverse (U i) * ((Ring.inverse (W i) * W i) * U i)) * Q := by
          simp only [mul_assoc]
        _ = 1 := by rw [Ring.inverse_mul_cancel _ hWi, one_mul,
          Ring.inverse_mul_cancel _ hUi, mul_one, hQinvQ]
    intro θ
    exact congrArg (fun f : ℝ →ᵇ AMOTransferMatrix => f θ) heq
  have hframe : ∀ᶠ i in l, ∀ θ,
      amoTransfer (lam i) (E i : ℂ) θ * B i θ =
        p • (B i (θ + 2 * Real.pi * α) * D i θ) := by
    filter_upwards [hWunit, hVunit, hRF, hRG] with i hWi hVi hRFi hRGi
    have hSWi := resonant_shift_unit ω hWi
    have hprod : seedFunctionShift ω (W i) * N i = (-p⁻¹) • T i := by
      dsimp only [N]
      rw [mul_smul_comm, ← mul_assoc, Ring.mul_inverse_cancel _ hSWi, one_mul]
    have hraw : p • (seedFunctionShift ω (W i) * C i) =
        p • seedFunctionShift ω (W i) - u i • T i := by
      dsimp only [C]
      rw [mul_add, mul_one, mul_smul_comm, hprod, smul_add, smul_comm p (u i), smul_smul]
      simp [hp, sub_eq_add_neg]
    have hrawpoint (θ : ℝ) : amoTransfer (lam i) (E i : ℂ) θ * W i θ =
        p • (seedFunctionShift ω (W i) θ * C i θ) := by
      have hFθ := hRFi θ
      have hGθ := hRGi θ
      rw [resonantPhase_neg] at hFθ hGθ
      have hrow := resonantFrame_receiving_row hp ω (lam i) (E i) (u i) (a i) (b i)
        q L R (F i) (G i) θ hFθ hGθ
      change amoTransfer (lam i) (E i : ℂ) θ * W i θ =
        (p • seedFunctionShift ω (W i) - u i • T i) θ at hrow
      rw [← hraw] at hrow
      exact hrow
    have hshiftU : seedFunctionShift ω (U i) = V i := by
      simp only [U, V, Xplus, seedFunctionShift_add, seedFunctionShift_one, seedFunctionShift_smul]
    have hshiftQ : seedFunctionShift ω Q = Q := by ext θ : 1; rfl
    have htrans : seedFunctionShift ω (B i) * D i =
        seedFunctionShift ω (W i) * C i * U i * Q := by
      dsimp only [B, D, Cnew]
      rw [seedFunctionShift_mul, seedFunctionShift_mul, hshiftU, hshiftQ]
      calc
        _ = seedFunctionShift ω (W i) *
            (V i * (Q * Qinv) * Ring.inverse (V i)) * C i * U i * Q := by
          simp only [mul_assoc]
        _ = _ := by rw [hQQinv, mul_one, Ring.mul_inverse_cancel _ hVi, mul_one]
    intro θ
    change amoTransfer (lam i) (E i : ℂ) θ * (W i θ * U i θ * Q θ) =
      p • ((seedFunctionShift ω (B i) * D i) θ)
    rw [htrans]
    change amoTransfer (lam i) (E i : ℂ) θ * (W i θ * U i θ * Q θ) =
      p • ((seedFunctionShift ω (W i) θ * C i θ) * U i θ * Q θ)
    calc
      _ = (amoTransfer (lam i) (E i : ℂ) θ * W i θ) * U i θ * Q θ := by
        simp only [mul_assoc]
      _ = _ := by rw [hrawpoint θ, smul_mul_assoc, smul_mul_assoc]
  exact eventually_amoLyapunov_pos_of_signed_uniform_frame_limit
    hc (seedPhase_norm κ) hu hupos hDlim hinv hframe

end CriticalDTM

import DTM.Background.IndependentSeeds.AMOFreeIDS
import DTM.Background.IndependentSeeds.AMOPrincipalResonance
import DTM.Background.SpectralVanishing.AMOSpectralLyapunov
import DTM.Background.Labels.MagneticLabelProperties

/-!
# Labelled small-coupling gaps from a positive Lyapunov curve

A continuous genuine resolvent curve approaching an interior free resonance
has the explicit free label. The actual exterior IDS values then force spectral
points on both sides and supply the full bounded gap containing the curve.

For irrational frequency and couplings at most one, the proved vanishing of the
actual Lyapunov exponent on the spectrum converts a positive-exponent curve to
such a resolvent curve. Positivity and existence of this curve are still explicit
hypotheses; this module does not prove a perturbative seed or invoke a noncritical
Dry Ten Martini theorem.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

/-- A right-hand resolvent curve has full labelled gaps at every point and every
phase, including actual spectral endpoints and the given energy in the interior. -/
theorem amo_labelled_gap_of_resolvent_curve
    {α κ ε : ℝ} (hα : Irrational α) (hκ0 : 0 < κ) (hκpi : κ < Real.pi)
    (hε0 : 0 < ε) (e : ℝ → ℝ) (hcont : ContinuousOn e (Ioo 0 ε))
    (hlim : Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (2 * Real.cos κ)))
    (hres : ∀ lam ∈ Ioo (0 : ℝ) ε, (lam, e lam) ∈ realJointResolventDomain α) :
    ∀ lam ∈ Ioo (0 : ℝ) ε, ∀ θ : ℝ, ∃ a b : ℝ,
      IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam θ)
        (almostMathieuIDS α lam) (1 - κ / Real.pi) a b ∧ e lam ∈ Ioo a b := by
  letI : PreconnectedSpace (Ioo (0 : ℝ) ε) :=
    isPreconnected_iff_preconnectedSpace.mp isPreconnected_Ioo
  let p : Ioo (0 : ℝ) ε → ℝ × ℝ := fun t => (t.1, e t.1)
  have hpcont : Continuous p := continuous_subtype_val.prodMk hcont.restrict
  let v : ℕ → ℝ := fun j => ε / ((j : ℝ) + 2)
  have hv (j : ℕ) : v j ∈ Ioo (0 : ℝ) ε := by
    have hj : 0 < (j : ℝ) + 2 := by positivity
    constructor
    · exact div_pos hε0 hj
    · apply (div_lt_iff₀ hj).mpr
      nlinarith [mul_nonneg hε0.le (Nat.cast_nonneg j)]
  have hv0 : Tendsto v atTop (𝓝 0) := by
    have h := (tendsto_add_atTop_iff_nat 2).2 (tendsto_const_div_atTop_nhds_zero_nat ε)
    simpa only [v, Nat.cast_add, Nat.cast_ofNat] using h
  have hvright : Tendsto v atTop (𝓝[>] (0 : ℝ)) :=
    tendsto_nhdsWithin_iff.mpr ⟨hv0, Eventually.of_forall (fun j => (hv j).1)⟩
  let u : ℕ → Ioo (0 : ℝ) ε := fun j => ⟨v j, hv j⟩
  have hplim : Tendsto (fun j => p (u j)) atTop (𝓝 (0, 2 * Real.cos κ)) :=
    hv0.prodMk_nhds (hlim.comp hvright)
  have hlabel (lam : ℝ) (hlam : lam ∈ Ioo (0 : ℝ) ε) :
      magneticLowerMass α lam (e lam) = 1 - κ / Real.pi :=
    magneticLowerMass_eq_free_of_resolvent_curve α hκ0 hκpi p hpcont
      (fun t => hres t.1 t.2) u hplim ⟨lam, hlam⟩
  have hinterior : 1 - κ / Real.pi ∈ Ioo (0 : ℝ) 1 := by
    have hpos := div_pos hκ0 Real.pi_pos
    have hlt := (div_lt_one Real.pi_pos).mpr hκpi
    constructor <;> linarith
  intro lam hlam θ
  have hnot : e lam ∉ magneticRealSpectrumSet α lam :=
    spectrum.not_mem_iff.mpr (hres lam hlam)
  obtain ⟨a, b, hgap, hin, hlabels⟩ := exists_labelled_spectral_gap
    (magneticRealSpectrumSet_isClosed α lam)
    (magneticLowerMass_locallyConstantOff α lam)
    (magneticLowerMass_hasExteriorLabels α lam) hnot (hlabel lam hlam) hinterior
  have hIDS : almostMathieuIDS α lam = magneticLowerMass α lam :=
    (funext (magneticLowerMass_eq_almostMathieuIDS α lam)).symm
  refine ⟨a, b, ?_, hin⟩
  simpa only [almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα, hIDS] using
    (show IsLabelledSpectralGap (magneticRealSpectrumSet α lam)
      (magneticLowerMass α lam) (1 - κ / Real.pi) a b from ⟨hgap, hlabels⟩)

/-- Positive actual Lyapunov exponent below critical coupling excludes the
actual spectrum. Combined with the free limit, it supplies the full labelled gap. -/
theorem amo_labelled_gap_of_positive_lyapunov_curve
    {α κ ε : ℝ} (hα : Irrational α) (hκ0 : 0 < κ) (hκpi : κ < Real.pi)
    (hε0 : 0 < ε) (hε1 : ε ≤ 1) (e : ℝ → ℝ) (hcont : ContinuousOn e (Ioo 0 ε))
    (hlim : Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (2 * Real.cos κ)))
    (hpos : ∀ lam ∈ Ioo (0 : ℝ) ε, 0 < amoLyapunov α lam (e lam : ℂ)) :
    ∀ lam ∈ Ioo (0 : ℝ) ε, ∀ θ : ℝ, ∃ a b : ℝ,
      IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam θ)
        (almostMathieuIDS α lam) (1 - κ / Real.pi) a b ∧ e lam ∈ Ioo a b := by
  apply amo_labelled_gap_of_resolvent_curve hα hκ0 hκpi hε0 e hcont hlim
  intro lam hlam
  apply spectrum.not_mem_iff.mp
  intro hspec
  have hz := amoLyapunov_eq_zero_of_mem_magneticSpectrum hα hlam.1
    (hlam.2.le.trans hε1) hspec
  exact (ne_of_gt (hpos lam hlam)) hz

/-- At the principal arithmetic resonance the full gaps carry exactly the
specified integer label, not its complement. -/
theorem amo_labelled_gap_of_positive_lyapunov_principal_curve
    {α ε : ℝ} (hα : Irrational α) {n : ℤ} (hn : n ≠ 0)
    (hε0 : 0 < ε) (hε1 : ε ≤ 1) (e : ℝ → ℝ) (hcont : ContinuousOn e (Ioo 0 ε))
    (hlim : Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (2 * Real.cos (amoPrincipalKappa α n))))
    (hpos : ∀ lam ∈ Ioo (0 : ℝ) ε, 0 < amoLyapunov α lam (e lam : ℂ)) :
    ∀ lam ∈ Ioo (0 : ℝ) ε, ∀ θ : ℝ, ∃ a b : ℝ,
      IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam θ)
        (almostMathieuIDS α lam) (arithmeticGapLabel α n) a b ∧ e lam ∈ Ioo a b := by
  simpa only [amoPrincipalKappa_label, arithmeticGapLabel] using
    amo_labelled_gap_of_positive_lyapunov_curve hα
      (amoPrincipalKappa_pos hα hn) (amoPrincipalKappa_lt_pi hα hn)
      hε0 hε1 e hcont hlim hpos

/-- One positive-exponent curve at a principal resonance supplies arbitrarily
small genuine seeds at every phase. No seed-persistence theorem is used here. -/
theorem amo_small_seeds_of_positive_lyapunov_curve
    {α ε : ℝ} (hα : Irrational α) {n : ℤ} (hn : n ≠ 0)
    (hε0 : 0 < ε) (hε1 : ε ≤ 1) (e : ℝ → ℝ) (hcont : ContinuousOn e (Ioo 0 ε))
    (hlim : Tendsto e (𝓝[>] (0 : ℝ)) (𝓝 (2 * Real.cos (amoPrincipalKappa α n))))
    (hpos : ∀ lam ∈ Ioo (0 : ℝ) ε, 0 < amoLyapunov α lam (e lam : ℂ)) :
    ∀ δ : ℝ, 0 < δ → ∃ s : ℝ, 0 < s ∧ s < δ ∧ ∀ θ : ℝ, ∃ a b : ℝ,
      IsLabelledSpectralGap (almostMathieuRealSpectrumSet α s θ)
        (almostMathieuIDS α s) (arithmeticGapLabel α n) a b ∧ e s ∈ Ioo a b := by
  intro δ hδ
  let s : ℝ := min ε δ / 2
  have hm : 0 < min ε δ := lt_min hε0 hδ
  have hs0 : 0 < s := half_pos hm
  have hsε : s < ε := (half_lt_self hm).trans_le (min_le_left ε δ)
  have hsδ : s < δ := (half_lt_self hm).trans_le (min_le_right ε δ)
  refine ⟨s, hs0, hsδ, ?_⟩
  exact amo_labelled_gap_of_positive_lyapunov_principal_curve hα hn
    hε0 hε1 e hcont hlim hpos s ⟨hs0, hsε⟩

end CriticalDTM

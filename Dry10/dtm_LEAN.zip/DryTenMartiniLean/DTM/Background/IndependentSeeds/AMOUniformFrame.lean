import DTM.Background.IndependentSeeds.AMOHyperbolicCone
import Mathlib.Topology.ContinuousMap.Bounded.Normed

/-!
# Uniform first-order frame limits give positive actual AMO exponents

A bounded-continuous matrix family with normalized first-order limit
`diag(c,-c)`, where `c > 0`, is eventually near the expanding diagonal.
The bounded-continuous norm provides uniform endpoint frame bounds, so the
complex cone criterion applies.  Filters need not be nontrivial, and no
periodicity of the bounded-continuous frames is required.
-/

noncomputable section

open Filter Matrix
open scoped Topology Matrix Matrix.L2OpNorm BoundedContinuousFunction

namespace CriticalDTM

/-- The constant first-order hyperbolic generator, as a complex matrix. -/
def amoHyperbolicGenerator (c : ℝ) : AMOTransferMatrix :=
  !![(c : ℂ), 0; 0, -(c : ℂ)]

theorem amoHyperbolicDiagonal_eq_one_add_smul (t c : ℝ) :
    amoHyperbolicDiagonal (t * c) = 1 + t • amoHyperbolicGenerator c := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [amoHyperbolicDiagonal, amoHyperbolicGenerator, Matrix.one_apply,
      Complex.real_smul]
  ring

/-- Uniform norm control on the normalized error gives all four entrywise
 remainder bounds required by the cone theorem. -/
theorem amoNearDiagonal_of_uniform_normalized_error
    {t c : ℝ} (ht : 0 < t) (C : ℝ →ᵇ AMOTransferMatrix)
    (herror : ‖t⁻¹ • (C - 1) -
      BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c)‖ ≤ c / 16) :
    ∀ θ, AMONearDiagonal (t * c) (C θ) := by
  let R : ℝ →ᵇ AMOTransferMatrix := t⁻¹ • (C - 1) -
    BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c)
  intro θ i j
  have heq : C θ - amoHyperbolicDiagonal (t * c) = t • R θ := by
    change C θ - amoHyperbolicDiagonal (t * c) =
      t • (t⁻¹ • (C θ - 1) - amoHyperbolicGenerator c)
    rw [smul_sub, smul_smul, mul_inv_cancel₀ (ne_of_gt ht), one_smul,
      amoHyperbolicDiagonal_eq_one_add_smul]
    abel
  calc
    ‖C θ i j - amoHyperbolicDiagonal (t * c) i j‖ ≤
        amoTransferNorm (C θ - amoHyperbolicDiagonal (t * c)) :=
      norm_entry_le_amoTransferNorm (C θ - amoHyperbolicDiagonal (t * c)) i j
    _ = t * ‖R θ‖ := by
      rw [heq]
      change ‖t • R θ‖ = t * ‖R θ‖
      rw [norm_smul, Real.norm_eq_abs, abs_of_pos ht]
    _ ≤ t * ‖R‖ := mul_le_mul_of_nonneg_left (R.norm_coe_le_norm θ) ht.le
    _ ≤ t * (c / 16) := mul_le_mul_of_nonneg_left herror ht.le
    _ = t * c / 16 := by ring

/-- A genuine uniform first-order limit supplies an eventual positive cone
 parameter and uniform near-diagonal estimates. -/
theorem eventually_amoNearDiagonal_of_uniform_frame_limit
    {ι : Type*} {l : Filter ι} {c : ℝ} {t : ι → ℝ}
    {C : ι → (ℝ →ᵇ AMOTransferMatrix)}
    (hc : 0 < c) (ht : Tendsto t l (𝓝 0))
    (htpos : ∀ᶠ i in l, 0 < t i)
    (hlimit : Tendsto (fun i => (t i)⁻¹ • (C i - 1)) l
      (𝓝 (BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c)))) :
    ∀ᶠ i in l, 0 < t i * c ∧ t i * c ≤ 1 / 2 ∧
      ∀ θ, AMONearDiagonal (t i * c) (C i θ) := by
  have hscale : Tendsto (fun i => t i * c) l (𝓝 0) := by
    simpa only [zero_mul] using ht.mul_const c
  have hsmall : ∀ᶠ i in l, t i * c < 1 / 2 :=
    hscale.eventually (eventually_lt_nhds (by norm_num : (0 : ℝ) < 1 / 2))
  have hnorm : Tendsto (fun i => ‖(t i)⁻¹ • (C i - 1) -
      BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c)‖) l (𝓝 0) := by
    simpa only [sub_self, norm_zero] using
      (hlimit.sub_const (BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c))).norm
  have herror : ∀ᶠ i in l, ‖(t i)⁻¹ • (C i - 1) -
      BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c)‖ < c / 16 :=
    hnorm.eventually (eventually_lt_nhds (by positivity : (0 : ℝ) < c / 16))
  filter_upwards [htpos, hsmall, herror] with i hi hsi hei
  exact ⟨mul_pos hi hc, hsi.le, amoNearDiagonal_of_uniform_normalized_error hi (C i) hei.le⟩

/-- A uniform first-order hyperbolic frame limit implies eventual positivity
 of the actual AMO Lyapunov exponent.  The frame bounds may depend on `i`;
 only their uniformity in the real phase is needed. -/
theorem eventually_amoLyapunov_pos_of_uniform_frame_limit
    {ι : Type*} {l : Filter ι} {α c : ℝ} {lam E t : ι → ℝ} {ε : ℂ}
    {B Binv C : ι → (ℝ →ᵇ AMOTransferMatrix)}
    (hc : 0 < c) (hε : ‖ε‖ = 1) (ht : Tendsto t l (𝓝 0))
    (htpos : ∀ᶠ i in l, 0 < t i)
    (hlimit : Tendsto (fun i => (t i)⁻¹ • (C i - 1)) l
      (𝓝 (BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c))))
    (hinv : ∀ᶠ i in l, ∀ θ, Binv i θ * B i θ = 1)
    (hframe : ∀ᶠ i in l, ∀ θ,
      amoTransfer (lam i) (E i : ℂ) θ * B i θ =
        ε • (B i (θ + 2 * Real.pi * α) * C i θ)) :
    ∀ᶠ i in l, 0 < amoLyapunov α (lam i) (E i : ℂ) := by
  have hnear := eventually_amoNearDiagonal_of_uniform_frame_limit hc ht htpos hlimit
  filter_upwards [hnear, hinv, hframe] with i hi hinvi hframei
  let K : ℝ := max ‖B i‖ ‖Binv i‖ + 1
  have hB : ∀ θ, amoTransferNorm (B i θ) ≤ K := by
    intro θ
    change ‖B i θ‖ ≤ K
    exact ((B i).norm_coe_le_norm θ).trans (by
      dsimp only [K]
      linarith [le_max_left ‖B i‖ ‖Binv i‖])
  have hBinv : ∀ θ, amoTransferNorm (Binv i θ) ≤ K := by
    intro θ
    change ‖Binv i θ‖ ≤ K
    exact ((Binv i).norm_coe_le_norm θ).trans (by
      dsimp only [K]
      linarith [le_max_right ‖B i‖ ‖Binv i‖])
  exact amoLyapunov_pos_of_nearDiagonal_frame hi.1 hi.2.1 hε hinvi hB hBinv hframei hi.2.2

/-- The fixed interchange of the two complex coordinates. -/
private def amoUniformFrameSwap : AMOTransferMatrix := !![0, 1; 1, 0]

private theorem amoUniformFrameSwap_mul_self :
    amoUniformFrameSwap * amoUniformFrameSwap = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [amoUniformFrameSwap, Matrix.mul_apply, Fin.sum_univ_two]

private theorem amoUniformFrameSwap_generator (c : ℝ) :
    amoUniformFrameSwap * amoHyperbolicGenerator c * amoUniformFrameSwap =
      amoHyperbolicGenerator (-c) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [amoUniformFrameSwap, amoHyperbolicGenerator, Matrix.mul_apply, Fin.sum_univ_two]

/-- The first-order diagonal coefficient may have either nonzero sign.
 A fixed coordinate interchange handles the negative sign inside the proof. -/
theorem eventually_amoLyapunov_pos_of_signed_uniform_frame_limit
    {ι : Type*} {l : Filter ι} {α c : ℝ} {lam E t : ι → ℝ} {ε : ℂ}
    {B Binv C : ι → (ℝ →ᵇ AMOTransferMatrix)}
    (hc : c ≠ 0) (hε : ‖ε‖ = 1) (ht : Tendsto t l (𝓝 0))
    (htpos : ∀ᶠ i in l, 0 < t i)
    (hlimit : Tendsto (fun i => (t i)⁻¹ • (C i - 1)) l
      (𝓝 (BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c))))
    (hinv : ∀ᶠ i in l, ∀ θ, Binv i θ * B i θ = 1)
    (hframe : ∀ᶠ i in l, ∀ θ,
      amoTransfer (lam i) (E i : ℂ) θ * B i θ =
        ε • (B i (θ + 2 * Real.pi * α) * C i θ)) :
    ∀ᶠ i in l, 0 < amoLyapunov α (lam i) (E i : ℂ) := by
  rcases lt_or_gt_of_ne hc with hc | hc
  · let P : ℝ →ᵇ AMOTransferMatrix :=
      BoundedContinuousFunction.const ℝ amoUniformFrameSwap
    let B' : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => B i * P
    let Binv' : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => P * Binv i
    let C' : ι → (ℝ →ᵇ AMOTransferMatrix) := fun i => P * C i * P
    have hPP : P * P = 1 := by
      apply BoundedContinuousFunction.ext
      intro θ
      exact amoUniformFrameSwap_mul_self
    have heq (i : ι) :
        (t i)⁻¹ • (C' i - 1) = P * ((t i)⁻¹ • (C i - 1)) * P := by
      dsimp only [C']
      rw [mul_smul_comm, smul_mul_assoc]
      congr 1
      rw [mul_sub, sub_mul, mul_one, hPP]
    have htarget : P * BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator c) * P =
        BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator (-c)) := by
      apply BoundedContinuousFunction.ext
      intro θ
      exact amoUniformFrameSwap_generator c
    have hlimit' : Tendsto (fun i => (t i)⁻¹ • (C' i - 1)) l
        (𝓝 (BoundedContinuousFunction.const ℝ (amoHyperbolicGenerator (-c)))) := by
      simpa only [← heq, htarget] using (hlimit.const_mul P).mul_const P
    have hinv' : ∀ᶠ i in l, ∀ θ, Binv' i θ * B' i θ = 1 := by
      filter_upwards [hinv] with i hi
      intro θ
      change (amoUniformFrameSwap * Binv i θ) * (B i θ * amoUniformFrameSwap) = 1
      calc
        _ = amoUniformFrameSwap * (Binv i θ * B i θ) * amoUniformFrameSwap := by
          simp only [mul_assoc]
        _ = 1 := by rw [hi θ, mul_one, amoUniformFrameSwap_mul_self]
    have hframe' : ∀ᶠ i in l, ∀ θ,
        amoTransfer (lam i) (E i : ℂ) θ * B' i θ =
          ε • (B' i (θ + 2 * Real.pi * α) * C' i θ) := by
      filter_upwards [hframe] with i hi
      intro θ
      change amoTransfer (lam i) (E i : ℂ) θ * (B i θ * amoUniformFrameSwap) =
        ε • ((B i (θ + 2 * Real.pi * α) * amoUniformFrameSwap) *
          ((amoUniformFrameSwap * C i θ) * amoUniformFrameSwap))
      rw [← mul_assoc, hi θ, smul_mul_assoc]
      congr 1
      simp only [mul_assoc]
      rw [← mul_assoc amoUniformFrameSwap amoUniformFrameSwap,
        amoUniformFrameSwap_mul_self, one_mul]
    exact eventually_amoLyapunov_pos_of_uniform_frame_limit
      (by linarith : 0 < -c) hε ht htpos hlimit' hinv' hframe'
  · exact eventually_amoLyapunov_pos_of_uniform_frame_limit hc hε ht htpos hlimit hinv hframe

end CriticalDTM

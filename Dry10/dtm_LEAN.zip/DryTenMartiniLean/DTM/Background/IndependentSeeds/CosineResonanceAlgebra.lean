import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Irrational
import Mathlib.Algebra.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Lean.Elab.Tactic.Omega

/-!
# Finite cosine-resonance algebra

This file proves only finite algebraic identities and nonvanishing statements
for proposed perturbative coefficients at each irrational frequency and each
fixed positive integer order. No Diophantine hypothesis is used.

These coefficients are not identified with a spectral gap width or a cocycle
normal form. The actual finite-order normal-form construction, remainder
estimates, and IDS-label identification remain to be supplied.
-/

namespace CriticalDTM

/-- No nonzero integer multiple of an irrational frequency is a sine zero. -/
theorem sin_pi_mul_irrational_int_ne_zero {α : ℝ} (hα : Irrational α)
    {j : ℤ} (hj : j ≠ 0) : Real.sin (Real.pi * α * (j : ℝ)) ≠ 0 := by
  intro hz
  obtain ⟨k, hk⟩ := Real.sin_eq_zero_iff.mp hz
  apply (hα.intCast_mul hj).ne_int k
  apply mul_left_cancel₀ Real.pi_ne_zero
  calc
    Real.pi * ((j : ℝ) * α) = Real.pi * α * (j : ℝ) := by ring
    _ = (k : ℝ) * Real.pi := hk.symm
    _ = Real.pi * (k : ℝ) := mul_comm _ _

/-- The exact factorization of a finite cosine-resonance denominator. -/
theorem cosine_resonance_factorization (α : ℝ) (n j : ℤ) :
    2 * Real.cos (Real.pi * α * (n : ℝ)) -
      2 * Real.cos (Real.pi * α * ((2 * j - n : ℤ) : ℝ)) =
        -4 * Real.sin (Real.pi * α * (j : ℝ)) *
          Real.sin (Real.pi * α * ((n - j : ℤ) : ℝ)) := by
  have hsum : (Real.pi * α * (n : ℝ) +
      Real.pi * α * ((2 * j - n : ℤ) : ℝ)) / 2 =
        Real.pi * α * (j : ℝ) := by push_cast; ring
  have hdiff : (Real.pi * α * (n : ℝ) -
      Real.pi * α * ((2 * j - n : ℤ) : ℝ)) / 2 =
        Real.pi * α * ((n - j : ℤ) : ℝ) := by push_cast; ring
  calc
    _ = 2 * (Real.cos (Real.pi * α * (n : ℝ)) -
        Real.cos (Real.pi * α * ((2 * j - n : ℤ) : ℝ))) := by ring
    _ = _ := by rw [Real.cos_sub_cos, hsum, hdiff]; ring

/-- Every denominator away from the two resonant indices is nonzero. -/
theorem cosine_resonance_denominator_ne_zero {α : ℝ} (hα : Irrational α)
    {n j : ℤ} (hj : j ≠ 0) (hnj : n - j ≠ 0) :
    2 * Real.cos (Real.pi * α * (n : ℝ)) -
      2 * Real.cos (Real.pi * α * ((2 * j - n : ℤ) : ℝ)) ≠ 0 := by
  rw [cosine_resonance_factorization]
  exact mul_ne_zero (mul_ne_zero (by norm_num)
    (sin_pi_mul_irrational_int_ne_zero hα hj))
      (sin_pi_mul_irrational_int_ne_zero hα hnj)

end CriticalDTM

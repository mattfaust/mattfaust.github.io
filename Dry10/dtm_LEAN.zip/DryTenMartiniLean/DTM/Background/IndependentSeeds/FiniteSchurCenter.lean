import DTM.Background.Support.ImplicitBranch
import Mathlib.Analysis.Calculus.ContDiff.RCLike
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.Ring

/-!
# An exact finite Schur center

This is an application of the ordinary scalar implicit-function theorem to
`(E - E₀) A(λ,E) - λ² B(λ,E)`. In finite Jacobi applications `A` is the
product of two finite determinants and `B` the corresponding cofactor sum.
It constructs an exact continuous center, not a formal power series and not
an inverse of an infinite complementary operator.
-/

noncomputable section
namespace CriticalDTM

open Filter Set
open scoped Topology

/-- A nonzero finite denominator and smooth numerator give a genuine local
center with zero derivative at the uncoupled point. All conclusions hold on
one fixed open coupling interval containing zero. -/
theorem exists_exact_quadratic_center
    (E₀ : ℝ) (A B : ℝ × ℝ → ℝ)
    (hA : ContDiff ℝ 1 A) (hB : ContDiff ℝ 1 B)
    (hA₀ : A (0, E₀) ≠ 0) :
    ∃ ε : ℝ, 0 < ε ∧ ∃ e : ℝ → ℝ,
      e 0 = E₀ ∧ HasDerivAt e 0 0 ∧
      ContinuousOn e (Ioo (-ε) ε) ∧
      ∀ lam ∈ Ioo (-ε) ε,
        A (lam, e lam) ≠ 0 ∧
        (e lam - E₀) * A (lam, e lam) = lam ^ 2 * B (lam, e lam) ∧
        e lam - E₀ = lam ^ 2 * (B (lam, e lam) / A (lam, e lam)) := by
  let F : ℝ × ℝ → ℝ := fun p => (p.2 - E₀) * A p - p.1 ^ 2 * B p
  have hF : ContDiff ℝ 1 F := by
    exact ((contDiff_snd.sub contDiff_const).mul hA).sub
      ((contDiff_fst.pow 2).mul hB)
  have hbase : HasFDerivAt F
      (A (0, E₀) • ContinuousLinearMap.snd ℝ ℝ ℝ) (0, E₀) := by
    have hs := (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt (x := (0, E₀))
    have ht := (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt (x := (0, E₀))
    have ha := (hA.differentiable (by norm_num)).differentiableAt.hasFDerivAt
      (x := (0, E₀))
    have hb := (hB.differentiable (by norm_num)).differentiableAt.hasFDerivAt
      (x := (0, E₀))
    have h := ((hs.sub_const E₀).mul ha).sub ((ht.mul ht).mul hb)
    simpa [F, pow_two] using h
  have hD : fderiv ℝ F (0, E₀) (0, 1) ≠ 0 := by
    rw [hbase.fderiv]
    simpa using hA₀
  have hcoord : Continuous (fun p : ℝ × ℝ => fderiv ℝ F p (0, 1)) := by
    exact (hF.continuous_fderiv (by norm_num)).clm_apply continuous_const
  have hnear : ∀ᶠ p in 𝓝 (0, E₀),
      HasFDerivAt F (fderiv ℝ F p) p ∧ fderiv ℝ F p (0, 1) ≠ 0 := by
    filter_upwards [hcoord.continuousAt.eventually_ne hD] with p hp
    exact ⟨(hF.differentiable (by norm_num)).differentiableAt.hasFDerivAt, hp⟩
  obtain ⟨e, he₀, heder, _, hgraph, hzero, _⟩ :=
    exists_local_zero_branch_differentiable
      (hF.contDiffAt.hasStrictFDerivAt (by norm_num))
      (by simp [F] : F (0, E₀) = 0) hD hnear
  have heder₀ : HasDerivAt e 0 0 := by
    simpa [hbase.fderiv] using heder
  have hnonzero : ∀ᶠ lam in 𝓝 (0 : ℝ), A (lam, e lam) ≠ 0 :=
    hgraph.eventually (hA.continuous.continuousAt.eventually_ne hA₀)
  obtain ⟨ε, hε, hball⟩ := Metric.eventually_nhds_iff.mp (hzero.and hnonzero)
  have hmem {lam : ℝ} (hlam : lam ∈ Ioo (-ε) ε) : dist lam 0 < ε := by
    rw [Real.dist_eq, sub_zero, abs_lt]
    exact hlam
  refine ⟨ε, hε, e, he₀, heder₀, ?_, ?_⟩
  · intro lam hlam
    exact ((hball (hmem hlam)).1.2.continuousAt).continuousWithinAt
  · intro lam hlam
    obtain ⟨⟨hz, _⟩, hn⟩ := hball (hmem hlam)
    have hEq : (e lam - E₀) * A (lam, e lam) = lam ^ 2 * B (lam, e lam) :=
      sub_eq_zero.mp hz
    refine ⟨hn, hEq, ?_⟩
    apply (eq_div_iff hn).mpr at hEq
    simpa only [mul_div_assoc] using hEq

end CriticalDTM

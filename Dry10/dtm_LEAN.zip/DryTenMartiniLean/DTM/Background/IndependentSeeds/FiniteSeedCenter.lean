import DTM.Background.IndependentSeeds.FiniteSeedVectors
import DTM.Background.IndependentSeeds.FiniteSchurCenter
import DTM.Background.IndependentSeeds.AMOPrincipalResonance

/-!
# A genuine centered energy for the finite cosine resonance

All four functions entering the scalar Schur equation are actual finite
Jacobi determinants (the empty deleted middle contributes zero). A polynomial
implicit-function argument provides one continuous centered energy on a fixed
coupling interval. The interval may depend on the frequency and the label.
No limit of finite spectra, infinite complementary inverse, or seed hypothesis
is used to construct this finite center.
-/

noncomputable section
namespace CriticalDTM

open Set Filter
open scoped Topology

/-- Smoothness of the actual left branch determinant. -/
theorem contDiff_seedLeftDet (d : ℤ → ℝ) (k : ℕ) :
    ContDiff ℝ 1 (fun p : ℝ × ℝ => seedLeftDet d k p.1 p.2) := by
  exact contDiff_weightedJacobiDet
    (fun p : ℝ × ℝ => fun j => p.2 - d (-((j : ℤ) + 1)))
    (fun p => p.1) (fun _ => contDiff_snd.sub contDiff_const) contDiff_fst (k + 1)

/-- Smoothness of the actual middle branch determinant, including an empty middle. -/
theorem contDiff_seedMiddleDet (d : ℤ → ℝ) (k : ℕ) :
    ContDiff ℝ 1 (fun p : ℝ × ℝ => seedMiddleDet d k p.1 p.2) := by
  exact contDiff_weightedJacobiDet
    (fun p : ℝ × ℝ => fun j => p.2 - d ((j : ℤ) + 1))
    (fun p => p.1) (fun _ => contDiff_snd.sub contDiff_const) contDiff_fst k

theorem contDiff_seedLeftTailDet (d : ℤ → ℝ) (k : ℕ) :
    ContDiff ℝ 1 (fun p : ℝ × ℝ => seedLeftTailDet d k p.1 p.2) := by
  simp only [seedLeftTailDet, seedTailDet]
  exact contDiff_weightedJacobiDet _ _
    (fun _ => contDiff_snd.sub contDiff_const) contDiff_fst k

theorem contDiff_seedMiddleTailDet (d : ℤ → ℝ) (k : ℕ) :
    ContDiff ℝ 1 (fun p : ℝ × ℝ => seedMiddleTailDet d k p.1 p.2) := by
  cases k with
  | zero => simpa only [seedMiddleTailDet, seedTailDet] using
      (contDiff_const : ContDiff ℝ 1 (fun _ : ℝ × ℝ => (0 : ℝ)))
  | succ k =>
      simp only [seedMiddleTailDet, seedTailDet]
      exact contDiff_weightedJacobiDet _ _
        (fun _ => contDiff_snd.sub contDiff_const) contDiff_fst k

theorem seedLeftDet_zero_ne (d : ℤ → ℝ) (k : ℕ)
    (h : ∀ j : Fin (k + 1), d 0 - d (-((j.val : ℤ) + 1)) ≠ 0) :
    seedLeftDet d k 0 (d 0) ≠ 0 := by
  rw [seedLeftDet, weightedJacobiDet_zero_bond]
  exact Finset.prod_ne_zero_iff.mpr (fun j _ => h j)

theorem seedMiddleDet_zero_ne (d : ℤ → ℝ) (k : ℕ)
    (h : ∀ j : Fin k, d 0 - d ((j.val : ℤ) + 1) ≠ 0) :
    seedMiddleDet d k 0 (d 0) ≠ 0 := by
  rw [seedMiddleDet, weightedJacobiDet_zero_bond]
  exact Finset.prod_ne_zero_iff.mpr (fun j _ => h j)

/-- The exact finite center exists from finite diagonal nonresonance alone. -/
theorem exists_seed_finite_center (d : ℤ → ℝ) (k : ℕ)
    (hL : ∀ j : Fin (k + 1), d 0 - d (-((j.val : ℤ) + 1)) ≠ 0)
    (hM : ∀ j : Fin k, d 0 - d ((j.val : ℤ) + 1) ≠ 0) :
    ∃ ε : ℝ, 0 < ε ∧ ∃ e : ℝ → ℝ,
      e 0 = d 0 ∧ HasDerivAt e 0 0 ∧ ContinuousAt e 0 ∧
      ContinuousOn e (Ioo (-ε) ε) ∧
      ∀ lam ∈ Ioo (-ε) ε,
        seedLeftDet d k lam (e lam) ≠ 0 ∧
        seedMiddleDet d k lam (e lam) ≠ 0 ∧
        (e lam - d 0) * (seedLeftDet d k lam (e lam) * seedMiddleDet d k lam (e lam)) =
          lam ^ 2 * (seedLeftTailDet d k lam (e lam) * seedMiddleDet d k lam (e lam) +
            seedMiddleTailDet d k lam (e lam) * seedLeftDet d k lam (e lam)) := by
  let A : ℝ × ℝ → ℝ := fun p => seedLeftDet d k p.1 p.2 * seedMiddleDet d k p.1 p.2
  let B : ℝ × ℝ → ℝ := fun p =>
    seedLeftTailDet d k p.1 p.2 * seedMiddleDet d k p.1 p.2 +
      seedMiddleTailDet d k p.1 p.2 * seedLeftDet d k p.1 p.2
  have hA : ContDiff ℝ 1 A := (contDiff_seedLeftDet d k).mul (contDiff_seedMiddleDet d k)
  have hB : ContDiff ℝ 1 B :=
    ((contDiff_seedLeftTailDet d k).mul (contDiff_seedMiddleDet d k)).add
      ((contDiff_seedMiddleTailDet d k).mul (contDiff_seedLeftDet d k))
  obtain ⟨ε, hε, e, he, hder, hcont, hcenter⟩ :=
    exists_exact_quadratic_center (d 0) A B hA hB
      (mul_ne_zero (seedLeftDet_zero_ne d k hL) (seedMiddleDet_zero_ne d k hM))
  refine ⟨ε, hε, e, he, hder, hder.continuousAt, hcont, ?_⟩
  intro lam hlam
  obtain ⟨hn, hEq, _⟩ := hcenter lam hlam
  exact ⟨(mul_ne_zero_iff.mp hn).1, (mul_ne_zero_iff.mp hn).2, hEq⟩

/-- Irrational cosine supplies all finite nonresonance hypotheses, with the
actual principal-phase sign retained. -/
theorem exists_cosine_seed_finite_center {α κ : ℝ} (hα : Irrational α)
    (k : ℕ) {ℓ : ℤ}
    (hres : κ + Real.pi * α * (((k : ℤ) + 1 : ℤ) : ℝ) = Real.pi * (ℓ : ℝ)) :
    let d : ℤ → ℝ := fun j => 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ))
    ∃ ε : ℝ, 0 < ε ∧ ∃ e : ℝ → ℝ,
      e 0 = 2 * Real.cos κ ∧ HasDerivAt e 0 0 ∧ ContinuousAt e 0 ∧
      ContinuousOn e (Ioo (-ε) ε) ∧
      ∀ lam ∈ Ioo (-ε) ε,
        seedLeftDet d k lam (e lam) ≠ 0 ∧
        seedMiddleDet d k lam (e lam) ≠ 0 ∧
        (e lam - d 0) * (seedLeftDet d k lam (e lam) * seedMiddleDet d k lam (e lam)) =
          lam ^ 2 * (seedLeftTailDet d k lam (e lam) * seedMiddleDet d k lam (e lam) +
            seedMiddleTailDet d k lam (e lam) * seedLeftDet d k lam (e lam)) := by
  dsimp only
  have hL (j : Fin (k + 1)) :
      2 * Real.cos κ -
        2 * Real.cos (κ + 2 * Real.pi * α * ((-((j.val : ℤ) + 1) : ℤ) : ℝ)) ≠ 0 :=
    cosine_phase_resonance_denominator_ne_zero hα hres (by omega) (by omega)
  have hM (j : Fin k) :
      2 * Real.cos κ -
        2 * Real.cos (κ + 2 * Real.pi * α * (((j.val : ℤ) + 1 : ℤ) : ℝ)) ≠ 0 :=
    cosine_phase_resonance_denominator_ne_zero hα hres (by omega) (by have hj := j.isLt; omega)
  simpa only [Int.cast_zero, mul_zero, add_zero] using
    exists_seed_finite_center (fun j : ℤ => 2 * Real.cos (κ + 2 * Real.pi * α * (j : ℝ))) k
      (by simpa only [Int.cast_zero, mul_zero, add_zero] using hL)
      (by simpa only [Int.cast_zero, mul_zero, add_zero] using hM)

/-- After division by the leading `lam^(k+1)`, the resonant coefficient
approaches a nonzero finite constant, while the boundary coefficient vanishes.
These are limits of finite rational functions, not thermodynamic spectral limits. -/
theorem seed_normalized_coefficients_tendsto
    {ι : Type*} {l : Filter ι} (d : ℤ → ℝ) (k : ℕ)
    {lam e : ι → ℝ} (hlam : Tendsto lam l (𝓝 0)) (he : Tendsto e l (𝓝 (d 0)))
    (hL : seedLeftDet d k 0 (d 0) ≠ 0) (hM : seedMiddleDet d k 0 (d 0) ≠ 0) :
    Tendsto (fun i => (seedMiddleDet d k (lam i) (e i))⁻¹) l
      (𝓝 ((seedMiddleDet d k 0 (d 0))⁻¹)) ∧
    Tendsto (fun i => lam i / seedLeftDet d k (lam i) (e i)) l (𝓝 0) := by
  have hp := hlam.prodMk_nhds he
  have hleft := (contDiff_seedLeftDet d k).continuous.continuousAt.tendsto.comp hp
  have hmiddle := (contDiff_seedMiddleDet d k).continuous.continuousAt.tendsto.comp hp
  refine ⟨hmiddle.inv₀ hM, ?_⟩
  simpa only [zero_div] using hlam.div hleft hL

end CriticalDTM

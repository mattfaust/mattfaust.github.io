import DTM.Background.IndependentSeeds.AMORealFourierSynthesis
import DTM.Background.IndependentSeeds.FiniteSeedVectors

/-!
# Uniform limits of the actual finite seed vectors

For a fixed finite pair of branches, convergence of the coupling to zero and
of the energy to `E₀`, together with nonzero limiting branch determinants,
forces every driven coefficient to zero. Fourier synthesis therefore tends
to the constant root mode, and synthesis of its reflected partner tends to
the mode at the other physical root. All limits are in the bounded-continuous
function norm, hence uniform in the original radian phase.

The selected energy and its convergence are hypotheses; this file does not
construct a spectral center or prove a spectral gap.
-/

noncomputable section
namespace CriticalDTM

open Filter
open scoped Topology BigOperators BoundedContinuousFunction

private theorem tendsto_seed_branch_det {X : Type*} {l : Filter X}
    (d : ℕ → ℝ) {lam E : X → ℝ} {E₀ : ℝ}
    (hlam : Tendsto lam l (𝓝 0)) (hE : Tendsto E l (𝓝 E₀)) (m : ℕ) :
    Tendsto (fun x => weightedJacobiDet (fun j => E x - d j) (lam x) m) l
      (𝓝 (weightedJacobiDet (fun j => E₀ - d j) 0 m)) := by
  have hc : Continuous (fun p : ℝ × ℝ =>
      weightedJacobiDet (fun j => p.2 - d j) p.1 m) :=
    continuous_weightedJacobiDet
      (fun p : ℝ × ℝ => fun j => p.2 - d j) (fun p : ℝ × ℝ => p.1)
      (fun _ => continuous_snd.sub continuous_const) continuous_fst m
  have hp : Tendsto (fun x => (lam x, E x)) l (𝓝 ((0 : ℝ), E₀)) :=
    hlam.prodMk_nhds hE
  simpa only [Function.comp_def] using (hc.tendsto ((0 : ℝ), E₀)).comp hp

/-- Each actual determinant-quotient driven coefficient tends to zero. -/
theorem seedDrivenColumn_tendsto_zero {X : Type*} {l : Filter X}
    (d : ℕ → ℝ) (m : ℕ) {lam E : X → ℝ} {E₀ : ℝ}
    (hlam : Tendsto lam l (𝓝 0)) (hE : Tendsto E l (𝓝 E₀))
    (hdet : weightedJacobiDet (fun j => E₀ - d j) 0 m ≠ 0) (i : Fin m) :
    Tendsto (fun x => seedDrivenColumn (fun j => E x - d j) (lam x) m i) l (𝓝 0) := by
  have hnum := (hlam.pow (i.val + 1)).mul
    (tendsto_seed_branch_det (fun j => d (j + i.val + 1)) hlam hE (m - i.val - 1))
  have hquot := hnum.div (tendsto_seed_branch_det d hlam hE m) hdet
  simpa [seedDrivenColumn] using hquot

/-- Synthesis of the actual right branch is the finite sum on sites `1,...,m`. -/
theorem seedRealFourierSynthesis_seedRightBranch (d : ℤ → ℝ) (m : ℕ) (lam E : ℝ) :
    seedRealFourierSynthesis (seedRightBranch d m lam E) =
      ∑ i : Fin m, seedDrivenColumn (fun j => E - d ((j : ℤ) + 1)) lam m i •
        seedFourierMode ((i.val : ℤ) + 1) := by
  unfold seedRightBranch seedColumnFinsupp
  rw [Finsupp.equivMapDomain_eq_mapDomain]
  simp only [Finsupp.mapDomain_finset_sum, Finsupp.mapDomain_single,
    map_sum, seedRealFourierSynthesis_single]
  rfl

/-- The lattice reflection used by the finite vectors is the same Fourier reflection. -/
theorem seedRealFourierSynthesis_seedReflect (q : ℤ) (w : ℤ →₀ ℝ) :
    seedRealFourierSynthesis (seedReflect q w) =
      seedFourierMode q * (seedRealFourierSynthesis w).compContinuous
        ⟨fun θ : ℝ => -θ, continuous_neg⟩ := by
  unfold seedReflect
  rw [Finsupp.equivMapDomain_eq_mapDomain]
  exact seedRealFourierSynthesis_reflection_bcf q w

/-- Reflection preserves uniform convergence, with its fixed physical mode factor. -/
theorem seedRealFourierSynthesis_tendsto_seedReflect {X : Type*} {l : Filter X}
    (q : ℤ) (w : X → ℤ →₀ ℝ) {f : ℝ →ᵇ ℂ}
    (hw : Tendsto (fun x => seedRealFourierSynthesis (w x)) l (𝓝 f)) :
    Tendsto (fun x => seedRealFourierSynthesis (seedReflect q (w x))) l
      (𝓝 (seedFourierMode q * f.compContinuous ⟨fun θ : ℝ => -θ, continuous_neg⟩)) := by
  have hc : Continuous (fun g : ℝ →ᵇ ℂ => seedFourierMode q *
      g.compContinuous ⟨fun θ : ℝ => -θ, continuous_neg⟩) :=
    continuous_const.mul (BoundedContinuousFunction.continuous_compContinuous _)
  simpa only [seedRealFourierSynthesis_seedReflect] using (hc.tendsto f).comp hw

/-- A fixed driven branch tends to zero in uniform Fourier norm. -/
theorem seedRightBranch_synthesis_tendsto_zero {X : Type*} {l : Filter X}
    (d : ℤ → ℝ) (m : ℕ) {lam E : X → ℝ} {E₀ : ℝ}
    (hlam : Tendsto lam l (𝓝 0)) (hE : Tendsto E l (𝓝 E₀))
    (hdet : weightedJacobiDet (fun j => E₀ - d ((j : ℤ) + 1)) 0 m ≠ 0) :
    Tendsto (fun x => seedRealFourierSynthesis (seedRightBranch d m (lam x) (E x)))
      l (𝓝 0) := by
  simp_rw [seedRealFourierSynthesis_seedRightBranch]
  have h := tendsto_finset_sum Finset.univ (fun (i : Fin m) _ =>
    (seedDrivenColumn_tendsto_zero (fun j => d ((j : ℤ) + 1)) m hlam hE hdet i).smul
      (tendsto_const_nhds (x := seedFourierMode ((i.val : ℤ) + 1))))
  simpa only [zero_smul, Finset.sum_const_zero] using h

/-- The complete finite vector, with both actual branches, tends uniformly to `1`. -/
theorem seedFiniteVector_synthesis_tendsto_one {X : Type*} {l : Filter X}
    (d : ℤ → ℝ) (k : ℕ) {lam E : X → ℝ} {E₀ : ℝ}
    (hlam : Tendsto lam l (𝓝 0)) (hE : Tendsto E l (𝓝 E₀))
    (hleft : seedLeftDet d k 0 E₀ ≠ 0) (hmiddle : seedMiddleDet d k 0 E₀ ≠ 0) :
    Tendsto (fun x => seedRealFourierSynthesis (seedFiniteVector d k (lam x) (E x)))
      l (𝓝 1) := by
  have hl := seedRightBranch_synthesis_tendsto_zero (fun j => d (-j)) (k + 1)
    hlam hE (by simpa only [seedLeftDet] using hleft)
  have hr := seedRightBranch_synthesis_tendsto_zero d k hlam hE
    (by simpa only [seedMiddleDet] using hmiddle)
  have hrl := seedRealFourierSynthesis_tendsto_seedReflect 0
    (fun x => seedRightBranch (fun j => d (-j)) (k + 1) (lam x) (E x)) hl
  have hrl0 : Tendsto (fun x => seedRealFourierSynthesis
      (seedReflect 0 (seedRightBranch (fun j => d (-j)) (k + 1) (lam x) (E x))))
      l (𝓝 0) := by simpa using hrl
  have h := ((tendsto_const_nhds (x := (1 : ℝ →ᵇ ℂ))).add hrl0).add hr
  simpa only [seedFiniteVector, map_add, seedRealFourierSynthesis_single,
    one_smul, seedFourierMode_zero, add_zero] using h

/-- Its actual reflected partner tends uniformly to the mode at `q=k+1`. -/
theorem seedReflectedFiniteVector_synthesis_tendsto_mode {X : Type*} {l : Filter X}
    (d : ℤ → ℝ) (k : ℕ) {lam E : X → ℝ} {E₀ : ℝ}
    (hlam : Tendsto lam l (𝓝 0)) (hE : Tendsto E l (𝓝 E₀))
    (hleft : seedLeftDet d k 0 E₀ ≠ 0) (hmiddle : seedMiddleDet d k 0 E₀ ≠ 0) :
    Tendsto (fun x => seedRealFourierSynthesis
      (seedReflectedFiniteVector d k (lam x) (E x)))
      l (𝓝 (seedFourierMode ((k : ℤ) + 1))) := by
  have h := seedRealFourierSynthesis_tendsto_seedReflect ((k : ℤ) + 1)
    (fun x => seedFiniteVector d k (lam x) (E x))
    (seedFiniteVector_synthesis_tendsto_one d k hlam hE hleft hmiddle)
  simpa [seedReflectedFiniteVector] using h

end CriticalDTM

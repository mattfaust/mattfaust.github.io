import DTM.Background.IndependentSeeds.WeightedJacobi
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Interval
import Mathlib.Tactic.FieldSimp

/-!
# Explicit finite two-center determinant vectors

Finite Jacobi endpoint columns are embedded in the actual integer lattice.
All residual identities use the receiving row `H - E`; no finite block is
silently substituted for the whole-line operator.
-/

noncomputable section

namespace CriticalDTM

open Matrix
open scoped BigOperators

/-- Extend a finite column by zero to the integer lattice. -/
def seedColumnFinsupp {m : ℕ} (a : Fin m → ℝ) : ℤ →₀ ℝ :=
  ∑ i : Fin m, Finsupp.single (i.val : ℤ) (a i)

theorem seedColumnFinsupp_apply {m : ℕ} (a : Fin m → ℝ) (j : ℤ) :
    seedColumnFinsupp a j = ∑ i : Fin m, if (i.val : ℤ) = j then a i else 0 := by
  simp [seedColumnFinsupp, Finsupp.finset_sum_apply, Finsupp.single_apply]

@[simp] theorem seedColumnFinsupp_apply_fin {m : ℕ} (a : Fin m → ℝ) (i : Fin m) :
    seedColumnFinsupp a (i.val : ℤ) = a i := by
  rw [seedColumnFinsupp_apply]
  simp only [Int.natCast_inj, Fin.val_inj]
  simp

theorem seedColumnFinsupp_outside {m : ℕ} (a : Fin m → ℝ) (j : ℤ)
    (hj : j < 0 ∨ (m : ℤ) ≤ j) : seedColumnFinsupp a j = 0 := by
  rw [seedColumnFinsupp_apply]
  apply Finset.sum_eq_zero
  intro i _
  have hi := i.isLt
  have hne : (i.val : ℤ) ≠ j := by omega
  simp [hne]

/-- The actual tridiagonal matrix row is the zero-extended receiving row. -/
theorem weightedJacobiMatrix_mulVec_row (d : ℕ → ℝ) (c : ℝ) (m : ℕ)
    (a : Fin m → ℝ) (i : Fin m) :
    (weightedJacobiMatrix d c m *ᵥ a) i =
      d i.val * a i - c *
        (seedColumnFinsupp a ((i.val : ℤ) - 1) +
          seedColumnFinsupp a ((i.val : ℤ) + 1)) := by
  have hentry (j : Fin m) : weightedJacobiMatrix d c m i j * a j =
      (if i = j then d i.val * a j else 0) -
        c * (if (j.val : ℤ) = (i.val : ℤ) - 1 then a j else 0) -
        c * (if (j.val : ℤ) = (i.val : ℤ) + 1 then a j else 0) := by
    have hleft : (j.val : ℤ) = (i.val : ℤ) - 1 ↔ j.val + 1 = i.val := by omega
    have hright : (j.val : ℤ) = (i.val : ℤ) + 1 ↔ i.val + 1 = j.val := by omega
    by_cases hij : i = j
    · subst j
      simp [weightedJacobiMatrix, hleft, hright]
    · simp only [weightedJacobiMatrix, if_neg hij, hleft, hright]
      split_ifs <;> first | omega | ring
  simp only [Matrix.mulVec, dotProduct, hentry, Finset.sum_sub_distrib,
    ← Finset.mul_sum, Finset.sum_ite_eq, Finset.mem_univ, if_true]
  rw [seedColumnFinsupp_apply, seedColumnFinsupp_apply]
  ring

/-- Determinant with the first site removed; the empty branch contributes zero. -/
def seedTailDet (a : ℕ → ℝ) (c : ℝ) : ℕ → ℝ
  | 0 => 0
  | n + 1 => weightedJacobiDet (fun j => a (j + 1)) c n

/-- Driven branch coefficients, valid also on the empty finite type. -/
def seedDrivenColumn (a : ℕ → ℝ) (c : ℝ) (m : ℕ) : Fin m → ℝ :=
  fun i => c ^ (i.val + 1) *
    weightedJacobiDet (fun j => a (j + i.val + 1)) c (m - i.val - 1) /
      weightedJacobiDet a c m

theorem seedDrivenColumn_succ (a : ℕ → ℝ) (c : ℝ) (n : ℕ) :
    seedDrivenColumn a c (n + 1) =
      c • ((weightedJacobiMatrix a c (n + 1)).det⁻¹ •
        weightedJacobiEndpointColumn a c n) := by
  ext i
  have hlen : n + 1 - i.val - 1 = n - i.val := by omega
  simp only [seedDrivenColumn]
  rw [hlen]
  simp only [Pi.smul_apply, smul_eq_mul, weightedJacobiEndpointColumn,
    weightedJacobiDet, div_eq_mul_inv, pow_succ]
  ring

/-- The driven finite branch has source `c` at its near endpoint. -/
theorem seedDrivenColumn_residual (a : ℕ → ℝ) (c : ℝ) (n : ℕ)
    (hdet : weightedJacobiDet a c (n + 1) ≠ 0) :
    weightedJacobiMatrix a c (n + 1) *ᵥ seedDrivenColumn a c (n + 1) =
      Pi.single (0 : Fin (n + 1)) c := by
  rw [seedDrivenColumn_succ, Matrix.mulVec_smul,
    weightedJacobiEndpointColumn_normalized_residual a c n hdet]
  ext i
  simp [Pi.single_apply]

@[simp] theorem seedDrivenColumn_zero (a : ℕ → ℝ) (c : ℝ) (n : ℕ) :
    seedDrivenColumn a c (n + 1) 0 =
      c * seedTailDet a c (n + 1) / weightedJacobiDet a c (n + 1) := by
  simp [seedDrivenColumn, seedTailDet]

@[simp] theorem seedDrivenColumn_last (a : ℕ → ℝ) (c : ℝ) (n : ℕ) :
    seedDrivenColumn a c (n + 1) (Fin.last n) =
      c ^ (n + 1) / weightedJacobiDet a c (n + 1) := by
  simp only [seedDrivenColumn, Fin.val_last]
  rw [show n + 1 - n - 1 = 0 by omega, weightedJacobiDet_zero, mul_one]

private def seedShiftEquiv : ℤ ≃ ℤ where
  toFun j := j + 1
  invFun j := j - 1
  left_inv j := by dsimp; omega
  right_inv j := by dsimp; omega

private def seedReflectEquiv (q : ℤ) : ℤ ≃ ℤ where
  toFun j := q - j
  invFun j := q - j
  left_inv j := by dsimp; omega
  right_inv j := by dsimp; omega

/-- Reflection retains the actual lattice coordinates. -/
def seedReflect (q : ℤ) (w : ℤ →₀ ℝ) : ℤ →₀ ℝ :=
  Finsupp.equivMapDomain (seedReflectEquiv q) w

@[simp] theorem seedReflect_apply (q : ℤ) (w : ℤ →₀ ℝ) (j : ℤ) :
    seedReflect q w j = w (q - j) := by
  rw [seedReflect, Finsupp.equivMapDomain_apply]
  rfl

/-- The right branch occupies the physical sites `1,...,m`. -/
def seedRightBranch (d : ℤ → ℝ) (m : ℕ) (lam E : ℝ) : ℤ →₀ ℝ :=
  Finsupp.equivMapDomain seedShiftEquiv
    (seedColumnFinsupp (seedDrivenColumn (fun i => E - d ((i : ℤ) + 1)) lam m))

theorem seedRightBranch_apply (d : ℤ → ℝ) (m : ℕ) (lam E : ℝ) (j : ℤ) :
    seedRightBranch d m lam E j =
      seedColumnFinsupp (seedDrivenColumn (fun i => E - d ((i : ℤ) + 1)) lam m)
        (j - 1) := by
  rw [seedRightBranch, Finsupp.equivMapDomain_apply]
  rfl

/-- The receiving row of `H - E` on the whole integer lattice. -/
def seedFiniteResidual (d : ℤ → ℝ) (lam E : ℝ) (w : ℤ →₀ ℝ) (j : ℤ) : ℝ :=
  lam * (w (j - 1) + w (j + 1)) + (d j - E) * w j

/-- Left branch determinant, at sites `-1,...,-(k+1)`. -/
def seedLeftDet (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ) : ℝ :=
  weightedJacobiDet (fun j => E - d (-((j : ℤ) + 1))) lam (k + 1)

/-- Middle branch determinant, at sites `1,...,k`. -/
def seedMiddleDet (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ) : ℝ :=
  weightedJacobiDet (fun j => E - d ((j : ℤ) + 1)) lam k

/-- Left determinant after removing the near endpoint. -/
def seedLeftTailDet (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ) : ℝ :=
  seedTailDet (fun j => E - d (-((j : ℤ) + 1))) lam (k + 1)

/-- Middle determinant after removing the near endpoint; zero for an empty middle. -/
def seedMiddleTailDet (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ) : ℝ :=
  seedTailDet (fun j => E - d ((j : ℤ) + 1)) lam k

/-- The root has value one, with one driven branch on each physical side. -/
def seedFiniteVector (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ) : ℤ →₀ ℝ :=
  Finsupp.single 0 1 +
    seedReflect 0 (seedRightBranch (fun j => d (-j)) (k + 1) lam E) +
      seedRightBranch d k lam E

/-- Its reflected partner is centered at the physical site `q=k+1`. -/
def seedReflectedFiniteVector (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ) : ℤ →₀ ℝ :=
  seedReflect ((k : ℤ) + 1) (seedFiniteVector d k lam E)

theorem seedRightBranch_outside (d : ℤ → ℝ) (m : ℕ) (lam E : ℝ) (j : ℤ)
    (hj : j ≤ 0 ∨ (m : ℤ) < j) : seedRightBranch d m lam E j = 0 := by
  rw [seedRightBranch_apply]
  apply seedColumnFinsupp_outside
  omega

theorem seedRightBranch_residual_fin (d : ℤ → ℝ) (n : ℕ) (lam E : ℝ)
    (hdet : weightedJacobiDet (fun i => E - d ((i : ℤ) + 1)) lam (n + 1) ≠ 0)
    (i : Fin (n + 1)) :
    seedFiniteResidual d lam E (seedRightBranch d (n + 1) lam E) ((i.val : ℤ) + 1) =
      -((Pi.single 0 lam : Fin (n + 1) → ℝ) i) := by
  let a : ℕ → ℝ := fun r => E - d ((r : ℤ) + 1)
  have hrow := congrFun (seedDrivenColumn_residual a lam n hdet) i
  rw [weightedJacobiMatrix_mulVec_row] at hrow
  simp only [seedFiniteResidual, seedRightBranch_apply]
  rw [show ((i.val : ℤ) + 1) - 1 - 1 = (i.val : ℤ) - 1 by omega,
    show ((i.val : ℤ) + 1) + 1 - 1 = (i.val : ℤ) + 1 by omega,
    show ((i.val : ℤ) + 1) - 1 = (i.val : ℤ) by omega,
    seedColumnFinsupp_apply_fin]
  dsimp only [a] at hrow
  linear_combination -hrow

theorem seedFiniteResidual_add (d : ℤ → ℝ) (lam E : ℝ)
    (u v : ℤ →₀ ℝ) (j : ℤ) :
    seedFiniteResidual d lam E (u + v) j =
      seedFiniteResidual d lam E u j + seedFiniteResidual d lam E v j := by
  simp only [seedFiniteResidual, Finsupp.add_apply]
  ring

/-- Reflection exchanges the two physical bonds, including the source equation. -/
theorem seedFiniteResidual_reflect (d : ℤ → ℝ) (lam E : ℝ)
    (q : ℤ) (w : ℤ →₀ ℝ) (j : ℤ) :
    seedFiniteResidual d lam E (seedReflect q w) j =
      seedFiniteResidual (fun r => d (q - r)) lam E w (q - j) := by
  simp only [seedFiniteResidual, seedReflect_apply]
  rw [show q - (q - j) = j by omega,
    show q - (j - 1) = (q - j) + 1 by omega,
    show q - (j + 1) = (q - j) - 1 by omega]
  ring

theorem seedFiniteResidual_single (d : ℤ → ℝ) (lam E : ℝ) (r j : ℤ) :
    seedFiniteResidual d lam E (Finsupp.single r 1) j =
      Finsupp.single (r - 1) lam j + Finsupp.single r (d r - E) j +
        Finsupp.single (r + 1) lam j := by
  simp only [seedFiniteResidual, Finsupp.single_apply]
  by_cases h : r = j
  · subst j
    have hm : r - 1 ≠ r := by omega
    have hp : r + 1 ≠ r := by omega
    simp [hm, hp, Ne.symm hm, Ne.symm hp]
  · have hminus : r = j - 1 ↔ r + 1 = j := by omega
    have hplus : r = j + 1 ↔ r - 1 = j := by omega
    simp only [hminus, hplus, if_neg h]
    split_ifs <;> ring

/-- The two nonzero branch determinants are the only denominators used. -/
theorem seedCenterResidual_zero (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ)
    (hL : seedLeftDet d k lam E ≠ 0) (hM : seedMiddleDet d k lam E ≠ 0)
    (hcenter : (E - d 0) * seedLeftDet d k lam E * seedMiddleDet d k lam E =
      lam ^ 2 * (seedLeftTailDet d k lam E * seedMiddleDet d k lam E +
        seedMiddleTailDet d k lam E * seedLeftDet d k lam E)) :
    d 0 - E + lam ^ 2 * seedLeftTailDet d k lam E / seedLeftDet d k lam E +
      lam ^ 2 * seedMiddleTailDet d k lam E / seedMiddleDet d k lam E = 0 := by
  field_simp [hL, hM]
  nlinarith [hcenter]

@[simp] theorem seedRightBranch_one (d : ℤ → ℝ) (n : ℕ) (lam E : ℝ) :
    seedRightBranch d (n + 1) lam E 1 =
      lam * seedTailDet (fun i => E - d ((i : ℤ) + 1)) lam (n + 1) /
        weightedJacobiDet (fun i => E - d ((i : ℤ) + 1)) lam (n + 1) := by
  rw [seedRightBranch_apply]
  change seedColumnFinsupp _ ((0 : Fin (n + 1)).val : ℤ) = _
  rw [seedColumnFinsupp_apply_fin, seedDrivenColumn_zero]

@[simp] theorem seedRightBranch_last (d : ℤ → ℝ) (n : ℕ) (lam E : ℝ) :
    seedRightBranch d (n + 1) lam E ((n + 1 : ℕ) : ℤ) =
      lam ^ (n + 1) / weightedJacobiDet (fun i => E - d ((i : ℤ) + 1)) lam (n + 1) := by
  rw [seedRightBranch_apply]
  rw [show ((n + 1 : ℕ) : ℤ) - 1 = (n : ℤ) by omega]
  change seedColumnFinsupp _ ((Fin.last n).val : ℤ) = _
  rw [seedColumnFinsupp_apply_fin, seedDrivenColumn_last]

/-- A branch's whole-line residual includes both omitted boundary bonds.
For length zero, its two source terms cancel at the same site. -/
theorem seedRightBranch_residual (d : ℤ → ℝ) (m : ℕ) (lam E : ℝ)
    (hdet : weightedJacobiDet (fun i => E - d ((i : ℤ) + 1)) lam m ≠ 0) (j : ℤ) :
    seedFiniteResidual d lam E (seedRightBranch d m lam E) j =
      -(Finsupp.single 1 lam j) +
        Finsupp.single 0 (lam ^ 2 * seedTailDet (fun i => E - d ((i : ℤ) + 1)) lam m /
          weightedJacobiDet (fun i => E - d ((i : ℤ) + 1)) lam m) j +
        Finsupp.single ((m : ℤ) + 1)
          (lam ^ (m + 1) / weightedJacobiDet (fun i => E - d ((i : ℤ) + 1)) lam m) j := by
  cases m with
  | zero =>
      have hb : seedRightBranch d 0 lam E = 0 := by
        ext r
        apply seedRightBranch_outside
        omega
      simp [hb, seedFiniteResidual, seedTailDet]
  | succ n =>
      by_cases hzero : j = 0
      · subst j
        have hm := seedRightBranch_outside d (n + 1) lam E (-1) (by omega)
        have hz := seedRightBranch_outside d (n + 1) lam E 0 (by omega)
        have hfar : ((n + 1 : ℕ) : ℤ) + 1 ≠ 0 := by omega
        have hfar' : (n : ℤ) + 1 + 1 ≠ 0 := by omega
        simp [seedFiniteResidual, hm, hz, Finsupp.single_apply, hfar, hfar']
        ring
      by_cases hfar : j = ((n + 1 : ℕ) : ℤ) + 1
      · subst j
        have hz := seedRightBranch_outside d (n + 1) lam E
          (((n + 1 : ℕ) : ℤ) + 1) (by omega)
        have hp := seedRightBranch_outside d (n + 1) lam E
          ((((n + 1 : ℕ) : ℤ) + 1) + 1) (by omega)
        rw [seedFiniteResidual,
          show (((n + 1 : ℕ) : ℤ) + 1) - 1 = ((n + 1 : ℕ) : ℤ) by omega,
          hz, hp, seedRightBranch_last]
        have h1 : (1 : ℤ) ≠ ((n + 1 : ℕ) : ℤ) + 1 := by omega
        have h0 : (0 : ℤ) ≠ ((n + 1 : ℕ) : ℤ) + 1 := by omega
        simp only [Finsupp.single_apply, if_neg h1, if_neg h0, if_pos rfl,
          mul_zero, add_zero, neg_zero, zero_add]
        rw [pow_succ]
        ring_nf
        simp
      have hfar' : (n : ℤ) + 1 + 1 ≠ j := by omega
      by_cases hin : 1 ≤ j ∧ j ≤ ((n + 1 : ℕ) : ℤ)
      · let i : Fin (n + 1) := ⟨(j - 1).toNat, by omega⟩
        have hi : (i.val : ℤ) + 1 = j := by dsimp [i]; omega
        have hrow := seedRightBranch_residual_fin d n lam E hdet i
        rw [hi] at hrow
        rw [hrow]
        by_cases hi0 : i = 0
        · have hj1 : j = 1 := by simpa [hi0] using hi.symm
          rw [hj1]
          have hf1 : (n : ℤ) + 1 + 1 ≠ (1 : ℤ) := by omega
          simp [hi0, Pi.single_apply, Finsupp.single_apply, hf1]
        · have hj1 : (1 : ℤ) ≠ j := by
            intro hj
            apply hi0
            apply Fin.ext
            have : i.val = 0 := by omega
            exact this
          simp [Pi.single_apply, hi0, Ne.symm hi0, Finsupp.single_apply,
            hj1, Ne.symm hzero, Ne.symm hfar, hfar']
      · have hm : j - 1 ≤ 0 ∨ ((n + 1 : ℕ) : ℤ) < j - 1 := by omega
        have hp : j + 1 ≤ 0 ∨ ((n + 1 : ℕ) : ℤ) < j + 1 := by omega
        have hz : j ≤ 0 ∨ ((n + 1 : ℕ) : ℤ) < j := by omega
        have hj1 : (1 : ℤ) ≠ j := by omega
        simp [seedFiniteResidual, Finsupp.single_apply, hj1,
          Ne.symm hzero, Ne.symm hfar, hfar',
          seedRightBranch_outside d (n + 1) lam E (j - 1) hm,
          seedRightBranch_outside d (n + 1) lam E (j + 1) hp,
          seedRightBranch_outside d (n + 1) lam E j hz]

/-- The left branch includes its physical outer bond at `-q-1`. -/
theorem seedLeftBranch_residual (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ)
    (hL : seedLeftDet d k lam E ≠ 0) (j : ℤ) :
    seedFiniteResidual d lam E
        (seedReflect 0 (seedRightBranch (fun r => d (-r)) (k + 1) lam E)) j =
      -(Finsupp.single (-1) lam j) +
        Finsupp.single 0 (lam ^ 2 * seedLeftTailDet d k lam E /
          seedLeftDet d k lam E) j +
        Finsupp.single (-((k : ℤ) + 1) - 1)
          (lam ^ (k + 2) / seedLeftDet d k lam E) j := by
  rw [seedFiniteResidual_reflect]
  simp only [zero_sub]
  rw [seedRightBranch_residual (fun r => d (-r)) (k + 1) lam E hL (-j)]
  have h1 : (1 : ℤ) = -j ↔ (-1 : ℤ) = j := by omega
  have h0 : (0 : ℤ) = -j ↔ (0 : ℤ) = j := by omega
  have hfar : ((k + 1 : ℕ) : ℤ) + 1 = -j ↔ -((k : ℤ) + 1) - 1 = j := by omega
  simp only [Finsupp.single_apply, h1, h0, hfar]
  rfl

/-- The exact whole-line residual of the left-centered vector has only the
other resonant center and the outer boundary source. -/
theorem seedFiniteVector_residual (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ)
    (hL : seedLeftDet d k lam E ≠ 0) (hM : seedMiddleDet d k lam E ≠ 0)
    (hcenter : (E - d 0) * seedLeftDet d k lam E * seedMiddleDet d k lam E =
      lam ^ 2 * (seedLeftTailDet d k lam E * seedMiddleDet d k lam E +
        seedMiddleTailDet d k lam E * seedLeftDet d k lam E)) (j : ℤ) :
    seedFiniteResidual d lam E (seedFiniteVector d k lam E) j =
      Finsupp.single ((k : ℤ) + 1) (lam ^ (k + 1) / seedMiddleDet d k lam E) j +
        Finsupp.single (-((k : ℤ) + 1) - 1) (lam ^ (k + 2) / seedLeftDet d k lam E) j := by
  have hz := congrArg (fun x : ℝ => Finsupp.single (0 : ℤ) x j)
    (seedCenterResidual_zero d k lam E hL hM hcenter)
  simp only [Finsupp.single_add, Finsupp.add_apply, Finsupp.single_zero,
    Finsupp.zero_apply] at hz
  rw [seedFiniteVector, seedFiniteResidual_add, seedFiniteResidual_add,
    seedFiniteResidual_single, seedLeftBranch_residual d k lam E hL,
    seedRightBranch_residual d k lam E hM]
  simp only [zero_sub, zero_add]
  dsimp only [seedLeftDet, seedMiddleDet, seedLeftTailDet, seedMiddleTailDet] at hz ⊢
  linear_combination hz

/-- Physical reflection gives the partner source without dropping its outer bond. -/
theorem seedReflectedFiniteVector_residual (d : ℤ → ℝ) (k : ℕ) (lam E : ℝ)
    (hd : ∀ j : ℤ, d ((k : ℤ) + 1 - j) = d j)
    (hL : seedLeftDet d k lam E ≠ 0) (hM : seedMiddleDet d k lam E ≠ 0)
    (hcenter : (E - d 0) * seedLeftDet d k lam E * seedMiddleDet d k lam E =
      lam ^ 2 * (seedLeftTailDet d k lam E * seedMiddleDet d k lam E +
        seedMiddleTailDet d k lam E * seedLeftDet d k lam E)) (j : ℤ) :
    seedFiniteResidual d lam E (seedReflectedFiniteVector d k lam E) j =
      Finsupp.single 0 (lam ^ (k + 1) / seedMiddleDet d k lam E) j +
        Finsupp.single (2 * ((k : ℤ) + 1) + 1)
          (lam ^ (k + 2) / seedLeftDet d k lam E) j := by
  rw [seedReflectedFiniteVector, seedFiniteResidual_reflect]
  have hpot : (fun r => d ((k : ℤ) + 1 - r)) = d := funext hd
  rw [hpot, seedFiniteVector_residual d k lam E hL hM hcenter]
  have h1 : (k : ℤ) + 1 = (k : ℤ) + 1 - j ↔ (0 : ℤ) = j := by omega
  have hfar : -((k : ℤ) + 1) - 1 = (k : ℤ) + 1 - j ↔
      2 * ((k : ℤ) + 1) + 1 = j := by omega
  simp only [Finsupp.single_apply, h1, hfar]

end CriticalDTM

import Mathlib.Analysis.Normed.Ring.Units
import Mathlib.Tactic.Abel

/-!
# A first-order change of frame in a normed algebra

The exact normalized identity works in a noncommutative real algebra.
In a complete normed algebra, nearby units and continuity then identify the
first-order coefficient after a change of frame. Taking the algebra to be
bounded continuous matrix-valued functions makes the convergence uniform
in the phase variable. No determinant normalization or inverse expansion
is required.
-/

noncomputable section

open Filter
open scoped Topology

namespace CriticalDTM

/-- Exact normalized change-of-frame identity. Real scalars are central;
there is no commutativity assumption on the algebra itself. -/
theorem firstOrderConjugacy_normalized_eq
    {R : Type*} [Ring R] [Algebra ℝ R]
    {t : ℝ} (ht : t ≠ 0) (C X Xplus : R)
    (hV : IsUnit (1 + t • Xplus)) :
    t⁻¹ • (Ring.inverse (1 + t • Xplus) * C * (1 + t • X) - 1) =
      Ring.inverse (1 + t • Xplus) *
        (t⁻¹ • (C - 1) + C * X - Xplus) := by
  have hnum : C * (1 + t • X) - (1 + t • Xplus) =
      (C - 1) + t • (C * X - Xplus) := by
    simp only [mul_add, mul_one, mul_smul_comm, smul_sub]
    abel
  calc
    t⁻¹ • (Ring.inverse (1 + t • Xplus) * C * (1 + t • X) - 1) =
        t⁻¹ • (Ring.inverse (1 + t • Xplus) *
          (C * (1 + t • X) - (1 + t • Xplus))) := by
      rw [mul_sub, Ring.inverse_mul_cancel _ hV, mul_assoc]
    _ = Ring.inverse (1 + t • Xplus) *
        (t⁻¹ • ((C - 1) + t • (C * X - Xplus))) := by
      rw [hnum, mul_smul_comm]
    _ = Ring.inverse (1 + t • Xplus) *
        (t⁻¹ • (C - 1) + C * X - Xplus) := by
      rw [smul_add, smul_smul, inv_mul_cancel₀ ht, one_smul, add_sub_assoc]

section Normed

variable {R : Type*} [NormedRing R] [NormedAlgebra ℝ R] [CompleteSpace R]
variable {ι : Type*} {l : Filter ι} {t : ι → ℝ} {C : ι → R} {A : R}

/-- Each fixed first-order frame is eventually invertible. -/
theorem eventually_isUnit_one_add_smul
    (ht : Tendsto t l (𝓝 0)) (X : R) :
    ∀ᶠ i in l, IsUnit (1 + t i • X) := by
  have hU : Tendsto (fun i => (1 : R) + t i • X) l (𝓝 1) := by
    simpa only [zero_smul, add_zero] using
      (tendsto_const_nhds.add (ht.smul (tendsto_const_nhds (x := X))))
  exact hU.eventually (Units.nhds (1 : Rˣ))

/-- The inverse of a first-order frame tends to the identity. -/
theorem tendsto_inverse_one_add_smul
    (ht : Tendsto t l (𝓝 0)) (X : R) :
    Tendsto (fun i => Ring.inverse (1 + t i • X)) l (𝓝 (1 : R)) := by
  have hU : Tendsto (fun i => (1 : R) + t i • X) l (𝓝 1) := by
    simpa only [zero_smul, add_zero] using
      (tendsto_const_nhds.add (ht.smul (tendsto_const_nhds (x := X))))
  have hinv : ContinuousAt Ring.inverse (1 : R) :=
    NormedRing.inverse_continuousAt (1 : Rˣ)
  simpa only [Ring.inverse_one] using hinv.tendsto.comp hU

omit [CompleteSpace R] in
/-- A convergent normalized first-order difference already implies that the
original family tends to the identity. -/
theorem tendsto_one_of_normalized_sub_tendsto
    (ht : Tendsto t l (𝓝 0)) (htne : ∀ᶠ i in l, t i ≠ 0)
    (hA : Tendsto (fun i => (t i)⁻¹ • (C i - 1)) l (𝓝 A)) :
    Tendsto C l (𝓝 1) := by
  have hlim : Tendsto
      (fun i => t i • ((t i)⁻¹ • (C i - 1)) + 1) l (𝓝 (1 : R)) := by
    simpa only [zero_smul, zero_add] using
      (ht.smul hA).add (tendsto_const_nhds (x := (1 : R)))
  apply (tendsto_congr' ?_).2 hlim
  filter_upwards [htne] with i hi
  simp only [smul_smul, mul_inv_cancel₀ hi, one_smul, sub_add_cancel]

/-- A change of frame replaces the normalized first-order limit `A` by
`A + X - Xplus`. This version accepts convergence of the original family
explicitly. -/
theorem tendsto_firstOrderConjugacy_normalized_of_tendsto
    (ht : Tendsto t l (𝓝 0)) (htne : ∀ᶠ i in l, t i ≠ 0)
    (hC : Tendsto C l (𝓝 1))
    (hA : Tendsto (fun i => (t i)⁻¹ • (C i - 1)) l (𝓝 A))
    (X Xplus : R) :
    Tendsto (fun i => (t i)⁻¹ •
      (Ring.inverse (1 + t i • Xplus) * C i * (1 + t i • X) - 1))
      l (𝓝 (A + X - Xplus)) := by
  have hinner : Tendsto
      (fun i => (t i)⁻¹ • (C i - 1) + C i * X - Xplus)
      l (𝓝 (A + X - Xplus)) := by
    simpa only [one_mul] using
      (hA.add (hC.mul (tendsto_const_nhds (x := X)))).sub
        (tendsto_const_nhds (x := Xplus))
  have hlim : Tendsto
      (fun i => Ring.inverse (1 + t i • Xplus) *
        ((t i)⁻¹ • (C i - 1) + C i * X - Xplus))
      l (𝓝 (A + X - Xplus)) := by
    simpa only [one_mul] using (tendsto_inverse_one_add_smul ht Xplus).mul hinner
  apply (tendsto_congr' ?_).2 hlim
  filter_upwards [htne, eventually_isUnit_one_add_smul ht Xplus] with i hi hunit
  exact firstOrderConjugacy_normalized_eq hi (C i) X Xplus hunit

/-- Only the normalized first-order convergence and the vanishing, eventually
nonzero scale are needed for a first-order change of frame. -/
theorem tendsto_firstOrderConjugacy_normalized
    (ht : Tendsto t l (𝓝 0)) (htne : ∀ᶠ i in l, t i ≠ 0)
    (hA : Tendsto (fun i => (t i)⁻¹ • (C i - 1)) l (𝓝 A))
    (X Xplus : R) :
    Tendsto (fun i => (t i)⁻¹ •
      (Ring.inverse (1 + t i • Xplus) * C i * (1 + t i • X) - 1))
      l (𝓝 (A + X - Xplus)) :=
  tendsto_firstOrderConjugacy_normalized_of_tendsto ht htne
    (tendsto_one_of_normalized_sub_tendsto ht htne hA) hA X Xplus

end Normed

end CriticalDTM

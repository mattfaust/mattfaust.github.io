import DTM.Background.Transfer.AMOTransfer
import Mathlib.Tactic.FieldSimp

/-!
# Exact two-by-two algebra for a finite resonant Fourier frame

No spectral statement is assumed here. The periodic complex frame needs no
real or determinant-one normalization. Its scalar phase has modulus one in
the eventual application. An explicit diagonal corrector removes precisely
the two oscillatory diagonal terms; the remaining constant matrix has real
opposite eigenvalues.
-/

noncomputable section
namespace CriticalDTM

open Matrix
open scoped Matrix.L2OpNorm

/-- The uncoupled resonant Fourier frame, for `p = exp(iκ)` and a phase mode `z`. -/
def seedFreeFrame (p z : ℂ) : AMOTransferMatrix := !![1, z; p⁻¹, p * z]

/-- Its explicitly bounded inverse when the phase mode has modulus one. -/
def seedFreeFrameInverse (p z : ℂ) : AMOTransferMatrix :=
  !![p / (p - p⁻¹), -(1 / (p - p⁻¹));
      -(p⁻¹ * z⁻¹ / (p - p⁻¹)), z⁻¹ / (p - p⁻¹)]

theorem seedFreeFrame_inverse_mul {p z : ℂ} (hz : z ≠ 0)
    (hD : p - p⁻¹ ≠ 0) : seedFreeFrameInverse p z * seedFreeFrame p z = 1 := by
  unfold seedFreeFrameInverse seedFreeFrame
  generalize hm : p⁻¹ = m at hD ⊢
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply] <;>
    field_simp [hz, hD] <;> ring

theorem seedFreeFrame_mul_inverse {p z : ℂ} (hz : z ≠ 0)
    (hD : p - p⁻¹ ≠ 0) : seedFreeFrame p z * seedFreeFrameInverse p z = 1 := by
  unfold seedFreeFrameInverse seedFreeFrame
  generalize hm : p⁻¹ = m at hD ⊢
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply] <;>
    field_simp [hz, hD] <;> ring

/-- The exact first-order generator from the two resonant residual columns.
The multiplier `p⁻¹ ^ 2` is the resonance relation for the shifted mode. -/
theorem seedFreeFrame_residual_generator {p z : ℂ} (hp : p ≠ 0) (hz : z ≠ 0)
    (hD : p - p⁻¹ ≠ 0) :
    (-p⁻¹) • (seedFreeFrameInverse p (z * p⁻¹ ^ 2) * !![z, 1; 0, 0]) =
      !![-z / (p - p⁻¹), -(1 / (p - p⁻¹));
          1 / (p - p⁻¹), z⁻¹ / (p - p⁻¹)] := by
  unfold seedFreeFrameInverse
  generalize hm : p⁻¹ = m at hD ⊢
  have hm0 : m ≠ 0 := hm ▸ inv_ne_zero hp
  have hpm : p * m = 1 := hm ▸ mul_inv_cancel₀ hp
  have hmp : m * p = 1 := by simpa only [mul_comm] using hpm
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Matrix.mul_apply, Fin.sum_univ_two] <;>
    field_simp [hm0, hz, hD, hpm, hmp] <;> ring_nf
  all_goals linear_combination z * hmp

/-- The actual two-mode diagonal corrector. -/
def seedDiagonalCorrector (a z ρ : ℂ) : AMOTransferMatrix :=
  !![-a * z / (1 - ρ), 0; 0, a * z⁻¹ / (1 - ρ⁻¹)]

/-- One finite Fourier coboundary eliminates the same-order diagonal. -/
theorem seedDiagonalCorrector_difference {a z ρ : ℂ} (hρ1 : ρ ≠ 1) :
    seedDiagonalCorrector a z ρ - seedDiagonalCorrector a (z * ρ) ρ =
      -!![a * z, 0; 0, -a * z⁻¹] := by
  have hden : 1 - ρ ≠ 0 := sub_ne_zero.mpr (Ne.symm hρ1)
  have hden' : 1 - ρ⁻¹ ≠ 0 := by
    apply sub_ne_zero.mpr
    intro h
    apply hρ1
    simpa using congrArg Inv.inv h.symm
  unfold seedDiagonalCorrector
  simp only [_root_.mul_inv_rev]
  generalize hzi : z⁻¹ = w at ⊢
  generalize hri : ρ⁻¹ = r at hden' ⊢
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp <;> field_simp [hden, hden'] <;> ring

/-- A fixed complex basis for the Hermitian hyperbolic matrix. -/
def seedHyperbolicBasis : AMOTransferMatrix := !![Complex.I, -Complex.I; 1, 1]

def seedHyperbolicBasisInverse : AMOTransferMatrix :=
  !![-Complex.I / 2, (1 / 2 : ℂ); Complex.I / 2, (1 / 2 : ℂ)]

@[simp] theorem seedHyperbolicBasis_inverse_mul :
    seedHyperbolicBasisInverse * seedHyperbolicBasis = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [seedHyperbolicBasisInverse, seedHyperbolicBasis,
      Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply] <;>
    ring_nf
  all_goals norm_num [Complex.I_sq]

@[simp] theorem seedHyperbolicBasis_mul_inverse :
    seedHyperbolicBasis * seedHyperbolicBasisInverse = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [seedHyperbolicBasisInverse, seedHyperbolicBasis,
      Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply] <;>
    ring_nf
  all_goals norm_num [Complex.I_sq]

/-- The remaining constant matrix has eigenvalues exactly `+1` and `-1`. -/
theorem seedHyperbolicBasis_diagonalizes :
    seedHyperbolicBasisInverse * !![0, Complex.I; -Complex.I, 0] *
      seedHyperbolicBasis = !![(1 : ℂ), 0; 0, -1] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [seedHyperbolicBasisInverse, seedHyperbolicBasis,
      Matrix.mul_apply, Fin.sum_univ_two] <;>
    ring_nf
  all_goals norm_num [Complex.I_sq]

end CriticalDTM

import DTM.Background.Transfer.AMOTransfer
import Mathlib.Topology.ContinuousMap.Bounded.Normed

/-!
# Bounded continuous matrix functions for finite-order seeds

Four bounded continuous scalar entries assemble into a bounded continuous
`2 × 2` matrix function. All matrix norms here are the Euclidean operator
norm from the `Matrix.L2OpNorm` scope, consistently with `AMOTransferMatrix`.
The assembly is jointly continuous in the four uniform norms.

Translation is ordinary precomposition by `θ ↦ θ + ω`; it is continuous
in the function for each fixed shift, and preserves the pointwise algebra.
A supplied bounded continuous two-sided inverse gives a unit in the actual
bounded-continuous-function algebra. No Fourier or inverse existence is
assumed by the assembly and translation statements.
-/

noncomputable section

open scoped Matrix Matrix.L2OpNorm BoundedContinuousFunction

namespace CriticalDTM

/-- Assemble four scalar functions using the four constant matrix units. -/
def seedMatrixFunction (a b c d : ℝ →ᵇ ℂ) : ℝ →ᵇ AMOTransferMatrix :=
  a • BoundedContinuousFunction.const ℝ (!![1, 0; 0, 0] : AMOTransferMatrix) +
  b • BoundedContinuousFunction.const ℝ (!![0, 1; 0, 0] : AMOTransferMatrix) +
  c • BoundedContinuousFunction.const ℝ (!![0, 0; 1, 0] : AMOTransferMatrix) +
  d • BoundedContinuousFunction.const ℝ (!![0, 0; 0, 1] : AMOTransferMatrix)

@[simp]
theorem seedMatrixFunction_apply (a b c d : ℝ →ᵇ ℂ) (θ : ℝ) :
    seedMatrixFunction a b c d θ = !![a θ, b θ; c θ, d θ] := by
  change a θ • (!![1, 0; 0, 0] : AMOTransferMatrix) +
    b θ • (!![0, 1; 0, 0] : AMOTransferMatrix) +
    c θ • (!![0, 0; 1, 0] : AMOTransferMatrix) +
    d θ • (!![0, 0; 0, 1] : AMOTransferMatrix) = _
  ext i j
  fin_cases i <;> fin_cases j <;> simp

/-- Translation of the real phase, without quotienting or changing the function. -/
def seedFunctionShift {R : Type*} [PseudoMetricSpace R] (ω : ℝ) (f : ℝ →ᵇ R) :
    ℝ →ᵇ R :=
  f.compContinuous ⟨fun θ => θ + ω, continuous_id.add continuous_const⟩

@[simp]
theorem seedFunctionShift_apply {R : Type*} [PseudoMetricSpace R]
    (ω : ℝ) (f : ℝ →ᵇ R) (θ : ℝ) : seedFunctionShift ω f θ = f (θ + ω) := rfl

theorem lipschitz_seedFunctionShift {R : Type*} [PseudoMetricSpace R] (ω : ℝ) :
    LipschitzWith 1 (seedFunctionShift (R := R) ω) :=
  BoundedContinuousFunction.lipschitz_compContinuous _

theorem continuous_seedFunctionShift {R : Type*} [PseudoMetricSpace R] (ω : ℝ) :
    Continuous (seedFunctionShift (R := R) ω) :=
  (lipschitz_seedFunctionShift ω).continuous

section Ring

variable {R : Type*} [NormedRing R]

@[simp]
theorem seedFunctionShift_one (ω : ℝ) : seedFunctionShift ω (1 : ℝ →ᵇ R) = 1 := by
  ext θ
  rfl

theorem seedFunctionShift_add (ω : ℝ) (f g : ℝ →ᵇ R) :
    seedFunctionShift ω (f + g) = seedFunctionShift ω f + seedFunctionShift ω g := by
  ext θ
  rfl

theorem seedFunctionShift_mul (ω : ℝ) (f g : ℝ →ᵇ R) :
    seedFunctionShift ω (f * g) = seedFunctionShift ω f * seedFunctionShift ω g := by
  ext θ
  rfl

/-- A bounded continuous pointwise two-sided inverse is an actual unit in the
bounded-function algebra; in particular this applies to `AMOTransferMatrix`. -/
theorem seedFunction_isUnit_of_pointwise_inverse (f g : ℝ →ᵇ R)
    (hfg : ∀ θ, f θ * g θ = 1) (hgf : ∀ θ, g θ * f θ = 1) : IsUnit f := by
  refine ⟨⟨f, g, ?_, ?_⟩, rfl⟩
  · ext θ
    exact hfg θ
  · ext θ
    exact hgf θ

end Ring

theorem seedFunctionShift_smul {𝕜 R : Type*} [NormedField 𝕜]
    [SeminormedAddCommGroup R] [NormedSpace 𝕜 R]
    (ω : ℝ) (c : 𝕜) (f : ℝ →ᵇ R) :
    seedFunctionShift ω (c • f) = c • seedFunctionShift ω f := by
  ext θ
  rfl

end CriticalDTM

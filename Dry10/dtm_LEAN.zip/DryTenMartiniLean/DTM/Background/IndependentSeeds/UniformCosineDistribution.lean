import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-!
# The distribution of twice the cosine of a uniform turn

Lebesgue measure restricted to `(0,1]` already has total mass one. Its
pushforward by `t ↦ 2 cos(2πt)` has lower-tail mass `1 - κ/π` at `2 cos κ`,
for `0 < κ < π`. The fiber of that threshold consists of two points, so
it has mass zero. All measure and trigonometric objects below are Mathlib's.
-/

noncomputable section

namespace CriticalDTM

open Set MeasureTheory

private theorem cosine_lt_iff_between {κ x : ℝ} (hκ0 : 0 < κ)
    (hκpi : κ < Real.pi) (hx : x ∈ Icc 0 (2 * Real.pi)) :
    Real.cos x < Real.cos κ ↔ κ < x ∧ x < 2 * Real.pi - κ := by
  by_cases hxp : x ≤ Real.pi
  · rw [Real.strictAntiOn_cos.lt_iff_lt ⟨hx.1, hxp⟩ ⟨hκ0.le, hκpi.le⟩]
    constructor
    · intro h
      exact ⟨h, by linarith⟩
    · exact And.left
  · have hx' : 2 * Real.pi - x ∈ Icc 0 Real.pi := by
      constructor <;> linarith [hx.1, hx.2]
    have hcos : Real.cos x < Real.cos κ ↔ κ < 2 * Real.pi - x := by
      rw [← Real.cos_two_pi_sub x]
      exact Real.strictAntiOn_cos.lt_iff_lt hx' ⟨hκ0.le, hκpi.le⟩
    rw [hcos]
    constructor
    · intro h
      exact ⟨by linarith, by linarith⟩
    · intro h
      linarith [h.2]

private theorem cosine_eq_iff_endpoints {κ x : ℝ} (hκ0 : 0 < κ)
    (hκpi : κ < Real.pi) (hx : x ∈ Icc 0 (2 * Real.pi)) :
    Real.cos x = Real.cos κ → x = κ ∨ x = 2 * Real.pi - κ := by
  intro hcos
  by_cases hxp : x ≤ Real.pi
  · exact Or.inl (Real.injOn_cos ⟨hx.1, hxp⟩ ⟨hκ0.le, hκpi.le⟩ hcos)
  · have hx' : 2 * Real.pi - x ∈ Icc 0 Real.pi := by
      constructor <;> linarith [hx.1, hx.2]
    have heq : 2 * Real.pi - x = κ :=
      Real.injOn_cos hx' ⟨hκ0.le, hκpi.le⟩ (by
        rw [Real.cos_two_pi_sub]
        exact hcos)
    exact Or.inr (by linarith)

/-- On one turn, the strict lower preimage is the open interval between the
 two phases with energy `2 cos κ`. -/
theorem cosine_uniform_lower_tail_preimage {κ : ℝ} (hκ0 : 0 < κ)
    (hκpi : κ < Real.pi) :
    (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)) ⁻¹' Iio (2 * Real.cos κ) ∩
        Ioc 0 1 = Ioo (κ / (2 * Real.pi)) (1 - κ / (2 * Real.pi)) := by
  have hpi : 0 < 2 * Real.pi := by positivity
  have ha : 0 < κ / (2 * Real.pi) := div_pos hκ0 hpi
  have hmul : 2 * Real.pi * (κ / (2 * Real.pi)) = κ :=
    mul_div_cancel₀ κ hpi.ne'
  ext t
  constructor
  · rintro ⟨hcos, ht⟩
    have hx : 2 * Real.pi * t ∈ Icc 0 (2 * Real.pi) := by
      constructor
      · exact le_of_lt (mul_pos hpi ht.1)
      · nlinarith [ht.2]
    have h := (cosine_lt_iff_between hκ0 hκpi hx).mp (by
      change 2 * Real.cos (2 * Real.pi * t) < 2 * Real.cos κ at hcos
      linarith)
    constructor <;> nlinarith [h.1, h.2]
  · intro ht
    have ht0 : 0 < t := lt_trans ha ht.1
    have ht1 : t ≤ 1 := by linarith [ht.2]
    refine ⟨?_, ht0, ht1⟩
    have hx : 2 * Real.pi * t ∈ Icc 0 (2 * Real.pi) := by
      constructor
      · exact le_of_lt (mul_pos hpi ht0)
      · nlinarith
    have h := (cosine_lt_iff_between hκ0 hκpi hx).mpr
      (show κ < 2 * Real.pi * t ∧ 2 * Real.pi * t < 2 * Real.pi - κ by
        constructor <;> nlinarith [ht.1, ht.2])
    change 2 * Real.cos (2 * Real.pi * t) < 2 * Real.cos κ
    linarith

/-- The exact lower-tail mass of twice the cosine of a uniform turn. -/
theorem cosine_uniform_lower_tail {κ : ℝ} (hκ0 : 0 < κ) (hκpi : κ < Real.pi) :
    ((volume.restrict (Ioc 0 1)).map (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)))
        (Iio (2 * Real.cos κ)) = ENNReal.ofReal (1 - κ / Real.pi) := by
  have hf : Measurable (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)) :=
    (continuous_const.mul (Real.continuous_cos.comp (continuous_const.mul continuous_id))).measurable
  rw [Measure.map_apply hf measurableSet_Iio, Measure.restrict_apply' measurableSet_Ioc,
    cosine_uniform_lower_tail_preimage hκ0 hκpi, Real.volume_Ioo]
  congr 1
  field_simp
  ring

/-- There is no atom at any interior cosine threshold. -/
theorem cosine_uniform_singleton {κ : ℝ} (hκ0 : 0 < κ) (hκpi : κ < Real.pi) :
    ((volume.restrict (Ioc 0 1)).map (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)))
        {2 * Real.cos κ} = 0 := by
  have hf : Measurable (fun t : ℝ => 2 * Real.cos (2 * Real.pi * t)) :=
    (continuous_const.mul (Real.continuous_cos.comp (continuous_const.mul continuous_id))).measurable
  rw [Measure.map_apply hf (measurableSet_singleton _),
    Measure.restrict_apply' measurableSet_Ioc]
  have hpi : 0 < 2 * Real.pi := by positivity
  have hmul : 2 * Real.pi * (κ / (2 * Real.pi)) = κ :=
    mul_div_cancel₀ κ hpi.ne'
  apply measure_mono_null (t := {κ / (2 * Real.pi), 1 - κ / (2 * Real.pi)})
  · rintro t ⟨hcos, ht⟩
    have hx : 2 * Real.pi * t ∈ Icc 0 (2 * Real.pi) := by
      constructor
      · exact le_of_lt (mul_pos hpi ht.1)
      · nlinarith [ht.2]
    have h := cosine_eq_iff_endpoints hκ0 hκpi hx (by
      change 2 * Real.cos (2 * Real.pi * t) = 2 * Real.cos κ at hcos
      linarith)
    rcases h with h | h
    · simp only [mem_insert_iff, mem_singleton_iff]
      exact Or.inl (by nlinarith)
    · simp only [mem_insert_iff, mem_singleton_iff]
      exact Or.inr (by nlinarith)
  · exact (Set.Finite.insert _ (Set.finite_singleton _)).measure_zero volume

end CriticalDTM

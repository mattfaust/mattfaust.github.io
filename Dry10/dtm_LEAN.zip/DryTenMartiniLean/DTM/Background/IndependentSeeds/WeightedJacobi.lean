import DTM.Background.Potential.JacobiDeterminant
import Mathlib.Data.Fin.Rev
import Mathlib.Topology.Instances.Matrix
import Mathlib.Analysis.Calculus.ContDiff.Operations

/-!
# Weighted finite Jacobi determinants and endpoint Green columns

The actual finite pencil has diagonal `d` and two adjacent bonds `-c`.
Laplace expansion gives its continuant recurrence and every cofactor in the
first row. Thus the endpoint Green column is a finite determinant solution,
with its exact endpoint residual. The empty determinant is one; no division
by a bond or by a proper principal minor is used.
-/

noncomputable section

namespace CriticalDTM

open Matrix

variable {R : Type*} [CommRing R]

/-- The finite Dirichlet pencil with constant bond `-c`. -/
def weightedJacobiMatrix (d : ℕ → R) (c : R) (n : ℕ) :
    Matrix (Fin n) (Fin n) R :=
  fun i j => if i = j then d i.val
    else if i.val + 1 = j.val ∨ j.val + 1 = i.val then -c else 0

/-- The determinant of the actual finite weighted pencil. -/
def weightedJacobiDet (d : ℕ → R) (c : R) (n : ℕ) : R :=
  (weightedJacobiMatrix d c n).det

@[simp] theorem weightedJacobiMatrix_diagonal (d : ℕ → R) (c : R)
    (n : ℕ) (i : Fin n) : weightedJacobiMatrix d c n i i = d i.val := by
  simp [weightedJacobiMatrix]

@[simp] theorem weightedJacobiMatrix_zero_one (d : ℕ → R) (c : R) (n : ℕ) :
    weightedJacobiMatrix d c (n + 2) 0 1 = -c := by
  simp [weightedJacobiMatrix]

@[simp] theorem weightedJacobiMatrix_one_zero (d : ℕ → R) (c : R) (n : ℕ) :
    weightedJacobiMatrix d c (n + 2) 1 0 = -c := by
  simp [weightedJacobiMatrix]

@[simp] theorem weightedJacobiMatrix_zero_succ_succ (d : ℕ → R) (c : R)
    (n : ℕ) (j : Fin n) : weightedJacobiMatrix d c (n + 2) 0 j.succ.succ = 0 := by
  simp [weightedJacobiMatrix, Fin.ext_iff]

@[simp] theorem weightedJacobiMatrix_succ_succ_zero (d : ℕ → R) (c : R)
    (n : ℕ) (i : Fin n) : weightedJacobiMatrix d c (n + 2) i.succ.succ 0 = 0 := by
  simp [weightedJacobiMatrix, Fin.ext_iff]

@[simp] theorem weightedJacobiMatrix_succ_succ (d : ℕ → R) (c : R)
    (n : ℕ) (i j : Fin n) :
    weightedJacobiMatrix d c (n + 1) i.succ j.succ =
      weightedJacobiMatrix (fun k => d (k + 1)) c n i j := by
  simp [weightedJacobiMatrix, Fin.ext_iff]

/-- Deleting the first site shifts the physical diagonal by one. -/
theorem weightedJacobiMatrix_tail (d : ℕ → R) (c : R) (n : ℕ) :
    (weightedJacobiMatrix d c (n + 1)).submatrix Fin.succ Fin.succ =
      weightedJacobiMatrix (fun k => d (k + 1)) c n := by
  ext i j
  exact weightedJacobiMatrix_succ_succ d c n i j

@[simp] theorem weightedJacobiMatrix_transpose (d : ℕ → R) (c : R) (n : ℕ) :
    (weightedJacobiMatrix d c n)ᵀ = weightedJacobiMatrix d c n := by
  ext i j
  simp only [Matrix.transpose_apply, weightedJacobiMatrix]
  by_cases h : i = j
  · subst j
    simp
  · simp [h, Ne.symm h, or_comm]

@[simp] theorem weightedJacobiMatrix_det_zero (d : ℕ → R) (c : R) :
    (weightedJacobiMatrix d c 0).det = 1 := Matrix.det_fin_zero

@[simp] theorem weightedJacobiMatrix_det_one (d : ℕ → R) (c : R) :
    (weightedJacobiMatrix d c 1).det = d 0 := by
  simp [Matrix.det_fin_one]

@[simp] theorem weightedJacobiDet_zero (d : ℕ → R) (c : R) :
    weightedJacobiDet d c 0 = 1 := weightedJacobiMatrix_det_zero d c

@[simp] theorem weightedJacobiDet_one (d : ℕ → R) (c : R) :
    weightedJacobiDet d c 1 = d 0 := weightedJacobiMatrix_det_one d c

private theorem weightedJacobiMatrix_first_cofactor (d : ℕ → R) (c : R) (n : ℕ) :
    ((weightedJacobiMatrix d c (n + 2)).submatrix Fin.succ
      (1 : Fin (n + 2)).succAbove).det =
      -c * (weightedJacobiMatrix (fun k => d (k + 2)) c n).det := by
  rw [Matrix.det_succ_column_zero, Fin.sum_univ_succ]
  simp only [Fin.val_zero, pow_zero, one_mul, Matrix.submatrix_apply,
    Fin.one_succAbove_zero, Fin.succ_zero_eq_one, weightedJacobiMatrix_one_zero,
    Fin.zero_succAbove, Fin.val_succ, weightedJacobiMatrix_succ_succ_zero,
    mul_zero, zero_mul, Finset.sum_const_zero, add_zero]
  congr 1
  congr 1
  ext i j
  simp [Matrix.submatrix_apply, weightedJacobiMatrix_succ_succ, Nat.add_assoc]

/-- The weighted continuant recurrence, including its two-site case. -/
theorem weightedJacobiMatrix_det_recurrence (d : ℕ → R) (c : R) (n : ℕ) :
    (weightedJacobiMatrix d c (n + 2)).det =
      d 0 * (weightedJacobiMatrix (fun k => d (k + 1)) c (n + 1)).det -
        c ^ 2 * (weightedJacobiMatrix (fun k => d (k + 2)) c n).det := by
  rw [Matrix.det_succ_row_zero, Fin.sum_univ_succ, Fin.sum_univ_succ]
  simp only [Fin.val_zero, pow_zero, one_mul, weightedJacobiMatrix_diagonal,
    Fin.succAbove_zero, Fin.succ_zero_eq_one, Fin.val_one, pow_one,
    weightedJacobiMatrix_zero_one, neg_mul_neg, one_mul, Fin.val_succ,
    weightedJacobiMatrix_zero_succ_succ, mul_zero, zero_mul, Finset.sum_const_zero,
    add_zero, weightedJacobiMatrix_tail, weightedJacobiMatrix_first_cofactor]
  ring

theorem weightedJacobiDet_recurrence (d : ℕ → R) (c : R) (n : ℕ) :
    weightedJacobiDet d c (n + 2) =
      d 0 * weightedJacobiDet (fun k => d (k + 1)) c (n + 1) -
        c ^ 2 * weightedJacobiDet (fun k => d (k + 2)) c n :=
  weightedJacobiMatrix_det_recurrence d c n

/-- Delete row `j` and the first column. Each earlier site contributes one
bond, and the remaining factor is the determinant strictly after `j`. -/
theorem weightedJacobiMatrix_endpoint_minor (d : ℕ → R) (c : R) (n : ℕ)
    (j : Fin (n + 1)) :
    ((weightedJacobiMatrix d c (n + 1)).submatrix j.succAbove Fin.succ).det =
      (-c) ^ j.val *
        (weightedJacobiMatrix (fun k => d (k + j.val + 1)) c (n - j.val)).det := by
  induction n generalizing d with
  | zero =>
      have hj : j = 0 := Fin.ext (by omega)
      subst j
      simp
  | succ n ih =>
      refine Fin.cases ?_ (fun j => ?_) j
      · simp [weightedJacobiMatrix_tail]
      · rw [Matrix.det_succ_row_zero, Fin.sum_univ_succ]
        simp only [Fin.val_zero, pow_zero, one_mul, Matrix.submatrix_apply,
          Fin.succ_succAbove_zero, Fin.succ_zero_eq_one, Fin.succAbove_zero,
          weightedJacobiMatrix_zero_one, Fin.zero_succAbove, Fin.val_succ,
          weightedJacobiMatrix_zero_succ_succ, mul_zero, zero_mul,
          Finset.sum_const_zero, add_zero]
        have hminor :
            (((weightedJacobiMatrix d c (n + 1 + 1)).submatrix j.succ.succAbove
              Fin.succ).submatrix Fin.succ Fin.succ) =
            (weightedJacobiMatrix (fun k => d (k + 1)) c (n + 1)).submatrix
              j.succAbove Fin.succ := by
          ext a b
          simp [Matrix.submatrix_apply, weightedJacobiMatrix_succ_succ]
        rw [hminor, ih]
        simp only [Fin.val_succ, Nat.add_assoc]
        rw [Nat.add_sub_add_right, pow_succ']
        ring

/-- The whole first adjugate row, over an arbitrary commutative ring. -/
theorem weightedJacobiMatrix_adjugate_zero (d : ℕ → R) (c : R) (n : ℕ)
    (j : Fin (n + 1)) :
    (weightedJacobiMatrix d c (n + 1)).adjugate 0 j =
      c ^ j.val *
        (weightedJacobiMatrix (fun k => d (k + j.val + 1)) c (n - j.val)).det := by
  rw [Matrix.adjugate_fin_succ_eq_det_submatrix]
  simp only [Fin.val_zero, add_zero, Fin.succAbove_zero]
  rw [weightedJacobiMatrix_endpoint_minor, ← mul_assoc, ← mul_pow]
  simp

/-- The symmetric first adjugate column is the same determinant solution. -/
theorem weightedJacobiMatrix_adjugate_col_zero (d : ℕ → R) (c : R) (n : ℕ)
    (j : Fin (n + 1)) :
    (weightedJacobiMatrix d c (n + 1)).adjugate j 0 =
      c ^ j.val *
        (weightedJacobiMatrix (fun k => d (k + j.val + 1)) c (n - j.val)).det := by
  have h := congrArg (fun M : Matrix (Fin (n + 1)) (Fin (n + 1)) R => M 0 j)
    (Matrix.adjugate_transpose (weightedJacobiMatrix d c (n + 1)))
  simpa only [Matrix.transpose_apply, weightedJacobiMatrix_transpose,
    weightedJacobiMatrix_adjugate_zero] using h

/-- The polynomial endpoint solution, with one coordinate per physical site. -/
def weightedJacobiEndpointColumn (d : ℕ → R) (c : R) (n : ℕ) : Fin (n + 1) → R :=
  fun j => c ^ j.val *
    (weightedJacobiMatrix (fun k => d (k + j.val + 1)) c (n - j.val)).det

/-- All interior equations and the opposite endpoint equation hold exactly;
the sole boundary residual is the full determinant at site zero. -/
theorem weightedJacobiEndpointColumn_residual (d : ℕ → R) (c : R) (n : ℕ) :
    weightedJacobiMatrix d c (n + 1) *ᵥ weightedJacobiEndpointColumn d c n =
      (weightedJacobiMatrix d c (n + 1)).det •
        (Pi.single 0 1 : Fin (n + 1) → R) := by
  ext i
  have h := congrArg (fun M : Matrix (Fin (n + 1)) (Fin (n + 1)) R => M i 0)
    (Matrix.mul_adjugate (weightedJacobiMatrix d c (n + 1)))
  simpa [Matrix.mul_apply, Matrix.mulVec, dotProduct,
    weightedJacobiMatrix_adjugate_col_zero, weightedJacobiEndpointColumn,
    Matrix.one_apply, Pi.single_apply, eq_comm] using h

section Field

variable {K : Type*} [Field K]

/-- For a nonsingular pencil the normalized determinant column has unit
source at the first physical endpoint and no other boundary residual. -/
theorem weightedJacobiEndpointColumn_normalized_residual (d : ℕ → K) (c : K)
    (n : ℕ) (hdet : (weightedJacobiMatrix d c (n + 1)).det ≠ 0) :
    weightedJacobiMatrix d c (n + 1) *ᵥ
        ((weightedJacobiMatrix d c (n + 1)).det⁻¹ •
          weightedJacobiEndpointColumn d c n) = Pi.single (0 : Fin (n + 1)) (1 : K) := by
  rw [Matrix.mulVec_smul, weightedJacobiEndpointColumn_residual, smul_smul,
    inv_mul_cancel₀ hdet, one_smul]

end Field

section Continuity

variable {X : Type*} [TopologicalSpace X] [TopologicalSpace R] [IsTopologicalRing R]

/-- Continuous site diagonals and bonds give a continuous actual finite pencil. -/
theorem continuous_weightedJacobiMatrix (d : X → ℕ → R) (c : X → R)
    (hd : ∀ k, Continuous fun x => d x k) (hc : Continuous c) (n : ℕ) :
    Continuous fun x => weightedJacobiMatrix (d x) (c x) n := by
  apply continuous_matrix
  intro i j
  simp only [weightedJacobiMatrix]
  split_ifs
  · exact hd i.val
  · exact hc.neg
  · exact continuous_const

/-- In particular, the finite determinant is continuous in energy and bond;
there is no spectral assumption in this finite-dimensional assertion. -/
theorem continuous_weightedJacobiDet (d : X → ℕ → R) (c : X → R)
    (hd : ∀ k, Continuous fun x => d x k) (hc : Continuous c) (n : ℕ) :
    Continuous fun x => weightedJacobiDet (d x) (c x) n :=
  (continuous_weightedJacobiMatrix d c hd hc n).matrix_det

end Continuity

@[simp] theorem weightedJacobiMatrix_zero_bond (d : ℕ → R) (n : ℕ) :
    weightedJacobiMatrix d 0 n = Matrix.diagonal (fun i : Fin n => d i.val) := by
  ext i j
  by_cases h : i = j
  · subst j
    simp
  · simp [weightedJacobiMatrix, Matrix.diagonal_apply, h]

@[simp] theorem weightedJacobiDet_zero_bond (d : ℕ → R) (n : ℕ) :
    weightedJacobiDet d 0 n = ∏ i : Fin n, d i.val := by
  rw [weightedJacobiDet, weightedJacobiMatrix_zero_bond, Matrix.det_diagonal]

/-- Every differentiability order is inherited by the actual determinant,
by its polynomial continuant recurrence. -/
theorem contDiff_weightedJacobiDet {𝕜 : Type*} [NontriviallyNormedField 𝕜]
    {E : Type*} [NormedAddCommGroup E] [NormedSpace 𝕜 E] {m : WithTop ℕ∞}
    (d : E → ℕ → 𝕜) (c : E → 𝕜)
    (hd : ∀ k, ContDiff 𝕜 m fun x => d x k) (hc : ContDiff 𝕜 m c) (n : ℕ) :
    ContDiff 𝕜 m fun x => weightedJacobiDet (d x) (c x) n := by
  induction n using Nat.twoStepInduction generalizing d with
  | zero => simpa only [weightedJacobiDet_zero] using
      (contDiff_const : ContDiff 𝕜 m fun _ : E => (1 : 𝕜))
  | one => simpa only [weightedJacobiDet_one] using hd 0
  | more n ih₀ ih₁ =>
      simp only [weightedJacobiDet_recurrence]
      exact ((hd 0).mul (ih₁ (fun x k => d x (k + 1)) (fun k => hd (k + 1)))).sub
        ((hc.pow 2).mul (ih₀ (fun x k => d x (k + 2)) (fun k => hd (k + 2))))

end CriticalDTM

import DTM.Background.Realization.MagneticSpectralMeasure
import Mathlib.Topology.LocallyConstant.Algebra
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-!
# The actual spectral projection below a resolvent energy

At a real resolvent energy the lower part of the compact real spectrum is
clopen. Its continuous indicator defines a self-adjoint idempotent by the
actual continuous functional calculus. The trace of this projection is the
mass below that energy for the constructed root-state spectral measure.

This is a static spectral projection. No parameter continuity, empirical IDS
identification, or realization of arithmetic gap labels is claimed here.
-/

noncomputable section

namespace CriticalDTM

open Set MeasureTheory
open scoped ContinuousFunctionalCalculus

local instance gapProjection_realNormedSpace (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

def magneticLowerSpectrum (α lam energy : ℝ) : Set (MagneticRealSpectrum α lam) :=
  {x | (x : ℝ) < energy}

theorem resolvent_energy_not_mem_magneticRealSpectrum (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    energy ∉ spectrum ℝ (magneticAlgebraHamiltonian α lam) := by
  apply spectrum.not_mem_iff.mpr
  simpa only [magneticAlgebraPencil, Algebra.algebraMap_eq_smul_one] using
    magneticAlgebraPencil_isUnit α lam energy hm

theorem magneticLowerSpectrum_isClopen (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    IsClopen (magneticLowerSpectrum α lam energy) := by
  have hne (x : MagneticRealSpectrum α lam) : (x : ℝ) ≠ energy := by
    intro h
    exact resolvent_energy_not_mem_magneticRealSpectrum α lam energy hm (h ▸ x.property)
  have hset : magneticLowerSpectrum α lam energy =
      {x : MagneticRealSpectrum α lam | (x : ℝ) ≤ energy} := by
    ext x
    change ((x : ℝ) < energy) ↔ (x : ℝ) ≤ energy
    exact ⟨fun h => h.le, fun h => lt_of_le_of_ne h (hne x)⟩
  refine ⟨?_, isOpen_lt continuous_subtype_val continuous_const⟩
  rw [hset]
  exact isClosed_le continuous_subtype_val continuous_const

/-- The lower spectral indicator is continuous because the cut is in the
actual resolvent set. -/
def magneticLowerSpectrumIndicator (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    C(MagneticRealSpectrum α lam, ℝ) :=
  (LocallyConstant.charFn ℝ (magneticLowerSpectrum_isClopen α lam energy hm)).toContinuousMap

@[simp] theorem magneticLowerSpectrumIndicator_apply (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (x : MagneticRealSpectrum α lam) :
    magneticLowerSpectrumIndicator α lam energy hm x = if (x : ℝ) < energy then 1 else 0 := by
  rfl

/-- The actual CFC projection onto energies strictly below the cut. -/
def magneticGapProjection (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticAlgebra α :=
  cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
    (magneticLowerSpectrumIndicator α lam energy hm)

theorem magneticGapProjection_isSelfAdjoint (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    IsSelfAdjoint (magneticGapProjection α lam energy hm) :=
  cfcHom_predicate (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
    (magneticLowerSpectrumIndicator α lam energy hm)

theorem magneticGapProjection_idempotent (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticGapProjection α lam energy hm * magneticGapProjection α lam energy hm =
      magneticGapProjection α lam energy hm := by
  unfold magneticGapProjection
  rw [← map_mul]
  congr 1
  ext x
  simp only [ContinuousMap.mul_apply, magneticLowerSpectrumIndicator_apply]
  split_ifs <;> norm_num

/-- The projection trace is exactly the lower-set mass of the compact
root-state spectral measure, represented as a real number. -/
theorem magneticGapProjection_trace_eq_spectralMass (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticTraceReal α (magneticGapProjection α lam energy hm) =
      (magneticSpectralMeasure α lam (magneticLowerSpectrum α lam energy)).toReal := by
  rw [magneticGapProjection, ← magneticSpectralMeasure_integral]
  change (∫ x, (magneticLowerSpectrum α lam energy).indicator 1 x
    ∂magneticSpectralMeasure α lam) = _
  simpa only [measureReal_def] using
    (integral_indicator_one (μ := magneticSpectralMeasure α lam)
      (magneticLowerSpectrum_isClopen α lam energy hm).isClosed.measurableSet)

/-- Equivalently, the trace is the mass of the lower half-line for the
actual real-line root-state spectral measure. -/
theorem magneticGapProjection_trace_eq_realSpectralMass (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticTraceReal α (magneticGapProjection α lam energy hm) =
      (magneticRealSpectralMeasure α lam (Iio energy)).toReal := by
  rw [magneticGapProjection_trace_eq_spectralMass α lam energy hm,
    magneticRealSpectralMeasure, Measure.map_apply continuous_subtype_val.measurable measurableSet_Iio]
  rfl

end CriticalDTM

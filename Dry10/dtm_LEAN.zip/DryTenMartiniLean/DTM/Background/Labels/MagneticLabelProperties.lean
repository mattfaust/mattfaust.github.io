import DTM.Background.Labels.MagneticLabelUniqueness
import DTM.Background.Labels.MagneticLabelStability

/-!
# The actual magnetic label interfaces

The constructed spectral mass is locally constant on the actual joint
resolvent domain, distinguishes bounded gaps, and takes the exterior values
zero and one. These statements discharge the label interfaces used in
the gap-continuation and critical-limit reductions.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology ContinuousFunctionalCalculus

theorem magneticLowerMass_locallyConstantOff (α lam : ℝ) :
    LocallyConstantOff (magneticRealSpectrumSet α lam) (magneticLowerMass α lam) := by
  intro energy henergy
  have hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) :=
    spectrum.not_mem_iff.mp henergy
  have hcont : Continuous (fun x : ℝ => (lam, x)) := continuous_const.prodMk continuous_id
  exact hcont.continuousAt.eventually (magneticLowerMass_eventually_eq α (lam, energy) hm)

/-- Below the entire actual spectrum the CFC indicator is zero, so the
actual spectral mass is zero. -/
theorem magneticLowerMass_eq_zero_of_below_spectrum (α lam energy : ℝ)
    (hbelow : ∀ x ∈ magneticRealSpectrumSet α lam, energy < x) :
    magneticLowerMass α lam energy = 0 := by
  have hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) := by
    apply spectrum.not_mem_iff.mp
    intro hmem
    exact (lt_irrefl energy) (hbelow energy hmem)
  have hf : magneticLowerSpectrumIndicator α lam energy hm = 0 := by
    ext x
    have hx : energy < (x : ℝ) := hbelow x
      ((magneticRealSpectrumSet_eq_algebraSpectrum α lam).symm ▸ x.property)
    simp only [magneticLowerSpectrumIndicator_apply, if_neg (not_lt_of_ge hx.le),
      ContinuousMap.zero_apply]
  have hproj : magneticGapProjection α lam energy hm = 0 := by
    unfold magneticGapProjection
    rw [hf, map_zero]
  rw [magneticLowerMass_eq_projection_trace α lam energy hm, hproj, map_zero]

/-- Above the entire actual spectrum the CFC indicator is one, so trace
normalization gives spectral mass one. -/
theorem magneticLowerMass_eq_one_of_above_spectrum (α lam energy : ℝ)
    (habove : ∀ x ∈ magneticRealSpectrumSet α lam, x < energy) :
    magneticLowerMass α lam energy = 1 := by
  have hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) := by
    apply spectrum.not_mem_iff.mp
    intro hmem
    exact (lt_irrefl energy) (habove energy hmem)
  have hf : magneticLowerSpectrumIndicator α lam energy hm = 1 := by
    ext x
    have hx : (x : ℝ) < energy := habove x
      ((magneticRealSpectrumSet_eq_algebraSpectrum α lam).symm ▸ x.property)
    simp only [magneticLowerSpectrumIndicator_apply, if_pos hx, ContinuousMap.one_apply]
  have hproj : magneticGapProjection α lam energy hm = 1 := by
    unfold magneticGapProjection
    rw [hf, map_one]
  rw [magneticLowerMass_eq_projection_trace α lam energy hm, hproj, magneticTraceReal_one]

theorem magneticLowerMass_hasExteriorLabels (α lam : ℝ) :
    HasExteriorLabels (magneticRealSpectrumSet α lam) (magneticLowerMass α lam) :=
  ⟨magneticLowerMass_eq_zero_of_below_spectrum α lam,
    magneticLowerMass_eq_one_of_above_spectrum α lam⟩

end CriticalDTM

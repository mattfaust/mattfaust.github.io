import DTM.Background.Labels.MagneticProjectionContinuity
import DTM.Background.Realization.MagneticLowerMass

/-!
# Local stability of the actual magnetic spectral mass

Joint norm continuity of the actual gap projection and conjugacy of nearby
idempotents make its fixed canonical trace locally constant. The static
projection/measure identity identifies that trace with the actual lower
spectral mass. No continuity of an unspecified IDS is assumed.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

/-- Local constancy of the actual lower spectral mass on the genuine joint
resolvent domain, proved through the constructed continuous projections. -/
theorem magneticLowerMass_isLocallyConstant (α : ℝ) :
    IsLocallyConstant (fun p : realJointResolventDomain α =>
      magneticLowerMass α p.1.1 p.1.2) := by
  have htrace := trace_projection_isLocallyConstant
    (magneticTraceReal α) (magneticTraceReal_cyclic α)
    (magneticJointGapProjection α) (magneticJointGapProjection_continuous α)
    (magneticJointGapProjection_idempotent α)
  have hfun : (fun p : realJointResolventDomain α => magneticLowerMass α p.1.1 p.1.2) =
      (fun p : realJointResolventDomain α => magneticTraceReal α (magneticJointGapProjection α p)) := by
    funext p
    exact magneticLowerMass_eq_projection_trace α p.1.1 p.1.2 p.2
  rw [hfun]
  exact htrace

/-- The local equality holds on an ambient joint parameter neighborhood, not
merely along one previously selected energy path. -/
theorem magneticLowerMass_eventually_eq (α : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    ∀ᶠ q in 𝓝 p, magneticLowerMass α q.1 q.2 = magneticLowerMass α p.1 p.2 := by
  rw [← (realJointResolventDomain_isOpen α).isOpenEmbedding_subtypeVal.map_nhds_eq
    (⟨p, hp⟩ : realJointResolventDomain α)]
  exact (magneticLowerMass_isLocallyConstant α).eventually_eq
    (⟨p, hp⟩ : realJointResolventDomain α)

/-- Any continuous resolvent curve over a connected parameter space has one
constant actual spectral-mass value. -/
theorem magneticLowerMass_constant_on_resolvent_curve
    {X : Type*} [TopologicalSpace X] [PreconnectedSpace X]
    (α : ℝ) (p : X → ℝ × ℝ) (hcont : Continuous p)
    (hres : ∀ x, p x ∈ realJointResolventDomain α) (x y : X) :
    magneticLowerMass α (p x).1 (p x).2 = magneticLowerMass α (p y).1 (p y).2 := by
  let curve : X → realJointResolventDomain α := fun x => ⟨p x, hres x⟩
  have hc : Continuous curve := hcont.subtype_mk hres
  exact ((magneticLowerMass_isLocallyConstant α).comp_continuous hc).apply_eq_of_preconnectedSpace x y

end CriticalDTM

import DTM.Background.Realization.MagneticLowerMass
import DTM.Background.Realization.MagneticTraceFaithful
import DTM.Background.Historical.LabelledBranchGluing

/-!
# The actual lower spectral mass determines its gap

For two ordered resolvent cuts the difference of the lower spectral
projections is itself a projection. Equal actual trace masses and faithfulness
force this difference to vanish. Injectivity of the continuous functional
calculus then identifies the two cuts on the entire spectrum, so they cannot
straddle either endpoint of a bounded spectral gap.
-/

noncomputable section

namespace CriticalDTM

open Set
open scoped ContinuousFunctionalCalculus

/-- Spectral permanence identifies the internal real CFC spectrum with the
real slice of the actual lattice operator's complex spectrum. -/
theorem magneticRealSpectrumSet_eq_algebraSpectrum (α lam : ℝ) :
    magneticRealSpectrumSet α lam = spectrum ℝ (magneticAlgebraHamiltonian α lam) := by
  ext energy
  change (energy : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ)) ↔
    energy ∈ spectrum ℝ (magneticAlgebraHamiltonian α lam)
  rw [spectrum.mem_iff, spectrum.mem_iff]
  have hunit : IsUnit (algebraMap ℂ MagneticBoundedOperator (energy : ℂ) -
        hOperator α (lam : ℂ)) ↔ IsUnit (magneticAlgebraPencil α lam energy) := by
    rw [← magneticAlgebraPencil_coe]
    exact (magneticAlgebra α).coe_isUnit
  simpa only [magneticAlgebraPencil, Algebra.algebraMap_eq_smul_one] using not_congr hunit

/-- Between ordered real resolvent cuts the difference of the lower
spectral projections is again an idempotent. -/
theorem magneticGapProjection_sub_idempotent (α lam x y : ℝ)
    (hx : (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hy : (y : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) (hxy : x ≤ y) :
    (magneticGapProjection α lam y hy - magneticGapProjection α lam x hx) *
        (magneticGapProjection α lam y hy - magneticGapProjection α lam x hx) =
      magneticGapProjection α lam y hy - magneticGapProjection α lam x hx := by
  unfold magneticGapProjection
  rw [← map_sub, ← map_mul]
  congr 1
  ext z
  simp only [ContinuousMap.mul_apply, ContinuousMap.sub_apply,
    magneticLowerSpectrumIndicator_apply]
  by_cases hzx : (z : ℝ) < x
  · simp [hzx, hzx.trans_le hxy]
  · by_cases hzy : (z : ℝ) < y <;> simp [hzx, hzy]

/-- Equal traces of nested spectral projections imply equal projections,
using the proved faithfulness of the actual magnetic trace. -/
theorem magneticGapProjection_eq_of_ordered_trace_eq (α lam x y : ℝ)
    (hx : (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hy : (y : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) (hxy : x ≤ y)
    (htrace : magneticTraceReal α (magneticGapProjection α lam x hx) =
      magneticTraceReal α (magneticGapProjection α lam y hy)) :
    magneticGapProjection α lam x hx = magneticGapProjection α lam y hy := by
  have hself := (magneticGapProjection_isSelfAdjoint α lam y hy).sub
    (magneticGapProjection_isSelfAdjoint α lam x hx)
  have hzero : magneticGapProjection α lam y hy - magneticGapProjection α lam x hx = 0 := by
    apply magneticTraceReal_faithful α
    rw [hself.star_eq, magneticGapProjection_sub_idempotent α lam x y hx hy hxy,
      map_sub, htrace, sub_self]
  exact (sub_eq_zero.mp hzero).symm

theorem magneticGapProjection_eq_of_mass_eq (α lam x y : ℝ)
    (hx : (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hy : (y : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hmass : magneticLowerMass α lam x = magneticLowerMass α lam y) :
    magneticGapProjection α lam x hx = magneticGapProjection α lam y hy := by
  rw [magneticLowerMass_eq_projection_trace α lam x hx,
    magneticLowerMass_eq_projection_trace α lam y hy] at hmass
  rcases le_total x y with hxy | hyx
  · exact magneticGapProjection_eq_of_ordered_trace_eq α lam x y hx hy hxy hmass
  · exact (magneticGapProjection_eq_of_ordered_trace_eq α lam y x hy hx hyx hmass.symm).symm

/-- Equal actual lower masses give identical cuts at every spectral point.
The injectivity used here is that of the actual continuous functional calculus. -/
theorem magneticLowerMass_eq_implies_same_spectral_cut (α lam x y : ℝ)
    (hx : (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hy : (y : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hmass : magneticLowerMass α lam x = magneticLowerMass α lam y) :
    ∀ z ∈ magneticRealSpectrumSet α lam, z < x ↔ z < y := by
  have hproj := magneticGapProjection_eq_of_mass_eq α lam x y hx hy hmass
  have hind : magneticLowerSpectrumIndicator α lam x hx =
      magneticLowerSpectrumIndicator α lam y hy :=
    (cfcHom_isClosedEmbedding (magneticAlgebraHamiltonian_isSelfAdjoint α lam)).injective hproj
  intro z hz
  rw [magneticRealSpectrumSet_eq_algebraSpectrum] at hz
  have hvalue := congrArg (fun f : C(MagneticRealSpectrum α lam, ℝ) => f ⟨z, hz⟩) hind
  simp only [magneticLowerSpectrumIndicator_apply] at hvalue
  constructor
  · intro hzx
    by_contra hzy
    simp [hzx, hzy] at hvalue
  · intro hzy
    by_contra hzx
    simp [hzx, hzy] at hvalue

end CriticalDTM

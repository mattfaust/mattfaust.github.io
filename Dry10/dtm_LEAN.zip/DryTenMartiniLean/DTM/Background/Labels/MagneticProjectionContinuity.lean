import DTM.Background.Labels.MagneticGapProjection
import DTM.Background.Support.RealJointGreen
import DTM.Background.Labels.ProjectionContinuity
import DTM.Background.Support.CFCParameterContinuity

/-!
# Common spectral cuts for the actual magnetic gap projection

An open rectangle in the joint resolvent domain supplies a common gap for
nearby couplings. A fixed continuous cutoff then represents every nearby
lower spectral projection by the actual continuous functional calculus.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology ContinuousFunctionalCalculus

local instance projectionContinuity_realNormedSpace (α : ℝ) :
    NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

local instance projectionContinuity_realModule (α : ℝ) : Module ℝ (magneticAlgebra α) :=
  @Algebra.toModule ℝ (magneticAlgebra α) _ _
    (magneticAlgebra_realNormedAlgebra α).toAlgebra

local instance projectionContinuity_realSMulCommClass (α : ℝ) :
    SMulCommClass ℝ (magneticAlgebra α) (magneticAlgebra α) :=
  Algebra.to_smulCommClass

/-- A continuous ramp from one below `a` to zero above `b`. -/
def gapCutoff (a b x : ℝ) : ℝ := max 0 (min 1 ((b - x) / (b - a)))

theorem gapCutoff_continuous (a b : ℝ) : Continuous (gapCutoff a b) :=
  continuous_const.max (continuous_const.min
    ((continuous_const.sub continuous_id).div_const (b - a)))

theorem gapCutoff_eq_one {a b x : ℝ} (hab : a < b) (hx : x ≤ a) :
    gapCutoff a b x = 1 := by
  have hdiv : 1 ≤ (b - x) / (b - a) :=
    (le_div_iff₀ (sub_pos.mpr hab)).mpr (by linarith)
  simp [gapCutoff, min_eq_left hdiv]

theorem gapCutoff_eq_zero {a b x : ℝ} (hab : a < b) (hx : b ≤ x) :
    gapCutoff a b x = 0 := by
  have hdiv : (b - x) / (b - a) ≤ 0 :=
    div_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr hx) (sub_pos.mpr hab).le
  rw [gapCutoff, min_eq_right (hdiv.trans zero_le_one), max_eq_left hdiv]

theorem magneticAlgebraHamiltonian_continuous (α : ℝ) :
    Continuous (magneticAlgebraHamiltonian α) :=
  continuous_const.add (continuous_id.smul continuous_const)

/-- All energies in one fixed interval remain resolvent energies at every
sufficiently nearby coupling, while the varying cut remains inside it. -/
theorem magnetic_common_gap_neighborhood (α : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    ∃ a b : ℝ, p.2 ∈ Ioo a b ∧
      ∀ᶠ q in 𝓝 p, q.2 ∈ Ioo a b ∧
        ∀ x ∈ Ioo a b, (x : ℂ) ∈ resolventSet ℂ (hOperator α (q.1 : ℂ)) := by
  obtain ⟨u, hu, v, hv, huv⟩ := mem_nhds_prod_iff.mp
    ((realJointResolventDomain_isOpen α).mem_nhds hp)
  obtain ⟨a, b, hpab, habv⟩ := mem_nhds_iff_exists_Ioo_subset.mp hv
  refine ⟨a, b, hpab, ?_⟩
  have hu' : ∀ᶠ q : ℝ × ℝ in 𝓝 p, q.1 ∈ u :=
    continuous_fst.continuousAt.eventually hu
  have hv' : ∀ᶠ q : ℝ × ℝ in 𝓝 p, q.2 ∈ Ioo a b :=
    continuous_snd.continuousAt.eventually (isOpen_Ioo.mem_nhds hpab)
  filter_upwards [hu', hv'] with q hqu hqv
  refine ⟨hqv, ?_⟩
  intro x hx
  have hpair : (q.1, x) ∈ realJointResolventDomain α := huv ⟨hqu, habv hx⟩
  exact hpair

/-- On a common spectral gap, one fixed continuous function represents the
actual gap projection for every cut inside that gap. -/
theorem magneticGapProjection_eq_cutoff (α lam energy a b : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (henergy : energy ∈ Ioo a b)
    (hgap : ∀ x ∈ Ioo a b, (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticGapProjection α lam energy hm =
      cfc (gapCutoff a b) (magneticAlgebraHamiltonian α lam) := by
  have hab : a < b := henergy.1.trans henergy.2
  have havoid (x : MagneticRealSpectrum α lam) : (x : ℝ) ≤ a ∨ b ≤ (x : ℝ) := by
    by_cases hxa : (x : ℝ) ≤ a
    · exact Or.inl hxa
    · right
      by_contra hbx
      exact resolvent_energy_not_mem_magneticRealSpectrum α lam x
        (hgap x ⟨lt_of_not_ge hxa, lt_of_not_ge hbx⟩) x.property
  rw [magneticGapProjection, cfc_apply (gapCutoff a b)
    (magneticAlgebraHamiltonian α lam)
    (magneticAlgebraHamiltonian_isSelfAdjoint α lam) (gapCutoff_continuous a b).continuousOn]
  congr 1
  ext x
  change magneticLowerSpectrumIndicator α lam energy hm x = gapCutoff a b x
  rcases havoid x with hx | hx
  · rw [magneticLowerSpectrumIndicator_apply, if_pos (hx.trans_lt henergy.1),
      gapCutoff_eq_one hab hx]
  · rw [magneticLowerSpectrumIndicator_apply, if_neg (not_lt_of_ge (henergy.2.le.trans hx)),
      gapCutoff_eq_zero hab hx]

/-- The actual joint projection, with its necessary resolvent hypothesis
carried by the parameter domain. -/
def magneticJointGapProjection (α : ℝ) (p : realJointResolventDomain α) : magneticAlgebra α :=
  magneticGapProjection α p.1.1 p.1.2 p.2

/-- Genuine joint norm continuity of the actual gap projection. The common
gap and fixed cutoff are constructed; no projection-continuity hypothesis
is assumed. -/
theorem magneticJointGapProjection_continuousAt (α : ℝ)
    (p : realJointResolventDomain α) : ContinuousAt (magneticJointGapProjection α) p := by
  obtain ⟨a, b, _, hnear⟩ := magnetic_common_gap_neighborhood α p.1 p.2
  have hH : Continuous (fun q : realJointResolventDomain α =>
      magneticAlgebraHamiltonian α q.1.1) :=
    (magneticAlgebraHamiltonian_continuous α).comp
      (continuous_fst.comp continuous_subtype_val)
  have hc := continuousAt_cfc_of_continuous
    (fun q : realJointResolventDomain α => magneticAlgebraHamiltonian α q.1.1)
    p hH.continuousAt (gapCutoff a b) (gapCutoff_continuous a b)
    (Filter.Eventually.of_forall
      (fun q => magneticAlgebraHamiltonian_isSelfAdjoint α q.1.1))
  apply hc.congr_of_eventuallyEq
  filter_upwards [continuous_subtype_val.continuousAt.eventually hnear] with q hq
  exact magneticGapProjection_eq_cutoff α q.1.1 q.1.2 a b q.2 hq.1 hq.2

theorem magneticJointGapProjection_continuous (α : ℝ) :
    Continuous (magneticJointGapProjection α) :=
  continuous_iff_continuousAt.mpr (magneticJointGapProjection_continuousAt α)

theorem magneticJointGapProjection_idempotent (α : ℝ)
    (p : realJointResolventDomain α) :
    magneticJointGapProjection α p * magneticJointGapProjection α p =
      magneticJointGapProjection α p :=
  magneticGapProjection_idempotent α p.1.1 p.1.2 p.2

end CriticalDTM

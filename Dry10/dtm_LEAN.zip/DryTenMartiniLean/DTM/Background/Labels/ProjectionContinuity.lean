import DTM.Background.Labels.TraceProjection
import Mathlib.Analysis.Normed.Ring.Units
import Mathlib.Topology.LocallyConstant.Basic
import Mathlib.Tactic.Abel

/-!
# Trace constancy for continuous idempotent families

Nearby idempotents are intertwined by an invertible element. A fixed cyclic
trace is invariant under this conjugacy, so its value is locally constant on
any norm-continuous family of idempotents. No derivative is assumed.

This is the continuity step for projection labels. It does not construct a
Riesz projection or identify its trace with an integrated density of states.
-/

noncomputable section

namespace CriticalDTM

open scoped Topology

variable {A : Type*} [NormedRing A]

/-- The intertwiner taking the `Q` decomposition to the `P` decomposition. -/
def projectionIntertwiner (P Q : A) : A := P * Q + (1 - P) * (1 - Q)

theorem projectionIntertwiner_self (P : A) (hP : P * P = P) :
    projectionIntertwiner P P = 1 := by
  simp only [projectionIntertwiner, mul_sub, sub_mul, mul_one, one_mul, hP]
  abel

theorem projectionIntertwiner_intertwines (P Q : A)
    (hP : P * P = P) (hQ : Q * Q = Q) :
    P * projectionIntertwiner P Q = projectionIntertwiner P Q * Q := by
  have hPzero : P * (1 - P) = 0 := by rw [mul_sub, mul_one, hP, sub_self]
  have hQzero : (1 - Q) * Q = 0 := by rw [sub_mul, one_mul, hQ, sub_self]
  calc
    P * projectionIntertwiner P Q = P * Q := by
      simp only [projectionIntertwiner, mul_add, ← mul_assoc, hP, hPzero, zero_mul, add_zero]
    _ = projectionIntertwiner P Q * Q := by
      simp only [projectionIntertwiner, add_mul, mul_assoc, hQ, hQzero, mul_zero, add_zero]

variable [NormedAlgebra ℝ A]

/-- Cyclicity gives equality of traces for idempotents related by an invertible
intertwiner. Self-adjointness is unnecessary. -/
theorem trace_eq_of_projectionIntertwiner_isUnit
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (P Q : A) (hP : P * P = P) (hQ : Q * Q = Q)
    (hunit : IsUnit (projectionIntertwiner P Q)) : trace P = trace Q := by
  let U := projectionIntertwiner P Q
  have hinter : P * U = U * Q := projectionIntertwiner_intertwines P Q hP hQ
  calc
    trace P = trace ((P * U) * Ring.inverse U) := by
      rw [mul_assoc, Ring.mul_inverse_cancel U hunit, mul_one]
    _ = trace ((U * Q) * Ring.inverse U) := by rw [hinter]
    _ = trace (Ring.inverse U * (U * Q)) := hcyclic _ _
    _ = trace Q := by rw [← mul_assoc, Ring.inverse_mul_cancel U hunit, one_mul]

variable [CompleteSpace A] {X : Type*} [TopologicalSpace X]

/-- At every continuity point of a locally idempotent family, its trace is
constant on a neighborhood. The neighborhood and invertibility are derived. -/
theorem trace_projection_eventually_eq
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (P : X → A) (x : X) (hcontinuous : ContinuousAt P x)
    (hprojection : ∀ᶠ t in 𝓝 x, P t * P t = P t) :
    ∀ᶠ t in 𝓝 x, trace (P t) = trace (P x) := by
  have hx : P x * P x = P x := hprojection.self_of_nhds
  have hcont : ContinuousAt (fun t => projectionIntertwiner (P t) (P x)) x :=
    (hcontinuous.mul continuousAt_const).add
      ((continuousAt_const.sub hcontinuous).mul continuousAt_const)
  have hunit : IsUnit (projectionIntertwiner (P x) (P x)) := by
    rw [projectionIntertwiner_self (P x) hx]
    exact isUnit_one
  have hnear : ∀ᶠ t in 𝓝 x, IsUnit (projectionIntertwiner (P t) (P x)) :=
    hcont.eventually (Units.isOpen.mem_nhds hunit)
  filter_upwards [hprojection, hnear] with t ht htu
  exact trace_eq_of_projectionIntertwiner_isUnit trace hcyclic (P t) (P x) ht hx htu

/-- A continuous family of idempotents has a locally constant trace. -/
theorem trace_projection_isLocallyConstant
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (P : X → A) (hcontinuous : Continuous P)
    (hprojection : ∀ x, P x * P x = P x) :
    IsLocallyConstant (fun x => trace (P x)) := by
  apply (IsLocallyConstant.iff_eventually_eq _).mpr
  intro x
  exact trace_projection_eventually_eq trace hcyclic P x hcontinuous.continuousAt
    (Filter.Eventually.of_forall hprojection)

end CriticalDTM

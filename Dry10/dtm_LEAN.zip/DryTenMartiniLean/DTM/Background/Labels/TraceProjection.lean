import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Analysis.Calculus.Deriv.Add

/-!
# Proof guide: local calculus

Supporting trace-calculus interface: CyclicTrace is the fixed real-linear cyclicity hypothesis.
The manuscript gap-label proof instantiates the differentiated-projection
lemmas below with its fixed-contour physical Riesz projector in
`DTMAudit.ManuscriptRieszContinuity`.
No coupling-independent spectral measure is assumed.
-/

/-!
# Fixed cyclic traces of differentiable projection curves

The trace is one fixed continuous linear functional. The projection varies with
the real parameter. Differentiation therefore acts on the projection, not on
an assumed parameter-independent spectral measure.

This file does not construct Riesz projections, establish differentiability
of a spectral projection, or identify its trace with an integrated density of
states. Those are explicit separate application requirements.

We work over the real scalars. A complex operator algebra can be regarded as a
real normed algebra and the real part of its canonical trace has this type.
No positivity or normalization assumption on the trace is needed here.
-/

noncomputable section

namespace CriticalDTM

open scoped Topology

variable {A : Type*} [NormedRing A] [NormedAlgebra ℝ A]

/-- Cyclicity is the trace property used below. -/
/- Hypothesis: cyclicity concerns one fixed continuous real-linear functional. It cycles factors inside the trace, not operators outside it. -/
def CyclicTrace (trace : A →L[ℝ] ℝ) : Prop :=
  ∀ a b, trace (a * b) = trace (b * a)

omit [NormedAlgebra ℝ A] in
/-- An infinitesimal deformation of an idempotent has zero diagonal corner. -/
/- Projection calculation used by the current manuscript label proof: differentiating P^2=P yields DP+PD=D, whose P-corner vanishes. -/
theorem projection_tangent_corner
    (P D : A) (hprojection : P * P = P)
    (htangent : D * P + P * D = D) :
    P * D * P = 0 := by
  have hmult : P * D * P + P * D = P * D := by
    calc
      P * D * P + P * D = P * (D * P + P * D) := by
        simp only [mul_add, ← mul_assoc, hprojection]
      _ = P * D := by rw [htangent]
  exact add_right_cancel
    (show P * D * P + P * D = 0 + P * D from by simpa only [zero_add] using hmult)

/-- The trace of an idempotent's infinitesimal deformation is zero. -/
/- Auxiliary trace calculation: cyclicity transports the zero P-corner to trace(D)=0; this does not construct or differentiate a spectral projection. -/
theorem trace_projection_tangent_zero
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (P D : A) (hprojection : P * P = P)
    (htangent : D * P + P * D = D) : trace D = 0 := by
  have hcorner := projection_tangent_corner P D hprojection htangent
  have htraceCorner : trace (P * D) = 0 := by
    calc
      trace (P * D) = trace ((P * P) * D) := by rw [hprojection]
      _ = trace (P * (P * D)) := by rw [mul_assoc]
      _ = trace ((P * D) * P) := hcyclic P (P * D)
      _ = 0 := by rw [hcorner, map_zero]
  have htrace := congrArg trace htangent
  rw [map_add, hcyclic D P, htraceCorner, add_zero] at htrace
  exact htrace.symm

/-- The tangent relation follows by genuinely differentiating the local
identity `P(t)² = P(t)` and using uniqueness of derivatives. -/
theorem projection_derivative_tangent
    (P : ℝ → A) (D : A) (x : ℝ)
    (hderivative : HasDerivAt P D x)
    (hprojection : ∀ᶠ t in 𝓝 x, P t * P t = P t) :
    D * P x + P x * D = D := by
  exact (hderivative.mul hderivative).unique
    (hderivative.congr_of_eventuallyEq hprojection)

/-- A fixed cyclic trace has derivative zero along a differentiable local
curve of projections. This is a theorem about a varying projection, not an
assumption that its associated spectral measure is fixed. -/
/- Current manuscript label route: fixed-contour operator differentiability and physical projector idempotence are supplied by ManuscriptRieszContinuity; this theorem differentiates P^2=P and applies cyclicity. -/
theorem trace_projection_hasDerivAt_zero
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (P : ℝ → A) (D : A) (x : ℝ)
    (hderivative : HasDerivAt P D x)
    (hprojection : ∀ᶠ t in 𝓝 x, P t * P t = P t) :
    HasDerivAt (fun t => trace (P t)) 0 x := by
  have htangent := projection_derivative_tangent P D x hderivative hprojection
  have htrace := trace_projection_tangent_zero trace hcyclic (P x) D
    hprojection.self_of_nhds htangent
  have hcomposition := trace.hasFDerivAt.comp_hasDerivAt x hderivative
  simpa only [Function.comp_def, htrace] using hcomposition

end CriticalDTM

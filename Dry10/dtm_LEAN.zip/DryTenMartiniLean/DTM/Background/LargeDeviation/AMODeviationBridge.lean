import DTM.Background.LargeDeviation.AMOPhaseMeasure
import DTM.Background.Avalanche.AMOAvalancheAverageBadSet
import DTM.Background.LargeDeviation.AMOPhaseBadSetComplexity

/-!
# The Fourier deviation event controls the actual transfer deviation event

The finite Frobenius logarithm and its mean differ from the actual Euclidean
operator logarithm and its mean by the already-proved `log 2 / (2n)` error.
The unit-circle quotient transports the normalized measure exactly. Thus no
new distribution or phase-normalization assumption enters the LDT assembly.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set
open scoped Topology

local instance : Fact (0 < (1 : ℝ)) := ⟨by norm_num⟩

/-- The zero Fourier coefficient is the actual normalized finite phase mean. -/
theorem amoFiniteFrobeniusCircle_zeroCoeff (α lam : ℝ) (z : ℂ) (n : ℕ) :
    fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0 =
      ((∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t : ℝ) : ℂ) := by
  rw [fourierCoeff_amoFiniteFrobeniusCircle, logFourierCoeff]
  simp only [neg_zero, logFourierChar_zero, mul_one]
  exact Complex.ofRealCLM.intervalIntegral_comp_comm
    ((continuous_amoFiniteFrobeniusLog α lam z n).intervalIntegrable 0 1)

/-- A concrete subset statement between the physical operator-log deviation
and the Fourier function's deviation, with both finite normalization errors. -/
theorem amoAvalancheBaseBadSet_subset_fourier_preimage
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (kappa : ℝ)
    (hscale : Real.log 2 / (n : ℝ) ≤ kappa / 2) :
    amoAvalancheBaseBadSet α lam z n kappa ⊆
      (fun t : ℝ => (t : AddCircle (1 : ℝ))) ⁻¹'
        {x : AddCircle (1 : ℝ) | kappa / 2 <
          ‖amoFiniteFrobeniusCircle α lam z n x -
            fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖} := by
  intro t ht
  change kappa / 2 < ‖amoFiniteFrobeniusCircle α lam z n (t : AddCircle (1 : ℝ)) -
    fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖
  rw [amoFiniteFrobeniusCircle_coe, amoFiniteFrobeniusCircle_zeroCoeff,
    ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
  have hp := amoFiniteFrobeniusLog_sub_operator_bounds α lam z n hn t
  have hm := amoFiniteFrobeniusLog_integral_bounds α lam z n hn
  have hdelta : 0 ≤ Real.log 2 / (2 * (n : ℝ)) := by positivity
  have hpabs : |amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ) -
      amoFiniteFrobeniusLog α lam z n t| ≤ Real.log 2 / (2 * (n : ℝ)) := by
    rw [abs_sub_comm, abs_of_nonneg hp.1]
    exact hp.2
  have hmabs : |(∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t) -
      amoFiniteLyapunov α lam z n| ≤ Real.log 2 / (2 * (n : ℝ)) := by
    rw [abs_of_nonneg hm.1]
    exact hm.2
  have htri := abs_sub_le
    (amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ))
    (amoFiniteFrobeniusLog α lam z n t) (amoFiniteLyapunov α lam z n)
  have htri' := abs_sub_le (amoFiniteFrobeniusLog α lam z n t)
    (∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t)
    (amoFiniteLyapunov α lam z n)
  have htwo : 2 * (Real.log 2 / (2 * (n : ℝ))) = Real.log 2 / (n : ℝ) := by ring
  change kappa < |amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ) -
    amoFiniteLyapunov α lam z n| at ht
  linarith

/-- The distribution used by the actual averaged avalanche theorem is bounded
by the genuine normalized-Haar Fourier deviation probability. -/
theorem amoAvalancheBaseBadSet_mass_le_fourier
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (kappa : ℝ)
    (hscale : Real.log 2 / (n : ℝ) ≤ kappa / 2) :
    (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z n kappa) ≤
        AddCircle.haarAddCircle.real
          {x : AddCircle (1 : ℝ) | kappa / 2 <
            ‖amoFiniteFrobeniusCircle α lam z n x -
              fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖} := by
  have hs : MeasurableSet {x : AddCircle (1 : ℝ) | kappa / 2 <
      ‖amoFiniteFrobeniusCircle α lam z n x -
        fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖} :=
    (isOpen_lt continuous_const
      ((amoFiniteFrobeniusCircle α lam z n).continuous.sub continuous_const).norm).measurableSet
  calc
    _ ≤ (volume.restrict (Ioc (0 : ℝ) 1)).real
        ((fun t : ℝ => (t : AddCircle (1 : ℝ))) ⁻¹'
          {x : AddCircle (1 : ℝ) | kappa / 2 <
            ‖amoFiniteFrobeniusCircle α lam z n x -
              fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖}) :=
      measureReal_mono (amoAvalancheBaseBadSet_subset_fourier_preimage α lam z n hn kappa hscale)
    _ = _ := unitCircle_measureReal_preimage hs

/-- The corresponding Frobenius event, centered at the actual operator mean,
is controlled by the same Fourier deviation probability. -/
theorem amoFiniteFrobeniusBadSet_subset_fourier_deviation
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (kappa : ℝ)
    (hscale : Real.log 2 / (n : ℝ) ≤ kappa / 2) :
    amoFiniteFrobeniusBadSet α lam z n (amoFiniteLyapunov α lam z n) kappa ⊆
      {x : AddCircle (1 : ℝ) | kappa / 2 <
        ‖amoFiniteFrobeniusCircle α lam z n x -
          fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖} := by
  intro x hx
  obtain ⟨t, _, rfl⟩ := AddCircle.eq_coe_Ico x
  rw [mem_amoFiniteFrobeniusBadSet_coe] at hx
  change kappa / 2 < ‖amoFiniteFrobeniusCircle α lam z n (t : AddCircle (1 : ℝ)) -
    fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖
  rw [amoFiniteFrobeniusCircle_coe, amoFiniteFrobeniusCircle_zeroCoeff,
    ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
  have hm := amoFiniteFrobeniusLog_integral_bounds α lam z n hn
  have hmabs : |(∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t) -
      amoFiniteLyapunov α lam z n| ≤ Real.log 2 / (2 * (n : ℝ)) := by
    rw [abs_of_nonneg hm.1]
    exact hm.2
  have hdelta : Real.log 2 / (2 * (n : ℝ)) ≤ Real.log 2 / (n : ℝ) := by
    apply div_le_div_of_nonneg_left (Real.log_nonneg (by norm_num))
      (by exact_mod_cast hn)
    nlinarith [show (0 : ℝ) ≤ (n : ℝ) from Nat.cast_nonneg n]
  have htri := abs_sub_le (amoFiniteFrobeniusLog α lam z n t)
    (∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t)
    (amoFiniteLyapunov α lam z n)
  linarith

theorem amoFiniteFrobeniusBadSet_mass_le_fourier
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (kappa : ℝ)
    (hscale : Real.log 2 / (n : ℝ) ≤ kappa / 2) :
    AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z n (amoFiniteLyapunov α lam z n) kappa) ≤
        AddCircle.haarAddCircle.real
          {x : AddCircle (1 : ℝ) | kappa / 2 <
            ‖amoFiniteFrobeniusCircle α lam z n x -
              fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖} :=
  measureReal_mono (amoFiniteFrobeniusBadSet_subset_fourier_deviation α lam z n hn kappa hscale)

end CriticalDTM

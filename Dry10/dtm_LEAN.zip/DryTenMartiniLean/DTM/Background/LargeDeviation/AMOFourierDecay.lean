import DTM.Background.LargeDeviation.AMOTransferPolynomial
import DTM.Background.LargeDeviation.LogPolynomialFourier

/-!
# Uniform Fourier decay for actual finite AMO Frobenius logarithms

The phase variable here is in turns: the actual radian transfer phase is
`2 * π * t`. Polynomial representation and scalar logarithmic Fourier decay
combine to give the uniform `1 / |k|` bound for every positive length.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory

private theorem amo_logFourierChar_one (t : ℝ) :
    logFourierChar 1 t = Complex.exp (((2 * Real.pi * t : ℝ) : ℂ) * Complex.I) := by
  unfold logFourierChar
  congr 1
  push_cast
  ring

/-- The actual normalized Frobenius logarithm, used at positive lengths.
The phase argument `t` is measured in turns, not radians. -/
def amoFiniteFrobeniusLog (α lam : ℝ) (z : ℂ) (n : ℕ) (t : ℝ) : ℝ :=
  (1 / (2 * (n : ℝ))) *
    Real.log (amoTransferFrobeniusSq (amoTransferProduct α lam z (2 * Real.pi * t) n))

/-- The polynomial is the one constructed from the actual transfer entries. -/
theorem amoFiniteFrobeniusLog_eq_polynomial
    (α lam : ℝ) (z : ℂ) (n : ℕ) (t : ℝ) :
    amoFiniteFrobeniusLog α lam z n t = (1 / (2 * (n : ℝ))) *
      Real.log ‖(amoTransferFrobeniusPolynomial α lam z n).eval (logFourierChar 1 t)‖ := by
  rw [amo_logFourierChar_one, norm_amoTransferFrobeniusPolynomial_eval]
  rfl

theorem continuous_amoFiniteFrobeniusLog (α lam : ℝ) (z : ℂ) (n : ℕ) :
    Continuous (amoFiniteFrobeniusLog α lam z n) := by
  change Continuous (fun t : ℝ => amoFiniteFrobeniusLog α lam z n t)
  simp_rw [amoFiniteFrobeniusLog_eq_polynomial]
  exact continuous_const.mul (continuous_logPolynomial_boundary
    (amoTransferFrobeniusPolynomial α lam z n) (fun t =>
      amoTransferFrobeniusPolynomial_eval_ne_zero_of_norm_eq_one α lam z n _
        (logFourierChar_norm 1 t)))

/-- The normalization is transported through the actual Fourier integral. -/
theorem amoFiniteFrobeniusLog_fourier_eq_polynomial
    (α lam : ℝ) (z : ℂ) (n : ℕ) (k : ℤ) :
    logFourierCoeff (amoFiniteFrobeniusLog α lam z n) k =
      ((1 / (2 * (n : ℝ)) : ℝ) : ℂ) *
        logFourierCoeff (fun t => Real.log
          ‖(amoTransferFrobeniusPolynomial α lam z n).eval (logFourierChar 1 t)‖) k := by
  simp only [logFourierCoeff, amoFiniteFrobeniusLog_eq_polynomial,
    Complex.ofReal_mul, mul_assoc, intervalIntegral.integral_const_mul]

/-- Uniform Fourier decay for the actual AMO, with no spectral or arithmetic
assumption on the energy, frequency, or coupling. -/
theorem norm_logFourierCoeff_amoFiniteFrobeniusLog
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) {k : ℤ} (hk : k ≠ 0) :
    ‖logFourierCoeff (amoFiniteFrobeniusLog α lam z n) k‖ ≤ 1 / |(k : ℝ)| := by
  have hnR : 0 < (n : ℝ) := by exact_mod_cast hn
  have hkR : (k : ℝ) ≠ 0 := by exact_mod_cast hk
  have hscalar := norm_logPolynomialFourierCoeff (amoTransferFrobeniusPolynomial α lam z n)
    (amoTransferFrobeniusPolynomial_ne_zero α lam z n)
    (fun t => amoTransferFrobeniusPolynomial_eval_ne_zero_of_norm_eq_one α lam z n _
      (logFourierChar_norm 1 t)) hk
  have hdegree : ((amoTransferFrobeniusPolynomial α lam z n).natDegree : ℝ) ≤
      4 * (n : ℝ) := by
    exact_mod_cast amoTransferFrobeniusPolynomial_natDegree_le α lam z n
  rw [amoFiniteFrobeniusLog_fourier_eq_polynomial, norm_mul, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg (show 0 ≤ 1 / (2 * (n : ℝ)) by positivity)]
  calc
    _ ≤ (1 / (2 * (n : ℝ))) *
        (((amoTransferFrobeniusPolynomial α lam z n).natDegree : ℝ) /
          (2 * |(k : ℝ)|)) := mul_le_mul_of_nonneg_left hscalar (by positivity)
    _ ≤ (1 / (2 * (n : ℝ))) * ((4 * (n : ℝ)) / (2 * |(k : ℝ)|)) :=
      mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right hdegree (by positivity))
        (by positivity)
    _ = 1 / |(k : ℝ)| := by
      field_simp [ne_of_gt hnR, abs_ne_zero.mpr hkR]
      ring

end CriticalDTM

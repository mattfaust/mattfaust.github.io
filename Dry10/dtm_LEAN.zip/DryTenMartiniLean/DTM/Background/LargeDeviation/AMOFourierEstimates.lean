import DTM.Background.LargeDeviation.AMOFourierDecay
import DTM.Background.LargeDeviation.AMOFrobeniusBounds
import DTM.Background.Transfer.AMOTransferShiftBounds
import Mathlib.Analysis.Fourier.AddCircle

/-!
# Uniform scalar estimates for the actual finite AMO logarithms

The polynomial Fourier estimate and the physical one-step transfer bounds are
combined for the same finite Frobenius logarithm. Its circle realization is
an actual continuous function on the unit phase circle, suitable for Fourier
smoothing. No large-deviation estimate or spectral property is assumed.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Topology

local instance : Fact (0 < (1 : ℝ)) := ⟨by norm_num⟩

theorem amoFiniteFrobeniusLog_sub_operator_bounds
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (t : ℝ) :
    0 ≤ amoFiniteFrobeniusLog α lam z n t -
      amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ) ∧
    amoFiniteFrobeniusLog α lam z n t -
      amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ) ≤
        Real.log 2 / (2 * (n : ℝ)) := by
  simpa only [amoFiniteFrobeniusLog, amoTransferLogNorm, one_div, div_eq_mul_inv,
    mul_comm, one_mul] using amoTransferProduct_normalized_log_frobenius_gap
      α lam z (2 * Real.pi * t) n hn

/-- A one-base-rotation error of order `1/n` for the exact function whose
Fourier coefficients were bounded by the polynomial calculation. -/
theorem amoFiniteFrobeniusLog_shift_abs_sub_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (t : ℝ) :
    |amoFiniteFrobeniusLog α lam z n (t + α) - amoFiniteFrobeniusLog α lam z n t| ≤
      (2 * Real.log (amoTransferBound lam z) + Real.log 2) / (n : ℝ) := by
  have hleft := amoFiniteFrobeniusLog_sub_operator_bounds α lam z n hn (t + α)
  have hright := amoFiniteFrobeniusLog_sub_operator_bounds α lam z n hn t
  have hshift := amoTransferLogNorm_div_shift_abs_sub_le α lam z (2 * Real.pi * t) n hn
  rw [mul_add] at hleft
  have hshift' := abs_le.mp hshift
  have hlog : 0 ≤ Real.log 2 := Real.log_nonneg (by norm_num)
  have hn' : 0 < (n : ℝ) := by exact_mod_cast hn
  have hscale : 0 ≤ Real.log 2 / (2 * (n : ℝ)) := by positivity
  have htwo : Real.log 2 / (n : ℝ) = 2 * (Real.log 2 / (2 * (n : ℝ))) := by ring
  apply abs_le.mpr
  constructor <;> rw [add_div] <;> linarith

/-- The genuine finite transfer mean in the normalized phase convention. -/
theorem amoFiniteLyapunov_eq_unit_interval (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoFiniteLyapunov α lam z n =
      ∫ t in (0 : ℝ)..1, amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ) := by
  have h := intervalIntegral.integral_comp_mul_left
    (a := 0) (b := 1) (c := 2 * Real.pi)
    (fun θ => amoTransferLogNorm α lam z θ n) (by positivity)
  have hmean : (∫ t in (0 : ℝ)..1, amoTransferLogNorm α lam z (2 * Real.pi * t) n) =
      (∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm α lam z θ n) /
        (2 * Real.pi) := by
    simpa only [mul_zero, mul_one, zero_mul, one_mul, smul_eq_mul,
      div_eq_mul_inv, mul_comm] using h
  rw [intervalIntegral.integral_div, hmean]
  rfl

theorem amoFiniteFrobeniusLog_integral_bounds
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) :
    0 ≤ (∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t) -
      amoFiniteLyapunov α lam z n ∧
    (∫ t in (0 : ℝ)..1, amoFiniteFrobeniusLog α lam z n t) -
      amoFiniteLyapunov α lam z n ≤ Real.log 2 / (2 * (n : ℝ)) := by
  have hf : IntervalIntegrable (amoFiniteFrobeniusLog α lam z n) volume (0 : ℝ) 1 :=
    (continuous_amoFiniteFrobeniusLog α lam z n).intervalIntegrable 0 1
  have hg : IntervalIntegrable (fun t =>
      amoTransferLogNorm α lam z (2 * Real.pi * t) n / (n : ℝ)) volume 0 1 :=
    (((continuous_amoTransferLogNorm_phase α lam z n).comp
      (continuous_const.mul continuous_id)).div_const (n : ℝ)).intervalIntegrable 0 1
  rw [amoFiniteLyapunov_eq_unit_interval, ← intervalIntegral.integral_sub hf hg]
  constructor
  · exact intervalIntegral.integral_nonneg (by norm_num)
      (fun t _ => (amoFiniteFrobeniusLog_sub_operator_bounds α lam z n hn t).1)
  · have h := intervalIntegral.integral_mono (by norm_num : (0 : ℝ) ≤ 1)
      (hf.sub hg) (intervalIntegrable_const : IntervalIntegrable
        (fun _ : ℝ => Real.log 2 / (2 * (n : ℝ))) volume 0 1)
      (fun t => (amoFiniteFrobeniusLog_sub_operator_bounds α lam z n hn t).2)
    simpa using h

/-- The same scalar phase function as a continuous complex-valued circle map. -/
def amoFiniteFrobeniusCircle (α lam : ℝ) (z : ℂ) (n : ℕ) :
    C(AddCircle (1 : ℝ), ℂ) where
  toFun x := ((1 / (2 * (n : ℝ)) * Real.log
    ‖(amoTransferFrobeniusPolynomial α lam z n).eval (_root_.fourier 1 x)‖ : ℝ) : ℂ)
  continuous_toFun := Complex.continuous_ofReal.comp
    (continuous_const.mul (((amoTransferFrobeniusPolynomial α lam z n).continuous.comp
      (_root_.fourier 1).continuous).norm.log (fun x => norm_ne_zero_iff.mpr
        (amoTransferFrobeniusPolynomial_eval_ne_zero_of_norm_eq_one α lam z n _
          (show ‖_root_.fourier 1 x‖ = 1 from Circle.norm_coe _)))))

theorem amo_fourier_coe_eq_logFourierChar (k : ℤ) (t : ℝ) :
    _root_.fourier k (t : AddCircle (1 : ℝ)) = logFourierChar k t := by
  rw [_root_.fourier_coe_apply]
  unfold logFourierChar
  congr 1
  push_cast
  ring

@[simp] theorem amoFiniteFrobeniusCircle_coe
    (α lam : ℝ) (z : ℂ) (n : ℕ) (t : ℝ) :
    amoFiniteFrobeniusCircle α lam z n (t : AddCircle (1 : ℝ)) =
      (amoFiniteFrobeniusLog α lam z n t : ℂ) := by
  change ((1 / (2 * (n : ℝ)) * Real.log
    ‖(amoTransferFrobeniusPolynomial α lam z n).eval
      (_root_.fourier 1 (t : AddCircle (1 : ℝ)))‖ : ℝ) : ℂ) = _
  rw [amo_fourier_coe_eq_logFourierChar, amoFiniteFrobeniusLog_eq_polynomial]

theorem fourierCoeff_amoFiniteFrobeniusCircle
    (α lam : ℝ) (z : ℂ) (n : ℕ) (k : ℤ) :
    _root_.fourierCoeff (amoFiniteFrobeniusCircle α lam z n) k =
      logFourierCoeff (amoFiniteFrobeniusLog α lam z n) k := by
  have h := _root_.fourierCoeff_eq_intervalIntegral
    (amoFiniteFrobeniusCircle α lam z n) k (0 : ℝ)
  simpa only [zero_add, one_div_one, one_smul, amo_fourier_coe_eq_logFourierChar,
    amoFiniteFrobeniusCircle_coe, smul_eq_mul, mul_comm, logFourierCoeff] using h

theorem norm_fourierCoeff_amoFiniteFrobeniusCircle
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) {k : ℤ} (hk : k ≠ 0) :
    ‖_root_.fourierCoeff (amoFiniteFrobeniusCircle α lam z n) k‖ ≤
      1 / |(k : ℝ)| := by
  rw [fourierCoeff_amoFiniteFrobeniusCircle]
  exact norm_logFourierCoeff_amoFiniteFrobeniusLog α lam z n hn hk

theorem norm_amoFiniteFrobeniusCircle_shift_sub_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (x : AddCircle (1 : ℝ)) :
    ‖amoFiniteFrobeniusCircle α lam z n (x + (α : AddCircle (1 : ℝ))) -
      amoFiniteFrobeniusCircle α lam z n x‖ ≤
        (2 * Real.log (amoTransferBound lam z) + Real.log 2) / (n : ℝ) := by
  induction x using QuotientAddGroup.induction_on with
  | H t =>
      change ‖amoFiniteFrobeniusCircle α lam z n ((t + α : ℝ) : AddCircle (1 : ℝ)) -
        amoFiniteFrobeniusCircle α lam z n (t : AddCircle (1 : ℝ))‖ ≤ _
      rw [amoFiniteFrobeniusCircle_coe, amoFiniteFrobeniusCircle_coe,
        ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
      exact amoFiniteFrobeniusLog_shift_abs_sub_le α lam z n hn t

end CriticalDTM

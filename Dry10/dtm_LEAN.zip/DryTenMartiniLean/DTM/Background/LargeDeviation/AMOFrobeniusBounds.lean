import DTM.Background.LargeDeviation.AMOTransferPolynomial
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-!
# Frobenius versus Euclidean operator norm for the actual AMO transfer

The lower estimate is rowwise Cauchy--Schwarz. The upper estimate sums the
squared norms of the two actual columns. Thus no change to an entrywise
matrix norm, spectral theorem, or additional spectral input is involved.
The logarithmic gap is at most `log 2 / (2*n)` at every positive scale.
-/

noncomputable section

namespace CriticalDTM

open Matrix

private theorem amoTransfer_apply_norm_sq_le (M : AMOTransferMatrix)
    (x : EuclideanSpace ℂ (Fin 2)) :
    ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x‖ ^ 2 ≤
      amoTransferFrobeniusSq M * ‖x‖ ^ 2 := by
  rw [PiLp.norm_sq_eq_of_L2, PiLp.norm_sq_eq_of_L2]
  change (∑ i : Fin 2, ‖∑ j : Fin 2, M i j * x j‖ ^ 2) ≤ _
  calc
    _ ≤ ∑ i : Fin 2, (∑ j : Fin 2, ‖M i j‖ * ‖x j‖) ^ 2 := by
      apply Finset.sum_le_sum
      intro i _
      have h := norm_sum_le (Finset.univ : Finset (Fin 2)) (fun j => M i j * x j)
      simp only [norm_mul] at h
      exact pow_le_pow_left₀ (norm_nonneg _) h 2
    _ ≤ ∑ i : Fin 2, (∑ j : Fin 2, ‖M i j‖ ^ 2) * (∑ j : Fin 2, ‖x j‖ ^ 2) := by
      exact Finset.sum_le_sum fun i _ =>
        Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin 2))
          (fun j => ‖M i j‖) (fun j => ‖x j‖)
    _ = _ := by simp only [amoTransferFrobeniusSq, Finset.sum_mul]

/-- The square of the genuine Euclidean operator norm is bounded by the
sum of the squared norms of all four entries. -/
theorem amoTransferNorm_sq_le_frobeniusSq (M : AMOTransferMatrix) :
    amoTransferNorm M ^ 2 ≤ amoTransferFrobeniusSq M := by
  have hbound : amoTransferNorm M ≤ Real.sqrt (amoTransferFrobeniusSq M) := by
    unfold amoTransferNorm
    apply ContinuousLinearMap.opNorm_le_bound _ (Real.sqrt_nonneg _)
    intro x
    apply (sq_le_sq₀ (norm_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) (norm_nonneg _))).mp
    rw [mul_pow, Real.sq_sqrt (amoTransferFrobeniusSq_nonneg M)]
    exact amoTransfer_apply_norm_sq_le M x
  have hsq := pow_le_pow_left₀ (amoTransferNorm_nonneg M) hbound 2
  rwa [Real.sq_sqrt (amoTransferFrobeniusSq_nonneg M)] at hsq

/-- Each actual column has Euclidean norm at most the operator norm. -/
theorem amoTransfer_column_norm_sq_le (M : AMOTransferMatrix) (j : Fin 2) :
    (∑ i : Fin 2, ‖M i j‖ ^ 2) ≤ amoTransferNorm M ^ 2 := by
  let T := Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M
  let v : EuclideanSpace ℂ (Fin 2) := EuclideanSpace.single j 1
  have hentry (i : Fin 2) : (T v) i = M i j := by
    change (M *ᵥ Pi.single j 1) i = M i j
    rw [Matrix.mulVec_single_one]
    rfl
  have hnorm : ‖T v‖ ≤ amoTransferNorm M := by
    simpa [T, v, amoTransferNorm] using T.le_opNorm v
  have hsq := pow_le_pow_left₀ (norm_nonneg (T v)) hnorm 2
  rw [PiLp.norm_sq_eq_of_L2] at hsq
  simpa only [hentry] using hsq

/-- Summing the two column bounds gives the dimension-two upper constant. -/
theorem amoTransferFrobeniusSq_le_two_mul_norm_sq (M : AMOTransferMatrix) :
    amoTransferFrobeniusSq M ≤ 2 * amoTransferNorm M ^ 2 := by
  unfold amoTransferFrobeniusSq
  rw [Finset.sum_comm]
  calc
    _ ≤ ∑ _j : Fin 2, amoTransferNorm M ^ 2 :=
      Finset.sum_le_sum fun j _ => amoTransfer_column_norm_sq_le M j
    _ = _ := by simp [Fin.sum_univ_two, two_mul]

/-- The logarithmic comparison only requires a positive operator norm. -/
theorem amoTransfer_log_frobenius_gap_of_pos (M : AMOTransferMatrix)
    (hM : 0 < amoTransferNorm M) :
    0 ≤ Real.log (amoTransferFrobeniusSq M) / 2 - Real.log (amoTransferNorm M) ∧
      Real.log (amoTransferFrobeniusSq M) / 2 - Real.log (amoTransferNorm M) ≤
        Real.log 2 / 2 := by
  have hs : 0 < amoTransferNorm M ^ 2 := sq_pos_of_pos hM
  have hf : 0 < amoTransferFrobeniusSq M := hs.trans_le (amoTransferNorm_sq_le_frobeniusSq M)
  have hlo := Real.log_le_log hs (amoTransferNorm_sq_le_frobeniusSq M)
  have hhi := Real.log_le_log hf (amoTransferFrobeniusSq_le_two_mul_norm_sq M)
  rw [Real.log_pow] at hlo
  rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) hs.ne', Real.log_pow] at hhi
  norm_num only [Nat.cast_ofNat] at hlo hhi
  constructor <;> linarith

/-- Determinant-one transfers satisfy the nonzero condition internally. -/
theorem amoTransfer_log_frobenius_gap_of_det_one (M : AMOTransferMatrix) (hM : M.det = 1) :
    0 ≤ Real.log (amoTransferFrobeniusSq M) / 2 - Real.log (amoTransferNorm M) ∧
      Real.log (amoTransferFrobeniusSq M) / 2 - Real.log (amoTransferNorm M) ≤
        Real.log 2 / 2 :=
  amoTransfer_log_frobenius_gap_of_pos M (zero_lt_one.trans_le (one_le_amoTransferNorm_of_det_one M hM))

/-- Uniform finite-scale normalization, with no assumption about the energy or phase. -/
theorem amoTransfer_normalized_log_frobenius_gap (M : AMOTransferMatrix)
    (hM : M.det = 1) (n : ℕ) (hn : 0 < n) :
    0 ≤ Real.log (amoTransferFrobeniusSq M) / (2 * (n : ℝ)) -
        Real.log (amoTransferNorm M) / (n : ℝ) ∧
      Real.log (amoTransferFrobeniusSq M) / (2 * (n : ℝ)) -
        Real.log (amoTransferNorm M) / (n : ℝ) ≤ Real.log 2 / (2 * (n : ℝ)) := by
  have hnR : 0 < (n : ℝ) := by exact_mod_cast hn
  obtain ⟨hlo, hhi⟩ := amoTransfer_log_frobenius_gap_of_det_one M hM
  have heq : Real.log (amoTransferFrobeniusSq M) / (2 * (n : ℝ)) -
      Real.log (amoTransferNorm M) / (n : ℝ) =
      (Real.log (amoTransferFrobeniusSq M) / 2 - Real.log (amoTransferNorm M)) / (n : ℝ) := by
    ring
  rw [heq]
  constructor
  · exact div_nonneg hlo hnR.le
  · simpa only [div_div] using div_le_div_of_nonneg_right hhi hnR.le

/-- The comparison applied to the original ordered AMO transfer product. -/
theorem amoTransferProduct_normalized_log_frobenius_gap
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) (hn : 0 < n) :
    0 ≤ Real.log (amoTransferFrobeniusSq (amoTransferProduct α lam z θ n)) / (2 * (n : ℝ)) -
        Real.log (amoTransferNorm (amoTransferProduct α lam z θ n)) / (n : ℝ) ∧
      Real.log (amoTransferFrobeniusSq (amoTransferProduct α lam z θ n)) / (2 * (n : ℝ)) -
        Real.log (amoTransferNorm (amoTransferProduct α lam z θ n)) / (n : ℝ) ≤
          Real.log 2 / (2 * (n : ℝ)) :=
  amoTransfer_normalized_log_frobenius_gap _ (amoTransferProduct_det α lam z θ n) n hn

end CriticalDTM

import DTM.Background.LargeDeviation.DeviationParameters
import DTM.Background.LargeDeviation.FourierDeviation
import DTM.Background.LargeDeviation.RotationKernelBounds
import DTM.Background.LargeDeviation.AMODeviationBridge

/-!
# Exponential finite-scale large deviations for the actual AMO

The arithmetic kernel estimate is combined with finite Fourier smoothing,
Parseval/Chebyshev, and the proved AMO polynomial/shift bounds. The operator
version uses the actual determinant-one Euclidean transfer logarithm and the
same normalized phase measure as the averaged avalanche theorem.

No large-deviation estimate, spectral property, or limiting positive exponent
is assumed. Constants may depend on a fixed tolerance and a uniform one-step
bound; no quantitative modulus in the tolerance is required.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Topology

local instance : Fact (0 < (1 : ℝ)) := ⟨by norm_num⟩

/-- Actual Frobenius logarithms have exponential deviation tails after a
rationally controlled rotation, with all Fourier/arithmetic inputs discharged. -/
theorem amoFiniteFrobeniusCircle_largeDeviation {B kappa : ℝ}
    (hB : 0 < B) (hkappa : 0 < kappa) (hkappa1 : kappa ≤ 1) :
    ∃ C c : ℝ, 0 < C ∧ 0 < c ∧ ∃ Q : ℕ, 8 ≤ Q ∧
      ∀ (α lam : ℝ) (z : ℂ) (a : ℤ) (q n : ℕ), Q ≤ q →
        IsCoprime a (q : ℤ) →
        |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2 →
        2 * Real.log (amoTransferBound lam z) + Real.log 2 ≤ B →
        C * (q : ℝ) ≤ n →
        AddCircle.haarAddCircle.real
          {x : AddCircle (1 : ℝ) | kappa <
            ‖amoFiniteFrobeniusCircle α lam z n x -
              fourierCoeff (amoFiniteFrobeniusCircle α lam z n) 0‖} ≤
                Real.exp (-c * q) := by
  obtain ⟨C, c, hC, hc, Q, hQ, hcut⟩ := exists_deviation_cutoff_parameters hB hkappa hkappa1
  refine ⟨C, c, hC, hc, Q, hQ, ?_⟩
  intro α lam z a q n hq hcop happrox hbound hn
  have hq8 : 8 ≤ q := hQ.trans hq
  have hqR : (0 : ℝ) < q := by exact_mod_cast (show 0 < q by omega)
  have hnR : (0 : ℝ) < n := (mul_pos hC hqR).trans_le hn
  have hnNat : 0 < n := by exact_mod_cast hnR
  obtain ⟨R, K, hRq, hK, hlow, hsmall, htail⟩ := hcut q hq
  have hR : 0 < R := (show 0 < q by omega).trans_le hRq
  have hshift : ∀ x : AddCircle (1 : ℝ),
      ‖amoFiniteFrobeniusCircle α lam z n (x + (α : AddCircle (1 : ℝ))) -
        amoFiniteFrobeniusCircle α lam z n x‖ ≤ B / n := by
    intro x
    exact (norm_amoFiniteFrobeniusCircle_shift_sub_le α lam z n hnNat x).trans
      (div_le_div_of_nonneg_right hbound hnR.le)
  have hsmooth : (R : ℝ) * (B / (n : ℝ)) ≤ kappa / 4 := by
    simpa only [mul_div_assoc] using hsmall n hn
  have hlow' : (∑ k ∈ (Finset.Icc (-(K : ℤ)) (K : ℤ)).erase 0,
      (1 / |(k : ℝ)|) * fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k) ≤
        kappa / 4 := by
    exact (rationalApprox_sum_weighted_multiplier hq8 hcop happrox R hRq K hK).trans hlow
  exact (fourier_deviation_measure_le (amoFiniteFrobeniusCircle α lam z n) R hR
    (α : AddCircle (1 : ℝ)) K (B / (n : ℝ)) kappa hkappa
    (fun k hk => norm_fourierCoeff_amoFiniteFrobeniusCircle α lam z n hnNat hk)
    hshift hsmooth hlow').trans htail

end CriticalDTM

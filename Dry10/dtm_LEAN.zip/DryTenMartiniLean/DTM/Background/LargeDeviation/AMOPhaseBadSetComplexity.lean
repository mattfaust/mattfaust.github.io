import DTM.Background.LargeDeviation.PhaseBadSetGeometry
import DTM.Background.LargeDeviation.AMOFourierEstimates

/-!
# Thickening the actual finite AMO Frobenius bad set

The scalar function is exactly the continuous circle function used in the
AMO Fourier estimates. Its polynomial representation has degree at most
`4*n` and no zeros on the unit circle. Rescaling the center and threshold by
`2*n` therefore gives a Haar thickening cost at most `32*n*δ`.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory AddCircle Set
open scoped ENNReal

/-- Deviations of the actual normalized finite transfer Frobenius logarithm. -/
def amoFiniteFrobeniusBadSet (α lam : ℝ) (z : ℂ) (n : ℕ) (c κ : ℝ) :
    Set (AddCircle (1 : ℝ)) :=
  phaseBadSet (fun x => (amoFiniteFrobeniusCircle α lam z n x).re) c κ

/-- The circle set has exactly the original real-phase deviation condition. -/
@[simp] theorem mem_amoFiniteFrobeniusBadSet_coe
    (α lam : ℝ) (z : ℂ) (n : ℕ) (c κ t : ℝ) :
    (t : AddCircle (1 : ℝ)) ∈ amoFiniteFrobeniusBadSet α lam z n c κ ↔
      κ < |amoFiniteFrobeniusLog α lam z n t - c| := by
  simp [amoFiniteFrobeniusBadSet, phaseBadSet, amoFiniteFrobeniusCircle_coe]

theorem isOpen_amoFiniteFrobeniusBadSet
    (α lam : ℝ) (z : ℂ) (n : ℕ) (c κ : ℝ) :
    IsOpen (amoFiniteFrobeniusBadSet α lam z n c κ) :=
  isOpen_phaseBadSet (Complex.continuous_re.comp
    (amoFiniteFrobeniusCircle α lam z n).continuous) c κ

theorem measurableSet_amoFiniteFrobeniusBadHull
    (α lam : ℝ) (z : ℂ) (n : ℕ) (c κ δ : ℝ) :
    MeasurableSet (phaseBadHull (amoFiniteFrobeniusBadSet α lam z n c κ) δ) :=
  (isOpen_phaseBadHull (isOpen_amoFiniteFrobeniusBadSet α lam z n c κ) δ).measurableSet

/-- The normalization changes the center and threshold, not the bad phases. -/
theorem amoFiniteFrobeniusBadSet_eq_polynomial
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (c κ : ℝ) :
    amoFiniteFrobeniusBadSet α lam z n c κ =
      phaseBadSet (phasePolynomialLog (amoTransferFrobeniusPolynomial α lam z n))
        (2 * (n : ℝ) * c) (2 * (n : ℝ) * κ) := by
  have hn' : 0 < (n : ℝ) := by exact_mod_cast hn
  have hd : 0 < 2 * (n : ℝ) := by positivity
  ext x
  change κ < |1 / (2 * (n : ℝ)) *
      phasePolynomialLog (amoTransferFrobeniusPolynomial α lam z n) x - c| ↔ _
  have habs (u : ℝ) : |u - 2 * (n : ℝ) * c| =
      (2 * (n : ℝ)) * |1 / (2 * (n : ℝ)) * u - c| := by
    calc
      _ = |(2 * (n : ℝ)) * (1 / (2 * (n : ℝ)) * u - c)| := by
        congr 1
        field_simp
      _ = _ := by rw [abs_mul, abs_of_pos hd]
  change κ < |_ - c| ↔ 2 * (n : ℝ) * κ <
    |phasePolynomialLog (amoTransferFrobeniusPolynomial α lam z n) x - 2 * (n : ℝ) * c|
  rw [habs, mul_lt_mul_left hd]

/-- The actual finite AMO phase bad set has a degree-controlled thickening,
with no arithmetic, spectral, or large-deviation hypothesis. -/
theorem measure_amoFiniteFrobeniusBadHull_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (c : ℝ) {κ δ : ℝ}
    (hκ : 0 ≤ κ) (hδ : 0 ≤ δ) :
    haarAddCircle (phaseBadHull (amoFiniteFrobeniusBadSet α lam z n c κ) δ) ≤
      haarAddCircle (amoFiniteFrobeniusBadSet α lam z n c κ) +
        ENNReal.ofReal (32 * (n : ℝ) * δ) := by
  rw [amoFiniteFrobeniusBadSet_eq_polynomial α lam z n hn c κ]
  calc
    _ ≤ haarAddCircle (phaseBadSet
          (phasePolynomialLog (amoTransferFrobeniusPolynomial α lam z n))
          (2 * (n : ℝ) * c) (2 * (n : ℝ) * κ)) +
        ENNReal.ofReal (8 * ((amoTransferFrobeniusPolynomial α lam z n).natDegree : ℝ) * δ) :=
      measure_phaseBadHull_polynomial_le _
        (amoTransferFrobeniusPolynomial_eval_ne_zero_of_norm_eq_one α lam z n)
        _ (by positivity) hδ
    _ ≤ _ := by
      apply add_le_add_left
      apply ENNReal.ofReal_le_ofReal
      have hd : ((amoTransferFrobeniusPolynomial α lam z n).natDegree : ℝ) ≤ 4 * (n : ℝ) := by
        exact_mod_cast amoTransferFrobeniusPolynomial_natDegree_le α lam z n
      nlinarith

/-- Ordinary real Haar probabilities for the same actual finite AMO bad set. -/
theorem measureReal_amoFiniteFrobeniusBadHull_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) (c : ℝ) {κ δ : ℝ}
    (hκ : 0 ≤ κ) (hδ : 0 ≤ δ) :
    (haarAddCircle (phaseBadHull (amoFiniteFrobeniusBadSet α lam z n c κ) δ)).toReal ≤
      (haarAddCircle (amoFiniteFrobeniusBadSet α lam z n c κ)).toReal +
        32 * (n : ℝ) * δ := by
  have h := ENNReal.toReal_mono
    (show haarAddCircle (amoFiniteFrobeniusBadSet α lam z n c κ) +
        ENNReal.ofReal (32 * (n : ℝ) * δ) ≠ ∞ from
      ENNReal.add_ne_top.mpr ⟨measure_ne_top _ _, ENNReal.ofReal_ne_top⟩)
    (measure_amoFiniteFrobeniusBadHull_le α lam z n hn c hκ hδ)
  rw [ENNReal.toReal_add (measure_ne_top _ _) ENNReal.ofReal_ne_top,
    ENNReal.toReal_ofReal (by positivity)] at h
  exact h

/-- In particular, the center may be the genuine finite-scale Lyapunov mean. -/
theorem measureReal_amoFiniteLyapunovBadHull_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (hn : 0 < n) {κ δ : ℝ}
    (hκ : 0 ≤ κ) (hδ : 0 ≤ δ) :
    (haarAddCircle (phaseBadHull (amoFiniteFrobeniusBadSet α lam z n
      (amoFiniteLyapunov α lam z n) κ) δ)).toReal ≤
      (haarAddCircle (amoFiniteFrobeniusBadSet α lam z n
        (amoFiniteLyapunov α lam z n) κ)).toReal + 32 * (n : ℝ) * δ :=
  measureReal_amoFiniteFrobeniusBadHull_le α lam z n hn _ hκ hδ

end CriticalDTM

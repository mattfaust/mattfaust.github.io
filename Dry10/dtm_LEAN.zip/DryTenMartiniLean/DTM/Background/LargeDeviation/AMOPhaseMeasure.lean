import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

/-!
# The normalized real-phase / circle-measure bridge

The quotient map sends Lebesgue measure on `(0,1]` to the normalized Haar
probability on `AddCircle 1`. This fixes the mass convention used when
circle bad-set geometry is fed into the actual averaged AMO avalanche
principle.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set

/-- Unit-period real phase projects to normalized Haar probability. -/
theorem unitCircle_measurePreserving_mk :
    MeasurePreserving (fun t : ℝ => (t : AddCircle (1 : ℝ)))
      (volume.restrict (Ioc (0 : ℝ) 1)) AddCircle.haarAddCircle := by
  have hv : (volume : Measure (AddCircle (1 : ℝ))) = AddCircle.haarAddCircle := by
    simpa using (AddCircle.volume_eq_smul_haarAddCircle (T := (1 : ℝ)))
  simpa only [zero_add, hv] using (AddCircle.measurePreserving_mk (T := (1 : ℝ)) 0)

/-- The ordinary real probabilities agree in the two phase conventions. -/
theorem unitCircle_measureReal_preimage {s : Set (AddCircle (1 : ℝ))}
    (hs : MeasurableSet s) :
    (volume.restrict (Ioc (0 : ℝ) 1)).real
      ((fun t : ℝ => (t : AddCircle (1 : ℝ))) ⁻¹' s) = AddCircle.haarAddCircle.real s :=
  unitCircle_measurePreserving_mk.measureReal_preimage hs.nullMeasurableSet

end CriticalDTM

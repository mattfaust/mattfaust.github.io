import DTM.Background.Transfer.AMOTransfer
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Analysis.SpecialFunctions.Complex.Arg
import Mathlib.Tactic.FieldSimp

/-!
# Polynomial phase representation of the actual AMO transfer

Multiplication by the phase variable clears one negative power at each site.
The resulting matrix polynomial evaluates to the actual ordered transfer,
with entry degrees at most twice the number of sites. A fixed-degree
conjugate reflection then represents the transfer's Frobenius square by one
ordinary polynomial. No spectral or large-deviation assertion is used.
-/

noncomputable section

namespace CriticalDTM

open Matrix Polynomial

private theorem amo_phase_cos_identity (θ δ : ℝ) :
    (((2 * Real.cos (θ + δ) : ℝ) : ℂ) * Complex.exp ((θ : ℂ) * Complex.I)) =
      Complex.exp ((δ : ℂ) * Complex.I) * Complex.exp ((θ : ℂ) * Complex.I) ^ 2 +
        Complex.exp (-((δ : ℂ) * Complex.I)) := by
  simp only [Complex.ofReal_mul, Complex.ofReal_ofNat, Complex.ofReal_cos,
    Complex.cos, Complex.ofReal_add, add_mul, neg_add, neg_mul, Complex.exp_add,
    Complex.exp_neg]
  field_simp
  ring

/-- One actual transfer step after clearing the negative phase power. -/
def amoTransferStepPolynomial (α lam : ℝ) (z : ℂ) (j : ℕ) :
    Matrix (Fin 2) (Fin 2) (Polynomial ℂ) :=
  !![C z * X - C (lam : ℂ) *
      (C (Complex.exp (((2 * Real.pi * α * (j : ℝ) : ℝ) : ℂ) * Complex.I)) * X ^ 2 +
        C (Complex.exp (-(((2 * Real.pi * α * (j : ℝ) : ℝ) : ℂ) * Complex.I)))), -X;
    X, 0]

/-- The polynomial transfer has exactly the physical left-multiplication order. -/
def amoTransferPolynomial (α lam : ℝ) (z : ℂ) :
    ℕ → Matrix (Fin 2) (Fin 2) (Polynomial ℂ)
  | 0 => 1
  | n + 1 => amoTransferStepPolynomial α lam z n * amoTransferPolynomial α lam z n

@[simp] theorem amoTransferPolynomial_zero (α lam : ℝ) (z : ℂ) :
    amoTransferPolynomial α lam z 0 = 1 := rfl

@[simp] theorem amoTransferPolynomial_succ (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoTransferPolynomial α lam z (n + 1) =
      amoTransferStepPolynomial α lam z n * amoTransferPolynomial α lam z n := rfl

/-- Evaluation of a cleared step is the phase variable times the actual step. -/
theorem amoTransferStepPolynomial_eval (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    (amoTransferStepPolynomial α lam z n).map
      (Polynomial.eval (Complex.exp ((θ : ℂ) * Complex.I))) =
        Complex.exp ((θ : ℂ) * Complex.I) •
          amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) := by
  ext i j
  fin_cases i <;> fin_cases j
  · change (C z * X - C (lam : ℂ) * (_ + _)).eval
        (Complex.exp ((θ : ℂ) * Complex.I)) =
      Complex.exp ((θ : ℂ) * Complex.I) *
        (z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (n : ℝ)) : ℝ) : ℂ))
    simp only [Polynomial.eval_sub, Polynomial.eval_mul, Polynomial.eval_C,
      Polynomial.eval_add, Polynomial.eval_pow, Polynomial.eval_X]
    have hcos := amo_phase_cos_identity θ (2 * Real.pi * α * (n : ℝ))
    simp only [Complex.ofReal_mul, Complex.ofReal_ofNat] at hcos ⊢
    linear_combination (lam : ℂ) * hcos
  · simp [amoTransferStepPolynomial, amoTransfer, Matrix.smul_apply]
  · simp [amoTransferStepPolynomial, amoTransfer, Matrix.smul_apply]
  · simp [amoTransferStepPolynomial, amoTransfer, Matrix.smul_apply]

/-- The actual product is recovered at every real radian phase. -/
theorem amoTransferPolynomial_eval_matrix (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    (amoTransferPolynomial α lam z n).map
      (Polynomial.eval (Complex.exp ((θ : ℂ) * Complex.I))) =
        Complex.exp ((θ : ℂ) * Complex.I) ^ n • amoTransferProduct α lam z θ n := by
  induction n with
  | zero =>
      simp only [amoTransferPolynomial_zero, amoTransferProduct_zero, pow_zero, one_smul]
      exact Matrix.map_one _ (by simp) (by simp)
  | succ n ih =>
      rw [amoTransferPolynomial_succ]
      change (amoTransferStepPolynomial α lam z n * amoTransferPolynomial α lam z n).map
        (Polynomial.evalRingHom (Complex.exp ((θ : ℂ) * Complex.I))) = _
      rw [Matrix.map_mul]
      change (amoTransferStepPolynomial α lam z n).map (Polynomial.eval _) *
        (amoTransferPolynomial α lam z n).map (Polynomial.eval _) = _
      rw [amoTransferStepPolynomial_eval, ih, amoTransferProduct_succ,
        Matrix.smul_mul, Matrix.mul_smul, smul_smul, pow_succ']

/-- Each cleared polynomial entry represents its actual transfer entry. -/
theorem amoTransferPolynomial_eval (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) (i j : Fin 2) :
    (amoTransferPolynomial α lam z n i j).eval (Complex.exp ((θ : ℂ) * Complex.I)) =
      Complex.exp ((θ : ℂ) * Complex.I) ^ n * amoTransferProduct α lam z θ n i j := by
  exact congrArg (fun M : AMOTransferMatrix => M i j)
    (amoTransferPolynomial_eval_matrix α lam z θ n)

/-- A single cleared receiving row has degree at most two. -/
theorem amoTransferStepPolynomial_natDegree_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (i j : Fin 2) :
    (amoTransferStepPolynomial α lam z n i j).natDegree ≤ 2 := by
  fin_cases i <;> fin_cases j
  · change (C z * X - C (lam : ℂ) * (_ + _)).natDegree ≤ 2
    apply (Polynomial.natDegree_sub_le _ _).trans
    apply max_le
    · exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
    · apply (Polynomial.natDegree_C_mul_le _ _).trans
      apply Polynomial.natDegree_add_le_of_degree_le
      · exact Polynomial.natDegree_C_mul_X_pow_le _ _
      · simp
  · simp [amoTransferStepPolynomial]
  · simp [amoTransferStepPolynomial]
  · simp [amoTransferStepPolynomial]

/-- Every actual `n`-site entry has Laurent degree at most `n`. -/
theorem amoTransferPolynomial_natDegree_le
    (α lam : ℝ) (z : ℂ) (n : ℕ) (i j : Fin 2) :
    (amoTransferPolynomial α lam z n i j).natDegree ≤ 2 * n := by
  induction n generalizing i j with
  | zero =>
      simp only [amoTransferPolynomial_zero, Matrix.one_apply]
      split_ifs <;> simp
  | succ n ih =>
      rw [amoTransferPolynomial_succ, Matrix.mul_apply, Fin.sum_univ_two]
      apply Polynomial.natDegree_add_le_of_degree_le
      · exact (Polynomial.natDegree_mul_le_of_le
          (amoTransferStepPolynomial_natDegree_le α lam z n i 0) (ih 0 j)).trans (by omega)
      · exact (Polynomial.natDegree_mul_le_of_le
          (amoTransferStepPolynomial_natDegree_le α lam z n i 1) (ih 1 j)).trans (by omega)

private theorem amo_reflect_natDegree_le (p : Polynomial ℂ) (D : ℕ)
    (hp : p.natDegree ≤ D) : (Polynomial.reflect D p).natDegree ≤ D := by
  apply Polynomial.natDegree_le_iff_coeff_eq_zero.mpr
  intro j hj
  rw [Polynomial.coeff_reflect, Polynomial.revAt_eq_self_of_lt hj]
  exact Polynomial.coeff_eq_zero_of_natDegree_lt (hp.trans_lt hj)

/-- On the unit circle, fixed-degree conjugate reflection is the conjugate
value multiplied by precisely the prescribed phase power. -/
private theorem amo_reflect_eval (p : Polynomial ℂ) {D : ℕ} (hp : p.natDegree ≤ D)
    {w : ℂ} (hw : ‖w‖ = 1) :
    (Polynomial.reflect D (p.map (starRingEnd ℂ))).eval w = w ^ D * star (p.eval w) := by
  have hw0 : w ≠ 0 := by intro h; simp [h] at hw
  have hconj : star w = w⁻¹ := by
    rw [Complex.inv_def, Complex.normSq_eq_norm_sq, hw]
    simp
  have heval : (p.map (starRingEnd ℂ)).eval (w⁻¹) = star (p.eval w) := by
    rw [← hconj, Polynomial.eval_map]
    exact Polynomial.eval₂_hom (starRingEnd ℂ) w
  letI : Invertible (w⁻¹) := invertibleOfNonzero (inv_ne_zero hw0)
  have hreflect := Polynomial.eval₂_reflect_mul_pow (RingHom.id ℂ) (w⁻¹) D
    (p.map (starRingEnd ℂ)) (Polynomial.natDegree_map_le.trans hp)
  simp only [invOf_eq_inv, inv_inv] at hreflect
  change (Polynomial.reflect D (p.map (starRingEnd ℂ))).eval w * (w⁻¹) ^ D =
    (p.map (starRingEnd ℂ)).eval (w⁻¹) at hreflect
  rw [heval] at hreflect
  apply mul_right_cancel₀ (pow_ne_zero D (inv_ne_zero hw0))
  calc
    _ = star (p.eval w) := hreflect
    _ = star (p.eval w) * (w * w⁻¹) ^ D := by
      rw [mul_inv_cancel₀ hw0, one_pow, mul_one]
    _ = _ := by rw [mul_pow]; ring

/-- The ordinary Frobenius square, with its four actual matrix entries. -/
def amoTransferFrobeniusSq (M : AMOTransferMatrix) : ℝ :=
  ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ ^ 2

theorem amoTransferFrobeniusSq_nonneg (M : AMOTransferMatrix) :
    0 ≤ amoTransferFrobeniusSq M := by
  exact Finset.sum_nonneg fun i _ => Finset.sum_nonneg fun j _ => sq_nonneg _

theorem amoTransferFrobeniusSq_pos_of_det_one (M : AMOTransferMatrix) (hM : M.det = 1) :
    0 < amoTransferFrobeniusSq M := by
  have hM0 : M ≠ 0 := by intro h; simp [h] at hM
  obtain ⟨i, hi⟩ := Function.ne_iff.mp hM0
  obtain ⟨j, hij⟩ := Function.ne_iff.mp hi
  apply Finset.sum_pos' (fun i _ => Finset.sum_nonneg fun j _ => sq_nonneg _)
  refine ⟨i, Finset.mem_univ _, ?_⟩
  exact Finset.sum_pos' (fun j _ => sq_nonneg _)
    ⟨j, Finset.mem_univ _, sq_pos_of_pos (norm_pos_iff.mpr hij)⟩

/-- One ordinary polynomial represents the actual transfer Frobenius square.
The reflection degree is fixed at `2*n`, including when entry degrees drop. -/
def amoTransferFrobeniusPolynomial (α lam : ℝ) (z : ℂ) (n : ℕ) : Polynomial ℂ :=
  ∑ i : Fin 2, ∑ j : Fin 2,
    amoTransferPolynomial α lam z n i j *
      Polynomial.reflect (2 * n)
        ((amoTransferPolynomial α lam z n i j).map (starRingEnd ℂ))

/-- The Laurent Frobenius square has degree at most `2*n` in each direction. -/
theorem amoTransferFrobeniusPolynomial_natDegree_le (α lam : ℝ) (z : ℂ) (n : ℕ) :
    (amoTransferFrobeniusPolynomial α lam z n).natDegree ≤ 4 * n := by
  unfold amoTransferFrobeniusPolynomial
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro i _
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro j _
  have hentry := amoTransferPolynomial_natDegree_le α lam z n i j
  have hreflect := amo_reflect_natDegree_le
    ((amoTransferPolynomial α lam z n i j).map (starRingEnd ℂ)) (2 * n)
    (Polynomial.natDegree_map_le.trans hentry)
  exact (Polynomial.natDegree_mul_le_of_le hentry hreflect).trans (by omega)

/-- Evaluation identifies the polynomial with the actual transfer, including
its exact phase prefactor and the original complex energy. -/
theorem amoTransferFrobeniusPolynomial_eval
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    (amoTransferFrobeniusPolynomial α lam z n).eval (Complex.exp ((θ : ℂ) * Complex.I)) =
      Complex.exp ((θ : ℂ) * Complex.I) ^ (2 * n) *
        (amoTransferFrobeniusSq (amoTransferProduct α lam z θ n) : ℂ) := by
  simp only [amoTransferFrobeniusPolynomial, Polynomial.eval_finset_sum,
    Polynomial.eval_mul, amoTransferFrobeniusSq, Complex.ofReal_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  rw [amo_reflect_eval _ (amoTransferPolynomial_natDegree_le α lam z n i j)
    (Complex.norm_exp_ofReal_mul_I θ), mul_left_comm, Complex.star_def,
    Complex.mul_conj, Complex.normSq_eq_norm_sq, amoTransferPolynomial_eval]
  simp only [norm_mul, norm_pow, Complex.norm_exp_ofReal_mul_I, one_pow, one_mul]

/-- The unit-circle polynomial modulus is exactly the actual Frobenius square. -/
theorem norm_amoTransferFrobeniusPolynomial_eval
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    ‖(amoTransferFrobeniusPolynomial α lam z n).eval
      (Complex.exp ((θ : ℂ) * Complex.I))‖ =
        amoTransferFrobeniusSq (amoTransferProduct α lam z θ n) := by
  rw [amoTransferFrobeniusPolynomial_eval, norm_mul, norm_pow,
    Complex.norm_exp_ofReal_mul_I]
  simp only [one_pow, one_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (amoTransferFrobeniusSq_nonneg _)]

/-- There is no zero on a physical real phase: determinant one forces a
nonzero actual transfer matrix and hence a strictly positive Frobenius square. -/
theorem amoTransferFrobeniusPolynomial_eval_ne_zero
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    (amoTransferFrobeniusPolynomial α lam z n).eval
      (Complex.exp ((θ : ℂ) * Complex.I)) ≠ 0 := by
  apply norm_pos_iff.mp
  rw [norm_amoTransferFrobeniusPolynomial_eval]
  exact amoTransferFrobeniusSq_pos_of_det_one _ (amoTransferProduct_det α lam z θ n)

/-- The representing polynomial has no roots anywhere on the unit circle. -/
theorem amoTransferFrobeniusPolynomial_eval_ne_zero_of_norm_eq_one
    (α lam : ℝ) (z : ℂ) (n : ℕ) (w : ℂ) (hw : ‖w‖ = 1) :
    (amoTransferFrobeniusPolynomial α lam z n).eval w ≠ 0 := by
  obtain ⟨θ, rfl⟩ := (Complex.norm_eq_one_iff w).mp hw
  exact amoTransferFrobeniusPolynomial_eval_ne_zero α lam z θ n

theorem amoTransferFrobeniusPolynomial_ne_zero (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoTransferFrobeniusPolynomial α lam z n ≠ 0 := by
  intro h
  have hphase := amoTransferFrobeniusPolynomial_eval_ne_zero α lam z 0 n
  simp [h] at hphase

end CriticalDTM

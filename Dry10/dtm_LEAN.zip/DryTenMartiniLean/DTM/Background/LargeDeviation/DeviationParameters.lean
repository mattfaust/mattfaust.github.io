import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Real.Archimedean
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-!
# Finite smoothing and exponential Fourier cutoff parameters

Only a fixed deviation tolerance is needed for positive persistence. The
constants may depend on it, so elementary eventual estimates replace any
unnecessary quantitative modulus in the tolerance.
-/

noncomputable section
namespace CriticalDTM

open Filter
open scoped Topology

/-- Explicit finite cutoffs turn the proved smoothing/low-mode/square-tail
bounds into an exponential error. This is scalar parameter selection only. -/
theorem exists_deviation_cutoff_parameters {B kappa : ℝ}
    (hB : 0 < B) (hkappa : 0 < kappa) (hkappa1 : kappa ≤ 1) :
    ∃ C c : ℝ, 0 < C ∧ 0 < c ∧ ∃ Q : ℕ, 8 ≤ Q ∧
      ∀ q : ℕ, Q ≤ q → ∃ R K : ℕ,
        q ≤ R ∧ 1 ≤ K ∧
        4096 * ((q : ℝ) / R + (1 + Real.log ((K : ℝ) + 1)) / q) ≤ kappa / 4 ∧
        (∀ n : ℕ, C * (q : ℝ) ≤ n → (R : ℝ) * B / n ≤ kappa / 4) ∧
        16 / (kappa ^ 2 * ((K : ℝ) + 1)) ≤ Real.exp (-c * q) := by
  let A : ℝ := 65536 / kappa
  let b : ℝ := kappa / 65536
  let c : ℝ := b / 2
  let C : ℝ := 4 * (A + 1) * B / kappa
  have hA : 0 < A := by dsimp [A]; positivity
  have hA1 : 1 ≤ A := by
    apply (le_div_iff₀ hkappa).mpr
    linarith
  have hb : 0 < b := by dsimp [b]; positivity
  have hc : 0 < c := by dsimp [c]; positivity
  have hC : 0 < C := by dsimp [C]; positivity
  have hsmall : ∀ᶠ q : ℕ in atTop,
      (1 + Real.log 2) / (q : ℝ) ≤ kappa / 65536 := by
    exact (tendsto_const_div_atTop_nhds_zero_nat (1 + Real.log 2)).eventually
      (eventually_le_nhds (by positivity : (0 : ℝ) < kappa / 65536))
  have hexplim : Tendsto (fun q : ℕ => Real.exp (c * (q : ℝ))) atTop atTop :=
    Real.tendsto_exp_atTop.comp (tendsto_natCast_atTop_atTop.const_mul_atTop hc)
  have hexp : ∀ᶠ q : ℕ in atTop, 16 / kappa ^ 2 ≤ Real.exp (c * (q : ℝ)) :=
    hexplim.eventually (eventually_ge_atTop _)
  obtain ⟨Q, hQ⟩ := eventually_atTop.mp
    ((eventually_ge_atTop (8 : ℕ)).and (hsmall.and hexp))
  let Q' := max Q 8
  refine ⟨C, c, hC, hc, Q', le_max_right _ _, ?_⟩
  intro q hq
  have hQq : Q ≤ q := (le_max_left _ _).trans hq
  obtain ⟨hq8, hqsmall, hqexp⟩ := hQ q hQq
  have hqpos : 0 < q := by omega
  have hqR : (0 : ℝ) < q := by exact_mod_cast hqpos
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hqpos
  let R : ℕ := ⌈A * (q : ℝ)⌉₊
  let K : ℕ := ⌊Real.exp (b * (q : ℝ))⌋₊
  have hRlower : A * (q : ℝ) ≤ R := Nat.le_ceil _
  have hRupper : (R : ℝ) ≤ (A + 1) * q := by
    have h := (Nat.ceil_lt_add_one (mul_nonneg hA.le hqR.le)).le
    change (⌈A * (q : ℝ)⌉₊ : ℝ) ≤ (A + 1) * q
    calc
      _ ≤ A * q + 1 := h
      _ ≤ (A + 1) * q := by nlinarith
  have hqRnat : q ≤ R := by
    exact_mod_cast (show (q : ℝ) ≤ R from
      (le_mul_of_one_le_left hqR.le hA1).trans hRlower)
  have hRpos : (0 : ℝ) < R := hqR.trans_le (by exact_mod_cast hqRnat)
  have hexp1 : 1 ≤ Real.exp (b * (q : ℝ)) := Real.one_le_exp (by positivity)
  have hK1 : 1 ≤ K := by
    exact (Nat.one_le_floor_iff _).mpr hexp1
  have hKlower : Real.exp (b * (q : ℝ)) ≤ (K : ℝ) + 1 :=
    (Nat.lt_floor_add_one _).le
  have hKupper : (K : ℝ) + 1 ≤ 2 * Real.exp (b * (q : ℝ)) := by
    have h := Nat.floor_le (Real.exp_pos (b * (q : ℝ))).le
    dsimp only [K]
    linarith
  have hlogK : Real.log ((K : ℝ) + 1) ≤ Real.log 2 + b * q := by
    have h := Real.log_le_log (by positivity : (0 : ℝ) < (K : ℝ) + 1) hKupper
    rw [Real.log_mul (by norm_num) (Real.exp_pos _).ne', Real.log_exp] at h
    exact h
  have hqdiv : (q : ℝ) / R ≤ kappa / 65536 := by
    apply (div_le_iff₀ hRpos).mpr
    have hcoef : 0 ≤ kappa / 65536 := by positivity
    have h := mul_le_mul_of_nonneg_left hRlower hcoef
    have heq : (kappa / 65536) * (A * (q : ℝ)) = q := by
      dsimp [A]
      field_simp
      ring
    rw [heq] at h
    exact h
  refine ⟨R, K, hqRnat, hK1, ?_, ?_, ?_⟩
  · have hsecond : (1 + Real.log ((K : ℝ) + 1)) / q ≤
        kappa / 65536 + b := by
      have h := div_le_div_of_nonneg_right (add_le_add_left hlogK 1) hqR.le
      have heq : (1 + (Real.log 2 + b * (q : ℝ))) / q =
          (1 + Real.log 2) / q + b := by field_simp; ring
      rw [heq] at h
      linarith
    dsimp only [b] at hsecond
    linarith
  · intro n hn
    have hnR : (0 : ℝ) < n := (mul_pos hC hqR).trans_le hn
    apply (div_le_iff₀ hnR).mpr
    have h := mul_le_mul_of_nonneg_right hRupper hB.le
    have heq : ((A + 1) * (q : ℝ)) * B = (kappa / 4) * (C * q) := by
      dsimp [C]
      field_simp
      ring
    rw [heq] at h
    exact h.trans (mul_le_mul_of_nonneg_left hn (by positivity))
  · have hden : 0 < kappa ^ 2 * Real.exp (b * (q : ℝ)) := by positivity
    have htail : 16 / (kappa ^ 2 * ((K : ℝ) + 1)) ≤
        (16 / kappa ^ 2) * Real.exp (-b * q) := by
      calc
        _ ≤ 16 / (kappa ^ 2 * Real.exp (b * (q : ℝ))) :=
          div_le_div_of_nonneg_left (by norm_num) hden
            (mul_le_mul_of_nonneg_left hKlower (sq_nonneg _))
        _ = _ := by
          simp only [neg_mul, Real.exp_neg, div_eq_mul_inv, mul_inv_rev]
          ring
    calc
      _ ≤ (16 / kappa ^ 2) * Real.exp (-b * q) := htail
      _ ≤ Real.exp (c * (q : ℝ)) * Real.exp (-b * q) :=
        mul_le_mul_of_nonneg_right hqexp (Real.exp_pos _).le
      _ = Real.exp (-c * q) := by
        rw [← Real.exp_add]
        congr 1
        dsimp [c]
        ring

end CriticalDTM

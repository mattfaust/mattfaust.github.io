import DTM.Background.LargeDeviation.FourierSmoothingTail
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-!
# Finite Fourier smoothing and deviation in normalized Haar measure

For a continuous complex-valued function on the unit circle, inverse-frequency
Fourier decay and a finite low-mode bound imply a deviation estimate about the
actual zero Fourier coefficient. The proof uses the continuous finite Fourier
cut, its proved L² remainder estimate, and Chebyshev's inequality. There is no
pointwise infinite Fourier expansion or large-deviation hypothesis.

The arithmetic bound on the finite low-mode sum is an explicit hypothesis of
this scalar helper; its rotation-arithmetic instantiation is a separate step.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory AddCircle
open scoped ENNReal

/-- A finite Fourier cut differs from its mean by at most the sum of the
moduli of its retained nonzero Fourier coefficients. -/
theorem norm_fourierContinuousCut_sub_mean_le
    (f : C(AddCircle (1 : ℝ), ℂ)) (s : Finset ℤ) (hs : 0 ∈ s)
    (x : AddCircle (1 : ℝ)) :
    ‖fourierContinuousCut f s x - fourierCoeff f 0‖ ≤
      ∑ k ∈ s.erase 0, ‖fourierCoeff f k‖ := by
  classical
  have hcut : fourierContinuousCut f s x =
      ∑ k ∈ s, fourierCoeff f k * fourier k x := by
    simp [fourierContinuousCut, smul_eq_mul]
  have hsum : (∑ k ∈ s.erase 0, fourierCoeff f k * fourier k x) +
      fourierCoeff f 0 = fourierContinuousCut f s x := by
    simpa only [hcut, fourier_zero, mul_one] using
      Finset.sum_erase_add s (fun k : ℤ => fourierCoeff f k * fourier k x) hs
  have hsub : fourierContinuousCut f s x - fourierCoeff f 0 =
      ∑ k ∈ s.erase 0, fourierCoeff f k * fourier k x := by
    rw [← hsum, add_sub_cancel_right]
  rw [hsub]
  calc
    _ ≤ ∑ k ∈ s.erase 0, ‖fourierCoeff f k * fourier k x‖ := norm_sum_le _ _
    _ = _ := by
      apply Finset.sum_congr rfl
      intro k _
      rw [norm_mul, show ‖fourier k x‖ = 1 from Circle.norm_coe _, mul_one]

/-- The low-mode part of the actual orbit average is controlled by a finite
weighted sum of the nonnegative Fejér multipliers. -/
theorem norm_fourierContinuousCut_orbit_sub_mean_le
    (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ) (hR : 0 < R)
    (α : AddCircle (1 : ℝ)) (K : ℕ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ 1 / |(k : ℝ)|)
    (x : AddCircle (1 : ℝ)) :
    ‖fourierContinuousCut (fourierOrbitAverage f R α)
        (Finset.Icc (-(K : ℤ)) (K : ℤ)) x - fourierCoeff f 0‖ ≤
      ∑ k ∈ (Finset.Icc (-(K : ℤ)) (K : ℤ)).erase 0,
        (1 / |(k : ℝ)|) * fourierOrbitMultiplier R α k := by
  rw [← fourierCoeff_fourierOrbitAverage_zero f R hR α]
  apply (norm_fourierContinuousCut_sub_mean_le _ _ (by simp) x).trans
  apply Finset.sum_le_sum
  intro k hk
  rw [fourierCoeff_fourierOrbitAverage, norm_mul, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg (fourierOrbitMultiplier_nonneg R α k), mul_comm]
  exact mul_le_mul_of_nonneg_right (hcoeff k (Finset.mem_erase.mp hk).1)
    (fourierOrbitMultiplier_nonneg R α k)

/-- Finite scalar Fourier deviation bound in the actual normalized Haar measure.
The only arithmetic input is the displayed finite low-mode inequality. The mean
is complex-valued, and no reality assumption on `f` is used. -/
theorem fourier_deviation_measure_le_ofReal
    (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ) (hR : 0 < R)
    (α : AddCircle (1 : ℝ)) (K : ℕ) (ε κ : ℝ) (hκ : 0 < κ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ 1 / |(k : ℝ)|)
    (hshift : ∀ x, ‖f (x + α) - f x‖ ≤ ε)
    (hsmall : (R : ℝ) * ε ≤ κ / 4)
    (hlow : (∑ k ∈ (Finset.Icc (-(K : ℤ)) (K : ℤ)).erase 0,
      (1 / |(k : ℝ)|) * fourierOrbitMultiplier R α k) ≤ κ / 4) :
    haarAddCircle {x : AddCircle (1 : ℝ) | κ < ‖f x - fourierCoeff f 0‖} ≤
      ENNReal.ofReal (16 / (κ ^ 2 * ((K : ℝ) + 1))) := by
  let g := fourierOrbitAverage f R α
  let p := fourierContinuousCut g (Finset.Icc (-(K : ℤ)) (K : ℤ))
  have hclose (x : AddCircle (1 : ℝ)) : ‖f x - g x‖ ≤ κ / 4 := by
    rw [norm_sub_rev]
    exact (norm_fourierOrbitAverage_sub_le f R hR α ε hshift x).trans hsmall
  have hcut (x : AddCircle (1 : ℝ)) : ‖p x - fourierCoeff f 0‖ ≤ κ / 4 :=
    (norm_fourierContinuousCut_orbit_sub_mean_le f R hR α K hcoeff x).trans hlow
  have hlarge (x : AddCircle (1 : ℝ)) (hx : κ < ‖f x - fourierCoeff f 0‖) :
      κ / 2 < ‖g x - p x‖ := by
    have htriangle : ‖f x - fourierCoeff f 0‖ ≤
        ‖f x - g x‖ + (‖g x - p x‖ + ‖p x - fourierCoeff f 0‖) :=
      (norm_sub_le_norm_sub_add_norm_sub _ _ _).trans
        (add_le_add_left (norm_sub_le_norm_sub_add_norm_sub _ _ _) _)
    linarith [hclose x, hcut x]
  let u : AddCircle (1 : ℝ) → ℝ := fun x => ‖g x - p x‖ ^ 2 / (κ / 2) ^ 2
  have hu : Integrable u haarAddCircle :=
    (((g.continuous.sub p.continuous).norm.pow 2).div_const _).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)
  have hunonneg : 0 ≤ᵐ[haarAddCircle] u := by
    exact Filter.Eventually.of_forall fun x => div_nonneg (sq_nonneg _) (sq_nonneg _)
  have hmeasure : haarAddCircle {x : AddCircle (1 : ℝ) | κ < ‖f x - fourierCoeff f 0‖} ≤
      ENNReal.ofReal (∫ x, u x ∂haarAddCircle) := by
    apply hu.measure_le_integral hunonneg
    intro x hx
    change 1 ≤ ‖g x - p x‖ ^ 2 / (κ / 2) ^ 2
    rw [le_div_iff₀ (sq_pos_of_pos (half_pos hκ)), one_mul]
    exact pow_le_pow_left₀ (half_pos hκ).le (hlarge x hx).le 2
  apply hmeasure.trans
  apply ENNReal.ofReal_le_ofReal
  have htail : (∫ x : AddCircle (1 : ℝ), ‖g x - p x‖ ^ 2 ∂haarAddCircle) ≤
      4 / ((K : ℝ) + 1) := by
    simpa only [one_pow, mul_one] using
      integral_norm_fourierOrbitAverage_sub_cut_sq_le f R hR α 1 K hcoeff
  calc
    (∫ x, u x ∂haarAddCircle) =
        (∫ x : AddCircle (1 : ℝ), ‖g x - p x‖ ^ 2 ∂haarAddCircle) / (κ / 2) ^ 2 := by
      exact integral_div _ _
    _ ≤ (4 / ((K : ℝ) + 1)) / (κ / 2) ^ 2 :=
      div_le_div_of_nonneg_right htail (sq_nonneg _)
    _ = 16 / (κ ^ 2 * ((K : ℝ) + 1)) := by
      have hK : (K : ℝ) + 1 ≠ 0 := by positivity
      field_simp
      ring

/-- The same deviation estimate as a real probability mass. Haar measure on the
unit additive circle is normalized, so no additional normalization is needed. -/
theorem fourier_deviation_measure_le
    (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ) (hR : 0 < R)
    (α : AddCircle (1 : ℝ)) (K : ℕ) (ε κ : ℝ) (hκ : 0 < κ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ 1 / |(k : ℝ)|)
    (hshift : ∀ x, ‖f (x + α) - f x‖ ≤ ε)
    (hsmall : (R : ℝ) * ε ≤ κ / 4)
    (hlow : (∑ k ∈ (Finset.Icc (-(K : ℤ)) (K : ℤ)).erase 0,
      (1 / |(k : ℝ)|) * fourierOrbitMultiplier R α k) ≤ κ / 4) :
    (haarAddCircle {x : AddCircle (1 : ℝ) | κ < ‖f x - fourierCoeff f 0‖}).toReal ≤
      16 / (κ ^ 2 * ((K : ℝ) + 1)) := by
  exact ENNReal.toReal_le_of_le_ofReal (by positivity)
    (fourier_deviation_measure_le_ofReal f R hR α K ε κ hκ hcoeff hshift hsmall hlow)

end CriticalDTM

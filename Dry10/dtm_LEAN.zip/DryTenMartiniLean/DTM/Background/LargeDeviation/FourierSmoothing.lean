import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.Algebra.GeomSum

/-!
# Finite Fejér orbit smoothing

The double orbit average is a genuine finite positive average. Its Fourier
multiplier is the squared modulus of a normalized geometric sum. Everything
here is finite harmonic analysis; no large-deviation or arithmetic estimate
is assumed.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory AddCircle
open scoped ComplexConjugate

private theorem fourier_argument_add (k : ℤ) (x y : AddCircle (1 : ℝ)) :
    fourier k (x + y) = fourier k x * fourier k y := by
  simp only [fourier_apply, zsmul_add, toCircle_add, Circle.coe_mul]

private theorem fourier_argument_neg (k : ℤ) (x : AddCircle (1 : ℝ)) :
    fourier k (-x) = conj (fourier k x) := by
  calc
    fourier k (-x) = fourier (-k) x := by simp only [fourier_apply, zsmul_neg, neg_smul]
    _ = _ := fourier_neg

private theorem fourier_argument_nsmul (k : ℤ) (x : AddCircle (1 : ℝ)) (n : ℕ) :
    fourier k (n • x) = fourier k x ^ n := by
  induction n with
  | zero => simp [fourier_eval_zero]
  | succ n ih => rw [succ_nsmul, fourier_argument_add, ih, pow_succ]

/-- Translation acts diagonally on the normalized circle Fourier coefficients. -/
theorem fourierCoeff_translate (f : AddCircle (1 : ℝ) → ℂ) (a : AddCircle (1 : ℝ)) (k : ℤ) :
    fourierCoeff (fun x => f (x + a)) k = fourier k a * fourierCoeff f k := by
  have hu : fourier k a * fourier (-k) a = 1 := by
    rw [← fourier_add]
    simp [fourier_zero]
  have heq (x : AddCircle (1 : ℝ)) :
      fourier (-k) x * f (x + a) =
        fourier k a * (fourier (-k) (x + a) * f (x + a)) := by
    rw [fourier_argument_add]
    calc
      _ = (fourier k a * fourier (-k) a) * (fourier (-k) x * f (x + a)) := by rw [hu, one_mul]
      _ = _ := by ring
  simp only [fourierCoeff, smul_eq_mul]
  simp_rw [heq]
  rw [integral_const_mul]
  congr 1
  exact integral_add_right_eq_self (fun x : AddCircle (1 : ℝ) => fourier (-k) x * f x) a

/-- The actual double orbit average; phases are taken in the unit additive circle. -/
def fourierOrbitAverage (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ) (α : AddCircle (1 : ℝ)) :
    C(AddCircle (1 : ℝ), ℂ) where
  toFun x := ((R : ℂ) ^ 2)⁻¹ * ∑ j ∈ Finset.range R, ∑ l ∈ Finset.range R,
    f (x + ((j : ℤ) - (l : ℤ)) • α)
  continuous_toFun := by fun_prop

@[simp] theorem fourierOrbitAverage_apply (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ)
    (α x : AddCircle (1 : ℝ)) :
    fourierOrbitAverage f R α x = ((R : ℂ) ^ 2)⁻¹ *
      ∑ j ∈ Finset.range R, ∑ l ∈ Finset.range R, f (x + ((j : ℤ) - (l : ℤ)) • α) := rfl

/-- The normalized geometric orbit sum at frequency `k`. -/
def fourierOrbitAmplitude (R : ℕ) (α : AddCircle (1 : ℝ)) (k : ℤ) : ℂ :=
  (R : ℂ)⁻¹ * ∑ j ∈ Finset.range R, fourier k α ^ j

/-- The Fejér multiplier is a nonnegative real scalar. -/
def fourierOrbitMultiplier (R : ℕ) (α : AddCircle (1 : ℝ)) (k : ℤ) : ℝ :=
  ‖fourierOrbitAmplitude R α k‖ ^ 2

private theorem fourier_orbit_difference (α : AddCircle (1 : ℝ)) (k : ℤ) (j l : ℕ) :
    fourier k (((j : ℤ) - (l : ℤ)) • α) =
      fourier k α ^ j * conj (fourier k α ^ l) := by
  rw [sub_zsmul, fourier_argument_add, fourier_argument_neg]
  simp only [natCast_zsmul, fourier_argument_nsmul]

/-- The Fourier multiplier identity for the actual finite double average. -/
theorem fourierCoeff_fourierOrbitAverage (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ)
    (α : AddCircle (1 : ℝ)) (k : ℤ) :
    fourierCoeff (fourierOrbitAverage f R α) k =
      (fourierOrbitMultiplier R α k : ℂ) * fourierCoeff f k := by
  have hsum : fourierCoeff (fourierOrbitAverage f R α) k =
      ((R : ℂ) ^ 2)⁻¹ * ∑ j ∈ Finset.range R, ∑ l ∈ Finset.range R,
        fourierCoeff (fun x => f (x + ((j : ℤ) - (l : ℤ)) • α)) k := by
    simp only [fourierCoeff, fourierOrbitAverage_apply, smul_eq_mul]
    simp_rw [mul_left_comm (fourier (-k) _)]
    rw [integral_const_mul]
    congr 1
    simp_rw [Finset.mul_sum]
    rw [integral_finset_sum]
    · apply Finset.sum_congr rfl
      intro j _
      rw [integral_finset_sum]
      intro l _
      exact ((fourier (-k)).continuous.mul
        (f.continuous.comp (continuous_id.add continuous_const))).integrable_of_hasCompactSupport
          (HasCompactSupport.of_compactSpace _)
    · intro j _
      apply integrable_finset_sum
      intro l _
      exact ((fourier (-k)).continuous.mul
        (f.continuous.comp (continuous_id.add continuous_const))).integrable_of_hasCompactSupport
          (HasCompactSupport.of_compactSpace _)
  rw [hsum]
  simp_rw [fourierCoeff_translate, fourier_orbit_difference]
  simp only [← Finset.sum_mul, ← Finset.mul_sum, ← map_sum]
  unfold fourierOrbitMultiplier fourierOrbitAmplitude
  rw [← Complex.normSq_eq_norm_sq, ← Complex.mul_conj]
  simp only [map_mul, map_inv₀, map_natCast]
  ring

@[simp] theorem fourierOrbitMultiplier_nonneg (R : ℕ) (α : AddCircle (1 : ℝ)) (k : ℤ) :
    0 ≤ fourierOrbitMultiplier R α k := sq_nonneg _

/-- A normalized average of unit-modulus characters has modulus at most one. -/
theorem norm_fourierOrbitAmplitude_le_one (R : ℕ) (hR : 0 < R)
    (α : AddCircle (1 : ℝ)) (k : ℤ) : ‖fourierOrbitAmplitude R α k‖ ≤ 1 := by
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hu : ‖fourier k α‖ = 1 := Circle.norm_coe _
  unfold fourierOrbitAmplitude
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  calc
    _ ≤ (R : ℝ)⁻¹ * ∑ j ∈ Finset.range R, ‖fourier k α ^ j‖ :=
      mul_le_mul_of_nonneg_left (norm_sum_le _ _) (inv_nonneg.mpr hRr.le)
    _ = 1 := by simp [norm_pow, hu, inv_mul_cancel₀ hRr.ne']

theorem fourierOrbitMultiplier_le_one (R : ℕ) (hR : 0 < R)
    (α : AddCircle (1 : ℝ)) (k : ℤ) : fourierOrbitMultiplier R α k ≤ 1 := by
  exact pow_le_one₀ (norm_nonneg _) (norm_fourierOrbitAmplitude_le_one R hR α k)

/-- At zero frequency the averaging multiplier is exactly one. -/
theorem fourierOrbitMultiplier_zero (R : ℕ) (hR : 0 < R) (α : AddCircle (1 : ℝ)) :
    fourierOrbitMultiplier R α 0 = 1 := by
  have hRc : (R : ℂ) ≠ 0 := by exact_mod_cast hR.ne'
  simp [fourierOrbitMultiplier, fourierOrbitAmplitude, fourier_zero, hRc]

/-- In particular the actual normalized mean is preserved. -/
theorem fourierCoeff_fourierOrbitAverage_zero (f : C(AddCircle (1 : ℝ), ℂ))
    (R : ℕ) (hR : 0 < R) (α : AddCircle (1 : ℝ)) :
    fourierCoeff (fourierOrbitAverage f R α) 0 = fourierCoeff f 0 := by
  rw [fourierCoeff_fourierOrbitAverage, fourierOrbitMultiplier_zero R hR α]
  simp

/-- Smoothing cannot increase the modulus of any individual coefficient. -/
theorem norm_fourierCoeff_fourierOrbitAverage_le (f : C(AddCircle (1 : ℝ), ℂ))
    (R : ℕ) (hR : 0 < R) (α : AddCircle (1 : ℝ)) (k : ℤ) :
    ‖fourierCoeff (fourierOrbitAverage f R α) k‖ ≤ ‖fourierCoeff f k‖ := by
  rw [fourierCoeff_fourierOrbitAverage, norm_mul, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg (fourierOrbitMultiplier_nonneg R α k)]
  exact mul_le_of_le_one_left (norm_nonneg _) (fourierOrbitMultiplier_le_one R hR α k)

/-- The geometric sum gives the denominator estimate away from resonance. -/
theorem norm_fourierOrbitAmplitude_le (R : ℕ) (hR : 0 < R)
    (α : AddCircle (1 : ℝ)) (k : ℤ) (hk : fourier k α ≠ 1) :
    ‖fourierOrbitAmplitude R α k‖ ≤ 2 / ((R : ℝ) * ‖1 - fourier k α‖) := by
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hu : ‖fourier k α‖ = 1 := Circle.norm_coe _
  have hg : ∑ j ∈ Finset.range R, fourier k α ^ j =
      (1 - fourier k α ^ R) / (1 - fourier k α) := by
    apply (eq_div_iff (sub_ne_zero.mpr hk.symm)).mpr
    exact geom_sum_mul_neg _ _
  unfold fourierOrbitAmplitude
  rw [hg, norm_mul, norm_inv, Complex.norm_natCast, norm_div]
  calc
    _ ≤ (R : ℝ)⁻¹ * ((‖(1 : ℂ)‖ + ‖fourier k α ^ R‖) / ‖1 - fourier k α‖) := by
      gcongr
      exact norm_sub_le _ _
    _ = _ := by simp [norm_pow, hu]; ring

/-- A one-step bound telescopes along both positive and negative rotation iterates. -/
theorem norm_rotation_iterate_sub_le (f : AddCircle (1 : ℝ) → ℂ)
    (α : AddCircle (1 : ℝ)) (ε : ℝ)
    (hshift : ∀ x, ‖f (x + α) - f x‖ ≤ ε) (k : ℤ) (x : AddCircle (1 : ℝ)) :
    ‖f (x + k • α) - f x‖ ≤ |(k : ℝ)| * ε := by
  have hnat (n : ℕ) : ∀ x : AddCircle (1 : ℝ),
      ‖f (x + n • α) - f x‖ ≤ (n : ℝ) * ε := by
    induction n with
    | zero => intro x; simp
    | succ n ih =>
      intro x
      rw [succ_nsmul, ← add_assoc]
      calc
        _ ≤ ‖f (x + n • α + α) - f (x + n • α)‖ +
            ‖f (x + n • α) - f x‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
        _ ≤ ε + (n : ℝ) * ε := add_le_add (hshift _) (ih x)
        _ = _ := by push_cast; ring
  cases k with
  | ofNat n => simpa using hnat n x
  | negSucc n =>
    have heq : Int.negSucc n = -((n + 1 : ℕ) : ℤ) := by omega
    rw [heq, neg_smul, natCast_zsmul, Int.cast_neg, Int.cast_natCast, abs_neg,
      abs_of_nonneg (Nat.cast_nonneg (n + 1) : (0 : ℝ) ≤ (n + 1 : ℕ))]
    have h := hnat (n + 1) (x - (n + 1) • α)
    rw [sub_add_cancel] at h
    rw [norm_sub_rev] at h
    simpa only [sub_eq_add_neg] using h

/-- Positive finite averaging changes an almost rotation-invariant function
by at most `R*ε`; both directions of the orbit are included explicitly. -/
theorem norm_fourierOrbitAverage_sub_le (f : C(AddCircle (1 : ℝ), ℂ))
    (R : ℕ) (hR : 0 < R) (α : AddCircle (1 : ℝ)) (ε : ℝ)
    (hshift : ∀ x, ‖f (x + α) - f x‖ ≤ ε) (x : AddCircle (1 : ℝ)) :
    ‖fourierOrbitAverage f R α x - f x‖ ≤ (R : ℝ) * ε := by
  have hε : 0 ≤ ε := (norm_nonneg _).trans (hshift 0)
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hRc : (R : ℂ) ≠ 0 := by exact_mod_cast hR.ne'
  have hconst : ((R : ℂ) ^ 2)⁻¹ *
      (∑ _j ∈ Finset.range R, ∑ _l ∈ Finset.range R, f x) = f x := by
    simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    field_simp
    ring
  have heq : fourierOrbitAverage f R α x - f x = ((R : ℂ) ^ 2)⁻¹ *
      ∑ j ∈ Finset.range R, ∑ l ∈ Finset.range R,
        (f (x + ((j : ℤ) - (l : ℤ)) • α) - f x) := by
    simp only [Finset.sum_sub_distrib, mul_sub, hconst, fourierOrbitAverage_apply]
  rw [heq, norm_mul, norm_inv, norm_pow, Complex.norm_natCast]
  calc
    _ ≤ ((R : ℝ) ^ 2)⁻¹ * ∑ j ∈ Finset.range R, ∑ l ∈ Finset.range R,
        ‖f (x + ((j : ℤ) - (l : ℤ)) • α) - f x‖ := by
      apply mul_le_mul_of_nonneg_left _ (inv_nonneg.mpr (sq_nonneg _))
      exact (norm_sum_le _ _).trans (Finset.sum_le_sum fun j _ => norm_sum_le _ _)
    _ ≤ ((R : ℝ) ^ 2)⁻¹ * ∑ _j ∈ Finset.range R, ∑ _l ∈ Finset.range R,
        (R : ℝ) * ε := by
      apply mul_le_mul_of_nonneg_left _ (inv_nonneg.mpr (sq_nonneg _))
      apply Finset.sum_le_sum
      intro j hj
      apply Finset.sum_le_sum
      intro l hl
      apply (norm_rotation_iterate_sub_le f α ε hshift _ x).trans
      apply mul_le_mul_of_nonneg_right _ hε
      rw [Int.cast_sub, Int.cast_natCast, Int.cast_natCast, abs_le]
      have hjR : (j : ℝ) < R := by exact_mod_cast Finset.mem_range.mp hj
      have hlR : (l : ℝ) < R := by exact_mod_cast Finset.mem_range.mp hl
      have hj0 : (0 : ℝ) ≤ j := Nat.cast_nonneg j
      have hl0 : (0 : ℝ) ≤ l := Nat.cast_nonneg l
      constructor <;> linarith
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
      field_simp
      ring

end CriticalDTM

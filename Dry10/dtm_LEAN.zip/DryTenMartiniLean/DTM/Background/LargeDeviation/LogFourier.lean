import Mathlib.Analysis.SpecialFunctions.Complex.LogBounds
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-!
# Scalar logarithmic Fourier kernels

Fourier coefficients use phase in turns and Lebesgue measure on `[0,1]`.
The logarithmic series is integrated by dominated convergence with a
uniform geometric majorant. No spectral statement is used here.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory
open scoped ComplexConjugate

/-- The integral-frequency characters on one phase period. -/
def logFourierChar (k : ℤ) (t : ℝ) : ℂ :=
  Complex.exp ((k : ℂ) * (2 * (Real.pi : ℂ) * Complex.I) * t)

@[simp] theorem logFourierChar_zero (t : ℝ) : logFourierChar 0 t = 1 := by
  simp [logFourierChar]

@[simp] theorem logFourierChar_norm (k : ℤ) (t : ℝ) : ‖logFourierChar k t‖ = 1 := by
  simp [logFourierChar, Complex.norm_exp]

theorem logFourierChar_continuous (k : ℤ) : Continuous (logFourierChar k) := by
  unfold logFourierChar
  fun_prop

theorem logFourierChar_add (j k : ℤ) (t : ℝ) :
    logFourierChar (j + k) t = logFourierChar j t * logFourierChar k t := by
  simp only [logFourierChar, Int.cast_add, add_mul, Complex.exp_add]

@[simp] theorem logFourierChar_conj (k : ℤ) (t : ℝ) :
    conj (logFourierChar k t) = logFourierChar (-k) t := by
  simp [logFourierChar, ← Complex.exp_conj, map_ofNat]

theorem logFourierChar_pow (k : ℤ) (n : ℕ) (t : ℝ) :
    logFourierChar k t ^ n = logFourierChar (k * n) t := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ, ih, ← logFourierChar_add]
    congr 1
    push_cast
    ring

/-- Orthogonality, with the normalization used throughout this file. -/
theorem integral_logFourierChar (k : ℤ) :
    (∫ t in (0 : ℝ)..1, logFourierChar k t) = if k = 0 then 1 else 0 := by
  by_cases hk : k = 0
  · simp [hk]
  · have hc : (k : ℂ) * (2 * (Real.pi : ℂ) * Complex.I) ≠ 0 := by
      simp [hk, Real.pi_ne_zero]
    unfold logFourierChar
    rw [integral_exp_mul_complex hc]
    simp [hk]

/-- The normalized Fourier coefficient of a real-valued phase function. -/
def logFourierCoeff (f : ℝ → ℝ) (k : ℤ) : ℂ :=
  ∫ t in (0 : ℝ)..1, (f t : ℂ) * logFourierChar (-k) t

@[simp] theorem logFourierCoeff_const (c : ℝ) {k : ℤ} (hk : k ≠ 0) :
    logFourierCoeff (fun _ => c) k = 0 := by
  simp [logFourierCoeff, intervalIntegral.integral_const_mul, integral_logFourierChar, hk]

theorem logFourierCoeff_neg_frequency (f : ℝ → ℝ) (k : ℤ) :
    logFourierCoeff f (-k) = conj (logFourierCoeff f k) := by
  simp only [logFourierCoeff, intervalIntegral, ← integral_conj, map_sub]
  congr 1 <;> apply integral_congr_ae <;> filter_upwards with t <;>
    simp [logFourierChar_conj]

/-- Casting the real part of the complex Taylor series gives the real logarithm. -/
theorem hasSum_neg_log_norm {z : ℂ} (hz : ‖z‖ < 1) :
    HasSum (fun n : ℕ => (((z ^ n / n).re : ℝ) : ℂ))
      (-(Real.log ‖1 - z‖ : ℂ)) := by
  have h := Complex.hasSum_ofReal.mpr
    (Complex.hasSum_re (Complex.hasSum_taylorSeries_neg_log hz))
  simpa only [Complex.neg_re, Complex.log_re, Complex.ofReal_neg] using h

private theorem logFourier_term_bound (a : ℂ) (n : ℕ) (k : ℤ) (t : ℝ) :
    ‖((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
      logFourierChar (-k) t‖ ≤ ‖a‖ ^ n := by
  rw [norm_mul, logFourierChar_norm, mul_one, Complex.norm_real,
    Real.norm_eq_abs]
  calc
    |((a * logFourierChar 1 t) ^ n / n).re| ≤
        ‖(a * logFourierChar 1 t) ^ n / n‖ := Complex.abs_re_le_norm _
    _ ≤ ‖a‖ ^ n := by
      simp only [norm_div, norm_pow, norm_mul, logFourierChar_norm,
        mul_one, Complex.norm_natCast]
      rcases n.eq_zero_or_pos with rfl | hn
      · simp
      · exact div_le_self (pow_nonneg (norm_nonneg a) n) (by exact_mod_cast hn)

/-- Uniform geometric domination justifies termwise Fourier integration. -/
theorem hasSum_logFourier_integrals {a : ℂ} (ha : ‖a‖ < 1) (k : ℤ) :
    HasSum (fun n : ℕ => ∫ t in (0 : ℝ)..1,
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t)
      (-logFourierCoeff (fun t => Real.log ‖1 - a * logFourierChar 1 t‖) k) := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence
    (a := (0 : ℝ)) (b := 1) (μ := volume)
    (F := fun (n : ℕ) t => ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
      logFourierChar (-k) t)
    (f := fun t => -(Real.log ‖1 - a * logFourierChar 1 t‖ : ℂ) *
      logFourierChar (-k) t)
    (fun n _ => ‖a‖ ^ n)
    (fun n => (show Continuous (fun t : ℝ =>
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
        logFourierChar (-k) t) by
      unfold logFourierChar
      fun_prop).aestronglyMeasurable)
    (fun n => ae_of_all _ (fun t _ => logFourier_term_bound a n k t))
    (ae_of_all _ (fun _ _ => summable_geometric_of_lt_one (norm_nonneg a) ha))
    intervalIntegrable_const
    (ae_of_all _ (fun t _ =>
      (hasSum_neg_log_norm (by simpa using ha : ‖a * logFourierChar 1 t‖ < 1)).mul_right
        (logFourierChar (-k) t)))
  simpa only [neg_mul, intervalIntegral.integral_neg, logFourierCoeff] using h

private theorem integral_logFourier_term (a : ℂ) (n : ℕ) (k : ℤ) :
    (∫ t in (0 : ℝ)..1,
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t) =
      (a ^ n * (if (n : ℤ) - k = 0 then 1 else 0) +
        conj a ^ n * (if -(n : ℤ) - k = 0 then 1 else 0)) / (2 * n) := by
  have hterm (t : ℝ) :
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t =
        (a ^ n * logFourierChar ((n : ℤ) - k) t +
          conj a ^ n * logFourierChar (-(n : ℤ) - k) t) / (2 * n) := by
    rw [Complex.re_eq_add_conj]
    simp only [map_div₀, map_pow, map_mul, map_natCast, logFourierChar_conj,
      mul_pow, logFourierChar_pow, one_mul, neg_one_mul]
    rw [sub_eq_add_neg, sub_eq_add_neg, logFourierChar_add, logFourierChar_add]
    ring
  simp_rw [hterm]
  rw [intervalIntegral.integral_div, intervalIntegral.integral_add]
  · simp only [intervalIntegral.integral_const_mul, integral_logFourierChar]
  · exact (continuous_const.mul (logFourierChar_continuous _)).intervalIntegrable _ _
  · exact (continuous_const.mul (logFourierChar_continuous _)).intervalIntegrable _ _

/-- Positive coefficients of `log |1-a exp(2πit)|`, including their exact sign. -/
theorem logFourierCoeff_one_sub {a : ℂ} (ha : ‖a‖ < 1) {k : ℕ} (hk : 0 < k) :
    logFourierCoeff (fun t => Real.log ‖1 - a * logFourierChar 1 t‖) k =
      -(a ^ k / (2 * k)) := by
  have hterm (n : ℕ) :
      (∫ t in (0 : ℝ)..1,
        ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
          logFourierChar (-(k : ℤ)) t) = if n = k then a ^ k / (2 * k) else 0 := by
    rw [integral_logFourier_term]
    have hneg : -(n : ℤ) - k ≠ 0 := by omega
    by_cases hn : n = k
    · subst n
      simp [hneg]
    · have hne : (n : ℤ) - k ≠ 0 := by omega
      simp [hn, hne, hneg]
  have h := hasSum_logFourier_integrals ha (k : ℤ)
  simp_rw [hterm] at h
  have heq := h.unique (hasSum_ite_eq k (a ^ k / (2 * k)))
  exact neg_eq_iff_eq_neg.mp heq

theorem logFourierCoeff_add {f g : ℝ → ℝ} (hf : Continuous f) (hg : Continuous g)
    (k : ℤ) :
    logFourierCoeff (fun t => f t + g t) k = logFourierCoeff f k + logFourierCoeff g k := by
  simp only [logFourierCoeff, Complex.ofReal_add, add_mul]
  apply intervalIntegral.integral_add
  · exact ((Complex.continuous_ofReal.comp hf).mul (logFourierChar_continuous _)).intervalIntegrable _ _
  · exact ((Complex.continuous_ofReal.comp hg).mul (logFourierChar_continuous _)).intervalIntegrable _ _

theorem logFourierChar_sub_ne_zero {a : ℂ} (ha : ‖a‖ ≠ 1) (t : ℝ) :
    logFourierChar 1 t - a ≠ 0 := by
  intro h
  apply ha
  have := congrArg norm (sub_eq_zero.mp h)
  simpa using this.symm

/-- The no-unit-circle-root condition guarantees genuine logarithmic continuity. -/
theorem continuous_logFourier_root {a : ℂ} (ha : ‖a‖ ≠ 1) :
    Continuous (fun t => Real.log ‖logFourierChar 1 t - a‖) := by
  exact ((logFourierChar_continuous 1).sub continuous_const).norm.log
    (fun t => norm_ne_zero_iff.mpr (logFourierChar_sub_ne_zero ha t))

private theorem logFourier_root_inside_norm (a : ℂ) (t : ℝ) :
    ‖logFourierChar 1 t - a‖ = ‖1 - conj a * logFourierChar 1 t‖ := by
  have hm : logFourierChar 1 t * logFourierChar (-1) t = 1 := by
    rw [← logFourierChar_add]
    simp
  calc
    ‖logFourierChar 1 t - a‖ = ‖conj (logFourierChar 1 t - a)‖ := (Complex.norm_conj _).symm
    _ = ‖logFourierChar 1 t * conj (logFourierChar 1 t - a)‖ := by
      rw [norm_mul, logFourierChar_norm, one_mul]
    _ = ‖1 - conj a * logFourierChar 1 t‖ := by
      congr 1
      simp only [map_sub, logFourierChar_conj, mul_sub, hm]
      ring

/-- A root strictly inside the circle contributes `-conj(a)^k/(2k)`. -/
theorem logFourierCoeff_root_inside {a : ℂ} (ha : ‖a‖ < 1) {k : ℕ} (hk : 0 < k) :
    logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k =
      -(conj a ^ k / (2 * k)) := by
  simp_rw [logFourier_root_inside_norm]
  exact logFourierCoeff_one_sub (by simpa using ha) hk

/-- A root strictly outside the circle contributes `-a⁻ᵏ/(2k)`. -/
theorem logFourierCoeff_root_outside {a : ℂ} (ha : 1 < ‖a‖) {k : ℕ} (hk : 0 < k) :
    logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k =
      -(a⁻¹ ^ k / (2 * k)) := by
  have ha0 : a ≠ 0 := by intro h; norm_num [h] at ha
  have hi : ‖a⁻¹‖ < 1 := by rw [norm_inv]; exact inv_lt_one_of_one_lt₀ ha
  have hn (t : ℝ) : 1 - a⁻¹ * logFourierChar 1 t ≠ 0 := by
    intro h
    have hh := congrArg norm (sub_eq_zero.mp h)
    have hh' : ‖a⁻¹‖ = 1 := by simpa [norm_mul] using hh.symm
    exact (ne_of_lt hi) hh'
  have hc : Continuous (fun t => Real.log ‖1 - a⁻¹ * logFourierChar 1 t‖) :=
    (continuous_const.sub (continuous_const.mul (logFourierChar_continuous 1))).norm.log
      (fun t => norm_ne_zero_iff.mpr (hn t))
  have heq (t : ℝ) : Real.log ‖logFourierChar 1 t - a‖ =
      Real.log ‖a‖ + Real.log ‖1 - a⁻¹ * logFourierChar 1 t‖ := by
    have hfactor : logFourierChar 1 t - a = -a * (1 - a⁻¹ * logFourierChar 1 t) := by
      field_simp
      ring
    rw [hfactor, norm_mul, norm_neg, Real.log_mul (norm_ne_zero_iff.mpr ha0)
      (norm_ne_zero_iff.mpr (hn t))]
  simp_rw [heq]
  rw [logFourierCoeff_add continuous_const hc, logFourierCoeff_const _ (by omega), zero_add]
  exact logFourierCoeff_one_sub hi hk

/-- Every off-circle root has the required nonzero-frequency Fourier bound. -/
theorem norm_logFourierCoeff_root {a : ℂ} (ha : ‖a‖ ≠ 1) {k : ℤ} (hk : k ≠ 0) :
    ‖logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k‖ ≤
      1 / (2 * |(k : ℝ)|) := by
  have hpos (m : ℕ) (hm : 0 < m) :
      ‖logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) m‖ ≤
        1 / (2 * (m : ℝ)) := by
    rcases lt_or_gt_of_ne ha with h | h
    · rw [logFourierCoeff_root_inside h hm, norm_neg, norm_div, norm_pow, Complex.norm_conj]
      simp only [norm_mul, Complex.norm_ofNat, Complex.norm_natCast]
      exact div_le_div_of_nonneg_right (pow_le_one₀ (norm_nonneg a) h.le) (by positivity)
    · rw [logFourierCoeff_root_outside h hm, norm_neg, norm_div, norm_pow, norm_inv]
      simp only [norm_mul, Complex.norm_ofNat, Complex.norm_natCast]
      exact div_le_div_of_nonneg_right
        (pow_le_one₀ (inv_nonneg.mpr (norm_nonneg a)) (inv_le_one_of_one_le₀ h.le))
        (by positivity)
  rcases k with m | m
  · have hm : 0 < m := Nat.pos_of_ne_zero (by intro h; subst m; exact hk rfl)
    simpa using hpos m hm
  · have heq : Int.negSucc m = -((m + 1 : ℕ) : ℤ) := by omega
    rw [heq, logFourierCoeff_neg_frequency, Complex.norm_conj]
    simpa only [Int.cast_neg, Int.cast_natCast, abs_neg,
      abs_of_nonneg (Nat.cast_nonneg (m + 1) : (0 : ℝ) ≤ (m + 1 : ℕ))]
      using hpos (m + 1) (by omega)

end CriticalDTM

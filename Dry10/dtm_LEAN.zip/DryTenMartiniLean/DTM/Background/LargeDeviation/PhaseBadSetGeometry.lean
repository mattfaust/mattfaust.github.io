import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

/-!
# Degree-controlled thickening of polynomial phase bad sets

A short real translation can enter an open bad set only by crossing one of
its two threshold levels. On the unit circle each nonconstant polynomial
modulus level has at most twice the polynomial degree many points. These
facts give the required thickening estimate without semialgebraic geometry.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory AddCircle Set Polynomial
open scoped ENNReal

/-- The open deviation set of a real-valued circle function. -/
def phaseBadSet (f : AddCircle (1 : ℝ) → ℝ) (c κ : ℝ) : Set (AddCircle (1 : ℝ)) :=
  {x | κ < |f x - c|}

/-- The hull by real translations of size at most `δ`. -/
def phaseBadHull (s : Set (AddCircle (1 : ℝ))) (δ : ℝ) : Set (AddCircle (1 : ℝ)) :=
  {x | ∃ t : ℝ, |t| ≤ δ ∧ x + (t : AddCircle (1 : ℝ)) ∈ s}

theorem isOpen_phaseBadSet {f : AddCircle (1 : ℝ) → ℝ} (hf : Continuous f)
    (c κ : ℝ) : IsOpen (phaseBadSet f c κ) :=
  isOpen_lt continuous_const (hf.sub continuous_const).abs

theorem isOpen_phaseBadHull {s : Set (AddCircle (1 : ℝ))} (hs : IsOpen s) (δ : ℝ) :
    IsOpen (phaseBadHull s δ) := by
  have heq : phaseBadHull s δ =
      ⋃ t : ℝ, ⋃ (_ : |t| ≤ δ), (fun x : AddCircle (1 : ℝ) => x + (t : AddCircle (1 : ℝ))) ⁻¹' s := by
    ext x
    simp [phaseBadHull]
  rw [heq]
  exact isOpen_iUnion fun t => isOpen_iUnion fun _ =>
    hs.preimage (continuous_id.add continuous_const)

/-- An entering translation crosses a threshold within its real travel distance. -/
theorem phaseBadHull_subset_bad_union_threshold_balls
    {f : AddCircle (1 : ℝ) → ℝ} (hf : Continuous f) (c κ δ : ℝ)
    (S : Finset (AddCircle (1 : ℝ)))
    (hS : ∀ y, |f y - c| = κ → y ∈ S) :
    phaseBadHull (phaseBadSet f c κ) δ ⊆
      phaseBadSet f c κ ∪ ⋃ y ∈ S, Metric.closedBall y δ := by
  intro x hx
  by_cases hxb : x ∈ phaseBadSet f c κ
  · exact Or.inl hxb
  right
  obtain ⟨s, hs, hxs⟩ := hx
  have hxle : |f x - c| ≤ κ := le_of_not_gt hxb
  have hxsle : κ ≤ |f (x + (s : AddCircle (1 : ℝ))) - c| := le_of_lt hxs
  let g : ℝ → ℝ := fun t => |f (x + (t : AddCircle (1 : ℝ))) - c|
  have hg : Continuous g :=
    ((hf.comp (continuous_const.add QuotientAddGroup.continuous_mk)).sub continuous_const).abs
  have h0 : g 0 ≤ κ := by simpa [g] using hxle
  obtain ⟨t, ht, hgt⟩ := intermediate_value_uIcc hg.continuousOn
    (Set.mem_uIcc.mpr (Or.inl ⟨h0, hxsle⟩))
  have htδ : |t| ≤ δ := by
    obtain ⟨hs₁, hs₂⟩ := abs_le.mp hs
    rcases Set.mem_uIcc.mp ht with ht | ht <;> apply abs_le.mpr <;> constructor <;> linarith
  refine Set.mem_iUnion.mpr ⟨x + (t : AddCircle (1 : ℝ)), Set.mem_iUnion.mpr ⟨hS _ hgt, ?_⟩⟩
  have hnorm : ‖(t : AddCircle (1 : ℝ))‖ ≤ |t| :=
    QuotientAddGroup.norm_mk_le_norm
  simpa only [Metric.mem_closedBall, dist_eq_norm, sub_add_cancel_left, norm_neg] using
    hnorm.trans htδ

/-- The unit-period Haar probability of a closed ball is at most its diameter. -/
theorem haarAddCircle_closedBall_le (y : AddCircle (1 : ℝ)) (δ : ℝ) :
    haarAddCircle (Metric.closedBall y δ) ≤ ENNReal.ofReal (2 * δ) := by
  have hv : (volume : Measure (AddCircle (1 : ℝ))) = haarAddCircle := by
    simpa using (volume_eq_smul_haarAddCircle (T := (1 : ℝ)))
  rw [← hv, AddCircle.volume_closedBall]
  exact ENNReal.ofReal_le_ofReal (min_le_right _ _)

/-- Finite threshold complexity gives a quantitative Haar thickening bound. -/
theorem measure_phaseBadHull_le_of_threshold_finset
    {f : AddCircle (1 : ℝ) → ℝ} (hf : Continuous f) (c κ δ : ℝ)
    (S : Finset (AddCircle (1 : ℝ)))
    (hS : ∀ y, |f y - c| = κ → y ∈ S) :
    haarAddCircle (phaseBadHull (phaseBadSet f c κ) δ) ≤
      haarAddCircle (phaseBadSet f c κ) + ENNReal.ofReal (2 * (S.card : ℝ) * δ) := by
  calc
    _ ≤ haarAddCircle (phaseBadSet f c κ ∪ ⋃ y ∈ S, Metric.closedBall y δ) :=
      measure_mono (phaseBadHull_subset_bad_union_threshold_balls hf c κ δ S hS)
    _ ≤ haarAddCircle (phaseBadSet f c κ) +
        haarAddCircle (⋃ y ∈ S, Metric.closedBall y δ) := measure_union_le _ _
    _ ≤ haarAddCircle (phaseBadSet f c κ) + ∑ y ∈ S, haarAddCircle (Metric.closedBall y δ) :=
      add_le_add_left (measure_biUnion_finset_le S _) _
    _ ≤ haarAddCircle (phaseBadSet f c κ) + ∑ _y ∈ S, ENNReal.ofReal (2 * δ) :=
      add_le_add_left (Finset.sum_le_sum fun y _ => haarAddCircle_closedBall_le y δ) _
    _ = _ := by
      simp only [Finset.sum_const, nsmul_eq_mul]
      rw [← ENNReal.ofReal_natCast, ← ENNReal.ofReal_mul (Nat.cast_nonneg _)]
      congr 2
      ring

/-- The real logarithmic modulus of an ordinary polynomial on the unit circle. -/
def phasePolynomialLog (P : Polynomial ℂ) (x : AddCircle (1 : ℝ)) : ℝ :=
  Real.log ‖P.eval (_root_.fourier 1 x)‖

theorem continuous_phasePolynomialLog (P : Polynomial ℂ)
    (hP : ∀ w : ℂ, ‖w‖ = 1 → P.eval w ≠ 0) : Continuous (phasePolynomialLog P) :=
  (P.continuous.comp (_root_.fourier 1).continuous).norm.log
    (fun x => norm_ne_zero_iff.mpr (hP (_root_.fourier 1 x) (Circle.norm_coe _)))

/-- The fixed-degree reflected polynomial encoding one modulus level. -/
def phaseLevelPolynomial (P : Polynomial ℂ) (a : ℝ) : Polynomial ℂ :=
  P * Polynomial.reflect P.natDegree (P.map (starRingEnd ℂ)) -
    C ((Real.exp (2 * a) : ℝ) : ℂ) * X ^ P.natDegree

private theorem phase_reflect_natDegree_le (P : Polynomial ℂ) (D : ℕ)
    (hP : P.natDegree ≤ D) : (Polynomial.reflect D P).natDegree ≤ D := by
  apply Polynomial.natDegree_le_iff_coeff_eq_zero.mpr
  intro j hj
  rw [Polynomial.coeff_reflect, Polynomial.revAt_eq_self_of_lt hj]
  exact Polynomial.coeff_eq_zero_of_natDegree_lt (hP.trans_lt hj)

/-- One modulus level is encoded by a polynomial of degree at most `2*deg P`. -/
theorem phaseLevelPolynomial_natDegree_le (P : Polynomial ℂ) (a : ℝ) :
    (phaseLevelPolynomial P a).natDegree ≤ 2 * P.natDegree := by
  apply (Polynomial.natDegree_sub_le _ _).trans
  apply max_le
  · exact (Polynomial.natDegree_mul_le_of_le (le_refl P.natDegree)
      (phase_reflect_natDegree_le _ _ Polynomial.natDegree_map_le)).trans (by omega)
  · exact (Polynomial.natDegree_C_mul_X_pow_le _ _).trans (by omega)

private theorem phase_reflect_eval (P : Polynomial ℂ) {D : ℕ} (hP : P.natDegree ≤ D)
    {w : ℂ} (hw : ‖w‖ = 1) :
    (Polynomial.reflect D (P.map (starRingEnd ℂ))).eval w = w ^ D * star (P.eval w) := by
  have hw0 : w ≠ 0 := by intro h; simp [h] at hw
  have hconj : star w = w⁻¹ := by
    rw [Complex.inv_def, Complex.normSq_eq_norm_sq, hw]
    simp
  have heval : (P.map (starRingEnd ℂ)).eval (w⁻¹) = star (P.eval w) := by
    rw [← hconj, Polynomial.eval_map]
    exact Polynomial.eval₂_hom (starRingEnd ℂ) w
  letI : Invertible (w⁻¹) := invertibleOfNonzero (inv_ne_zero hw0)
  have hreflect := Polynomial.eval₂_reflect_mul_pow (RingHom.id ℂ) (w⁻¹) D
    (P.map (starRingEnd ℂ)) (Polynomial.natDegree_map_le.trans hP)
  simp only [invOf_eq_inv, inv_inv] at hreflect
  change (Polynomial.reflect D (P.map (starRingEnd ℂ))).eval w * (w⁻¹) ^ D =
    (P.map (starRingEnd ℂ)).eval (w⁻¹) at hreflect
  rw [heval] at hreflect
  apply mul_right_cancel₀ (pow_ne_zero D (inv_ne_zero hw0))
  calc
    _ = star (P.eval w) := hreflect
    _ = star (P.eval w) * (w * w⁻¹) ^ D := by
      rw [mul_inv_cancel₀ hw0, one_pow, mul_one]
    _ = _ := by rw [mul_pow]; ring

/-- The reflected level polynomial has exactly the prescribed modulus equation. -/
theorem phaseLevelPolynomial_eval (P : Polynomial ℂ) (a : ℝ) {w : ℂ} (hw : ‖w‖ = 1) :
    (phaseLevelPolynomial P a).eval w =
      w ^ P.natDegree * (((‖P.eval w‖ ^ 2 : ℝ) : ℂ) - (Real.exp (2 * a) : ℂ)) := by
  rw [phaseLevelPolynomial, Polynomial.eval_sub, Polynomial.eval_mul,
    phase_reflect_eval P (le_refl _) hw]
  simp only [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_pow, Polynomial.eval_X]
  rw [mul_left_comm, Complex.star_def, Complex.mul_conj, Complex.normSq_eq_norm_sq]
  ring

/-- On a nonvanishing unit-circle phase, the polynomial equation is equivalent
exactly to the logarithmic level, not merely an implication. -/
theorem phaseLevelPolynomial_eval_eq_zero_iff (P : Polynomial ℂ) (a : ℝ)
    {w : ℂ} (hw : ‖w‖ = 1) (hPw : P.eval w ≠ 0) :
    (phaseLevelPolynomial P a).eval w = 0 ↔ Real.log ‖P.eval w‖ = a := by
  have hw0 : w ≠ 0 := by intro h; simp [h] at hw
  rw [phaseLevelPolynomial_eval P a hw, mul_eq_zero,
    or_iff_right (pow_ne_zero _ hw0), sub_eq_zero, Complex.ofReal_inj]
  have hexp : Real.exp (2 * a) = (Real.exp a) ^ 2 := by
    rw [two_mul, Real.exp_add, pow_two]
  rw [hexp, sq_eq_sq₀ (norm_nonneg _) (Real.exp_pos a).le]
  constructor
  · intro h
    rw [h, Real.log_exp]
  · intro h
    rw [← h, Real.exp_log (norm_pos_iff.mpr hPw)]

private theorem phase_fourier_one_injective :
    Function.Injective (fun x : AddCircle (1 : ℝ) => (_root_.fourier 1 x : ℂ)) := by
  intro x y h
  dsimp only at h
  rw [_root_.fourier_one, _root_.fourier_one, Subtype.coe_inj] at h
  exact AddCircle.injective_toCircle one_ne_zero h

/-- Pulling the polynomial roots back along the injective circle parametrization. -/
def phaseLevelRoots (P : Polynomial ℂ) (a : ℝ) : Finset (AddCircle (1 : ℝ)) :=
  (phaseLevelPolynomial P a).roots.toFinset.preimage
    (fun x : AddCircle (1 : ℝ) => (_root_.fourier 1 x : ℂ)) phase_fourier_one_injective.injOn

/-- Every nondegenerate level has at most twice the original polynomial degree
many points; multiplicities can only reduce the number of distinct phases. -/
theorem phaseLevelRoots_card_le (P : Polynomial ℂ) (a : ℝ) :
    (phaseLevelRoots P a).card ≤ 2 * P.natDegree := by
  classical
  unfold phaseLevelRoots
  rw [Finset.card_preimage]
  exact (Finset.card_filter_le _ _).trans
    ((Multiset.toFinset_card_le _).trans
      ((Polynomial.card_roots' _).trans (phaseLevelPolynomial_natDegree_le P a)))

theorem mem_phaseLevelRoots_iff (P : Polynomial ℂ) (a : ℝ)
    (hP : ∀ w : ℂ, ‖w‖ = 1 → P.eval w ≠ 0) (hQ : phaseLevelPolynomial P a ≠ 0)
    (x : AddCircle (1 : ℝ)) : x ∈ phaseLevelRoots P a ↔ phasePolynomialLog P x = a := by
  simp only [phaseLevelRoots, Finset.mem_preimage, Multiset.mem_toFinset,
    Polynomial.mem_roots hQ, Polynomial.IsRoot.def]
  exact phaseLevelPolynomial_eval_eq_zero_iff P a (Circle.norm_coe _)
    (hP _ (Circle.norm_coe _))

/-- If the level polynomial vanishes identically, the logarithmic modulus really
is constant on the entire circle. This is the necessary degeneracy branch. -/
theorem phasePolynomialLog_constant_of_levelPolynomial_eq_zero (P : Polynomial ℂ) (a : ℝ)
    (hP : ∀ w : ℂ, ‖w‖ = 1 → P.eval w ≠ 0) (hQ : phaseLevelPolynomial P a = 0)
    (x : AddCircle (1 : ℝ)) : phasePolynomialLog P x = a := by
  apply (phaseLevelPolynomial_eval_eq_zero_iff P a (Circle.norm_coe _)
    (hP _ (Circle.norm_coe _))).mp
  rw [hQ, Polynomial.eval_zero]

/-- The two threshold levels have at most `4*deg P` points unless the strict
bad set is empty because the modulus is identically a threshold. -/
theorem phasePolynomialLog_threshold_complexity (P : Polynomial ℂ)
    (hP : ∀ w : ℂ, ‖w‖ = 1 → P.eval w ≠ 0) (c : ℝ) {κ : ℝ} (hκ : 0 ≤ κ) :
    phaseBadSet (phasePolynomialLog P) c κ = ∅ ∨
      ∃ S : Finset (AddCircle (1 : ℝ)), S.card ≤ 4 * P.natDegree ∧
        ∀ x, |phasePolynomialLog P x - c| = κ → x ∈ S := by
  classical
  have hdegenerate (a : ℝ) (ha : |a - c| = κ) (hQ : phaseLevelPolynomial P a = 0) :
      phaseBadSet (phasePolynomialLog P) c κ = ∅ := by
    ext x
    simp only [phaseBadSet, Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false]
    rw [phasePolynomialLog_constant_of_levelPolynomial_eq_zero P a hP hQ x, ha]
    exact lt_irrefl _
  have hmlevel : |(c - κ) - c| = κ := by
    rw [show (c - κ) - c = -κ by ring, abs_neg, abs_of_nonneg hκ]
  have hplevel : |(c + κ) - c| = κ := by
    rw [add_sub_cancel_left, abs_of_nonneg hκ]
  by_cases hm : phaseLevelPolynomial P (c - κ) = 0
  · exact Or.inl (hdegenerate _ hmlevel hm)
  by_cases hp : phaseLevelPolynomial P (c + κ) = 0
  · exact Or.inl (hdegenerate _ hplevel hp)
  right
  refine ⟨phaseLevelRoots P (c - κ) ∪ phaseLevelRoots P (c + κ), ?_, ?_⟩
  · exact (Finset.card_union_le _ _).trans
      ((Nat.add_le_add (phaseLevelRoots_card_le P (c - κ))
        (phaseLevelRoots_card_le P (c + κ))).trans (by omega))
  · intro x hx
    rcases le_total 0 (phasePolynomialLog P x - c) with h | h
    · apply Finset.mem_union_right
      apply (mem_phaseLevelRoots_iff P (c + κ) hP hp x).mpr
      rw [abs_of_nonneg h] at hx
      linarith
    · apply Finset.mem_union_left
      apply (mem_phaseLevelRoots_iff P (c - κ) hP hm x).mpr
      rw [abs_of_nonpos h] at hx
      linarith

@[simp] theorem phaseBadHull_empty (δ : ℝ) :
    phaseBadHull (∅ : Set (AddCircle (1 : ℝ))) δ = ∅ := by
  ext x
  simp [phaseBadHull]

/-- Degree-controlled thickening of the actual logarithmic polynomial bad set.
The coefficient is `8`, stronger than the convenient `16` bound. -/
theorem measure_phaseBadHull_polynomial_le (P : Polynomial ℂ)
    (hP : ∀ w : ℂ, ‖w‖ = 1 → P.eval w ≠ 0) (c : ℝ) {κ δ : ℝ}
    (hκ : 0 ≤ κ) (hδ : 0 ≤ δ) :
    haarAddCircle (phaseBadHull (phaseBadSet (phasePolynomialLog P) c κ) δ) ≤
      haarAddCircle (phaseBadSet (phasePolynomialLog P) c κ) +
        ENNReal.ofReal (8 * (P.natDegree : ℝ) * δ) := by
  obtain hbad | ⟨S, hcard, hS⟩ := phasePolynomialLog_threshold_complexity P hP c hκ
  · simp [hbad]
  calc
    _ ≤ haarAddCircle (phaseBadSet (phasePolynomialLog P) c κ) +
        ENNReal.ofReal (2 * (S.card : ℝ) * δ) :=
      measure_phaseBadHull_le_of_threshold_finset (continuous_phasePolynomialLog P hP) c κ δ S hS
    _ ≤ _ := by
      apply add_le_add_left
      apply ENNReal.ofReal_le_ofReal
      have hc : (S.card : ℝ) ≤ 4 * (P.natDegree : ℝ) := by exact_mod_cast hcard
      nlinarith

end CriticalDTM

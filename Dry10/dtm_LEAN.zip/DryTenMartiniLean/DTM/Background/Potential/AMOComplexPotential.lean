import DTM.Background.Potential.AMOLogPotential
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-!
# The actual logarithmic potential off the real axis

Off-real logarithmic kernels are continuous on the full real line. The existing
spectral-test bridge therefore identifies their phase-averaged AMO integrals
with the actual magnetic root integral. No transfer exponent is renamed here.

The integral definitions below are used at nonreal energies. Their totalized
values at real singular energies are not identified with the intrinsic EReal
potential; that boundary value is recovered by a proved decreasing limit.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Topology

def complexLogKernel (z : ℂ) (x : ℝ) : ℝ := Real.log ‖z - (x : ℂ)‖

theorem complexLogKernel_continuous {z : ℂ} (hz : z.im ≠ 0) :
    Continuous (complexLogKernel z) := by
  apply (continuous_const.sub Complex.continuous_ofReal).norm.log
  intro x h
  have heq : z = (x : ℂ) := sub_eq_zero.mp (norm_eq_zero.mp h)
  exact hz (by rw [heq]; simp)

def magneticComplexLogPotential (α lam : ℝ) (z : ℂ) : ℝ :=
  ∫ x : ℝ, complexLogKernel z x ∂magneticRealSpectralMeasure α lam

def amoComplexLogPotential (α lam : ℝ) (z : ℂ) : ℝ :=
  ∫ t in (0 : ℝ)..1, ∫ x : ℝ,
    complexLogKernel z x ∂amoRealSpectralMeasure α lam (2 * Real.pi * t)

theorem amoComplexLogPotential_eq_magnetic (α lam : ℝ) {z : ℂ}
    (hz : z.im ≠ 0) :
    amoComplexLogPotential α lam z = magneticComplexLogPotential α lam z :=
  (magneticRealSpectralMeasure_integral_eq_phase_average α lam
    (complexLogKernel z) (complexLogKernel_continuous hz)).symm

theorem magneticComplexLogPotential_eq_compactIntegral (α lam : ℝ) (z : ℂ) :
    magneticComplexLogPotential α lam z =
      ∫ x : MagneticRealSpectrum α lam, complexLogKernel z (x : ℝ)
        ∂magneticSpectralMeasure α lam :=
  magneticRealSpectralMeasure_integral_eq_subtype α lam (complexLogKernel z)

theorem magnetic_complexLogKernel_integrable (α lam : ℝ) {z : ℂ}
    (hz : z.im ≠ 0) :
    Integrable (fun x : MagneticRealSpectrum α lam => complexLogKernel z (x : ℝ))
      (magneticSpectralMeasure α lam) :=
  ((complexLogKernel_continuous hz).comp continuous_subtype_val).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

/-- A scalar logarithmic estimate with a uniform error. This avoids passing a
singular real logarithm through an integral at spectral energies. -/
theorem regularizedLogKernel_le_complexLogKernel_add
    (n : ℕ) (E x eta : ℝ) (heta : 0 < eta) :
    regularizedLogKernel n (E - x) ≤
      complexLogKernel ((E : ℂ) + (eta : ℂ) * Complex.I) x +
        logRegularizationScale n / eta := by
  let r : ℝ := ‖(E : ℂ) + (eta : ℂ) * Complex.I - (x : ℂ)‖
  have he : eta ≤ r := by
    simpa [r] using Complex.im_le_norm
      ((E : ℂ) + (eta : ℂ) * Complex.I - (x : ℂ))
  have hr : 0 < r := heta.trans_le he
  have ha : |E - x| ≤ r := by
    simpa [r] using Complex.abs_re_le_norm
      ((E : ℂ) + (eta : ℂ) * Complex.I - (x : ℂ))
  have hd := logRegularizationScale_pos n
  have hfrac := Real.log_le_sub_one_of_pos
    (div_pos (add_pos_of_nonneg_of_pos (abs_nonneg (E - x)) hd) hr)
  rw [Real.log_div (ne_of_gt (add_pos_of_nonneg_of_pos (abs_nonneg (E - x)) hd))
    (ne_of_gt hr)] at hfrac
  have hdiv : (|E - x| + logRegularizationScale n) / r - 1 ≤
      logRegularizationScale n / r := by
    rw [add_div]
    have := (div_le_one hr).mpr ha
    linarith
  have hscale : logRegularizationScale n / r ≤ logRegularizationScale n / eta :=
    div_le_div_of_nonneg_left hd.le heta he
  change Real.log (|E - x| + logRegularizationScale n) ≤
    Real.log r + logRegularizationScale n / eta
  linarith

/-- Integrating the scalar comparison preserves its explicit uniform error. -/
theorem magneticRegularizedLogPotential_le_complex_add
    (α lam E eta : ℝ) (heta : 0 < eta) (n : ℕ) :
    magneticRegularizedLogPotential α n (lam, E) ≤
      magneticComplexLogPotential α lam ((E : ℂ) + (eta : ℂ) * Complex.I) +
        logRegularizationScale n / eta := by
  have hz : ((E : ℂ) + (eta : ℂ) * Complex.I).im ≠ 0 := by
    simpa using ne_of_gt heta
  rw [magneticRegularizedLogPotential_eq_spectralIntegral,
    magneticComplexLogPotential_eq_compactIntegral]
  have h := integral_mono (magnetic_regularizedLogKernel_integrable α lam E n)
    ((magnetic_complexLogKernel_integrable α lam hz).add
      (integrable_const (logRegularizationScale n / eta)))
    (fun x : MagneticRealSpectrum α lam =>
      regularizedLogKernel_le_complexLogKernel_add n E x eta heta)
  change (∫ x : MagneticRealSpectrum α lam,
    regularizedLogKernel n (E - (x : ℝ)) ∂magneticSpectralMeasure α lam) ≤
      ∫ x : MagneticRealSpectrum α lam,
        complexLogKernel ((E : ℂ) + (eta : ℂ) * Complex.I) (x : ℝ) +
          logRegularizationScale n / eta ∂magneticSpectralMeasure α lam at h
  rw [integral_add (magnetic_complexLogKernel_integrable α lam hz)
    (integrable_const (logRegularizationScale n / eta))] at h
  simpa using h

/-- The intrinsic spectral boundary value is below each off-real potential.
This holds even if the boundary value is `-∞`, without a log-integrability input. -/
theorem magneticTotalLogPotential_le_complexLogPotential
    (α lam E eta : ℝ) (heta : 0 < eta) :
    magneticTotalLogPotential α (lam, E) ≤
      (magneticComplexLogPotential α lam ((E : ℂ) + (eta : ℂ) * Complex.I) : EReal) := by
  let V := magneticComplexLogPotential α lam ((E : ℂ) + (eta : ℂ) * Complex.I)
  have hlim : Tendsto (fun n : ℕ => V + logRegularizationScale n / eta)
      atTop (𝓝 V) := by
    simpa using tendsto_const_nhds.add (logRegularizationScale_tendsto.div_const eta)
  apply ge_of_tendsto' (continuous_coe_real_ereal.continuousAt.tendsto.comp hlim)
  intro n
  exact (iInf_le (fun m : ℕ =>
    (magneticRegularizedLogPotential α m (lam, E) : EReal)) n).trans
      (EReal.coe_le_coe_iff.mpr
        (magneticRegularizedLogPotential_le_complex_add α lam E eta heta n))

/-- The smaller imaginary regularization is bounded by the additive one. -/
theorem complexLogKernel_regularization_le (n : ℕ) (E x : ℝ) :
    complexLogKernel ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) x ≤
      regularizedLogKernel n (E - x) := by
  apply Real.log_le_log
  · have h := Complex.im_le_norm
      ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I - (x : ℂ))
    have he : logRegularizationScale n ≤
        ‖(E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I - (x : ℂ)‖ := by
      simpa using h
    exact (logRegularizationScale_pos n).trans_le he
  · simpa only [Complex.sub_re, Complex.add_re, Complex.ofReal_re,
      Complex.mul_I_re, Complex.ofReal_im, neg_zero, add_zero,
      Complex.sub_im, Complex.add_im, Complex.mul_I_im, zero_add, sub_zero,
      abs_of_pos (logRegularizationScale_pos n)] using
      Complex.norm_le_abs_re_add_abs_im
        ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I - (x : ℂ))

theorem magneticComplexLogPotential_regularization_le (α lam E : ℝ) (n : ℕ) :
    magneticComplexLogPotential α lam
      ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) ≤
        magneticRegularizedLogPotential α n (lam, E) := by
  rw [magneticComplexLogPotential_eq_compactIntegral,
    magneticRegularizedLogPotential_eq_spectralIntegral]
  have hz : ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I).im ≠ 0 := by
    simpa using ne_of_gt (logRegularizationScale_pos n)
  exact integral_mono (magnetic_complexLogKernel_integrable α lam hz)
    (magnetic_regularizedLogKernel_integrable α lam E n)
    (fun x => complexLogKernel_regularization_le n E x)

/-- Both regularizations have exactly the same intrinsic EReal boundary value. -/
theorem magneticTotalLogPotential_eq_iInf_complex (α lam E : ℝ) :
    magneticTotalLogPotential α (lam, E) =
      ⨅ n : ℕ, (magneticComplexLogPotential α lam
        ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) : EReal) := by
  apply le_antisymm
  · exact le_iInf fun n => magneticTotalLogPotential_le_complexLogPotential
      α lam E _ (logRegularizationScale_pos n)
  · apply le_iInf
    intro n
    exact (iInf_le _ n).trans (EReal.coe_le_coe_iff.mpr
      (magneticComplexLogPotential_regularization_le α lam E n))

/-- The imaginary regularizations decrease as their height decreases. -/
theorem magneticComplexLogPotential_regularization_antitone (α lam E : ℝ) :
    Antitone (fun n => magneticComplexLogPotential α lam
      ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I)) := by
  intro n m hnm
  dsimp only
  rw [magneticComplexLogPotential_eq_compactIntegral,
    magneticComplexLogPotential_eq_compactIntegral]
  have hzm : ((E : ℂ) + (logRegularizationScale m : ℂ) * Complex.I).im ≠ 0 := by
    simpa using ne_of_gt (logRegularizationScale_pos m)
  have hzn : ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I).im ≠ 0 := by
    simpa using ne_of_gt (logRegularizationScale_pos n)
  apply integral_mono (magnetic_complexLogKernel_integrable α lam hzm)
    (magnetic_complexLogKernel_integrable α lam hzn)
  intro x
  apply Real.log_le_log
  · have he : logRegularizationScale m ≤
        ‖(E : ℂ) + (logRegularizationScale m : ℂ) * Complex.I - (x : ℝ)‖ := by
      simpa using Complex.im_le_norm
        ((E : ℂ) + (logRegularizationScale m : ℂ) * Complex.I - (x : ℝ))
    exact (logRegularizationScale_pos m).trans_le he
  · simp only [Complex.norm_def, Complex.normSq_apply, Complex.sub_re,
      Complex.add_re, Complex.ofReal_re, Complex.mul_I_re, Complex.ofReal_im,
      neg_zero, add_zero, Complex.sub_im, Complex.add_im,
      Complex.mul_I_im, zero_add, sub_zero]
    apply Real.sqrt_le_sqrt
    have hscale := logRegularizationScale_antitone hnm
    have hpos := logRegularizationScale_pos m
    nlinarith

theorem magneticComplexLogPotential_tendsto_total (α lam E : ℝ) :
    Tendsto (fun n : ℕ => (magneticComplexLogPotential α lam
      ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) : EReal)) atTop
        (𝓝 (magneticTotalLogPotential α (lam, E))) := by
  rw [magneticTotalLogPotential_eq_iInf_complex]
  apply tendsto_atTop_iInf
  intro n m hnm
  exact EReal.coe_le_coe_iff.mpr
    (magneticComplexLogPotential_regularization_antitone α lam E hnm)

/-- The one-dimensional statement uses its independently defined phase integral. -/
theorem amoTotalLogPotential_le_complexLogPotential
    (α lam E eta : ℝ) (heta : 0 < eta) :
    amoTotalLogPotential α (lam, E) ≤
      (amoComplexLogPotential α lam ((E : ℂ) + (eta : ℂ) * Complex.I) : EReal) := by
  rw [amoTotalLogPotential_eq_magnetic,
    amoComplexLogPotential_eq_magnetic α lam (by simpa using ne_of_gt heta)]
  exact magneticTotalLogPotential_le_complexLogPotential α lam E eta heta

theorem amoComplexLogPotential_tendsto_total (α lam E : ℝ) :
    Tendsto (fun n : ℕ => (amoComplexLogPotential α lam
      ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) : EReal)) atTop
        (𝓝 (amoTotalLogPotential α (lam, E))) := by
  have heq (n : ℕ) : amoComplexLogPotential α lam
      ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) =
        magneticComplexLogPotential α lam
          ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) :=
    amoComplexLogPotential_eq_magnetic α lam
      (by simpa using ne_of_gt (logRegularizationScale_pos n))
  simp_rw [amoTotalLogPotential_eq_magnetic, heq]
  exact magneticComplexLogPotential_tendsto_total α lam E

end CriticalDTM

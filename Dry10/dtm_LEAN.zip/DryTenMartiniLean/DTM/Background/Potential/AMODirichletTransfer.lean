import DTM.Background.Potential.JacobiDeterminant
import DTM.Background.EmpiricalIDS.AMOFiniteVolume
import DTM.Background.Transfer.AMOTransfer
import Mathlib.Analysis.CStarAlgebra.Spectrum

/-!
# The actual AMO Dirichlet determinant equals the transfer entry

The finite matrix is the physical compression on sites `0,...,n-1`, and the
transfer matrices act with later sites on the left. Their identification here
is an unconditional algebraic theorem, for every length and complex energy.
-/

noncomputable section

namespace CriticalDTM

open Matrix
open scoped Matrix.L2OpNorm

/-- The physical finite AMO pencil is the unit-bond Jacobi matrix with its
actual, unscaled potential. The phase is converted only by commutativity. -/
theorem amoFiniteMatrix_pencil_eq_jacobiMatrix (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n =
      jacobiMatrix (fun k => z - ((2 * lam * Real.cos
        (θ + 2 * Real.pi * α * (k : ℝ)) : ℝ) : ℂ)) n := by
  ext i j
  by_cases hij : i = j
  · subst j
    simp [Matrix.sub_apply, Matrix.smul_apply, jacobiMatrix, add_comm θ]
  · by_cases hplus : i.val + 1 = j.val
    · have hminus : ¬ j.val + 1 = i.val := by omega
      simp [Matrix.sub_apply, Matrix.smul_apply, Matrix.one_apply,
        amoFiniteMatrix_entry, jacobiMatrix, hij, hplus, hminus]
    · by_cases hminus : j.val + 1 = i.val
      · simp [Matrix.sub_apply, Matrix.smul_apply, Matrix.one_apply,
          amoFiniteMatrix_entry, jacobiMatrix, hij, hplus, hminus]
      · simp [Matrix.sub_apply, Matrix.smul_apply, Matrix.one_apply,
          amoFiniteMatrix_entry, jacobiMatrix, hij, hplus, hminus]

/-- The actual AMO product is the generic receiving-row product with exactly
the same order and no change of energy. -/
theorem amoTransferProduct_eq_jacobiTransferProduct
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ n =
      jacobiTransferProduct (fun k => z - ((2 * lam * Real.cos
        (θ + 2 * Real.pi * α * (k : ℝ)) : ℝ) : ℂ)) n := by
  induction n with
  | zero => rfl
  | succ n ih =>
      simp only [amoTransferProduct_succ, jacobiTransferProduct_succ, ih]
      rfl

/-- The finite physical Dirichlet determinant is the `(0,0)` transfer entry,
for all lengths (including zero) and all complex energies. -/
theorem amoFiniteMatrix_det_eq_transferProduct
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    (z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n).det =
      amoTransferProduct α lam z θ n 0 0 := by
  rw [amoFiniteMatrix_pencil_eq_jacobiMatrix, amoTransferProduct_eq_jacobiTransferProduct]
  exact jacobiMatrix_det_eq_transferProduct _ _

private theorem amoJacobiDiagonal_shift (α lam : ℝ) (z : ℂ) (θ : ℝ) (m : ℕ) :
    (fun k : ℕ => z - ((2 * lam * Real.cos
      (θ + 2 * Real.pi * α * ((k + m : ℕ) : ℝ)) : ℝ) : ℂ)) =
      (fun k : ℕ => z - ((2 * lam * Real.cos
        ((θ + 2 * Real.pi * α * (m : ℝ)) +
          2 * Real.pi * α * (k : ℝ)) : ℝ) : ℂ)) := by
  funext k
  have hphase : θ + 2 * Real.pi * α * ((k + m : ℕ) : ℝ) =
      (θ + 2 * Real.pi * α * (m : ℝ)) + 2 * Real.pi * α * (k : ℝ) := by
    push_cast
    ring
  rw [hphase]

/-- The lower-left entry deletes the last physical site. -/
theorem amoTransferProduct_entry10 (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ (n + 1) 1 0 =
      (z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n).det := by
  rw [amoTransferProduct_eq_jacobiTransferProduct, jacobiTransferProduct_entry10,
    amoFiniteMatrix_pencil_eq_jacobiMatrix]

/-- The upper-right entry deletes the first site, advancing the actual phase. -/
theorem amoTransferProduct_entry01 (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ (n + 1) 0 1 =
      -(z • (1 : Matrix (Fin n) (Fin n) ℂ) -
        amoFiniteMatrix α lam (θ + 2 * Real.pi * α) n).det := by
  rw [amoTransferProduct_eq_jacobiTransferProduct, jacobiTransferProduct_entry01,
    amoJacobiDiagonal_shift]
  simp only [Nat.cast_one, mul_one, amoFiniteMatrix_pencil_eq_jacobiMatrix]

/-- The lower-right entry deletes both physical endpoints. -/
theorem amoTransferProduct_entry11 (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ (n + 2) 1 1 =
      -(z • (1 : Matrix (Fin n) (Fin n) ℂ) -
        amoFiniteMatrix α lam (θ + 2 * Real.pi * α) n).det := by
  rw [amoTransferProduct_eq_jacobiTransferProduct, jacobiTransferProduct_entry11,
    amoJacobiDiagonal_shift]
  simp only [Nat.cast_one, mul_one, amoFiniteMatrix_pencil_eq_jacobiMatrix]

end CriticalDTM

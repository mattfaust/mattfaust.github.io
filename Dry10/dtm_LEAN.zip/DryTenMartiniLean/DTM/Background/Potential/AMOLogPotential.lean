import DTM.Background.Realization.AMOMagneticMeasureBridge
import DTM.Background.Potential.LogPotentialExtension

/-!
# The intrinsic logarithmic potential of the actual one-dimensional AMO

Each finite regularization is the normalized phase average of the actual
one-dimensional root spectral integral. The total potential is its decreasing
extended-real infimum; no possibly undefined singular Bochner integral is used.

The already-proved continuous-test identity identifies this independent
construction with the magnetic potential. No transfer-matrix Thouless formula,
spectral vanishing, or gap-opening hypothesis is assumed here.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Topology

/-- Actual phase-averaged AMO root spectral logarithm with a positive additive
regularization, including at spectral energies. -/
def amoRegularizedLogPotential (α : ℝ) (n : ℕ) (p : ℝ × ℝ) : ℝ :=
  ∫ t in (0 : ℝ)..1, ∫ x : ℝ,
    regularizedLogKernel n (p.2 - x) ∂amoRealSpectralMeasure α p.1 (2 * Real.pi * t)

/-- This is an equality between independently defined one- and two-dimensional
spectral integrals, not a definition of either in terms of the other. -/
theorem amoRegularizedLogPotential_eq_magnetic (α : ℝ) (n : ℕ) (p : ℝ × ℝ) :
    amoRegularizedLogPotential α n p = magneticRegularizedLogPotential α n p := by
  rcases p with ⟨lam, energy⟩
  rw [amoRegularizedLogPotential, magneticRegularizedLogPotential_eq_realSpectralIntegral]
  exact (magneticRealSpectralMeasure_integral_eq_phase_average α lam
    (fun x => regularizedLogKernel n (energy - x))
    ((regularizedLogKernel_continuous n).comp (continuous_const.sub continuous_id))).symm

/-- The actual AMO total potential, with `-∞` allowed, not a renamed transfer
Lyapunov exponent or a totalized real logarithmic integral. -/
def amoTotalLogPotential (α : ℝ) (p : ℝ × ℝ) : EReal :=
  ⨅ n : ℕ, (amoRegularizedLogPotential α n p : EReal)

theorem amoTotalLogPotential_eq_magnetic (α : ℝ) (p : ℝ × ℝ) :
    amoTotalLogPotential α p = magneticTotalLogPotential α p := by
  unfold amoTotalLogPotential magneticTotalLogPotential
  simp_rw [amoRegularizedLogPotential_eq_magnetic]

end CriticalDTM

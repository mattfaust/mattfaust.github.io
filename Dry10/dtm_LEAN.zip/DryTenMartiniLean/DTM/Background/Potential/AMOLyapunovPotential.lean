import DTM.Background.Potential.AMOTransferOffReal
import DTM.Background.Potential.AMODirichletTransfer
import DTM.Background.EmpiricalIDS.AMOFiniteVolumeMeasure

/-!
# The actual transfer exponent and logarithmic spectral potential

Finite Dirichlet logarithms have two independently proved limits: the actual
spectral potential, by finite-volume spectral-test convergence, and the actual
transfer Lyapunov exponent, by a uniform off-real determinant/norm comparison.
Uniqueness of limits proves equality on the upper half-plane.

The already-proved imaginary boundary limit then makes the intrinsic real
potential nonnegative. Upper semicontinuity of the actual transfer exponent
gives the required one-sided real comparison. No spectral-vanishing or
noncritical-gap hypothesis is used in any of these theorems.
-/

noncomputable section
namespace CriticalDTM

open Set Filter MeasureTheory
open scoped Topology

/-- Equality of two independently defined quantities on the upper half-plane. -/
theorem magneticComplexLogPotential_eq_amoLyapunov
    (α lam : ℝ) {z : ℂ} (hz : 0 < z.im) :
    magneticComplexLogPotential α lam z = amoLyapunov α lam z := by
  have hmeasure := tendsto_integral_amoFinite_logDet α lam (ne_of_gt hz)
  have htransfer := (tendsto_add_atTop_iff_nat 1).2
    (tendsto_amoFiniteDirichletLogAverage α lam z hz)
  have hmean (n : ℕ) : amoFiniteDirichletLogAverage α lam z (n + 1) =
      ∫ t in (0 : ℝ)..1,
        Real.log ‖Matrix.det (z • (1 : Matrix (Fin (n + 1)) (Fin (n + 1)) ℂ) -
          amoFiniteMatrix α lam (2 * Real.pi * t) (n + 1))‖ /
            ((n + 1 : ℕ) : ℝ) := by
    rw [amoFiniteDirichletLogAverage_eq_unit_interval]
    simp_rw [← amoFiniteMatrix_det_eq_transferProduct]
    rw [intervalIntegral.integral_div]
  simp_rw [hmean] at htransfer
  exact tendsto_nhds_unique hmeasure htransfer

theorem amoComplexLogPotential_eq_amoLyapunov
    (α lam : ℝ) {z : ℂ} (hz : 0 < z.im) :
    amoComplexLogPotential α lam z = amoLyapunov α lam z := by
  rw [amoComplexLogPotential_eq_magnetic α lam (ne_of_gt hz)]
  exact magneticComplexLogPotential_eq_amoLyapunov α lam hz

/-- Nonnegativity of the intrinsic potential follows from determinant-one
transfer products and the proved imaginary boundary limit, not a spectral input. -/
theorem amoTotalLogPotential_nonneg (α lam E : ℝ) :
    0 ≤ amoTotalLogPotential α (lam, E) := by
  apply ge_of_tendsto' (amoComplexLogPotential_tendsto_total α lam E)
  intro n
  rw [amoComplexLogPotential_eq_amoLyapunov α lam
    (by simpa using logRegularizationScale_pos n)]
  exact EReal.coe_le_coe_iff.mpr (amoLyapunov_nonneg α lam _)

/-- The real spectral potential is bounded above by the actual transfer
Lyapunov exponent, including at spectral energies. -/
theorem amoTotalLogPotential_le_amoLyapunov (α lam E : ℝ) :
    amoTotalLogPotential α (lam, E) ≤ (amoLyapunov α lam (E : ℂ) : EReal) := by
  by_contra h
  obtain ⟨c, hc, hcU⟩ := EReal.lt_iff_exists_real_btwn.mp (lt_of_not_ge h)
  have hc' : amoLyapunov α lam (E : ℂ) < c := EReal.coe_lt_coe_iff.mp hc
  have hzlim : Tendsto (fun n : ℕ =>
      (E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I) atTop (𝓝 (E : ℂ)) := by
    have hscale := Complex.continuous_ofReal.continuousAt.tendsto.comp
      logRegularizationScale_tendsto
    simpa using tendsto_const_nhds.add (hscale.mul_const Complex.I)
  have hlim : Tendsto (fun n : ℕ =>
      (α, lam, (E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I)) atTop
        (𝓝 (α, lam, (E : ℂ))) :=
    tendsto_const_nhds.prodMk_nhds (tendsto_const_nhds.prodMk_nhds hzlim)
  obtain ⟨n, hn⟩ := (hlim.eventually
    (amoLyapunov_upperSemicontinuous (α, lam, (E : ℂ)) c hc')).exists
  have hupper := amoTotalLogPotential_le_complexLogPotential α lam E
    (logRegularizationScale n) (logRegularizationScale_pos n)
  rw [amoComplexLogPotential_eq_amoLyapunov α lam
    (by simpa using logRegularizationScale_pos n)] at hupper
  have hlt := EReal.coe_lt_coe_iff.mpr hn
  exact (lt_irrefl _) ((hupper.trans_lt hlt).trans hcU)

/-- This implication compares the independently defined potential and exponent;
the Thouless formula is not a supplied premise. The spectral Lyapunov-zero theorem itself is separate. -/
theorem amoTotalLogPotential_eq_zero_of_lyapunov_eq_zero
    (α lam E : ℝ) (hL : amoLyapunov α lam (E : ℂ) = 0) :
    amoTotalLogPotential α (lam, E) = 0 := by
  apply le_antisymm _ (amoTotalLogPotential_nonneg α lam E)
  simpa only [hL, EReal.coe_zero] using amoTotalLogPotential_le_amoLyapunov α lam E

theorem magneticTotalLogPotential_nonneg (α lam E : ℝ) :
    0 ≤ magneticTotalLogPotential α (lam, E) := by
  rw [← amoTotalLogPotential_eq_magnetic]
  exact amoTotalLogPotential_nonneg α lam E

end CriticalDTM

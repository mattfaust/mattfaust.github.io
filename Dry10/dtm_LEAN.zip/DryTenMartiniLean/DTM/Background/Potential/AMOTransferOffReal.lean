import DTM.Background.Transfer.AMOLyapunov
import DTM.Background.Potential.JacobiOffReal

/-!
# Off-real comparison of actual transfer norms and Dirichlet determinants

The diagonal is literally `z - 2λ cos(θ + 2παj)`. The checked Jacobi
continuant identities and upper-half-plane quotient estimates control all
four transfer entries. Consequently the logarithm of the Euclidean operator
norm differs from the logarithm of the Dirichlet determinant by a uniform
constant, independent of phase and chain length. After phase averaging and
dividing by the length, the finite Dirichlet logarithms converge to the
independently defined transfer Lyapunov exponent.
-/

noncomputable section

open Filter MeasureTheory Set
open scoped Topology

namespace CriticalDTM

/-- Identification with the generic Jacobi transfer product at the literal
almost Mathieu diagonal, including its physical radian phase. -/
private theorem amoTransferProduct_eq_jacobiTransferProduct
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ n = jacobiTransferProduct
      (fun j => z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ)) n := by
  induction n with
  | zero => simp
  | succ n ih =>
      simp only [amoTransferProduct_succ, jacobiTransferProduct_succ, ih,
        amoTransfer, jacobiTransfer]

/-- The leading transfer entry is the actual finite tridiagonal determinant. -/
theorem amoTransferProduct_entry00_eq_jacobiMatrix_det
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ n 0 0 =
      (jacobiMatrix
        (fun j => z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ)) n).det := by
  rw [amoTransferProduct_eq_jacobiTransferProduct, jacobiMatrix_det_eq_transferProduct]

/-- No finite Dirichlet determinant vanishes in the upper half-plane. -/
theorem amoTransferProduct_entry00_ne_zero_of_im_pos
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (hz : 0 < z.im) (n : ℕ) :
    amoTransferProduct α lam z θ (n + 1) 0 0 ≠ 0 := by
  rw [amoTransferProduct_entry00_eq_jacobiMatrix_det]
  exact (jacobiMatrix_det_tail_ratio _ hz (by intro j; simp only [Complex.sub_im, Complex.ofReal_im, sub_zero, le_refl]) n).1

theorem amoTransferProduct_entry10_norm_le_of_im_pos
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (hz : 0 < z.im) (n : ℕ) :
    ‖amoTransferProduct α lam z θ (n + 1) 1 0‖ ≤
      z.im⁻¹ * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ := by
  have h : ‖amoTransferProduct α lam z θ (n + 1) 1 0 /
      amoTransferProduct α lam z θ (n + 1) 0 0‖ ≤ z.im⁻¹ := by
    simpa only [amoTransferProduct_eq_jacobiTransferProduct,
      jacobiTransferProduct_entry10, ← jacobiMatrix_det_eq_transferProduct] using
      jacobiMatrix_det_prefix_ratio
        (fun j => z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ))
        hz (by intro j; simp only [Complex.sub_im, Complex.ofReal_im, sub_zero, le_refl]) n
  rw [norm_div] at h
  exact (div_le_iff₀ (norm_pos_iff.mpr
    (amoTransferProduct_entry00_ne_zero_of_im_pos α lam z θ hz n))).mp h

theorem amoTransferProduct_entry01_norm_le_of_im_pos
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (hz : 0 < z.im) (n : ℕ) :
    ‖amoTransferProduct α lam z θ (n + 1) 0 1‖ ≤
      z.im⁻¹ * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ := by
  have h : ‖amoTransferProduct α lam z θ (n + 1) 0 1 /
      amoTransferProduct α lam z θ (n + 1) 0 0‖ ≤ z.im⁻¹ := by
    simpa only [amoTransferProduct_eq_jacobiTransferProduct,
      jacobiTransferProduct_entry01, ← jacobiMatrix_det_eq_transferProduct,
      neg_div, norm_neg] using
      (jacobiMatrix_det_tail_ratio
        (fun j => z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ))
        hz (by intro j; simp only [Complex.sub_im, Complex.ofReal_im, sub_zero, le_refl]) n).2.2
  rw [norm_div] at h
  exact (div_le_iff₀ (norm_pos_iff.mpr
    (amoTransferProduct_entry00_ne_zero_of_im_pos α lam z θ hz n))).mp h

theorem amoTransferProduct_entry11_norm_le_of_im_pos
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (hz : 0 < z.im) (n : ℕ) :
    ‖amoTransferProduct α lam z θ (n + 1) 1 1‖ ≤
      (z.im⁻¹ * z.im⁻¹) * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ := by
  cases n with
  | zero =>
      have hzero : amoTransferProduct α lam z θ 1 1 1 = 0 := by
        simp [amoTransferProduct, amoTransfer]
      rw [hzero, norm_zero]
      positivity
  | succ n =>
      have h : ‖amoTransferProduct α lam z θ (n + 2) 1 1 /
          amoTransferProduct α lam z θ (n + 2) 0 0‖ ≤ z.im⁻¹ * z.im⁻¹ := by
        simpa only [amoTransferProduct_eq_jacobiTransferProduct,
          jacobiTransferProduct_entry11, ← jacobiMatrix_det_eq_transferProduct,
          neg_div, norm_neg] using
          jacobiMatrix_det_interior_ratio
            (fun j => z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (j : ℝ)) : ℝ) : ℂ))
            hz (by intro j; simp only [Complex.sub_im, Complex.ofReal_im, sub_zero, le_refl]) n
      rw [norm_div] at h
      exact (div_le_iff₀ (norm_pos_iff.mpr
        (amoTransferProduct_entry00_ne_zero_of_im_pos α lam z θ hz (n + 1)))).mp h

/-- Uniform comparison of the true Euclidean transfer norm with its Dirichlet
entry, at every positive length and phase. -/
theorem amoTransferProduct_norm_le_entry00_of_im_pos
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (hz : 0 < z.im) (n : ℕ) :
    amoTransferNorm (amoTransferProduct α lam z θ (n + 1)) ≤
      (1 + z.im⁻¹) ^ 2 * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ := by
  have h01 := amoTransferProduct_entry01_norm_le_of_im_pos α lam z θ hz n
  have h10 := amoTransferProduct_entry10_norm_le_of_im_pos α lam z θ hz n
  have h11 := amoTransferProduct_entry11_norm_le_of_im_pos α lam z θ hz n
  calc
    amoTransferNorm (amoTransferProduct α lam z θ (n + 1)) ≤
        ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ +
        ‖amoTransferProduct α lam z θ (n + 1) 0 1‖ +
        ‖amoTransferProduct α lam z θ (n + 1) 1 0‖ +
        ‖amoTransferProduct α lam z θ (n + 1) 1 1‖ :=
      amoTransferNorm_le_four_entries _
    _ ≤ ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ +
        z.im⁻¹ * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ +
        z.im⁻¹ * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ +
        (z.im⁻¹ * z.im⁻¹) * ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ :=
      add_le_add (add_le_add (add_le_add le_rfl h01) h10) h11
    _ = _ := by ring

/-- The unnormalized logarithmic error is bounded independently of phase and length. -/
theorem amoTransferLogNorm_sub_log_entry00_bounds
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (hz : 0 < z.im) (n : ℕ) :
    0 ≤ amoTransferLogNorm α lam z θ (n + 1) -
      Real.log ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ ∧
    amoTransferLogNorm α lam z θ (n + 1) -
      Real.log ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ ≤
        2 * Real.log (1 + z.im⁻¹) := by
  have hentry : 0 < ‖amoTransferProduct α lam z θ (n + 1) 0 0‖ :=
    norm_pos_iff.mpr (amoTransferProduct_entry00_ne_zero_of_im_pos α lam z θ hz n)
  have hc : 0 < 1 + z.im⁻¹ := by positivity
  unfold amoTransferLogNorm
  constructor
  · exact sub_nonneg.mpr (Real.log_le_log hentry (norm_entry_le_amoTransferNorm _ 0 0))
  · have h := Real.log_le_log (amoTransferProduct_norm_pos α lam z θ (n + 1))
      (amoTransferProduct_norm_le_entry00_of_im_pos α lam z θ hz n)
    rw [Real.log_mul (pow_ne_zero 2 hc.ne') hentry.ne', Real.log_pow] at h
    linarith

/-- The normalized phase logarithm of the actual finite Dirichlet determinant.
The estimates below are on the upper half-plane, where its nonvanishing and
integrability are proved rather than relying on the totalized value of `log 0`. -/
def amoFiniteDirichletLogAverage (α lam : ℝ) (z : ℂ) (n : ℕ) : ℝ :=
  ((∫ θ in (0 : ℝ)..(2 * Real.pi),
    Real.log ‖amoTransferProduct α lam z θ n 0 0‖) / (2 * Real.pi)) / (n : ℝ)

/-- The same finite mean on the normalized phase interval used by the IDS. -/
theorem amoFiniteDirichletLogAverage_eq_unit_interval
    (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoFiniteDirichletLogAverage α lam z n =
      (∫ t in (0 : ℝ)..1,
        Real.log ‖amoTransferProduct α lam z (2 * Real.pi * t) n 0 0‖) / (n : ℝ) := by
  have h := intervalIntegral.integral_comp_mul_left
    (a := 0) (b := 1) (c := 2 * Real.pi)
    (fun θ => Real.log ‖amoTransferProduct α lam z θ n 0 0‖) (by positivity)
  have heq : (∫ t in (0 : ℝ)..1,
      Real.log ‖amoTransferProduct α lam z (2 * Real.pi * t) n 0 0‖) =
      (∫ θ in (0 : ℝ)..(2 * Real.pi),
        Real.log ‖amoTransferProduct α lam z θ n 0 0‖) / (2 * Real.pi) := by
    simpa only [mul_zero, zero_mul, mul_one, one_mul, smul_eq_mul, div_eq_mul_inv, mul_comm] using h
  exact congrArg (fun x => x / (n : ℝ)) heq.symm

theorem continuous_amoTransferLogEntry00_phase_of_im_pos
    (α lam : ℝ) (z : ℂ) (hz : 0 < z.im) (n : ℕ) :
    Continuous (fun θ => Real.log ‖amoTransferProduct α lam z θ (n + 1) 0 0‖) := by
  have hp : Continuous (fun θ => amoTransferProduct α lam z θ (n + 1)) := by
    have h := (continuous_amoTransferProduct (n + 1)).comp
      (show Continuous (fun θ : ℝ => (α, lam, z, θ)) by fun_prop)
    exact h
  exact ((hp.matrix_elem 0 0).norm).log (fun θ => norm_ne_zero_iff.mpr
    (amoTransferProduct_entry00_ne_zero_of_im_pos α lam z θ hz n))

/-- The actual phase-averaged logarithmic error is at most a fixed constant
 divided by the positive chain length. -/
theorem amoFiniteLyapunov_sub_dirichlet_bounds
    (α lam : ℝ) (z : ℂ) (hz : 0 < z.im) (n : ℕ) :
    0 ≤ amoFiniteLyapunov α lam z (n + 1) - amoFiniteDirichletLogAverage α lam z (n + 1) ∧
    amoFiniteLyapunov α lam z (n + 1) - amoFiniteDirichletLogAverage α lam z (n + 1) ≤
      (2 * Real.log (1 + z.im⁻¹)) / ((n + 1 : ℕ) : ℝ) := by
  have hperiod : 0 < 2 * Real.pi := by positivity
  have hnorm := amoTransferLogNorm_intervalIntegrable α lam z (n + 1) 0 (2 * Real.pi)
  have hentry : IntervalIntegrable
      (fun θ => Real.log ‖amoTransferProduct α lam z θ (n + 1) 0 0‖) volume 0 (2 * Real.pi) :=
    (continuous_amoTransferLogEntry00_phase_of_im_pos α lam z hz n).intervalIntegrable
      0 (2 * Real.pi)
  have heq : amoFiniteLyapunov α lam z (n + 1) -
      amoFiniteDirichletLogAverage α lam z (n + 1) =
      ((∫ θ in (0 : ℝ)..(2 * Real.pi),
        (amoTransferLogNorm α lam z θ (n + 1) -
          Real.log ‖amoTransferProduct α lam z θ (n + 1) 0 0‖)) / (2 * Real.pi)) /
        ((n + 1 : ℕ) : ℝ) := by
    unfold amoFiniteLyapunov amoTransferLogAverage amoFiniteDirichletLogAverage
    rw [← sub_div, ← sub_div, ← intervalIntegral.integral_sub hnorm hentry]
  rw [heq]
  constructor
  · apply div_nonneg (div_nonneg _ hperiod.le) (Nat.cast_nonneg _)
    exact intervalIntegral.integral_nonneg hperiod.le
      (fun θ _ => (amoTransferLogNorm_sub_log_entry00_bounds α lam z θ hz n).1)
  · have hi := intervalIntegral.integral_mono hperiod.le (hnorm.sub hentry)
      (continuous_const.intervalIntegrable 0 (2 * Real.pi))
      (fun θ => (amoTransferLogNorm_sub_log_entry00_bounds α lam z θ hz n).2)
    simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hi
    have havg : (∫ θ in (0 : ℝ)..(2 * Real.pi),
        (amoTransferLogNorm α lam z θ (n + 1) -
          Real.log ‖amoTransferProduct α lam z θ (n + 1) 0 0‖)) / (2 * Real.pi) ≤
        2 * Real.log (1 + z.im⁻¹) := by
      apply (div_le_iff₀ hperiod).mpr
      simpa only [mul_comm] using hi
    exact div_le_div_of_nonneg_right havg (Nat.cast_nonneg _)

/-- The finite Dirichlet phase logarithms converge to the genuine transfer LE.
This theorem uses only the actual finite matrices and upper-half-plane algebra;
identifying the limit with the infinite DOS potential remains a separate step. -/
theorem tendsto_amoFiniteDirichletLogAverage
    (α lam : ℝ) (z : ℂ) (hz : 0 < z.im) :
    Tendsto (amoFiniteDirichletLogAverage α lam z) atTop (𝓝 (amoLyapunov α lam z)) := by
  have herr : Tendsto (fun n : ℕ => amoFiniteLyapunov α lam z (n + 1) -
      amoFiniteDirichletLogAverage α lam z (n + 1)) atTop (𝓝 0) := by
    apply squeeze_zero (fun n => (amoFiniteLyapunov_sub_dirichlet_bounds α lam z hz n).1)
      (fun n => (amoFiniteLyapunov_sub_dirichlet_bounds α lam z hz n).2)
    exact (tendsto_const_div_atTop_nhds_zero_nat (2 * Real.log (1 + z.im⁻¹))).comp
      (tendsto_add_atTop_nat 1)
  have h := ((tendsto_amoFiniteLyapunov α lam z).comp (tendsto_add_atTop_nat 1)).sub herr
  have hd : Tendsto (fun n : ℕ => amoFiniteDirichletLogAverage α lam z (n + 1))
      atTop (𝓝 (amoLyapunov α lam z)) := by
    simpa only [Function.comp_def, sub_sub_cancel, sub_zero] using h
  exact (tendsto_add_atTop_iff_nat 1).mp hd

end CriticalDTM

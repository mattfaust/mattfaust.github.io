import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Ring

/-!
# Dirichlet Jacobi determinants and actual transfer products

The tridiagonal matrix has diagonal `d 0, ..., d (n-1)` and both adjacent
entries equal to `-1`. Two Laplace expansions prove its continuant recurrence
for every length, including the empty determinant. The recurrence then
identifies the determinant with the `(0,0)` entry of the ordered product of
`!![d k, -1; 1, 0]`. No spectral or nonvanishing assumption is used.
-/

noncomputable section

namespace CriticalDTM

open Matrix

variable {R : Type*} [CommRing R]

/-- The unit-bond Dirichlet Jacobi pencil with prescribed diagonal. -/
def jacobiMatrix (d : ℕ → R) (n : ℕ) : Matrix (Fin n) (Fin n) R :=
  fun i j => if i = j then d i.val
    else if i.val + 1 = j.val ∨ j.val + 1 = i.val then -1 else 0

@[simp] theorem jacobiMatrix_diagonal (d : ℕ → R) (n : ℕ) (i : Fin n) :
    jacobiMatrix d n i i = d i.val := by
  simp [jacobiMatrix]

@[simp] theorem jacobiMatrix_zero_one (d : ℕ → R) (n : ℕ) :
    jacobiMatrix d (n + 2) 0 1 = -1 := by
  simp [jacobiMatrix]

@[simp] theorem jacobiMatrix_one_zero (d : ℕ → R) (n : ℕ) :
    jacobiMatrix d (n + 2) 1 0 = -1 := by
  simp [jacobiMatrix]

@[simp] theorem jacobiMatrix_zero_succ_succ (d : ℕ → R) (n : ℕ) (j : Fin n) :
    jacobiMatrix d (n + 2) 0 j.succ.succ = 0 := by
  simp [jacobiMatrix, Fin.ext_iff]

@[simp] theorem jacobiMatrix_succ_succ_zero (d : ℕ → R) (n : ℕ) (i : Fin n) :
    jacobiMatrix d (n + 2) i.succ.succ 0 = 0 := by
  simp [jacobiMatrix, Fin.ext_iff]

@[simp] theorem jacobiMatrix_succ_succ (d : ℕ → R) (n : ℕ) (i j : Fin n) :
    jacobiMatrix d (n + 1) i.succ j.succ =
      jacobiMatrix (fun k => d (k + 1)) n i j := by
  simp [jacobiMatrix, Fin.ext_iff]

/-- Deleting the first row and column shifts the physical diagonal by one. -/
theorem jacobiMatrix_tail (d : ℕ → R) (n : ℕ) :
    (jacobiMatrix d (n + 1)).submatrix Fin.succ Fin.succ =
      jacobiMatrix (fun k => d (k + 1)) n := by
  ext i j
  exact jacobiMatrix_succ_succ d n i j

/-- The off-diagonal first-row cofactor is minus the determinant two sites in. -/
private theorem jacobiMatrix_first_cofactor (d : ℕ → R) (n : ℕ) :
    ((jacobiMatrix d (n + 2)).submatrix Fin.succ
      (1 : Fin (n + 2)).succAbove).det =
      -(jacobiMatrix (fun k => d (k + 2)) n).det := by
  rw [Matrix.det_succ_column_zero, Fin.sum_univ_succ]
  simp only [Fin.val_zero, pow_zero, one_mul, Matrix.submatrix_apply,
    Fin.one_succAbove_zero, Fin.succ_zero_eq_one, jacobiMatrix_one_zero,
    Fin.zero_succAbove, Fin.val_succ, jacobiMatrix_succ_succ_zero,
    mul_zero, zero_mul, Finset.sum_const_zero, add_zero, neg_one_mul]
  congr 1
  congr 1
  ext i j
  simp [Matrix.submatrix_apply, jacobiMatrix_succ_succ, Nat.add_assoc]

/-- The all-length continuant identity, proved from the actual determinant. -/
theorem jacobiMatrix_det_recurrence (d : ℕ → R) (n : ℕ) :
    (jacobiMatrix d (n + 2)).det =
      d 0 * (jacobiMatrix (fun k => d (k + 1)) (n + 1)).det -
        (jacobiMatrix (fun k => d (k + 2)) n).det := by
  rw [Matrix.det_succ_row_zero, Fin.sum_univ_succ, Fin.sum_univ_succ]
  simp only [Fin.val_zero, pow_zero, one_mul, jacobiMatrix_diagonal,
    Fin.succAbove_zero, Fin.succ_zero_eq_one, Fin.val_one, pow_one,
    jacobiMatrix_zero_one, neg_mul_neg, one_mul, Fin.val_succ,
    jacobiMatrix_zero_succ_succ, mul_zero, zero_mul, Finset.sum_const_zero,
    add_zero, jacobiMatrix_tail, jacobiMatrix_first_cofactor, sub_eq_add_neg]

/-- The scalar recurrence's one-site transfer, with the physical state ordering. -/
def jacobiTransfer (a : R) : Matrix (Fin 2) (Fin 2) R := !![a, -1; 1, 0]

/-- Later sites multiply on the left; the empty product is the identity. -/
def jacobiTransferProduct (d : ℕ → R) : ℕ → Matrix (Fin 2) (Fin 2) R
  | 0 => 1
  | n + 1 => jacobiTransfer (d n) * jacobiTransferProduct d n

@[simp] theorem jacobiTransferProduct_zero (d : ℕ → R) :
    jacobiTransferProduct d 0 = 1 := rfl

@[simp] theorem jacobiTransferProduct_succ (d : ℕ → R) (n : ℕ) :
    jacobiTransferProduct d (n + 1) =
      jacobiTransfer (d n) * jacobiTransferProduct d n := rfl

/-- Split off the earliest site on the right, retaining the product order. -/
theorem jacobiTransferProduct_tail (d : ℕ → R) (n : ℕ) :
    jacobiTransferProduct d (n + 1) =
      jacobiTransferProduct (fun k => d (k + 1)) n * jacobiTransfer (d 0) := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [jacobiTransferProduct_succ, ih, jacobiTransferProduct_succ, mul_assoc]

/-- The transfer entry obeys the same tail continuant recurrence. -/
theorem jacobiTransferProduct_entry_recurrence (d : ℕ → R) (n : ℕ) :
    jacobiTransferProduct d (n + 2) 0 0 =
      d 0 * jacobiTransferProduct (fun k => d (k + 1)) (n + 1) 0 0 -
        jacobiTransferProduct (fun k => d (k + 2)) n 0 0 := by
  rw [jacobiTransferProduct_tail d (n + 1)]
  simp only [Matrix.mul_apply, Fin.sum_univ_two, jacobiTransfer,
    Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    mul_one]
  rw [jacobiTransferProduct_tail (fun k => d (k + 1)) n]
  simp only [Matrix.mul_apply, Fin.sum_univ_two, jacobiTransfer,
    Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    mul_neg_one, mul_zero, add_zero, Nat.add_assoc]
  ring

/-- The determinant is the `(0,0)` entry of the actual all-site transfer product. -/
theorem jacobiMatrix_det_eq_transferProduct (d : ℕ → R) (n : ℕ) :
    (jacobiMatrix d n).det = jacobiTransferProduct d n 0 0 := by
  induction n using Nat.twoStepInduction generalizing d with
  | zero => simp
  | one => simp [jacobiTransferProduct, jacobiTransfer]
  | more n ih₀ ih₁ =>
      rw [jacobiMatrix_det_recurrence, jacobiTransferProduct_entry_recurrence,
        ih₀, ih₁]

/-- The lower-left entry is the determinant with the last site removed. -/
theorem jacobiTransferProduct_entry10 (d : ℕ → R) (n : ℕ) :
    jacobiTransferProduct d (n + 1) 1 0 = (jacobiMatrix d n).det := by
  rw [jacobiTransferProduct_succ]
  simpa [Matrix.mul_apply, Fin.sum_univ_two, jacobiTransfer] using
    (jacobiMatrix_det_eq_transferProduct d n).symm

/-- The upper-right entry is minus the determinant with the first site removed. -/
theorem jacobiTransferProduct_entry01 (d : ℕ → R) (n : ℕ) :
    jacobiTransferProduct d (n + 1) 0 1 =
      -(jacobiMatrix (fun k => d (k + 1)) n).det := by
  rw [jacobiTransferProduct_tail]
  simp [Matrix.mul_apply, Fin.sum_univ_two, jacobiTransfer,
    jacobiMatrix_det_eq_transferProduct]

/-- For at least two sites, the lower-right entry deletes both endpoints. -/
theorem jacobiTransferProduct_entry11 (d : ℕ → R) (n : ℕ) :
    jacobiTransferProduct d (n + 2) 1 1 =
      -(jacobiMatrix (fun k => d (k + 1)) n).det := by
  rw [jacobiTransferProduct_succ]
  simpa only [Matrix.mul_apply, Fin.sum_univ_two, jacobiTransfer,
    Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    one_mul, zero_mul, add_zero] using jacobiTransferProduct_entry01 d n

end CriticalDTM

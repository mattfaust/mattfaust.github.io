import DTM.Background.Potential.JacobiDeterminant
import Mathlib.Analysis.Complex.Basic
import Mathlib.Data.Fin.Rev
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-!
# Uniform off-real bounds on finite Jacobi determinant ratios

The scalar inverse map preserves the lower half-plane when the diagonal has
positive imaginary part. Applying the exact continuant recurrence proves
nonvanishing and a uniform bound on endpoint determinant ratios, for every
chain length. These are finite algebraic estimates, not a spectral assumption.
-/

noncomputable section
namespace CriticalDTM

open Matrix

theorem complex_inv_bounds_of_im_lower {z : ℂ} {eta : ℝ}
    (heta : 0 < eta) (hz : eta ≤ z.im) :
    z ≠ 0 ∧ z⁻¹.im ≤ 0 ∧ ‖z⁻¹‖ ≤ eta⁻¹ := by
  have hne : z ≠ 0 := by
    intro h
    rw [h, Complex.zero_im] at hz
    linarith
  refine ⟨hne, ?_, ?_⟩
  · rw [Complex.inv_im]
    exact div_nonpos_of_nonpos_of_nonneg (by linarith) (Complex.normSq_nonneg z)
  · rw [norm_inv]
    have hnorm : eta ≤ ‖z‖ := hz.trans (Complex.im_le_norm z)
    simpa only [one_div] using one_div_le_one_div_of_le heta hnorm

/-- Reversing both finite coordinates preserves the actual Jacobi determinant. -/
theorem jacobiMatrix_det_reverse {R : Type*} [CommRing R]
    (d : ℕ → R) (n : ℕ) :
    (jacobiMatrix (fun j => d (n - 1 - j)) n).det = (jacobiMatrix d n).det := by
  have hmat : jacobiMatrix (fun j => d (n - 1 - j)) n =
      (jacobiMatrix d n).submatrix Fin.revPerm Fin.revPerm := by
    ext i j
    have hi := i.isLt
    have hj := j.isLt
    simp only [jacobiMatrix, Matrix.submatrix_apply, Fin.revPerm_apply,
      Fin.rev_inj, Fin.val_rev]
    have hrev : n - 1 - i.val = n - (i.val + 1) := by omega
    have hadj : i.val + 1 = j.val ∨ j.val + 1 = i.val ↔
        (n - (i.val + 1)) + 1 = n - (j.val + 1) ∨
          (n - (j.val + 1)) + 1 = n - (i.val + 1) := by omega
    simp only [hrev, hadj]
  rw [hmat, Matrix.det_submatrix_equiv_self]

/-- The quotient of the tail determinant by the full determinant is a genuine
lower-half-plane resolvent entry and has norm at most `1 / eta`. -/
theorem jacobiMatrix_det_tail_ratio (d : ℕ → ℂ) {eta : ℝ}
    (heta : 0 < eta) (hd : ∀ j, eta ≤ (d j).im) (n : ℕ) :
    (jacobiMatrix d (n + 1)).det ≠ 0 ∧
      ((jacobiMatrix (fun j => d (j + 1)) n).det /
        (jacobiMatrix d (n + 1)).det).im ≤ 0 ∧
      ‖(jacobiMatrix (fun j => d (j + 1)) n).det /
        (jacobiMatrix d (n + 1)).det‖ ≤ eta⁻¹ := by
  induction n generalizing d with
  | zero =>
      simpa [jacobiMatrix, Matrix.det_fin_one] using
        complex_inv_bounds_of_im_lower heta (hd 0)
  | succ n ih =>
      have hp := ih (fun j => d (j + 1)) (fun j => hd (j + 1))
      let t : ℂ := (jacobiMatrix (fun j => d (j + 1)) (n + 1)).det
      let b : ℂ := (jacobiMatrix (fun j => d (j + 2)) n).det
      have ht : t ≠ 0 := hp.1
      have hb : (b / t).im ≤ 0 := by
        simpa only [Nat.add_assoc] using hp.2.1
      let w : ℂ := d 0 - b / t
      have hw : eta ≤ w.im := by
        dsimp only [w]
        rw [Complex.sub_im]
        linarith [hd 0]
      have hw' := complex_inv_bounds_of_im_lower heta hw
      have hdet : (jacobiMatrix d (n + 1 + 1)).det = w * t := by
        rw [jacobiMatrix_det_recurrence]
        change d 0 * t - b = (d 0 - b / t) * t
        rw [sub_mul, div_mul_cancel₀ _ ht]
      have hratio : t / (jacobiMatrix d (n + 1 + 1)).det = w⁻¹ := by
        rw [hdet]
        field_simp [ht, hw'.1]
        ring
      refine ⟨by rw [hdet]; exact mul_ne_zero hw'.1 ht, ?_, ?_⟩
      · change (t / (jacobiMatrix d (n + 1 + 1)).det).im ≤ 0
        rw [hratio]
        exact hw'.2.1
      · change ‖t / (jacobiMatrix d (n + 1 + 1)).det‖ ≤ eta⁻¹
        rw [hratio]
        exact hw'.2.2

/-- The quotient with the last site deleted obeys the same uniform bound. -/
theorem jacobiMatrix_det_prefix_ratio (d : ℕ → ℂ) {eta : ℝ}
    (heta : 0 < eta) (hd : ∀ j, eta ≤ (d j).im) (n : ℕ) :
    ‖(jacobiMatrix d n).det / (jacobiMatrix d (n + 1)).det‖ ≤ eta⁻¹ := by
  have h := (jacobiMatrix_det_tail_ratio
    (fun j => d ((n + 1) - 1 - j)) heta (fun j => hd _) n).2.2
  rw [jacobiMatrix_det_reverse] at h
  have heq : (fun j => d ((n + 1) - 1 - (j + 1))) =
      (fun j => d (n - 1 - j)) := by
    funext j
    congr 1
    omega
  rw [heq, jacobiMatrix_det_reverse] at h
  exact h

/-- Deleting both endpoints costs at most two endpoint bounds. -/
theorem jacobiMatrix_det_interior_ratio (d : ℕ → ℂ) {eta : ℝ}
    (heta : 0 < eta) (hd : ∀ j, eta ≤ (d j).im) (n : ℕ) :
    ‖(jacobiMatrix (fun j => d (j + 1)) n).det /
      (jacobiMatrix d (n + 2)).det‖ ≤ eta⁻¹ * eta⁻¹ := by
  have hprefix := jacobiMatrix_det_prefix_ratio d heta hd (n + 1)
  have htail := jacobiMatrix_det_tail_ratio d heta hd n
  have hfactor : (jacobiMatrix (fun j => d (j + 1)) n).det /
      (jacobiMatrix d (n + 2)).det =
      ((jacobiMatrix (fun j => d (j + 1)) n).det / (jacobiMatrix d (n + 1)).det) *
        ((jacobiMatrix d (n + 1)).det / (jacobiMatrix d (n + 2)).det) := by
    field_simp [htail.1, (jacobiMatrix_det_tail_ratio d heta hd (n + 1)).1]
  rw [hfactor, norm_mul]
  exact mul_le_mul htail.2.2 hprefix (norm_nonneg _) (by positivity)

end CriticalDTM

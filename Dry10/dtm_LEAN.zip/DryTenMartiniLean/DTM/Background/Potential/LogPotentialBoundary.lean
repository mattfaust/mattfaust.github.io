import DTM.Background.Potential.LogPotentialExtension
import DTM.Background.Labels.MagneticLabelUniqueness
import Mathlib.Analysis.Convex.SpecificFunctions.Basic

/-!
# Consequences of intrinsic spectral vanishing

This module does not prove that the almost-Mathieu spectral potential vanishes.
It proves the elementary consequences of that single, explicitly stated
property for the actual probability measure: nonnegativity, energy continuity,
and exact agreement of the real positive envelope with the resolvent potential.

The key observation is that `log (|E-x| + ε)` is concave in `E` on every
interval whose interior excludes the spectral point `x`. Thus zero total
potential at both gap endpoints forces every regularized gap potential to be
nonnegative. Monotonicity of distance handles the two exterior components.
No additional lower-bound or continuity hypothesis is imposed.
-/

noncomputable section

namespace CriticalDTM

open Set Filter MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

/-- On one side of the source point, distance is affine, so adding a positive
regularization scale preserves the concavity of the logarithm. -/
theorem regularizedLogKernel_concaveOn_interval (n : ℕ) {a b x : ℝ}
    (hx : x ≤ a ∨ b ≤ x) :
    ConcaveOn ℝ (Icc a b) (fun E => regularizedLogKernel n (E - x)) := by
  refine ⟨convex_Icc a b, ?_⟩
  intro u hu v hv r s hr hs hrs
  have hw : r * u + s * v ∈ Icc a b := by
    simpa only [smul_eq_mul] using (convex_Icc a b) hu hv hr hs hrs
  have hdist : |r * u + s * v - x| + logRegularizationScale n =
      r * (|u - x| + logRegularizationScale n) +
        s * (|v - x| + logRegularizationScale n) := by
    rcases hx with hx | hx
    · rw [abs_of_nonneg (sub_nonneg.mpr (hx.trans hw.1)),
        abs_of_nonneg (sub_nonneg.mpr (hx.trans hu.1)),
        abs_of_nonneg (sub_nonneg.mpr (hx.trans hv.1))]
      nlinarith [congrArg (fun t : ℝ => t * x) hrs,
        congrArg (fun t : ℝ => t * logRegularizationScale n) hrs]
    · rw [abs_of_nonpos (sub_nonpos.mpr (hw.2.trans hx)),
        abs_of_nonpos (sub_nonpos.mpr (hu.2.trans hx)),
        abs_of_nonpos (sub_nonpos.mpr (hv.2.trans hx))]
      nlinarith [congrArg (fun t : ℝ => t * x) hrs,
        congrArg (fun t : ℝ => t * logRegularizationScale n) hrs]
  have hlog := strictConcaveOn_log_Ioi.concaveOn.2
    (show |u - x| + logRegularizationScale n ∈ Ioi (0 : ℝ) from
      add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n))
    (show |v - x| + logRegularizationScale n ∈ Ioi (0 : ℝ) from
      add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n)) hr hs hrs
  change r * Real.log (|u - x| + logRegularizationScale n) +
    s * Real.log (|v - x| + logRegularizationScale n) ≤
      Real.log (|r * u + s * v - x| + logRegularizationScale n)
  rw [hdist]
  simpa only [smul_eq_mul] using hlog

/-- Integrating the pointwise concavity uses the actual compact spectral
measure and its proved integrability for every regularized kernel. -/
theorem magneticRegularizedLogPotential_concaveOn_gap
    (α lam : ℝ) (n : ℕ) {a b : ℝ}
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam) a b) :
    ConcaveOn ℝ (Icc a b) (fun E => magneticRegularizedLogPotential α n (lam, E)) := by
  have hside (x : MagneticRealSpectrum α lam) : (x : ℝ) ≤ a ∨ b ≤ (x : ℝ) := by
    by_cases hxa : (x : ℝ) ≤ a
    · exact Or.inl hxa
    · right
      by_contra hbx
      have hxS : (x : ℝ) ∈ magneticRealSpectrumSet α lam := by
        rw [magneticRealSpectrumSet_eq_algebraSpectrum]
        exact x.property
      exact hgap.interior_avoids ⟨lt_of_not_ge hxa, lt_of_not_ge hbx⟩ hxS
  refine ⟨convex_Icc a b, ?_⟩
  intro u hu v hv r s hr hs hrs
  simp only [smul_eq_mul]
  rw [magneticRegularizedLogPotential_eq_spectralIntegral α lam u n,
    magneticRegularizedLogPotential_eq_spectralIntegral α lam v n,
    magneticRegularizedLogPotential_eq_spectralIntegral α lam (r * u + s * v) n]
  calc
    r * (∫ x : MagneticRealSpectrum α lam,
        regularizedLogKernel n (u - (x : ℝ)) ∂magneticSpectralMeasure α lam) +
      s * (∫ x : MagneticRealSpectrum α lam,
        regularizedLogKernel n (v - (x : ℝ)) ∂magneticSpectralMeasure α lam) =
      ∫ x : MagneticRealSpectrum α lam,
        r * regularizedLogKernel n (u - (x : ℝ)) +
          s * regularizedLogKernel n (v - (x : ℝ)) ∂magneticSpectralMeasure α lam := by
      rw [integral_add
        ((magnetic_regularizedLogKernel_integrable α lam u n).const_mul r)
        ((magnetic_regularizedLogKernel_integrable α lam v n).const_mul s),
        integral_const_mul, integral_const_mul]
    _ ≤ ∫ x : MagneticRealSpectrum α lam,
        regularizedLogKernel n (r * u + s * v - (x : ℝ))
          ∂magneticSpectralMeasure α lam := by
      apply integral_mono
        (((magnetic_regularizedLogKernel_integrable α lam u n).const_mul r).add
          ((magnetic_regularizedLogKernel_integrable α lam v n).const_mul s))
        (magnetic_regularizedLogKernel_integrable α lam (r * u + s * v) n)
      intro x
      simpa only [smul_eq_mul] using
        (regularizedLogKernel_concaveOn_interval n (hside x)).2 hu hv hr hs hrs

/-- Vanishing at both true spectral endpoints implies nonnegativity
throughout the closed gap, without presupposing endpoint continuity. -/
theorem magneticRegularizedLogPotential_nonneg_on_gap
    (α lam : ℝ) (n : ℕ) {a b E : ℝ}
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam) a b)
    (ha : magneticTotalLogPotential α (lam, a) = 0)
    (hb : magneticTotalLogPotential α (lam, b) = 0) (hE : E ∈ Icc a b) :
    0 ≤ magneticRegularizedLogPotential α n (lam, E) := by
  have hsegment : E ∈ segment ℝ a b := by
    rwa [segment_eq_Icc hgap.endpoints_ordered.le]
  have h := (magneticRegularizedLogPotential_concaveOn_gap α lam n hgap).ge_on_segment
    (show a ∈ Icc a b from ⟨le_rfl, hgap.endpoints_ordered.le⟩)
    (show b ∈ Icc a b from ⟨hgap.endpoints_ordered.le, le_rfl⟩) hsegment
  exact (le_min
    (magneticRegularizedLogPotential_nonneg_of_total_eq_zero α (lam, a) ha n)
    (magneticRegularizedLogPotential_nonneg_of_total_eq_zero α (lam, b) hb n)).trans h

/-- Spectral vanishing is the sole hypothesis here. Compactness provides
exterior endpoints, while every interior nonspectral point lies in a full gap. -/
theorem magneticRegularizedLogPotential_nonneg_of_spectral_vanishing
    (α lam : ℝ)
    (hzero : ∀ E ∈ magneticRealSpectrumSet α lam,
      magneticTotalLogPotential α (lam, E) = 0) (E : ℝ) (n : ℕ) :
    0 ≤ magneticRegularizedLogPotential α n (lam, E) := by
  have hcompact : IsCompact (magneticRealSpectrumSet α lam) := by
    rw [magneticRealSpectrumSet_eq_algebraSpectrum]
    exact spectrum.isCompact (𝕜 := ℝ) (magneticAlgebraHamiltonian α lam)
  have hnonempty : (magneticRealSpectrumSet α lam).Nonempty := by
    rw [magneticRealSpectrumSet_eq_algebraSpectrum]
    exact (magneticAlgebraHamiltonian_isSelfAdjoint α lam).spectrum_nonempty
  by_cases hE : E ∈ magneticRealSpectrumSet α lam
  · exact magneticRegularizedLogPotential_nonneg_of_total_eq_zero α (lam, E) (hzero E hE) n
  by_cases hleft : ∃ x ∈ magneticRealSpectrumSet α lam, x < E
  · by_cases hright : ∃ x ∈ magneticRealSpectrumSet α lam, E < x
    · obtain ⟨a, b, hgap, hEin⟩ := exists_spectral_gap_of_two_sided
        (magneticRealSpectrumSet_isClosed α lam) hE hleft hright
      exact magneticRegularizedLogPotential_nonneg_on_gap α lam n hgap
        (hzero a hgap.left_mem) (hzero b hgap.right_mem) ⟨hEin.1.le, hEin.2.le⟩
    · obtain ⟨b, hb⟩ := hcompact.exists_isGreatest hnonempty
      have hbE : b ≤ E := le_of_not_gt (fun hEb => hright ⟨b, hb.1, hEb⟩)
      have hcompare : magneticRegularizedLogPotential α n (lam, b) ≤
          magneticRegularizedLogPotential α n (lam, E) := by
        rw [magneticRegularizedLogPotential_eq_spectralIntegral α lam b n,
          magneticRegularizedLogPotential_eq_spectralIntegral α lam E n]
        apply integral_mono (magnetic_regularizedLogKernel_integrable α lam b n)
          (magnetic_regularizedLogKernel_integrable α lam E n)
        intro x
        have hxS : (x : ℝ) ∈ magneticRealSpectrumSet α lam := by
          rw [magneticRealSpectrumSet_eq_algebraSpectrum]
          exact x.property
        have hxb : (x : ℝ) ≤ b := hb.2 hxS
        unfold regularizedLogKernel
        apply Real.log_le_log
          (add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n))
        rw [abs_of_nonneg (sub_nonneg.mpr hxb),
          abs_of_nonneg (sub_nonneg.mpr (hxb.trans hbE))]
        linarith
      exact (magneticRegularizedLogPotential_nonneg_of_total_eq_zero
        α (lam, b) (hzero b hb.1) n).trans hcompare
  · obtain ⟨a, ha⟩ := hcompact.exists_isLeast hnonempty
    have hEa : E ≤ a := le_of_not_gt (fun haE => hleft ⟨a, ha.1, haE⟩)
    have hcompare : magneticRegularizedLogPotential α n (lam, a) ≤
        magneticRegularizedLogPotential α n (lam, E) := by
      rw [magneticRegularizedLogPotential_eq_spectralIntegral α lam a n,
        magneticRegularizedLogPotential_eq_spectralIntegral α lam E n]
      apply integral_mono (magnetic_regularizedLogKernel_integrable α lam a n)
        (magnetic_regularizedLogKernel_integrable α lam E n)
      intro x
      have hxS : (x : ℝ) ∈ magneticRealSpectrumSet α lam := by
        rw [magneticRealSpectrumSet_eq_algebraSpectrum]
        exact x.property
      have hax : a ≤ (x : ℝ) := ha.2 hxS
      unfold regularizedLogKernel
      apply Real.log_le_log
        (add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n))
      rw [abs_of_nonpos (sub_nonpos.mpr hax),
        abs_of_nonpos (sub_nonpos.mpr (hEa.trans hax))]
      linarith
    exact (magneticRegularizedLogPotential_nonneg_of_total_eq_zero
      α (lam, a) (hzero a ha.1) n).trans hcompare

theorem magneticTotalLogPotential_nonneg_of_spectral_vanishing
    (α lam : ℝ)
    (hzero : ∀ E ∈ magneticRealSpectrumSet α lam,
      magneticTotalLogPotential α (lam, E) = 0) (E : ℝ) :
    0 ≤ magneticTotalLogPotential α (lam, E) := by
  apply le_iInf
  intro n
  exact EReal.coe_le_coe_iff.mpr
    (magneticRegularizedLogPotential_nonneg_of_spectral_vanishing α lam hzero E n)

theorem magneticLogPotential_nonneg_of_spectral_vanishing
    (α lam : ℝ)
    (hzero : ∀ E ∈ magneticRealSpectrumSet α lam,
      magneticTotalLogPotential α (lam, E) = 0) (E : ℝ)
    (hm : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    0 ≤ magneticLogPotential α lam E := by
  have h := magneticTotalLogPotential_nonneg_of_spectral_vanishing α lam hzero E
  rw [magneticTotalLogPotential_eq_magneticLogPotential α lam E hm] at h
  exact EReal.coe_le_coe_iff.mp h

/-- The positive envelope equals the original trace-log potential in the
resolvent set; its positivity is derived from spectral vanishing, not assumed. -/
theorem magneticPositiveLogPotential_eq_of_spectral_vanishing
    (α lam : ℝ)
    (hzero : ∀ E ∈ magneticRealSpectrumSet α lam,
      magneticTotalLogPotential α (lam, E) = 0) (E : ℝ)
    (hm : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticPositiveLogPotential α (lam, E) = magneticLogPotential α lam E := by
  rw [magneticPositiveLogPotential_eq_max α lam E hm,
    max_eq_right (magneticLogPotential_nonneg_of_spectral_vanishing α lam hzero E hm)]

/-- At a spectral zero, upper semicontinuity and the proved nonnegative
positive envelope give continuity. Away from the spectrum, the existing
energy derivative supplies continuity. -/
theorem magneticPositiveLogPotential_energy_continuous_of_spectral_vanishing
    (α lam : ℝ)
    (hzero : ∀ E ∈ magneticRealSpectrumSet α lam,
      magneticTotalLogPotential α (lam, E) = 0) :
    Continuous (fun E => magneticPositiveLogPotential α (lam, E)) := by
  apply continuous_iff_continuousAt.mpr
  intro E
  by_cases hE : E ∈ magneticRealSpectrumSet α lam
  · have hvalue : magneticPositiveLogPotential α (lam, E) = 0 :=
      magneticPositiveLogPotential_eq_zero_of_total_eq_zero α (lam, E) (hzero E hE)
    apply continuousAt_iff_lower_upperSemicontinuousAt.mpr
    refine ⟨?_, (magneticPositiveLogPotential_upperSemicontinuous α (lam, E)).comp_continuousAt
      (continuousAt_const.prodMk continuousAt_id)⟩
    intro c hc
    have hc0 : c < 0 := by simpa only [hvalue] using hc
    exact Eventually.of_forall fun F => hc0.trans_le
      (magneticPositiveLogPotential_nonneg α (lam, F))
  · have hm : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) := spectrum.not_mem_iff.mp hE
    have hcont : ContinuousAt (fun F => max 0 (magneticLogPotential α lam F)) E :=
      continuousAt_const.max (magneticLogPotential_energy_hasDerivAt α lam E hm).continuousAt
    apply hcont.congr_of_eventuallyEq
    filter_upwards [(magneticRealSpectrumSet_isClosed α lam).isOpen_compl.mem_nhds hE] with F hF
    exact magneticPositiveLogPotential_eq_max α lam F (spectrum.not_mem_iff.mp hF)

end CriticalDTM

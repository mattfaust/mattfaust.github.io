import DTM.Background.Support.MagneticIntegralBridge
import DTM.Background.Support.CFCParameterContinuity
import Mathlib.Topology.Instances.EReal.Lemmas
import Mathlib.Topology.Semicontinuous
import Mathlib.Topology.Order.MonotoneConvergence
import Mathlib.Analysis.SpecificLimits.Basic

/-!
# An intrinsic total logarithmic potential

The actual root-state probability measure defines a total extended-real
logarithmic potential by decreasing regularization of its logarithmic kernel.
The positive regularization scale is added to the distance, rather than used
as a cutoff; this also preserves concavity on each spectral gap.

Every regularized integral is the actual magnetic trace of a continuous
function of the self-adjoint pencil. Consequently its joint continuity, and
the upper semicontinuity of the extended-real infimum, follow from the proved
operator-argument CFC continuity theorem. At resolvent energies the infimum
is finite and agrees with the existing trace-log potential.

The auxiliary positive-part envelope is real-valued and globally upper
semicontinuous, including at couplings outside the subcritical range. It is
not declared to be the total logarithmic potential where that potential is
negative. Spectral vanishing is not asserted or assumed by these definitions.
-/

noncomputable section

namespace CriticalDTM

open Set Filter MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

local instance logExtension_realNormedSpace (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

local instance logExtension_realModule (α : ℝ) : Module ℝ (magneticAlgebra α) :=
  @Algebra.toModule ℝ (magneticAlgebra α) _ _
    (magneticAlgebra_realNormedAlgebra α).toAlgebra

local instance logExtension_realSMulCommClass (α : ℝ) :
    SMulCommClass ℝ (magneticAlgebra α) (magneticAlgebra α) :=
  Algebra.to_smulCommClass

/-- A positive decreasing scale tending to zero. -/
def logRegularizationScale (n : ℕ) : ℝ := 1 / ((n : ℝ) + 1)

theorem logRegularizationScale_pos (n : ℕ) : 0 < logRegularizationScale n := by
  unfold logRegularizationScale
  positivity

theorem logRegularizationScale_antitone : Antitone logRegularizationScale := by
  intro n m hnm
  apply one_div_le_one_div_of_le
  · positivity
  · exact add_le_add_right (Nat.cast_le.mpr hnm) 1

theorem logRegularizationScale_tendsto :
    Tendsto logRegularizationScale atTop (𝓝 0) :=
  tendsto_one_div_add_atTop_nhds_zero_nat

/-- A globally continuous regularization of the logarithm of distance. -/
def regularizedLogKernel (n : ℕ) (x : ℝ) : ℝ :=
  Real.log (|x| + logRegularizationScale n)

theorem regularizedLogKernel_continuous (n : ℕ) :
    Continuous (regularizedLogKernel n) :=
  (continuous_abs.add continuous_const).log fun x =>
    (add_pos_of_nonneg_of_pos (abs_nonneg x) (logRegularizationScale_pos n)).ne'

theorem regularizedLogKernel_antitone (x : ℝ) :
    Antitone (fun n => regularizedLogKernel n x) := by
  intro n m hnm
  exact Real.log_le_log
    (add_pos_of_nonneg_of_pos (abs_nonneg x) (logRegularizationScale_pos m))
    (add_le_add_left (logRegularizationScale_antitone hnm) |x|)

/-- The actual trace of a continuous regularized function of the pencil. -/
def magneticRegularizedLogPotential (α : ℝ) (n : ℕ) (p : ℝ × ℝ) : ℝ :=
  magneticTraceReal α
    (cfc (regularizedLogKernel n) (magneticAlgebraPencil α p.1 p.2))

theorem magneticAlgebraPencil_joint_continuous (α : ℝ) :
    Continuous (fun p : ℝ × ℝ => magneticAlgebraPencil α p.1 p.2) := by
  change Continuous (fun p : ℝ × ℝ => p.2 • (1 : magneticAlgebra α) -
    ((⟨hOperator α 0, hOperator_mem_magneticAlgebra α 0⟩ : magneticAlgebra α) +
      p.1 • magneticAlgebraVertical α))
  exact (continuous_snd.smul continuous_const).sub
    (continuous_const.add (continuous_fst.smul continuous_const))

/-- Joint continuity uses the fixed scalar kernel and the norm-continuous
self-adjoint pencil, not any continuity theorem for a supplied Lyapunov exponent. -/
theorem magneticRegularizedLogPotential_continuous (α : ℝ) (n : ℕ) :
    Continuous (magneticRegularizedLogPotential α n) := by
  apply continuous_iff_continuousAt.mpr
  intro p
  exact (magneticTraceReal α).continuous.continuousAt.comp
    (continuousAt_cfc_of_continuous
      (fun q : ℝ × ℝ => magneticAlgebraPencil α q.1 q.2) p
      (magneticAlgebraPencil_joint_continuous α).continuousAt
      (regularizedLogKernel n) (regularizedLogKernel_continuous n)
      (Eventually.of_forall fun q => magneticAlgebraPencil_isSelfAdjoint α q.1 q.2))

/-- Each regularization is an integral of the actual probability measure,
including at spectral energies. -/
theorem magneticRegularizedLogPotential_eq_spectralIntegral
    (α lam energy : ℝ) (n : ℕ) :
    magneticRegularizedLogPotential α n (lam, energy) =
      ∫ x : MagneticRealSpectrum α lam,
        regularizedLogKernel n (energy - (x : ℝ)) ∂magneticSpectralMeasure α lam := by
  have hshift : Continuous (fun x : ℝ => energy - x) := continuous_const.sub continuous_id
  have hkernel : ContinuousOn (fun x : ℝ => regularizedLogKernel n (energy - x))
      (spectrum ℝ (magneticAlgebraHamiltonian α lam)) :=
    ((regularizedLogKernel_continuous n).comp hshift).continuousOn
  rw [magneticSpectralMeasure_integral_cfc_of_continuousOn α lam
    (fun x : ℝ => regularizedLogKernel n (energy - x)) hkernel,
    cfc_comp' (regularizedLogKernel n) (fun x : ℝ => energy - x)
      (magneticAlgebraHamiltonian α lam)
      (regularizedLogKernel_continuous n).continuousOn hshift.continuousOn
      (magneticAlgebraHamiltonian_isSelfAdjoint α lam),
    cfc_real_pencil _ (magneticAlgebraHamiltonian_isSelfAdjoint α lam) energy]
  rfl

theorem magneticRegularizedLogPotential_eq_realSpectralIntegral
    (α lam energy : ℝ) (n : ℕ) :
    magneticRegularizedLogPotential α n (lam, energy) =
      ∫ x : ℝ, regularizedLogKernel n (energy - x)
        ∂magneticRealSpectralMeasure α lam := by
  rw [magneticRealSpectralMeasure_integral_eq_subtype]
  exact magneticRegularizedLogPotential_eq_spectralIntegral α lam energy n

theorem magnetic_regularizedLogKernel_integrable (α lam energy : ℝ) (n : ℕ) :
    Integrable (fun x : MagneticRealSpectrum α lam =>
      regularizedLogKernel n (energy - (x : ℝ))) (magneticSpectralMeasure α lam) :=
  ((regularizedLogKernel_continuous n).comp
    (continuous_const.sub continuous_subtype_val)).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)

theorem magneticRegularizedLogPotential_antitone (α : ℝ) (p : ℝ × ℝ) :
    Antitone (fun n => magneticRegularizedLogPotential α n p) := by
  intro n m hnm
  change magneticRegularizedLogPotential α m (p.1, p.2) ≤
    magneticRegularizedLogPotential α n (p.1, p.2)
  rw [magneticRegularizedLogPotential_eq_spectralIntegral α p.1 p.2 m,
    magneticRegularizedLogPotential_eq_spectralIntegral α p.1 p.2 n]
  exact integral_mono
    (magnetic_regularizedLogKernel_integrable α p.1 p.2 m)
    (magnetic_regularizedLogKernel_integrable α p.1 p.2 n)
    (fun x => regularizedLogKernel_antitone (p.2 - (x : ℝ)) hnm)

/-- The actual total logarithmic potential, with a possible value `-∞`.
This is the decreasing logarithmic-integral definition, not the totalized
Bochner integral of a possibly nonintegrable real logarithm. -/
def magneticTotalLogPotential (α : ℝ) (p : ℝ × ℝ) : EReal :=
  ⨅ n : ℕ, (magneticRegularizedLogPotential α n p : EReal)

/-- A globally real, nonnegative auxiliary envelope. On a regime where the
actual potential is nonnegative it is the actual potential itself. -/
def magneticPositiveLogPotential (α : ℝ) (p : ℝ × ℝ) : ℝ :=
  ⨅ n : ℕ, max 0 (magneticRegularizedLogPotential α n p)

theorem magneticPositiveLogPotential_bddBelow (α : ℝ) (p : ℝ × ℝ) :
    BddBelow (range fun n : ℕ => max 0 (magneticRegularizedLogPotential α n p)) :=
  ⟨0, by rintro _ ⟨n, rfl⟩; exact le_max_left _ _⟩

theorem magneticPositiveLogPotential_nonneg (α : ℝ) (p : ℝ × ℝ) :
    0 ≤ magneticPositiveLogPotential α p :=
  le_ciInf fun _ => le_max_left _ _

theorem magneticPositiveLogPotential_upperSemicontinuous (α : ℝ) :
    UpperSemicontinuous (magneticPositiveLogPotential α) :=
  upperSemicontinuous_ciInf (magneticPositiveLogPotential_bddBelow α) fun n =>
    (continuous_const.max (magneticRegularizedLogPotential_continuous α n)).upperSemicontinuous

/-- On a fixed compact resolvent spectrum the regularized kernels converge
in the continuous-function norm. Currying a continuous function of scale and
spectral point provides this without a singular dominated-convergence step. -/
theorem magneticRegularizedLogPotential_tendsto (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    Tendsto (fun n : ℕ => magneticRegularizedLogPotential α n (lam, energy))
      atTop (𝓝 (magneticLogPotential α lam energy)) := by
  let K : ℝ → C(MagneticRealSpectrum α lam, ℝ) := fun t =>
    ⟨fun x => Real.log (|energy - (x : ℝ)| + |t|),
      ((continuous_const.sub continuous_subtype_val).abs.add continuous_const).log
        (fun x => (add_pos_of_pos_of_nonneg
          (abs_pos.mpr (magnetic_spectral_shift_ne_zero α lam energy hm x))
          (abs_nonneg t)).ne')⟩
  have hK : Continuous K := by
    apply ContinuousMap.continuous_of_continuous_uncurry
    exact (((continuous_const.sub
      (continuous_subtype_val.comp continuous_snd)).abs).add continuous_fst.abs).log
      (fun p => (add_pos_of_pos_of_nonneg
        (abs_pos.mpr (magnetic_spectral_shift_ne_zero α lam energy hm p.2))
        (abs_nonneg p.1)).ne')
  have htrace : Continuous (fun t => magneticTraceReal α
      (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) (K t))) :=
    (magneticTraceReal α).continuous.comp
      ((cfcHom_continuous (magneticAlgebraHamiltonian_isSelfAdjoint α lam)).comp hK)
  have hlimit := htrace.continuousAt.tendsto.comp logRegularizationScale_tendsto
  have hn (n : ℕ) : magneticTraceReal α
      (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
        (K (logRegularizationScale n))) =
      magneticRegularizedLogPotential α n (lam, energy) := by
    rw [← magneticSpectralMeasure_integral,
      magneticRegularizedLogPotential_eq_spectralIntegral α lam energy n]
    apply integral_congr_ae
    exact Eventually.of_forall fun x => by
      simp only [K, ContinuousMap.coe_mk, regularizedLogKernel,
        abs_of_pos (logRegularizationScale_pos n)]
  have hzero : magneticTraceReal α
      (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) (K 0)) =
      magneticLogPotential α lam energy := by
    rw [← magneticSpectralMeasure_integral,
      magneticLogPotential_eq_spectralIntegral α lam energy hm]
    apply integral_congr_ae
    exact Eventually.of_forall fun x => by simp only [K, ContinuousMap.coe_mk, abs_zero, add_zero]
  simpa only [Function.comp_def, hn, hzero] using hlimit

/-- Exact agreement with the existing actual trace-log potential off the
spectrum. No comparison with an externally supplied Lyapunov function is used. -/
theorem magneticTotalLogPotential_eq_magneticLogPotential (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticTotalLogPotential α (lam, energy) =
      (magneticLogPotential α lam energy : EReal) := by
  apply iInf_eq_of_tendsto
  · intro n m hnm
    exact EReal.coe_le_coe_iff.mpr
      (magneticRegularizedLogPotential_antitone α (lam, energy) hnm)
  · exact continuous_coe_real_ereal.continuousAt.tendsto.comp
      (magneticRegularizedLogPotential_tendsto α lam energy hm)

theorem magneticPositiveLogPotential_eq_max (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticPositiveLogPotential α (lam, energy) =
      max 0 (magneticLogPotential α lam energy) := by
  have hanti : Antitone (fun n : ℕ => max 0
      (magneticRegularizedLogPotential α n (lam, energy))) := by
    intro n m hnm
    exact max_le_max_left 0 (magneticRegularizedLogPotential_antitone α (lam, energy) hnm)
  exact tendsto_nhds_unique
    (tendsto_atTop_ciInf hanti (magneticPositiveLogPotential_bddBelow α (lam, energy)))
    (tendsto_const_nhds.max (magneticRegularizedLogPotential_tendsto α lam energy hm))

theorem magneticRegularizedLogPotential_nonneg_of_total_eq_zero
    (α : ℝ) (p : ℝ × ℝ) (hzero : magneticTotalLogPotential α p = 0) (n : ℕ) :
    0 ≤ magneticRegularizedLogPotential α n p := by
  have h : (0 : EReal) ≤ (magneticRegularizedLogPotential α n p : EReal) :=
    hzero ▸ iInf_le (fun n : ℕ => (magneticRegularizedLogPotential α n p : EReal)) n
  exact EReal.coe_le_coe_iff.mp h

theorem magneticPositiveLogPotential_eq_zero_of_total_eq_zero
    (α : ℝ) (p : ℝ × ℝ) (hzero : magneticTotalLogPotential α p = 0) :
    magneticPositiveLogPotential α p = 0 := by
  apply le_antisymm _ (magneticPositiveLogPotential_nonneg α p)
  by_contra h
  have hpos : 0 < magneticPositiveLogPotential α p := lt_of_not_ge h
  have hlt : magneticTotalLogPotential α p < (magneticPositiveLogPotential α p : EReal) := by
    rw [hzero]
    exact EReal.coe_lt_coe_iff.mpr hpos
  obtain ⟨n, hn⟩ := iInf_lt_iff.mp hlt
  have hn' : magneticRegularizedLogPotential α n p < magneticPositiveLogPotential α p :=
    EReal.coe_lt_coe_iff.mp hn
  have hle : magneticPositiveLogPotential α p ≤ max 0 (magneticRegularizedLogPotential α n p) :=
    ciInf_le (magneticPositiveLogPotential_bddBelow α p) n
  exact (not_lt_of_ge hle) (max_lt hpos hn')

end CriticalDTM

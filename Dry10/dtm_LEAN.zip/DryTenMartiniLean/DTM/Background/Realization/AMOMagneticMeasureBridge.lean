import DTM.Background.Realization.AMOMagneticMoments
import DTM.Background.Realization.MagneticLowerMass
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-!
# The magnetic root measure and the actual almost Mathieu IDS

Polynomial approximation extends the explicit moment identity to continuous
functional-calculus tests. Continuous lower-cut ramps and dominated convergence
then identify the pre-existing lower masses; no alternate IDS definition or
spectral bridge assumption is introduced.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Polynomial ContinuousFunctionalCalculus Topology

theorem norm_amoRootState_le (A : AMOBoundedOperator) : ‖amoRootState A‖ ≤ ‖A‖ := by
  calc
    ‖amoRootState A‖ ≤ ‖A amoRoot‖ :=
      lp.norm_apply_le_norm (by norm_num) (A amoRoot) 0
    _ ≤ ‖A‖ * ‖amoRoot‖ := A.le_opNorm amoRoot
    _ = ‖A‖ := by rw [amoRoot_norm, mul_one]

theorem norm_rootTrace_le (A : MagneticBoundedOperator) : ‖rootTrace A‖ ≤ ‖A‖ := by
  calc
    ‖rootTrace A‖ ≤ ‖rootTrace‖ * ‖A‖ := rootTrace.le_opNorm A
    _ ≤ 1 * ‖A‖ := mul_le_mul_of_nonneg_right rootTrace_norm_le (norm_nonneg A)
    _ = ‖A‖ := one_mul _

/-- Operator-norm continuity gives continuity of every continuous CFC root test
throughout the actual phase family. -/
theorem continuous_amoRootState_cfc_phase (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Continuous (fun θ => amoRootState (cfc f (almostMathieuOperator α lam θ))) := by
  rw [continuous_iff_continuousAt]
  intro θ
  exact amoRootState.continuous.continuousAt.comp
    (continuousAt_cfc_of_continuous (almostMathieuOperator α lam) θ
      (continuous_almostMathieuOperator_phase α lam).continuousAt f hf
      (Eventually.of_forall (almostMathieuOperator_isSelfAdjoint α lam)))

theorem amoRootState_cfc_intervalIntegrable (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    IntervalIntegrable (fun t =>
      amoRootState (cfc f (almostMathieuOperator α lam (2 * Real.pi * t))))
      volume (0 : ℝ) 1 :=
  ((continuous_amoRootState_cfc_phase α lam f hf).comp
    (continuous_const.mul continuous_id)).intervalIntegrable 0 1

/-- Continuous tests of the actual magnetic Hamiltonian equal the phase
average of the corresponding tests of the actual one-dimensional AMO. -/
theorem integral_amoRootState_cfc (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    (∫ t in (0 : ℝ)..1,
      amoRootState (cfc f (almostMathieuOperator α lam (2 * Real.pi * t)))) =
        rootTrace (cfc f (hOperator α (lam : ℂ))) := by
  apply sub_eq_zero.mp
  apply norm_eq_zero.mp
  apply le_antisymm _ (norm_nonneg _)
  apply le_of_forall_pos_le_add
  intro epsilon hepsilon
  have hepsilon2 : 0 < epsilon / 2 := by linarith
  let K : Set ℝ := Icc (-(2 + 2 * |lam|)) (2 + 2 * |lam|)
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K isCompact_Icc
    f hf.continuousOn (epsilon / 2) hepsilon2
  have hmag : ‖cfc f (hOperator α (lam : ℂ)) -
      Polynomial.aeval (hOperator α (lam : ℂ)) p‖ < epsilon / 2 := by
    apply norm_cfc_sub_polynomial_lt f K hf.continuousOn p (epsilon / 2) hepsilon2 hp
      _ (hOperator_isSelfAdjoint α lam)
    exact real_spectrum_subset_Icc_of_norm_le _ (by
      simpa only [Complex.norm_real, Real.norm_eq_abs] using hOperator_norm_le α (lam : ℂ))
  have hamo (t : ℝ) : ‖cfc f (almostMathieuOperator α lam (2 * Real.pi * t)) -
      Polynomial.aeval (almostMathieuOperator α lam (2 * Real.pi * t)) p‖ < epsilon / 2 := by
    apply norm_cfc_sub_polynomial_lt f K hf.continuousOn p (epsilon / 2) hepsilon2 hp
      _ (almostMathieuOperator_isSelfAdjoint α lam _)
    exact real_spectrum_subset_Icc_of_norm_le _ (almostMathieuOperator_norm_le α lam _)
  have hmean : ‖(∫ t in (0 : ℝ)..1,
      amoRootState (cfc f (almostMathieuOperator α lam (2 * Real.pi * t)))) -
        rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p)‖ ≤ epsilon / 2 := by
    rw [← integral_amoRootState_aeval α lam p,
      ← intervalIntegral.integral_sub (amoRootState_cfc_intervalIntegrable α lam f hf)
        (amoRootState_aeval_intervalIntegrable α lam p)]
    have h := intervalIntegral.norm_integral_le_of_norm_le_const (a := (0 : ℝ)) (b := 1)
      (f := fun t =>
        amoRootState (cfc f (almostMathieuOperator α lam (2 * Real.pi * t))) -
          amoRootState (Polynomial.aeval (almostMathieuOperator α lam (2 * Real.pi * t)) p))
      (C := epsilon / 2) (fun t _ => by
        dsimp only
        rw [← map_sub]
        exact (norm_amoRootState_le _).trans (hamo t).le)
    simpa using h
  have hroot : ‖rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p) -
      rootTrace (cfc f (hOperator α (lam : ℂ)))‖ ≤ epsilon / 2 := by
    rw [norm_sub_rev, ← map_sub]
    exact (norm_rootTrace_le _).trans hmag.le
  calc
    _ ≤ ‖(∫ t in (0 : ℝ)..1,
          amoRootState (cfc f (almostMathieuOperator α lam (2 * Real.pi * t)))) -
            rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p)‖ +
        ‖rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p) -
          rootTrace (cfc f (hOperator α (lam : ℂ)))‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ epsilon / 2 + epsilon / 2 := add_le_add hmean hroot
    _ = 0 + epsilon := by ring

/-- Real-valued root tests, in the form directly used by the two RMK measures. -/
theorem integral_amoRootStateReal_cfc (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    (∫ t in (0 : ℝ)..1,
      amoRootStateReal (cfc f (almostMathieuOperator α lam (2 * Real.pi * t)))) =
        (rootTrace (cfc f (hOperator α (lam : ℂ)))).re := by
  change (∫ t in (0 : ℝ)..1,
    Complex.reCLM (amoRootState (cfc f (almostMathieuOperator α lam (2 * Real.pi * t))))) = _
  rw [Complex.reCLM.intervalIntegral_comp_comm (amoRootState_cfc_intervalIntegrable α lam f hf),
    integral_amoRootState_cfc α lam f hf]
  rfl

section MagneticMeasure

/-- The CFC in the closed magnetic algebra is the CFC of the same bounded
physical operator under the actual inclusion homomorphism. -/
theorem magneticAlgebraHamiltonian_cfc_coe (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    ((cfc f (magneticAlgebraHamiltonian α lam) : magneticAlgebra α) : MagneticBoundedOperator) =
      cfc f (hOperator α (lam : ℂ)) := by
  have h := (magneticAlgebra α).subtype.map_cfc f (magneticAlgebraHamiltonian α lam)
    hf.continuousOn continuous_subtype_val (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
    (by simpa only [StarSubalgebra.subtype_apply, magneticAlgebraHamiltonian_coe] using
      hOperator_isSelfAdjoint α lam)
  simpa only [StarSubalgebra.subtype_apply, magneticAlgebraHamiltonian_coe] using h

/-- The two pre-existing RMK constructions have the same averaged continuous
tests. There is no assumption connecting their measures. -/
theorem magneticRealSpectralMeasure_integral_eq_phase_average (α lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    (∫ x, f x ∂magneticRealSpectralMeasure α lam) =
      ∫ t in (0 : ℝ)..1, ∫ x, f x ∂amoRealSpectralMeasure α lam (2 * Real.pi * t) := by
  rw [magneticRealSpectralMeasure_integral_cfc α lam f hf, magneticTraceReal_apply,
    magneticAlgebraHamiltonian_cfc_coe α lam f hf]
  simp_rw [amoRealSpectralMeasure_integral_cfc α lam _ f hf]
  exact (integral_amoRootStateReal_cfc α lam f hf).symm

end MagneticMeasure

/-- Continuous tests approaching the strict lower-half-line indicator. These
are only test functions; neither spectral measure nor IDS is redefined. -/
def idsLowerCutApprox (energy : ℝ) (n : ℕ) (x : ℝ) : ℝ :=
  min 1 (max 0 ((n : ℝ) * (energy - x)))

theorem continuous_idsLowerCutApprox (energy : ℝ) (n : ℕ) :
    Continuous (idsLowerCutApprox energy n) := by
  unfold idsLowerCutApprox
  fun_prop

theorem idsLowerCutApprox_nonneg (energy : ℝ) (n : ℕ) (x : ℝ) :
    0 ≤ idsLowerCutApprox energy n x :=
  le_min zero_le_one (le_max_left _ _)

theorem idsLowerCutApprox_le_one (energy : ℝ) (n : ℕ) (x : ℝ) :
    idsLowerCutApprox energy n x ≤ 1 := min_le_left _ _

theorem norm_idsLowerCutApprox_le_one (energy : ℝ) (n : ℕ) (x : ℝ) :
    ‖idsLowerCutApprox energy n x‖ ≤ 1 := by
  rw [Real.norm_eq_abs, abs_of_nonneg (idsLowerCutApprox_nonneg energy n x)]
  exact idsLowerCutApprox_le_one energy n x

/-- The approximants vanish at the cut itself, so atoms at the cut require no
exception and the limit has exactly the pre-existing `Iio` convention. -/
theorem tendsto_idsLowerCutApprox (energy x : ℝ) :
    Tendsto (fun n => idsLowerCutApprox energy n x) atTop
      (𝓝 ((Iio energy).indicator (fun _ : ℝ => (1 : ℝ)) x)) := by
  by_cases hx : x < energy
  · rw [Set.indicator_of_mem (show x ∈ Iio energy from hx)]
    have hdiff : 0 < energy - x := sub_pos.mpr hx
    obtain ⟨N, hN⟩ := exists_nat_gt ((energy - x)⁻¹)
    have hN' : 1 < (N : ℝ) * (energy - x) := by
      have h := mul_lt_mul_of_pos_right hN hdiff
      simpa only [inv_mul_cancel₀ (ne_of_gt hdiff)] using h
    have heq : (fun n => idsLowerCutApprox energy n x) =ᶠ[atTop] (fun _ => (1 : ℝ)) := by
      filter_upwards [eventually_ge_atTop N] with n hn
      have hn' : (N : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
      have hprod : 1 ≤ (n : ℝ) * (energy - x) :=
        hN'.le.trans (mul_le_mul_of_nonneg_right hn' hdiff.le)
      exact min_eq_left (le_max_of_le_right hprod)
    exact (tendsto_congr' heq).2 tendsto_const_nhds
  · rw [Set.indicator_of_not_mem (show x ∉ Iio energy from hx)]
    have heq (n : ℕ) : idsLowerCutApprox energy n x = 0 := by
      have hprod : (n : ℝ) * (energy - x) ≤ 0 :=
        mul_nonpos_of_nonneg_of_nonpos (Nat.cast_nonneg n) (sub_nonpos.mpr (le_of_not_gt hx))
      simp only [idsLowerCutApprox, max_eq_left hprod, min_eq_right zero_le_one]
    exact (tendsto_congr heq).2 tendsto_const_nhds

/-- Bounded convergence to the lower mass for any existing finite real measure. -/
theorem tendsto_integral_idsLowerCutApprox (μ : Measure ℝ) [IsFiniteMeasure μ] (energy : ℝ) :
    Tendsto (fun n => ∫ x, idsLowerCutApprox energy n x ∂μ) atTop
      (𝓝 ((μ (Iio energy)).toReal)) := by
  have h := tendsto_integral_of_dominated_convergence (μ := μ)
    (F := fun n x => idsLowerCutApprox energy n x)
    (f := (Iio energy).indicator (fun _ : ℝ => (1 : ℝ))) (fun _ : ℝ => (1 : ℝ))
    (fun n => (continuous_idsLowerCutApprox energy n).aestronglyMeasurable)
    (integrable_const 1)
    (fun n => Eventually.of_forall (norm_idsLowerCutApprox_le_one energy n))
    (Eventually.of_forall (tendsto_idsLowerCutApprox energy))
  simpa only [integral_indicator_const (1 : ℝ) measurableSet_Iio, smul_eq_mul,
    mul_one, measureReal_def] using h

/-- The phase dependence of integrated continuous tests is ordinary continuity,
not an unproved measurability assertion for an averaged measure. -/
theorem continuous_amoRealSpectralMeasure_integral_phase (α lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    Continuous (fun θ => ∫ x, f x ∂amoRealSpectralMeasure α lam θ) := by
  simp_rw [amoRealSpectralMeasure_integral_cfc α lam _ f hf]
  exact Complex.continuous_re.comp (continuous_amoRootState_cfc_phase α lam f hf)

/-- The normalized phase average of the continuous approximants converges to
exactly the previously defined phase-averaged IDS. -/
theorem tendsto_phase_integral_idsLowerCutApprox (α lam energy : ℝ) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1,
      ∫ x, idsLowerCutApprox energy n x ∂amoRealSpectralMeasure α lam (2 * Real.pi * t))
        atTop (𝓝 (almostMathieuIDS α lam energy)) := by
  unfold almostMathieuIDS
  simp_rw [intervalIntegral.integral_of_le (show (0 : ℝ) ≤ 1 by norm_num)]
  apply tendsto_integral_of_dominated_convergence (fun _ : ℝ => (1 : ℝ))
  · intro n
    exact ((continuous_amoRealSpectralMeasure_integral_phase α lam
      (idsLowerCutApprox energy n) (continuous_idsLowerCutApprox energy n)).comp
        (continuous_const.mul continuous_id)).aestronglyMeasurable
  · exact integrable_const 1
  · intro n
    apply Eventually.of_forall
    intro t
    have h := MeasureTheory.norm_integral_le_of_norm_le_const
      (μ := amoRealSpectralMeasure α lam (2 * Real.pi * t))
      (Eventually.of_forall (norm_idsLowerCutApprox_le_one energy n))
    simpa using h
  · exact Eventually.of_forall (fun t =>
      tendsto_integral_idsLowerCutApprox
        (amoRealSpectralMeasure α lam (2 * Real.pi * t)) energy)

/-- The genuine IDS identity for the actual definitions, at every real
frequency, coupling and energy. In particular no irrationality, spectral-gap
condition, atom-free assumption or external bridge is needed. -/
theorem magneticLowerMass_eq_almostMathieuIDS (α lam energy : ℝ) :
    magneticLowerMass α lam energy = almostMathieuIDS α lam energy := by
  have hmag := tendsto_integral_idsLowerCutApprox (magneticRealSpectralMeasure α lam) energy
  have hamo := tendsto_phase_integral_idsLowerCutApprox α lam energy
  have htest (n : ℕ) := magneticRealSpectralMeasure_integral_eq_phase_average α lam
    (idsLowerCutApprox energy n) (continuous_idsLowerCutApprox energy n)
  simp_rw [← htest] at hamo
  exact tendsto_nhds_unique hmag hamo

end CriticalDTM

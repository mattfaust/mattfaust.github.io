import DTM.Background.Realization.MagneticTrace
import DTM.Background.Realization.AMOSpectralMeasure
import Mathlib.Analysis.SpecialFunctions.Integrals

/-!
# Magnetic moments and the actual almost Mathieu phase family

The one-dimensional monomial below acts on ordinary square-summable
wavefunctions. It obeys the same explicit multiplication law as the magnetic
lattice monomial. Averaging its physical root entry over one phase period
picks out exactly the magnetic root entry. Finite linear combinations and
products then identify the moments of the two actual Hamiltonians.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory
open scoped Polynomial

private theorem amoMagnetic_summable_sq (u : AMOHilbert) :
    Summable (fun n => ‖u n‖ ^ (2 : ℕ)) := by
  have h := (lp.memℓp u).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  simpa using h

private theorem amoMagnetic_norm_sq (u : AMOHilbert) :
    ‖u‖ ^ (2 : ℕ) = ∑' n, ‖u n‖ ^ (2 : ℕ) := by
  have h := lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) u
  simpa using h

/-- The phase parameter `t` has period one; the physical radian phase is `2πt`.
The receiving row is `exp(2πint) exp(2πiαnj) u(j+m)`. -/
def amoMagneticMonomialVector (α t : ℝ) (a : Site) (u : AMOHilbert) : AMOHilbert :=
  ⟨fun j => magneticPhase t a.2 * magneticPhase α (a.2 * j) * u (j + a.1), by
    apply memℓp_gen
    have h := (Equiv.addRight a.1).summable_iff.mpr (amoMagnetic_summable_sq u)
    simpa [Function.comp_def, norm_mul, magneticPhase_norm] using h⟩

@[simp] theorem amoMagneticMonomialVector_apply (α t : ℝ) (a : Site)
    (u : AMOHilbert) (j : ℤ) :
    amoMagneticMonomialVector α t a u j =
      magneticPhase t a.2 * magneticPhase α (a.2 * j) * u (j + a.1) := rfl

theorem amoMagneticMonomialVector_norm (α t : ℝ) (a : Site) (u : AMOHilbert) :
    ‖amoMagneticMonomialVector α t a u‖ = ‖u‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [amoMagnetic_norm_sq, amoMagnetic_norm_sq]
  simp only [amoMagneticMonomialVector_apply, norm_mul, magneticPhase_norm, one_mul]
  exact (Equiv.addRight a.1).tsum_eq (fun j => ‖u j‖ ^ (2 : ℕ))

/-- The actual bounded one-dimensional magnetic monomial. -/
def amoMagneticMonomial (α t : ℝ) (a : Site) : AMOBoundedOperator :=
  LinearMap.mkContinuous
    { toFun := amoMagneticMonomialVector α t a
      map_add' := by
        intro u v
        apply lp.ext
        funext j
        simp [mul_add]
      map_smul' := by
        intro c u
        apply lp.ext
        funext j
        simp [mul_left_comm] }
    1 (fun u => by simp [amoMagneticMonomialVector_norm])

@[simp] theorem amoMagneticMonomial_apply (α t : ℝ) (a : Site)
    (u : AMOHilbert) (j : ℤ) :
    amoMagneticMonomial α t a u j =
      magneticPhase t a.2 * magneticPhase α (a.2 * j) * u (j + a.1) := rfl

/-- The cocycle is exactly the cocycle of `magneticMonomial_mul`. -/
theorem amoMagneticMonomial_mul (α t : ℝ) (a b : Site) :
    amoMagneticMonomial α t a * amoMagneticMonomial α t b =
      magneticPhase α (b.2 * a.1) • amoMagneticMonomial α t (a + b) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext j
  simp only [ContinuousLinearMap.mul_apply, amoMagneticMonomial_apply,
    ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul,
    Prod.fst_add, Prod.snd_add, mul_add, add_mul, magneticPhase_add, add_assoc]
  ring

@[simp] theorem amoMagneticMonomial_origin (α t : ℝ) :
    amoMagneticMonomial α t origin = 1 := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext j
  simp [origin, magneticPhase_zero]

@[simp] theorem amoRootState_amoMagneticMonomial (α t : ℝ) (a : Site) :
    amoRootState (amoMagneticMonomial α t a) =
      if a.1 = 0 then magneticPhase t a.2 else 0 := by
  by_cases ha : a.1 = 0
  · simp [amoRootState_apply, amoRoot, magneticPhase_zero, ha]
  · simp [amoRootState_apply, amoRoot, magneticPhase_zero, ha]

/-- No Fourier transform or direct-integral theorem is used: this is the
ordinary integral of an exponential over one period. -/
theorem integral_magneticPhase (n : ℤ) :
    (∫ t in (0 : ℝ)..1, magneticPhase t n) = if n = 0 then 1 else 0 := by
  by_cases hn : n = 0
  · simp [hn, magneticPhase_zero]
  · let c : ℂ := (n : ℂ) * (2 * (Real.pi : ℂ) * Complex.I)
    have hc : c ≠ 0 := by
      simp [c, hn, Real.pi_ne_zero]
    have hphase (t : ℝ) : magneticPhase t n = Complex.exp (c * t) := by
      unfold magneticPhase c
      congr 1
      push_cast
      ring
    simp_rw [hphase]
    rw [integral_exp_mul_complex hc]
    simp [hn, c]

theorem continuous_magneticPhase_parameter (n : ℤ) :
    Continuous (fun t : ℝ => magneticPhase t n) := by
  unfold magneticPhase
  fun_prop

theorem amoRootState_amoMagneticMonomial_intervalIntegrable (α : ℝ) (a : Site) :
    IntervalIntegrable (fun t => amoRootState (amoMagneticMonomial α t a))
      volume (0 : ℝ) 1 := by
  simp_rw [amoRootState_amoMagneticMonomial]
  split_ifs
  · exact (continuous_magneticPhase_parameter a.2).intervalIntegrable 0 1
  · exact intervalIntegrable_const

/-- Averaging the one-dimensional physical root gives exactly the magnetic
physical root on every monomial, for every real frequency, rational or not. -/
theorem integral_amoRootState_amoMagneticMonomial (α : ℝ) (a : Site) :
    (∫ t in (0 : ℝ)..1, amoRootState (amoMagneticMonomial α t a)) =
      rootTrace (magneticMonomial α a) := by
  rw [rootTrace_magneticMonomial]
  simp_rw [amoRootState_amoMagneticMonomial]
  by_cases ha : a.1 = 0
  · simp [ha, integral_magneticPhase, origin, Prod.ext_iff]
  · simp [ha, origin, Prod.ext_iff]

private theorem exp_add_exp_neg_eq_two_cos (x : ℝ) :
    Complex.exp ((x : ℂ) * Complex.I) + Complex.exp ((-x : ℂ) * Complex.I) =
      (2 * Real.cos x : ℝ) := by
  rw [Complex.exp_mul_I, Complex.exp_mul_I, Complex.cos_neg, Complex.sin_neg]
  simp only [← Complex.ofReal_cos]
  push_cast
  ring

/-- The four explicit monomials recover the pre-existing almost Mathieu
operator, including its original cosine potential and phase normalization. -/
theorem almostMathieuOperator_eq_amoMagneticMonomials (α lam t : ℝ) :
    almostMathieuOperator α lam (2 * Real.pi * t) =
      amoMagneticMonomial α t (1, 0) + amoMagneticMonomial α t (-1, 0) +
      (lam : ℂ) • amoMagneticMonomial α t (0, 1) +
      (lam : ℂ) • amoMagneticMonomial α t (0, -1) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext j
  simp only [almostMathieuOperator_apply, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.smul_apply, lp.coeFn_add, lp.coeFn_smul, Pi.add_apply,
    Pi.smul_apply, smul_eq_mul, amoMagneticMonomial_apply]
  simp only [Int.zero_mul, magneticPhase_zero, one_mul, Int.one_mul,
    Int.neg_mul, Int.neg_one_mul, add_zero, mul_one]
  have hphase : magneticPhase t 1 * magneticPhase α j +
      magneticPhase t (-1) * magneticPhase α (-j) =
        (2 * Real.cos (2 * Real.pi * α * (j : ℝ) + 2 * Real.pi * t) : ℝ) := by
    simp only [magneticPhase, Int.cast_one, Int.cast_neg, mul_one, ← Complex.exp_add]
    convert exp_add_exp_neg_eq_two_cos
      (2 * Real.pi * α * (j : ℝ) + 2 * Real.pi * t) using 2 <;> push_cast <;> ring
  rw [sub_eq_add_neg]
  calc
    _ = u (j + 1) + u (j + -1) +
        (lam : ℂ) * (magneticPhase t 1 * magneticPhase α j +
          magneticPhase t (-1) * magneticPhase α (-j)) * u j := by
      rw [hphase]
      push_cast
      ring
    _ = _ := by ring

/-- Finite simultaneous magnetic/AMO polynomials. Using paired operators
retains their explicit coefficients without assuming faithfulness of a fiber. -/
def magneticAMOPolynomialSpace (α : ℝ) :
    Submodule ℂ (MagneticBoundedOperator × (ℝ → AMOBoundedOperator)) :=
  Submodule.span ℂ (Set.range (fun a : Site =>
    (magneticMonomial α a, fun t => amoMagneticMonomial α t a)))

theorem magneticAMOMonomial_mem (α : ℝ) (a : Site) :
    (magneticMonomial α a, fun t => amoMagneticMonomial α t a) ∈
      magneticAMOPolynomialSpace α :=
  Submodule.subset_span (Set.mem_range_self a)

theorem magneticAMOPolynomialSpace_one_mem (α : ℝ) :
    (1 : MagneticBoundedOperator × (ℝ → AMOBoundedOperator)) ∈
      magneticAMOPolynomialSpace α := by
  simpa only [magneticMonomial_origin, amoMagneticMonomial_origin] using
    magneticAMOMonomial_mem α origin

private theorem magneticAMOMonomial_mul (α : ℝ) (a b : Site) :
    (magneticMonomial α a, fun t => amoMagneticMonomial α t a) *
        (magneticMonomial α b, fun t => amoMagneticMonomial α t b) =
      magneticPhase α (b.2 * a.1) •
        (magneticMonomial α (a + b), fun t => amoMagneticMonomial α t (a + b)) := by
  apply Prod.ext
  · exact magneticMonomial_mul α a b
  · funext t
    exact amoMagneticMonomial_mul α t a b

theorem magneticAMOPolynomialSpace_mul_mem (α : ℝ)
    {A B : MagneticBoundedOperator × (ℝ → AMOBoundedOperator)}
    (hA : A ∈ magneticAMOPolynomialSpace α) (hB : B ∈ magneticAMOPolynomialSpace α) :
    A * B ∈ magneticAMOPolynomialSpace α := by
  induction hA, hB using Submodule.span_induction₂ with
  | mem_mem A B hA hB =>
    obtain ⟨a, rfl⟩ := hA
    obtain ⟨b, rfl⟩ := hB
    rw [magneticAMOMonomial_mul]
    exact (magneticAMOPolynomialSpace α).smul_mem _ (magneticAMOMonomial_mem α (a + b))
  | zero_left B hB => simp
  | zero_right A hA => simp
  | add_left A C B hA hC hB ihA ihC =>
    simpa only [add_mul] using (magneticAMOPolynomialSpace α).add_mem ihA ihC
  | add_right A B C hA hB hC ihB ihC =>
    simpa only [mul_add] using (magneticAMOPolynomialSpace α).add_mem ihB ihC
  | smul_left c A B hA hB ih =>
    simpa only [smul_mul_assoc] using (magneticAMOPolynomialSpace α).smul_mem c ih
  | smul_right c A B hA hB ih =>
    simpa only [mul_smul_comm] using (magneticAMOPolynomialSpace α).smul_mem c ih

/-- Every finite paired polynomial has the same averaged root functional. -/
theorem magneticAMOPolynomialSpace_root_mean (α : ℝ)
    {A : MagneticBoundedOperator × (ℝ → AMOBoundedOperator)}
    (hA : A ∈ magneticAMOPolynomialSpace α) :
    IntervalIntegrable (fun t => amoRootState (A.2 t)) volume (0 : ℝ) 1 ∧
      (∫ t in (0 : ℝ)..1, amoRootState (A.2 t)) = rootTrace A.1 := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    exact ⟨amoRootState_amoMagneticMonomial_intervalIntegrable α a,
      integral_amoRootState_amoMagneticMonomial α a⟩
  | zero => simp [intervalIntegrable_const]
  | add A B hA hB ihA ihB =>
    simp only [Prod.fst_add, Prod.snd_add, Pi.add_apply, map_add]
    exact ⟨ihA.1.add ihB.1, by rw [intervalIntegral.integral_add ihA.1 ihB.1, ihA.2, ihB.2]⟩
  | smul c A hA ih =>
    simp only [Prod.smul_fst, Prod.smul_snd, Pi.smul_apply, map_smul, smul_eq_mul]
    exact ⟨ih.1.const_mul c, by rw [intervalIntegral.integral_const_mul, ih.2]⟩

theorem magneticAMOHamiltonian_mem (α lam : ℝ) :
    (hOperator α (lam : ℂ), fun t => almostMathieuOperator α lam (2 * Real.pi * t)) ∈
      magneticAMOPolynomialSpace α := by
  have heq :
      (hOperator α (lam : ℂ), fun t => almostMathieuOperator α lam (2 * Real.pi * t)) =
        (magneticMonomial α (1, 0), fun t => amoMagneticMonomial α t (1, 0)) +
        (magneticMonomial α (-1, 0), fun t => amoMagneticMonomial α t (-1, 0)) +
        (lam : ℂ) • (magneticMonomial α (0, 1), fun t => amoMagneticMonomial α t (0, 1)) +
        (lam : ℂ) • (magneticMonomial α (0, -1), fun t => amoMagneticMonomial α t (0, -1)) := by
    apply Prod.ext
    · exact hOperator_eq_magneticMonomials α (lam : ℂ)
    · funext t
      exact almostMathieuOperator_eq_amoMagneticMonomials α lam t
  rw [heq]
  exact (magneticAMOPolynomialSpace α).add_mem
    ((magneticAMOPolynomialSpace α).add_mem
      ((magneticAMOPolynomialSpace α).add_mem
        (magneticAMOMonomial_mem α (1, 0)) (magneticAMOMonomial_mem α (-1, 0)))
      ((magneticAMOPolynomialSpace α).smul_mem (lam : ℂ) (magneticAMOMonomial_mem α (0, 1))))
    ((magneticAMOPolynomialSpace α).smul_mem (lam : ℂ) (magneticAMOMonomial_mem α (0, -1)))

theorem magneticAMOPolynomialSpace_pow_mem (α : ℝ)
    {A : MagneticBoundedOperator × (ℝ → AMOBoundedOperator)}
    (hA : A ∈ magneticAMOPolynomialSpace α) (n : ℕ) :
    A ^ n ∈ magneticAMOPolynomialSpace α := by
  induction n with
  | zero => simpa only [pow_zero] using magneticAMOPolynomialSpace_one_mem α
  | succ n ih =>
    rw [pow_succ]
    exact magneticAMOPolynomialSpace_mul_mem α ih hA

/-- Equality of every power moment of the two pre-existing physical operators. -/
theorem integral_amoRootState_pow (α lam : ℝ) (n : ℕ) :
    (∫ t in (0 : ℝ)..1,
      amoRootState ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ n)) =
        rootTrace ((hOperator α (lam : ℂ)) ^ n) := by
  exact (magneticAMOPolynomialSpace_root_mean α
    (magneticAMOPolynomialSpace_pow_mem α (magneticAMOHamiltonian_mem α lam) n)).2

/-- Real polynomial evaluation preserves the explicitly paired polynomial span. -/
theorem magneticAMOPolynomialSpace_aeval_mem (α : ℝ)
    {A : MagneticBoundedOperator × (ℝ → AMOBoundedOperator)}
    (hA : A ∈ magneticAMOPolynomialSpace α) (p : ℝ[X]) :
    (Polynomial.aeval A.1 p, fun t => Polynomial.aeval (A.2 t) p) ∈
      magneticAMOPolynomialSpace α := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
    simpa only [map_add] using (magneticAMOPolynomialSpace α).add_mem hp hq
  | monomial n c =>
    have h := (magneticAMOPolynomialSpace α).smul_mem (c : ℂ)
      (magneticAMOPolynomialSpace_pow_mem α hA n)
    simpa only [Polynomial.aeval_monomial, Algebra.algebraMap_eq_smul_one,
      smul_mul_assoc, one_mul, Complex.coe_smul] using h

/-- Polynomial root tests agree under the normalized physical phase average. -/
theorem integral_amoRootState_aeval (α lam : ℝ) (p : ℝ[X]) :
    (∫ t in (0 : ℝ)..1,
      amoRootState (Polynomial.aeval (almostMathieuOperator α lam (2 * Real.pi * t)) p)) =
        rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p) := by
  exact (magneticAMOPolynomialSpace_root_mean α
    (magneticAMOPolynomialSpace_aeval_mem α (magneticAMOHamiltonian_mem α lam) p)).2

theorem amoRootState_aeval_intervalIntegrable (α lam : ℝ) (p : ℝ[X]) :
    IntervalIntegrable (fun t =>
      amoRootState (Polynomial.aeval (almostMathieuOperator α lam (2 * Real.pi * t)) p))
      volume (0 : ℝ) 1 := by
  exact (magneticAMOPolynomialSpace_root_mean α
    (magneticAMOPolynomialSpace_aeval_mem α (magneticAMOHamiltonian_mem α lam) p)).1

end CriticalDTM

import DTM.Background.Realization.AMOPhaseSpectrum
import DTM.Background.Realization.AMOPhaseFaithful
import DTM.Background.Realization.AMOMagneticMeasureBridge
import DTM.Background.Labels.MagneticLabelUniqueness
import Mathlib.Topology.MetricSpace.HausdorffDistance

/-!
# The actual AMO spectrum equals the actual magnetic spectrum

The proved phase-average identity for continuous tests, together with the two
proved faithfulness statements, identifies which continuous functions vanish
on the two spectra. Distance to a closed spectrum separates any point outside
it. Phase independence at irrational frequency then identifies each actual
one-dimensional AMO spectrum with the actual magnetic operator spectrum.

No spectral identification, trace identity, or Dry Ten Martini theorem is
assumed in this module.
-/

noncomputable section

namespace CriticalDTM

open Set MeasureTheory
open scoped ContinuousFunctionalCalculus

/-- The squared AMO root CFC norm has exactly the actual magnetic trace average. -/
theorem integral_amo_cfc_norm_sq_eq_magneticTraceReal (α lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    (∫ t in (0 : ℝ)..1,
      ‖cfc f (almostMathieuOperator α lam (2 * Real.pi * t)) amoRoot‖ ^ 2) =
        magneticTraceReal α
          (star (cfc f (magneticAlgebraHamiltonian α lam)) *
            cfc f (magneticAlgebraHamiltonian α lam)) := by
  have hamo (θ : ℝ) :
      amoRootStateReal (cfc (fun x => f x * f x) (almostMathieuOperator α lam θ)) =
        ‖cfc f (almostMathieuOperator α lam θ) amoRoot‖ ^ 2 := by
    rw [cfc_mul f f _ hf.continuousOn hf.continuousOn]
    simpa only [(cfc_predicate f (almostMathieuOperator α lam θ)).star_eq] using
      amoRootStateReal_star_mul_self (cfc f (almostMathieuOperator α lam θ))
  have h := integral_amoRootStateReal_cfc α lam (fun x => f x * f x) (hf.mul hf)
  simp_rw [hamo] at h
  rw [← magneticAlgebraHamiltonian_cfc_coe α lam (fun x => f x * f x) (hf.mul hf)] at h
  change (∫ t in (0 : ℝ)..1,
    ‖cfc f (almostMathieuOperator α lam (2 * Real.pi * t)) amoRoot‖ ^ 2) =
      magneticTraceReal α (cfc (fun x => f x * f x) (magneticAlgebraHamiltonian α lam)) at h
  rw [cfc_mul f f _ hf.continuousOn hf.continuousOn] at h
  simpa only [(cfc_predicate f (magneticAlgebraHamiltonian α lam)).star_eq] using h

/-- Continuous functional-calculus vanishing in the actual magnetic algebra
is equivalent to vanishing at every phase of the actual AMO family. -/
theorem magnetic_cfc_eq_zero_iff_amo_all_phases (α lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    cfc f (magneticAlgebraHamiltonian α lam) = 0 ↔
      ∀ θ : ℝ, cfc f (almostMathieuOperator α lam θ) = 0 := by
  constructor
  · intro hmag
    apply amo_cfc_eq_zero_of_phase_integral_norm_sq_zero α lam f hf
    rw [integral_amo_cfc_norm_sq_eq_magneticTraceReal α lam f hf, hmag,
      star_zero, zero_mul, map_zero]
  · intro hamo
    apply magneticTraceReal_faithful α (cfc f (magneticAlgebraHamiltonian α lam))
    rw [← integral_amo_cfc_norm_sq_eq_magneticTraceReal α lam f hf]
    simp [hamo]

/-- Every phase's AMO spectrum is contained in the magnetic spectrum, even
without irrationality. The proof uses the distance to the latter spectrum. -/
theorem almostMathieuRealSpectrumSet_subset_magneticRealSpectrumSet (α lam θ : ℝ) :
    almostMathieuRealSpectrumSet α lam θ ⊆ magneticRealSpectrumSet α lam := by
  rw [almostMathieuRealSpectrumSet_eq_realSpectrum, magneticRealSpectrumSet_eq_algebraSpectrum]
  let f : ℝ → ℝ := fun x => Metric.infDist x (spectrum ℝ (magneticAlgebraHamiltonian α lam))
  have hf : Continuous f := Metric.continuous_infDist_pt _
  have hmag : cfc f (magneticAlgebraHamiltonian α lam) = 0 := by
    calc
      _ = cfc (0 : ℝ → ℝ) (magneticAlgebraHamiltonian α lam) :=
        cfc_congr (fun _ hx => Metric.infDist_zero_of_mem hx)
      _ = 0 := cfc_zero ℝ _
  have hamo := (magnetic_cfc_eq_zero_iff_amo_all_phases α lam f hf).mp hmag θ
  have hvalue := eqOn_of_cfc_eq_cfc
    (hamo.trans (cfc_zero ℝ (almostMathieuOperator α lam θ)).symm)
    hf.continuousOn continuousOn_const (almostMathieuOperator_isSelfAdjoint α lam θ)
  intro x hx
  exact ((spectrum.isClosed (𝕜 := ℝ) (magneticAlgebraHamiltonian α lam)).mem_iff_infDist_zero
    (magneticAlgebraHamiltonian_isSelfAdjoint α lam).spectrum_nonempty).mpr (hvalue hx)

/-- Irrational phase independence gives the reverse inclusion in each actual
AMO phase, using distance to that phase's spectrum and magnetic faithfulness. -/
theorem magneticRealSpectrumSet_subset_almostMathieuRealSpectrumSet {α : ℝ}
    (hα : Irrational α) (lam θ : ℝ) :
    magneticRealSpectrumSet α lam ⊆ almostMathieuRealSpectrumSet α lam θ := by
  rw [magneticRealSpectrumSet_eq_algebraSpectrum, almostMathieuRealSpectrumSet_eq_realSpectrum]
  let f : ℝ → ℝ := fun x => Metric.infDist x (spectrum ℝ (almostMathieuOperator α lam θ))
  have hf : Continuous f := Metric.continuous_infDist_pt _
  have hphases (φ : ℝ) : spectrum ℝ (almostMathieuOperator α lam φ) =
      spectrum ℝ (almostMathieuOperator α lam θ) := by
    simpa only [almostMathieuRealSpectrumSet_eq_realSpectrum] using
      almostMathieuRealSpectrumSet_phase_independent hα lam φ θ
  have hamo (φ : ℝ) : cfc f (almostMathieuOperator α lam φ) = 0 := by
    calc
      _ = cfc (0 : ℝ → ℝ) (almostMathieuOperator α lam φ) := by
        apply cfc_congr
        intro x hx
        exact Metric.infDist_zero_of_mem (hphases φ ▸ hx)
      _ = 0 := cfc_zero ℝ _
  have hmag := (magnetic_cfc_eq_zero_iff_amo_all_phases α lam f hf).mpr hamo
  have hvalue := eqOn_of_cfc_eq_cfc
    (hmag.trans (cfc_zero ℝ (magneticAlgebraHamiltonian α lam)).symm)
    hf.continuousOn continuousOn_const (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
  intro x hx
  exact ((spectrum.isClosed (𝕜 := ℝ) (almostMathieuOperator α lam θ)).mem_iff_infDist_zero
    (almostMathieuOperator_isSelfAdjoint α lam θ).spectrum_nonempty).mpr (hvalue hx)

/-- The pre-existing real spectral sets of the actual one-dimensional AMO and
actual magnetic lattice operator agree, at every phase and real coupling. -/
theorem almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet {α : ℝ}
    (hα : Irrational α) (lam θ : ℝ) :
    almostMathieuRealSpectrumSet α lam θ = magneticRealSpectrumSet α lam :=
  Set.Subset.antisymm
    (almostMathieuRealSpectrumSet_subset_magneticRealSpectrumSet α lam θ)
    (magneticRealSpectrumSet_subset_almostMathieuRealSpectrumSet hα lam θ)

/-- The equality also holds for the full complex spectra of the actual
operators on their different Hilbert spaces, not only for a named real slice. -/
theorem almostMathieuOperator_spectrum_eq_magnetic {α : ℝ}
    (hα : Irrational α) (lam θ : ℝ) :
    spectrum ℂ (almostMathieuOperator α lam θ) = spectrum ℂ (hOperator α (lam : ℂ)) := by
  have hsets := almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα lam θ
  ext z
  constructor
  · intro hz
    have hre := (almostMathieuOperator_isSelfAdjoint α lam θ).mem_spectrum_eq_re hz
    have hx : z.re ∈ almostMathieuRealSpectrumSet α lam θ := by
      change (z.re : ℂ) ∈ spectrum ℂ (almostMathieuOperator α lam θ)
      rwa [← hre]
    rw [hsets] at hx
    change (z.re : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ)) at hx
    rwa [← hre] at hx
  · intro hz
    have hre := (hOperator_isSelfAdjoint α lam).mem_spectrum_eq_re hz
    have hx : z.re ∈ magneticRealSpectrumSet α lam := by
      change (z.re : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ))
      rwa [← hre]
    rw [← hsets] at hx
    change (z.re : ℂ) ∈ spectrum ℂ (almostMathieuOperator α lam θ) at hx
    rwa [← hre] at hx

end CriticalDTM

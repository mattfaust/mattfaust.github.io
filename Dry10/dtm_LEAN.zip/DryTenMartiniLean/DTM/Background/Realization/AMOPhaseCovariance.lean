import DTM.Background.Realization.AlmostMathieu

/-!
# Integer-shift covariance of the actual almost Mathieu operator

The shift acts on the existing `ℓ²(ℤ, ℂ)` by `u(n) ↦ u(n+k)`.
Its adjoint is the inverse shift. Conjugating the actual receiving row changes
its radian phase by `2παk`; adding an integer multiple of `2π` leaves the
operator unchanged. The resulting spectral identities use genuine unitary
conjugation, not a replacement definition of the spectrum.
-/

noncomputable section

namespace CriticalDTM

/-- Integer translation, with its inverse, as a unitary equivalence. -/
def amoIntegerShiftEquiv (k : ℤ) : AMOHilbert ≃ₗᵢ[ℂ] AMOHilbert :=
  amoReindexEquiv
    { toFun := fun n => n + k
      invFun := fun n => n - k
      left_inv := by intro n; simp
      right_inv := by intro n; simp }

/-- The bounded receiving-row shift by an arbitrary integer. -/
def amoIntegerShift (k : ℤ) : AMOBoundedOperator := amoIntegerShiftEquiv k

@[simp] theorem amoIntegerShift_apply (k : ℤ) (u : AMOHilbert) (n : ℤ) :
    amoIntegerShift k u n = u (n + k) := rfl

@[simp] theorem amoIntegerShift_star_apply (k : ℤ) (u : AMOHilbert) (n : ℤ) :
    star (amoIntegerShift k) u n = u (n - k) := by
  unfold amoIntegerShift
  rw [LinearIsometryEquiv.star_eq_symm]
  rfl

@[simp] theorem amoIntegerShift_mul_star (k : ℤ) :
    amoIntegerShift k * star (amoIntegerShift k) = 1 := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext n
  simp

@[simp] theorem amoIntegerShift_star_mul (k : ℤ) :
    star (amoIntegerShift k) * amoIntegerShift k = 1 := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext n
  simp

/-- Translation intertwines the actual operators at the translated phases. -/
theorem almostMathieuOperator_phase_intertwining (α lam θ : ℝ) (k : ℤ) :
    amoIntegerShift k * almostMathieuOperator α lam θ =
      almostMathieuOperator α lam (θ + 2 * Real.pi * α * (k : ℝ)) * amoIntegerShift k := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext n
  simp only [ContinuousLinearMap.mul_apply, amoIntegerShift_apply,
    almostMathieuOperator_apply, Int.cast_add]
  have hphase : 2 * Real.pi * α * ((n : ℝ) + (k : ℝ)) + θ =
      2 * Real.pi * α * (n : ℝ) + (θ + 2 * Real.pi * α * (k : ℝ)) := by ring
  rw [hphase]
  congr 2 <;> ring_nf

/-- Unitary integer-shift covariance, with the physical radian-phase sign. -/
theorem almostMathieuOperator_phase_covariance (α lam θ : ℝ) (k : ℤ) :
    amoIntegerShift k * almostMathieuOperator α lam θ * star (amoIntegerShift k) =
      almostMathieuOperator α lam (θ + 2 * Real.pi * α * (k : ℝ)) := by
  rw [almostMathieuOperator_phase_intertwining, mul_assoc,
    amoIntegerShift_mul_star, mul_one]

/-- The true operator, not only its spectrum, is `2π`-periodic in phase. -/
theorem almostMathieuOperator_phase_periodic (α lam : ℝ) :
    Function.Periodic (almostMathieuOperator α lam) (2 * Real.pi) := by
  intro θ
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext n
  simp only [almostMathieuOperator_apply, ← add_assoc, Real.cos_add_two_pi]

@[simp] theorem almostMathieuOperator_phase_add_int_mul_two_pi
    (α lam θ : ℝ) (m : ℤ) :
    almostMathieuOperator α lam (θ + (m : ℝ) * (2 * Real.pi)) =
      almostMathieuOperator α lam θ :=
  (almostMathieuOperator_phase_periodic α lam).int_mul m θ

/-- Unitary conjugation preserves the actual complex spectrum along each orbit. -/
theorem almostMathieuOperator_spectrum_phase_shift (α lam θ : ℝ) (k : ℤ) :
    spectrum ℂ (almostMathieuOperator α lam (θ + 2 * Real.pi * α * (k : ℝ))) =
      spectrum ℂ (almostMathieuOperator α lam θ) := by
  let U : AMOBoundedOperatorˣ :=
    ⟨amoIntegerShift k, star (amoIntegerShift k),
      amoIntegerShift_mul_star k, amoIntegerShift_star_mul k⟩
  rw [← almostMathieuOperator_phase_covariance]
  exact spectrum.units_conjugate (u := U)

end CriticalDTM

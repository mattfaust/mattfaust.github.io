import DTM.Background.Realization.AMOSpectralMeasure
import DTM.Background.Realization.AMOPhaseCovariance
import Mathlib.Algebra.Order.Floor.Ring

/-!
# Faithfulness of phase-averaged actual AMO root tests

A nonnegative continuous periodic function with zero integral vanishes
pointwise. Applied to the actual root CFC norm, phase covariance transports
that vanishing to every coordinate vector. Thus a zero phase-averaged squared
CFC root norm forces the actual CFC operator to be zero at every phase.

No trace property of an individual one-dimensional root state is assumed.
-/

noncomputable section
namespace CriticalDTM

open Set MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

/-- Positivity and continuity promote a zero period integral to pointwise
vanishing, including the endpoints of the period. -/
theorem continuous_periodic_nonneg_eq_zero_of_integral_zero
    {f : ℝ → ℝ} (hf : Continuous f) (hp : Function.Periodic f 1)
    (hnonneg : ∀ x, 0 ≤ f x) (hint : (∫ t in (0 : ℝ)..1, f t) = 0) :
    ∀ x, f x = 0 := by
  have hclosed : ∀ x ∈ Icc (0 : ℝ) 1, f x = 0 := by
    intro x hx
    apply le_antisymm _ (hnonneg x)
    by_contra h
    have hpos : 0 < f x := lt_of_not_ge h
    have hi := intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt
      (show (0 : ℝ) < 1 by norm_num) continuousOn_const hf.continuousOn
      (fun t _ => hnonneg t) ⟨x, hx, hpos⟩
    simp only [intervalIntegral.integral_zero, hint, lt_self_iff_false] at hi
  intro x
  have hperiod := hp.int_mul (Int.floor x) (Int.fract x)
  simp only [mul_one, Int.fract_add_floor] at hperiod
  exact hperiod.trans (hclosed _ ⟨Int.fract_nonneg x, (Int.fract_lt_one x).le⟩)

/-- Unitary conjugation as an actual star algebra homomorphism. -/
def amoShiftConjugation (k : ℤ) : AMOBoundedOperator →⋆ₐ[ℂ] AMOBoundedOperator where
  toFun A := amoIntegerShift k * A * star (amoIntegerShift k)
  map_one' := by simp
  map_mul' := by
    intro A B
    simp only [mul_assoc, ← mul_assoc (star (amoIntegerShift k)),
      amoIntegerShift_star_mul, one_mul]
  map_zero' := by simp
  map_add' := by intro A B; simp only [mul_add, add_mul]
  commutes' := by
    intro c
    simp only [Algebra.algebraMap_eq_smul_one, mul_smul_comm, mul_one,
      smul_mul_assoc, amoIntegerShift_mul_star]
  map_star' := by intro A; simp only [star_mul, star_star, mul_assoc]

@[simp] theorem amoShiftConjugation_apply (k : ℤ) (A : AMOBoundedOperator) :
    amoShiftConjugation k A = amoIntegerShift k * A * star (amoIntegerShift k) := rfl

theorem amoShiftConjugation_continuous (k : ℤ) : Continuous (amoShiftConjugation k) :=
  (continuous_const.mul continuous_id).mul continuous_const

/-- The same actual phase covariance holds after continuous functional calculus. -/
theorem amo_cfc_phase_covariance (α lam θ : ℝ) (k : ℤ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    amoIntegerShift k * cfc f (almostMathieuOperator α lam θ) * star (amoIntegerShift k) =
      cfc f (almostMathieuOperator α lam (θ + 2 * Real.pi * α * (k : ℝ))) := by
  have hcov : amoShiftConjugation k (almostMathieuOperator α lam θ) =
      almostMathieuOperator α lam (θ + 2 * Real.pi * α * (k : ℝ)) :=
    almostMathieuOperator_phase_covariance α lam θ k
  have hself : IsSelfAdjoint (amoShiftConjugation k (almostMathieuOperator α lam θ)) := by
    rw [hcov]
    exact almostMathieuOperator_isSelfAdjoint _ _ _
  have h := (amoShiftConjugation k).map_cfc f (almostMathieuOperator α lam θ)
    hf.continuousOn (amoShiftConjugation_continuous k)
    (almostMathieuOperator_isSelfAdjoint α lam θ) hself
  simpa only [amoShiftConjugation_apply, almostMathieuOperator_phase_covariance] using h

/-- A bounded operator that kills every coordinate vector of actual `ℓ²(ℤ)` is zero. -/
theorem amoOperator_eq_zero_of_single (A : AMOBoundedOperator)
    (hA : ∀ n : ℤ, A (lp.single 2 n (1 : ℂ)) = 0) : A = 0 := by
  have ha : ContinuousLinearMap.adjoint A = 0 := by
    apply ContinuousLinearMap.ext
    intro u
    apply lp.ext
    funext n
    have hi := ContinuousLinearMap.adjoint_inner_right A (lp.single 2 n (1 : ℂ)) u
    rw [hA n] at hi
    simpa only [lp.inner_single_left, inner_zero_left, RCLike.inner_apply,
      map_one, mul_one, ContinuousLinearMap.zero_apply, lp.coeFn_zero, Pi.zero_apply] using hi
  have h := congrArg ContinuousLinearMap.adjoint ha
  simpa only [ContinuousLinearMap.adjoint_adjoint, map_zero] using h

/-- Phase covariance transports a zero root CFC vector to the whole lattice. -/
theorem amo_cfc_eq_zero_of_all_phase_roots_zero
    (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f)
    (hroot : ∀ θ : ℝ, cfc f (almostMathieuOperator α lam θ) amoRoot = 0) :
    ∀ θ : ℝ, cfc f (almostMathieuOperator α lam θ) = 0 := by
  intro θ
  apply amoOperator_eq_zero_of_single
  intro n
  have hcov := amo_cfc_phase_covariance α lam θ n f hf
  have h := congrArg (fun A : AMOBoundedOperator =>
      star (amoIntegerShift n) (A amoRoot)) hcov
  have hsingle : star (amoIntegerShift n) amoRoot = lp.single 2 n (1 : ℂ) := by
    apply lp.ext
    funext j
    simp only [amoIntegerShift_star_apply, amoRoot, lp.coeFn_single, Pi.single_apply]
    simp [sub_eq_zero]
  dsimp only at h
  rw [hroot, map_zero] at h
  simpa only [ContinuousLinearMap.mul_apply,
    ← ContinuousLinearMap.mul_apply (star (amoIntegerShift n)) (amoIntegerShift n),
    amoIntegerShift_star_mul, ContinuousLinearMap.one_apply, hsingle] using h

/-- CFC depends continuously on the actual radian phase in operator norm. -/
theorem continuous_amo_cfc_phase (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f) :
    Continuous (fun θ => cfc f (almostMathieuOperator α lam θ)) := by
  apply continuous_iff_continuousAt.mpr
  intro θ
  exact continuousAt_cfc_of_continuous (almostMathieuOperator α lam) θ
    (continuous_almostMathieuOperator_phase α lam).continuousAt f hf
    (Filter.Eventually.of_forall (almostMathieuOperator_isSelfAdjoint α lam))

/-- Faithfulness of phase-averaged squared root CFC norms. This is not
faithfulness or cyclicity of a single phase's root state on all operators. -/
theorem amo_cfc_eq_zero_of_phase_integral_norm_sq_zero
    (α lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f)
    (hint : (∫ t in (0 : ℝ)..1,
      ‖cfc f (almostMathieuOperator α lam (2 * Real.pi * t)) amoRoot‖ ^ 2) = 0) :
    ∀ θ : ℝ, cfc f (almostMathieuOperator α lam θ) = 0 := by
  let F : ℝ → ℝ := fun t =>
    ‖cfc f (almostMathieuOperator α lam (2 * Real.pi * t)) amoRoot‖ ^ 2
  have hFcont : Continuous F := by
    exact (((continuous_amo_cfc_phase α lam f hf).comp
      (continuous_const.mul continuous_id)).clm_apply continuous_const).norm.pow 2
  have hFper : Function.Periodic F 1 := by
    intro t
    change ‖cfc f (almostMathieuOperator α lam (2 * Real.pi * (t + 1))) amoRoot‖ ^ 2 = _
    rw [mul_add, mul_one, almostMathieuOperator_phase_periodic α lam]
  have hFzero := continuous_periodic_nonneg_eq_zero_of_integral_zero
    hFcont hFper (fun _ => sq_nonneg _) hint
  apply amo_cfc_eq_zero_of_all_phase_roots_zero α lam f hf
  intro θ
  have h := hFzero (θ / (2 * Real.pi))
  have hpi : (2 : ℝ) * Real.pi ≠ 0 := ne_of_gt (mul_pos (by norm_num) Real.pi_pos)
  dsimp only [F] at h
  rw [mul_div_cancel₀ θ hpi] at h
  exact norm_eq_zero.mp (sq_eq_zero_iff.mp h)

end CriticalDTM

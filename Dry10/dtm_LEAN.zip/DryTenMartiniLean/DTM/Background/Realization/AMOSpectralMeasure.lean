import DTM.Background.Realization.AlmostMathieu
import DTM.Background.Support.CFCParameterContinuity
import Mathlib.MeasureTheory.Integral.RieszMarkovKakutani.Real
import Mathlib.MeasureTheory.Measure.Typeclasses.Probability
import Mathlib.MeasureTheory.Measure.Portmanteau
import Mathlib.MeasureTheory.Constructions.BorelSpace.Order
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic

/-!
# The AMO root spectral measures and phase-averaged IDS

For each actual one-dimensional operator, RMK constructs the probability
measure representing its unit root vector state on the continuous functional
calculus. Positivity uses a norm square; no cyclicity is asserted for this state.

The IDS is defined by the conventional phase average of lower spectral masses.
The operator phase is in radians, so the normalized average over `t ∈ [0,1]`
uses operator phase `2πt`. This is not an empirical finite-volume limit and is
not defined by renaming the two-dimensional magnetic lower mass. Operator-norm
continuity and the portmanteau theorem prove that the averaged half-line masses
are measurable and integrable. Convergence of finite-volume counts and
identification with the magnetic measure are separate obligations.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory CompactlySupported
open scoped ContinuousFunctionalCalculus Topology

/-- The actual physical root vector state, not a trace on all operators. -/
def amoRootState : AMOBoundedOperator →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun A => A amoRoot 0
      map_add' := by intro A B; simp
      map_smul' := by intro c A; simp }
    1 (fun A => by
      calc
        ‖A amoRoot 0‖ ≤ ‖A amoRoot‖ :=
          lp.norm_apply_le_norm (by norm_num) (A amoRoot) 0
        _ ≤ ‖A‖ * ‖amoRoot‖ := A.le_opNorm amoRoot
        _ = 1 * ‖A‖ := by simp [amoRoot_norm])

@[simp] theorem amoRootState_apply (A : AMOBoundedOperator) :
    amoRootState A = A amoRoot 0 := rfl

theorem amoRootState_eq_inner (A : AMOBoundedOperator) :
    amoRootState A = @inner ℂ AMOHilbert _ amoRoot (A amoRoot) := by
  rw [amoRoot, lp.inner_single_left]
  simp [amoRootState, amoRoot]

@[simp] theorem amoRootState_one : amoRootState (1 : AMOBoundedOperator) = 1 := by
  simp

def amoRootStateReal : AMOBoundedOperator →L[ℝ] ℝ :=
  Complex.reCLM.comp (amoRootState.restrictScalars ℝ)

@[simp] theorem amoRootStateReal_apply (A : AMOBoundedOperator) :
    amoRootStateReal A = (amoRootState A).re := rfl

@[simp] theorem amoRootStateReal_one : amoRootStateReal 1 = 1 := by
  simp

theorem amoRootStateReal_star_mul_self (A : AMOBoundedOperator) :
    amoRootStateReal (star A * A) = ‖A amoRoot‖ ^ 2 := by
  rw [amoRootStateReal_apply, amoRootState_eq_inner]
  change (@inner ℂ AMOHilbert _ amoRoot (star A (A amoRoot))).re = _
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  exact inner_self_eq_norm_sq (𝕜 := ℂ) _

theorem amoRootStateReal_star_mul_self_nonneg (A : AMOBoundedOperator) :
    0 ≤ amoRootStateReal (star A * A) := by
  rw [amoRootStateReal_star_mul_self]
  exact sq_nonneg _

/-- The compact real spectrum of the actual one-dimensional operator. -/
abbrev AMORealSpectrum (α lam θ : ℝ) : Type :=
  spectrum ℝ (almostMathieuOperator α lam θ)

private def amoCompactTestToContinuous {X : Type*} [TopologicalSpace X] :
    C_c(X, ℝ) →ₗ[ℝ] C(X, ℝ) where
  toFun := fun f => f.toContinuousMap
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- The root vector state applied to the actual continuous functional calculus. -/
def amoSpectralFunctional (α lam θ : ℝ) :
    C_c(AMORealSpectrum α lam θ, ℝ) →ₗ[ℝ] ℝ :=
  amoRootStateReal.toLinearMap.comp
    ((cfcL (almostMathieuOperator_isSelfAdjoint α lam θ)).toLinearMap.comp
      amoCompactTestToContinuous)

set_option maxHeartbeats 800000 in
theorem amoSpectralFunctional_nonneg (α lam θ : ℝ)
    (f : C_c(AMORealSpectrum α lam θ, ℝ)) (hf : 0 ≤ f) :
    0 ≤ amoSpectralFunctional α lam θ f := by
  let g : C(AMORealSpectrum α lam θ, ℝ) :=
    ⟨fun x => Real.sqrt (f x), Real.continuous_sqrt.comp f.continuous⟩
  have hsq : g * g = f.toContinuousMap := by
    ext x
    exact Real.mul_self_sqrt (hf x)
  let hH := almostMathieuOperator_isSelfAdjoint α lam θ
  have hfact : cfcHom hH f.toContinuousMap = star (cfcHom hH g) * cfcHom hH g := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul, hsq]
  change 0 ≤ amoRootStateReal (cfcHom hH f.toContinuousMap)
  rw [hfact]
  exact amoRootStateReal_star_mul_self_nonneg (cfcHom hH g)

/-- The root spectral measure, constructed rather than postulated. -/
def amoSpectralMeasure (α lam θ : ℝ) : Measure (AMORealSpectrum α lam θ) :=
  RealRMK.rieszMeasure (amoSpectralFunctional_nonneg α lam θ)

theorem amoSpectralMeasure_integral_compact (α lam θ : ℝ)
    (f : C_c(AMORealSpectrum α lam θ, ℝ)) :
    ∫ x, f x ∂amoSpectralMeasure α lam θ =
      amoRootStateReal
        (cfcHom (almostMathieuOperator_isSelfAdjoint α lam θ) f.toContinuousMap) :=
  RealRMK.integral_rieszMeasure (amoSpectralFunctional_nonneg α lam θ) f

theorem amoSpectralMeasure_integral (α lam θ : ℝ)
    (f : C(AMORealSpectrum α lam θ, ℝ)) :
    ∫ x, f x ∂amoSpectralMeasure α lam θ =
      amoRootStateReal (cfcHom (almostMathieuOperator_isSelfAdjoint α lam θ) f) := by
  let fc : C_c(AMORealSpectrum α lam θ, ℝ) :=
    { toContinuousMap := f
      hasCompactSupport' := HasCompactSupport.of_compactSpace f }
  exact amoSpectralMeasure_integral_compact α lam θ fc

/-- The unit root and the constant-one test prove normalization. -/
instance amoSpectralMeasure_isProbabilityMeasure (α lam θ : ℝ) :
    IsProbabilityMeasure (amoSpectralMeasure α lam θ) := by
  constructor
  apply (ENNReal.toReal_eq_one_iff _).mp
  have h := amoSpectralMeasure_integral α lam θ (1 : C(AMORealSpectrum α lam θ, ℝ))
  simpa only [ContinuousMap.one_apply, integral_const, smul_eq_mul, mul_one,
    map_one, amoRootStateReal_one, measureReal_def] using h

/-- The actual root measure pushed from the compact spectrum to real energies. -/
def amoRealSpectralMeasure (α lam θ : ℝ) : Measure ℝ :=
  (amoSpectralMeasure α lam θ).map (fun x : AMORealSpectrum α lam θ => (x : ℝ))

instance amoRealSpectralMeasure_isProbabilityMeasure (α lam θ : ℝ) :
    IsProbabilityMeasure (amoRealSpectralMeasure α lam θ) :=
  isProbabilityMeasure_map continuous_subtype_val.measurable.aemeasurable

/-- Continuous tests recover the root vector state of the actual AMO. -/
theorem amoRealSpectralMeasure_integral (α lam θ : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂amoRealSpectralMeasure α lam θ =
      amoRootStateReal
        (cfcHom (almostMathieuOperator_isSelfAdjoint α lam θ)
          (⟨fun x => f x, hf.comp continuous_subtype_val⟩ :
            C(AMORealSpectrum α lam θ, ℝ))) := by
  rw [amoRealSpectralMeasure,
    integral_map continuous_subtype_val.measurable.aemeasurable hf.aestronglyMeasurable]
  exact amoSpectralMeasure_integral α lam θ
    (⟨fun x => f x, hf.comp continuous_subtype_val⟩ : C(AMORealSpectrum α lam θ, ℝ))

theorem amoRealSpectralMeasure_integral_cfc (α lam θ : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂amoRealSpectralMeasure α lam θ =
      amoRootStateReal (cfc f (almostMathieuOperator α lam θ)) := by
  rw [cfc_apply f (almostMathieuOperator α lam θ)
    (almostMathieuOperator_isSelfAdjoint α lam θ) hf.continuousOn]
  exact amoRealSpectralMeasure_integral α lam θ f hf

/-- The mass of actual AMO root spectral energies strictly below the cut. -/
def amoRootLowerMass (α lam θ energy : ℝ) : ℝ :=
  (amoRealSpectralMeasure α lam θ (Set.Iio energy)).toReal

/-- The conventional phase-averaged IDS, with the strict lower-half-line
convention. The normalized phase parameter ranges from zero to one; the
operator's radian phase is `2πt`. This is an explicit definition, not an
identification with the magnetic lower mass or with empirical eigenvalue counts. -/
def almostMathieuIDS (α lam energy : ℝ) : ℝ :=
  ∫ t in (0 : ℝ)..1, amoRootLowerMass α lam (2 * Real.pi * t) energy

end CriticalDTM

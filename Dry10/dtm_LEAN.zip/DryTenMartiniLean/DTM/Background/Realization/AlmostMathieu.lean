import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.CStarAlgebra.ContinuousLinearMap
import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# The one-dimensional almost Mathieu operator

This is the bounded operator on the actual space `ℓ²(ℤ, ℂ)`, with phase measured
in radians. Its receiving row is proved below. It is not a renaming of the
square-lattice magnetic operator: identifying their spectra is a separate task.
-/

noncomputable section

namespace CriticalDTM

abbrev AMOHilbert := ℓ²(ℤ, ℂ)
abbrev AMOBoundedOperator := AMOHilbert →L[ℂ] AMOHilbert

/-- The unit vector at the physical origin of the one-dimensional lattice. -/
def amoRoot : AMOHilbert := lp.single 2 (0 : ℤ) (1 : ℂ)

@[simp] theorem amoRoot_zero : amoRoot 0 = 1 := by
  simp [amoRoot]

theorem amoRoot_norm : ‖amoRoot‖ = 1 := by
  simp [amoRoot, lp.norm_single]

instance amoHilbert_nontrivial : Nontrivial AMOHilbert := by
  refine ⟨⟨amoRoot, 0, ?_⟩⟩
  intro h
  have hc := congrArg (fun u : AMOHilbert => u 0) h
  simp at hc

private theorem amo_summable_sq (u : AMOHilbert) :
    Summable (fun n => ‖u n‖ ^ (2 : ℕ)) := by
  have h := (lp.memℓp u).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  simpa using h

private theorem amo_norm_sq (u : AMOHilbert) :
    ‖u‖ ^ (2 : ℕ) = ∑' n, ‖u n‖ ^ (2 : ℕ) := by
  have h := lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) u
  simpa using h

/-- Reindexing a square-summable sequence by an integer permutation. -/
def amoReindexVector (e : ℤ ≃ ℤ) (u : AMOHilbert) : AMOHilbert :=
  ⟨fun n => u (e n), by
    apply memℓp_gen
    have h := e.summable_iff.mpr (amo_summable_sq u)
    simpa [Function.comp_def] using h⟩

@[simp] theorem amoReindexVector_apply (e : ℤ ≃ ℤ) (u : AMOHilbert) (n : ℤ) :
    amoReindexVector e u n = u (e n) := rfl

theorem amoReindexVector_norm (e : ℤ ≃ ℤ) (u : AMOHilbert) :
    ‖amoReindexVector e u‖ = ‖u‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [amo_norm_sq, amo_norm_sq]
  exact e.tsum_eq (fun n => ‖u n‖ ^ (2 : ℕ))

/-- Reindexing as a genuine unitary equivalence, with the inverse permutation. -/
def amoReindexEquiv (e : ℤ ≃ ℤ) : AMOHilbert ≃ₗᵢ[ℂ] AMOHilbert where
  toFun := amoReindexVector e
  invFun := amoReindexVector e.symm
  left_inv := by
    intro u
    apply lp.ext
    funext n
    simp
  right_inv := by
    intro u
    apply lp.ext
    funext n
    simp
  map_add' := by
    intro u v
    apply lp.ext
    rfl
  map_smul' := by
    intro c u
    apply lp.ext
    rfl
  norm_map' := amoReindexVector_norm e

def amoSuccEquiv : ℤ ≃ ℤ where
  toFun := fun n => n + 1
  invFun := fun n => n - 1
  left_inv := by intro n; simp
  right_inv := by intro n; simp

/-- The receiving-row shift `u(n) ↦ u(n+1)`. -/
def amoShift : AMOBoundedOperator := amoReindexEquiv amoSuccEquiv

@[simp] theorem amoShift_apply (u : AMOHilbert) (n : ℤ) :
    amoShift u n = u (n + 1) := rfl

@[simp] theorem amoShift_star_apply (u : AMOHilbert) (n : ℤ) :
    star amoShift u n = u (n - 1) := by
  unfold amoShift
  rw [LinearIsometryEquiv.star_eq_symm]
  rfl

theorem amoShift_norm_le : ‖amoShift‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro u
  simp [amoShift]

private theorem amo_cos_coordinate_norm_le (α θ : ℝ) (u : AMOHilbert) (n : ℤ) :
    ‖(Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) * u n‖ ≤ ‖u n‖ := by
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
  exact (mul_le_mul_of_nonneg_right (Real.abs_cos_le_one _) (norm_nonneg _)).trans_eq
    (one_mul _)

/-- Multiplication by the real cosine potential before scaling by `2λ`. -/
def amoCosVector (α θ : ℝ) (u : AMOHilbert) : AMOHilbert :=
  ⟨fun n => (Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) * u n, by
    apply memℓp_gen
    have h : Summable (fun n : ℤ =>
        ‖(Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) * u n‖ ^ (2 : ℕ)) :=
      Summable.of_nonneg_of_le (fun n => sq_nonneg _)
        (fun n => (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).2
          (amo_cos_coordinate_norm_le α θ u n)) (amo_summable_sq u)
    simpa using h⟩

@[simp] theorem amoCosVector_apply (α θ : ℝ) (u : AMOHilbert) (n : ℤ) :
    amoCosVector α θ u n =
      (Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) * u n := rfl

theorem amoCosVector_norm_le (α θ : ℝ) (u : AMOHilbert) :
    ‖amoCosVector α θ u‖ ≤ ‖u‖ := by
  apply (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [amo_norm_sq, amo_norm_sq]
  exact Summable.tsum_le_tsum
    (fun n => (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).2
      (amo_cos_coordinate_norm_le α θ u n))
    (amo_summable_sq (amoCosVector α θ u)) (amo_summable_sq u)

def amoCosOperator (α θ : ℝ) : AMOBoundedOperator :=
  LinearMap.mkContinuous
    { toFun := amoCosVector α θ
      map_add' := by
        intro u v
        apply lp.ext
        funext n
        simp [mul_add]
      map_smul' := by
        intro c u
        apply lp.ext
        funext n
        simp [mul_left_comm] }
    1 (fun u => by simpa using amoCosVector_norm_le α θ u)

@[simp] theorem amoCosOperator_apply (α θ : ℝ) (u : AMOHilbert) (n : ℤ) :
    amoCosOperator α θ u n =
      (Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) * u n := rfl

theorem amoCosOperator_norm_le (α θ : ℝ) : ‖amoCosOperator α θ‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro u
  simpa using amoCosVector_norm_le α θ u

theorem amoCosOperator_isSelfAdjoint (α θ : ℝ) : IsSelfAdjoint (amoCosOperator α θ) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro u v
  rw [lp.inner_eq_tsum, lp.inner_eq_tsum]
  apply tsum_congr
  intro n
  change @inner ℂ _ _
      ((Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) • u n) (v n) =
    @inner ℂ _ _ (u n)
      ((Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) • v n)
  simp only [inner_smul_left, inner_smul_right, Complex.conj_ofReal]

/-- Cosine addition expresses the phase dependence using two fixed bounded
multipliers. In particular continuity is in operator norm, not just pointwise. -/
theorem amoCosOperator_eq_cos_smul_add_sin_smul (α θ : ℝ) :
    amoCosOperator α θ = (Real.cos θ : ℂ) • amoCosOperator α 0 +
      (Real.sin θ : ℂ) • amoCosOperator α (Real.pi / 2) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext n
  change (Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℂ) * u n =
    (Real.cos θ : ℂ) * ((Real.cos (2 * Real.pi * α * (n : ℝ) + 0) : ℂ) * u n) +
      (Real.sin θ : ℂ) *
        ((Real.cos (2 * Real.pi * α * (n : ℝ) + Real.pi / 2) : ℂ) * u n)
  rw [add_zero, Real.cos_add_pi_div_two, Real.cos_add]
  simp only [Complex.ofReal_sub, Complex.ofReal_mul, Complex.ofReal_neg]
  ring

theorem continuous_amoCosOperator (α : ℝ) : Continuous (amoCosOperator α) := by
  have h := ((Complex.continuous_ofReal.comp Real.continuous_cos).smul
    (continuous_const : Continuous (fun _ : ℝ => amoCosOperator α 0))).add
      ((Complex.continuous_ofReal.comp Real.continuous_sin).smul
        (continuous_const : Continuous (fun _ : ℝ => amoCosOperator α (Real.pi / 2))))
  simpa only [Function.comp_apply, ← amoCosOperator_eq_cos_smul_add_sin_smul] using h

/-- The actual almost Mathieu operator, with unscaled hopping and radian phase. -/
def almostMathieuOperator (α lam θ : ℝ) : AMOBoundedOperator :=
  amoShift + star amoShift + ((2 * lam : ℝ) : ℂ) • amoCosOperator α θ

/-- The defining receiving row on every vector in the actual Hilbert space. -/
@[simp] theorem almostMathieuOperator_apply (α lam θ : ℝ) (u : AMOHilbert) (n : ℤ) :
    almostMathieuOperator α lam θ u n = u (n + 1) + u (n - 1) +
      ((2 * lam * Real.cos (2 * Real.pi * α * (n : ℝ) + θ) : ℝ) : ℂ) * u n := by
  simp [almostMathieuOperator, mul_assoc]

theorem almostMathieuOperator_isSelfAdjoint (α lam θ : ℝ) :
    IsSelfAdjoint (almostMathieuOperator α lam θ) := by
  exact (IsSelfAdjoint.add_star_self amoShift).add
    ((show IsSelfAdjoint ((2 * lam : ℝ) : ℂ) from Complex.conj_ofReal _).smul
      (amoCosOperator_isSelfAdjoint α θ))

theorem almostMathieuOperator_norm_le (α lam θ : ℝ) :
    ‖almostMathieuOperator α lam θ‖ ≤ 2 + 2 * |lam| := by
  have hs : ‖amoShift + star amoShift‖ ≤ 2 := by
    have h := norm_add_le amoShift (star amoShift)
    rw [norm_star amoShift] at h
    linarith [amoShift_norm_le]
  have hv : ‖((2 * lam : ℝ) : ℂ) • amoCosOperator α θ‖ ≤ 2 * |lam| := by
    rw [norm_smul ((2 * lam : ℝ) : ℂ) (amoCosOperator α θ)]
    have h := mul_le_mul_of_nonneg_left (amoCosOperator_norm_le α θ)
      (norm_nonneg ((2 * lam : ℝ) : ℂ))
    simpa [abs_mul] using h
  exact (norm_add_le _ _).trans (add_le_add hs hv)

theorem continuous_almostMathieuOperator_phase (α lam : ℝ) :
    Continuous (almostMathieuOperator α lam) := by
  unfold almostMathieuOperator
  exact continuous_const.add ((continuous_amoCosOperator α).const_smul _)

/-- The real slice of the complex spectrum of this one-dimensional operator. -/
def almostMathieuRealSpectrumSet (α lam θ : ℝ) : Set ℝ :=
  {E | (E : ℂ) ∈ spectrum ℂ (almostMathieuOperator α lam θ)}

theorem almostMathieuRealSpectrumSet_eq_realSpectrum (α lam θ : ℝ) :
    almostMathieuRealSpectrumSet α lam θ = spectrum ℝ (almostMathieuOperator α lam θ) := by
  ext E
  change (E : ℂ) ∈ spectrum ℂ (almostMathieuOperator α lam θ) ↔
    E ∈ spectrum ℝ (almostMathieuOperator α lam θ)
  simp only [spectrum.mem_iff, Algebra.algebraMap_eq_smul_one, Complex.coe_smul]

end CriticalDTM

import DTM.Background.Realization.MagneticTrace
import DTM.NewResults.Boundary.MagneticSymmetry
import Mathlib.Analysis.CStarAlgebra.Spectrum
import Mathlib.Analysis.CStarAlgebra.ContinuousLinearMap
import Mathlib.Topology.Algebra.StarSubalgebra

/-!
# The closed magnetic star algebra

Finite magnetic polynomials are closed under products and adjoints. Their
norm closure is therefore a genuine unital closed star subalgebra. Spectral
permanence, rather than an assertion for arbitrary closed algebras, puts the
actual magnetic resolvent in this algebra.
-/

noncomputable section

namespace CriticalDTM

private theorem adjoint_eq_of_isometry_right_inverse
    (A B : MagneticBoundedOperator) (hnorm : ∀ u, ‖A u‖ = ‖u‖)
    (hinv : A * B = 1) : star A = B := by
  let Ai : MagneticHilbert →ₗᵢ[ℂ] MagneticHilbert :=
    { toLinearMap := A.toLinearMap, norm_map' := hnorm }
  have hp : ∀ u v, @inner ℂ MagneticHilbert _ (A u) v =
      @inner ℂ MagneticHilbert _ u (B v) := by
    intro u v
    have hv : A (B v) = v := by
      have h := congrArg (fun T : MagneticBoundedOperator => T v) hinv
      simpa only [ContinuousLinearMap.mul_apply, ContinuousLinearMap.one_apply] using h
    calc
      @inner ℂ MagneticHilbert _ (A u) v =
          @inner ℂ MagneticHilbert _ (A u) (A (B v)) := by rw [hv]
      _ = @inner ℂ MagneticHilbert _ u (B v) := Ai.inner_map_map u (B v)
  have hA : A = ContinuousLinearMap.adjoint B :=
    (ContinuousLinearMap.eq_adjoint_iff A B).mpr hp
  rw [ContinuousLinearMap.star_eq_adjoint, hA, ContinuousLinearMap.adjoint_adjoint]

theorem magneticMonomial_star (α : ℝ) (a : Site) :
    star (magneticMonomial α a) =
      magneticPhase α (a.2 * a.1) • magneticMonomial α (-a) := by
  apply adjoint_eq_of_isometry_right_inverse
  · intro u
    exact twistedVector_norm (latticeTranslation a) (fun s => magneticPhase α (a.2 * s.1))
      (fun s => magneticPhase_norm α (a.2 * s.1)) u
  · rw [mul_smul_comm, magneticMonomial_mul]
    simp only [Prod.snd_neg, neg_mul, add_neg_cancel,
      show (0 : Site) = origin from rfl, magneticMonomial_origin, smul_smul]
    rw [magneticPhase_mul_neg]
    simp

theorem magneticPolynomialSpace_star_mem (α : ℝ) {A : MagneticBoundedOperator}
    (hA : A ∈ magneticPolynomialSpace α) : star A ∈ magneticPolynomialSpace α := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    rw [magneticMonomial_star]
    exact (magneticPolynomialSpace α).smul_mem _ (magneticMonomial_mem_polynomialSpace α (-a))
  | zero => simp
  | add A B hA hB ihA ihB =>
    simpa only [star_add] using (magneticPolynomialSpace α).add_mem ihA ihB
  | smul c A hA ih =>
    simpa only [star_smul] using (magneticPolynomialSpace α).smul_mem (star c) ih

def magneticPolynomialStarAlgebra (α : ℝ) : StarSubalgebra ℂ MagneticBoundedOperator where
  carrier := magneticPolynomialSpace α
  zero_mem' := (magneticPolynomialSpace α).zero_mem
  one_mem' := magneticPolynomialSpace_one_mem α
  add_mem' := (magneticPolynomialSpace α).add_mem
  mul_mem' := magneticPolynomialSpace_mul_mem α
  algebraMap_mem' := by
    intro c
    rw [Algebra.algebraMap_eq_smul_one]
    exact (magneticPolynomialSpace α).smul_mem c (magneticPolynomialSpace_one_mem α)
  star_mem' := magneticPolynomialSpace_star_mem α

def magneticAlgebra (α : ℝ) : StarSubalgebra ℂ MagneticBoundedOperator :=
  (magneticPolynomialStarAlgebra α).topologicalClosure

instance magneticAlgebra_isClosed (α : ℝ) :
    IsClosed (magneticAlgebra α : Set MagneticBoundedOperator) :=
  StarSubalgebra.isClosed_topologicalClosure _

theorem polynomialSpace_subset_magneticAlgebra (α : ℝ) {A : MagneticBoundedOperator}
    (hA : A ∈ magneticPolynomialSpace α) : A ∈ magneticAlgebra α :=
  subset_closure hA

theorem hOperator_mem_magneticAlgebra (α : ℝ) (lam : ℂ) :
    hOperator α lam ∈ magneticAlgebra α :=
  polynomialSpace_subset_magneticAlgebra α (hOperator_mem_polynomialSpace α lam)

theorem rootTrace_magneticAlgebra_cyclic (α : ℝ) {A B : MagneticBoundedOperator}
    (hA : A ∈ magneticAlgebra α) (hB : B ∈ magneticAlgebra α) :
    rootTrace (A * B) = rootTrace (B * A) :=
  rootTrace_closure_cyclic α hA hB

end CriticalDTM

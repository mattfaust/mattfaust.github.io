import DTM.NewResults.Boundary.Compression

/-!
# The commuting magnetic lattice actions

The commutation relation is checked on arbitrary functions on `ℤ × ℤ`.
It follows directly from the phase addition law, without a presentation
of the Heisenberg algebra or any operator-domain assertion.
-/

namespace CriticalDTM

theorem magnetic_rows_commute (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) :
    hRow α lam (conjugateRow α lam u) s =
      conjugateRow α lam (hRow α lam u) s := by
  rcases s with ⟨j, k⟩
  simp only [hRow, conjugateRow, east, west, north, south]
  simp only [sub_eq_add_neg, neg_add_rev, neg_neg, magneticPhase_add]
  simp only [add_assoc, neg_add_cancel, add_neg_cancel, add_zero]
  ring

noncomputable def latticeRoot (s : Site) : ℂ := if s = origin then 1 else 0

@[simp] theorem latticeRoot_origin : latticeRoot origin = 1 := by
  simp [latticeRoot]

theorem magneticPhase_mul_latticeRoot (α : ℝ) (n : Site → ℤ)
    (hn : n origin = 0) (s : Site) :
    magneticPhase α (n s) * latticeRoot s = latticeRoot s := by
  by_cases hs : s = origin
  · subst s
    simp [hn, magneticPhase_zero]
  · simp [latticeRoot, hs]

theorem magnetic_rows_agree_on_root (α : ℝ) (lam : ℂ) (s : Site) :
    hRow α lam latticeRoot s = conjugateRow α lam latticeRoot s := by
  have he := magneticPhase_mul_latticeRoot α Prod.snd (by rfl) (east s)
  have hw := magneticPhase_mul_latticeRoot α (fun t => -t.2) (by rfl) (west s)
  have hn := magneticPhase_mul_latticeRoot α Prod.fst (by rfl) (north s)
  have hs := magneticPhase_mul_latticeRoot α (fun t => -t.1) (by rfl) (south s)
  dsimp [east, west, north, south] at he hw hn hs
  unfold hRow conjugateRow east west north south
  linear_combination lam * hn + lam * hs - he - hw

end CriticalDTM

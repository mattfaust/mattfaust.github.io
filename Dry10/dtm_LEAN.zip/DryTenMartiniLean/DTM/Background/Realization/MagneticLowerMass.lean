import DTM.Background.Labels.MagneticGapProjection

/-!
# The actual lower spectral mass

This quantity is the lower-half-line mass of the constructed magnetic root
spectral measure. At a resolvent energy it equals the actual gap projection
trace. No empirical IDS identification is used in this definition.
-/

noncomputable section

namespace CriticalDTM

open Set

/-- The actual root spectral measure of energies strictly below the cut. -/
def magneticLowerMass (α lam energy : ℝ) : ℝ :=
  (magneticRealSpectralMeasure α lam (Iio energy)).toReal

theorem magneticLowerMass_eq_projection_trace (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticLowerMass α lam energy =
      magneticTraceReal α (magneticGapProjection α lam energy hm) :=
  (magneticGapProjection_trace_eq_realSpectralMass α lam energy hm).symm

end CriticalDTM

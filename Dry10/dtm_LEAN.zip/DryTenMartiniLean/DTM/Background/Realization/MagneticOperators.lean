import DTM.Background.Realization.MagneticLattice
import Mathlib.Analysis.InnerProductSpace.l2Space

/-!
# Bounded magnetic operators on the lattice Hilbert space

The shifts and magnetic phases are constructed on the actual infinite
square-summable sequence space.  Their norm control is proved by reindexing
the sum of squared coordinate norms.
-/

noncomputable section

namespace CriticalDTM

abbrev MagneticHilbert := ℓ²(Site, ℂ)

private theorem lattice_summable_sq (u : MagneticHilbert) :
    Summable (fun s => ‖u s‖ ^ (2 : ℕ)) := by
  have h := (lp.memℓp u).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  simpa using h

private theorem lattice_norm_sq (u : MagneticHilbert) :
    ‖u‖ ^ (2 : ℕ) = ∑' s, ‖u s‖ ^ (2 : ℕ) := by
  have h := lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) u
  simpa using h

def twistedVector (e : Site ≃ Site) (w : Site → ℂ) (hw : ∀ s, ‖w s‖ = 1)
    (u : MagneticHilbert) : MagneticHilbert :=
  ⟨fun s => w s * u (e s), by
    apply memℓp_gen
    have h := e.summable_iff.mpr (lattice_summable_sq u)
    simpa [Function.comp_def, norm_mul, hw] using h⟩

@[simp] theorem twistedVector_apply (e : Site ≃ Site) (w : Site → ℂ)
    (hw : ∀ s, ‖w s‖ = 1) (u : MagneticHilbert) (s : Site) :
    twistedVector e w hw u s = w s * u (e s) := rfl

theorem twistedVector_norm (e : Site ≃ Site) (w : Site → ℂ)
    (hw : ∀ s, ‖w s‖ = 1) (u : MagneticHilbert) :
    ‖twistedVector e w hw u‖ = ‖u‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [lattice_norm_sq, lattice_norm_sq]
  simp only [twistedVector_apply, norm_mul, hw, one_mul]
  exact e.tsum_eq (fun s => ‖u s‖ ^ (2 : ℕ))

def twistedOperator (e : Site ≃ Site) (w : Site → ℂ) (hw : ∀ s, ‖w s‖ = 1) :
    MagneticHilbert →L[ℂ] MagneticHilbert :=
  LinearMap.mkContinuous
    { toFun := twistedVector e w hw
      map_add' := by
        intro u v
        apply lp.ext
        funext s
        simp [mul_add]
      map_smul' := by
        intro c u
        apply lp.ext
        funext s
        simp [mul_left_comm] }
    1 (fun u => by simp [twistedVector_norm])

@[simp] theorem twistedOperator_apply (e : Site ≃ Site) (w : Site → ℂ)
    (hw : ∀ s, ‖w s‖ = 1) (u : MagneticHilbert) (s : Site) :
    twistedOperator e w hw u s = w s * u (e s) := rfl

theorem twistedOperator_norm_le (e : Site ≃ Site) (w : Site → ℂ)
    (hw : ∀ s, ‖w s‖ = 1) : ‖twistedOperator e w hw‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro u
  simpa using (twistedVector_norm e w hw u).le

def eastEquiv : Site ≃ Site where
  toFun := east
  invFun := west
  left_inv := by intro s; rcases s with ⟨j, k⟩; simp [east, west]
  right_inv := by intro s; rcases s with ⟨j, k⟩; simp [east, west]

def northEquiv : Site ≃ Site where
  toFun := north
  invFun := south
  left_inv := by intro s; rcases s with ⟨j, k⟩; simp [north, south]
  right_inv := by intro s; rcases s with ⟨j, k⟩; simp [north, south]

theorem magneticPhase_norm (α : ℝ) (n : ℤ) : ‖magneticPhase α n‖ = 1 :=
  Complex.norm_exp_ofReal_mul_I _

def hOperator (α : ℝ) (lam : ℂ) : MagneticHilbert →L[ℂ] MagneticHilbert :=
  twistedOperator eastEquiv (fun _ => 1) (fun _ => norm_one) +
  twistedOperator eastEquiv.symm (fun _ => 1) (fun _ => norm_one) +
  lam • twistedOperator northEquiv (fun s => magneticPhase α s.1)
    (fun s => magneticPhase_norm α s.1) +
  lam • twistedOperator northEquiv.symm (fun s => magneticPhase α (-s.1))
    (fun s => magneticPhase_norm α (-s.1))

def conjugateOperator (α : ℝ) (lam : ℂ) : MagneticHilbert →L[ℂ] MagneticHilbert :=
  twistedOperator eastEquiv (fun s => magneticPhase α s.2)
    (fun s => magneticPhase_norm α s.2) +
  twistedOperator eastEquiv.symm (fun s => magneticPhase α (-s.2))
    (fun s => magneticPhase_norm α (-s.2)) +
  lam • twistedOperator northEquiv (fun _ => 1) (fun _ => norm_one) +
  lam • twistedOperator northEquiv.symm (fun _ => 1) (fun _ => norm_one)

@[simp] theorem hOperator_apply (α : ℝ) (lam : ℂ) (u : MagneticHilbert) (s : Site) :
    hOperator α lam u s = hRow α lam u s := by
  simp [hOperator, hRow, eastEquiv, northEquiv, mul_assoc]

@[simp] theorem conjugateOperator_apply (α : ℝ) (lam : ℂ)
    (u : MagneticHilbert) (s : Site) :
    conjugateOperator α lam u s = conjugateRow α lam u s := by
  simp [conjugateOperator, conjugateRow, eastEquiv, northEquiv, mul_assoc]

theorem magnetic_operators_commute (α : ℝ) (lam : ℂ) (u : MagneticHilbert) :
    hOperator α lam (conjugateOperator α lam u) =
      conjugateOperator α lam (hOperator α lam u) := by
  apply lp.ext
  funext s
  simp only [hOperator_apply, conjugateOperator_apply]
  have hC : (conjugateOperator α lam u : Site → ℂ) = conjugateRow α lam u := by
    funext s
    exact conjugateOperator_apply α lam u s
  have hH : (hOperator α lam u : Site → ℂ) = hRow α lam u := by
    funext s
    exact hOperator_apply α lam u s
  rw [hC, hH]
  exact magnetic_rows_commute α lam u s

def hilbertRoot : MagneticHilbert := lp.single 2 origin 1

@[simp] theorem hilbertRoot_apply (s : Site) : hilbertRoot s = latticeRoot s := by
  by_cases hs : s = origin
  · subst s
    simp [hilbertRoot]
  · simp [hilbertRoot, lp.single_apply_ne, latticeRoot, hs]

theorem magnetic_operators_agree_on_root (α : ℝ) (lam : ℂ) :
    hOperator α lam hilbertRoot = conjugateOperator α lam hilbertRoot := by
  apply lp.ext
  funext s
  simp only [hOperator_apply, conjugateOperator_apply]
  have hr : (hilbertRoot : Site → ℂ) = latticeRoot := funext hilbertRoot_apply
  rw [hr]
  exact magnetic_rows_agree_on_root α lam s

end CriticalDTM

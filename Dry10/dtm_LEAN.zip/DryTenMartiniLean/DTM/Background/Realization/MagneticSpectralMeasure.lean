import DTM.NewResults.Calculus.MagneticPotential
import Mathlib.MeasureTheory.Integral.RieszMarkovKakutani.Real
import Mathlib.MeasureTheory.Measure.Typeclasses.Probability

/-!
# The actual magnetic root-state spectral measure

The Riesz–Markov–Kakutani theorem constructs a probability measure on the
compact real spectrum of the actual magnetic-algebra Hamiltonian. Its
integrals of continuous functions are the actual fixed root trace of the
continuous functional calculus. We also push this measure to the real line.

This file does not identify the measure with a finite-volume empirical IDS,
assert full support or absence of atoms, or invoke a Thouless formula.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory CompactlySupported
open scoped ContinuousFunctionalCalculus

local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

/-- The compact real spectrum, viewed as a topological space. -/
abbrev MagneticRealSpectrum (α lam : ℝ) : Type :=
  spectrum ℝ (magneticAlgebraHamiltonian α lam)

/-- Forgetting compact support is real-linear. -/
def compactTestToContinuous {X : Type*} [TopologicalSpace X] :
    C_c(X, ℝ) →ₗ[ℝ] C(X, ℝ) where
  toFun := fun f => f.toContinuousMap
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- The fixed root state composed with the actual continuous functional
calculus, on the compact-support interface required by RMK. -/
def magneticSpectralFunctional (α lam : ℝ) :
    C_c(MagneticRealSpectrum α lam, ℝ) →ₗ[ℝ] ℝ :=
  (magneticTraceReal α).toLinearMap.comp
    ((cfcL (magneticAlgebraHamiltonian_isSelfAdjoint α lam)).toLinearMap.comp
      compactTestToContinuous)

set_option maxHeartbeats 800000 in
/-- Positivity follows from the square-root factorization of a nonnegative
continuous function and positivity of the actual vector state. -/
theorem magneticSpectralFunctional_nonneg (α lam : ℝ)
    (f : C_c(MagneticRealSpectrum α lam, ℝ)) (hf : 0 ≤ f) :
    0 ≤ magneticSpectralFunctional α lam f := by
  let g : C(MagneticRealSpectrum α lam, ℝ) :=
    ⟨fun x => Real.sqrt (f x), Real.continuous_sqrt.comp f.continuous⟩
  have hsq : g * g = f.toContinuousMap := by
    ext x
    exact Real.mul_self_sqrt (hf x)
  let hH := magneticAlgebraHamiltonian_isSelfAdjoint α lam
  have hfact : cfcHom hH f.toContinuousMap = star (cfcHom hH g) * cfcHom hH g := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul, hsq]
  change 0 ≤ magneticTraceReal α (cfcHom hH f.toContinuousMap)
  rw [hfact]
  exact magneticTraceReal_star_mul_self_nonneg α (cfcHom hH g)

/-- The probability measure representing the actual root trace on the
compact real spectrum. Normalization is proved below. -/
def magneticSpectralMeasure (α lam : ℝ) : Measure (MagneticRealSpectrum α lam) :=
  RealRMK.rieszMeasure (magneticSpectralFunctional_nonneg α lam)

/-- RMK's representation formula for compactly supported continuous tests. -/
theorem magneticSpectralMeasure_integral_compact (α lam : ℝ)
    (f : C_c(MagneticRealSpectrum α lam, ℝ)) :
    ∫ x, f x ∂magneticSpectralMeasure α lam =
      magneticTraceReal α
        (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f.toContinuousMap) :=
  RealRMK.integral_rieszMeasure (magneticSpectralFunctional_nonneg α lam) f

/-- Every continuous test on the compact spectrum has the root-state
integral representation; no compact-support assumption is left to callers. -/
theorem magneticSpectralMeasure_integral (α lam : ℝ)
    (f : C(MagneticRealSpectrum α lam, ℝ)) :
    ∫ x, f x ∂magneticSpectralMeasure α lam =
      magneticTraceReal α (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f) := by
  let fc : C_c(MagneticRealSpectrum α lam, ℝ) :=
    { toContinuousMap := f
      hasCompactSupport' := HasCompactSupport.of_compactSpace f }
  exact magneticSpectralMeasure_integral_compact α lam fc

/-- Normalization is proved from the actual unit root and constant-one test. -/
instance magneticSpectralMeasure_isProbabilityMeasure (α lam : ℝ) :
    IsProbabilityMeasure (magneticSpectralMeasure α lam) := by
  constructor
  apply (ENNReal.toReal_eq_one_iff _).mp
  have h := magneticSpectralMeasure_integral α lam (1 : C(MagneticRealSpectrum α lam, ℝ))
  simpa only [ContinuousMap.one_apply, integral_const, smul_eq_mul, mul_one,
    map_one, magneticTraceReal_one, measureReal_def] using h

/-- The same actual root-state measure, pushed from its compact spectral
space to the real energy axis. -/
def magneticRealSpectralMeasure (α lam : ℝ) : Measure ℝ :=
  (magneticSpectralMeasure α lam).map (fun x : MagneticRealSpectrum α lam => (x : ℝ))

instance magneticRealSpectralMeasure_isProbabilityMeasure (α lam : ℝ) :
    IsProbabilityMeasure (magneticRealSpectralMeasure α lam) :=
  isProbabilityMeasure_map continuous_subtype_val.measurable.aemeasurable

/-- Real-line continuous tests recover the trace of their restrictions to
the actual spectrum. -/
theorem magneticRealSpectralMeasure_integral (α lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂magneticRealSpectralMeasure α lam =
      magneticTraceReal α
        (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
          (⟨fun x => f x, hf.comp continuous_subtype_val⟩ :
            C(MagneticRealSpectrum α lam, ℝ))) := by
  rw [magneticRealSpectralMeasure,
    integral_map continuous_subtype_val.measurable.aemeasurable hf.aestronglyMeasurable]
  exact magneticSpectralMeasure_integral α lam
    (⟨fun x => f x, hf.comp continuous_subtype_val⟩ : C(MagneticRealSpectrum α lam, ℝ))

/-- The usual unbundled CFC form of the real-line representation formula. -/
theorem magneticRealSpectralMeasure_integral_cfc (α lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂magneticRealSpectralMeasure α lam =
      magneticTraceReal α (cfc f (magneticAlgebraHamiltonian α lam)) := by
  rw [cfc_apply f (magneticAlgebraHamiltonian α lam)
    (magneticAlgebraHamiltonian_isSelfAdjoint α lam) hf.continuousOn]
  exact magneticRealSpectralMeasure_integral α lam f hf

end CriticalDTM

import DTM.Background.Labels.MagneticLabelUniqueness
import DTM.Background.SpectralVanishing.AMOCyclicVolumeApproximation

/-!
# Full support of the actual magnetic spectral measure

A continuous bump that vanished almost everywhere for the root-state measure
would have zero squared CFC trace. Faithfulness of the existing magnetic trace
then makes its functional calculus zero; injectivity evaluates this at every
actual spectral energy. Thus every neighbourhood of a spectral energy has
positive mass, with no support or Lyapunov hypothesis.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set
open scoped ContinuousFunctionalCalculus

set_option maxHeartbeats 800000 in
/-- Every open neighbourhood of an actual spectral energy has strictly
positive mass for the actual magnetic root-state spectral measure. -/
theorem magneticRealSpectralMeasure_ball_pos_of_mem (α lam E : ℝ)
    (hE : E ∈ magneticRealSpectrumSet α lam) {epsilon : ℝ} (he : 0 < epsilon) :
    0 < magneticRealSpectralMeasure α lam (Metric.ball E epsilon) := by
  by_contra hpos
  have hmass : magneticRealSpectralMeasure α lam (Metric.ball E epsilon) = 0 :=
    le_antisymm (le_of_not_gt hpos) (zero_le _)
  have hout : ∀ᵐ x ∂magneticRealSpectralMeasure α lam,
      x ∉ Metric.ball E epsilon := by
    apply ae_iff.mpr
    simpa only [not_not, setOf_mem_eq] using hmass
  have hzero : (fun x => amoCyclicEnergyBump E epsilon x * amoCyclicEnergyBump E epsilon x)
      =ᵐ[magneticRealSpectralMeasure α lam] (fun _ => (0 : ℝ)) := by
    filter_upwards [hout] with x hx
    have hx' : epsilon ≤ |x - E| := by
      simpa only [Metric.mem_ball, Real.dist_eq, not_lt] using hx
    simp only [amoCyclicEnergyBump, max_eq_left (sub_nonpos.mpr hx'), zero_mul]
  let g : C(MagneticRealSpectrum α lam, ℝ) :=
    ⟨fun x => amoCyclicEnergyBump E epsilon x,
      (continuous_amoCyclicEnergyBump E epsilon).comp continuous_subtype_val⟩
  let hH := magneticAlgebraHamiltonian_isSelfAdjoint α lam
  have htrace : magneticTraceReal α (star (cfcHom hH g) * cfcHom hH g) = 0 := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul]
    have hint := magneticRealSpectralMeasure_integral α lam
      (fun x => amoCyclicEnergyBump E epsilon x * amoCyclicEnergyBump E epsilon x)
      ((continuous_amoCyclicEnergyBump E epsilon).mul
        (continuous_amoCyclicEnergyBump E epsilon))
    rw [integral_congr_ae hzero, integral_zero] at hint
    exact hint.symm
  have hg : g = 0 := by
    apply (cfcHom_isClosedEmbedding hH).injective
    rw [map_zero]
    exact magneticTraceReal_faithful α (cfcHom hH g) htrace
  rw [magneticRealSpectrumSet_eq_algebraSpectrum] at hE
  have hvalue := congrArg (fun f : C(MagneticRealSpectrum α lam, ℝ) => f ⟨E, hE⟩) hg
  have : epsilon = 0 := by
    simpa only [g, ContinuousMap.coe_mk, sub_self, abs_zero, sub_zero,
      amoCyclicEnergyBump, max_eq_right he.le, ContinuousMap.zero_apply] using hvalue
  exact he.ne' this

end CriticalDTM

import DTM.NewResults.Boundary.MagneticSource
import DTM.Background.Realization.OperatorBounds
import Mathlib.LinearAlgebra.Span.Basic

/-!
# The canonical root trace on magnetic polynomials

The root functional is defined on all bounded lattice operators. Its trace
property is proved on the magnetic polynomial span and on its norm closure;
it is not asserted on the algebra of all bounded operators.
-/

noncomputable section

namespace CriticalDTM

abbrev MagneticBoundedOperator := MagneticHilbert →L[ℂ] MagneticHilbert

theorem hilbertRoot_norm : ‖hilbertRoot‖ = 1 := by
  simp [hilbertRoot, lp.norm_single]

def rootTrace : MagneticBoundedOperator →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun A => A hilbertRoot origin
      map_add' := by intro A B; simp
      map_smul' := by intro c A; simp }
    1 (fun A => by
      calc
        ‖A hilbertRoot origin‖ ≤ ‖A hilbertRoot‖ :=
          lp.norm_apply_le_norm (by norm_num) (A hilbertRoot) origin
        _ ≤ ‖A‖ * ‖hilbertRoot‖ := A.le_opNorm hilbertRoot
        _ = 1 * ‖A‖ := by rw [hilbertRoot_norm]; ring)

@[simp] theorem rootTrace_apply (A : MagneticBoundedOperator) :
    rootTrace A = A hilbertRoot origin := rfl

theorem rootTrace_eq_inner (A : MagneticBoundedOperator) :
    rootTrace A = @inner ℂ MagneticHilbert _ hilbertRoot (A hilbertRoot) := by
  rw [inner_hilbertRoot]
  rfl

theorem rootTrace_norm_le : ‖rootTrace‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro A
  calc
    ‖rootTrace A‖ ≤ ‖A hilbertRoot‖ :=
      lp.norm_apply_le_norm (by norm_num) (A hilbertRoot) origin
    _ ≤ ‖A‖ * ‖hilbertRoot‖ := A.le_opNorm hilbertRoot
    _ = 1 * ‖A‖ := by rw [hilbertRoot_norm]; ring

def latticeTranslation (a : Site) : Site ≃ Site where
  toFun := fun s => (s.1 + a.1, s.2 + a.2)
  invFun := fun s => (s.1 - a.1, s.2 - a.2)
  left_inv := by intro s; rcases s with ⟨j, k⟩; simp
  right_inv := by intro s; rcases s with ⟨j, k⟩; simp

/-- `W(m,n)u(j,k) = exp(2πiα n j) u(j+m,k+n)`. -/
def magneticMonomial (α : ℝ) (a : Site) : MagneticBoundedOperator :=
  twistedOperator (latticeTranslation a) (fun s => magneticPhase α (a.2 * s.1))
    (fun s => magneticPhase_norm α (a.2 * s.1))

@[simp] theorem magneticMonomial_apply (α : ℝ) (a : Site)
    (u : MagneticHilbert) (s : Site) :
    magneticMonomial α a u s =
      magneticPhase α (a.2 * s.1) * u (s.1 + a.1, s.2 + a.2) := rfl

theorem magneticMonomial_mul (α : ℝ) (a b : Site) :
    magneticMonomial α a * magneticMonomial α b =
      magneticPhase α (b.2 * a.1) • magneticMonomial α (a + b) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext s
  simp only [ContinuousLinearMap.mul_apply, magneticMonomial_apply,
    ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  simp only [Prod.fst_add, Prod.snd_add, mul_add, add_mul, magneticPhase_add, add_assoc]
  ring

@[simp] theorem magneticMonomial_origin (α : ℝ) :
    magneticMonomial α origin = 1 := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext s
  simp [origin, magneticPhase_zero]

@[simp] theorem rootTrace_magneticMonomial (α : ℝ) (a : Site) :
    rootTrace (magneticMonomial α a) = if a = origin then 1 else 0 := by
  simp [rootTrace_apply, origin, magneticPhase_zero, latticeRoot]

theorem rootTrace_monomials_cyclic (α : ℝ) (a b : Site) :
    rootTrace (magneticMonomial α a * magneticMonomial α b) =
      rootTrace (magneticMonomial α b * magneticMonomial α a) := by
  rw [magneticMonomial_mul, magneticMonomial_mul, map_smul, map_smul]
  simp only [rootTrace_magneticMonomial, smul_eq_mul]
  by_cases h : a + b = origin
  · have h' : b + a = origin := by simpa [add_comm] using h
    have hm : a.1 + b.1 = 0 := congrArg Prod.fst h
    have hn : a.2 + b.2 = 0 := congrArg Prod.snd h
    have hab : b.2 * a.1 = a.2 * b.1 := by
      linear_combination a.1 * hn - a.2 * hm
    simp [h, h', hab]
  · have h' : b + a ≠ origin := by simpa [add_comm] using h
    simp [h, h']

def magneticPolynomialSpace (α : ℝ) : Submodule ℂ MagneticBoundedOperator :=
  Submodule.span ℂ (Set.range (magneticMonomial α))

theorem magneticMonomial_mem_polynomialSpace (α : ℝ) (a : Site) :
    magneticMonomial α a ∈ magneticPolynomialSpace α :=
  Submodule.subset_span (Set.mem_range_self a)

theorem magneticPolynomialSpace_one_mem (α : ℝ) :
    (1 : MagneticBoundedOperator) ∈ magneticPolynomialSpace α := by
  rw [← magneticMonomial_origin α]
  exact magneticMonomial_mem_polynomialSpace α origin

theorem magneticPolynomialSpace_mul_mem (α : ℝ) {A B : MagneticBoundedOperator}
    (hA : A ∈ magneticPolynomialSpace α) (hB : B ∈ magneticPolynomialSpace α) :
    A * B ∈ magneticPolynomialSpace α := by
  induction hA, hB using Submodule.span_induction₂ with
  | mem_mem A B hA hB =>
    obtain ⟨a, rfl⟩ := hA
    obtain ⟨b, rfl⟩ := hB
    rw [magneticMonomial_mul]
    exact (magneticPolynomialSpace α).smul_mem _ (magneticMonomial_mem_polynomialSpace α (a + b))
  | zero_left B hB => simp
  | zero_right A hA => simp
  | add_left A C B hA hC hB ihA ihC =>
    simpa only [add_mul] using (magneticPolynomialSpace α).add_mem ihA ihC
  | add_right A B C hA hB hC ihB ihC =>
    simpa only [mul_add] using (magneticPolynomialSpace α).add_mem ihB ihC
  | smul_left c A B hA hB ih =>
    have heq : (c • A) * B = c • (A * B) := by
      apply ContinuousLinearMap.ext
      intro u
      rfl
    rw [heq]
    exact (magneticPolynomialSpace α).smul_mem c ih
  | smul_right c A B hA hB ih =>
    simpa only [mul_smul_comm] using (magneticPolynomialSpace α).smul_mem c ih

theorem hOperator_eq_magneticMonomials (α : ℝ) (lam : ℂ) :
    hOperator α lam = magneticMonomial α (1, 0) + magneticMonomial α (-1, 0) +
      lam • magneticMonomial α (0, 1) + lam • magneticMonomial α (0, -1) := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext s
  simp [hOperator_apply, hRow, magneticMonomial_apply, east, west, north, south,
    magneticPhase_zero, sub_eq_add_neg, mul_assoc]

theorem hOperator_mem_polynomialSpace (α : ℝ) (lam : ℂ) :
    hOperator α lam ∈ magneticPolynomialSpace α := by
  rw [hOperator_eq_magneticMonomials]
  exact (magneticPolynomialSpace α).add_mem
    ((magneticPolynomialSpace α).add_mem
      ((magneticPolynomialSpace α).add_mem
        (magneticMonomial_mem_polynomialSpace α (1, 0))
        (magneticMonomial_mem_polynomialSpace α (-1, 0)))
      ((magneticPolynomialSpace α).smul_mem lam (magneticMonomial_mem_polynomialSpace α (0, 1))))
    ((magneticPolynomialSpace α).smul_mem lam (magneticMonomial_mem_polynomialSpace α (0, -1)))

theorem rootTrace_polynomials_cyclic (α : ℝ) {A B : MagneticBoundedOperator}
    (hA : A ∈ magneticPolynomialSpace α) (hB : B ∈ magneticPolynomialSpace α) :
    rootTrace (A * B) = rootTrace (B * A) := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    induction hB using Submodule.span_induction with
    | mem B hB =>
      obtain ⟨b, rfl⟩ := hB
      exact rootTrace_monomials_cyclic α a b
    | zero => simp
    | add B C hB hC ihB ihC => simp only [mul_add, add_mul, map_add, ihB, ihC]
    | smul c B hB ihB => simp only [mul_smul_comm, smul_mul_assoc, map_smul, ihB]
  | zero => simp
  | add A C hA hC ihA ihC => simp only [mul_add, add_mul, map_add, ihA, ihC]
  | smul c A hA ihA => simp only [mul_smul_comm, smul_mul_assoc, map_smul, ihA]

def magneticPolynomialClosure (α : ℝ) : Set MagneticBoundedOperator :=
  closure (magneticPolynomialSpace α : Set MagneticBoundedOperator)

theorem rootTrace_closure_cyclic (α : ℝ) {A B : MagneticBoundedOperator}
    (hA : A ∈ magneticPolynomialClosure α) (hB : B ∈ magneticPolynomialClosure α) :
    rootTrace (A * B) = rootTrace (B * A) := by
  have hfirst (B : MagneticBoundedOperator) (hB : B ∈ magneticPolynomialSpace α) :
      rootTrace (A * B) = rootTrace (B * A) := by
    apply closure_minimal
      (fun C hC => rootTrace_polynomials_cyclic α hC hB)
      (isClosed_eq
        (rootTrace.continuous.comp (continuous_id.mul continuous_const))
        (rootTrace.continuous.comp (continuous_const.mul continuous_id))) hA
  exact closure_minimal (fun C hC => hfirst C hC)
    (isClosed_eq
      (rootTrace.continuous.comp (continuous_const.mul continuous_id))
      (rootTrace.continuous.comp (continuous_id.mul continuous_const))) hB

end CriticalDTM

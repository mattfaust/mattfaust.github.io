import DTM.Background.Realization.MagneticAlgebra
import DTM.NewResults.Calculus.CouplingCalculus

/-!
# Proof guide: local calculus

Concrete trace-domain bridge for the coupling derivative. The
actual coupling operator B and resolvent lie in the closed magnetic algebra,
where root-trace cyclicity has been proved. Changing BR to RB is justified only
under that fixed trace, not by commutation or an assertion about all bounded
operators.
-/

/-!
# The coupling direction and resolvent belong to the traced algebra

This module connects the independently constructed coupling derivative to
the actual canonical trace.  Membership and cyclicity are conclusions.
-/

namespace CriticalDTM

/- Coupling direction: B=H(1)-H(0) is a magnetic polynomial, so all varying pencils remain in the same fixed traced algebra. -/
theorem verticalOperator_mem_polynomialSpace (α : ℝ) :
    verticalOperator α ∈ magneticPolynomialSpace α := by
  rw [verticalOperator_eq_difference]
  exact (magneticPolynomialSpace α).sub_mem
    (hOperator_mem_polynomialSpace α 1) (hOperator_mem_polynomialSpace α 0)

/- Domain check: actual polynomial membership places B in the norm-closed magnetic algebra used by the trace-log theorem. -/
theorem verticalOperator_mem_magneticAlgebra (α : ℝ) :
    verticalOperator α ∈ magneticAlgebra α :=
  polynomialSpace_subset_magneticAlgebra α (verticalOperator_mem_polynomialSpace α)

/- Energy bridge: the root trace of the actual resolvent equals the independently defined projected Green function. -/
theorem rootTrace_resolvent_eq_green (H : MagneticBoundedOperator) (z : ℂ) :
    rootTrace (resolvent H z) = projectedGreen H hilbertRoot z :=
  rootTrace_eq_inner (resolvent H z)

/- Trace source-pairing identity: cyclicity exchanges BR and RB inside the root trace, using actual resolvent membership in its traced algebra. -/

end CriticalDTM

import DTM.NewResults.Calculus.TraceGreenBridge

/-!
# Faithfulness of the actual magnetic trace

Cyclicity transports a zero root norm to the whole magnetic translation orbit
of the root. That orbit contains every coordinate vector up to a nonzero phase,
so the bounded operator itself vanishes.
-/

noncomputable section

namespace CriticalDTM

theorem magneticMonomial_mul_star (α : ℝ) (a : Site) :
    magneticMonomial α a * star (magneticMonomial α a) = 1 := by
  rw [magneticMonomial_star, mul_smul_comm, magneticMonomial_mul]
  simp only [Prod.snd_neg, neg_mul, add_neg_cancel,
    show (0 : Site) = origin from rfl, magneticMonomial_origin, smul_smul]
  rw [magneticPhase_mul_neg]
  simp

theorem magneticMonomial_root (α : ℝ) (a : Site) :
    magneticMonomial α a hilbertRoot =
      magneticPhase α (a.2 * (-a.1)) • lp.single 2 (-a) (1 : ℂ) := by
  apply lp.ext
  funext s
  simp only [magneticMonomial_apply, hilbertRoot, lp.coeFn_smul, Pi.smul_apply,
    smul_eq_mul, lp.coeFn_single, Pi.single_apply]
  have heq : (s.1 + a.1, s.2 + a.2) = origin ↔ s = -a := by
    simp only [origin, Prod.mk.injEq, Prod.ext_iff, Prod.fst_neg, Prod.snd_neg]
    exact and_congr add_eq_zero_iff_eq_neg add_eq_zero_iff_eq_neg
  by_cases hs : s = -a
  · subst s
    simp [origin]
  · simp [hs, heq]

/-- A bounded lattice operator that kills all coordinate vectors is zero. -/
theorem magneticOperator_eq_zero_of_single
    (A : MagneticBoundedOperator)
    (hA : ∀ s : Site, A (lp.single 2 s (1 : ℂ)) = 0) : A = 0 := by
  have ha : ContinuousLinearMap.adjoint A = 0 := by
    apply ContinuousLinearMap.ext
    intro u
    apply lp.ext
    funext s
    have hi := ContinuousLinearMap.adjoint_inner_right A (lp.single 2 s (1 : ℂ)) u
    rw [hA s] at hi
    simpa only [lp.inner_single_left, inner_zero_left, RCLike.inner_apply,
      map_one, mul_one,
      ContinuousLinearMap.zero_apply, lp.coeFn_zero, Pi.zero_apply] using hi
  have h := congrArg ContinuousLinearMap.adjoint ha
  simpa only [ContinuousLinearMap.adjoint_adjoint, map_zero] using h

set_option maxHeartbeats 800000 in
/-- The canonical root trace is faithful on the actual closed magnetic algebra. -/
theorem magneticTraceReal_faithful (α : ℝ) (A : magneticAlgebra α)
    (h : magneticTraceReal α (star A * A) = 0) : A = 0 := by
  have horbit (a : Site) :
      (A : MagneticBoundedOperator) (magneticMonomial α a hilbertRoot) = 0 := by
    let W : magneticAlgebra α := ⟨magneticMonomial α a,
      polynomialSpace_subset_magneticAlgebra α
        (magneticMonomial_mem_polynomialSpace α a)⟩
    have hW : W * star W = 1 := by
      apply Subtype.ext
      exact magneticMonomial_mul_star α a
    have hz : magneticTraceReal α (star (A * W) * (A * W)) = 0 := by
      calc
        magneticTraceReal α (star (A * W) * (A * W)) =
            magneticTraceReal α (star W * (star A * A * W)) := by
          rw [star_mul]; congr 1
        _ = magneticTraceReal α ((star A * A * W) * star W) :=
          magneticTraceReal_cyclic α _ _
        _ = magneticTraceReal α (star A * A) := by rw [mul_assoc, hW, mul_one]
        _ = 0 := h
    rw [magneticTraceReal_star_mul_self] at hz
    have hn : ‖((A * W : magneticAlgebra α) : MagneticBoundedOperator) hilbertRoot‖ = 0 :=
      (sq_eq_zero_iff).mp hz
    exact norm_eq_zero.mp hn
  apply Subtype.ext
  apply magneticOperator_eq_zero_of_single
  intro s
  have hz := horbit (-s)
  rw [magneticMonomial_root, map_smul] at hz
  have hc : magneticPhase α ((-s).2 * (-(-s).1)) ≠ 0 := by
    intro hc
    have hn := magneticPhase_norm α ((-s).2 * (-(-s).1))
    rw [hc, norm_zero] at hn
    exact zero_ne_one hn
  simpa only [neg_neg] using (smul_eq_zero.mp hz).resolve_left hc

end CriticalDTM

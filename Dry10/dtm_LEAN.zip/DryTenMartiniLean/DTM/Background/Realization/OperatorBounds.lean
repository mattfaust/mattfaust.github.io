import DTM.Background.Realization.MagneticOperators
import Mathlib.Analysis.Normed.Algebra.Spectrum

/-!
# Uniform operator and spectral bounds

The actual magnetic operators satisfy the elementary four-step norm bound.
In particular every real spectral energy lies in `[-4,4]` for coupling in
`[0,1]`.  No assertion about the existence or position of gap maximizers is
included here.
-/

namespace CriticalDTM

instance magneticHilbert_nontrivial : Nontrivial MagneticHilbert := by
  refine ⟨⟨hilbertRoot, 0, ?_⟩⟩
  intro h
  have hc := congrArg (fun u : MagneticHilbert => u origin) h
  simp at hc

private theorem four_term_norm_bound
    {V : Type*} [NormedAddCommGroup V] [NormedSpace ℂ V]
    (a b c d : V) (lam : ℂ)
    (ha : ‖a‖ ≤ 1) (hb : ‖b‖ ≤ 1) (hc : ‖c‖ ≤ 1) (hd : ‖d‖ ≤ 1) :
    ‖a + b + lam • c + lam • d‖ ≤ 2 + 2 * ‖lam‖ := by
  have hab : ‖a + b‖ ≤ 2 := (norm_add_le a b).trans (by linarith)
  have hc' : ‖lam • c‖ ≤ ‖lam‖ := by
    rw [norm_smul]
    simpa only [mul_one] using mul_le_mul_of_nonneg_left hc (norm_nonneg lam)
  have hd' : ‖lam • d‖ ≤ ‖lam‖ := by
    rw [norm_smul]
    simpa only [mul_one] using mul_le_mul_of_nonneg_left hd (norm_nonneg lam)
  calc
    ‖a + b + lam • c + lam • d‖ ≤ ‖a + b + lam • c‖ + ‖lam • d‖ := norm_add_le _ _
    _ ≤ ‖a + b‖ + ‖lam • c‖ + ‖lam • d‖ :=
      add_le_add_right (norm_add_le _ _) _
    _ ≤ 2 + 2 * ‖lam‖ := by linarith

theorem hOperator_norm_le (α : ℝ) (lam : ℂ) :
    ‖hOperator α lam‖ ≤ 2 + 2 * ‖lam‖ := by
  unfold hOperator
  apply four_term_norm_bound
  all_goals apply twistedOperator_norm_le

theorem hOperator_norm_le_four (α : ℝ) {lam : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam ≤ 1) :
    ‖hOperator α (lam : ℂ)‖ ≤ 4 := by
  have h := hOperator_norm_le α (lam : ℂ)
  have hn : ‖(lam : ℂ)‖ = lam := by simp [abs_of_nonneg hlam0]
  rw [hn] at h
  linarith

theorem real_spectral_energy_bound (α : ℝ) {lam E : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam ≤ 1)
    (hE : (E : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ))) :
    |E| ≤ 4 := by
  have h := (spectrum.norm_le_norm_of_mem hE).trans
    (hOperator_norm_le_four α hlam0 hlam1)
  simpa using h

theorem real_spectral_energy_mem_Icc (α : ℝ) {lam E : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam ≤ 1)
    (hE : (E : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ))) :
    E ∈ Set.Icc (-4 : ℝ) 4 :=
  abs_le.mp (real_spectral_energy_bound α hlam0 hlam1 hE)

/-- Any energy between two real spectral edges has the same uniform bound.
This applies to a gap maximizer once the two spectral edges are supplied. -/
theorem energy_between_spectral_edges_mem_Icc (α : ℝ) {lam a b E : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam ≤ 1)
    (ha : (a : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ)))
    (hb : (b : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ)))
    (haE : a ≤ E) (hEb : E ≤ b) : E ∈ Set.Icc (-4 : ℝ) 4 := by
  have hba := real_spectral_energy_mem_Icc α hlam0 hlam1 ha
  have hbb := real_spectral_energy_mem_Icc α hlam0 hlam1 hb
  exact ⟨hba.1.trans haE, hEb.trans hbb.2⟩

end CriticalDTM

import DTM.Background.Avalanche.AMOAvalancheAverageDeviations

/-!
# Finite ordinary dyadic propagation for the actual AMO exponent

The four-block weighted avalanche estimate contracts successive dyadic
Lyapunov drops. Its growth and adjacent-pair conditions are recovered inside
the induction from the initial finite pair. The only measure hypothesis is a
uniform bound for the actual finite deviation masses at lengths at least `N`.

The number of steps is finite and satisfies `r * ε ≤ κ`. A fixed positive
error does not give an infinite-scale positivity conclusion.
-/

noncomputable section
open MeasureTheory Set
namespace CriticalDTM

/-- A uniform error for the four-block estimate at every length at least `N`,
while the inductively proved lower bound is at least `400κ`. -/
def amoDyadicPropagationError (lam : ℝ) (z : ℂ) (N : ℕ) (κ δ : ℝ) : ℝ :=
  4000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) +
    16 * Real.log (amoTransferBound lam z) * δ

theorem amoDyadicPropagationError_nonneg (lam : ℝ) (z : ℂ) (N : ℕ)
    {κ δ : ℝ} (hδ : 0 ≤ δ) : 0 ≤ amoDyadicPropagationError lam z N κ δ := by
  unfold amoDyadicPropagationError
  exact add_nonneg (by positivity)
    (mul_nonneg (mul_nonneg (by norm_num)
      (Real.log_nonneg (amoTransferBound_one_le lam z))) hδ)

/-- Actual integrated subadditivity, not an extra monotonicity hypothesis. -/
theorem amoFiniteLyapunov_double_le (α lam : ℝ) (z : ℂ) (N : ℕ) :
    amoFiniteLyapunov α lam z (2 * N) ≤ amoFiniteLyapunov α lam z N := by
  by_cases hN : N = 0
  · subst N
    simp
  have hNr : (0 : ℝ) < (N : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hN
  have h := amoTransferLogAverage_subadditive α lam z N N
  rw [← two_mul N] at h
  simp only [amoAvalanche_average_eq_mul_finite, Nat.cast_mul, Nat.cast_ofNat] at h
  nlinarith

/-- Four-block averaged AP with a common error. The positivity and pair
hypotheses are local to this one scale, not assumptions about future scales. -/
theorem amoFiniteLyapunov_dyadic_step_of_deviation_masses
    (α lam : ℝ) (z : ℂ) (N M : ℕ) (hN : 0 < N) (hNM : N ≤ M)
    {κ δ : ℝ} (hκ : 0 < κ)
    (hscale : Real.log 10000 ≤ 200 * κ * (N : ℝ))
    (hL : 400 * κ ≤ amoFiniteLyapunov α lam z M)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z M ≤
      amoFiniteLyapunov α lam z (2 * M))
    (hbadM : (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z M κ) ≤ δ)
    (hbad2M : (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z (2 * M) κ) ≤ δ) :
    |amoFiniteLyapunov α lam z (4 * M) +
      (1 / 2 : ℝ) * amoFiniteLyapunov α lam z M -
      (3 / 2 : ℝ) * amoFiniteLyapunov α lam z (2 * M)| ≤
        amoDyadicPropagationError lam z N κ δ := by
  have hM : 0 < M := hN.trans_le hNM
  have hNr : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN
  have hNMr : (N : ℝ) ≤ (M : ℝ) := by exact_mod_cast hNM
  have hexp : 200 * κ * (N : ℝ) ≤
      (M : ℝ) * amoFiniteLyapunov α lam z M / 2 := by
    have h1 := mul_le_mul_of_nonneg_left hNMr (show 0 ≤ 200 * κ by positivity)
    have h2 := mul_le_mul_of_nonneg_left hL (Nat.cast_nonneg M : (0 : ℝ) ≤ M)
    nlinarith
  have hden : (N : ℝ) * Real.exp (200 * κ * (N : ℝ)) ≤
      (M : ℝ) * Real.exp ((M : ℝ) * amoFiniteLyapunov α lam z M / 2) :=
    mul_le_mul hNMr (Real.exp_le_exp.mpr hexp) (Real.exp_pos _).le (Nat.cast_nonneg M)
  have hden0 : 0 < (N : ℝ) * Real.exp (200 * κ * (N : ℝ)) := by positivity
  have herr : 1000 / ((M : ℝ) *
      Real.exp ((M : ℝ) * amoFiniteLyapunov α lam z M / 2)) ≤
      4000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) := by
    calc
      _ ≤ 1000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) :=
        div_le_div_of_nonneg_left (by norm_num) hden0 hden
      _ ≤ _ := div_le_div_of_nonneg_right (by norm_num) hden0.le
  have h := (amoFiniteLyapunov_avalanche_of_deviation_masses α lam z M 2 hM
    hκ hL hL2 (hscale.trans hexp) hbadM hbad2M).1
  norm_num at h
  exact h.trans (by unfold amoDyadicPropagationError; nlinarith [herr])

/-- A finite scalar induction for the weighted four-block recurrence. The
recurrence is required only under the current good conditions; those
conditions at every subsequent step are conclusions of the induction. -/
theorem dyadicPropagation_of_conditional_recurrence (a : ℕ → ℝ)
    {κ ε : ℝ} (hκ : 0 < κ) (hε : 0 ≤ ε) (hεκ : ε ≤ κ)
    (hmono : ∀ j, a (j + 1) ≤ a j)
    (hinitial : 1000 * κ ≤ a 0)
    (hpair : a 0 - a 1 ≤ a 0 / 20)
    (hstep : ∀ j, 400 * κ ≤ a j → (9 / 10 : ℝ) * a j ≤ a (j + 1) →
      |a (j + 2) + (1 / 2 : ℝ) * a j - (3 / 2 : ℝ) * a (j + 1)| ≤ ε)
    (r : ℕ) (hr : (r : ℝ) * ε ≤ κ) :
    (a 0 - 2 * (a 0 - a 1) - 2 * (r : ℝ) * ε ≤ a r) ∧
    (a r - a (r + 1) ≤ (1 / 2 : ℝ) ^ r * (a 0 - a 1) + 2 * ε) ∧
    (898 * κ ≤ a r) ∧
    ((9 / 10 : ℝ) * a r ≤ a (r + 1)) ∧
    (|(2 * a (r + 1) - a r) - (2 * a 1 - a 0)| ≤ 2 * (r : ℝ) * ε) := by
  have hd0 : 0 ≤ a 0 - a 1 := sub_nonneg.mpr (hmono 0)
  have hfinish (j : ℕ) (hj : (j : ℝ) * ε ≤ κ)
      (hd : a j - a (j + 1) ≤ (1 / 2 : ℝ) ^ j * (a 0 - a 1) + 2 * ε)
      (hp : |(2 * a (j + 1) - a j) - (2 * a 1 - a 0)| ≤ 2 * (j : ℝ) * ε) :
      (a 0 - 2 * (a 0 - a 1) - 2 * (j : ℝ) * ε ≤ a j) ∧
      (898 * κ ≤ a j) ∧ ((9 / 10 : ℝ) * a j ≤ a (j + 1)) := by
    have hlower : a 0 - 2 * (a 0 - a 1) - 2 * (j : ℝ) * ε ≤ a j := by
      linarith [(abs_le.mp hp).1, hmono j]
    have hpow : (1 / 2 : ℝ) ^ j ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
    have hrough : a j - a (j + 1) ≤ a 0 - a 1 + 2 * ε := by
      have ht := mul_le_mul_of_nonneg_right hpow hd0
      linarith
    refine ⟨hlower, ?_, ?_⟩ <;> linarith
  induction r with
  | zero =>
      have hd : a 0 - a 1 ≤ (1 / 2 : ℝ) ^ 0 * (a 0 - a 1) + 2 * ε := by
        simp only [pow_zero, one_mul]
        linarith
      have hp : |(2 * a (0 + 1) - a 0) - (2 * a 1 - a 0)| ≤
          2 * ((0 : ℕ) : ℝ) * ε := by norm_num
      obtain ⟨hlower, hlarge, hnext⟩ := hfinish 0 hr hd hp
      exact ⟨hlower, hd, hlarge, hnext, hp⟩
  | succ r ih =>
      have hr' : (r : ℝ) * ε ≤ κ := by
        push_cast at hr
        nlinarith
      obtain ⟨_, hd, hlarge, hnext, hp⟩ := ih hr'
      have hs := hstep r (by linarith) hnext
      have hrec : a (r + 1) - a (r + 2) ≤ (a r - a (r + 1)) / 2 + ε := by
        linarith [(abs_le.mp hs).1]
      have hd' : a (r + 1) - a (r + 1 + 1) ≤
          (1 / 2 : ℝ) ^ (r + 1) * (a 0 - a 1) + 2 * ε := by
        rw [pow_succ]
        have hh := mul_le_mul_of_nonneg_left hd (show (0 : ℝ) ≤ 1 / 2 by norm_num)
        have hidx : r + 1 + 1 = r + 2 := by omega
        rw [hidx]
        nlinarith
      have hpdiff : |(2 * a (r + 1 + 1) - a (r + 1)) - (2 * a (r + 1) - a r)| ≤
          2 * ε := by
        have heq : (2 * a (r + 1 + 1) - a (r + 1)) - (2 * a (r + 1) - a r) =
            2 * (a (r + 2) + (1 / 2 : ℝ) * a r - (3 / 2 : ℝ) * a (r + 1)) := by
          rw [show r + 1 + 1 = r + 2 by omega]
          ring
        rw [heq, abs_mul, abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2)]
        exact mul_le_mul_of_nonneg_left hs (by norm_num)
      have hp' : |(2 * a (r + 1 + 1) - a (r + 1)) - (2 * a 1 - a 0)| ≤
          2 * ((r + 1 : ℕ) : ℝ) * ε := by
        have ht := (abs_add
          ((2 * a (r + 1 + 1) - a (r + 1)) - (2 * a (r + 1) - a r))
          ((2 * a (r + 1) - a r) - (2 * a 1 - a 0))).trans (add_le_add hpdiff hp)
        push_cast
        convert ht using 1 <;> congr 1 <;> ring
      obtain ⟨hlower, hlarge', hnext'⟩ := hfinish (r + 1) hr hd' hp'
      exact ⟨hlower, hd', hlarge', hnext', hp'⟩

/-- Ordinary dyadic propagation for the actual phase-averaged transfer
exponents. Uniform finite deviation masses are the only measure input.
Neither positivity nor a lower bound for the infinite-scale exponent is
assumed. The finite-pair lower estimate, geometric drop estimate, and both
AP conditions are propagated for every `r` in the stated error budget. -/
theorem amoFiniteLyapunov_dyadic_propagation
    (α lam : ℝ) (z : ℂ) (N : ℕ) (hN : 0 < N)
    {κ δ : ℝ} (hκ : 0 < κ) (hδ : 0 ≤ δ)
    (hscale : Real.log 10000 ≤ 200 * κ * (N : ℝ))
    (hinitial : 1000 * κ ≤ amoFiniteLyapunov α lam z N)
    (hpair : amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N) ≤
      amoFiniteLyapunov α lam z N / 20)
    (hbad : ∀ M, N ≤ M → (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z M κ) ≤ δ)
    (herror : amoDyadicPropagationError lam z N κ δ ≤ κ)
    (r : ℕ) (hr : (r : ℝ) * amoDyadicPropagationError lam z N κ δ ≤ κ) :
    (amoFiniteLyapunov α lam z N -
        2 * (amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)) -
        2 * (r : ℝ) * amoDyadicPropagationError lam z N κ δ ≤
      amoFiniteLyapunov α lam z (2 ^ r * N)) ∧
    (0 ≤ amoFiniteLyapunov α lam z (2 ^ r * N) -
      amoFiniteLyapunov α lam z (2 ^ (r + 1) * N)) ∧
    (amoFiniteLyapunov α lam z (2 ^ r * N) -
        amoFiniteLyapunov α lam z (2 ^ (r + 1) * N) ≤
      (1 / 2 : ℝ) ^ r *
        (amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)) +
        2 * amoDyadicPropagationError lam z N κ δ) ∧
    (898 * κ ≤ amoFiniteLyapunov α lam z (2 ^ r * N)) ∧
    ((9 / 10 : ℝ) * amoFiniteLyapunov α lam z (2 ^ r * N) ≤
      amoFiniteLyapunov α lam z (2 ^ (r + 1) * N)) ∧
    (|(2 * amoFiniteLyapunov α lam z (2 ^ (r + 1) * N) -
          amoFiniteLyapunov α lam z (2 ^ r * N)) -
        (2 * amoFiniteLyapunov α lam z (2 * N) - amoFiniteLyapunov α lam z N)| ≤
      2 * (r : ℝ) * amoDyadicPropagationError lam z N κ δ) := by
  let a : ℕ → ℝ := fun j => amoFiniteLyapunov α lam z (2 ^ j * N)
  have hsucc (j : ℕ) : 2 ^ (j + 1) * N = 2 * (2 ^ j * N) := by
    simp only [pow_succ]
    ring
  have htwo (j : ℕ) : 2 ^ (j + 2) * N = 4 * (2 ^ j * N) := by
    rw [pow_add]
    norm_num
    ring
  have hmono (j : ℕ) : a (j + 1) ≤ a j := by
    dsimp only [a]
    rw [hsucc]
    exact amoFiniteLyapunov_double_le α lam z _
  have hstep (j : ℕ) (hL : 400 * κ ≤ a j)
      (hL2 : (9 / 10 : ℝ) * a j ≤ a (j + 1)) :
      |a (j + 2) + (1 / 2 : ℝ) * a j - (3 / 2 : ℝ) * a (j + 1)| ≤
        amoDyadicPropagationError lam z N κ δ := by
    have hNM : N ≤ 2 ^ j * N := by
      have hp : 1 ≤ (2 : ℕ) ^ j := one_le_pow₀ (by norm_num)
      simpa only [one_mul] using Nat.mul_le_mul_right N hp
    have hN2M : N ≤ 2 * (2 ^ j * N) := by omega
    have hL2' : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z (2 ^ j * N) ≤
        amoFiniteLyapunov α lam z (2 * (2 ^ j * N)) := by
      simpa only [a, hsucc] using hL2
    have h := amoFiniteLyapunov_dyadic_step_of_deviation_masses α lam z N (2 ^ j * N)
      hN hNM hκ hscale hL hL2' (hbad _ hNM) (hbad _ hN2M)
    dsimp only [a]
    rw [htwo j, hsucc j]
    exact h
  have h := dyadicPropagation_of_conditional_recurrence a hκ
    (amoDyadicPropagationError_nonneg lam z N hδ) herror hmono
    (by simpa only [a, pow_zero, one_mul] using hinitial)
    (by simpa only [a, pow_zero, one_mul, pow_one] using hpair) hstep r hr
  rcases h with ⟨hlower, hdrop, hlarge, hnext, hpotential⟩
  have hdnonneg : 0 ≤ a r - a (r + 1) := sub_nonneg.mpr (hmono r)
  have hresult := And.intro hlower (And.intro hdnonneg
    (And.intro hdrop (And.intro hlarge (And.intro hnext hpotential))))
  simpa only [a, pow_zero, one_mul, pow_one] using hresult

end CriticalDTM

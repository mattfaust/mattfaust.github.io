import DTM.Background.Transfer.AMOLyapunov
import DTM.Background.Records.RotationRecords
import Mathlib.Topology.Instances.Irrational

/-!
# Open finite seeds and extension from irrational frequencies

Fekete convergence at a single irrational frequency selects an arbitrarily
large rotation record with a positive finite exponent and a small two-scale
difference. Only these finite, continuous data are retained on the resulting
open neighborhood; positivity of the limiting exponent at neighboring
parameters is neither assumed nor asserted.

Separately, upper semicontinuity extends a lower bound already proved on the
irrational points of an open set to every point of that set.
-/

noncomputable section

open Filter Set
open scoped Topology

namespace CriticalDTM

/-- A lower bound on a dense part of an open set extends by upper
semicontinuity. This does not assert persistence from a single point. -/
theorem le_of_upperSemicontinuous_on_dense_open
    {X : Type*} [TopologicalSpace X] {f : X → ℝ} {D U : Set X} {c : ℝ}
    (hf : UpperSemicontinuous f) (hD : Dense D) (hU : IsOpen U)
    (h : ∀ x ∈ U ∩ D, c ≤ f x) : ∀ x ∈ U, c ≤ f x := by
  intro x hx
  by_contra hxc
  have hxc' : f x < c := lt_of_not_ge hxc
  obtain ⟨y, hyD, hyU, hyc⟩ := hD.exists_mem_open
    (hU.inter (hf.isOpen_preimage c)) ⟨x, hx, hxc'⟩
  exact (not_lt_of_ge (h y ⟨hyU, hyD⟩)) hyc

/-- Irrational frequencies are dense even when the energy coordinate varies. -/
theorem dense_irrational_frequency : Dense {p : ℝ × ℝ | Irrational p.1} := by
  convert dense_irrational.prod (dense_univ : Dense (univ : Set ℝ)) using 1
  ext p
  simp

/-- The actual transfer exponent is upper semicontinuous on the real
frequency-energy plane at every fixed coupling. -/
theorem amoLyapunov_upperSemicontinuous_fixedCoupling (lam : ℝ) :
    UpperSemicontinuous (fun p : ℝ × ℝ => amoLyapunov p.1 lam (p.2 : ℂ)) := by
  have hmap : Continuous (fun p : ℝ × ℝ => (p.1, lam, (p.2 : ℂ))) :=
    continuous_fst.prodMk (continuous_const.prodMk
      (Complex.continuous_ofReal.comp continuous_snd))
  have h := amoLyapunov_upperSemicontinuous.comp_continuous hmap
  exact h

/-- A lower bound proved at all irrational frequencies in an open set also
holds at rational frequencies, with no additional continuity hypothesis. -/
theorem amoLyapunov_lowerBound_of_irrational_on_open (lam : ℝ)
    {U : Set (ℝ × ℝ)} {c : ℝ} (hU : IsOpen U)
    (h : ∀ p ∈ U, Irrational p.1 → c ≤ amoLyapunov p.1 lam (p.2 : ℂ)) :
    ∀ p ∈ U, c ≤ amoLyapunov p.1 lam (p.2 : ℂ) := by
  apply le_of_upperSemicontinuous_on_dense_open
    (amoLyapunov_upperSemicontinuous_fixedCoupling lam) dense_irrational_frequency hU
  intro p hp
  exact h p hp.1 hp.2

/-- Each finite level is continuous on the real frequency-energy plane. -/
theorem continuous_amoFiniteLyapunov_fixedCoupling (lam : ℝ) (n : ℕ) :
    Continuous (fun p : ℝ × ℝ => amoFiniteLyapunov p.1 lam (p.2 : ℂ) n) := by
  have hmap : Continuous (fun p : ℝ × ℝ => (p.1, lam, (p.2 : ℂ))) :=
    continuous_fst.prodMk (continuous_const.prodMk
      (Complex.continuous_ofReal.comp continuous_snd))
  have h := (continuous_amoFiniteLyapunov n).comp hmap
  exact h

/-- A positive limiting exponent at one irrational center supplies an open
seed consisting solely of strict finite-scale data. No bound on the coupling
or rate of Fekete convergence is needed. -/
theorem exists_amoFiniteSeed_open {α lam E κ : ℝ}
    (hα : Irrational α) (hE : |E| < 5) (hκ : 0 < κ)
    (hL : 16000 * κ < amoLyapunov α lam (E : ℂ)) (Q : ℕ) :
    ∃ q₀ : ℕ, max Q 8 ≤ q₀ ∧ ∃ U : Set (ℝ × ℝ),
      IsOpen U ∧ (α, E) ∈ U ∧ ∀ p ∈ U,
        rotationRecord p.1 q₀ ∧ |p.2| < 5 ∧
          8000 * κ < amoFiniteLyapunov p.1 lam (p.2 : ℂ) (q₀ ^ 4) ∧
          amoFiniteLyapunov p.1 lam (p.2 : ℂ) (q₀ ^ 4) -
            amoFiniteLyapunov p.1 lam (p.2 : ℂ) (2 * q₀ ^ 4) < κ / 100 := by
  have hupper : ∀ᶠ n in atTop,
      amoFiniteLyapunov α lam (E : ℂ) n < amoLyapunov α lam (E : ℂ) + κ / 200 :=
    (tendsto_amoFiniteLyapunov α lam (E : ℂ)).eventually
      (gt_mem_nhds (show amoLyapunov α lam (E : ℂ) <
        amoLyapunov α lam (E : ℂ) + κ / 200 by linarith))
  obtain ⟨N, hN⟩ := eventually_atTop.mp hupper
  obtain ⟨q₀, hq₀, hrecord⟩ := exists_rotationRecord_gt hα (max (max Q 8) N)
  have hqQ : max Q 8 ≤ q₀ := (le_max_left _ _).trans (Nat.le_of_lt hq₀)
  have hqN : N ≤ q₀ := (le_max_right _ _).trans (Nat.le_of_lt hq₀)
  have hqpow : q₀ ≤ q₀ ^ 4 := Nat.le_self_pow (by decide) q₀
  have hpow : 1 ≤ q₀ ^ 4 := (Nat.succ_le_iff.mpr hrecord.1).trans hqpow
  have hfinite : 8000 * κ < amoFiniteLyapunov α lam (E : ℂ) (q₀ ^ 4) := by
    have hlower := amoLyapunov_le_finite α lam (E : ℂ) hpow
    linarith only [hκ, hL, hlower]
  have hdiff : amoFiniteLyapunov α lam (E : ℂ) (q₀ ^ 4) -
      amoFiniteLyapunov α lam (E : ℂ) (2 * q₀ ^ 4) < κ / 100 := by
    have hn := hN (q₀ ^ 4) (hqN.trans hqpow)
    have h2n := amoLyapunov_le_finite α lam (E : ℂ)
      (show 1 ≤ 2 * q₀ ^ 4 by omega)
    linarith only [hκ, hn, h2n]
  let U : Set (ℝ × ℝ) := {p | rotationRecord p.1 q₀ ∧ |p.2| < 5 ∧
    8000 * κ < amoFiniteLyapunov p.1 lam (p.2 : ℂ) (q₀ ^ 4) ∧
    amoFiniteLyapunov p.1 lam (p.2 : ℂ) (q₀ ^ 4) -
      amoFiniteLyapunov p.1 lam (p.2 : ℂ) (2 * q₀ ^ 4) < κ / 100}
  have hU : IsOpen U :=
    ((isOpen_rotationRecord q₀).preimage continuous_fst).inter
      ((isOpen_lt continuous_snd.abs continuous_const).inter
        ((isOpen_lt continuous_const
          (continuous_amoFiniteLyapunov_fixedCoupling lam (q₀ ^ 4))).inter
          (isOpen_lt ((continuous_amoFiniteLyapunov_fixedCoupling lam (q₀ ^ 4)).sub
            (continuous_amoFiniteLyapunov_fixedCoupling lam (2 * q₀ ^ 4))) continuous_const)))
  exact ⟨q₀, hqQ, U, hU, ⟨hrecord, hE, hfinite, hdiff⟩, fun _ hp => hp⟩

end CriticalDTM

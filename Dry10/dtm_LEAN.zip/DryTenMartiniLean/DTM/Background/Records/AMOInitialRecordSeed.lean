import DTM.Background.Records.AMORecordTransition
import DTM.Background.Records.AMORecordParameters

/-!
# Preparing the initial sextic record seed

The weighted averaged avalanche principle at `q²` and `2q²` blocks turns a
high finite pair at `q⁴` into the sextic seed used by record propagation.
The two actual exceptional masses come from `AMORecordBadMasses`; neither
the prepared seed nor an infinite-scale lower bound is assumed.
-/

noncomputable section
open MeasureTheory Set Filter
namespace CriticalDTM

/-- The weighted averaged AP at an arbitrary block count, with its endpoint
correction expressed as the actual finite dyadic drop. -/
private theorem initialSeed_avalanche_blocks
    (α lam : ℝ) (z : ℂ) (N m : ℕ) (hN : 0 < N) (hm : 2 ≤ m)
    {κ δ : ℝ} (hκ : 0 < κ)
    (hL : 400 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤
      amoFiniteLyapunov α lam z (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2)
    (hbadN : (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z N κ) ≤ δ)
    (hbad2N : (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z (2 * N) κ) ≤ δ) :
    |amoFiniteLyapunov α lam z (m * N) - amoFiniteLyapunov α lam z N +
      2 * (1 - 1 / (m : ℝ)) * amoRecordGap α lam z N| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
          4 * Real.log (amoTransferBound lam z) * (m : ℝ) * δ := by
  have hmidx : m - 2 + 2 = m := Nat.sub_add_cancel hm
  have hmr : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have h := (amoFiniteLyapunov_avalanche_of_deviation_masses α lam z N (m - 2)
    hN hκ hL hL2 hscale hbadN hbad2N).1
  simp only [hmidx, Nat.cast_add, Nat.cast_one, Nat.cast_sub hm, Nat.cast_ofNat] at h
  have heq : amoFiniteLyapunov α lam z (m * N) +
      ((m : ℝ) - 2) / (m : ℝ) * amoFiniteLyapunov α lam z N -
      (2 * ((m : ℝ) - 2 + 1) / (m : ℝ)) * amoFiniteLyapunov α lam z (2 * N) =
        amoFiniteLyapunov α lam z (m * N) - amoFiniteLyapunov α lam z N +
          2 * (1 - 1 / (m : ℝ)) * amoRecordGap α lam z N := by
    unfold amoRecordGap
    field_simp [hmr.ne']
    ring
  rw [heq] at h
  exact h

/-- At `m` and `2m` blocks, the exact endpoint correction damps the initial
finite drop by `1/m`. The exceptional-set errors retain their actual block
counts. -/
private theorem initialSeed_avalanche_pair
    (α lam : ℝ) (z : ℂ) (N m : ℕ) (hN : 0 < N) (hm : 2 ≤ m)
    {κ δ : ℝ} (hκ : 0 < κ)
    (hL : 400 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤
      amoFiniteLyapunov α lam z (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2)
    (hbadN : (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z N κ) ≤ δ)
    (hbad2N : (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z (2 * N) κ) ≤ δ) :
    amoFiniteLyapunov α lam z N - 2 * amoRecordGap α lam z N -
        (1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
          4 * Real.log (amoTransferBound lam z) * (m : ℝ) * δ) ≤
      amoFiniteLyapunov α lam z (m * N) ∧
    amoRecordGap α lam z (m * N) ≤ amoRecordGap α lam z N / (m : ℝ) +
      (2000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
        12 * Real.log (amoTransferBound lam z) * (m : ℝ) * δ) := by
  have h1 := initialSeed_avalanche_blocks α lam z N m hN hm hκ hL hL2 hscale hbadN hbad2N
  have h2 := initialSeed_avalanche_blocks α lam z N (2 * m) hN (by omega)
    hκ hL hL2 hscale hbadN hbad2N
  have hmr : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hcoef : 2 * (1 - 1 / ((2 * m : ℕ) : ℝ)) - 2 * (1 - 1 / (m : ℝ)) =
      1 / (m : ℝ) := by push_cast; field_simp [hmr.ne']; ring
  have hidx : 2 * m * N = 2 * (m * N) := by ring
  rw [hidx] at h2
  constructor
  · have hnonneg := div_nonneg (amoRecordGap_nonneg α lam z N) hmr.le
    have hcoef1 : 2 * (1 - 1 / (m : ℝ)) * amoRecordGap α lam z N =
        2 * amoRecordGap α lam z N - 2 * (amoRecordGap α lam z N / (m : ℝ)) := by ring
    rw [hcoef1] at h1
    linarith only [hnonneg, (abs_le.mp h1).1]
  · have hc := congrArg (fun t : ℝ => t * amoRecordGap α lam z N) hcoef
    dsimp only at hc
    dsimp only [amoRecordGap]
    dsimp only [amoRecordGap] at h1 h2 hc
    rw [sub_mul] at hc
    simp only [Nat.cast_mul, Nat.cast_ofNat, div_eq_mul_inv, one_mul] at h1 h2 hc ⊢
    nlinarith only [hc, (abs_le.mp h1).2, (abs_le.mp h2).1]

/-- The finite preparation with its explicit scalar conditions. These
conditions are all discharged in the public threshold theorem below. -/
private theorem initialSeed_of_scalar
    (α lam : ℝ) (z : ℂ) (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5)
    {κ C c : ℝ} (hκ : 0 < κ) (hCκ : c / (100 * κ) ≤ C)
    {q : ℕ} (hq8 : 8 ≤ q)
    (hNC : C * (q : ℝ) ≤ (q : ℝ) ^ 4)
    (hscale : Real.log 10000 ≤ 200 * κ * (q : ℝ) ^ 4)
    (hseed : amoRecordErrorConstant * (q : ℝ) ^ 4 * Real.exp (-c * (q : ℝ)) ≤ κ / 100)
    (hbad : AMORecordBadMasses α lam z κ C c q)
    (hL : 8000 * κ ≤ amoFiniteLyapunov α lam z (q ^ 4))
    (hd : amoRecordGap α lam z (q ^ 4) ≤ κ / 100) :
    4000 * κ ≤ amoFiniteLyapunov α lam z (q ^ 6) ∧
      ((q ^ 6 : ℕ) : ℝ) * amoRecordGap α lam z (q ^ 6) ≤ κ * (q : ℝ) ^ 4 / 50 := by
  have hq : 0 < q := by omega
  have hqr : (0 : ℝ) < q := by exact_mod_cast hq
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast (show 1 ≤ q by omega)
  have hN : 0 < q ^ 4 := pow_pos hq 4
  have hNr : (0 : ℝ) < ((q ^ 4 : ℕ) : ℝ) := by exact_mod_cast hN
  have hm : 2 ≤ q ^ 2 := (by norm_num : 2 ≤ (8 : ℕ) ^ 2).trans (Nat.pow_le_pow_left hq8 2)
  have hm1 : (1 : ℝ) ≤ (q : ℝ) ^ 2 := one_le_pow₀ hq1
  have hNC' : C * (q : ℝ) ≤ ((q ^ 4 : ℕ) : ℝ) := by simpa only [Nat.cast_pow] using hNC
  have hexp : 200 * κ * ((q ^ 4 : ℕ) : ℝ) ≤
      ((q ^ 4 : ℕ) : ℝ) * amoFiniteLyapunov α lam z (q ^ 4) / 2 := by
    have h := mul_le_mul_of_nonneg_left hL hNr.le
    nlinarith only [h, mul_nonneg hκ.le hNr.le]
  have hscale' : Real.log 10000 ≤
      ((q ^ 4 : ℕ) : ℝ) * amoFiniteLyapunov α lam z (q ^ 4) / 2 := by
    apply le_trans _ hexp
    simpa only [Nat.cast_pow] using hscale
  have hpair : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z (q ^ 4) ≤
      amoFiniteLyapunov α lam z (2 * q ^ 4) := by
    unfold amoRecordGap at hd
    linarith only [hL, hd, hκ]
  obtain ⟨hheight, hdrop⟩ := initialSeed_avalanche_pair α lam z (q ^ 4) (q ^ 2) hN hm
    hκ (by linarith only [hL, hκ]) hpair hscale' (hbad (q ^ 4) hNC').1
    (hbad (2 * q ^ 4) (by
      simp only [Nat.cast_mul, Nat.cast_ofNat]
      linarith only [hNC', hNr])).1
  have hidx : q ^ 2 * q ^ 4 = q ^ 6 := by ring
  rw [hidx] at hheight hdrop
  let A : ℝ := 1000 / (((q ^ 4 : ℕ) : ℝ) *
    Real.exp (((q ^ 4 : ℕ) : ℝ) * amoFiniteLyapunov α lam z (q ^ 4) / 2))
  let B : ℝ := Real.log (amoTransferBound lam z)
  let δ : ℝ := Real.exp (-c * (q : ℝ))
  let E : ℝ := 2 * A + 12 * B * (q : ℝ) ^ 2 * δ
  have hA0 : 0 ≤ A := by dsimp only [A]; positivity
  have hB0 : 0 ≤ B := Real.log_nonneg (amoTransferBound_one_le lam z)
  have hδ0 : 0 ≤ δ := (Real.exp_pos _).le
  have hbad0 : 0 ≤ B * (q : ℝ) ^ 2 * δ := by positivity
  have hEbound : E ≤ (q : ℝ) ^ 2 * amoDyadicPropagationError lam z (q ^ 4) κ δ := by
    have hden : ((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ)) ≤
        ((q ^ 4 : ℕ) : ℝ) *
          Real.exp (((q ^ 4 : ℕ) : ℝ) * amoFiniteLyapunov α lam z (q ^ 4) / 2) :=
      mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hexp) hNr.le
    have hA : A ≤ 1000 / (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ))) :=
      div_le_div_of_nonneg_left (by norm_num) (by positivity) hden
    have h2A : 2 * A ≤ 4000 /
        (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ))) := by
      calc
        2 * A ≤ 2 * (1000 /
            (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ)))) :=
          mul_le_mul_of_nonneg_left hA (by norm_num)
        _ = 2000 / (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ))) := by ring
        _ ≤ _ := div_le_div_of_nonneg_right (by norm_num) (by positivity)
    have hmul : 2 * A ≤ (q : ℝ) ^ 2 * (4000 /
        (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ)))) := by
      apply h2A.trans
      simpa only [one_mul] using mul_le_mul_of_nonneg_right hm1
        (show 0 ≤ 4000 / (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ))) by positivity)
    have hbadmul : 12 * B * (q : ℝ) ^ 2 * δ ≤ (q : ℝ) ^ 2 * (16 * B * δ) := by
      calc
        _ = 12 * (B * (q : ℝ) ^ 2 * δ) := by ring
        _ ≤ 16 * (B * (q : ℝ) ^ 2 * δ) := mul_le_mul_of_nonneg_right (by norm_num) hbad0
        _ = _ := by ring
    calc
      E ≤ (q : ℝ) ^ 2 * (4000 /
          (((q ^ 4 : ℕ) : ℝ) * Real.exp (200 * κ * ((q ^ 4 : ℕ) : ℝ)))) +
          (q : ℝ) ^ 2 * (16 * B * δ) := add_le_add hmul hbadmul
      _ = _ := by dsimp only [amoDyadicPropagationError, B]; ring
  have hEsmall : E ≤ κ / (100 * (q : ℝ) ^ 2) := by
    calc
      E ≤ (q : ℝ) ^ 2 * amoDyadicPropagationError lam z (q ^ 4) κ δ := hEbound
      _ ≤ (q : ℝ) ^ 2 * (amoRecordErrorConstant * δ) :=
        mul_le_mul_of_nonneg_left (amoRecord_dyadic_error_le hlam hz hκ hCκ hq hN hNC')
          (sq_nonneg (q : ℝ))
      _ ≤ κ / (100 * (q : ℝ) ^ 2) := by
        apply (le_div_iff₀ (by positivity : 0 < 100 * (q : ℝ) ^ 2)).mpr
        dsimp only [δ]
        nlinarith only [hseed]
  have hEκ : E ≤ κ / 100 := by
    exact hEsmall.trans (div_le_div_of_nonneg_left hκ.le (by norm_num)
      (by linarith only [hm1] : (100 : ℝ) ≤ 100 * (q : ℝ) ^ 2))
  have hEm : A + 4 * B * (q : ℝ) ^ 2 * δ ≤ E := by
    dsimp only [E]
    nlinarith only [hA0, hbad0]
  have hheight' : amoFiniteLyapunov α lam z (q ^ 4) - 2 * amoRecordGap α lam z (q ^ 4) -
      (A + 4 * B * (q : ℝ) ^ 2 * δ) ≤ amoFiniteLyapunov α lam z (q ^ 6) := by
    simpa only [A, B, δ, Nat.cast_pow] using hheight
  have hdrop' : amoRecordGap α lam z (q ^ 6) ≤ amoRecordGap α lam z (q ^ 4) / (q : ℝ) ^ 2 + E := by
    convert hdrop using 1
    dsimp only [E, A, B, δ]
    push_cast
    ring
  have hdsmall : amoRecordGap α lam z (q ^ 6) ≤ κ / (50 * (q : ℝ) ^ 2) := by
    have hdiv := div_le_div_of_nonneg_right hd (sq_nonneg (q : ℝ))
    have heq : (κ / 100) / (q : ℝ) ^ 2 + κ / (100 * (q : ℝ) ^ 2) =
        κ / (50 * (q : ℝ) ^ 2) := by ring
    linarith only [hdrop', hdiv, hEsmall, heq]
  have hheightE : amoFiniteLyapunov α lam z (q ^ 4) - 2 * amoRecordGap α lam z (q ^ 4) - E ≤
      amoFiniteLyapunov α lam z (q ^ 6) :=
    (sub_le_sub_left hEm _).trans hheight'
  have hhigh : 4000 * κ ≤ amoFiniteLyapunov α lam z (q ^ 4) -
      2 * amoRecordGap α lam z (q ^ 4) - E := by
    calc
      4000 * κ ≤ 8000 * κ - 2 * (κ / 100) - κ / 100 := by linarith only [hκ]
      _ ≤ _ := sub_le_sub (sub_le_sub hL (mul_le_mul_of_nonneg_left hd (by norm_num))) hEκ
  refine ⟨hhigh.trans hheightE, ?_⟩
  have hw := mul_le_mul_of_nonneg_left hdsmall
    (pow_nonneg hqr.le 6)
  have hcancel : (q : ℝ) ^ 6 * (κ / (50 * (q : ℝ) ^ 2)) = κ * (q : ℝ) ^ 4 / 50 := by
    field_simp [hqr.ne']
    ring
  simpa only [Nat.cast_pow, hcancel] using hw

/-- Actual preprocessing of a high finite pair at `q⁴` into the sextic
record seed. The threshold depends only on the fixed scalar parameters;
all initial-scale and exponential-error conditions are proved eventually. -/
theorem amoFiniteLyapunov_prepare_record_seed
    {κ C c : ℝ} (hκ : 0 < κ) (hC : 1 ≤ C) (hc : 0 < c)
    (hCκ : c / (100 * κ) ≤ C) :
    ∃ Q : ℕ, ∀ (α lam : ℝ) (z : ℂ) (q : ℕ), Q ≤ q →
      |lam| ≤ 1 → ‖z‖ ≤ 5 → AMORecordBadMasses α lam z κ C c q →
      8000 * κ ≤ amoFiniteLyapunov α lam z (q ^ 4) →
      amoRecordGap α lam z (q ^ 4) ≤ κ / 100 →
      4000 * κ ≤ amoFiniteLyapunov α lam z (q ^ 6) ∧
        ((q ^ 6 : ℕ) : ℝ) * amoRecordGap α lam z (q ^ 6) ≤ κ * (q : ℝ) ^ 4 / 50 := by
  obtain ⟨Q₁, hQ₁⟩ := exists_amoRecordParameterBounds hκ (by linarith only [hC]) hc
    amoRecordErrorConstant_pos
  have hpow4 : Tendsto (fun q : ℕ => (q : ℝ) ^ 4) atTop atTop :=
    (tendsto_pow_atTop (by norm_num : (4 : ℕ) ≠ 0)).comp tendsto_natCast_atTop_atTop
  have hscale : ∀ᶠ q : ℕ in atTop, Real.log 10000 ≤ 200 * κ * (q : ℝ) ^ 4 :=
    (hpow4.const_mul_atTop (by positivity : 0 < 200 * κ)).eventually (eventually_ge_atTop _)
  obtain ⟨Q₂, hQ₂⟩ := eventually_atTop.mp hscale
  refine ⟨max Q₁ Q₂, ?_⟩
  intro α lam z q hq hlam hz hbad hL hd
  have hparams := hQ₁ q ((le_max_left _ _).trans hq)
  exact initialSeed_of_scalar α lam z hlam hz hκ hCκ hparams.q_ge_eight
    hparams.linear_le_pow_four (hQ₂ q ((le_max_right _ _).trans hq)) hparams.seed_error_le
    hbad hL hd

end CriticalDTM

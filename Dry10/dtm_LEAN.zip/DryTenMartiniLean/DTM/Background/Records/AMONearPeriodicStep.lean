import DTM.Background.LargeDeviation.AMOPhaseBadSetComplexity
import DTM.Background.LargeDeviation.AMOPhaseMeasure
import DTM.Background.Avalanche.AMOAvalancheAverageDeviations

/-!
# The long near-periodic averaged avalanche step for the actual AMO

When `q ∣ N`, every phase translation of an `N`-block is, modulo one, its
rational-approximation drift. Thus one hull at scale `N` and one at scale
`2*N` control arbitrarily many consecutive blocks. Their total exceptional
mass is at most `2*δ + 96*N*η`, independent of the block count except through
the arithmetic radius condition. The only deviation inputs are the two
finite Frobenius bad-set masses, centered at the actual operator Lyapunov
means. The matrix AP and the polynomial hull complexity are already proved.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory Set

/-- Rational block translations vanish on the unit circle when `q ∣ N`. -/
theorem unitCircle_nearPeriodic_shift (α : ℝ) (N j : ℕ) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) :
    ((α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) =
      ((((j * N : ℕ) : ℝ) * (α - (a : ℝ) / (q : ℝ)) : ℝ) : AddCircle (1 : ℝ)) := by
  obtain ⟨r, hr⟩ := hqN
  have hqr : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  have heq : α * ((j * N : ℕ) : ℝ) -
      ((j * N : ℕ) : ℝ) * (α - (a : ℝ) / (q : ℝ)) =
        (((j : ℤ) * (r : ℤ) * a : ℤ) : ℝ) := by
    rw [hr]
    push_cast
    field_simp
    ring
  have hz : (((((j : ℤ) * (r : ℤ) * a : ℤ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) = 0 := by
    apply (AddCircle.coe_eq_zero_iff (1 : ℝ)).mpr
    refine ⟨(j : ℤ) * (r : ℤ) * a, ?_⟩
    simp
  apply sub_eq_zero.mp
  rw [← AddCircle.coe_sub, heq, hz]

/-- One finite hull excludes all block shifts within the arithmetic radius. -/
theorem not_mem_phaseBadSet_nearPeriodic_shift
    {s : Set (AddCircle (1 : ℝ))} {x : AddCircle (1 : ℝ)}
    (α : ℝ) (N m j : ℕ) (a : ℤ) (q : ℕ) (hq : 0 < q) (hqN : q ∣ N)
    (hj : j ≤ m) {η : ℝ}
    (hnear : (((m * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hx : x ∉ phaseBadHull s η) :
    x + ((α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) ∉ s := by
  intro hbad
  apply hx
  refine ⟨((j * N : ℕ) : ℝ) * (α - (a : ℝ) / (q : ℝ)), ?_, ?_⟩
  · rw [abs_mul, abs_of_nonneg (Nat.cast_nonneg _)]
    refine le_trans ?_ hnear
    exact mul_le_mul_of_nonneg_right
      (by exact_mod_cast Nat.mul_le_mul_right N hj) (abs_nonneg _)
  · rw [← unitCircle_nearPeriodic_shift α N j a q hq hqN]
    exact hbad

/-- The two actual finite Frobenius hulls, with no union over the block count. -/
def amoNearPeriodicBadSet (α lam : ℝ) (z : ℂ) (N : ℕ) (κ η : ℝ) :
    Set (AddCircle (1 : ℝ)) :=
  phaseBadHull (amoFiniteFrobeniusBadSet α lam z N (amoFiniteLyapunov α lam z N) κ) η ∪
    phaseBadHull (amoFiniteFrobeniusBadSet α lam z (2 * N)
      (amoFiniteLyapunov α lam z (2 * N)) κ) η

theorem measurableSet_amoNearPeriodicBadSet
    (α lam : ℝ) (z : ℂ) (N : ℕ) (κ η : ℝ) :
    MeasurableSet (amoNearPeriodicBadSet α lam z N κ η) :=
  (measurableSet_amoFiniteFrobeniusBadHull α lam z N _ κ η).union
    (measurableSet_amoFiniteFrobeniusBadHull α lam z (2 * N) _ κ η)

/-- Degree `4*N` and degree `8*N` give costs `32*N*η` and `64*N*η`. -/
theorem amoNearPeriodicBadSet_mass_le
    (α lam : ℝ) (z : ℂ) (N : ℕ) (hN : 0 < N) {κ η δ : ℝ}
    (hκ : 0 ≤ κ) (hη : 0 ≤ η)
    (hbadN : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z N (amoFiniteLyapunov α lam z N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z (2 * N) (amoFiniteLyapunov α lam z (2 * N)) κ) ≤ δ) :
    AddCircle.haarAddCircle.real (amoNearPeriodicBadSet α lam z N κ η) ≤
      2 * δ + 96 * (N : ℝ) * η := by
  have h1 := measureReal_amoFiniteLyapunovBadHull_le α lam z N hN hκ hη
  have h2 := measureReal_amoFiniteLyapunovBadHull_le α lam z (2 * N) (by omega) hκ hη
  have hu := measureReal_union_le (μ := AddCircle.haarAddCircle)
    (phaseBadHull (amoFiniteFrobeniusBadSet α lam z N (amoFiniteLyapunov α lam z N) κ) η)
    (phaseBadHull (amoFiniteFrobeniusBadSet α lam z (2 * N)
      (amoFiniteLyapunov α lam z (2 * N)) κ) η)
  change AddCircle.haarAddCircle.real (_ ∪ _) ≤ _
  simp only [Nat.cast_mul, Nat.cast_ofNat] at h2
  simp only [Measure.real] at hbadN hbad2N hu ⊢
  linarith

/-- Outside the two hulls all `n+2` blocks and all `n+1` pairs are Frobenius-good. -/
theorem amoNearPeriodicBadSet_frobenius_good
    (α lam : ℝ) (z : ℂ) (N n : ℕ) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) {κ η : ℝ}
    (hnear : ((((n + 2) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (x : ℝ) (hx : (x : AddCircle (1 : ℝ)) ∉ amoNearPeriodicBadSet α lam z N κ η) :
    (∀ j < n + 2,
      |amoFiniteFrobeniusLog α lam z N (x + α * ((j * N : ℕ) : ℝ)) -
        amoFiniteLyapunov α lam z N| ≤ κ) ∧
    (∀ j < n + 1,
      |amoFiniteFrobeniusLog α lam z (2 * N) (x + α * ((j * N : ℕ) : ℝ)) -
        amoFiniteLyapunov α lam z (2 * N)| ≤ κ) := by
  have hxs := not_or.mp hx
  constructor
  · intro j hj
    have h := not_mem_phaseBadSet_nearPeriodic_shift α N (n + 2) j a q hq hqN
      (by omega) hnear hxs.1
    change ((x + α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) ∉ _ at h
    rw [mem_amoFiniteFrobeniusBadSet_coe] at h
    exact le_of_not_gt h
  · intro j hj
    have h := not_mem_phaseBadSet_nearPeriodic_shift α N (n + 2) j a q hq hqN
      (by omega) hnear hxs.2
    change ((x + α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) ∉ _ at h
    rw [mem_amoFiniteFrobeniusBadSet_coe] at h
    exact le_of_not_gt h

/-- The proved Frobenius/operator gap changes a `κ` deviation to at most `2*κ`. -/
theorem amoTransferLogNorm_deviation_le_of_frobenius
    (α lam : ℝ) (z : ℂ) (N : ℕ) (hN : 0 < N) (x c : ℝ) {κ : ℝ}
    (hκ : 0 ≤ κ) (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hf : |amoFiniteFrobeniusLog α lam z N x - c| ≤ κ) :
    |amoTransferLogNorm α lam z (2 * Real.pi * x) N / (N : ℝ) - c| ≤ 2 * κ := by
  have h := amoFiniteFrobeniusLog_sub_operator_bounds α lam z N hN x
  obtain ⟨hlo, hhi⟩ := abs_le.mp hf
  apply abs_le.mpr
  constructor <;> linarith [h.1, h.2]

/-- The actual operator-normalized block and pair deviations needed by the AP. -/
theorem amoNearPeriodicBadSet_operator_good
    (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) {κ η : ℝ} (hκ : 0 ≤ κ)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hnear : ((((n + 2) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (x : ℝ) (hx : (x : AddCircle (1 : ℝ)) ∉ amoNearPeriodicBadSet α lam z N κ η) :
    (∀ j < n + 2,
      |amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N / (N : ℝ) -
          amoFiniteLyapunov α lam z N| ≤ 2 * κ) ∧
    (∀ j < n + 1,
      |amoTransferLogNorm α lam z
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) / ((2 * N : ℕ) : ℝ) -
          amoFiniteLyapunov α lam z (2 * N)| ≤ 2 * κ) := by
  have hf := amoNearPeriodicBadSet_frobenius_good α lam z N n a q hq hqN hnear x hx
  have hgap2 : Real.log 2 / (2 * ((2 * N : ℕ) : ℝ)) ≤ κ := by
    calc
      _ = (Real.log 2 / (2 * (N : ℝ))) / 2 := by push_cast; ring
      _ ≤ κ := by linarith
  have hphase (j : ℕ) : 2 * Real.pi * (x + α * ((j * N : ℕ) : ℝ)) =
      2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ) := by ring
  constructor
  · intro j hj
    simpa only [hphase] using amoTransferLogNorm_deviation_le_of_frobenius α lam z N hN
      (x + α * ((j * N : ℕ) : ℝ)) _ hκ hgap (hf.1 j hj)
  · intro j hj
    simpa only [hphase] using amoTransferLogNorm_deviation_le_of_frobenius α lam z (2 * N)
      (by omega) (x + α * ((j * N : ℕ) : ℝ)) _ hκ hgap2 (hf.2 j hj)

/-- The genuine long near-periodic weighted averaged AP step. Its exceptional
mass has no block-count loss; only the arithmetic radius involves `n+2`. -/
theorem amoFiniteLyapunov_nearPeriodic_step
    (α lam : ℝ) (z : ℂ) (N n : ℕ) (hN : 0 < N) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) {κ η δ : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hnear : ((((n + 2) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hL : 800 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤ amoFiniteLyapunov α lam z (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2)
    (hbadN : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z N (amoFiniteLyapunov α lam z N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z (2 * N) (amoFiniteLyapunov α lam z (2 * N)) κ) ≤ δ) :
    |amoFiniteLyapunov α lam z ((n + 2) * N) +
      (1 - 2 / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z N -
      2 * (1 - 1 / (n + 2 : ℕ)) * amoFiniteLyapunov α lam z (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
          4 * Real.log (amoTransferBound lam z) * δ +
          192 * Real.log (amoTransferBound lam z) * (N : ℝ) * η := by
  let s : Set ℝ := (fun x : ℝ => (x : AddCircle (1 : ℝ))) ⁻¹'
    amoNearPeriodicBadSet α lam z N κ η
  have hs : MeasurableSet s := (measurableSet_amoNearPeriodicBadSet α lam z N κ η).preimage
    QuotientAddGroup.continuous_mk.measurable
  have hmass : (volume.restrict (Ioc (0 : ℝ) 1)).real s ≤ 2 * δ + 96 * (N : ℝ) * η := by
    rw [unitCircle_measureReal_preimage (measurableSet_amoNearPeriodicBadSet α lam z N κ η)]
    exact amoNearPeriodicBadSet_mass_le α lam z N hN hκ.le hη hbadN hbad2N
  have hμ : 10000 ≤ Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2) := by
    have h := Real.exp_le_exp.mpr hscale
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 10000)] using h
  have hgood (x : ℝ) (hx : x ∉ s) :=
    amoNearPeriodicBadSet_operator_good α lam z N n hN a q hq hqN hκ.le hgap hnear x hx
  have hconditions (x : ℝ) (hx : x ∉ s) :=
    amoAvalanche_good_of_deviations α lam z N n hN x (show 0 < 2 * κ by positivity)
      (by linarith : 400 * (2 * κ) ≤ amoFiniteLyapunov α lam z N) hL2
      (hgood x hx).1 (hgood x hx).2
  have havg := amoFiniteLyapunov_avalanche_average α lam z N n hN hμ hs hmass
    (fun x hx => (hconditions x hx).1) (fun x hx => (hconditions x hx).2)
  have hm : ((n + 2 : ℕ) : ℝ) ≠ 0 := by positivity
  have hcoeff1 : (n : ℝ) / (n + 2 : ℕ) = 1 - 2 / (n + 2 : ℕ) := by
    push_cast
    field_simp
  have hcoeff2 : (2 * (n + 1 : ℕ) / (n + 2 : ℕ) : ℝ) = 2 * (1 - 1 / (n + 2 : ℕ)) := by
    push_cast
    field_simp
    ring
  rw [hcoeff1, hcoeff2] at havg
  convert havg using 1
  ring

end CriticalDTM

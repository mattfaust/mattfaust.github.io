import DTM.Background.LargeDeviation.AMOLargeDeviation
import DTM.Background.Records.AMORecordTransition

/-!
# The actual LDT supplies both record-transition deviation inputs

One common parameter choice controls the physical operator bad set and the
Frobenius bad set centered at the physical finite mean. The auxiliary constants
also satisfy the inequalities used by the actual finite record transition.
No bad-mass estimate remains a supplied analytic premise of this theorem.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set
open scoped Topology

theorem exists_amoRecordBadMasses {κ : ℝ} (hκ : 0 < κ) (hκ1 : κ ≤ 1) :
    ∃ C c : ℝ, 1 ≤ C ∧ 0 < c ∧ c / (100 * κ) ≤ C ∧
      ∃ Q : ℕ, 8 ≤ Q ∧
        ∀ (α lam : ℝ) (z : ℂ) (a : ℤ) (q : ℕ), Q ≤ q →
          IsCoprime a (q : ℤ) →
          |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2 →
          |lam| ≤ 1 → ‖z‖ ≤ 5 → AMORecordBadMasses α lam z κ C c q := by
  let B : ℝ := 2 * Real.log 9 + Real.log 2
  have hB : 0 < B := by
    have h9 : 0 < Real.log 9 := Real.log_pos (by norm_num)
    have h2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
    dsimp [B]
    linarith
  obtain ⟨C₀, c, hC₀, hc, Q, hQ, hdev⟩ :=
    amoFiniteFrobeniusCircle_largeDeviation hB
      (by positivity : 0 < κ / 2) (by linarith : κ / 2 ≤ 1)
  let C : ℝ := max 1 (max C₀ (max (2 * Real.log 2 / κ + 1) (c / (100 * κ))))
  have hC1 : 1 ≤ C := le_max_left _ _
  have hC₀C : C₀ ≤ C := (le_max_left _ _).trans (le_max_right _ _)
  have hsizeC : 2 * Real.log 2 / κ + 1 ≤ C :=
    (le_max_left _ _).trans ((le_max_right _ _).trans (le_max_right _ _))
  have hcC : c / (100 * κ) ≤ C :=
    (le_max_right _ _).trans ((le_max_right _ _).trans (le_max_right _ _))
  have hC : 0 < C := zero_lt_one.trans_le hC1
  refine ⟨C, c, hC1, hc, hcC, Q, hQ, ?_⟩
  intro α lam z a q hq hcop happrox hlam hz
  have hqpos : 0 < q := by have := hQ.trans hq; omega
  have hqR : (0 : ℝ) < q := by exact_mod_cast hqpos
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hqpos
  have hbound : 2 * Real.log (amoTransferBound lam z) + Real.log 2 ≤ B := by
    have hK : amoTransferBound lam z ≤ 9 := by
      unfold amoTransferBound
      linarith
    have hlog := Real.log_le_log (amoTransferBound_pos lam z) hK
    dsimp [B]
    linarith
  intro M hM
  have hMr : (0 : ℝ) < M := (mul_pos hC hqR).trans_le hM
  have hMpos : 0 < M := by exact_mod_cast hMr
  have hC₀M : C₀ * (q : ℝ) ≤ M :=
    (mul_le_mul_of_nonneg_right hC₀C hqR.le).trans hM
  have hsizeM : 2 * Real.log 2 / κ ≤ (M : ℝ) := by
    calc
      _ ≤ 2 * Real.log 2 / κ + 1 := by linarith
      _ ≤ C := hsizeC
      _ ≤ C * q := le_mul_of_one_le_right hC.le hq1
      _ ≤ M := hM
  have hscale : Real.log 2 / (M : ℝ) ≤ κ / 2 := by
    have hm := (div_le_iff₀ hκ).mp hsizeM
    apply (div_le_iff₀ hMr).mpr
    nlinarith
  have htail := hdev α lam z a q M hq hcop happrox hbound hC₀M
  exact ⟨(amoAvalancheBaseBadSet_mass_le_fourier α lam z M hMpos κ hscale).trans htail,
    (amoFiniteFrobeniusBadSet_mass_le_fourier α lam z M hMpos κ hscale).trans htail⟩

end CriticalDTM

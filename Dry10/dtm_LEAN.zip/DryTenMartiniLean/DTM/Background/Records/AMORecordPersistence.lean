import DTM.Background.Records.AMORecordLDT
import DTM.Background.Records.AMORecordTransitionTheorem
import DTM.Background.Records.AMOInitialRecordSeed
import DTM.Background.Records.RecordScaleBudget
import DTM.Background.Records.AMOFiniteSeedTopology

/-!
# Positive persistence of the actual AMO Lyapunov exponent

The actual exponential LDT supplies both deviation inputs at every sufficiently
large record denominator. The proved finite transition and summable record
budget then construct an infinite sequence of high finite exponents. Fekete
convergence identifies its limit with the independently defined exponent.

Only finite seed conditions are used to obtain the local neighborhood. Record
openness and finite-level continuity make them stable; global upper
semicontinuity extends the resulting lower bound from irrational frequencies
to every point of that neighborhood. No persistence or spectral theorem is
assumed by this module.
-/

noncomputable section
namespace CriticalDTM

open Set Filter
open scoped Topology

/-- A high, nearly flat finite pair at one sufficiently large actual record
forces positivity of the genuine limiting transfer exponent. -/
theorem amoLyapunov_ge_of_record_seed {κ : ℝ} (hκ : 0 < κ) (hκ1 : κ ≤ 1) :
    ∃ Q : ℕ, ∀ (α lam : ℝ) (z : ℂ) (q₀ : ℕ),
      Irrational α → |lam| ≤ 1 → ‖z‖ ≤ 5 → Q ≤ q₀ → rotationRecord α q₀ →
      8000 * κ ≤ amoFiniteLyapunov α lam z (q₀ ^ 4) →
      amoFiniteLyapunov α lam z (q₀ ^ 4) -
        amoFiniteLyapunov α lam z (2 * q₀ ^ 4) ≤ κ / 100 →
      κ ≤ amoLyapunov α lam z := by
  obtain ⟨C, c, hC, hc, hCκ, Qd, hQd, hLDT⟩ := exists_amoRecordBadMasses hκ hκ1
  obtain ⟨Qt, htransition⟩ := amoFiniteLyapunov_record_transition hκ hC hc hCκ
  obtain ⟨Qi, hprepare⟩ := amoFiniteLyapunov_prepare_record_seed hκ hC hc hCκ
  have hγ : 0 < c / 2000 := by positivity
  obtain ⟨Qb, _, hbudget⟩ := exists_recordScale_budget
    (A := amoRecordTransitionConstant) (H := (6 : ℝ)) (γ := c / 2000)
    hκ amoRecordTransitionConstant_pos (by norm_num) hγ
  let Q := max 8 (max Qd (max Qt (max Qi Qb)))
  refine ⟨Q, ?_⟩
  intro α lam z q₀ hα hlam hz hq₀ hrecord hheight hdrop
  have hQd0 : Qd ≤ q₀ := by dsimp [Q] at hq₀; omega
  have hQt0 : Qt ≤ q₀ := by dsimp [Q] at hq₀; omega
  have hQi0 : Qi ≤ q₀ := by dsimp [Q] at hq₀; omega
  have hQb0 : Qb ≤ q₀ := by dsimp [Q] at hq₀; omega
  have hbad0 : AMORecordBadMasses α lam z κ C c q₀ :=
    hLDT α lam z (rotationNumerator α q₀) q₀ hQd0
      (rotationRecord_isCoprime hrecord) (rotationRecord_approx_lt hα hrecord) hlam hz
  have hprepared := hprepare α lam z q₀ hQi0 hlam hz hbad0 hheight hdrop
  let qs : ℕ → ℕ := rotationRecordSeq hα hrecord
  have hqs0 : qs 0 = q₀ := rotationRecordSeq_zero hα hrecord
  have hqs : StrictMono qs := rotationRecordSeq_strictMono hα hrecord
  have hq₀qs (j : ℕ) : q₀ ≤ qs j := by
    rw [← hqs0]
    exact hqs.monotone (Nat.zero_le j)
  have hbad (j : ℕ) : AMORecordBadMasses α lam z κ C c (qs j) :=
    hLDT α lam z (rotationNumerator α (qs j)) (qs j)
      (hQd0.trans (hq₀qs j)) (rotationRecordSeq_isCoprime hα hrecord j)
      (rotationRecordSeq_approx_lt hα hrecord j) hlam hz
  have hstep : RecordScaleTransition κ amoRecordTransitionConstant 6 (c / 2000)
      (amoFiniteLyapunov α lam z) qs := by
    intro j N hNlo hNhi hdiv hLN hdN
    obtain ⟨M, hMd, hNM, hMlo, hMhi, hLM, hwM⟩ :=
      htransition α lam z (qs j) (qs (j + 1)) N (rotationNumerator α (qs j))
        (hQt0.trans (hq₀qs j)) (hqs (Nat.lt_succ_self j)) hlam hz hNlo hNhi hdiv
        (rotationRecordSeq_approx_le hα hrecord j) hLN hdN (hbad j) (hbad (j + 1))
    exact ⟨M, hNM, hMlo, hMhi, hMd, hLM, hwM⟩
  have hinit : 4000 * κ ≤ amoFiniteLyapunov α lam z ((qs 0) ^ 6) := by
    simpa only [hqs0] using hprepared.1
  have hweight : (((qs 0) ^ 6 : ℕ) : ℝ) *
      recordScaleGap (amoFiniteLyapunov α lam z) ((qs 0) ^ 6) ≤
        κ * (qs 0 : ℝ) ^ 4 / 50 := by
    simpa only [hqs0, recordScaleGap, amoRecordGap] using hprepared.2
  obtain ⟨Ns, hNs⟩ := hbudget (amoFiniteLyapunov α lam z) qs hqs
    (by simpa only [hqs0] using hQb0) hinit hweight hstep
  have hlimit := (tendsto_amoFiniteLyapunov α lam z).comp hNs.tendsto
  have hlower : 2000 * κ ≤ amoLyapunov α lam z := ge_of_tendsto' hlimit hNs.height
  linarith

/-- Positive limiting exponents persist on an actual open frequency/energy
neighborhood. This theorem is proved, not an external spectral input. -/
theorem amoLyapunov_positive_persistence
    {α lam E : ℝ} (hα : Irrational α) (hlam : |lam| ≤ 1) (hE : |E| < 5)
    (hL : 0 < amoLyapunov α lam (E : ℂ)) :
    ∃ κ : ℝ, 0 < κ ∧ ∃ U : Set (ℝ × ℝ), IsOpen U ∧ (α, E) ∈ U ∧
      ∀ p ∈ U, κ ≤ amoLyapunov p.1 lam (p.2 : ℂ) := by
  let κ : ℝ := min 1 (amoLyapunov α lam (E : ℂ) / 32000)
  have hκ : 0 < κ := lt_min (by norm_num) (by positivity)
  have hκ1 : κ ≤ 1 := min_le_left _ _
  have hκL : κ ≤ amoLyapunov α lam (E : ℂ) / 32000 := min_le_right _ _
  have hmargin : 16000 * κ < amoLyapunov α lam (E : ℂ) := by linarith
  obtain ⟨Q, hseed⟩ := amoLyapunov_ge_of_record_seed hκ hκ1
  obtain ⟨q₀, hq₀, U, hU, hUE, hdata⟩ := exists_amoFiniteSeed_open hα hE hκ hmargin Q
  have hlower : ∀ p ∈ U, Irrational p.1 → κ ≤ amoLyapunov p.1 lam (p.2 : ℂ) := by
    intro p hp hpirr
    obtain ⟨hpRecord, hpWindow, hpHigh, hpDrop⟩ := hdata p hp
    have hpz : ‖(p.2 : ℂ)‖ ≤ 5 := by
      simpa only [Complex.norm_real, Real.norm_eq_abs] using hpWindow.le
    exact hseed p.1 lam (p.2 : ℂ) q₀ hpirr hlam hpz
      ((le_max_left _ _).trans hq₀) hpRecord hpHigh.le hpDrop.le
  exact ⟨κ, hκ, U, hU, hUE, amoLyapunov_lowerBound_of_irrational_on_open lam hU hlower⟩

end CriticalDTM

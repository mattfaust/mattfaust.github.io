import DTM.Background.Records.AMORecordTransitionArithmetic
import DTM.Background.Records.AMORecordTransitionScalar

/-!
# One record-denominator finite-scale transition

The input deviation bounds concern actual operator and Frobenius bad sets.
The finite scale selection and every use of the avalanche principle are
proved from those bounds and one high initial finite pair.
-/

noncomputable section
set_option maxHeartbeats 1000000
open MeasureTheory Set
namespace CriticalDTM

/-- Actual uniform finite bad masses at a fixed approximation denominator. -/
def AMORecordBadMasses (α lam : ℝ) (z : ℂ) (κ C c : ℝ) (q : ℕ) : Prop :=
  ∀ M : ℕ, C * (q : ℝ) ≤ (M : ℝ) →
    (volume.restrict (Ioc (0 : ℝ) 1)).real (amoAvalancheBaseBadSet α lam z M κ) ≤
      Real.exp (-c * (q : ℝ)) ∧
    AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z M (amoFiniteLyapunov α lam z M) κ) ≤
        Real.exp (-c * (q : ℝ))

/-- The polynomial window already lies in the old denominator's LDT and AP
ranges. These are scalar consequences, not additional scale assumptions. -/
theorem amoRecord_initial_scale_data {κ C c : ℝ} (hκ : 0 < κ)
    {q N : ℕ} (hs : AMORecordTransitionScalar κ C c q) (hNlo : q ^ 6 ≤ N) :
    0 < N ∧ C * (q : ℝ) ≤ (N : ℝ) ∧
      Real.log 10000 ≤ 200 * κ * (N : ℝ) ∧ Real.log 2 / (2 * (N : ℝ)) ≤ κ := by
  have hq : 0 < q := hs.positive
  have hN : 0 < N := (pow_pos hq 6).trans_le hNlo
  have hq0 : (0 : ℝ) ≤ q := Nat.cast_nonneg q
  have hlo : (q : ℝ) ^ 6 ≤ N := by exact_mod_cast hNlo
  have hNC : C * (q : ℝ) ≤ N := by
    have hpoly := hs.polynomial
    nlinarith
  refine ⟨hN, hNC, ?_, ?_⟩
  · exact hs.scale.trans (mul_le_mul_of_nonneg_left hlo (by positivity))
  · exact (div_le_div_of_nonneg_left (Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 2))
      (by positivity : (0 : ℝ) < 2 * (q : ℝ) ^ 6)
      (by linarith : 2 * (q : ℝ) ^ 6 ≤ 2 * (N : ℝ))).trans hs.gap

/-- Ordinary records are reached by actual dyadic propagation and upward
rounding. The only dynamical input is the old denominator's bad masses. -/
theorem amoRecordTransition_ordinary
    (α lam : ℝ) (z : ℂ) (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5)
    {κ C c : ℝ} (hκ : 0 < κ) (hc : 0 < c)
    (hCκ : c / (100 * κ) ≤ C)
    {q p N : ℕ} (hs : AMORecordTransitionScalar κ C c q) (hqp : q < p)
    (hNlo : q ^ 6 ≤ N) (hNhi : N ≤ 3 * q ^ 6)
    (hL : 2000 * κ ≤ amoFiniteLyapunov α lam z N)
    (hd : amoRecordGap α lam z N ≤ κ / 100)
    (hbad : AMORecordBadMasses α lam z κ C c q)
    (hshort : (p : ℝ) ≤ Real.exp (4 * (c / 1000) * (q : ℝ))) :
    ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      amoFiniteLyapunov α lam z N - 6 * amoRecordGap α lam z N -
          Real.exp (-(c / 2000) * (q : ℝ)) - 2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 ≤
        amoFiniteLyapunov α lam z R ∧
      (R : ℝ) * amoRecordGap α lam z R ≤ (N : ℝ) * amoRecordGap α lam z N +
        (3 + 9 * Real.log (amoTransferBound lam z)) * (p : ℝ) := by
  obtain ⟨hN, hNC, hscale, _⟩ := amoRecord_initial_scale_data hκ hs hNlo
  have hq : 0 < q := hs.positive
  have hp : 0 < p := hq.trans hqp
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hpr : (1 : ℝ) ≤ p := by exact_mod_cast hp
  let ε : ℝ := amoRecordErrorConstant * Real.exp (-c * (q : ℝ))
  let τ : ℝ := Real.exp (-(c / 2000) * (q : ℝ))
  have hε : 0 ≤ ε := by dsimp only [ε]; exact mul_nonneg amoRecordErrorConstant_pos.le (Real.exp_pos _).le
  have hτ0 : 0 ≤ τ := (Real.exp_pos _).le
  have hτ1 : τ ≤ 1 := by
    apply Real.exp_le_one_iff.mpr
    have hqr : (0 : ℝ) ≤ q := Nat.cast_nonneg q
    nlinarith [hc]
  have hpower : (p : ℝ) ^ 6 ≤ Real.exp (24 * (c / 1000) * (q : ℝ)) := by
    calc
      _ ≤ (Real.exp (4 * (c / 1000) * (q : ℝ))) ^ 6 := by gcongr
      _ = _ := by rw [← Real.exp_nat_mul]; congr 1; ring
  have hsmall : 6 * (p : ℝ) ^ 6 * ε ≤ min (κ / 100) (τ / 100) := by
    exact (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpower (by norm_num : (0 : ℝ) ≤ 6)) hε).trans hs.ordinary_small
  have hsmallκ : 6 * (p : ℝ) ^ 6 * ε ≤ κ / 100 := hsmall.trans (min_le_left _ _)
  have hsmallτ : 6 * (p : ℝ) ^ 6 * ε ≤ τ / 100 := hsmall.trans (min_le_right _ _)
  have hmax : ((max N (2 * p ^ 6) : ℕ) : ℝ) ≤ 3 * (p : ℝ) ^ 6 := by
    have hqpow : q ^ 6 ≤ p ^ 6 := Nat.pow_le_pow_left hqp.le 6
    have hnat : max N (2 * p ^ 6) ≤ 3 * p ^ 6 := max_le (by omega) (by omega)
    exact_mod_cast hnat
  have hH : ((max N (2 * p ^ 6) : ℕ) : ℝ) ≤ 3 * (p : ℝ) ^ 6 * (N : ℝ) := by
    have ht := mul_le_mul_of_nonneg_left hNr (show 0 ≤ 3 * (p : ℝ) ^ 6 by positivity)
    nlinarith
  obtain ⟨P, hPT, hNP, hPmax, hLP, hwP, hdP⟩ := amoFiniteLyapunov_dyadic_to_target
    α lam z N (p ^ 6) hN hκ (Real.exp_pos _).le hscale (by linarith)
    (by unfold amoRecordGap at hd ⊢; linarith)
    (fun M hNM => (hbad M (hNC.trans (by exact_mod_cast hNM))).1)
    (amoRecord_dyadic_error_le hlam hz hκ hCκ hq hN hNC) hH
    (by nlinarith : (3 * (p : ℝ) ^ 6) * ε ≤ κ)
  change amoFiniteLyapunov α lam z N - 2 * amoRecordGap α lam z N -
    2 * (3 * (p : ℝ) ^ 6) * ε ≤ amoFiniteLyapunov α lam z P at hLP
  change (P : ℝ) * amoRecordGap α lam z P ≤
    (N : ℝ) * amoRecordGap α lam z N + 2 * (P : ℝ) * ε at hwP
  obtain ⟨R, hRd, hPR, hRT, hRmax, hLR, hwR⟩ :=
    amoFiniteLyapunov_record_rounding α lam z hq hqp hNhi hPT hPmax
  have hPmaxR : (P : ℝ) ≤ ((max N (2 * p ^ 6) : ℕ) : ℝ) := by exact_mod_cast hPmax
  have hPbound : (P : ℝ) ≤ 3 * (p : ℝ) ^ 6 := hPmaxR.trans hmax
  have hwe : 2 * (P : ℝ) * ε ≤ τ / 100 := by
    have ht := mul_le_mul_of_nonneg_right hPbound hε
    nlinarith
  have hd0 := amoRecordGap_nonneg α lam z N
  refine ⟨R, hRd, hNP.trans hPR, hRT, hRmax, ?_, ?_⟩
  · change amoFiniteLyapunov α lam z N - 6 * amoRecordGap α lam z N - τ -
      2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 ≤ amoFiniteLyapunov α lam z R
    linarith only [hLR, hLP, hsmallτ, hτ0, hd0]
  · nlinarith only [hwR, hwP, hwe, hτ1, hpr]

end CriticalDTM

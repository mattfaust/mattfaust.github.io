import DTM.Background.Records.AMORecordTransitionSteps
import DTM.Background.Records.AMOTransferLengthBounds

/-!
# Integer length selection and rounding at record denominators

Only elementary integer and real arithmetic is used here. In particular the
near-periodic block count is constructed by the natural floor, rather than
assumed to satisfy a drift condition.
-/

noncomputable section
namespace CriticalDTM

/-- Strictly increasing denominators leave room for one upward rounding in
the polynomial scale window. -/
theorem record_pow_six_rounding_room {q p : ℕ} (hq : 0 < q) (hqp : q < p) :
    q ^ 6 + p ≤ p ^ 6 ∧ p ≤ p ^ 6 := by
  have hp1 : 1 ≤ p := by omega
  have hp5 : p ≤ p ^ 5 := by
    simpa only [pow_one] using pow_le_pow_right₀ hp1 (by norm_num : 1 ≤ (5 : ℕ))
  have hqp5 : q ^ 5 ≤ p ^ 5 := Nat.pow_le_pow_left hqp.le 5
  have hs : q ^ 6 + p ≤ p ^ 6 := by
    calc
      q ^ 6 + p = q ^ 5 * q + p := by rw [pow_succ]
      _ ≤ p ^ 5 * q + p ^ 5 := Nat.add_le_add (Nat.mul_le_mul_right q hqp5) hp5
      _ = p ^ 5 * (q + 1) := by ring
      _ ≤ p ^ 5 * p := Nat.mul_le_mul_left _ hqp
      _ = p ^ 6 := by ring
  exact ⟨hs, (Nat.le_add_left p (q ^ 6)).trans hs⟩

/-- An actual next multiple with the stipulated sixth-power window. -/
theorem exists_record_rounding {q p N P : ℕ} (hq : 0 < q) (hqp : q < p)
    (hN : N ≤ 3 * q ^ 6) (hPlo : p ^ 6 ≤ P) (hPhi : P ≤ max N (2 * p ^ 6)) :
    ∃ R : ℕ, p ∣ R ∧ P ≤ R ∧ R ≤ P + p ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 := by
  have hp : 0 < p := hq.trans hqp
  let R := p * (P / p + 1)
  have hRlo : P ≤ R := by
    have hmod := Nat.mod_lt P hp
    have hdiv := Nat.mod_add_div P p
    dsimp only [R]
    nlinarith
  have hRhi : R ≤ P + p := by
    have hdiv : p * (P / p) ≤ P := Nat.mul_div_le P p
    dsimp only [R]
    nlinarith
  have hroom := record_pow_six_rounding_room hq hqp
  have hmax : max N (2 * p ^ 6) + p ≤ 3 * p ^ 6 := by
    rcases le_total N (2 * p ^ 6) with h | h
    · rw [max_eq_right h]
      omega
    · rw [max_eq_left h]
      omega
  refine ⟨R, dvd_mul_right _ _, hRlo, hRhi, hPlo.trans hRlo, ?_⟩
  exact hRhi.trans ((Nat.add_le_add_right hPhi p).trans hmax)

/-- The floor construction simultaneously gives both drift estimates and the
lower length bound needed to bridge to the new denominator. -/
theorem exists_record_nearPeriodic_blocks
    (α : ℝ) (a : ℤ) (q p N : ℕ) (hq : 0 < q) (hp : 0 < p) (hN : 0 < N)
    {η : ℝ} (hη : 0 ≤ η)
    (happrox : |α - (a : ℝ) / (q : ℝ)| ≤ 1 / ((q : ℝ) * (p : ℝ)))
    (hroom : 8 * (N : ℝ) ≤ η * (q : ℝ) * (p : ℝ)) :
    ∃ m : ℕ, 2 ≤ m ∧
      η * (q : ℝ) * (p : ℝ) / 4 ≤ ((m * N : ℕ) : ℝ) ∧
      ((m * N : ℕ) : ℝ) ≤ η * (q : ℝ) * (p : ℝ) / 2 ∧
      ((((2 * m) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η := by
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hqr : (0 : ℝ) < q := by exact_mod_cast hq
  have hpr : (0 : ℝ) < p := by exact_mod_cast hp
  let x : ℝ := η * (q : ℝ) * (p : ℝ) / (2 * (N : ℝ))
  let m : ℕ := ⌊x⌋₊
  have hx : 0 ≤ x := by dsimp only [x]; positivity
  have hfloor : (m : ℝ) ≤ x := Nat.floor_le hx
  have hfloor' : x < (m : ℝ) + 1 := Nat.lt_floor_add_one x
  have hx4 : 4 ≤ x := by dsimp only [x]; apply (le_div_iff₀ (by positivity)).mpr; linarith
  have hm : 2 ≤ m := by
    have hmr : (2 : ℝ) ≤ m := by linarith
    exact_mod_cast hmr
  have hlo : η * (q : ℝ) * (p : ℝ) / 4 ≤ ((m * N : ℕ) : ℝ) := by
    have hxmul : x * (2 * (N : ℝ)) = η * (q : ℝ) * (p : ℝ) := by
      dsimp only [x]
      field_simp
    have hf := mul_lt_mul_of_pos_right hfloor' (show 0 < 2 * (N : ℝ) by positivity)
    push_cast
    nlinarith
  have hhi : ((m * N : ℕ) : ℝ) ≤ η * (q : ℝ) * (p : ℝ) / 2 := by
    have hf := (le_div_iff₀ (show 0 < 2 * (N : ℝ) by positivity)).mp hfloor
    push_cast
    linarith
  refine ⟨m, hm, hlo, hhi, ?_⟩
  have hh : ((((2 * m) * N : ℕ) : ℝ)) ≤ η * (q : ℝ) * (p : ℝ) := by
    push_cast at hhi ⊢
    linarith
  have he : ((((2 * m) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤
      ((((2 * m) * N : ℕ) : ℝ)) * (1 / ((q : ℝ) * (p : ℝ))) :=
    mul_le_mul_of_nonneg_left happrox (Nat.cast_nonneg _)
  apply he.trans
  rw [mul_one_div]
  exact (div_le_iff₀ (mul_pos hqr hpr)).mpr (by nlinarith)

/-- Rounding contributes exactly a fifth-power height tail and a linear
weighted-gap cost, independent of the number of preceding dyadic steps. -/
theorem amoFiniteLyapunov_record_rounding
    (α lam : ℝ) (z : ℂ) {q p N P : ℕ} (hq : 0 < q) (hqp : q < p)
    (hN : N ≤ 3 * q ^ 6) (hPlo : p ^ 6 ≤ P) (hPhi : P ≤ max N (2 * p ^ 6)) :
    ∃ R : ℕ, p ∣ R ∧ P ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      amoFiniteLyapunov α lam z P - 2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 ≤
        amoFiniteLyapunov α lam z R ∧
      (R : ℝ) * amoRecordGap α lam z R ≤ (P : ℝ) * amoRecordGap α lam z P +
        9 * Real.log (amoTransferBound lam z) * (p : ℝ) := by
  obtain ⟨R, hRd, hPR, hRp, hRlo, hRhi⟩ := exists_record_rounding hq hqp hN hPlo hPhi
  have hp : 0 < p := hq.trans hqp
  have hpr : (0 : ℝ) < p := by exact_mod_cast hp
  have hP : 0 < P := (pow_pos hp 6).trans_le hPlo
  have hPpr : (p : ℝ) ^ 6 ≤ (P : ℝ) := by exact_mod_cast hPlo
  have hB : 0 ≤ Real.log (amoTransferBound lam z) :=
    Real.log_nonneg (amoTransferBound_one_le lam z)
  have herr : 2 * Real.log (amoTransferBound lam z) * (p : ℝ) / (P : ℝ) ≤
      2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 := by
    calc
      _ ≤ 2 * Real.log (amoTransferBound lam z) * (p : ℝ) / (p : ℝ) ^ 6 :=
        div_le_div_of_nonneg_left (by positivity) (pow_pos hpr 6) hPpr
      _ = _ := by field_simp; ring
  refine ⟨R, hRd, hPR, hRlo, hRhi, ?_, ?_⟩
  · have h := amoFiniteLyapunov_rounding_lower α lam z hP hPR hRp
    linarith
  · exact amoFiniteLyapunov_weightedDyadicGap_rounding_le α lam z hP hPR hRp
      ((record_pow_six_rounding_room hq hqp).2.trans hPlo)

end CriticalDTM

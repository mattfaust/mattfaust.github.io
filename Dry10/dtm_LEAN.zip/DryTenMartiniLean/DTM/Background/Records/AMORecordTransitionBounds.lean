import DTM.Background.Records.AMORecordTransitionSteps

/-!
# Uniform actual avalanche errors in the fixed AMO window

The dyadic and near-periodic errors are bounded by scalar functions of the
record denominator. No later finite or infinite Lyapunov lower bound occurs
in the conclusions' hypotheses.
-/

noncomputable section
namespace CriticalDTM

/-- A common harmless constant for both finite avalanche errors. -/
def amoRecordErrorConstant : ℝ := 10000 * (1 + Real.log 9)

theorem amoRecordErrorConstant_pos : 0 < amoRecordErrorConstant := by
  unfold amoRecordErrorConstant
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num)
  positivity

/-- The fixed coupling and energy window gives the stated `log 9` bound. -/
theorem amoRecord_log_bound {lam : ℝ} {z : ℂ} (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5) :
    Real.log (amoTransferBound lam z) ≤ Real.log 9 := by
  apply Real.log_le_log (amoTransferBound_pos lam z)
  unfold amoTransferBound
  linarith

/-- A uniform denominator-only bound for the actual dyadic AP error. -/
theorem amoRecord_dyadic_error_le {lam : ℝ} {z : ℂ}
    (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5)
    {κ C c : ℝ} (hκ : 0 < κ)
    (hCκ : c / (100 * κ) ≤ C)
    {q N : ℕ} (hq : 0 < q) (hN : 0 < N) (hNC : C * (q : ℝ) ≤ N) :
    amoDyadicPropagationError lam z N κ (Real.exp (-c * (q : ℝ))) ≤
      amoRecordErrorConstant * Real.exp (-c * (q : ℝ)) := by
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hqr : (0 : ℝ) < q := by exact_mod_cast hq
  have hcC : c ≤ C * (100 * κ) := (div_le_iff₀ (by positivity)).mp hCκ
  have he : c * (q : ℝ) ≤ 200 * κ * (N : ℝ) := by
    have h1 := mul_le_mul_of_nonneg_right hcC hqr.le
    have h2 := mul_le_mul_of_nonneg_left hNC (show 0 ≤ 100 * κ by positivity)
    nlinarith [mul_nonneg hκ.le (Nat.cast_nonneg N : (0 : ℝ) ≤ N)]
  have hden : Real.exp (c * (q : ℝ)) ≤ (N : ℝ) * Real.exp (200 * κ * (N : ℝ)) := by
    exact (Real.exp_le_exp.mpr he).trans
      (by nlinarith [Real.exp_pos (200 * κ * (N : ℝ))])
  have hap : 4000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) ≤
      4000 * Real.exp (-c * (q : ℝ)) := by
    calc
      _ ≤ 4000 / Real.exp (c * (q : ℝ)) :=
        div_le_div_of_nonneg_left (by norm_num) (Real.exp_pos _) hden
      _ = _ := by rw [div_eq_mul_inv, ← Real.exp_neg]; congr 2; ring
  have hB := amoRecord_log_bound hlam hz
  have hδ := Real.exp_pos (-c * (q : ℝ))
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num)
  have hbδ := mul_le_mul_of_nonneg_right hB hδ.le
  unfold amoDyadicPropagationError amoRecordErrorConstant
  nlinarith [mul_nonneg hlog hδ.le]

/-- The initial high finite pair controls the true near-periodic AP error by
a polynomial times the drift radius, plus the denominator's LDT error. -/
theorem amoRecord_near_error_le
    (α : ℝ) {lam : ℝ} {z : ℂ} (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5)
    {κ C c η : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hCκ : c / (100 * κ) ≤ C)
    {q N : ℕ} (hq : 0 < q) (hN : 0 < N) (hNC : C * (q : ℝ) ≤ N)
    (hNhi : N ≤ 3 * q ^ 6)
    (hL : 800 * κ ≤ amoFiniteLyapunov α lam z N) :
    1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
      4 * Real.log (amoTransferBound lam z) * Real.exp (-c * (q : ℝ)) +
      192 * Real.log (amoTransferBound lam z) * (N : ℝ) * η ≤
        amoRecordErrorConstant * ((q : ℝ) ^ 6 * η + Real.exp (-c * (q : ℝ))) := by
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hexp : 200 * κ * (N : ℝ) ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2 := by
    have h := mul_le_mul_of_nonneg_left hL hNr.le
    nlinarith
  have hden : (N : ℝ) * Real.exp (200 * κ * (N : ℝ)) ≤
      (N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2) :=
    mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hexp) hNr.le
  have hap : 1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) ≤
      4000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) := by
    calc
      _ ≤ 1000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) :=
        div_le_div_of_nonneg_left (by norm_num) (by positivity) hden
      _ ≤ _ := div_le_div_of_nonneg_right (by norm_num) (by positivity)
  have hd := amoRecord_dyadic_error_le hlam hz hκ hCκ hq hN hNC
  have hB0 : 0 ≤ Real.log (amoTransferBound lam z) :=
    Real.log_nonneg (amoTransferBound_one_le lam z)
  have hB := amoRecord_log_bound hlam hz
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num)
  have hNhiR : (N : ℝ) ≤ 3 * (q : ℝ) ^ 6 := by exact_mod_cast hNhi
  have hNη := mul_le_mul_of_nonneg_right hNhiR hη
  have hBη := mul_le_mul_of_nonneg_right hB (mul_nonneg hNr.le hη)
  have hNηB := mul_le_mul_of_nonneg_left hNη hlog
  have hδB := mul_nonneg hB0 (Real.exp_pos (-c * (q : ℝ))).le
  have hqη := mul_nonneg (pow_nonneg (Nat.cast_nonneg q : (0 : ℝ) ≤ q) 6) hη
  unfold amoDyadicPropagationError amoRecordErrorConstant at hd
  unfold amoRecordErrorConstant
  nlinarith [mul_nonneg hlog hqη]

end CriticalDTM

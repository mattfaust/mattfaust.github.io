import DTM.Background.Records.AMORecordTransition

/-!
# The long record-denominator scale transition

A floor-selected near-periodic block count bridges the exceptionally large
jump. Old-denominator dyadic propagation reaches the new LDT threshold;
new-denominator propagation reaches the polynomial scale. All intermediate
AP conditions are deduced from the proved height and drop estimates.
-/

noncomputable section
set_option maxHeartbeats 2000000
open MeasureTheory Set
namespace CriticalDTM

/-- Long records use the true near-periodic step, two finite dyadic chains,
and actual length rounding. No transition or future positivity is assumed. -/
theorem amoRecordTransition_long
    (α lam : ℝ) (z : ℂ) (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5)
    {κ C c : ℝ} (hκ : 0 < κ) (hC : 1 ≤ C) (hc : 0 < c)
    (hCκ : c / (100 * κ) ≤ C)
    {q p N : ℕ} (hs : AMORecordTransitionScalar κ C c q)
    (hpScalar : AMORecordTransitionScalar κ C c p) (hqp : q < p)
    (hNlo : q ^ 6 ≤ N) (hNhi : N ≤ 3 * q ^ 6) (hqN : q ∣ N)
    (a : ℤ) (happrox : |α - (a : ℝ) / (q : ℝ)| ≤ 1 / ((q : ℝ) * (p : ℝ)))
    (hL : 2000 * κ ≤ amoFiniteLyapunov α lam z N)
    (hd : amoRecordGap α lam z N ≤ κ / 100)
    (hbadq : AMORecordBadMasses α lam z κ C c q)
    (hbadp : AMORecordBadMasses α lam z κ C c p)
    (hlong : Real.exp (4 * (c / 1000) * (q : ℝ)) < (p : ℝ)) :
    ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      amoFiniteLyapunov α lam z N - 6 * amoRecordGap α lam z N -
          Real.exp (-(c / 2000) * (q : ℝ)) - 2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 ≤
        amoFiniteLyapunov α lam z R ∧
      (R : ℝ) * amoRecordGap α lam z R ≤ (N : ℝ) * amoRecordGap α lam z N +
        (3 + 9 * Real.log (amoTransferBound lam z)) * (p : ℝ) := by
  obtain ⟨hN, hNC, hscale, hgap⟩ := amoRecord_initial_scale_data hκ hs hNlo
  have hC0 : 0 < C := lt_of_lt_of_le (by norm_num) hC
  have hq : 0 < q := hs.positive
  have hp : 0 < p := hpScalar.positive
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hqr : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hpr : (1 : ℝ) ≤ p := by exact_mod_cast hp
  have hqpR : (q : ℝ) ≤ p := by exact_mod_cast hqp.le
  have hNhiR : (N : ℝ) ≤ 3 * (q : ℝ) ^ 6 := by exact_mod_cast hNhi
  let η : ℝ := Real.exp (-(c / 1000) * (q : ℝ))
  let ε : ℝ := amoRecordErrorConstant * Real.exp (-c * (q : ℝ))
  let εp : ℝ := amoRecordErrorConstant * Real.exp (-c * (p : ℝ))
  let E : ℝ := amoRecordErrorConstant * ((q : ℝ) ^ 6 * η + Real.exp (-c * (q : ℝ)))
  let τ : ℝ := Real.exp (-(c / 2000) * (q : ℝ))
  let H : ℝ := 8 * (C + 1) * Real.exp ((c / 1000) * (q : ℝ))
  have hη : 0 < η := Real.exp_pos _
  have hε : 0 ≤ ε := mul_nonneg amoRecordErrorConstant_pos.le (Real.exp_pos _).le
  have hεp : 0 ≤ εp := mul_nonneg amoRecordErrorConstant_pos.le (Real.exp_pos _).le
  have hE : 0 ≤ E := mul_nonneg amoRecordErrorConstant_pos.le (by positivity)
  have hτ : 0 < τ := Real.exp_pos _
  have hτ1 : τ ≤ 1 := by
    apply Real.exp_le_one_iff.mpr
    have hqr0 : (0 : ℝ) ≤ q := Nat.cast_nonneg q
    nlinarith only [hc, hqr0]
  have hτp : Real.exp (-(c / 2000) * (p : ℝ)) ≤ τ := by
    apply Real.exp_le_exp.mpr
    have ht := mul_le_mul_of_nonneg_left hqpR (show 0 ≤ c / 2000 by positivity)
    linarith only [ht]
  have hEκ : E ≤ κ / 100 := hs.near_small.trans (min_le_left _ _)
  have hEτ : E ≤ τ / 100 := hs.near_small.trans (min_le_right _ _)
  have hHEκ : H * ε ≤ κ / 100 := hs.bridge_small.trans (min_le_left _ _)
  have hHEτ : H * ε ≤ τ / 100 := hs.bridge_small.trans (min_le_right _ _)
  have hH8 : 8 * (C + 1) ≤ H := by
    have hexp : 1 ≤ Real.exp ((c / 1000) * (q : ℝ)) :=
      Real.one_le_exp_iff.mpr (by positivity)
    dsimp only [H]
    nlinarith only [hexp, hC]
  have hH1 : 1 ≤ H := by linarith only [hH8, hC]
  have hεH : ε ≤ H * ε := by nlinarith only [hH1, hε]
  have hεκ : ε ≤ κ / 100 := hεH.trans hHEκ
  have hετ : ε ≤ τ / 100 := hεH.trans hHEτ
  have hHη : H * η = 8 * (C + 1) := by
    dsimp only [H, η]
    rw [mul_assoc, ← Real.exp_add]
    have he : c / 1000 * (q : ℝ) + -(c / 1000) * (q : ℝ) = 0 := by ring
    rw [he, Real.exp_zero, mul_one]
  have hroom : 8 * (N : ℝ) ≤ η * (q : ℝ) * (p : ℝ) := by
    have hh := mul_le_mul_of_nonneg_left hlong.le (show 0 ≤ η * (q : ℝ) by positivity)
    have hr := hs.long_room
    change 24 * (q : ℝ) ^ 6 ≤ η * (q : ℝ) * Real.exp (4 * (c / 1000) * (q : ℝ)) at hr
    nlinarith only [hNhiR, hr, hh]
  obtain ⟨m, hm, hMlo, hMhi, hnear⟩ :=
    exists_record_nearPeriodic_blocks α a q p N hq hp hN hη.le happrox hroom
  let M := m * N
  change η * (q : ℝ) * (p : ℝ) / 4 ≤ (M : ℝ) at hMlo
  change (M : ℝ) ≤ η * (q : ℝ) * (p : ℝ) / 2 at hMhi
  have hNM : N ≤ M := by dsimp only [M]; nlinarith only [hm]
  have hM : 0 < M := hN.trans_le hNM
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  have hMNr : (N : ℝ) ≤ M := by exact_mod_cast hNM
  have hMp : (M : ℝ) ≤ (p : ℝ) / 2 := by
    have hrad := hs.radius_small
    change (q : ℝ) * η ≤ 1 at hrad
    have ht := mul_le_mul_of_nonneg_right hrad (show (0 : ℝ) ≤ p by positivity)
    nlinarith only [ht, hMhi]
  have hpairN : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤ amoFiniteLyapunov α lam z (2 * N) := by
    unfold amoRecordGap at hd
    linarith only [hd, hL, hκ]
  have hLscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2 := by
    have hl := mul_le_mul_of_nonneg_left hL hNr.le
    nlinarith only [hl, hscale, hκ, hNr]
  have hNC2 : C * (q : ℝ) ≤ ((2 * N : ℕ) : ℝ) := by push_cast; linarith only [hNC, hNr]
  obtain ⟨hLM, hdM, hwM⟩ := amoFiniteLyapunov_nearPeriodic_pair α lam z N m hN hm a q hq hqN
    hκ hη.le hnear hgap (by linarith only [hL, hκ]) hpairN hLscale
    (hbadq N hNC).2 (hbadq (2 * N) hNC2).2
    (amoRecord_near_error_le α hlam hz hκ hη.le hCκ hq hN hNC hNhi (by linarith only [hL, hκ]))
  change amoFiniteLyapunov α lam z N - 2 * amoRecordGap α lam z N - E ≤
    amoFiniteLyapunov α lam z M at hLM
  change amoRecordGap α lam z M ≤ amoRecordGap α lam z N / (m : ℝ) + 2 * E at hdM
  change (M : ℝ) * amoRecordGap α lam z M ≤ (N : ℝ) * amoRecordGap α lam z N + 2 * (M : ℝ) * E at hwM
  have hd0 := amoRecordGap_nonneg α lam z N
  have hmr : (1 : ℝ) ≤ m := by exact_mod_cast (show 1 ≤ m by omega)
  have hddiv : amoRecordGap α lam z N / (m : ℝ) ≤ amoRecordGap α lam z N := by
    apply (div_le_iff₀ (by linarith only [hmr] : (0 : ℝ) < m)).mpr
    nlinarith only [hd0, hmr]
  have hdMrough : amoRecordGap α lam z M ≤ amoRecordGap α lam z N + 2 * E := by linarith only [hdM, hddiv]
  have hLMlarge : 1900 * κ ≤ amoFiniteLyapunov α lam z M := by linarith only [hLM, hL, hd, hEκ, hκ]
  have hpairM : amoRecordGap α lam z M ≤ amoFiniteLyapunov α lam z M / 20 := by linarith only [hLMlarge, hdMrough, hd, hEκ, hκ]
  have hMC : C * (q : ℝ) ≤ M := hNC.trans hMNr
  have hscaleM : Real.log 10000 ≤ 200 * κ * (M : ℝ) :=
    hscale.trans (mul_le_mul_of_nonneg_left hMNr (by positivity))
  let T : ℕ := ⌈C * (p : ℝ)⌉₊
  have hTlo : C * (p : ℝ) ≤ T := Nat.le_ceil _
  have hThi : (T : ℝ) ≤ (C + 1) * (p : ℝ) := by
    have ht := Nat.ceil_lt_add_one (show 0 ≤ C * (p : ℝ) by positivity)
    change (T : ℝ) < C * (p : ℝ) + 1 at ht
    nlinarith only [ht, hpr]
  have hMT : M ≤ T := by
    have ht : (M : ℝ) ≤ T := by nlinarith only [hMp, hTlo, hC, hpr]
    exact_mod_cast ht
  have hmaxMT : max M (2 * T) = 2 * T := max_eq_right (by omega)
  have hHbridge : ((max M (2 * T) : ℕ) : ℝ) ≤ H * (M : ℝ) := by
    rw [hmaxMT]
    push_cast
    have h1 := mul_le_mul_of_nonneg_left hMlo (show 0 ≤ H by linarith only [hH1])
    have h2 : H * (η * (q : ℝ) * (p : ℝ) / 4) = 2 * (C + 1) * (q : ℝ) * (p : ℝ) := by
      calc
        _ = (H * η) * (q : ℝ) * (p : ℝ) / 4 := by ring
        _ = _ := by rw [hHη]; ring
    rw [h2] at h1
    have h3 := mul_le_mul_of_nonneg_left hqr
      (show 0 ≤ 2 * (C + 1) * (p : ℝ) by positivity)
    nlinarith only [h1, h3, hThi]
  obtain ⟨P, hTP, hMP, hPmax, hLP, hwP, hdP⟩ := amoFiniteLyapunov_dyadic_to_target
    α lam z M T hM hκ (Real.exp_pos _).le hscaleM (by linarith only [hLMlarge, hκ]) hpairM
    (fun J hMJ => (hbadq J (hMC.trans (by exact_mod_cast hMJ))).1)
    (amoRecord_dyadic_error_le hlam hz hκ hCκ hq hM hMC) hHbridge
    (by linarith only [hHEκ, hκ] : H * ε ≤ κ)
  change amoFiniteLyapunov α lam z M - 2 * amoRecordGap α lam z M - 2 * H * ε ≤
    amoFiniteLyapunov α lam z P at hLP
  change (P : ℝ) * amoRecordGap α lam z P ≤ (M : ℝ) * amoRecordGap α lam z M +
    2 * (P : ℝ) * ε at hwP
  change amoRecordGap α lam z P ≤ amoRecordGap α lam z M + 2 * ε at hdP
  have hP : 0 < P := hM.trans_le hMP
  have hPbound : (P : ℝ) ≤ 2 * (C + 1) * (p : ℝ) := by
    rw [hmaxMT] at hPmax
    have ht : (P : ℝ) ≤ 2 * (T : ℝ) := by exact_mod_cast hPmax
    linarith only [ht, hThi]
  have hPpowR : (P : ℝ) ≤ (p : ℝ) ^ 6 := hPbound.trans hpScalar.polynomial
  have hPpow : P ≤ p ^ 6 := by exact_mod_cast hPpowR
  have hPC : C * (p : ℝ) ≤ P := hTlo.trans (by exact_mod_cast hTP)
  have hLPlarge : 1800 * κ ≤ amoFiniteLyapunov α lam z P := by linarith only [hLMlarge, hLP, hdMrough, hd, hEκ, hHEκ, hκ]
  have hdPrough : amoRecordGap α lam z P ≤ amoRecordGap α lam z N + 2 * E + 2 * ε := by linarith only [hdP, hdMrough]
  have hpairP : amoRecordGap α lam z P ≤ amoFiniteLyapunov α lam z P / 20 := by linarith only [hLPlarge, hdPrough, hd, hEκ, hεκ, hκ]
  have hMPri : (M : ℝ) ≤ P := by exact_mod_cast hMP
  have hscaleP : Real.log 10000 ≤ 200 * κ * (P : ℝ) :=
    hscaleM.trans (mul_le_mul_of_nonneg_left hMPri (by positivity))
  have hpSmallκ : 6 * (p : ℝ) ^ 6 * εp ≤ κ / 100 := hpScalar.polynomial_small.trans (min_le_left _ _)
  have hpSmallτ : 6 * (p : ℝ) ^ 6 * εp ≤ τ / 100 :=
    (hpScalar.polynomial_small.trans (min_le_right _ _)).trans (by linarith only [hτp])
  have hmaxP : max P (2 * p ^ 6) = 2 * p ^ 6 := max_eq_right (by omega)
  have hHnew : ((max P (2 * p ^ 6) : ℕ) : ℝ) ≤ (2 * (p : ℝ) ^ 6) * (P : ℝ) := by
    have hPr : (1 : ℝ) ≤ P := by exact_mod_cast hP
    rw [hmaxP]
    push_cast
    nlinarith only [hPr, pow_nonneg (show (0 : ℝ) ≤ p by positivity) 6]
  obtain ⟨S, hST, hPS, hSmax, hLS, hwS, _⟩ := amoFiniteLyapunov_dyadic_to_target
    α lam z P (p ^ 6) hP hκ (Real.exp_pos _).le hscaleP (by linarith only [hLPlarge, hκ]) hpairP
    (fun J hPJ => (hbadp J (hPC.trans (by exact_mod_cast hPJ))).1)
    (amoRecord_dyadic_error_le hlam hz hκ hCκ hp hP hPC) hHnew
    (by nlinarith only [hpSmallκ, hκ] : (2 * (p : ℝ) ^ 6) * εp ≤ κ)
  change amoFiniteLyapunov α lam z P - 2 * amoRecordGap α lam z P -
    2 * (2 * (p : ℝ) ^ 6) * εp ≤ amoFiniteLyapunov α lam z S at hLS
  change (S : ℝ) * amoRecordGap α lam z S ≤ (P : ℝ) * amoRecordGap α lam z P +
    2 * (S : ℝ) * εp at hwS
  have hSmax' : S ≤ max N (2 * p ^ 6) := by
    rw [hmaxP] at hSmax
    exact hSmax.trans (le_max_right _ _)
  obtain ⟨R, hRd, hSR, hRT, hRmax, hLR, hwR⟩ :=
    amoFiniteLyapunov_record_rounding α lam z hq hqp hNhi hST hSmax'
  have hSM : (S : ℝ) ≤ 2 * (p : ℝ) ^ 6 := by
    rw [hmaxP] at hSmax
    exact_mod_cast hSmax
  have hwE : 2 * (M : ℝ) * E ≤ (p : ℝ) / 100 := by
    have he := mul_le_mul_of_nonneg_right hMhi hE
    have ht := mul_le_mul_of_nonneg_right hs.near_weight (show (0 : ℝ) ≤ p by positivity)
    change (η * (q : ℝ) * E) * (p : ℝ) ≤ (1 / 100 : ℝ) * (p : ℝ) at ht
    nlinarith only [he, ht]
  have hwε : 2 * (P : ℝ) * ε ≤ (p : ℝ) / 100 := by
    have h1 := mul_le_mul_of_nonneg_right hPbound hε
    have h2 := mul_le_mul_of_nonneg_right hH8 hε
    have h2p := mul_le_mul_of_nonneg_right h2 (show (0 : ℝ) ≤ p by positivity)
    have h3 := mul_le_mul_of_nonneg_right hHEτ (show (0 : ℝ) ≤ p by positivity)
    have h4 := mul_le_mul_of_nonneg_right hτ1 (show (0 : ℝ) ≤ p by positivity)
    nlinarith only [h1, h2p, h3, h4, hτ, hpr]
  have hwεp : 2 * (S : ℝ) * εp ≤ 1 := by
    have he := mul_le_mul_of_nonneg_right hSM hεp
    nlinarith only [he, hpSmallτ, hτ1]
  refine ⟨R, hRd, hNM.trans (hMP.trans (hPS.trans hSR)), hRT, hRmax, ?_, ?_⟩
  · change amoFiniteLyapunov α lam z N - 6 * amoRecordGap α lam z N - τ -
      2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 ≤ amoFiniteLyapunov α lam z R
    linarith only [hLM, hLP, hLS, hLR, hdMrough, hdPrough,
      hEτ, hHEτ, hετ, hpSmallτ, hτ]
  · nlinarith only [hwM, hwP, hwS, hwR, hwE, hwε, hwεp, hpr]

end CriticalDTM

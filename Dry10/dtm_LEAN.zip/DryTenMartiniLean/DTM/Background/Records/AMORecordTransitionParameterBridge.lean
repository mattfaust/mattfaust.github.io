import DTM.Background.Records.AMORecordParameters
import DTM.Background.Records.AMORecordTransitionScalar

/-!
# Discharging the scalar thresholds of the record transition

The generic scalar decay theorem is instantiated at the actual constant used
by the checked transition bounds. No transfer, spectral or persistence premise
is needed to obtain a sufficiently large denominator threshold.
-/

noncomputable section
namespace CriticalDTM

/-- The independently proved scalar estimates supply every transition field. -/
theorem amoRecordParameterBounds_to_transitionScalar
    {κ C c : ℝ} {q : ℕ}
    (h : AMORecordParameterBounds κ C c amoRecordErrorConstant q) :
    AMORecordTransitionScalar κ C c q := by
  have hgamma : (c / 1000) / 2 = c / 2000 := by ring
  refine ⟨by have := h.q_ge_eight; omega,
    h.two_linear_le_pow_six, h.log_10000_le, h.log_two_div_le, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simpa only [amoRecordEta, amoRecordGamma] using h.q_mul_eta_le_one
  · simpa only [amoRecordEta, amoRecordGamma] using h.growth
  · simpa only [amoRecordNearError, amoRecordEta, amoRecordDecay, amoRecordGamma, hgamma]
      using le_min h.near_le_kappa h.near_le_decay
  · simpa only [amoRecordNearError, amoRecordEta, amoRecordGamma] using h.eta_mul_near_le
  · simpa only [amoRecordEpsilon, amoRecordDecay, amoRecordGamma, hgamma] using h.bridge_error_le
  · simpa only [amoRecordEpsilon, amoRecordDecay, amoRecordGamma, hgamma] using h.dyadic_error_le
  · simpa only [amoRecordEpsilon, amoRecordDecay, amoRecordGamma, hgamma] using h.polynomial_error_le

theorem exists_amoRecordTransitionScalar {κ C c : ℝ}
    (hκ : 0 < κ) (hC : 0 < C) (hc : 0 < c) :
    ∃ Q : ℕ, ∀ q : ℕ, Q ≤ q → AMORecordTransitionScalar κ C c q := by
  obtain ⟨Q, hQ⟩ := exists_amoRecordParameterBounds hκ hC hc amoRecordErrorConstant_pos
  exact ⟨Q, fun q hq => amoRecordParameterBounds_to_transitionScalar (hQ q hq)⟩

end CriticalDTM

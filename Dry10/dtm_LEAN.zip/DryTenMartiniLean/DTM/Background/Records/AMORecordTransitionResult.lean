import DTM.Background.Records.AMORecordTransitionLong

/-!
# Common constants for the genuine record-denominator transition

The two scale-selection cases share one constant. The scalar
threshold is independent of all cocycles and is discharged in the final
parameter-specialized module.
-/

noncomputable section
namespace CriticalDTM

/-- One common constant controls the drop loss, rounding tail, and weighted
budget increment. It is uniform throughout the stipulated AMO window. -/
def amoRecordTransitionConstant : ℝ := 10 * (1 + Real.log 9)

theorem amoRecordTransitionConstant_pos : 0 < amoRecordTransitionConstant := by
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num)
  unfold amoRecordTransitionConstant
  positivity

/-- One actual record-denominator transition, with only elementary scalar
threshold inequalities left explicit. The two dynamical hypotheses are the
actual finite deviation masses at the old and new denominators. -/
theorem amoFiniteLyapunov_record_transition_of_scalar_bounds
    (α lam : ℝ) (z : ℂ) (hlam : |lam| ≤ 1) (hz : ‖z‖ ≤ 5)
    {κ C c : ℝ} (hκ : 0 < κ) (hC : 1 ≤ C) (hc : 0 < c)
    (hCκ : c / (100 * κ) ≤ C)
    {q p N : ℕ} (hs : AMORecordTransitionScalar κ C c q)
    (hpScalar : AMORecordTransitionScalar κ C c p) (hqp : q < p)
    (hNlo : q ^ 6 ≤ N) (hNhi : N ≤ 3 * q ^ 6) (hqN : q ∣ N)
    (a : ℤ) (happrox : |α - (a : ℝ) / (q : ℝ)| ≤ 1 / ((q : ℝ) * (p : ℝ)))
    (hL : 2000 * κ ≤ amoFiniteLyapunov α lam z N)
    (hd : amoRecordGap α lam z N ≤ κ / 100)
    (hbadq : AMORecordBadMasses α lam z κ C c q)
    (hbadp : AMORecordBadMasses α lam z κ C c p) :
    ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      amoFiniteLyapunov α lam z N - 6 * amoRecordGap α lam z N -
          Real.exp (-(c / 2000) * (q : ℝ)) - amoRecordTransitionConstant / (p : ℝ) ^ 5 ≤
        amoFiniteLyapunov α lam z R ∧
      (R : ℝ) * amoRecordGap α lam z R ≤ (N : ℝ) * amoRecordGap α lam z N +
        amoRecordTransitionConstant * (p : ℝ) := by
  have hstep : ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      amoFiniteLyapunov α lam z N - 6 * amoRecordGap α lam z N -
          Real.exp (-(c / 2000) * (q : ℝ)) - 2 * Real.log (amoTransferBound lam z) / (p : ℝ) ^ 5 ≤
        amoFiniteLyapunov α lam z R ∧
      (R : ℝ) * amoRecordGap α lam z R ≤ (N : ℝ) * amoRecordGap α lam z N +
        (3 + 9 * Real.log (amoTransferBound lam z)) * (p : ℝ) := by
    rcases le_or_gt (p : ℝ) (Real.exp (4 * (c / 1000) * (q : ℝ))) with hshort | hlong
    · exact amoRecordTransition_ordinary α lam z hlam hz hκ hc hCκ hs hqp hNlo hNhi hL hd hbadq hshort
    · exact amoRecordTransition_long α lam z hlam hz hκ hC hc hCκ hs hpScalar hqp hNlo hNhi hqN
        a happrox hL hd hbadq hbadp hlong
  obtain ⟨R, hRd, hNR, hRT, hRmax, hLR, hwR⟩ := hstep
  have hB := amoRecord_log_bound hlam hz
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num)
  have hAB : 2 * Real.log (amoTransferBound lam z) ≤ amoRecordTransitionConstant := by
    unfold amoRecordTransitionConstant
    linarith
  have hAw : 3 + 9 * Real.log (amoTransferBound lam z) ≤ amoRecordTransitionConstant := by
    unfold amoRecordTransitionConstant
    linarith
  have htail := div_le_div_of_nonneg_right hAB
    (pow_nonneg (Nat.cast_nonneg p : (0 : ℝ) ≤ p) 5)
  have hwA := mul_le_mul_of_nonneg_right hAw (Nat.cast_nonneg p : (0 : ℝ) ≤ p)
  exact ⟨R, hRd, hNR, hRT, hRmax, by linarith, by linarith⟩

end CriticalDTM

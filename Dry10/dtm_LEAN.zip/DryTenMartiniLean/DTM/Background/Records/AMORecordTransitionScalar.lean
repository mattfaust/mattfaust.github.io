import DTM.Background.Records.AMORecordTransitionBounds

/-! # Scalar thresholds for one record-denominator transition

Every field is an elementary inequality in one natural denominator and fixed
real constants. The eventual existence of these bounds is independent of
all transfer matrices, frequencies, and Lyapunov exponents.
-/

noncomputable section
namespace CriticalDTM

structure AMORecordTransitionScalar (κ C c : ℝ) (q : ℕ) : Prop where
  positive : 0 < q
  polynomial : 2 * (C + 1) * (q : ℝ) ≤ (q : ℝ) ^ 6
  scale : Real.log 10000 ≤ 200 * κ * (q : ℝ) ^ 6
  gap : Real.log 2 / (2 * (q : ℝ) ^ 6) ≤ κ
  radius_small : (q : ℝ) * Real.exp (-(c / 1000) * (q : ℝ)) ≤ 1
  long_room : 24 * (q : ℝ) ^ 6 ≤
    Real.exp (-(c / 1000) * (q : ℝ)) * (q : ℝ) * Real.exp (4 * (c / 1000) * (q : ℝ))
  near_small : amoRecordErrorConstant *
    ((q : ℝ) ^ 6 * Real.exp (-(c / 1000) * (q : ℝ)) + Real.exp (-c * (q : ℝ))) ≤
      min (κ / 100) (Real.exp (-(c / 2000) * (q : ℝ)) / 100)
  near_weight : Real.exp (-(c / 1000) * (q : ℝ)) * (q : ℝ) *
    (amoRecordErrorConstant *
      ((q : ℝ) ^ 6 * Real.exp (-(c / 1000) * (q : ℝ)) + Real.exp (-c * (q : ℝ)))) ≤ 1 / 100
  bridge_small : (8 * (C + 1) * Real.exp ((c / 1000) * (q : ℝ))) *
    (amoRecordErrorConstant * Real.exp (-c * (q : ℝ))) ≤
      min (κ / 100) (Real.exp (-(c / 2000) * (q : ℝ)) / 100)
  ordinary_small : 6 * Real.exp (24 * (c / 1000) * (q : ℝ)) *
    (amoRecordErrorConstant * Real.exp (-c * (q : ℝ))) ≤
      min (κ / 100) (Real.exp (-(c / 2000) * (q : ℝ)) / 100)
  polynomial_small : 6 * (q : ℝ) ^ 6 *
    (amoRecordErrorConstant * Real.exp (-c * (q : ℝ))) ≤
      min (κ / 100) (Real.exp (-(c / 2000) * (q : ℝ)) / 100)

end CriticalDTM

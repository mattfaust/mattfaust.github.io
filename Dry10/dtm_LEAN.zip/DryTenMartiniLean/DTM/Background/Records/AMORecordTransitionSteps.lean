import DTM.Background.Records.AMODyadicPropagation
import DTM.Background.Records.AMONearPeriodicStep

/-!
# Finite scale-selection steps for record-denominator propagation

These lemmas select actual lengths and apply the proved dyadic and
near-periodic avalanche estimates. All later-scale growth and pair conditions
are derived from finite initial data. Scalar error budgets in these local
lemmas are not assumptions about future Lyapunov exponents.
-/

noncomputable section
open MeasureTheory Set
namespace CriticalDTM

/-- The actual finite dyadic drop. -/
def amoRecordGap (α lam : ℝ) (z : ℂ) (N : ℕ) : ℝ :=
  amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)

theorem amoRecordGap_nonneg (α lam : ℝ) (z : ℂ) (N : ℕ) :
    0 ≤ amoRecordGap α lam z N :=
  sub_nonneg.mpr (amoFiniteLyapunov_double_le α lam z N)

/-- The first dyadic multiple above a target overshoots by less than a factor
of two, unless the initial length was already above the target. -/
theorem exists_dyadic_multiple_near_target (N T : ℕ) (hN : 0 < N) :
    ∃ r : ℕ, T ≤ 2 ^ r * N ∧ N ≤ 2 ^ r * N ∧
      2 ^ r * N ≤ max N (2 * T) ∧ r ≤ 2 ^ r := by
  have hex : ∃ r : ℕ, T ≤ 2 ^ r * N := by
    refine ⟨T, (show T < 2 ^ T from Nat.lt_two_pow_self).le.trans ?_⟩
    simpa only [Nat.succ_eq_add_one, zero_add, mul_one] using Nat.mul_le_mul_left (2 ^ T) hN
  let r := Nat.find hex
  have hr : T ≤ 2 ^ r * N := Nat.find_spec hex
  have hupper : 2 ^ r * N ≤ max N (2 * T) := by
    cases hr0 : r with
    | zero => simp only [hr0, pow_zero, one_mul]; exact le_max_left _ _
    | succ s =>
      have hs : ¬ T ≤ 2 ^ s * N := Nat.find_min hex (by omega)
      have hlt : 2 ^ s * N < T := Nat.lt_of_not_ge hs
      calc
        2 ^ (s + 1) * N = 2 * (2 ^ s * N) := by rw [pow_succ]; ring
        _ ≤ 2 * T := Nat.mul_le_mul_left 2 hlt.le
        _ ≤ _ := le_max_right _ _
  refine ⟨r, hr, ?_, hupper, (show r < 2 ^ r from Nat.lt_two_pow_self).le⟩
  simpa only [one_mul] using Nat.mul_le_mul_right N
    (one_le_pow₀ (by norm_num : 1 ≤ (2 : ℕ)))

/-- A dyadic target is reached with a genuine weighted-gap estimate. The
single scalar budget bounds all errors in the finite induction. -/
theorem amoFiniteLyapunov_dyadic_to_target
    (α lam : ℝ) (z : ℂ) (N T : ℕ) (hN : 0 < N)
    {κ δ ε H : ℝ} (hκ : 0 < κ) (hδ : 0 ≤ δ)
    (hscale : Real.log 10000 ≤ 200 * κ * (N : ℝ))
    (hinitial : 1000 * κ ≤ amoFiniteLyapunov α lam z N)
    (hpair : amoRecordGap α lam z N ≤ amoFiniteLyapunov α lam z N / 20)
    (hbad : ∀ M, N ≤ M → (volume.restrict (Ioc (0 : ℝ) 1)).real
      (amoAvalancheBaseBadSet α lam z M κ) ≤ δ)
    (herr : amoDyadicPropagationError lam z N κ δ ≤ ε)
    (hH : ((max N (2 * T) : ℕ) : ℝ) ≤ H * (N : ℝ))
    (hbudget : H * ε ≤ κ) :
    ∃ P : ℕ, T ≤ P ∧ N ≤ P ∧ P ≤ max N (2 * T) ∧
      amoFiniteLyapunov α lam z N - 2 * amoRecordGap α lam z N - 2 * H * ε ≤
        amoFiniteLyapunov α lam z P ∧
      (P : ℝ) * amoRecordGap α lam z P ≤
        (N : ℝ) * amoRecordGap α lam z N + 2 * (P : ℝ) * ε ∧
      amoRecordGap α lam z P ≤ amoRecordGap α lam z N + 2 * ε := by
  obtain ⟨r, hrT, hrN, hrupper, hrr⟩ := exists_dyadic_multiple_near_target N T hN
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hε : 0 ≤ ε := (amoDyadicPropagationError_nonneg lam z N hδ).trans herr
  have hH1 : 1 ≤ H := by
    have hmax : (N : ℝ) ≤ ((max N (2 * T) : ℕ) : ℝ) := by
      exact_mod_cast le_max_left N (2 * T)
    nlinarith
  have hrH : (r : ℝ) ≤ H := by
    have h1 : (r : ℝ) * (N : ℝ) ≤ ((2 ^ r * N : ℕ) : ℝ) := by
      exact_mod_cast Nat.mul_le_mul_right N hrr
    have h2 : ((2 ^ r * N : ℕ) : ℝ) ≤ ((max N (2 * T) : ℕ) : ℝ) := by
      exact_mod_cast hrupper
    nlinarith
  have herror : amoDyadicPropagationError lam z N κ δ ≤ κ := by
    have h := mul_le_mul_of_nonneg_right hH1 hε
    linarith
  have hrerr : (r : ℝ) * amoDyadicPropagationError lam z N κ δ ≤ κ := by
    calc
      _ ≤ (r : ℝ) * ε := mul_le_mul_of_nonneg_left herr (Nat.cast_nonneg r)
      _ ≤ H * ε := mul_le_mul_of_nonneg_right hrH hε
      _ ≤ _ := hbudget
  obtain ⟨hlower, _, hdrop, _, _, _⟩ := amoFiniteLyapunov_dyadic_propagation
    α lam z N hN hκ hδ hscale hinitial hpair hbad herror r hrerr
  have hsucc : 2 ^ (r + 1) * N = 2 * (2 ^ r * N) := by rw [pow_succ]; ring
  rw [hsucc] at hdrop
  change amoRecordGap α lam z (2 ^ r * N) ≤
    (1 / 2 : ℝ) ^ r * amoRecordGap α lam z N +
      2 * amoDyadicPropagationError lam z N κ δ at hdrop
  have hrε : (r : ℝ) * amoDyadicPropagationError lam z N κ δ ≤ H * ε := by
    exact (mul_le_mul_of_nonneg_left herr (Nat.cast_nonneg r)).trans
      (mul_le_mul_of_nonneg_right hrH hε)
  refine ⟨2 ^ r * N, hrT, hrN, hrupper, by dsimp only [amoRecordGap] at *; linarith, ?_, ?_⟩
  · have hw := mul_le_mul_of_nonneg_left hdrop
      (Nat.cast_nonneg (2 ^ r * N) : (0 : ℝ) ≤ (2 ^ r * N : ℕ))
    have hcancel : ((2 ^ r * N : ℕ) : ℝ) * (1 / 2 : ℝ) ^ r = N := by
      push_cast
      calc
        (2 : ℝ) ^ r * (N : ℝ) * (1 / 2 : ℝ) ^ r =
            (2 * (1 / 2 : ℝ)) ^ r * (N : ℝ) := by rw [mul_pow]; ring
        _ = _ := by norm_num
    rw [mul_add, ← mul_assoc, hcancel] at hw
    have he := mul_le_mul_of_nonneg_left herr
      (show 0 ≤ 2 * ((2 ^ r * N : ℕ) : ℝ) by positivity)
    nlinarith
  · have hp : (1 / 2 : ℝ) ^ r ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
    have ht := mul_le_mul_of_nonneg_right hp (amoRecordGap_nonneg α lam z N)
    linarith

/-- The near-periodic weighted estimate at any block count at least two. -/
theorem amoFiniteLyapunov_nearPeriodic_blocks
    (α lam : ℝ) (z : ℂ) (N m : ℕ) (hN : 0 < N) (hm : 2 ≤ m)
    (a : ℤ) (q : ℕ) (hq : 0 < q) (hqN : q ∣ N)
    {κ η δ E : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hnear : (((m * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hL : 800 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤ amoFiniteLyapunov α lam z (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2)
    (hbadN : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z N (amoFiniteLyapunov α lam z N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z (2 * N) (amoFiniteLyapunov α lam z (2 * N)) κ) ≤ δ)
    (herr : 1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
      4 * Real.log (amoTransferBound lam z) * δ +
      192 * Real.log (amoTransferBound lam z) * (N : ℝ) * η ≤ E) :
    |amoFiniteLyapunov α lam z (m * N) - amoFiniteLyapunov α lam z N +
      2 * (1 - 1 / (m : ℝ)) * amoRecordGap α lam z N| ≤ E := by
  have hmidx : m - 2 + 2 = m := Nat.sub_add_cancel hm
  have h := amoFiniteLyapunov_nearPeriodic_step α lam z N (m - 2) hN a q hq hqN
    hκ hη (by simpa only [hmidx] using hnear) hgap hL hL2 hscale hbadN hbad2N
  simp only [hmidx] at h
  have heq : amoFiniteLyapunov α lam z (m * N) +
      (1 - 2 / (m : ℝ)) * amoFiniteLyapunov α lam z N -
      2 * (1 - 1 / (m : ℝ)) * amoFiniteLyapunov α lam z (2 * N) =
      amoFiniteLyapunov α lam z (m * N) - amoFiniteLyapunov α lam z N +
        2 * (1 - 1 / (m : ℝ)) * amoRecordGap α lam z N := by
    unfold amoRecordGap
    ring
  rw [heq] at h
  exact h.trans herr

/-- Applying the actual near-periodic AP at `m` and `2m` yields `1/m`
damping of the finite drop, including the weighted endpoint correction. -/
theorem amoFiniteLyapunov_nearPeriodic_pair
    (α lam : ℝ) (z : ℂ) (N m : ℕ) (hN : 0 < N) (hm : 2 ≤ m)
    (a : ℤ) (q : ℕ) (hq : 0 < q) (hqN : q ∣ N)
    {κ η δ E : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hnear : ((((2 * m) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hL : 800 * κ ≤ amoFiniteLyapunov α lam z N)
    (hL2 : (9 / 10 : ℝ) * amoFiniteLyapunov α lam z N ≤ amoFiniteLyapunov α lam z (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * amoFiniteLyapunov α lam z N / 2)
    (hbadN : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z N (amoFiniteLyapunov α lam z N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (amoFiniteFrobeniusBadSet α lam z (2 * N) (amoFiniteLyapunov α lam z (2 * N)) κ) ≤ δ)
    (herr : 1000 / ((N : ℝ) * Real.exp ((N : ℝ) * amoFiniteLyapunov α lam z N / 2)) +
      4 * Real.log (amoTransferBound lam z) * δ +
      192 * Real.log (amoTransferBound lam z) * (N : ℝ) * η ≤ E) :
    amoFiniteLyapunov α lam z N - 2 * amoRecordGap α lam z N - E ≤
      amoFiniteLyapunov α lam z (m * N) ∧
    amoRecordGap α lam z (m * N) ≤ amoRecordGap α lam z N / (m : ℝ) + 2 * E ∧
    ((m * N : ℕ) : ℝ) * amoRecordGap α lam z (m * N) ≤
      (N : ℝ) * amoRecordGap α lam z N + 2 * ((m * N : ℕ) : ℝ) * E := by
  have hnear1 : (((m * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η := by
    have hmul : (((m * N : ℕ) : ℝ)) ≤ (((2 * m * N : ℕ) : ℝ)) := by
      exact_mod_cast Nat.mul_le_mul_right N (show m ≤ 2 * m by omega)
    exact (mul_le_mul_of_nonneg_right hmul (abs_nonneg _)).trans hnear
  have h1 := amoFiniteLyapunov_nearPeriodic_blocks α lam z N m hN hm a q hq hqN
    hκ hη hnear1 hgap hL hL2 hscale hbadN hbad2N herr
  have h2 := amoFiniteLyapunov_nearPeriodic_blocks α lam z N (2 * m) hN (by omega)
    a q hq hqN hκ hη hnear hgap hL hL2 hscale hbadN hbad2N herr
  have hmr : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hcoef : 2 * (1 - 1 / ((2 * m : ℕ) : ℝ)) - 2 * (1 - 1 / (m : ℝ)) =
      1 / (m : ℝ) := by push_cast; field_simp [hmr.ne']; ring
  have hidx : 2 * m * N = 2 * (m * N) := by ring
  rw [hidx] at h2
  have hdrop : amoRecordGap α lam z (m * N) ≤ amoRecordGap α lam z N / (m : ℝ) + 2 * E := by
    have hc := congrArg (fun t : ℝ => t * amoRecordGap α lam z N) hcoef
    dsimp only at hc
    dsimp only [amoRecordGap]
    dsimp only [amoRecordGap] at h1 h2 hc
    rw [sub_mul] at hc
    simp only [div_eq_mul_inv, one_mul] at h1 h2 hc ⊢
    nlinarith only [hc, (abs_le.mp h1).2, (abs_le.mp h2).1]
  refine ⟨?_, hdrop, ?_⟩
  · have hnonneg := div_nonneg (amoRecordGap_nonneg α lam z N) hmr.le
    have hcoef1 : 2 * (1 - 1 / (m : ℝ)) * amoRecordGap α lam z N =
        2 * amoRecordGap α lam z N - 2 * (amoRecordGap α lam z N / (m : ℝ)) := by ring
    rw [hcoef1] at h1
    linarith [(abs_le.mp h1).1]
  · have hw := mul_le_mul_of_nonneg_left hdrop
      (Nat.cast_nonneg (m * N) : (0 : ℝ) ≤ ((m * N : ℕ) : ℝ))
    have hcancel : ((m * N : ℕ) : ℝ) * (amoRecordGap α lam z N / (m : ℝ)) =
        (N : ℝ) * amoRecordGap α lam z N := by push_cast; field_simp; ring
    rw [mul_add, hcancel] at hw
    nlinarith

end CriticalDTM

import DTM.Background.Records.AMORecordTransitionResult
import DTM.Background.Records.AMORecordTransitionParameterBridge

/-!
# A genuine one-denominator AMO scale transition

For sufficiently large record denominators, one high finite pair and the
actual finite operator/Frobenius bad masses produce the next polynomial
scale. Both ordinary and exceptionally long denominator jumps are covered.
The scalar threshold is proved, and every intermediate avalanche growth and
pair condition is derived. No infinite-scale positivity is an input.

The height coefficient is the sharper constant `6`. The single uniform
constant `10*(1+log 9)` controls the rounding tail and the weighted increment.
-/

noncomputable section
namespace CriticalDTM

/-- The fully parameter-selected one-record scale transition. The only
analytic hypotheses beyond the current finite pair are actual deviation
masses; there is no hypothesized transition or later Lyapunov lower bound. -/
theorem amoFiniteLyapunov_record_transition {κ C c : ℝ}
    (hκ : 0 < κ) (hC : 1 ≤ C) (hc : 0 < c) (hCκ : c / (100 * κ) ≤ C) :
    ∃ Q : ℕ, ∀ (α lam : ℝ) (z : ℂ) (q p N : ℕ) (a : ℤ),
      Q ≤ q → q < p → |lam| ≤ 1 → ‖z‖ ≤ 5 →
      q ^ 6 ≤ N → N ≤ 3 * q ^ 6 → q ∣ N →
      |α - (a : ℝ) / (q : ℝ)| ≤ 1 / ((q : ℝ) * (p : ℝ)) →
      2000 * κ ≤ amoFiniteLyapunov α lam z N →
      amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N) ≤ κ / 100 →
      AMORecordBadMasses α lam z κ C c q → AMORecordBadMasses α lam z κ C c p →
      ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
        amoFiniteLyapunov α lam z N -
            6 * (amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)) -
            Real.exp (-(c / 2000) * (q : ℝ)) - amoRecordTransitionConstant / (p : ℝ) ^ 5 ≤
          amoFiniteLyapunov α lam z R ∧
        (R : ℝ) * (amoFiniteLyapunov α lam z R - amoFiniteLyapunov α lam z (2 * R)) ≤
          (N : ℝ) * (amoFiniteLyapunov α lam z N - amoFiniteLyapunov α lam z (2 * N)) +
            amoRecordTransitionConstant * (p : ℝ) := by
  obtain ⟨Q, hQ⟩ := exists_amoRecordTransitionScalar hκ (lt_of_lt_of_le (by norm_num) hC) hc
  refine ⟨Q, ?_⟩
  intro α lam z q p N a hQq hqp hlam hz hNlo hNhi hqN happrox hL hd hbadq hbadp
  have hQp : Q ≤ p := hQq.trans hqp.le
  exact amoFiniteLyapunov_record_transition_of_scalar_bounds α lam z hlam hz hκ hC hc hCκ
    (hQ q hQq) (hQ p hQp) hqp hNlo hNhi hqN a happrox hL hd hbadq hbadp

end CriticalDTM

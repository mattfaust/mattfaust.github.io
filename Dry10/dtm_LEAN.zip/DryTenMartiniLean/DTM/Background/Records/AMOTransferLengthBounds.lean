import DTM.Background.Transfer.AMOTransferShiftBounds

/-!
# Length perturbation and rounding bounds for actual AMO transfer products

An explicitly reverse-ordered word of the literal one-step inverses is a
both-sided inverse of each actual transfer product. Its Euclidean operator
norm is bounded by the same power of the uniform one-step bound. Removing
or adding a suffix therefore changes the logarithm by at most its length
times `log K`, with no auxiliary norm-equivalence loss.

Phase integration and normalization give length stability for the actual
finite Lyapunov exponents. The final bounds control rounding a scale and
its dyadic gap; they require no deviation, persistence, or spectral input.
-/

noncomputable section

open Matrix MeasureTheory

namespace CriticalDTM

/-- The inverse word, with the factor order reversed explicitly. -/
def amoTransferProductInv (α lam : ℝ) (z : ℂ) (θ : ℝ) : ℕ → AMOTransferMatrix
  | 0 => 1
  | n + 1 => amoTransferProductInv α lam z θ n *
      amoTransferInv lam z (θ + 2 * Real.pi * α * (n : ℝ))

@[simp] theorem amoTransferProduct_inv_mul
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProductInv α lam z θ n * amoTransferProduct α lam z θ n = 1 := by
  induction n with
  | zero => simp [amoTransferProductInv]
  | succ n ih =>
      rw [amoTransferProduct_succ, amoTransferProductInv, mul_assoc,
        ← mul_assoc (amoTransferInv lam z _), amoTransfer_inv_mul, one_mul, ih]

/-- The actual inverse word has the same exponential norm bound. -/
theorem amoTransferProductInv_norm_le_pow
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferNorm (amoTransferProductInv α lam z θ n) ≤ amoTransferBound lam z ^ n := by
  induction n with
  | zero => simp [amoTransferProductInv]
  | succ n ih =>
      rw [amoTransferProductInv]
      calc
        _ ≤ amoTransferNorm (amoTransferProductInv α lam z θ n) *
            amoTransferNorm (amoTransferInv lam z (θ + 2 * Real.pi * α * (n : ℝ))) :=
          amoTransferNorm_mul_le _ _
        _ ≤ amoTransferBound lam z ^ n * amoTransferBound lam z :=
          mul_le_mul ih (amoTransferInv_norm_le_bound lam z _)
            (amoTransferNorm_nonneg _) (pow_nonneg (amoTransferBound_pos lam z).le _)
        _ = _ := (pow_succ _ _).symm

/-- Adding the actual suffix multiplies the norm by at most `K^(m-n)`. -/
theorem amoTransferProduct_length_norm_le
    (α lam : ℝ) (z : ℂ) (θ : ℝ) {n m : ℕ} (hnm : n ≤ m) :
    amoTransferNorm (amoTransferProduct α lam z θ m) ≤
      amoTransferBound lam z ^ (m - n) *
        amoTransferNorm (amoTransferProduct α lam z θ n) := by
  have heq : (m - n) + n = m := Nat.sub_add_cancel hnm
  calc
    _ = amoTransferNorm
        (amoTransferProduct α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n) *
          amoTransferProduct α lam z θ n) := by rw [← amoTransferProduct_add, heq]
    _ ≤ amoTransferNorm
        (amoTransferProduct α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n)) *
          amoTransferNorm (amoTransferProduct α lam z θ n) := amoTransferNorm_mul_le _ _
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (amoTransferProduct_norm_le_pow α lam z _ _) (amoTransferNorm_nonneg _)

/-- Removing a suffix uses its proved actual inverse, not a totalized matrix inverse. -/
theorem amoTransferProduct_length_norm_reverse_le
    (α lam : ℝ) (z : ℂ) (θ : ℝ) {n m : ℕ} (hnm : n ≤ m) :
    amoTransferNorm (amoTransferProduct α lam z θ n) ≤
      amoTransferBound lam z ^ (m - n) *
        amoTransferNorm (amoTransferProduct α lam z θ m) := by
  have heq : (m - n) + n = m := Nat.sub_add_cancel hnm
  have hinv : amoTransferProduct α lam z θ n =
      amoTransferProductInv α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n) *
        amoTransferProduct α lam z θ m := by
    calc
      _ = amoTransferProductInv α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n) *
          (amoTransferProduct α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n) *
            amoTransferProduct α lam z θ n) := by
        rw [← mul_assoc, amoTransferProduct_inv_mul, one_mul]
      _ = _ := by rw [← amoTransferProduct_add, heq]
  calc
    _ = amoTransferNorm
        (amoTransferProductInv α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n) *
          amoTransferProduct α lam z θ m) := congrArg amoTransferNorm hinv
    _ ≤ amoTransferNorm
        (amoTransferProductInv α lam z (θ + 2 * Real.pi * α * (n : ℝ)) (m - n)) *
          amoTransferNorm (amoTransferProduct α lam z θ m) := amoTransferNorm_mul_le _ _
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (amoTransferProductInv_norm_le_pow α lam z _ _) (amoTransferNorm_nonneg _)

/-- Exact pointwise logarithmic length stability, including zero length. -/
theorem amoTransferLogNorm_length_abs_sub_le
    (α lam : ℝ) (z : ℂ) (θ : ℝ) {n m : ℕ} (hnm : n ≤ m) :
    |amoTransferLogNorm α lam z θ m - amoTransferLogNorm α lam z θ n| ≤
      ((m : ℝ) - (n : ℝ)) * Real.log (amoTransferBound lam z) := by
  have hK := (pow_pos (amoTransferBound_pos lam z) (m - n)).ne'
  have hf := Real.log_le_log (amoTransferProduct_norm_pos α lam z θ m)
    (amoTransferProduct_length_norm_le α lam z θ hnm)
  have hb := Real.log_le_log (amoTransferProduct_norm_pos α lam z θ n)
    (amoTransferProduct_length_norm_reverse_le α lam z θ hnm)
  rw [Real.log_mul hK (amoTransferProduct_norm_pos α lam z θ n).ne',
    Real.log_pow, Nat.cast_sub hnm] at hf
  rw [Real.log_mul hK (amoTransferProduct_norm_pos α lam z θ m).ne',
    Real.log_pow, Nat.cast_sub hnm] at hb
  unfold amoTransferLogNorm
  exact abs_le.mpr ⟨by linarith, by linarith⟩

/-- Integration preserves the exact unnormalized length bound. -/
theorem amoTransferLogAverage_length_abs_sub_le
    (α lam : ℝ) (z : ℂ) {n m : ℕ} (hnm : n ≤ m) :
    |amoTransferLogAverage α lam z m - amoTransferLogAverage α lam z n| ≤
      ((m : ℝ) - (n : ℝ)) * Real.log (amoTransferBound lam z) := by
  have hperiod : 0 < 2 * Real.pi := by positivity
  have hi := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0 : ℝ)) (b := 2 * Real.pi)
    (f := fun θ => amoTransferLogNorm α lam z θ m - amoTransferLogNorm α lam z θ n)
    (C := ((m : ℝ) - (n : ℝ)) * Real.log (amoTransferBound lam z))
    (fun θ _ => by simpa only [Real.norm_eq_abs] using
      amoTransferLogNorm_length_abs_sub_le α lam z θ hnm)
  unfold amoTransferLogAverage
  rw [← sub_div, abs_div, abs_of_pos hperiod]
  apply (div_le_iff₀ hperiod).mpr
  rw [← intervalIntegral.integral_sub
    (amoTransferLogNorm_intervalIntegrable α lam z m 0 (2 * Real.pi))
    (amoTransferLogNorm_intervalIntegrable α lam z n 0 (2 * Real.pi))]
  simpa only [Real.norm_eq_abs, sub_zero, abs_of_pos hperiod] using hi

/-- Undoing the finite-scale normalization, valid also at the unused zero scale. -/
theorem amoTransferLogAverage_eq_mul_finite (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoTransferLogAverage α lam z n = (n : ℝ) * amoFiniteLyapunov α lam z n := by
  by_cases hn : n = 0
  · subst n
    simp
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  unfold amoFiniteLyapunov
  field_simp

/-- Changing any positive length by a suffix changes the actual finite
Lyapunov exponent by at most twice the relative length change times `log K`. -/
theorem amoFiniteLyapunov_length_abs_sub_le
    (α lam : ℝ) (z : ℂ) {n m : ℕ} (hn : 0 < n) (hnm : n ≤ m) :
    |amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z n| ≤
      2 * Real.log (amoTransferBound lam z) * ((m : ℝ) - (n : ℝ)) / (n : ℝ) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hnm' : (n : ℝ) ≤ (m : ℝ) := by exact_mod_cast hnm
  have hgap := amoTransferLogAverage_length_abs_sub_le α lam z hnm
  rw [amoTransferLogAverage_eq_mul_finite, amoTransferLogAverage_eq_mul_finite] at hgap
  have hB := Real.log_nonneg (amoTransferBound_one_le lam z)
  have hL0 := amoFiniteLyapunov_nonneg α lam z m
  have hL1 := amoFiniteLyapunov_le_log_bound α lam z m
  have hp0 := mul_nonneg (sub_nonneg.mpr hnm') hL0
  have hp1 := mul_le_mul_of_nonneg_left hL1 (sub_nonneg.mpr hnm')
  have hscaled : |(n : ℝ) *
      (amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z n)| ≤
      2 * Real.log (amoTransferBound lam z) * ((m : ℝ) - (n : ℝ)) := by
    exact abs_le.mpr ⟨by nlinarith [(abs_le.mp hgap).1],
      by nlinarith [(abs_le.mp hgap).2, mul_nonneg (sub_nonneg.mpr hnm') hB]⟩
  apply (le_div_iff₀ hn').mpr
  simpa only [abs_mul, abs_of_pos hn', mul_comm] using hscaled

/-- Doubling decreases the actual averaged finite exponent by subadditivity. -/
theorem amoFiniteLyapunov_two_mul_le (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoFiniteLyapunov α lam z (2 * n) ≤ amoFiniteLyapunov α lam z n := by
  by_cases hn : n = 0
  · subst n
    simp
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn
  have h := amoTransferLogAverage_subadditive α lam z n n
  rw [← two_mul n] at h
  simp only [amoTransferLogAverage_eq_mul_finite, Nat.cast_mul, Nat.cast_ofNat] at h
  nlinarith

/-- The dyadic gap is an actual nonnegative finite quantity bounded by `log K`. -/
theorem amoFiniteLyapunov_dyadicGap_bounds (α lam : ℝ) (z : ℂ) (n : ℕ) :
    0 ≤ amoFiniteLyapunov α lam z n - amoFiniteLyapunov α lam z (2 * n) ∧
    amoFiniteLyapunov α lam z n - amoFiniteLyapunov α lam z (2 * n) ≤
      Real.log (amoTransferBound lam z) := by
  exact ⟨sub_nonneg.mpr (amoFiniteLyapunov_two_mul_le α lam z n),
    (sub_le_self _ (amoFiniteLyapunov_nonneg α lam z (2 * n))).trans
      (amoFiniteLyapunov_le_log_bound α lam z n)⟩

/-- Length stability at the base and doubled lengths controls the dyadic gap. -/
theorem amoFiniteLyapunov_dyadicGap_length_abs_sub_le
    (α lam : ℝ) (z : ℂ) {n m : ℕ} (hn : 0 < n) (hnm : n ≤ m) :
    |(amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z (2 * m)) -
      (amoFiniteLyapunov α lam z n - amoFiniteLyapunov α lam z (2 * n))| ≤
      4 * Real.log (amoTransferBound lam z) * ((m : ℝ) - (n : ℝ)) / (n : ℝ) := by
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_of_gt hn
  have h1 := amoFiniteLyapunov_length_abs_sub_le α lam z hn hnm
  have h2 := amoFiniteLyapunov_length_abs_sub_le α lam z
    (n := 2 * n) (m := 2 * m) (by omega) (by omega)
  have heq : 2 * Real.log (amoTransferBound lam z) *
      (((2 * m : ℕ) : ℝ) - ((2 * n : ℕ) : ℝ)) / ((2 * n : ℕ) : ℝ) =
      2 * Real.log (amoTransferBound lam z) * ((m : ℝ) - (n : ℝ)) / (n : ℝ) := by
    push_cast
    field_simp
    ring
  rw [heq] at h2
  have ht := (abs_sub
    (amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z n)
    (amoFiniteLyapunov α lam z (2 * m) - amoFiniteLyapunov α lam z (2 * n))).trans
      (add_le_add h1 h2)
  convert ht using 1 <;> congr 1 <;> ring

/-- Rounding upward by at most `q` sites costs at most `2 q log K / n`. -/
theorem amoFiniteLyapunov_rounding_abs_sub_le
    (α lam : ℝ) (z : ℂ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) :
    |amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z n| ≤
      2 * Real.log (amoTransferBound lam z) * (q : ℝ) / (n : ℝ) := by
  have hδ : (m : ℝ) - (n : ℝ) ≤ (q : ℝ) := by
    have h : (m : ℝ) ≤ (n : ℝ) + (q : ℝ) := by exact_mod_cast hmq
    linarith
  exact (amoFiniteLyapunov_length_abs_sub_le α lam z hn hnm).trans
    (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hδ
        (mul_nonneg (by norm_num) (Real.log_nonneg (amoTransferBound_one_le lam z))))
      (Nat.cast_nonneg n))

/-- The one-sided rounding loss used to retain a finite-scale lower bound. -/
theorem amoFiniteLyapunov_rounding_lower
    (α lam : ℝ) (z : ℂ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) :
    amoFiniteLyapunov α lam z n -
        2 * Real.log (amoTransferBound lam z) * (q : ℝ) / (n : ℝ) ≤
      amoFiniteLyapunov α lam z m := by
  have h := (abs_le.mp (amoFiniteLyapunov_rounding_abs_sub_le α lam z hn hnm hmq)).1
  linarith

/-- The dyadic gap costs at most `4 q log K / n` under upward rounding. -/
theorem amoFiniteLyapunov_dyadicGap_rounding_abs_sub_le
    (α lam : ℝ) (z : ℂ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) :
    |(amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z (2 * m)) -
      (amoFiniteLyapunov α lam z n - amoFiniteLyapunov α lam z (2 * n))| ≤
      4 * Real.log (amoTransferBound lam z) * (q : ℝ) / (n : ℝ) := by
  have hδ : (m : ℝ) - (n : ℝ) ≤ (q : ℝ) := by
    have h : (m : ℝ) ≤ (n : ℝ) + (q : ℝ) := by exact_mod_cast hmq
    linarith
  exact (amoFiniteLyapunov_dyadicGap_length_abs_sub_le α lam z hn hnm).trans
    (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hδ
        (mul_nonneg (by norm_num) (Real.log_nonneg (amoTransferBound_one_le lam z))))
      (Nat.cast_nonneg n))

/-- When the rounding tolerance is no larger than the base length, the
length-weighted dyadic gap incurs only a length-independent rounding error. -/
theorem amoFiniteLyapunov_weightedDyadicGap_rounding_le
    (α lam : ℝ) (z : ℂ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) (hqn : q ≤ n) :
    (m : ℝ) * (amoFiniteLyapunov α lam z m - amoFiniteLyapunov α lam z (2 * m)) ≤
      (n : ℝ) * (amoFiniteLyapunov α lam z n - amoFiniteLyapunov α lam z (2 * n)) +
        9 * Real.log (amoTransferBound lam z) * (q : ℝ) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hnm' : (n : ℝ) ≤ (m : ℝ) := by exact_mod_cast hnm
  have hm2 : (m : ℝ) ≤ 2 * (n : ℝ) := by
    have h : m ≤ 2 * n := by omega
    exact_mod_cast h
  have hδ : (m : ℝ) - (n : ℝ) ≤ (q : ℝ) := by
    have h : (m : ℝ) ≤ (n : ℝ) + (q : ℝ) := by exact_mod_cast hmq
    linarith
  have hB := Real.log_nonneg (amoTransferBound_one_le lam z)
  have hgap := mul_le_mul_of_nonneg_left
    (abs_le.mp (amoFiniteLyapunov_dyadicGap_rounding_abs_sub_le α lam z hn hnm hmq)).2
    (Nat.cast_nonneg m : (0 : ℝ) ≤ (m : ℝ))
  have herr := mul_le_mul_of_nonneg_right hm2
    (show 0 ≤ 4 * Real.log (amoTransferBound lam z) * (q : ℝ) / (n : ℝ) by positivity)
  have hcancel : (2 * (n : ℝ)) *
      (4 * Real.log (amoTransferBound lam z) * (q : ℝ) / (n : ℝ)) =
      8 * Real.log (amoTransferBound lam z) * (q : ℝ) := by
    field_simp
    ring
  rw [hcancel] at herr
  have hd := mul_le_mul_of_nonneg_left (amoFiniteLyapunov_dyadicGap_bounds α lam z n).2
    (sub_nonneg.mpr hnm')
  have hdq := mul_le_mul_of_nonneg_right hδ hB
  nlinarith

end CriticalDTM

import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Order.Filter.AtTopBot.Tendsto
import Mathlib.Tactic

/-!
# Scalar record-scale budget and dependent construction

This file has no dynamical or spectral input. Its transition hypothesis is a
single finite step, applicable only after a high finite value and a small
doubling defect have been established. A summable scalar budget recovers
those two conditions at every step of the construction. In particular, no
future finite-scale positivity or limiting Lyapunov bound is assumed.

The height-loss coefficient `H` is independent of the common error constant
`A`. No nonnegativity assumption on the doubling defect is needed.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace CriticalDTM

/-- The finite doubling defect of an arbitrary real-valued sequence. -/
def recordScaleGap (F : ℕ → ℝ) (N : ℕ) : ℝ := F N - F (2 * N)

/-- A denominator-only upper bound for the propagated doubling defect. -/
def recordScaleGapEnvelope (κ A : ℝ) (q : ℕ) : ℝ :=
  κ / (50 * (q : ℝ) ^ 2) + A / (q : ℝ) ^ 4

/-- A summable upper bound for one step's height loss. -/
def recordScaleLossEnvelope (κ A H γ : ℝ) (q : ℕ) : ℝ :=
  H * recordScaleGapEnvelope κ A q + Real.exp (-γ * (q : ℝ)) + A / (q : ℝ) ^ 5

/-- The only propagation hypothesis: one finite transition from one admissible
scale. This is not a hypothesis about an already existing infinite sequence. -/
def RecordScaleTransition (κ A H γ : ℝ) (F : ℕ → ℝ) (q : ℕ → ℕ) : Prop :=
  ∀ s N : ℕ, (q s) ^ 6 ≤ N → N ≤ 3 * (q s) ^ 6 → q s ∣ N →
    2000 * κ ≤ F N → recordScaleGap F N ≤ κ / 100 →
    ∃ M : ℕ, N ≤ M ∧ (q (s + 1)) ^ 6 ≤ M ∧ M ≤ 3 * (q (s + 1)) ^ 6 ∧
      q (s + 1) ∣ M ∧
      F N - H * recordScaleGap F N - Real.exp (-γ * (q s : ℝ)) -
        A / (q (s + 1) : ℝ) ^ 5 ≤ F M ∧
      (M : ℝ) * recordScaleGap F M ≤
        (N : ℝ) * recordScaleGap F N + A * (q (s + 1) : ℝ)

lemma recordScaleGapEnvelope_nonneg {κ A : ℝ} (hκ : 0 ≤ κ) (hA : 0 ≤ A) (q : ℕ) :
    0 ≤ recordScaleGapEnvelope κ A q := by
  unfold recordScaleGapEnvelope
  positivity

lemma recordScaleLossEnvelope_nonneg {κ A H γ : ℝ}
    (hκ : 0 ≤ κ) (hA : 0 ≤ A) (hH : 0 ≤ H) (q : ℕ) :
    0 ≤ recordScaleLossEnvelope κ A H γ q := by
  unfold recordScaleLossEnvelope
  exact add_nonneg (add_nonneg
    (mul_nonneg hH (recordScaleGapEnvelope_nonneg hκ hA q)) (Real.exp_pos _).le)
    (div_nonneg hA (pow_nonneg (Nat.cast_nonneg _) _))

lemma summable_recordScaleGapEnvelope (κ A : ℝ) :
    Summable (recordScaleGapEnvelope κ A) := by
  have h₂ := (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (2 : ℕ))).mul_left (κ / 50)
  have h₄ := (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (4 : ℕ))).mul_left A
  convert h₂.add h₄ using 1
  ext q
  unfold recordScaleGapEnvelope
  ring

lemma summable_recordScaleLossEnvelope (κ A H : ℝ) {γ : ℝ} (hγ : 0 < γ) :
    Summable (recordScaleLossEnvelope κ A H γ) := by
  have hgap := (summable_recordScaleGapEnvelope κ A).mul_left H
  have hexp : Summable (fun q : ℕ => Real.exp (-γ * (q : ℝ))) := by
    simpa only [mul_comm] using Real.summable_exp_nat_mul_iff.mpr (neg_neg_of_pos hγ)
  have h₅ := (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (5 : ℕ))).mul_left A
  convert (hgap.add hexp).add h₅ using 1
  ext q
  unfold recordScaleLossEnvelope
  ring

/-- A purely scalar threshold: all defects are small above `Q`, and the full
natural-number tail of the loss majorant costs at most `κ`. -/
structure RecordScaleBudgetBounds (κ A H γ : ℝ) (Q : ℕ) : Prop where
  positive : 0 < Q
  gap : ∀ q : ℕ, Q ≤ q → recordScaleGapEnvelope κ A q ≤ κ / 100
  tail : (∑' n : ℕ, recordScaleLossEnvelope κ A H γ (n + Q)) ≤ κ
  summable : Summable (recordScaleLossEnvelope κ A H γ)

/-- Existence of the scalar threshold uses only summability of p-series and
exponential decay; it is independent of `F` and of the record sequence. -/
theorem exists_recordScaleBudgetBounds {κ A H γ : ℝ} (hκ : 0 < κ)
    (hγ : 0 < γ) : ∃ Q : ℕ, RecordScaleBudgetBounds κ A H γ Q := by
  have hgap : ∀ᶠ q : ℕ in atTop, recordScaleGapEnvelope κ A q ≤ κ / 100 :=
    (summable_recordScaleGapEnvelope κ A).tendsto_atTop_zero.eventually
      (eventually_le_nhds (by positivity : (0 : ℝ) < κ / 100))
  have htail : ∀ᶠ Q : ℕ in atTop,
      (∑' n : ℕ, recordScaleLossEnvelope κ A H γ (n + Q)) ≤ κ :=
    (tendsto_sum_nat_add (recordScaleLossEnvelope κ A H γ)).eventually
      (eventually_le_nhds hκ)
  obtain ⟨Q₁, hQ₁⟩ := eventually_atTop.mp hgap
  obtain ⟨Q₂, hQ₂⟩ := eventually_atTop.mp htail
  refine ⟨max 1 (max Q₁ Q₂), ?_⟩
  exact ⟨by omega, fun q hq => hQ₁ q (by omega), hQ₂ _ (by omega),
    summable_recordScaleLossEnvelope κ A H hγ⟩

/-- Any finite selection of distinct denominators above the threshold costs
no more than the full scalar tail. -/
theorem recordScale_prefix_loss_le {κ A H γ : ℝ}
    (hκ : 0 ≤ κ) (hA : 0 ≤ A) (hH : 0 ≤ H) (hγ : 0 < γ)
    {Q : ℕ} (hQ : RecordScaleBudgetBounds κ A H γ Q)
    {q : ℕ → ℕ} (hq : StrictMono q) (hQq : Q ≤ q 0) (s : ℕ) :
    (∑ j ∈ Finset.range s, recordScaleLossEnvelope κ A H γ (q j)) ≤ κ := by
  classical
  let e : ℕ → ℕ := fun j => q j - Q
  have hshift (j : ℕ) : e j + Q = q j :=
    Nat.sub_add_cancel (hQq.trans (hq.monotone (Nat.zero_le j)))
  have he : Function.Injective e := by
    intro i j hij
    apply hq.injective
    simpa only [hshift] using congrArg (fun n => n + Q) hij
  have hs : Summable (fun n : ℕ => recordScaleLossEnvelope κ A H γ (n + Q)) :=
    (summable_nat_add_iff Q).mpr (summable_recordScaleLossEnvelope κ A H hγ)
  calc
    _ = ∑ n ∈ (Finset.range s).image e, recordScaleLossEnvelope κ A H γ (n + Q) := by
      rw [Finset.sum_image (fun i _ j _ hij => he hij)]
      simp only [hshift]
    _ ≤ ∑' n : ℕ, recordScaleLossEnvelope κ A H γ (n + Q) :=
      hs.sum_le_tsum _ (fun n _ => recordScaleLossEnvelope_nonneg hκ hA hH (n + Q))
    _ ≤ κ := hQ.tail

/-- The quadratic weighted-defect envelope absorbs every successive linear
record cost. Strict increase of natural denominators is essential here. -/
lemma recordScale_square_step {q p : ℕ} (hqp : q < p) :
    (q : ℝ) ^ 2 + (p : ℝ) ≤ (p : ℝ) ^ 2 := by
  have hstep : (q : ℝ) + 1 ≤ p := by exact_mod_cast hqp
  have hq : (0 : ℝ) ≤ q := Nat.cast_nonneg q
  have hp : (0 : ℝ) ≤ p := Nat.cast_nonneg p
  nlinarith [mul_nonneg (show 0 ≤ (p : ℝ) - q - 1 by linarith)
    (show 0 ≤ (p : ℝ) + q by positivity)]

/-- Convert the propagated weighted upper bound to a small local defect.
Negative defects cause no difficulty, so no sign assumption is required. -/
lemma recordScale_gap_le_envelope {κ A : ℝ} (hκ : 0 ≤ κ) (hA : 0 ≤ A)
    {q₀ q N : ℕ} (hq : 0 < q) (hq₀ : q₀ ≤ q) (hN : q ^ 6 ≤ N)
    {d : ℝ} (hw : (N : ℝ) * d ≤ κ * (q₀ : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2) :
    d ≤ recordScaleGapEnvelope κ A q := by
  have hqr : (0 : ℝ) < q := by exact_mod_cast hq
  have hNr : (0 : ℝ) < N := by exact_mod_cast (pow_pos hq 6).trans_le hN
  have hq₀r : (q₀ : ℝ) ^ 4 ≤ (q : ℝ) ^ 4 := by
    exact_mod_cast Nat.pow_le_pow_left hq₀ 4
  have hscale : (q : ℝ) ^ 6 ≤ N := by exact_mod_cast hN
  have hid : (q : ℝ) ^ 6 * recordScaleGapEnvelope κ A q =
      κ * (q : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2 := by
    unfold recordScaleGapEnvelope
    field_simp
    ring
  have hb : κ * (q₀ : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2 ≤
      κ * (q : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2 := by gcongr
  have hm := mul_le_mul_of_nonneg_right hscale (recordScaleGapEnvelope_nonneg hκ hA q)
  rw [hid] at hm
  exact (mul_le_mul_left hNr).mp (hw.trans (hb.trans hm))

/-- Finite invariants stored by the dependent recursion. -/
private def RecordScaleState (κ A H γ : ℝ) (F : ℕ → ℝ) (q : ℕ → ℕ)
    (s N : ℕ) : Prop :=
  (q s) ^ 6 ≤ N ∧ N ≤ 3 * (q s) ^ 6 ∧ q s ∣ N ∧
  F ((q 0) ^ 6) - (∑ j ∈ Finset.range s, recordScaleLossEnvelope κ A H γ (q j)) ≤ F N ∧
  (N : ℝ) * recordScaleGap F N ≤ κ * (q 0 : ℝ) ^ 4 / 50 + A * (q s : ℝ) ^ 2

/-- The infinite sequence produced from the finite transition rule. -/
structure RecordScaleSequence (κ : ℝ) (F : ℕ → ℝ) (q Ns : ℕ → ℕ) : Prop where
  initial : Ns 0 = (q 0) ^ 6
  monotone : Monotone Ns
  tendsto : Tendsto Ns atTop atTop
  lower : ∀ s : ℕ, (q s) ^ 6 ≤ Ns s
  upper : ∀ s : ℕ, Ns s ≤ 3 * (q s) ^ 6
  dvd : ∀ s : ℕ, q s ∣ Ns s
  height : ∀ s : ℕ, 2000 * κ ≤ F (Ns s)
  gap : ∀ s : ℕ, recordScaleGap F (Ns s) ≤ κ / 100

/-- Scalar budget induction. All future admissibility conditions are derived
from finite-prefix invariants before the finite transition is invoked. -/
theorem recordScale_sequence_of_budget {κ A H γ : ℝ}
    (hκ : 0 < κ) (hA : 0 < A) (hH : 0 < H) (hγ : 0 < γ)
    {Q : ℕ} (hQ : RecordScaleBudgetBounds κ A H γ Q)
    {F : ℕ → ℝ} {q : ℕ → ℕ} (hq : StrictMono q) (hQq : Q ≤ q 0)
    (hheight₀ : 4000 * κ ≤ F ((q 0) ^ 6))
    (hweight₀ : (((q 0) ^ 6 : ℕ) : ℝ) * recordScaleGap F ((q 0) ^ 6) ≤
      κ * (q 0 : ℝ) ^ 4 / 50)
    (hstep : RecordScaleTransition κ A H γ F q) :
    ∃ Ns : ℕ → ℕ, RecordScaleSequence κ F q Ns := by
  have hden (s : ℕ) : Q ≤ q s := hQq.trans (hq.monotone (Nat.zero_le s))
  have hpos (s : ℕ) : 0 < q s := hQ.positive.trans_le (hden s)
  have hprefix (s : ℕ) :
      (∑ j ∈ Finset.range s, recordScaleLossEnvelope κ A H γ (q j)) ≤ κ :=
    recordScale_prefix_loss_le hκ.le hA.le hH.le hγ hQ hq hQq s
  have height {s N : ℕ} (hN : RecordScaleState κ A H γ F q s N) :
      2000 * κ ≤ F N := by
    have hl := hN.2.2.2.1
    have hb := hprefix s
    linarith
  have gapEnvelope {s N : ℕ} (hN : RecordScaleState κ A H γ F q s N) :
      recordScaleGap F N ≤ recordScaleGapEnvelope κ A (q s) :=
    recordScale_gap_le_envelope hκ.le hA.le (hpos s)
      (hq.monotone (Nat.zero_le s)) hN.1 hN.2.2.2.2
  have gap {s N : ℕ} (hN : RecordScaleState κ A H γ F q s N) :
      recordScaleGap F N ≤ κ / 100 :=
    (gapEnvelope hN).trans (hQ.gap (q s) (hden s))
  have initial : RecordScaleState κ A H γ F q 0 ((q 0) ^ 6) := by
    refine ⟨le_rfl, by omega, dvd_pow_self _ (by norm_num), ?_, ?_⟩
    · simp only [Finset.range_zero, Finset.sum_empty, sub_zero, le_refl]
    · exact hweight₀.trans (le_add_of_nonneg_right
        (mul_nonneg hA.le (sq_nonneg (q 0 : ℝ))))
  have next (s N : ℕ) (hN : RecordScaleState κ A H γ F q s N) :
      ∃ M : ℕ, N ≤ M ∧ RecordScaleState κ A H γ F q (s + 1) M := by
    obtain ⟨M, hNM, hMlo, hMhi, hMdvd, hMF, hMw⟩ :=
      hstep s N hN.1 hN.2.1 hN.2.2.1 (height hN) (gap hN)
    refine ⟨M, hNM, hMlo, hMhi, hMdvd, ?_, ?_⟩
    · have hrat : A / (q (s + 1) : ℝ) ^ 5 ≤ A / (q s : ℝ) ^ 5 := by
        apply div_le_div_of_nonneg_left hA.le
        · exact pow_pos (by exact_mod_cast hpos s) 5
        · gcongr
          exact_mod_cast hq.monotone (Nat.le_succ s)
      have hg := mul_le_mul_of_nonneg_left (gapEnvelope hN) hH.le
      have hl := hN.2.2.2.1
      rw [Finset.sum_range_succ]
      unfold recordScaleLossEnvelope at hl ⊢
      linarith
    · have hw := hN.2.2.2.2
      have hsquare := mul_le_mul_of_nonneg_left
        (recordScale_square_step (hq (Nat.lt_succ_self s))) hA.le
      nlinarith
  let State (s : ℕ) := {N : ℕ // RecordScaleState κ A H γ F q s N}
  let advance (s : ℕ) (x : State s) : State (s + 1) :=
    ⟨Classical.choose (next s x.val x.property),
      (Classical.choose_spec (next s x.val x.property)).2⟩
  let states : (s : ℕ) → State s :=
    Nat.rec ⟨(q 0) ^ 6, initial⟩ (fun s x => advance s x)
  let Ns : ℕ → ℕ := fun s => (states s).val
  have hstates (s : ℕ) : RecordScaleState κ A H γ F q s (Ns s) :=
    (states s).property
  have hmono : Monotone Ns := by
    apply monotone_nat_of_le_succ
    intro s
    exact (Classical.choose_spec (next s (states s).val (states s).property)).1
  refine ⟨Ns, ?_⟩
  exact {
    initial := rfl
    monotone := hmono
    tendsto := tendsto_atTop_mono (fun s =>
      (Nat.le_pow (by norm_num : 0 < (6 : ℕ))).trans (hstates s).1) hq.tendsto_atTop
    lower := fun s => (hstates s).1
    upper := fun s => (hstates s).2.1
    dvd := fun s => (hstates s).2.2.1
    height := fun s => height (hstates s)
    gap := fun s => gap (hstates s) }

/-- A uniform scalar threshold, chosen before the function and record sequence,
turns the one-record finite rule into a genuine infinite positive sequence. -/
theorem exists_recordScale_budget {κ A H γ : ℝ}
    (hκ : 0 < κ) (hA : 0 < A) (hH : 0 < H) (hγ : 0 < γ) :
    ∃ Q : ℕ, 0 < Q ∧ ∀ (F : ℕ → ℝ) (q : ℕ → ℕ),
      StrictMono q → Q ≤ q 0 →
      4000 * κ ≤ F ((q 0) ^ 6) →
      (((q 0) ^ 6 : ℕ) : ℝ) * recordScaleGap F ((q 0) ^ 6) ≤ κ * (q 0 : ℝ) ^ 4 / 50 →
      RecordScaleTransition κ A H γ F q →
      ∃ Ns : ℕ → ℕ, RecordScaleSequence κ F q Ns := by
  obtain ⟨Q, hQ⟩ := exists_recordScaleBudgetBounds (A := A) (H := H) hκ hγ
  exact ⟨Q, hQ.positive, fun F q hq hQq hheight hweight hstep =>
    recordScale_sequence_of_budget hκ hA hH hγ hQ hq hQq hheight hweight hstep⟩

end CriticalDTM

import DTM.Background.EmpiricalIDS.AMOFiniteVolume
import Mathlib.LinearAlgebra.Matrix.Trace

/-!
# The actual cyclic finite almost Mathieu operator

Only the bond between the two endpoints is restored. For length at least three
this gives the physical nearest-neighbour cycle, with unit hopping on every
bond. The definitions at lengths zero, one and two are harmless extensions;
physical cyclic statements below use length `n + 3`.
-/

noncomputable section
namespace CriticalDTM

open scoped Matrix Matrix.L2OpNorm

/-- The two oriented matrix units of the restored endpoint bond. -/
def amoCyclicCorner : (q : ℕ) → Matrix (Fin q) (Fin q) ℂ
  | 0 => 0
  | n + 1 => Matrix.stdBasisMatrix 0 (Fin.last n) 1 +
      Matrix.stdBasisMatrix (Fin.last n) 0 1

/-- The actual Dirichlet matrix with only the periodic corner bond added. -/
def amoCyclicMatrix (α lam θ : ℝ) (q : ℕ) : Matrix (Fin q) (Fin q) ℂ :=
  amoFiniteMatrix α lam θ q + amoCyclicCorner q

/-- The same cyclic matrix acting on the physical Euclidean coordinate space. -/
def amoCyclicOperator (α lam θ : ℝ) (q : ℕ) : AMOFiniteBoundedOperator q :=
  (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) (amoCyclicMatrix α lam θ q)

@[simp] theorem amoCyclicMatrix_toEuclideanCLM (α lam θ : ℝ) (q : ℕ) :
    (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) (amoCyclicMatrix α lam θ q) = amoCyclicOperator α lam θ q := rfl

theorem amoCyclicOperator_eq_add (α lam θ : ℝ) (q : ℕ) :
    amoCyclicOperator α lam θ q = amoFiniteOperator α lam θ q +
      (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) (amoCyclicCorner q) := by
  rw [amoCyclicOperator, amoCyclicMatrix, map_add, amoFiniteMatrix_toEuclideanCLM]

/-- A matrix unit really sends the physical input coordinate to the specified
physical output coordinate. -/
theorem amoCyclic_matrixUnit_apply (q : ℕ) (i j : Fin q) (u : AMOFiniteHilbert q) :
    (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) (Matrix.stdBasisMatrix i j (1 : ℂ)) u =
      EuclideanSpace.single i (u j) := by
  apply PiLp.ext
  intro a
  change (Matrix.stdBasisMatrix i j (1 : ℂ) *ᵥ u) a = _
  rw [Matrix.mulVec_stdBasisMatrix]
  simp [EuclideanSpace.single_apply, Function.update_apply, eq_comm]

/-- Exact receiving row: no source, potential, or pre-existing bond is changed. -/
theorem amoCyclicOperator_apply_corner (α lam θ : ℝ) (n : ℕ)
    (u : AMOFiniteHilbert (n + 1)) (i : Fin (n + 1)) :
    amoCyclicOperator α lam θ (n + 1) u i =
      amoFiniteExtend (n + 1) u ((i.val : ℤ) + 1) +
      amoFiniteExtend (n + 1) u ((i.val : ℤ) - 1) +
      ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + θ) : ℝ) : ℂ) * u i +
      ((if i = 0 then u (Fin.last n) else 0) +
       (if i = Fin.last n then u 0 else 0)) := by
  rw [amoCyclicOperator_eq_add]
  simp [amoCyclicCorner, amoCyclic_matrixUnit_apply, EuclideanSpace.single_apply, eq_comm]

theorem amoCyclicCorner_isHermitian (q : ℕ) : (amoCyclicCorner q).IsHermitian := by
  cases q with
  | zero => simp [amoCyclicCorner, Matrix.IsHermitian]
  | succ n =>
    simp [amoCyclicCorner, Matrix.IsHermitian, Matrix.conjTranspose_add, add_comm]

theorem amoCyclicMatrix_isHermitian (α lam θ : ℝ) (q : ℕ) :
    (amoCyclicMatrix α lam θ q).IsHermitian :=
  (amoFiniteMatrix_isHermitian α lam θ q).add (amoCyclicCorner_isHermitian q)

theorem amoCyclicOperator_isSelfAdjoint (α lam θ : ℝ) (q : ℕ) :
    IsSelfAdjoint (amoCyclicOperator α lam θ q) :=
  (show IsSelfAdjoint (amoCyclicMatrix α lam θ q) from
    amoCyclicMatrix_isHermitian α lam θ q).map
      (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ))

/-- Euclidean operator norm of one physical matrix unit. -/
theorem amoCyclic_matrixUnit_norm_le (q : ℕ) (i j : Fin q) :
    ‖Matrix.stdBasisMatrix i j (1 : ℂ)‖ ≤ 1 := by
  rw [Matrix.cstar_norm_def]
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro u
  rw [amoCyclic_matrixUnit_apply]
  simpa using PiLp.norm_apply_le u j

theorem amoCyclicCorner_norm_le (q : ℕ) : ‖amoCyclicCorner q‖ ≤ 2 := by
  cases q with
  | zero => simp [amoCyclicCorner]
  | succ n =>
    exact (norm_add_le _ _).trans (by
      have h₁ := amoCyclic_matrixUnit_norm_le (n + 1) 0 (Fin.last n)
      have h₂ := amoCyclic_matrixUnit_norm_le (n + 1) (Fin.last n) 0
      linarith)

theorem amoCyclicMatrix_norm_le (α lam θ : ℝ) (q : ℕ) :
    ‖amoCyclicMatrix α lam θ q‖ ≤ 4 + 2 * |lam| := by
  exact (norm_add_le _ _).trans (by
    have hD := amoFiniteMatrix_norm_le α lam θ q
    have hK := amoCyclicCorner_norm_le q
    linarith)

theorem amoCyclicOperator_norm_le (α lam θ : ℝ) (q : ℕ) :
    ‖amoCyclicOperator α lam θ q‖ ≤ 4 + 2 * |lam| := by
  rw [← amoCyclicMatrix_toEuclideanCLM, ← Matrix.cstar_norm_def]
  exact amoCyclicMatrix_norm_le α lam θ q

theorem continuous_amoCyclicOperator_phase (α lam : ℝ) (q : ℕ) :
    Continuous (fun θ => amoCyclicOperator α lam θ q) := by
  simp_rw [amoCyclicOperator_eq_add]
  exact (continuous_amoFiniteOperator_phase α lam q).add continuous_const

/-- The entry estimate uses the actual Euclidean operator norm, not an
entrywise matrix norm. -/
theorem amoCyclic_matrix_entry_norm_le (q : ℕ) (A : Matrix (Fin q) (Fin q) ℂ)
    (i j : Fin q) : ‖A i j‖ ≤ ‖A‖ := by
  have he : A i j = (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) A (EuclideanSpace.single j 1) i := by
    change _ = (A *ᵥ Pi.single j 1) i
    simp
  rw [he, Matrix.cstar_norm_def]
  calc
    _ ≤ ‖(Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) A (EuclideanSpace.single j 1)‖ := PiLp.norm_apply_le _ _
    _ ≤ ‖(Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) A‖ * ‖EuclideanSpace.single j (1 : ℂ)‖ :=
      ((Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) A).le_opNorm _
    _ = ‖(Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) A‖ := by simp

/-- Elementary finite trace computation for a rank-one corner. -/
theorem amoCyclic_trace_mul_matrixUnit (q : ℕ) (A : Matrix (Fin q) (Fin q) ℂ)
    (i j : Fin q) : Matrix.trace (A * Matrix.stdBasisMatrix i j 1) = A j i := by
  rw [Matrix.trace, Finset.sum_eq_single j]
  · simp
  · intro b _ hbj
    exact Matrix.StdBasisMatrix.mul_right_apply_of_ne 1 i j b b hbj A
  · simp

theorem amoCyclic_trace_mul_corner (n : ℕ)
    (A : Matrix (Fin (n + 1)) (Fin (n + 1)) ℂ) :
    Matrix.trace (A * amoCyclicCorner (n + 1)) = A (Fin.last n) 0 + A 0 (Fin.last n) := by
  rw [amoCyclicCorner, mul_add, Matrix.trace_add,
    amoCyclic_trace_mul_matrixUnit, amoCyclic_trace_mul_matrixUnit]

theorem amoCyclic_norm_trace_mul_corner_le (n : ℕ)
    (A : Matrix (Fin (n + 1)) (Fin (n + 1)) ℂ) :
    ‖Matrix.trace (A * amoCyclicCorner (n + 1))‖ ≤ 2 * ‖A‖ := by
  rw [amoCyclic_trace_mul_corner]
  exact (norm_add_le _ _).trans (by
    have h₁ := amoCyclic_matrix_entry_norm_le (n + 1) A (Fin.last n) 0
    have h₂ := amoCyclic_matrix_entry_norm_le (n + 1) A 0 (Fin.last n)
    linarith)

end CriticalDTM

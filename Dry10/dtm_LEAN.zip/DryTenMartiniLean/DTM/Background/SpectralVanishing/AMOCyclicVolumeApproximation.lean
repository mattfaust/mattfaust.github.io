import DTM.Background.SpectralVanishing.AMOCyclicVolumeLimit

/-!
# Spectral approximation from the proved cyclic weak limit

The hypothesis on the limiting energy is precisely positivity of every open
neighbourhood for the actual magnetic measure. No spectral faithfulness or
weak convergence is postulated: the latter is the preceding theorem, while the
former remains an explicit support hypothesis to be supplied separately.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Topology

/-- A continuous nonnegative bump, positive precisely in the energy ball. -/
def amoCyclicEnergyBump (E epsilon x : ℝ) : ℝ := max 0 (epsilon - |x - E|)

theorem continuous_amoCyclicEnergyBump (E epsilon : ℝ) :
    Continuous (amoCyclicEnergyBump E epsilon) := by
  unfold amoCyclicEnergyBump
  fun_prop

theorem amoCyclicEnergyBump_nonneg (E epsilon x : ℝ) :
    0 ≤ amoCyclicEnergyBump E epsilon x := le_max_left _ _

theorem amoCyclicEnergyBump_norm_le (E x : ℝ) {epsilon : ℝ} (he : 0 < epsilon) :
    ‖amoCyclicEnergyBump E epsilon x‖ ≤ epsilon := by
  rw [Real.norm_eq_abs, abs_of_nonneg (amoCyclicEnergyBump_nonneg E epsilon x)]
  exact max_le he.le (sub_le_self _ (abs_nonneg _))

theorem amoCyclicEnergyBump_integrable (μ : Measure ℝ) [IsFiniteMeasure μ]
    (E : ℝ) {epsilon : ℝ} (he : 0 < epsilon) :
    Integrable (amoCyclicEnergyBump E epsilon) μ :=
  (integrable_const epsilon).mono'
    (continuous_amoCyclicEnergyBump E epsilon).aestronglyMeasurable
    (Eventually.of_forall (fun x => amoCyclicEnergyBump_norm_le E x he))

/-- Positive mass in an open energy ball gives a strictly positive continuous
test; there is no invocation of a totalized undefined integral. -/
theorem amoCyclicEnergyBump_integral_pos (μ : Measure ℝ) [IsFiniteMeasure μ]
    (E : ℝ) {epsilon : ℝ} (he : 0 < epsilon)
    (hμ : 0 < μ (Metric.ball E epsilon)) :
    0 < ∫ x, amoCyclicEnergyBump E epsilon x ∂μ := by
  apply (integral_pos_iff_support_of_nonneg
    (amoCyclicEnergyBump_nonneg E epsilon) (amoCyclicEnergyBump_integrable μ E he)).2
  apply hμ.trans_le
  apply measure_mono
  intro x hx
  apply Function.mem_support.mpr
  have hx' : |x - E| < epsilon := by simpa only [Metric.mem_ball, Real.dist_eq] using hx
  exact ne_of_gt (lt_max_of_lt_right (sub_pos.mpr hx'))

/-- The proved varying-frequency weak limit forces a genuine cyclic eigenvalue
near every energy ball of positive limiting mass, eventually at every length. -/
theorem amoCyclic_eventually_eigenvalue_near (lam E : ℝ)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop)
    {epsilon : ℝ} (he : 0 < epsilon)
    (hμ : 0 < magneticRealSpectralMeasure α lam (Metric.ball E epsilon)) :
    ∀ᶠ j in atTop, ∃ (θ : ℝ) (i : Fin (ns j + 1)),
      |amoCyclicEigenvalues (αs j) lam θ (ns j + 1) i - E| < epsilon := by
  have hpos := amoCyclicEnergyBump_integral_pos (magneticRealSpectralMeasure α lam) E he hμ
  have hlim := tendsto_integral_amoCyclicSpectralMeasure_varying lam
    (amoCyclicEnergyBump E epsilon) (continuous_amoCyclicEnergyBump E epsilon) hα hn
  filter_upwards [hlim.eventually (eventually_gt_nhds hpos)] with j hj
  by_contra hnone
  push_neg at hnone
  have hz (t : ℝ) : (∫ x, amoCyclicEnergyBump E epsilon x
      ∂amoCyclicSpectralMeasure (αs j) lam (2 * Real.pi * t) (ns j)) = 0 := by
    rw [amoCyclicSpectralMeasure_integral]
    have hs : (∑ i : Fin (ns j + 1), amoCyclicEnergyBump E epsilon
        (amoCyclicEigenvalues (αs j) lam (2 * Real.pi * t) (ns j + 1) i)) = 0 := by
      apply Finset.sum_eq_zero
      intro i _
      exact max_eq_left (sub_nonpos.mpr (hnone (2 * Real.pi * t) i))
    rw [hs, mul_zero]
  simp_rw [hz] at hj
  simp at hj

/-- A support energy is approached by unit physical cyclic eigenvectors along
a cofinal selection from any converging frequencies and diverging physical lengths.
Only the displayed neighbourhood-mass hypothesis needs spectral faithfulness. -/
theorem amoCyclic_exists_subsequence_eigenvalues_tendsto (lam E : ℝ)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop)
    (hμ : ∀ epsilon > 0, 0 < magneticRealSpectralMeasure α lam (Metric.ball E epsilon)) :
    ∃ (φ : ℕ → ℕ) (θs Es : ℕ → ℝ),
      Tendsto φ atTop atTop ∧ Tendsto Es atTop (𝓝 E) ∧
      ∀ j, ∃ u : AMOFiniteHilbert (ns (φ j) + 1), ‖u‖ = 1 ∧
        amoCyclicOperator (αs (φ j)) lam (θs j) (ns (φ j) + 1) u = (Es j : ℂ) • u := by
  have hex (m : ℕ) : ∃ j ≥ m, ∃ (θ : ℝ) (i : Fin (ns j + 1)),
      |amoCyclicEigenvalues (αs j) lam θ (ns j + 1) i - E| < 1 / ((m + 1 : ℕ) : ℝ) := by
    have he : (0 : ℝ) < 1 / ((m + 1 : ℕ) : ℝ) := by positivity
    exact ((eventually_ge_atTop m).and
      (amoCyclic_eventually_eigenvalue_near lam E hα hn he (hμ _ he))).exists
  choose φ hφ θs indices his using hex
  refine ⟨φ, θs, (fun j => amoCyclicEigenvalues (αs (φ j)) lam (θs j) (ns (φ j) + 1) (indices j)),
    ?_, ?_, ?_⟩
  · exact tendsto_atTop_mono hφ tendsto_id
  · apply tendsto_iff_norm_sub_tendsto_zero.mpr
    simp only [Real.norm_eq_abs]
    exact squeeze_zero (fun j => abs_nonneg _) (fun j => (his j).le)
      ((tendsto_add_atTop_iff_nat 1).2 (tendsto_const_div_atTop_nhds_zero_nat (1 : ℝ)))
  · intro j
    exact amoCyclicEigenvalues_exists_unit_eigenvector (αs (φ j)) lam (θs j) (ns (φ j) + 1) (indices j)

/-- Physical-cycle form of the spectral approximation: all approximating
operators have length at least three and retain every unit hopping bond. -/
theorem amoCyclic_exists_physical_subsequence_eigenvalues_tendsto (lam E : ℝ)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop)
    (hμ : ∀ epsilon > 0, 0 < magneticRealSpectralMeasure α lam (Metric.ball E epsilon)) :
    ∃ (φ : ℕ → ℕ) (θs Es : ℕ → ℝ),
      Tendsto φ atTop atTop ∧ Tendsto Es atTop (𝓝 E) ∧
      ∀ j, ∃ u : AMOFiniteHilbert (ns (φ j) + 3), ‖u‖ = 1 ∧
        amoCyclicOperator (αs (φ j)) lam (θs j) (ns (φ j) + 3) u = (Es j : ℂ) • u := by
  exact amoCyclic_exists_subsequence_eigenvalues_tendsto lam E hα
    (((tendsto_add_atTop_iff_nat 2).2 tendsto_id).comp hn) hμ

/-- If desired the cofinal selection can be taken to be a genuine strictly
increasing subsequence of the original physical lengths and frequencies. -/
theorem amoCyclic_exists_strict_physical_subsequence (lam E : ℝ)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop)
    (hμ : ∀ epsilon > 0, 0 < magneticRealSpectralMeasure α lam (Metric.ball E epsilon)) :
    ∃ (φ : ℕ → ℕ) (θs Es : ℕ → ℝ),
      StrictMono φ ∧ Tendsto φ atTop atTop ∧ Tendsto Es atTop (𝓝 E) ∧
      ∀ j, ∃ u : AMOFiniteHilbert (ns (φ j) + 3), ‖u‖ = 1 ∧
        amoCyclicOperator (αs (φ j)) lam (θs j) (ns (φ j) + 3) u = (Es j : ℂ) • u := by
  obtain ⟨φ, θs, Es, hφ, hE, hu⟩ :=
    amoCyclic_exists_physical_subsequence_eigenvalues_tendsto lam E hα hn hμ
  obtain ⟨ψ, hψ, hφψ⟩ := strictMono_subseq_of_tendsto_atTop hφ
  exact ⟨φ ∘ ψ, θs ∘ ψ, Es ∘ ψ, hφψ, hφψ.tendsto_atTop,
    hE.comp hψ.tendsto_atTop, fun j => hu (ψ j)⟩

end CriticalDTM

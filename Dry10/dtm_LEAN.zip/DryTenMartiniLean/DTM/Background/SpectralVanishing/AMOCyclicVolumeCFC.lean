import DTM.Background.SpectralVanishing.AMOCyclicVolumeMoments

/-!
# Cyclic continuous spectral tests

Common-window polynomial approximation extends the proved rank-two moment
comparison to the CFC. The target remains the independently constructed
magnetic spectral measure. Every CFC operator here is selfadjoint and every
phase integral is proved integrable.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Topology Polynomial ContinuousFunctionalCalculus

local instance amoCyclicCFCRealAlgebra (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

theorem continuous_amoCyclicTrace_cfc_phase (α lam : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    Continuous (fun θ => amoFiniteTrace n (cfc f (amoCyclicOperator α lam θ (n + 1)))) := by
  rw [continuous_iff_continuousAt]
  intro θ
  exact (amoFiniteTrace n).continuous.continuousAt.comp
    (continuousAt_cfc_of_continuous (fun θ => amoCyclicOperator α lam θ (n + 1)) θ
      (continuous_amoCyclicOperator_phase α lam (n + 1)).continuousAt f hf
      (Eventually.of_forall (fun θ => amoCyclicOperator_isSelfAdjoint α lam θ (n + 1))))

theorem amoCyclicTrace_cfc_intervalIntegrable (α lam : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    IntervalIntegrable (fun t => amoFiniteTrace n
      (cfc f (amoCyclicOperator α lam (2 * Real.pi * t) (n + 1)))) volume (0 : ℝ) 1 :=
  ((continuous_amoCyclicTrace_cfc_phase α lam n f hf).comp
    (continuous_const.mul continuous_id)).intervalIntegrable 0 1

end CriticalDTM

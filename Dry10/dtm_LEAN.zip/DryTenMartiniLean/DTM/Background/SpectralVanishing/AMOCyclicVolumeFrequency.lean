import DTM.Background.SpectralVanishing.AMOCyclicVolumeCFC

/-!
# Frequency continuity from finite physical propagation

The infinite AMO is not asserted to be norm-continuous in frequency. A degree
`k` root moment is instead exactly a middle-coordinate moment in a physical
interval of length `2k+1`, after the actual phase translation. This supplies
frequency continuity of the moments and, with the uniform boundary estimate,
the varying-frequency cyclic moment limit.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Matrix Matrix.L2OpNorm Topology Polynomial ContinuousFunctionalCalculus

/-- Only the finite physical matrices are used for parameter-norm continuity. -/
theorem amoCyclic_continuous_finiteOperator_parameters (lam : ℝ) (q : ℕ) :
    Continuous (fun p : ℝ × ℝ => amoFiniteOperator p.1 lam p.2 q) := by
  have hm : Continuous (fun p : ℝ × ℝ => amoFiniteMatrix p.1 lam p.2 q) := by
    apply continuous_pi
    intro i
    apply continuous_pi
    intro j
    simp_rw [amoFiniteMatrix_entry]
    by_cases hij : i = j <;> simp only [hij, if_true, if_false] <;> fun_prop
  let T := Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)
  let L : Matrix (Fin q) (Fin q) ℂ →ₗ[ℂ] AMOFiniteBoundedOperator q :=
    { toFun := T
      map_add' := T.map_add'
      map_smul' := T.map_smul' }
  have hc : Continuous (fun A : Matrix (Fin q) (Fin q) ℂ => T A) :=
    L.continuous_of_finiteDimensional
  have hh := hc.comp hm
  change Continuous (fun p : ℝ × ℝ =>
    (Matrix.toEuclideanCLM (n := Fin q) (𝕜 := ℂ)) (amoFiniteMatrix p.1 lam p.2 q)) at hh
  simpa only [amoFiniteMatrix_toEuclideanCLM] using hh

/-- A root moment sees exactly the centered physical interval of radius `k`. -/
theorem amoCyclic_rootMoment_eq_center (α lam θ : ℝ) (k : ℕ) :
    amoRootState ((almostMathieuOperator α lam θ) ^ k) =
      amoFiniteCoordinateState (2 * k + 1) ⟨k, by omega⟩
        ((amoFiniteOperator α lam (θ - 2 * Real.pi * α * (k : ℝ)) (2 * k + 1)) ^ k) := by
  rw [amoFiniteCoordinateState_apply,
    amoFiniteOperator_pow_diagonal_interior α lam _ (2 * k + 1) k ⟨k, by omega⟩
      (by simp) (by simp; omega)]
  change amoRootState ((almostMathieuOperator α lam θ) ^ k) =
    amoCoordinateState (k : ℤ)
      ((almostMathieuOperator α lam (θ - 2 * Real.pi * α * (k : ℝ))) ^ k)
  rw [amoCoordinateState_pow_eq_root]
  congr 3
  push_cast
  ring

/-- Frequency and phase continuity of a fixed root moment, without any
incorrect infinite-operator norm-continuity claim. -/
theorem amoCyclic_continuous_rootMoment_parameters (lam : ℝ) (k : ℕ) :
    Continuous (fun p : ℝ × ℝ => amoRootState ((almostMathieuOperator p.1 lam p.2) ^ k)) := by
  simp_rw [amoCyclic_rootMoment_eq_center]
  exact (amoFiniteCoordinateState (2 * k + 1) ⟨k, by omega⟩).continuous.comp
    (((amoCyclic_continuous_finiteOperator_parameters lam (2 * k + 1)).comp
      (continuous_fst.prodMk (continuous_snd.sub
        ((continuous_const.mul continuous_fst).mul continuous_const)))).pow k)

set_option maxHeartbeats 800000 in
/-- The genuine magnetic root moments are continuous along convergent
frequencies, proved through the finite centered AMO identity and phase average. -/
theorem amoCyclic_tendsto_rootTrace_pow_frequency (lam : ℝ) (k : ℕ)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α)) :
    Tendsto (fun j => rootTrace ((hOperator (αs j) (lam : ℂ)) ^ k)) atTop
      (𝓝 (rootTrace ((hOperator α (lam : ℂ)) ^ k))) := by
  simp_rw [← integral_amoRootState_pow,
    intervalIntegral.integral_of_le (show (0 : ℝ) ≤ 1 by norm_num)]
  apply tendsto_integral_of_dominated_convergence (fun _ : ℝ => (2 + 2 * |lam|) ^ k)
  · intro j
    exact (amoRootState.continuous.comp
      (((continuous_almostMathieuOperator_phase (αs j) lam).comp
        (continuous_const.mul continuous_id)).pow k)).aestronglyMeasurable
  · exact integrable_const _
  · intro j
    apply Eventually.of_forall
    intro t
    exact (norm_amoRootState_le _).trans ((norm_pow_le _ k).trans
      (pow_le_pow_left₀ (norm_nonneg _) (almostMathieuOperator_norm_le (αs j) lam _) k))
  · apply Eventually.of_forall
    intro t
    have hp : Tendsto (fun j => (αs j, 2 * Real.pi * t)) atTop (𝓝 (α, 2 * Real.pi * t)) :=
      hα.prodMk_nhds tendsto_const_nhds
    have ht := ((amoCyclic_continuous_rootMoment_parameters lam k).tendsto (α, 2 * Real.pi * t)).comp hp
    simpa only [Function.comp_apply] using ht

/-- The existing physical Dirichlet bulk comparison, with its uniform error
exposed independently of the fixed-frequency limit theorem. -/
theorem amoCyclic_norm_integral_dirichlet_pow_sub_root_le (α lam : ℝ) (n k : ℕ) :
    ‖(∫ t in (0 : ℝ)..1,
      amoFiniteTrace n ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) -
        rootTrace ((hOperator α (lam : ℂ)) ^ k)‖ ≤
      (4 * (k : ℝ) * (2 + 2 * |lam|) ^ k) / ((n + 1 : ℕ) : ℝ) := by
  have hbulk : (∫ t in (0 : ℝ)..1, ((n + 1 : ℕ) : ℂ)⁻¹ *
      ∑ i : Fin (n + 1), amoCoordinateState (i.val : ℤ)
        ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)) =
      rootTrace ((hOperator α (lam : ℂ)) ^ k) := by
    rw [intervalIntegral.integral_const_mul, intervalIntegral.integral_finset_sum]
    · simp only [integral_amoCoordinateState_pow, Finset.sum_const, Finset.card_univ,
        Fintype.card_fin, nsmul_eq_mul]
      rw [← mul_assoc, inv_mul_cancel₀ (Nat.cast_ne_zero.mpr (Nat.succ_ne_zero n)), one_mul]
    · intro i _
      exact amoCoordinateState_pow_intervalIntegrable α lam _ k
  have hbulki : IntervalIntegrable (fun t => ((n + 1 : ℕ) : ℂ)⁻¹ *
      ∑ i : Fin (n + 1), amoCoordinateState (i.val : ℤ)
        ((almostMathieuOperator α lam (2 * Real.pi * t)) ^ k)) volume (0 : ℝ) 1 := by
    simpa only [Finset.sum_apply] using
      ((IntervalIntegrable.sum Finset.univ (fun (i : Fin (n + 1)) _ =>
        amoCoordinateState_pow_intervalIntegrable α lam (i.val : ℤ) k)).const_mul
          (((n + 1 : ℕ) : ℂ)⁻¹))
  rw [← hbulk, ← intervalIntegral.integral_sub
    (amoFiniteTrace_pow_intervalIntegrable α lam n k) hbulki]
  simpa using intervalIntegral.norm_integral_le_of_norm_le_const (a := (0 : ℝ)) (b := 1)
    (fun t _ => norm_amoFiniteTrace_pow_sub_bulk_le α lam (2 * Real.pi * t) n k)

/-- Uniform cyclic error against the actual infinite magnetic moment. -/
theorem amoCyclic_norm_integral_pow_sub_root_le (α lam : ℝ) (n k : ℕ) :
    ‖(∫ t in (0 : ℝ)..1,
      amoFiniteTrace n ((amoCyclicOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) -
        rootTrace ((hOperator α (lam : ℂ)) ^ k)‖ ≤
      (2 * (k : ℝ) * (4 + 2 * |lam|) ^ (k - 1) +
        4 * (k : ℝ) * (2 + 2 * |lam|) ^ k) / ((n + 1 : ℕ) : ℝ) := by
  calc
    _ ≤ ‖(∫ t in (0 : ℝ)..1, amoFiniteTrace n
          ((amoCyclicOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) -
        (∫ t in (0 : ℝ)..1, amoFiniteTrace n
          ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k))‖ +
        ‖(∫ t in (0 : ℝ)..1, amoFiniteTrace n
          ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) -
          rootTrace ((hOperator α (lam : ℂ)) ^ k)‖ :=
      norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ _ := by
      rw [add_div]
      exact add_le_add (norm_integral_amoCyclicTrace_pow_sub_le α lam n k)
        (amoCyclic_norm_integral_dirichlet_pow_sub_root_le α lam n k)

/-- Frequencies may vary and lengths may grow along any sequence. This is a
proved weak-moment limit, not a spectral-continuity assumption. -/
theorem tendsto_integral_amoCyclicTrace_pow_varying (lam : ℝ) (k : ℕ)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop) :
    Tendsto (fun j => ∫ t in (0 : ℝ)..1,
      amoFiniteTrace (ns j) ((amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) ^ k)) atTop
        (𝓝 (rootTrace ((hOperator α (lam : ℂ)) ^ k))) := by
  have herr : Tendsto (fun j => (∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
        ((amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) ^ k)) -
      rootTrace ((hOperator (αs j) (lam : ℂ)) ^ k)) atTop (𝓝 0) := by
    rw [tendsto_zero_iff_norm_tendsto_zero]
    exact squeeze_zero (fun j => norm_nonneg _)
      (fun j => amoCyclic_norm_integral_pow_sub_root_le (αs j) lam (ns j) k)
      (((tendsto_add_atTop_iff_nat 1).2 (tendsto_const_div_atTop_nhds_zero_nat
        (2 * (k : ℝ) * (4 + 2 * |lam|) ^ (k - 1) + 4 * (k : ℝ) * (2 + 2 * |lam|) ^ k))).comp hn)
  simpa only [sub_add_cancel, zero_add] using
    herr.add (amoCyclic_tendsto_rootTrace_pow_frequency lam k hα)

end CriticalDTM

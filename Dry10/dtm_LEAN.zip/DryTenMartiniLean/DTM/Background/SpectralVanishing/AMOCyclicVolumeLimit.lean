import DTM.Background.SpectralVanishing.AMOCyclicVolumeFrequency
import DTM.Background.SpectralVanishing.AMOCyclicVolumeMeasure

/-!
# Varying-frequency cyclic spectral-test convergence

Both the frequencies and the finite lengths may vary. The conclusion follows
from the proved finite-propagation moment continuity and the uniform physical
rank-two boundary estimate, followed by common-window polynomial approximation.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Topology Polynomial ContinuousFunctionalCalculus

local instance amoCyclicLimitRealAlgebra (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

theorem tendsto_integral_amoCyclicTrace_aeval_varying (lam : ℝ) (p : ℝ[X])
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop) :
    Tendsto (fun j => ∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
      (Polynomial.aeval (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) p)) atTop
        (𝓝 (rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p))) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
    simp only [map_add]
    simp_rw [intervalIntegral.integral_add
      (amoCyclicTrace_aeval_intervalIntegrable _ lam _ p)
      (amoCyclicTrace_aeval_intervalIntegrable _ lam _ q)]
    exact hp.add hq
  | monomial k c =>
    simp only [Polynomial.aeval_monomial, Algebra.algebraMap_eq_smul_one,
      smul_mul_assoc, one_mul, Complex.coe_smul, map_smul, smul_eq_mul]
    simp only [ContinuousLinearMap.map_smul_of_tower, intervalIntegral.integral_smul]
    exact (tendsto_integral_amoCyclicTrace_pow_varying lam k hα hn).const_smul c

set_option maxHeartbeats 800000 in
set_option synthInstance.maxHeartbeats 80000 in
/-- Actual finite cyclic normalized CFC traces converge, after phase average,
to the same continuous test of the pre-existing magnetic Hamiltonian. -/
theorem tendsto_integral_amoCyclicTrace_cfc_varying (lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop) :
    Tendsto (fun j => ∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
      (cfc f (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)))) atTop
        (𝓝 (rootTrace (cfc f (hOperator α (lam : ℂ))))) := by
  apply Metric.tendsto_nhds.mpr
  intro epsilon hepsilon
  have hepsilon3 : 0 < epsilon / 3 := by linarith
  let K : Set ℝ := Icc (-(4 + 2 * |lam|)) (4 + 2 * |lam|)
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K isCompact_Icc
    f hf.continuousOn (epsilon / 3) hepsilon3
  have hmag : ‖cfc f (hOperator α (lam : ℂ)) -
      Polynomial.aeval (hOperator α (lam : ℂ)) p‖ < epsilon / 3 := by
    apply norm_cfc_sub_polynomial_lt f K hf.continuousOn p (epsilon / 3) hepsilon3 hp
      _ (hOperator_isSelfAdjoint α lam)
    exact real_spectrum_subset_Icc_of_norm_le _ (by
      have h := hOperator_norm_le α (lam : ℂ)
      simp only [Complex.norm_real, Real.norm_eq_abs] at h
      linarith)
  have hfinite (j : ℕ) (t : ℝ) :
      ‖cfc f (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) -
        Polynomial.aeval (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) p‖ <
          epsilon / 3 := by
    apply norm_cfc_sub_polynomial_lt (A := AMOFiniteBoundedOperator (ns j + 1))
      f K hf.continuousOn p (epsilon / 3) hepsilon3 hp
      _ (amoCyclicOperator_isSelfAdjoint (αs j) lam _ (ns j + 1))
    exact real_spectrum_subset_Icc_of_norm_le _ (amoCyclicOperator_norm_le (αs j) lam _ (ns j + 1))
  have hmean (j : ℕ) :
      ‖(∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
          (cfc f (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)))) -
        (∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
          (Polynomial.aeval (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) p))‖ ≤
            epsilon / 3 := by
    rw [← intervalIntegral.integral_sub (amoCyclicTrace_cfc_intervalIntegrable (αs j) lam (ns j) f hf)
      (amoCyclicTrace_aeval_intervalIntegrable (αs j) lam (ns j) p)]
    have h := intervalIntegral.norm_integral_le_of_norm_le_const (a := (0 : ℝ)) (b := 1)
      (f := fun t => amoFiniteTrace (ns j)
          (cfc f (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1))) -
        amoFiniteTrace (ns j) (Polynomial.aeval
          (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) p))
      (C := epsilon / 3) (fun t _ => by
        dsimp only
        rw [← map_sub]
        exact (norm_amoFiniteTrace_le (ns j) _).trans (hfinite j t).le)
    simpa using h
  have hroot : ‖rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p) -
      rootTrace (cfc f (hOperator α (lam : ℂ)))‖ ≤ epsilon / 3 := by
    rw [norm_sub_rev, ← map_sub]
    exact (norm_rootTrace_le _).trans hmag.le
  filter_upwards [Metric.tendsto_nhds.mp
    (tendsto_integral_amoCyclicTrace_aeval_varying lam p hα hn) (epsilon / 3) hepsilon3] with j hn
  rw [dist_eq_norm] at hn ⊢
  have htriangle := norm_sub_le_norm_sub_add_norm_sub
    (∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
      (cfc f (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1))))
    (∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
      (Polynomial.aeval (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) p))
    (rootTrace (cfc f (hOperator α (lam : ℂ))))
  have htriangle' := norm_sub_le_norm_sub_add_norm_sub
    (∫ t in (0 : ℝ)..1, amoFiniteTrace (ns j)
      (Polynomial.aeval (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)) p))
    (rootTrace (Polynomial.aeval (hOperator α (lam : ℂ)) p))
    (rootTrace (cfc f (hOperator α (lam : ℂ))))
  linarith [hmean j]

/-- The target is the integral against the actual measure constructed earlier,
not a newly named finite density of states. -/
theorem tendsto_integral_amoCyclicTraceReal_cfc_varying (lam : ℝ) (f : ℝ → ℝ) (hf : Continuous f)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop) :
    Tendsto (fun j => ∫ t in (0 : ℝ)..1, amoFiniteTraceReal (ns j)
      (cfc f (amoCyclicOperator (αs j) lam (2 * Real.pi * t) (ns j + 1)))) atTop
        (𝓝 (∫ x, f x ∂magneticRealSpectralMeasure α lam)) := by
  have htarget : (rootTrace (cfc f (hOperator α (lam : ℂ)))).re =
      ∫ x, f x ∂magneticRealSpectralMeasure α lam := by
    rw [magneticRealSpectralMeasure_integral_eq_phase_average α lam f hf]
    simp_rw [amoRealSpectralMeasure_integral_cfc α lam _ f hf]
    exact (integral_amoRootStateReal_cfc α lam f hf).symm
  have h := Complex.continuous_re.continuousAt.tendsto.comp
    (tendsto_integral_amoCyclicTrace_cfc_varying lam f hf hα hn)
  rw [htarget] at h
  convert h using 1
  funext j
  exact Complex.reCLM.intervalIntegral_comp_comm
    (amoCyclicTrace_cfc_intervalIntegrable (αs j) lam (ns j) f hf)

/-- Weak continuous-test convergence of the independently constructed actual
cyclic empirical probabilities, with frequency and length both varying. -/
theorem tendsto_integral_amoCyclicSpectralMeasure_varying (lam : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f)
    {αs : ℕ → ℝ} {α : ℝ} (hα : Tendsto αs atTop (𝓝 α))
    {ns : ℕ → ℕ} (hn : Tendsto ns atTop atTop) :
    Tendsto (fun j => ∫ t in (0 : ℝ)..1,
      ∫ x, f x ∂amoCyclicSpectralMeasure (αs j) lam (2 * Real.pi * t) (ns j)) atTop
        (𝓝 (∫ x, f x ∂magneticRealSpectralMeasure α lam)) := by
  simp_rw [amoCyclicSpectralMeasure_integral_cfc _ lam _ _ f hf]
  exact tendsto_integral_amoCyclicTraceReal_cfc_varying lam f hf hα hn

end CriticalDTM

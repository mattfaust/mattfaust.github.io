import DTM.Background.SpectralVanishing.AMOCyclicVolumeCFC
import DTM.Background.SpectralVanishing.AMOCyclicVolumeSpectrum

/-!
# Actual cyclic empirical spectral measures

The empirical probability is defined independently, by the genuine Hermitian
cyclic eigenvalues counted with multiplicities. Its CFC identity is proved by
finite diagonalization and polynomial approximation.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Set Filter
open scoped Matrix ENNReal Polynomial ContinuousFunctionalCalculus Topology

local instance amoCyclicMeasureRealAlgebra (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

theorem amoCyclicTrace_pow_eq_eigenvalues (α lam θ : ℝ) (n k : ℕ) :
    amoFiniteTrace n ((amoCyclicOperator α lam θ (n + 1)) ^ k) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (((amoCyclicEigenvalues α lam θ (n + 1) i) ^ k : ℝ) : ℂ) := by
  rw [← amoCyclicMatrix_toEuclideanCLM α lam θ (n + 1), ← map_pow,
    amoFiniteTrace_toEuclideanCLM, amoCyclicMatrix_trace_pow]
  simp only [Complex.ofReal_pow]

theorem amoCyclicTrace_aeval_eq_eigenvalues (α lam θ : ℝ) (n : ℕ) (p : ℝ[X]) :
    amoFiniteTrace n (Polynomial.aeval (amoCyclicOperator α lam θ (n + 1)) p) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        ((p.eval (amoCyclicEigenvalues α lam θ (n + 1) i) : ℝ) : ℂ) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
    simp only [map_add, Polynomial.eval_add, Complex.ofReal_add,
      Finset.sum_add_distrib, mul_add, hp, hq]
  | monomial k c =>
    simp only [Polynomial.aeval_monomial, Algebra.algebraMap_eq_smul_one,
      smul_mul_assoc, one_mul, ContinuousLinearMap.map_smul_of_tower,
      Polynomial.eval_monomial, Complex.ofReal_mul, Complex.ofReal_pow]
    rw [amoCyclicTrace_pow_eq_eigenvalues, ← Complex.coe_smul]
    simp only [smul_eq_mul, Complex.ofReal_pow, ← Finset.mul_sum]
    ring

set_option maxHeartbeats 800000 in
set_option synthInstance.maxHeartbeats 80000 in
/-- The finite CFC trace is exactly the empirical eigenvalue test. This is
proved from actual matrix diagonalization and common-window approximation. -/
theorem amoCyclicTrace_cfc_eq_eigenvalues (α lam θ : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    amoFiniteTrace n (cfc f (amoCyclicOperator α lam θ (n + 1))) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (f (amoCyclicEigenvalues α lam θ (n + 1) i) : ℂ) := by
  apply sub_eq_zero.mp
  apply norm_eq_zero.mp
  apply le_antisymm _ (norm_nonneg _)
  apply le_of_forall_pos_le_add
  intro epsilon hepsilon
  have hepsilon2 : 0 < epsilon / 2 := by linarith
  let K : Set ℝ := Icc (-(4 + 2 * |lam|)) (4 + 2 * |lam|)
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K isCompact_Icc
    f hf.continuousOn (epsilon / 2) hepsilon2
  have hop : ‖cfc f (amoCyclicOperator α lam θ (n + 1)) -
      Polynomial.aeval (amoCyclicOperator α lam θ (n + 1)) p‖ < epsilon / 2 := by
    apply norm_cfc_sub_polynomial_lt (A := AMOFiniteBoundedOperator (n + 1))
      f K hf.continuousOn p (epsilon / 2) hepsilon2 hp _
      (amoCyclicOperator_isSelfAdjoint α lam θ (n + 1))
    exact real_spectrum_subset_Icc_of_norm_le _ (amoCyclicOperator_norm_le α lam θ (n + 1))
  have htrace : ‖amoFiniteTrace n (cfc f (amoCyclicOperator α lam θ (n + 1))) -
      amoFiniteTrace n (Polynomial.aeval (amoCyclicOperator α lam θ (n + 1)) p)‖ ≤ epsilon / 2 := by
    rw [← map_sub]
    exact (norm_amoFiniteTrace_le n _).trans hop.le
  have heig : ‖amoFiniteTrace n (Polynomial.aeval (amoCyclicOperator α lam θ (n + 1)) p) -
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (f (amoCyclicEigenvalues α lam θ (n + 1) i) : ℂ)‖ ≤ epsilon / 2 := by
    rw [amoCyclicTrace_aeval_eq_eigenvalues, ← mul_sub, ← Finset.sum_sub_distrib]
    apply amoFinite_mean_norm_le
    intro i
    rw [← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs, abs_sub_comm]
    exact (hp _ (amoCyclicEigenvalues_mem_window α lam θ (n + 1) i)).le
  have htri := norm_sub_le_norm_sub_add_norm_sub
    (amoFiniteTrace n (cfc f (amoCyclicOperator α lam θ (n + 1))))
    (amoFiniteTrace n (Polynomial.aeval (amoCyclicOperator α lam θ (n + 1)) p))
    (((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
      (f (amoCyclicEigenvalues α lam θ (n + 1) i) : ℂ))
  linarith

/-- The independently constructed finite-volume empirical probability measure,
with eigenvalues repeated according to their true multiplicity. -/
def amoCyclicSpectralMeasure (α lam θ : ℝ) (n : ℕ) : Measure ℝ :=
  ((n + 1 : ℕ) : ℝ≥0∞)⁻¹ • ∑ i : Fin (n + 1),
    Measure.dirac (amoCyclicEigenvalues α lam θ (n + 1) i)

theorem amoCyclicSpectralMeasure_integral (α lam θ : ℝ) (n : ℕ) (f : ℝ → ℝ) :
    ∫ x, f x ∂amoCyclicSpectralMeasure α lam θ n =
      ((n + 1 : ℕ) : ℝ)⁻¹ * ∑ i : Fin (n + 1), f (amoCyclicEigenvalues α lam θ (n + 1) i) := by
  rw [amoCyclicSpectralMeasure, integral_smul_measure,
    integral_finset_sum_measure (fun _ _ => integrable_dirac)]
  simp only [integral_dirac, ENNReal.toReal_inv, ENNReal.toReal_natCast, smul_eq_mul]

theorem amoCyclicSpectralMeasure_integral_cfc (α lam θ : ℝ) (n : ℕ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂amoCyclicSpectralMeasure α lam θ n =
      amoFiniteTraceReal n (cfc f (amoCyclicOperator α lam θ (n + 1))) := by
  rw [amoCyclicSpectralMeasure_integral, amoFiniteTraceReal_apply,
    amoCyclicTrace_cfc_eq_eigenvalues α lam θ n f hf]
  have hcast : (((((n + 1 : ℕ) : ℝ)⁻¹ *
      ∑ i : Fin (n + 1), f (amoCyclicEigenvalues α lam θ (n + 1) i)) : ℝ) : ℂ) =
      ((n + 1 : ℕ) : ℂ)⁻¹ * ∑ i : Fin (n + 1),
        (f (amoCyclicEigenvalues α lam θ (n + 1) i) : ℂ) := by
    push_cast
    rfl
  simpa only [Complex.ofReal_re] using congrArg Complex.re hcast

end CriticalDTM

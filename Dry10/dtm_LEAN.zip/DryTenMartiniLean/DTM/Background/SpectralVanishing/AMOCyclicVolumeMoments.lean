import DTM.Background.SpectralVanishing.AMOCyclicVolume
import DTM.Background.EmpiricalIDS.AMOFiniteVolumeMeasure

/-!
# The rank-two periodic-boundary error

The noncommutative telescoping identity and elementary finite trace cyclicity
move the restored bond to the end of every summand. Each trace is then just two
physical matrix entries. No estimate proportional to the finite dimension is
used before normalizing the trace.
-/

noncomputable section
namespace CriticalDTM

open MeasureTheory Filter Set
open scoped Matrix Matrix.L2OpNorm Topology Polynomial ContinuousFunctionalCalculus

local instance amoCyclicMomentsRealAlgebra (n : ℕ) : Algebra ℝ (AMOFiniteBoundedOperator n) :=
  (inferInstance : Algebra ℂ (AMOFiniteBoundedOperator n)).complexToReal

/-- Explicit noncommutative telescoping; no commutation of the two matrices. -/
theorem amoCyclic_pow_sub_pow {R : Type*} [Ring R] (A B : R) (k : ℕ) :
    A ^ k - B ^ k = ∑ i ∈ Finset.range k, B ^ i * (A - B) * A ^ (k - 1 - i) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Finset.sum_range_succ']
    have hs : (∑ i ∈ Finset.range k,
        B ^ (i + 1) * (A - B) * A ^ (k + 1 - 1 - (i + 1))) =
        B * ∑ i ∈ Finset.range k, B ^ i * (A - B) * A ^ (k - 1 - i) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      rw [show k + 1 - 1 - (i + 1) = k - 1 - i by omega, pow_succ']
      simp only [mul_assoc]
    rw [hs, ← ih]
    simp only [pow_zero, one_mul, Nat.add_sub_cancel, Nat.sub_zero]
    rw [pow_succ' A, pow_succ' B]
    noncomm_ring

/-- Unnormalized trace error: exactly two entries per telescoping summand. -/
theorem norm_amoCyclicMatrix_trace_pow_sub_le (α lam θ : ℝ) (n k : ℕ) :
    ‖Matrix.trace ((amoCyclicMatrix α lam θ (n + 1)) ^ k) -
      Matrix.trace ((amoFiniteMatrix α lam θ (n + 1)) ^ k)‖ ≤
        2 * (k : ℝ) * (4 + 2 * |lam|) ^ (k - 1) := by
  let C := amoCyclicMatrix α lam θ (n + 1)
  let D := amoFiniteMatrix α lam θ (n + 1)
  let M : ℝ := 4 + 2 * |lam|
  have hM : 0 ≤ M := by dsimp [M]; positivity
  have hC : ‖C‖ ≤ M := amoCyclicMatrix_norm_le α lam θ (n + 1)
  have hD : ‖D‖ ≤ M := (amoFiniteMatrix_norm_le α lam θ (n + 1)).trans (by dsimp [M]; linarith)
  have hCD : C - D = amoCyclicCorner (n + 1) := by dsimp [C, D, amoCyclicMatrix]; abel
  change ‖Matrix.trace (C ^ k) - Matrix.trace (D ^ k)‖ ≤ 2 * (k : ℝ) * M ^ (k - 1)
  rw [← Matrix.trace_sub, amoCyclic_pow_sub_pow, Matrix.trace_sum]
  calc
    _ ≤ ∑ i ∈ Finset.range k,
        ‖Matrix.trace (D ^ i * (C - D) * C ^ (k - 1 - i))‖ := norm_sum_le _ _
    _ ≤ ∑ _i ∈ Finset.range k, 2 * M ^ (k - 1) := by
      apply Finset.sum_le_sum
      intro i hi
      rw [hCD, Matrix.trace_mul_cycle]
      calc
        _ ≤ 2 * ‖C ^ (k - 1 - i) * D ^ i‖ := amoCyclic_norm_trace_mul_corner_le n _
        _ ≤ 2 * (M ^ (k - 1 - i) * M ^ i) := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact (norm_mul_le _ _).trans (mul_le_mul
            ((norm_pow_le _ _).trans (pow_le_pow_left₀ (norm_nonneg _) hC _))
            ((norm_pow_le _ _).trans (pow_le_pow_left₀ (norm_nonneg _) hD _))
            (norm_nonneg _) (pow_nonneg hM _))
        _ = 2 * M ^ (k - 1) := by
          rw [← pow_add]
          congr 2
          have := Finset.mem_range.mp hi
          omega
    _ = _ := by simp; ring

/-- The actual normalized cyclic and Dirichlet power traces differ by at most
`2 k M^(k-1) / q`, uniformly in frequency and phase. -/
theorem norm_amoCyclicTrace_pow_sub_le (α lam θ : ℝ) (n k : ℕ) :
    ‖amoFiniteTrace n ((amoCyclicOperator α lam θ (n + 1)) ^ k) -
      amoFiniteTrace n ((amoFiniteOperator α lam θ (n + 1)) ^ k)‖ ≤
        (2 * (k : ℝ) * (4 + 2 * |lam|) ^ (k - 1)) / ((n + 1 : ℕ) : ℝ) := by
  rw [← amoCyclicMatrix_toEuclideanCLM, ← amoFiniteMatrix_toEuclideanCLM,
    ← map_pow, ← map_pow, amoFiniteTrace_toEuclideanCLM, amoFiniteTrace_toEuclideanCLM,
    ← mul_sub, norm_mul, norm_inv, Complex.norm_natCast]
  calc
    _ ≤ ((n + 1 : ℕ) : ℝ)⁻¹ * (2 * (k : ℝ) * (4 + 2 * |lam|) ^ (k - 1)) :=
      mul_le_mul_of_nonneg_left (norm_amoCyclicMatrix_trace_pow_sub_le α lam θ n k) (by positivity)
    _ = _ := by rw [div_eq_mul_inv, mul_comm]

theorem amoCyclicTrace_pow_intervalIntegrable (α lam : ℝ) (n k : ℕ) :
    IntervalIntegrable (fun t => amoFiniteTrace n
      ((amoCyclicOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) volume (0 : ℝ) 1 :=
  ((amoFiniteTrace n).continuous.comp
    (((continuous_amoCyclicOperator_phase α lam (n + 1)).comp
      (continuous_const.mul continuous_id)).pow k)).intervalIntegrable 0 1

/-- Integrated boundary error, retaining uniformity in frequency. -/
theorem norm_integral_amoCyclicTrace_pow_sub_le (α lam : ℝ) (n k : ℕ) :
    ‖(∫ t in (0 : ℝ)..1, amoFiniteTrace n
        ((amoCyclicOperator α lam (2 * Real.pi * t) (n + 1)) ^ k)) -
      (∫ t in (0 : ℝ)..1, amoFiniteTrace n
        ((amoFiniteOperator α lam (2 * Real.pi * t) (n + 1)) ^ k))‖ ≤
        (2 * (k : ℝ) * (4 + 2 * |lam|) ^ (k - 1)) / ((n + 1 : ℕ) : ℝ) := by
  rw [← intervalIntegral.integral_sub (amoCyclicTrace_pow_intervalIntegrable α lam n k)
    (amoFiniteTrace_pow_intervalIntegrable α lam n k)]
  simpa using intervalIntegral.norm_integral_le_of_norm_le_const (a := (0 : ℝ)) (b := 1)
    (fun t _ => norm_amoCyclicTrace_pow_sub_le α lam (2 * Real.pi * t) n k)

theorem amoCyclicTrace_aeval_intervalIntegrable (α lam : ℝ) (n : ℕ) (p : ℝ[X]) :
    IntervalIntegrable (fun t => amoFiniteTrace n
      (Polynomial.aeval (amoCyclicOperator α lam (2 * Real.pi * t) (n + 1)) p))
      volume (0 : ℝ) 1 :=
  ((amoFiniteTrace n).continuous.comp
    (p.continuous_aeval.comp ((continuous_amoCyclicOperator_phase α lam (n + 1)).comp
      (continuous_const.mul continuous_id)))).intervalIntegrable 0 1

end CriticalDTM

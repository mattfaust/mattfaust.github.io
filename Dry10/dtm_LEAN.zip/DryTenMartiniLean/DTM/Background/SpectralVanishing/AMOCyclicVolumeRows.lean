import DTM.Background.SpectralVanishing.AMOCyclicVolume

/-! # Physical cyclic receiving rows -/

noncomputable section
namespace CriticalDTM

/-- The physical next site, wrapping exactly at the last endpoint. -/
def amoCyclicNext (n : ℕ) (i : Fin (n + 3)) : Fin (n + 3) :=
  if h : i.val + 1 < n + 3 then ⟨i.val + 1, h⟩ else 0

/-- The physical previous site, wrapping exactly at the first endpoint. -/
def amoCyclicPrev (n : ℕ) (i : Fin (n + 3)) : Fin (n + 3) :=
  if h : 0 < i.val then ⟨i.val - 1, by have := i.isLt; omega⟩ else Fin.last (n + 2)

@[simp] theorem amoCyclicNext_val (n : ℕ) (i : Fin (n + 3)) :
    (amoCyclicNext n i).val = (i.val + 1) % (n + 3) := by
  unfold amoCyclicNext
  split_ifs with h
  · exact (Nat.mod_eq_of_lt h).symm
  · have he : i.val + 1 = n + 3 := by have := i.isLt; omega
    simp [he]

@[simp] theorem amoCyclicPrev_val (n : ℕ) (i : Fin (n + 3)) :
    (amoCyclicPrev n i).val = (i.val + (n + 3) - 1) % (n + 3) := by
  unfold amoCyclicPrev
  split_ifs with h
  · have he : i.val + (n + 3) - 1 = i.val - 1 + (n + 3) := by omega
    rw [he, Nat.add_mod_right, Nat.mod_eq_of_lt (by have := i.isLt; omega)]
  · have he : i.val = 0 := by omega
    simp [he, Nat.mod_eq_of_lt (show n + 2 < n + 3 by omega)]

/-- Exact unit-hopping cyclic row, valid on every site, including both restored
endpoints. The only diagonal term is the original AMO potential. -/
theorem amoCyclicOperator_apply (α lam θ : ℝ) (n : ℕ)
    (u : AMOFiniteHilbert (n + 3)) (i : Fin (n + 3)) :
    amoCyclicOperator α lam θ (n + 3) u i =
      u (amoCyclicNext n i) + u (amoCyclicPrev n i) +
      ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + θ) : ℝ) : ℂ) * u i := by
  have hrow := amoCyclicOperator_apply_corner α lam θ (n + 2) u i
  have hnxt : amoFiniteExtend (n + 3) u ((i.val : ℤ) + 1) +
      (if i = Fin.last (n + 2) then u 0 else 0) = u (amoCyclicNext n i) := by
    by_cases h : i.val + 1 < n + 3
    · rw [show amoCyclicNext n i = ⟨i.val + 1, h⟩ from dif_pos h]
      have hilast : i ≠ Fin.last (n + 2) := by intro he; have := congrArg Fin.val he; simp at this; omega
      rw [if_neg hilast]
      have he : (i.val : ℤ) + 1 = ((⟨i.val + 1, h⟩ : Fin (n + 3)).val : ℤ) := by simp
      rw [he, amoFiniteExtend_apply_site, add_zero]
    · rw [show amoCyclicNext n i = 0 from dif_neg h]
      have hilast : i = Fin.last (n + 2) := by apply Fin.ext; simp; have := i.isLt; omega
      rw [if_pos hilast, amoFiniteExtend_apply_outside _ _ _ (Or.inr (by have := i.isLt; omega)), zero_add]
  have hprv : amoFiniteExtend (n + 3) u ((i.val : ℤ) - 1) +
      (if i = 0 then u (Fin.last (n + 2)) else 0) = u (amoCyclicPrev n i) := by
    by_cases h : 0 < i.val
    · rw [show amoCyclicPrev n i = ⟨i.val - 1, by have := i.isLt; omega⟩ from dif_pos h]
      have hi0 : i ≠ 0 := by intro he; have hh : i.val = 0 := congrArg Fin.val he; omega
      rw [if_neg hi0]
      have he : (i.val : ℤ) - 1 = ((⟨i.val - 1, by have := i.isLt; omega⟩ : Fin (n + 3)).val : ℤ) := by
        simp only
        omega
      rw [he, amoFiniteExtend_apply_site, add_zero]
    · rw [show amoCyclicPrev n i = Fin.last (n + 2) from dif_neg h]
      have hi0 : i = 0 := by apply Fin.ext; change i.val = 0; omega
      rw [if_pos hi0, amoFiniteExtend_apply_outside _ _ _ (Or.inl (by have := i.isLt; omega)), zero_add]
  rw [hrow, ← hnxt, ← hprv]
  abel

end CriticalDTM

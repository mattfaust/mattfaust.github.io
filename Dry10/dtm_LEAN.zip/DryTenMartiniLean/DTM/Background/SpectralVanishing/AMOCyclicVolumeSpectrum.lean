import DTM.Background.SpectralVanishing.AMOCyclicVolume
import DTM.Background.EmpiricalIDS.AMOFiniteVolumeSpectrum

/-! # The actual cyclic eigenvalues, with multiplicities -/

noncomputable section
namespace CriticalDTM

open Set
open scoped Matrix Matrix.L2OpNorm

/-- The real eigenvalues, counted with multiplicity, of the actual cyclic
matrix on the physical sites `0,...,n-1`. -/
def amoCyclicEigenvalues (α lam θ : ℝ) (n : ℕ) : Fin n → ℝ :=
  (amoCyclicMatrix_isHermitian α lam θ n).eigenvalues

theorem amoCyclicEigenvalues_mem_window (α lam θ : ℝ) (n : ℕ) (i : Fin n) :
    amoCyclicEigenvalues α lam θ n i ∈ Icc (-(4 + 2 * |lam|)) (4 + 2 * |lam|) := by
  letI : Nonempty (Fin n) := ⟨i⟩
  have hnorm : ‖amoCyclicEigenvalues α lam θ n i‖ ≤ ‖amoCyclicMatrix α lam θ n‖ :=
    spectrum.norm_le_norm_of_mem
      ((amoCyclicMatrix_isHermitian α lam θ n).eigenvalues_mem_spectrum_real i)
  exact abs_le.mp (hnorm.trans (amoCyclicMatrix_norm_le α lam θ n))

/-- Finite Hermitian diagonalization identifies every actual matrix moment
with the sum of the corresponding eigenvalue moments. -/
theorem amoCyclicMatrix_trace_pow (α lam θ : ℝ) (n k : ℕ) :
    Matrix.trace ((amoCyclicMatrix α lam θ n) ^ k) =
      ∑ i : Fin n, (amoCyclicEigenvalues α lam θ n i : ℂ) ^ k := by
  let hM := amoCyclicMatrix_isHermitian α lam θ n
  let U : (Matrix (Fin n) (Fin n) ℂ)ˣ := unitary.toUnits hM.eigenvectorUnitary
  have hdiag : amoCyclicMatrix α lam θ n =
      (U : Matrix (Fin n) (Fin n) ℂ) *
        Matrix.diagonal (fun i => (amoCyclicEigenvalues α lam θ n i : ℂ)) *
          (↑U⁻¹ : Matrix (Fin n) (Fin n) ℂ) := hM.spectral_theorem
  rw [hdiag, Units.conj_pow, Matrix.trace_units_conj, Matrix.diagonal_pow, Matrix.trace_diagonal]
  rfl

/-- Every listed cyclic eigenvalue has a genuine unit physical eigenvector. -/
theorem amoCyclicEigenvalues_exists_unit_eigenvector (α lam θ : ℝ) (q : ℕ) (i : Fin q) :
    ∃ u : AMOFiniteHilbert q, ‖u‖ = 1 ∧
      amoCyclicOperator α lam θ q u = (amoCyclicEigenvalues α lam θ q i : ℂ) • u := by
  let hC := amoCyclicMatrix_isHermitian α lam θ q
  refine ⟨hC.eigenvectorBasis i, hC.eigenvectorBasis.orthonormal.norm_eq_one i, ?_⟩
  apply PiLp.ext
  intro j
  have h := congrFun (hC.mulVec_eigenvectorBasis i) j
  simpa only [Pi.smul_apply, smul_eq_mul, Complex.real_smul, PiLp.smul_apply] using h

end CriticalDTM

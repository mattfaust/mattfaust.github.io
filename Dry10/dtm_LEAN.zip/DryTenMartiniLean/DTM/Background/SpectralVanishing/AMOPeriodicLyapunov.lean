import DTM.Background.Transfer.AMOTransferShiftBounds
import Mathlib.Tactic.FieldSimp

/-!
# A finite trace bound for the rational-frequency transfer exponent

The two-by-two Cayley–Hamilton identity controls powers of a determinant-one
matrix whose complex trace has norm at most six. For a rational base rotation,
the actual transfer over repeated periods is exactly a power of the period
matrix. Phase integration and the already defined Lyapunov infimum then give
`L ≤ log 8 / q` from an explicit uniform period-trace bound. Deriving that
trace bound from periodic spectral data is a separate finite-volume step;
no spectral vanishing or large-deviation property is asserted here.
-/

noncomputable section

open Filter Matrix MeasureTheory
open scoped Topology Matrix Matrix.L2OpNorm

namespace CriticalDTM

/-- The two-by-two Cayley–Hamilton identity, checked entry by entry. -/
theorem amoTransferMatrix_cayleyHamilton (M : AMOTransferMatrix) :
    M ^ 2 = M.trace • M - M.det • (1 : AMOTransferMatrix) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [pow_two, Matrix.mul_apply, Fin.sum_univ_two,
      Matrix.trace_fin_two, Matrix.det_fin_two] <;> ring

/-- Actual powers of a determinant-one matrix obey the second-order trace recurrence. -/
theorem amoTransferMatrix_pow_recurrence (M : AMOTransferMatrix) (hdet : M.det = 1) (m : ℕ) :
    M ^ (m + 2) = M.trace • M ^ (m + 1) - M ^ m := by
  calc
    M ^ (m + 2) = M ^ 2 * M ^ m := by rw [← pow_add, Nat.add_comm m 2]
    _ = (M.trace • M - 1) * M ^ m := by
      rw [amoTransferMatrix_cayleyHamilton, hdet, one_smul]
    _ = _ := by rw [sub_mul, smul_mul_assoc, one_mul, ← pow_succ']

/-- A loose but uniform Euclidean norm bound from the exact trace recurrence.
The complex trace is bounded in norm; it is not assumed to be real. -/
theorem amoTransferMatrix_norm_pow_le_of_trace
    (M : AMOTransferMatrix) (hdet : M.det = 1) (htrace : ‖M.trace‖ ≤ 6)
    (K : ℝ) (hK : 1 ≤ K) (hM : amoTransferNorm M ≤ K) (m : ℕ) :
    amoTransferNorm (M ^ m) ≤ K * (8 : ℝ) ^ m := by
  have hK0 : 0 ≤ K := zero_le_one.trans hK
  have hstep (j : ℕ) : amoTransferNorm (M ^ (j + 2)) ≤
      ‖M.trace‖ * amoTransferNorm (M ^ (j + 1)) + amoTransferNorm (M ^ j) := by
    rw [amoTransferMatrix_pow_recurrence M hdet]
    change ‖M.trace • M ^ (j + 1) - M ^ j‖ ≤
      ‖M.trace‖ * ‖M ^ (j + 1)‖ + ‖M ^ j‖
    simpa only [norm_smul] using norm_sub_le (M.trace • M ^ (j + 1)) (M ^ j)
  induction m using Nat.twoStepInduction with
  | zero => simpa only [pow_zero, amoTransferNorm_one, mul_one] using hK
  | one =>
      simp only [pow_one]
      exact hM.trans (by linarith)
  | more m ih₀ ih₁ =>
      calc
        amoTransferNorm (M ^ (m + 2)) ≤
            ‖M.trace‖ * amoTransferNorm (M ^ (m + 1)) + amoTransferNorm (M ^ m) := hstep m
        _ ≤ 6 * (K * (8 : ℝ) ^ (m + 1)) + K * (8 : ℝ) ^ m :=
          add_le_add (mul_le_mul htrace ih₁ (amoTransferNorm_nonneg _) (by norm_num)) ih₀
        _ ≤ K * (8 : ℝ) ^ (m + 2) := by
          have hp : 0 ≤ K * (8 : ℝ) ^ m := mul_nonneg hK0 (by positivity)
          simp only [pow_succ]
          nlinarith

/-- A rational full period shifts the physical radian phase by an integer multiple of `2π`. -/
theorem amoTransferProduct_phase_add_rational_period
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (p : ℤ) (q : ℕ)
    (hperiod : (q : ℝ) * α = (p : ℝ)) (n : ℕ) :
    amoTransferProduct α lam z (θ + 2 * Real.pi * α * (q : ℝ)) n =
      amoTransferProduct α lam z θ n := by
  have hshift : 2 * Real.pi * α * (q : ℝ) = (p : ℝ) * (2 * Real.pi) := by
    calc
      2 * Real.pi * α * (q : ℝ) = ((q : ℝ) * α) * (2 * Real.pi) := by ring
      _ = _ := by rw [hperiod]
  rw [hshift]
  exact (amoTransferProduct_periodic α lam z n).int_mul p θ

/-- Repeated periods of the actual rational-frequency cocycle are matrix powers. -/
theorem amoTransferProduct_mul_period_eq_pow
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (p : ℤ) (q : ℕ)
    (hperiod : (q : ℝ) * α = (p : ℝ)) (m : ℕ) :
    amoTransferProduct α lam z θ (m * q) = (amoTransferProduct α lam z θ q) ^ m := by
  induction m with
  | zero => simp
  | succ m ih =>
      rw [Nat.succ_mul, amoTransferProduct_add,
        amoTransferProduct_phase_add_rational_period α lam z θ p q hperiod, ih, pow_succ]

/-- The uniform finite trace bound gives a growth estimate along all period multiples. -/
theorem amoTransferProduct_periodic_norm_le_of_trace
    (α lam : ℝ) (z : ℂ) (p : ℤ) (q : ℕ)
    (hperiod : (q : ℝ) * α = (p : ℝ))
    (htrace : ∀ θ : ℝ, ‖(amoTransferProduct α lam z θ q).trace‖ ≤ 6)
    (θ : ℝ) (m : ℕ) :
    amoTransferNorm (amoTransferProduct α lam z θ (m * q)) ≤
      amoTransferBound lam z ^ q * (8 : ℝ) ^ m := by
  rw [amoTransferProduct_mul_period_eq_pow α lam z θ p q hperiod]
  exact amoTransferMatrix_norm_pow_le_of_trace _
    (amoTransferProduct_det α lam z θ q) (htrace θ) (amoTransferBound lam z ^ q)
    (one_le_pow₀ (amoTransferBound_one_le lam z))
    (amoTransferProduct_norm_le_pow α lam z θ q) m

theorem amoTransferLogNorm_periodic_le_of_trace
    (α lam : ℝ) (z : ℂ) (p : ℤ) (q : ℕ)
    (hperiod : (q : ℝ) * α = (p : ℝ))
    (htrace : ∀ θ : ℝ, ‖(amoTransferProduct α lam z θ q).trace‖ ≤ 6)
    (θ : ℝ) (m : ℕ) :
    amoTransferLogNorm α lam z θ (m * q) ≤
      (q : ℝ) * Real.log (amoTransferBound lam z) + (m : ℝ) * Real.log 8 := by
  have h := Real.log_le_log (amoTransferProduct_norm_pos α lam z θ (m * q))
    (amoTransferProduct_periodic_norm_le_of_trace α lam z p q hperiod htrace θ m)
  rw [Real.log_mul (pow_ne_zero q (amoTransferBound_pos lam z).ne')
    (pow_ne_zero m (by norm_num : (8 : ℝ) ≠ 0))] at h
  simpa only [amoTransferLogNorm, Real.log_pow] using h

/-- This is the actual phase integral of the pointwise period-multiple estimate. -/
theorem amoTransferLogAverage_periodic_le_of_trace
    (α lam : ℝ) (z : ℂ) (p : ℤ) (q : ℕ)
    (hperiod : (q : ℝ) * α = (p : ℝ))
    (htrace : ∀ θ : ℝ, ‖(amoTransferProduct α lam z θ q).trace‖ ≤ 6) (m : ℕ) :
    amoTransferLogAverage α lam z (m * q) ≤
      (q : ℝ) * Real.log (amoTransferBound lam z) + (m : ℝ) * Real.log 8 := by
  have hphase : 0 < 2 * Real.pi := by positivity
  have hi := intervalIntegral.integral_mono hphase.le
    (amoTransferLogNorm_intervalIntegrable α lam z (m * q) 0 (2 * Real.pi))
    (continuous_const.intervalIntegrable 0 (2 * Real.pi))
    (fun θ => amoTransferLogNorm_periodic_le_of_trace α lam z p q hperiod htrace θ m)
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hi
  apply (div_le_iff₀ hphase).mpr
  simpa only [mul_comm] using hi

/-- The finite normalized exponent has an explicit vanishing transient term. -/
theorem amoFiniteLyapunov_periodic_le_of_trace
    (α lam : ℝ) (z : ℂ) (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hperiod : (q : ℝ) * α = (p : ℝ))
    (htrace : ∀ θ : ℝ, ‖(amoTransferProduct α lam z θ q).trace‖ ≤ 6)
    (m : ℕ) (hm : 0 < m) :
    amoFiniteLyapunov α lam z (m * q) ≤
      Real.log (amoTransferBound lam z) / (m : ℝ) + Real.log 8 / (q : ℝ) := by
  have hq' : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  have hm' : (m : ℝ) ≠ 0 := by exact_mod_cast hm.ne'
  unfold amoFiniteLyapunov
  refine (div_le_div_of_nonneg_right
    (amoTransferLogAverage_periodic_le_of_trace α lam z p q hperiod htrace m)
    (Nat.cast_nonneg (m * q))).trans_eq ?_
  rw [Nat.cast_mul]
  field_simp [hq', hm']
  ring

/-- An explicit uniform period-trace estimate implies the rational exponent
bound. The trace hypothesis is finite data to be discharged separately, not
an external spectral vanishing theorem. -/
theorem amoLyapunov_le_log_eight_div_period_of_trace
    (α lam : ℝ) (z : ℂ) (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hperiod : (q : ℝ) * α = (p : ℝ))
    (htrace : ∀ θ : ℝ, ‖(amoTransferProduct α lam z θ q).trace‖ ≤ 6) :
    amoLyapunov α lam z ≤ Real.log 8 / (q : ℝ) := by
  have hlim : Tendsto (fun m : ℕ =>
      Real.log (amoTransferBound lam z) / ((m + 1 : ℕ) : ℝ) + Real.log 8 / (q : ℝ))
      atTop (𝓝 (Real.log 8 / (q : ℝ))) := by
    have h := ((tendsto_const_div_atTop_nhds_zero_nat (Real.log (amoTransferBound lam z))).comp
      (tendsto_add_atTop_nat 1)).add (tendsto_const_nhds (x := Real.log 8 / (q : ℝ)))
    simpa only [Function.comp_def, zero_add] using h
  apply le_of_tendsto_of_tendsto tendsto_const_nhds hlim
  exact Filter.Eventually.of_forall fun m =>
    (amoLyapunov_le_finite α lam z (n := (m + 1) * q)
      (Nat.one_le_of_lt (Nat.mul_pos (Nat.succ_pos m) hq))).trans
        (amoFiniteLyapunov_periodic_le_of_trace α lam z p q hq hperiod htrace (m + 1)
          (Nat.succ_pos m))

end CriticalDTM

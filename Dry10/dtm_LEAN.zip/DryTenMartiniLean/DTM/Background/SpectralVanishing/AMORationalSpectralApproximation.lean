import DTM.Background.Realization.MagneticSpectralSupport
import DTM.Background.SpectralVanishing.RationalApproximationSequence
import DTM.Background.SpectralVanishing.AMORationalSpectralBound

/-!
# Actual rational low-Lyapunov approximation of spectral energies

Every spectral energy of the irrational magnetic Hamiltonian is approached by
unit eigenvectors of actual rational-frequency cyclic Hamiltonians. Their cycle
lengths are the reduced frequency denominators and tend to infinity. The proved
rational trace oscillation and periodic estimate bound their actual Lyapunov
exponents by `log 8 / q` when `0 < lam ≤ 1`.

No neighbourhood-mass, finite-volume convergence, or positive-Lyapunov
persistence hypothesis remains in this approximation theorem.
-/

noncomputable section

namespace CriticalDTM

open Filter Set
open scoped Topology

/-- The proved rational Lyapunov estimate applies directly to any nonzero
physical cyclic eigenvector, not just a chosen eigenvalue enumeration. -/
theorem amoLyapunov_le_log_eight_div_period_of_cyclic_eigenvector
    (p : ℤ) (q : ℕ) (hq : 3 ≤ q) (hcop : p.natAbs.Coprime q)
    (lam : ℝ) (hlam0 : 0 < lam) (hlam1 : lam ≤ 1) (θ₀ E : ℝ)
    (u : AMOFiniteHilbert q) (hu0 : u ≠ 0)
    (hu : amoCyclicOperator ((p : ℝ) / (q : ℝ)) lam θ₀ q u = (E : ℂ) • u) :
    amoLyapunov ((p : ℝ) / (q : ℝ)) lam (E : ℂ) ≤ Real.log 8 / (q : ℝ) := by
  have hbase : (amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ₀ q).trace = 2 := by
    obtain ⟨n, rfl⟩ : ∃ n : ℕ, q = n + 3 := ⟨q - 3, by omega⟩
    exact amoTransferProduct_trace_eq_two_of_cyclic_eigenvector
      ((p : ℝ) / ((n + 3 : ℕ) : ℝ)) lam θ₀ (E : ℂ) n u hu0 hu
  apply amoLyapunov_le_log_eight_div_period_of_trace
    ((p : ℝ) / (q : ℝ)) lam (E : ℂ) p q (by omega)
  · have hq0 : (q : ℝ) ≠ 0 := by exact_mod_cast (show q ≠ 0 by omega)
    field_simp [hq0]
  · intro θ
    have hosc := amoTransferProduct_trace_oscillation p q (by omega) hcop lam (E : ℂ) θ θ₀
    have hpow : |lam| ^ q ≤ 1 := pow_le_one₀ (abs_nonneg lam) (by rwa [abs_of_pos hlam0])
    calc
      ‖(amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ q).trace‖ =
          ‖((amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ q).trace -
            (amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ₀ q).trace) +
              (amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ₀ q).trace‖ := by
                rw [sub_add_cancel]
      _ ≤ ‖(amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ q).trace -
              (amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ₀ q).trace‖ +
            ‖(amoTransferProduct ((p : ℝ) / (q : ℝ)) lam (E : ℂ) θ₀ q).trace‖ := norm_add_le _ _
      _ ≤ 4 * |lam| ^ q + 2 := add_le_add hosc (by rw [hbase]; norm_num)
      _ ≤ 6 := by linarith

/-- Every actual irrational spectral energy has rational-frequency physical
cyclic approximations with diverging reduced denominators and vanishing upper
bounds for their actual Lyapunov exponents. -/
theorem amo_exists_rational_spectral_approximation {α : ℝ} (hα : Irrational α)
    (lam E : ℝ) (hlam0 : 0 < lam) (hlam1 : lam ≤ 1)
    (hE : E ∈ magneticRealSpectrumSet α lam) :
    ∃ (rs : ℕ → ℚ) (θs Es : ℕ → ℝ),
      Tendsto (fun j => (rs j : ℝ)) atTop (𝓝 α) ∧
      Tendsto Es atTop (𝓝 E) ∧
      Tendsto (fun j => (rs j).den) atTop atTop ∧
      ∀ j, 3 ≤ (rs j).den ∧
        |α - (rs j : ℝ)| < 1 / ((rs j).den : ℝ) ^ 2 ∧
        amoLyapunov (rs j : ℝ) lam (Es j : ℂ) ≤ Real.log 8 / ((rs j).den : ℝ) ∧
        ∃ u : AMOFiniteHilbert (rs j).den, ‖u‖ = 1 ∧
          amoCyclicOperator (rs j : ℝ) lam (θs j) (rs j).den u = (Es j : ℂ) • u := by
  obtain ⟨rs, hrs, hden, hgood⟩ := exists_rational_approximation_sequence hα
  let ns : ℕ → ℕ := fun j => (rs j).den - 3
  have hn : Tendsto ns atTop atTop :=
    tendsto_atTop_mono (fun j => by change j ≤ ns j; dsimp [ns]; have := (hgood j).1; omega) tendsto_id
  obtain ⟨φ, θs, Es, _, hφ, hEs, hu⟩ :=
    amoCyclic_exists_strict_physical_subsequence lam E hrs hn
      (fun epsilon he => magneticRealSpectralMeasure_ball_pos_of_mem α lam E hE he)
  refine ⟨rs ∘ φ, θs, Es, hrs.comp hφ, hEs, hden.comp hφ, fun j => ?_⟩
  have hq : 3 ≤ (rs (φ j)).den := by have := (hgood (φ j)).1; omega
  have hlen : ns (φ j) + 3 = (rs (φ j)).den := Nat.sub_add_cancel hq
  have huj : ∃ u : AMOFiniteHilbert (rs (φ j)).den, ‖u‖ = 1 ∧
      amoCyclicOperator (rs (φ j) : ℝ) lam (θs j) (rs (φ j)).den u = (Es j : ℂ) • u := by
    rw [← hlen]
    exact hu j
  obtain ⟨u, hunit, heig⟩ := huj
  refine ⟨hq, (hgood (φ j)).2, ?_, u, hunit, heig⟩
  change amoLyapunov (rs (φ j) : ℝ) lam (Es j : ℂ) ≤ Real.log 8 / ((rs (φ j)).den : ℝ)
  rw [Rat.cast_def]
  apply amoLyapunov_le_log_eight_div_period_of_cyclic_eigenvector
    (rs (φ j)).num (rs (φ j)).den hq (rs (φ j)).reduced lam hlam0 hlam1 (θs j) (Es j) u
  · intro hz
    simp [hz] at hunit
  · simpa only [Rat.cast_def] using heig

end CriticalDTM

import DTM.Background.SpectralVanishing.AMORationalTrace
import DTM.Background.SpectralVanishing.AMOCyclicVolumeRows
import DTM.Background.SpectralVanishing.AMOCyclicVolumeSpectrum
import DTM.Background.SpectralVanishing.AMOPeriodicLyapunov

/-!
# Rational Lyapunov bounds at actual cyclic eigenvalues

A genuine cyclic eigenvector propagates through the physical transfer steps
and returns to its initial two-component state. This nonzero state forces
period trace two. Rational trace oscillation therefore supplies a uniform
trace bound, and hence the actual Lyapunov bound `log 8 / q`.
-/

noncomputable section

namespace CriticalDTM

open Matrix

private def amoCyclicTransferSite (n k : ℕ) : Fin (n + 3) :=
  ⟨k % (n + 3), Nat.mod_lt _ (by omega)⟩

private def amoCyclicTransferState (n : ℕ) (u : AMOFiniteHilbert (n + 3))
    (k : ℕ) : Fin 2 → ℂ :=
  ![u (amoCyclicTransferSite n k), u (amoCyclicTransferSite n (k + (n + 3) - 1))]

private theorem amo_cyclic_site_next (n k : ℕ) (hk : k < n + 3) :
    amoCyclicNext n (amoCyclicTransferSite n k) = amoCyclicTransferSite n (k + 1) := by
  apply Fin.ext
  simp only [amoCyclicNext_val, amoCyclicTransferSite, Nat.mod_eq_of_lt hk]

private theorem amo_cyclic_site_prev (n k : ℕ) (hk : k < n + 3) :
    amoCyclicPrev n (amoCyclicTransferSite n k) =
      amoCyclicTransferSite n (k + (n + 3) - 1) := by
  apply Fin.ext
  simp only [amoCyclicPrev_val, amoCyclicTransferSite, Nat.mod_eq_of_lt hk]

private theorem amo_cyclic_site_prev_next (n k : ℕ) :
    amoCyclicTransferSite n ((k + 1) + (n + 3) - 1) = amoCyclicTransferSite n k := by
  apply Fin.ext
  simp only [amoCyclicTransferSite]
  rw [show (k + 1) + (n + 3) - 1 = k + (n + 3) by omega, Nat.add_mod_right]

private theorem amo_cyclic_state_period (n : ℕ) (u : AMOFiniteHilbert (n + 3)) :
    amoCyclicTransferState n u (n + 3) = amoCyclicTransferState n u 0 := by
  have hfirst : amoCyclicTransferSite n (n + 3) = amoCyclicTransferSite n 0 := by
    apply Fin.ext
    simp [amoCyclicTransferSite]
  have hlast : amoCyclicTransferSite n ((n + 3) + (n + 3) - 1) =
      amoCyclicTransferSite n (0 + (n + 3) - 1) := by
    apply Fin.ext
    simp only [amoCyclicTransferSite]
    rw [show (n + 3) + (n + 3) - 1 = (n + 3 - 1) + (n + 3) by omega,
      Nat.add_mod_right, zero_add]
  unfold amoCyclicTransferState
  rw [hfirst, hlast]

private theorem amo_cyclic_transfer_step (α lam θ : ℝ) (z : ℂ) (n : ℕ)
    (u : AMOFiniteHilbert (n + 3))
    (hu : amoCyclicOperator α lam θ (n + 3) u = z • u) (k : ℕ) (hk : k < n + 3) :
    amoTransfer lam z (θ + 2 * Real.pi * α * (k : ℝ)) *ᵥ amoCyclicTransferState n u k =
      amoCyclicTransferState n u (k + 1) := by
  have hrow := congrArg (fun v : AMOFiniteHilbert (n + 3) =>
    v (amoCyclicTransferSite n k)) hu
  change amoCyclicOperator α lam θ (n + 3) u (amoCyclicTransferSite n k) =
    z * u (amoCyclicTransferSite n k) at hrow
  rw [amoCyclicOperator_apply, amo_cyclic_site_next n k hk,
    amo_cyclic_site_prev n k hk] at hrow
  have hval : (amoCyclicTransferSite n k).val = k := Nat.mod_eq_of_lt hk
  rw [hval] at hrow
  unfold amoCyclicTransferState
  rw [amo_cyclic_site_prev_next]
  funext i
  fin_cases i
  · simp only [amoTransfer, Matrix.mulVec, dotProduct, Fin.sum_univ_two]
    change (z - ((2 * lam * Real.cos (θ + 2 * Real.pi * α * (k : ℝ)) : ℝ) : ℂ)) *
        u (amoCyclicTransferSite n k) + (-1) *
          u (amoCyclicTransferSite n (k + (n + 3) - 1)) =
            u (amoCyclicTransferSite n (k + 1))
    rw [add_comm θ]
    linear_combination -hrow
  · simp [amoTransfer, Matrix.mulVec, dotProduct, Fin.sum_univ_two]

private theorem amo_cyclic_transfer_product (α lam θ : ℝ) (z : ℂ) (n : ℕ)
    (u : AMOFiniteHilbert (n + 3))
    (hu : amoCyclicOperator α lam θ (n + 3) u = z • u) (k : ℕ) (hk : k ≤ n + 3) :
    amoTransferProduct α lam z θ k *ᵥ amoCyclicTransferState n u 0 =
      amoCyclicTransferState n u k := by
  induction k with
  | zero => simp
  | succ k ih =>
      rw [amoTransferProduct_succ, ← Matrix.mulVec_mulVec, ih (by omega)]
      exact amo_cyclic_transfer_step α lam θ z n u hu k (by omega)

private theorem amo_cyclic_state_ne_zero (α lam θ : ℝ) (z : ℂ) (n : ℕ)
    (u : AMOFiniteHilbert (n + 3)) (hu0 : u ≠ 0)
    (hu : amoCyclicOperator α lam θ (n + 3) u = z • u) :
    amoCyclicTransferState n u 0 ≠ 0 := by
  intro hv
  apply hu0
  apply PiLp.ext
  intro i
  have h := congrFun (amo_cyclic_transfer_product α lam θ z n u hu i.val i.isLt.le) 0
  rw [hv, Matrix.mulVec_zero] at h
  change 0 = u (amoCyclicTransferSite n i.val) at h
  have hi : amoCyclicTransferSite n i.val = i := Fin.ext (Nat.mod_eq_of_lt i.isLt)
  rw [hi] at h
  exact h.symm

private theorem amo_trace_eq_two_of_fixed_vector (M : AMOTransferMatrix)
    (hdet : M.det = 1) (v : Fin 2 → ℂ) (hv : v ≠ 0) (hMv : M *ᵥ v = v) :
    M.trace = 2 := by
  have hN : (M - 1) *ᵥ v = 0 := by rw [Matrix.sub_mulVec, hMv, Matrix.one_mulVec, sub_self]
  have hD : (M - 1).det = 0 := by
    by_contra hd
    have hinj : Function.Injective ((M - 1).mulVec) :=
      Matrix.mulVec_injective_iff_isUnit.mpr
        ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hd))
    exact hv (hinj (by simpa only [Matrix.mulVec_zero] using hN))
  rw [Matrix.trace_fin_two]
  rw [Matrix.det_fin_two] at hdet
  simp only [Matrix.det_fin_two, Matrix.sub_apply, Matrix.one_apply,
    Fin.isValue, if_true, Fin.reduceEq, if_false, sub_zero] at hD
  linear_combination hdet - hD

/-- A nonzero eigenvector of the actual cyclic receiving rows forces period
trace two. This finite identity does not require a rational frequency. -/
theorem amoTransferProduct_trace_eq_two_of_cyclic_eigenvector
    (α lam θ : ℝ) (z : ℂ) (n : ℕ) (u : AMOFiniteHilbert (n + 3)) (hu0 : u ≠ 0)
    (hu : amoCyclicOperator α lam θ (n + 3) u = z • u) :
    (amoTransferProduct α lam z θ (n + 3)).trace = 2 := by
  apply amo_trace_eq_two_of_fixed_vector _ (amoTransferProduct_det α lam z θ (n + 3))
    (amoCyclicTransferState n u 0) (amo_cyclic_state_ne_zero α lam θ z n u hu0 hu)
  exact (amo_cyclic_transfer_product α lam θ z n u hu (n + 3) le_rfl).trans
    (amo_cyclic_state_period n u)

end CriticalDTM

import DTM.Background.LargeDeviation.AMOTransferPolynomial
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.RingTheory.RootsOfUnity.Complex

/-!
# Rational phase oscillation of the actual almost Mathieu trace

The cleared phase polynomial is invariant under the primitive rational
rotation. Its only possible trace coefficients have indices `0`, `q`, and
`2*q`; the two extreme coefficients have norm `|lam|^q`. This proves the
finite Chambers oscillation estimate without assuming a Chambers formula.
-/

noncomputable section

namespace CriticalDTM

open Matrix Polynomial

private def amoRationalPhaseRoot (α : ℝ) : ℂ :=
  Complex.exp (((2 * Real.pi * α : ℝ) : ℂ) * Complex.I)

private theorem amo_phase_root_pow (α : ℝ) (n : ℕ) :
    Complex.exp (((2 * Real.pi * α * (n : ℝ) : ℝ) : ℂ) * Complex.I) =
      amoRationalPhaseRoot α ^ n := by
  rw [amoRationalPhaseRoot, ← Complex.exp_nat_mul]
  congr 1
  push_cast
  ring

private theorem amo_phase_root_primitive (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hcop : p.natAbs.Coprime q) :
    IsPrimitiveRoot (amoRationalPhaseRoot ((p : ℝ) / (q : ℝ))) q := by
  have h := (Complex.isPrimitiveRoot_exp q hq.ne').zpow_of_gcd_eq_one p
    (by simpa [Int.gcd] using hcop)
  rw [← Complex.exp_int_mul] at h
  convert h using 1
  unfold amoRationalPhaseRoot
  congr 1
  push_cast
  ring

private theorem amo_step_root_form (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoTransferStepPolynomial α lam z n =
      !![C z * X - C (lam : ℂ) *
          (C (amoRationalPhaseRoot α ^ n) * X ^ 2 +
            C ((amoRationalPhaseRoot α ^ n)⁻¹)), -X; X, 0] := by
  simp only [amoTransferStepPolynomial, Complex.exp_neg, amo_phase_root_pow]

/-- Clearing a phase power makes one rational phase shift a site shift. -/
private theorem amo_step_comp (α lam : ℝ) (z : ℂ) (n : ℕ) :
    (amoTransferStepPolynomial α lam z n).map
        (Polynomial.compRingHom (C (amoRationalPhaseRoot α) * X)) =
      C (amoRationalPhaseRoot α) • amoTransferStepPolynomial α lam z (n + 1) := by
  have hξ : amoRationalPhaseRoot α ≠ 0 := Complex.exp_ne_zero _
  have hC : C (amoRationalPhaseRoot α) * C (amoRationalPhaseRoot α)⁻¹ =
      (1 : Polynomial ℂ) := by
    rw [← C_mul, mul_inv_cancel₀ hξ, C_1]
  rw [amo_step_root_form, amo_step_root_form]
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j
  · change
      (C z * X - C (lam : ℂ) *
        (C (amoRationalPhaseRoot α ^ n) * X ^ 2 +
          C ((amoRationalPhaseRoot α ^ n)⁻¹))).comp
            (C (amoRationalPhaseRoot α) * X) =
        C (amoRationalPhaseRoot α) *
          (C z * X - C (lam : ℂ) *
            (C (amoRationalPhaseRoot α ^ (n + 1)) * X ^ 2 +
              C ((amoRationalPhaseRoot α ^ (n + 1))⁻¹)))
    simp only [Polynomial.sub_comp, Polynomial.mul_comp, Polynomial.C_comp,
      Polynomial.X_comp, Polynomial.add_comp, Polynomial.pow_comp,
      pow_succ, _root_.mul_inv_rev, C_mul]
    linear_combination C (lam : ℂ) * C ((amoRationalPhaseRoot α ^ n)⁻¹) * hC
  · simp [Polynomial.coe_compRingHom_apply, Matrix.smul_apply]
  · simp [Polynomial.coe_compRingHom_apply, Matrix.smul_apply, smul_eq_mul]
  · simp [Polynomial.coe_compRingHom_apply, Matrix.smul_apply]

private theorem amo_polynomial_comp_intertwine (α lam : ℝ) (z : ℂ) (n : ℕ) :
    (amoTransferPolynomial α lam z n).map
        (Polynomial.compRingHom (C (amoRationalPhaseRoot α) * X)) *
          amoTransferStepPolynomial α lam z 0 =
      C (amoRationalPhaseRoot α) ^ n •
        (amoTransferStepPolynomial α lam z n * amoTransferPolynomial α lam z n) := by
  induction n with
  | zero => simp
  | succ n ih =>
      simp only [amoTransferPolynomial_succ, Matrix.map_mul, amo_step_comp]
      rw [Matrix.smul_mul, Matrix.smul_mul, Matrix.mul_assoc, ih,
        Matrix.mul_smul, smul_smul, pow_succ']

private theorem amo_step_period (α lam : ℝ) (z : ℂ) (q : ℕ)
    (hξ : amoRationalPhaseRoot α ^ q = 1) :
    amoTransferStepPolynomial α lam z q = amoTransferStepPolynomial α lam z 0 := by
  rw [amo_step_root_form, amo_step_root_form, hξ, pow_zero]

private theorem amo_step_det (α lam : ℝ) (z : ℂ) (n : ℕ) :
    (amoTransferStepPolynomial α lam z n).det = (X : Polynomial ℂ) ^ 2 := by
  simp [amoTransferStepPolynomial, Matrix.det_fin_two, pow_two]

private theorem amo_trace_of_intertwine
    (A B S : Matrix (Fin 2) (Fin 2) (Polynomial ℂ)) (h : A * S = S * B)
    (hS : S.det ≠ 0) : A.trace = B.trace := by
  apply mul_left_cancel₀ hS
  calc
    S.det * A.trace = (A * S * S.adjugate).trace := by
      rw [Matrix.mul_assoc, Matrix.mul_adjugate, Matrix.mul_smul,
        Matrix.mul_one, Matrix.trace_smul, smul_eq_mul]
    _ = (S * B * S.adjugate).trace := by rw [h]
    _ = S.det * B.trace := by
      rw [Matrix.trace_mul_cycle, Matrix.adjugate_mul, Matrix.smul_mul,
        Matrix.one_mul, Matrix.trace_smul, smul_eq_mul]

/-- The actual cleared trace is invariant under a full rational site cycle. -/
private theorem amo_trace_polynomial_comp (α lam : ℝ) (z : ℂ) (q : ℕ)
    (hξ : amoRationalPhaseRoot α ^ q = 1) :
    ((amoTransferPolynomial α lam z q).trace).comp
      (C (amoRationalPhaseRoot α) * X) = (amoTransferPolynomial α lam z q).trace := by
  have h := amo_polynomial_comp_intertwine α lam z q
  rw [← C_pow, hξ, C_1, one_smul, amo_step_period α lam z q hξ] at h
  have ht := amo_trace_of_intertwine _ _ _ h
    (by rw [amo_step_det]; exact pow_ne_zero _ Polynomial.X_ne_zero)
  simpa only [Matrix.trace_fin_two, Matrix.map_apply,
    Polynomial.coe_compRingHom_apply, Polynomial.add_comp] using ht

private theorem amo_trace_polynomial_degree (α lam : ℝ) (z : ℂ) (q : ℕ) :
    ((amoTransferPolynomial α lam z q).trace).natDegree ≤ 2 * q := by
  rw [Matrix.trace_fin_two]
  exact Polynomial.natDegree_add_le_of_degree_le
    (amoTransferPolynomial_natDegree_le α lam z q 0 0)
    (amoTransferPolynomial_natDegree_le α lam z q 1 1)

/-- No nonmultiple of the primitive period survives in the actual trace. -/
private theorem amo_trace_coeff_zero (α lam : ℝ) (z : ℂ) (q : ℕ)
    (hξ : IsPrimitiveRoot (amoRationalPhaseRoot α) q) (k : ℕ) (hk : ¬q ∣ k) :
    ((amoTransferPolynomial α lam z q).trace).coeff k = 0 := by
  have h := congrArg (fun P : Polynomial ℂ => P.coeff k)
    (amo_trace_polynomial_comp α lam z q hξ.pow_eq_one)
  simp only [Polynomial.comp_C_mul_X_coeff] at h
  have hn : amoRationalPhaseRoot α ^ k ≠ 1 := mt (hξ.pow_eq_one_iff_dvd k).mp hk
  by_contra hc
  exact hn ((mul_eq_left₀ hc).mp h)

private theorem amo_trace_polynomial_sparse (α lam : ℝ) (z : ℂ) (q : ℕ)
    (hq : 0 < q) (hξ : IsPrimitiveRoot (amoRationalPhaseRoot α) q) :
    (amoTransferPolynomial α lam z q).trace =
      C ((amoTransferPolynomial α lam z q).trace.coeff 0) +
      C ((amoTransferPolynomial α lam z q).trace.coeff q) * X ^ q +
      C ((amoTransferPolynomial α lam z q).trace.coeff (2 * q)) * X ^ (2 * q) := by
  have hq0 : q ≠ 0 := hq.ne'
  have h2q0 : 2 * q ≠ 0 := by omega
  have h2q : q ≠ 2 * q := by omega
  ext k
  by_cases hk0 : k = 0
  · subst k
    simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, hq0, hq0.symm, h2q0]
  by_cases hkq : k = q
  · subst k
    simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, hq0, h2q]
  by_cases hk2q : k = 2 * q
  · subst k
    simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, h2q0, h2q.symm]
  have hz : (amoTransferPolynomial α lam z q).trace.coeff k = 0 := by
    by_cases hle : k ≤ 2 * q
    · apply amo_trace_coeff_zero α lam z q hξ k
      rintro ⟨m, hm⟩
      have hm2 : m ≤ 2 := by nlinarith
      interval_cases m <;> simp_all [Nat.mul_comm]
    · exact Polynomial.coeff_eq_zero_of_natDegree_lt
        ((amo_trace_polynomial_degree α lam z q).trans_lt (lt_of_not_ge hle))
  simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, hz, hk0, hkq, hk2q]

private theorem amo_extreme_coeff_top_left (α lam : ℝ) (z : ℂ) (n : ℕ) :
    ‖(amoTransferPolynomial α lam z n 0 0).coeff 0‖ = |lam| ^ n ∧
    ‖(amoTransferPolynomial α lam z n 0 0).coeff (2 * n)‖ = |lam| ^ n := by
  induction n with
  | zero => simp
  | succ n ih =>
      constructor
      · simp only [amoTransferPolynomial_succ, Matrix.mul_apply, Fin.sum_univ_two,
          Polynomial.coeff_add, Polynomial.mul_coeff_zero]
        simpa [amoTransferStepPolynomial, Polynomial.coeff_X, Polynomial.coeff_C,
          norm_mul, Complex.norm_exp, Complex.norm_real, Real.norm_eq_abs, pow_succ'] using
          congrArg (fun r : ℝ => |lam| * r) ih.1
      · rw [show 2 * (n + 1) = 2 + 2 * n by omega]
        simp only [amoTransferPolynomial_succ, Matrix.mul_apply, Fin.sum_univ_two,
          Polynomial.coeff_add]
        rw [Polynomial.coeff_mul_add_eq_of_natDegree_le
          (amoTransferStepPolynomial_natDegree_le α lam z n 0 0)
          (amoTransferPolynomial_natDegree_le α lam z n 0 0),
          Polynomial.coeff_mul_add_eq_of_natDegree_le
          (amoTransferStepPolynomial_natDegree_le α lam z n 0 1)
          (amoTransferPolynomial_natDegree_le α lam z n 1 0)]
        simpa [amoTransferStepPolynomial, Polynomial.coeff_C_mul_X_pow,
          Polynomial.coeff_X, Polynomial.coeff_C, norm_mul, Complex.norm_exp,
          Complex.norm_real, Real.norm_eq_abs, pow_succ'] using congrArg (fun r : ℝ => |lam| * r) ih.2

private theorem amo_extreme_coeff_bottom_right (α lam : ℝ) (z : ℂ) (n : ℕ) :
    (amoTransferPolynomial α lam z (n + 1) 1 1).coeff 0 = 0 ∧
    (amoTransferPolynomial α lam z (n + 1) 1 1).coeff (2 * (n + 1)) = 0 := by
  constructor
  · simp [amoTransferPolynomial_succ, Matrix.mul_apply, Fin.sum_univ_two,
      amoTransferStepPolynomial]
  · rw [show 2 * (n + 1) = 2 + 2 * n by omega]
    simp only [amoTransferPolynomial_succ, Matrix.mul_apply, Fin.sum_univ_two,
      Polynomial.coeff_add]
    rw [Polynomial.coeff_mul_add_eq_of_natDegree_le
      (amoTransferStepPolynomial_natDegree_le α lam z n 1 0)
      (amoTransferPolynomial_natDegree_le α lam z n 0 1),
      Polynomial.coeff_mul_add_eq_of_natDegree_le
      (amoTransferStepPolynomial_natDegree_le α lam z n 1 1)
      (amoTransferPolynomial_natDegree_le α lam z n 1 1)]
    simp [amoTransferStepPolynomial, Polynomial.coeff_X]

/-- Both extreme Laurent trace coefficients have precisely the physical
coupling modulus, including zero coupling and a one-site period. -/
private theorem amo_trace_extreme_coeff_norm (α lam : ℝ) (z : ℂ) (q : ℕ) (hq : 0 < q) :
    ‖(amoTransferPolynomial α lam z q).trace.coeff 0‖ = |lam| ^ q ∧
    ‖(amoTransferPolynomial α lam z q).trace.coeff (2 * q)‖ = |lam| ^ q := by
  obtain ⟨n, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hq.ne'
  have hb := amo_extreme_coeff_bottom_right α lam z n
  simpa only [Matrix.trace_fin_two, Polynomial.coeff_add, hb.1, hb.2, add_zero] using
    amo_extreme_coeff_top_left α lam z (n + 1)

private theorem amo_trace_polynomial_eval (α lam : ℝ) (z : ℂ) (θ : ℝ) (q : ℕ) :
    ((amoTransferPolynomial α lam z q).trace).eval
      (Complex.exp ((θ : ℂ) * Complex.I)) =
        Complex.exp ((θ : ℂ) * Complex.I) ^ q *
          (amoTransferProduct α lam z θ q).trace := by
  rw [Matrix.trace_fin_two, Polynomial.eval_add, amoTransferPolynomial_eval,
    amoTransferPolynomial_eval, Matrix.trace_fin_two]
  ring

private theorem amo_trace_laurent (α lam : ℝ) (z : ℂ) (q : ℕ)
    (hq : 0 < q) (hξ : IsPrimitiveRoot (amoRationalPhaseRoot α) q) (θ : ℝ) :
    (amoTransferProduct α lam z θ q).trace =
      (amoTransferPolynomial α lam z q).trace.coeff 0 /
          Complex.exp ((θ : ℂ) * Complex.I) ^ q +
        (amoTransferPolynomial α lam z q).trace.coeff q +
        (amoTransferPolynomial α lam z q).trace.coeff (2 * q) *
          Complex.exp ((θ : ℂ) * Complex.I) ^ q := by
  have h := congrArg (fun P : Polynomial ℂ =>
    P.eval (Complex.exp ((θ : ℂ) * Complex.I)))
    (amo_trace_polynomial_sparse α lam z q hq hξ)
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C,
    Polynomial.eval_pow, Polynomial.eval_X, amo_trace_polynomial_eval] at h
  have hw : Complex.exp ((θ : ℂ) * Complex.I) ^ q ≠ 0 :=
    pow_ne_zero q (Complex.exp_ne_zero _)
  apply mul_left_cancel₀ hw
  rw [h, show 2 * q = q + q by omega, pow_add]
  field_simp
  ring

/-- The actual rational almost Mathieu period trace varies by at most
`4 * |lam|^q` over all real phases. The energy is arbitrary and complex;
no Chambers formula or spectral hypothesis is assumed. -/
theorem amoTransferProduct_trace_oscillation
    (p : ℤ) (q : ℕ) (hq : 0 < q) (hcop : p.natAbs.Coprime q)
    (lam : ℝ) (z : ℂ) (θ φ : ℝ) :
    ‖(amoTransferProduct ((p : ℝ) / (q : ℝ)) lam z θ q).trace -
      (amoTransferProduct ((p : ℝ) / (q : ℝ)) lam z φ q).trace‖ ≤ 4 * |lam| ^ q := by
  let α : ℝ := (p : ℝ) / (q : ℝ)
  have hξ := amo_phase_root_primitive p q hq hcop
  rw [amo_trace_laurent α lam z q hq hξ θ, amo_trace_laurent α lam z q hq hξ φ]
  let a := (amoTransferPolynomial α lam z q).trace.coeff 0
  let b := (amoTransferPolynomial α lam z q).trace.coeff q
  let c := (amoTransferPolynomial α lam z q).trace.coeff (2 * q)
  let w := Complex.exp ((θ : ℂ) * Complex.I) ^ q
  let v := Complex.exp ((φ : ℂ) * Complex.I) ^ q
  have hw : ‖w‖ = 1 := by simp [w, norm_pow, Complex.norm_exp_ofReal_mul_I]
  have hv : ‖v‖ = 1 := by simp [v, norm_pow, Complex.norm_exp_ofReal_mul_I]
  have hc := amo_trace_extreme_coeff_norm α lam z q hq
  change ‖a‖ = |lam| ^ q ∧ ‖c‖ = |lam| ^ q at hc
  change ‖(a / w + b + c * w) - (a / v + b + c * v)‖ ≤ _
  calc
    ‖(a / w + b + c * w) - (a / v + b + c * v)‖ =
        ‖(a / w - a / v) + (c * w - c * v)‖ := by congr 1; ring
    _ ≤ (‖a / w‖ + ‖a / v‖) + (‖c * w‖ + ‖c * v‖) :=
      (norm_add_le _ _).trans (add_le_add (norm_sub_le _ _) (norm_sub_le _ _))
    _ = 4 * |lam| ^ q := by rw [norm_div, norm_div, norm_mul, norm_mul, hw, hv, hc.1, hc.2]; ring

end CriticalDTM

import DTM.Background.Records.AMORecordPersistence
import DTM.Background.SpectralVanishing.AMORationalSpectralApproximation
import DTM.Background.Potential.AMOLyapunovPotential
import DTM.Background.Realization.AMOMagneticSpectrum

/-!
# Vanishing of the actual AMO exponent on the subcritical and critical spectrum

Every irrational spectral energy has rational cyclic approximations whose
actual transfer exponents have upper bounds tending to zero. The proved
positive-persistence theorem excludes a positive exponent at the limit.
The independently proved DOS comparison then gives exactly the intrinsic
spectral-vanishing statement needed by the critical-gap argument.
-/

noncomputable section
namespace CriticalDTM

open Set Filter
open scoped Topology

/-- The spectral Lyapunov formula needed by the critical-gap proof, established
without a noncritical gap-opening assumption. -/
theorem amoLyapunov_eq_zero_of_mem_magneticSpectrum
    {α lam E : ℝ} (hα : Irrational α) (hlam0 : 0 < lam) (hlam1 : lam ≤ 1)
    (hE : E ∈ magneticRealSpectrumSet α lam) :
    amoLyapunov α lam (E : ℂ) = 0 := by
  have hlam : |lam| ≤ 1 := by rwa [abs_of_pos hlam0]
  have hspec : (E : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ)) := hE
  have hnorm := spectrum.norm_le_norm_of_mem hspec
  have hH := hOperator_norm_le α (lam : ℂ)
  have hEabs : |E| ≤ 4 := by
    simp only [Complex.norm_real, Real.norm_eq_abs] at hnorm hH
    linarith
  apply le_antisymm _ (amoLyapunov_nonneg α lam (E : ℂ))
  by_contra h
  have hpos : 0 < amoLyapunov α lam (E : ℂ) := lt_of_not_ge h
  obtain ⟨κ, hκ, U, hU, hUE, hlower⟩ :=
    amoLyapunov_positive_persistence hα hlam (by linarith : |E| < 5) hpos
  obtain ⟨rs, θs, Es, hrs, hEs, hden, happrox⟩ :=
    amo_exists_rational_spectral_approximation hα lam E hlam0 hlam1 hE
  have hpair : Tendsto (fun j => ((rs j : ℝ), Es j)) atTop (𝓝 (α, E)) :=
    hrs.prodMk_nhds hEs
  have hnear : ∀ᶠ j in atTop, ((rs j : ℝ), Es j) ∈ U :=
    hpair.eventually (hU.mem_nhds hUE)
  have hsmall : ∀ᶠ j in atTop, Real.log 8 / ((rs j).den : ℝ) < κ :=
    ((tendsto_const_div_atTop_nhds_zero_nat (Real.log 8)).comp hden).eventually
      (eventually_lt_nhds hκ)
  obtain ⟨j, hj, hj'⟩ := (hnear.and hsmall).exists
  have hlow := hlower ((rs j : ℝ), Es j) hj
  have hupper := (happrox j).2.2.1
  exact (not_lt_of_ge hlow) (hupper.trans_lt hj')

theorem magneticTotalLogPotential_eq_zero_on_spectrum
    {α lam : ℝ} (hα : Irrational α) (hlam0 : 0 < lam) (hlam1 : lam ≤ 1)
    (E : ℝ) (hE : E ∈ magneticRealSpectrumSet α lam) :
    magneticTotalLogPotential α (lam, E) = 0 := by
  rw [← amoTotalLogPotential_eq_magnetic]
  exact amoTotalLogPotential_eq_zero_of_lyapunov_eq_zero α lam E
    (amoLyapunov_eq_zero_of_mem_magneticSpectrum hα hlam0 hlam1 hE)

end CriticalDTM

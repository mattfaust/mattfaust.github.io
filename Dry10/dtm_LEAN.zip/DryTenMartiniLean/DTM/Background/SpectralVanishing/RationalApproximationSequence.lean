import Mathlib.NumberTheory.DiophantineApproximation.Basic
import Mathlib.Analysis.SpecificLimits.Basic

/-!
# Rational approximation with diverging reduced denominators

Dirichlet's infinitely many good approximants to an irrational number cannot
have bounded denominators: their numerators are then bounded as well. Choosing
outside each such finite set gives actual reduced rationals converging to the
irrational frequency, with denominator at least the index plus three.
-/

noncomputable section

namespace CriticalDTM

open Filter Set
open scoped Topology

/-- Good approximants with bounded reduced denominator form a finite set. -/
theorem finite_rat_good_approximants_bounded_den (α : ℝ) (N : ℕ) :
    {r : ℚ | |α - (r : ℝ)| < 1 / (r.den : ℝ) ^ 2 ∧ r.den ≤ N}.Finite := by
  let f : ℚ → ℤ × ℕ := fun r => (r.num, r.den)
  let B : ℤ := ⌈(|α| + 1) * (N : ℝ)⌉
  have hinj : Function.Injective f := by
    intro a b hab
    change (a.num, a.den) = (b.num, b.den) at hab
    have hnum : a.num = b.num := congrArg Prod.fst hab
    have hden : a.den = b.den := congrArg Prod.snd hab
    rw [← Rat.num_div_den a, ← Rat.num_div_den b, hnum, hden]
  apply Set.Finite.of_finite_image (f := f) ?_ hinj.injOn
  apply ((finite_Icc (-B) B).prod (finite_Iic N)).subset
  rintro _ ⟨r, hr, rfl⟩
  have hd : (0 : ℝ) < r.den := by exact_mod_cast r.pos
  have hd1 : (1 : ℝ) ≤ r.den := by exact_mod_cast r.pos
  have herr : |α - (r : ℝ)| ≤ 1 := hr.1.le.trans
    ((div_le_one (sq_pos_of_pos hd)).2 (by nlinarith))
  have hrabs : |(r : ℝ)| ≤ |α| + 1 := by
    calc
      |(r : ℝ)| = |α + ((r : ℝ) - α)| := by congr 1; ring
      _ ≤ |α| + |(r : ℝ) - α| := abs_add _ _
      _ ≤ |α| + 1 := add_le_add_left (by rwa [abs_sub_comm]) _
  have hnum : |(r.num : ℝ)| ≤ (|α| + 1) * (N : ℝ) := by
    calc
      |(r.num : ℝ)| = |(r : ℝ)| * (r.den : ℝ) := by
        rw [Rat.cast_def, abs_div, abs_of_pos hd, div_mul_cancel₀ _ hd.ne']
      _ ≤ (|α| + 1) * (r.den : ℝ) := mul_le_mul_of_nonneg_right hrabs hd.le
      _ ≤ (|α| + 1) * (N : ℝ) :=
        mul_le_mul_of_nonneg_left (by exact_mod_cast hr.2) (by positivity)
  have hB : |(r.num : ℝ)| ≤ (B : ℝ) := hnum.trans (Int.le_ceil _)
  change (-B ≤ r.num ∧ r.num ≤ B) ∧ r.den ≤ N
  exact ⟨⟨by exact_mod_cast (abs_le.mp hB).1,
    by exact_mod_cast (abs_le.mp hB).2⟩, hr.2⟩

/-- An irrational frequency has good rational approximants of arbitrarily
large reduced denominator. -/
theorem exists_rat_good_approximation_den_gt {α : ℝ} (hα : Irrational α) (N : ℕ) :
    ∃ r : ℚ, |α - (r : ℝ)| < 1 / (r.den : ℝ) ^ 2 ∧ N < r.den := by
  obtain ⟨r, hr, hn⟩ :=
    (Real.infinite_rat_abs_sub_lt_one_div_den_sq_of_irrational hα).exists_not_mem_finite
      (finite_rat_good_approximants_bounded_den α N)
  exact ⟨r, hr, lt_of_not_ge (fun h => hn ⟨hr, h⟩)⟩

/-- Actual reduced rational frequencies approach any irrational frequency,
with a pointwise denominator lower bound and a Dirichlet error bound. -/
theorem exists_rational_approximation_sequence {α : ℝ} (hα : Irrational α) :
    ∃ rs : ℕ → ℚ,
      Tendsto (fun j => (rs j : ℝ)) atTop (𝓝 α) ∧
      Tendsto (fun j => (rs j).den) atTop atTop ∧
      ∀ j, j + 3 ≤ (rs j).den ∧ |α - (rs j : ℝ)| < 1 / ((rs j).den : ℝ) ^ 2 := by
  choose rs herr hlarge using fun j => exists_rat_good_approximation_den_gt hα (j + 2)
  have hden (j : ℕ) : j + 3 ≤ (rs j).den := by have := hlarge j; omega
  refine ⟨rs, ?_, ?_, fun j => ⟨hden j, herr j⟩⟩
  · apply tendsto_iff_dist_tendsto_zero.mpr
    simp only [Real.dist_eq]
    apply squeeze_zero (fun j => abs_nonneg _) (fun j => ?_)
      ((tendsto_add_atTop_iff_nat 1).2 (tendsto_const_div_atTop_nhds_zero_nat (1 : ℝ)))
    have hd1 : (1 : ℝ) ≤ (rs j).den := by exact_mod_cast (rs j).pos
    have hj : ((j + 1 : ℕ) : ℝ) ≤ (rs j).den := by
      exact_mod_cast (show j + 1 ≤ (rs j).den by have := hden j; omega)
    have hs : ((j + 1 : ℕ) : ℝ) ≤ ((rs j).den : ℝ) ^ 2 := by
      nlinarith [sq_nonneg (((rs j).den : ℝ) - 1)]
    have herror : |(rs j : ℝ) - α| ≤ 1 / ((rs j).den : ℝ) ^ 2 := by
      simpa only [abs_sub_comm] using (herr j).le
    exact herror.trans (one_div_le_one_div_of_le (by positivity) hs)
  · exact tendsto_atTop_mono (fun j => by change j ≤ (rs j).den; have := hden j; omega) tendsto_id

end CriticalDTM

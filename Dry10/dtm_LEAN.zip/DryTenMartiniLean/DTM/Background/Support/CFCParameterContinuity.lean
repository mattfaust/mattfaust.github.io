import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Basic
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Isometric
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.Topology.Algebra.Polynomial
import Mathlib.Tactic.Linarith

/-!
# Continuity of the continuous functional calculus in its operator argument

Polynomial approximation on a common compact real spectral window, together
with the CFC norm estimate, proves continuity as the self-adjoint operator
varies. No operator-argument continuity theorem is assumed.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology Polynomial ContinuousFunctionalCalculus

/-- Stone–Weierstrass gives one polynomial that approximates a continuous
real function uniformly on a prescribed compact real set. -/
theorem exists_polynomial_uniform_approximation (K : Set ℝ) (hK : IsCompact K)
    (f : ℝ → ℝ) (hf : ContinuousOn f K) (epsilon : ℝ) (hepsilon : 0 < epsilon) :
    ∃ p : ℝ[X], ∀ x ∈ K, ‖f x - p.eval x‖ < epsilon := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK
  let F : C(K, ℝ) := ⟨fun x => f x, hf.restrict⟩
  have hmem : F ∈ (polynomialFunctions K).topologicalClosure := by
    rw [polynomialFunctions.topologicalClosure]
    trivial
  change F ∈ closure (polynomialFunctions K : Set C(K, ℝ)) at hmem
  obtain ⟨G, hG, hdist⟩ := Metric.mem_closure_iff.mp hmem epsilon hepsilon
  rw [polynomialFunctions_coe] at hG
  obtain ⟨p, rfl⟩ := hG
  refine ⟨p, fun x hx => ?_⟩
  have hpoint := ContinuousMap.norm_coe_le_norm
    (F - Polynomial.toContinuousMapOnAlgHom K p) (⟨x, hx⟩ : K)
  have hpoint' : ‖f x - p.eval x‖ ≤ ‖F - Polynomial.toContinuousMapOnAlgHom K p‖ := hpoint
  exact hpoint'.trans_lt (by simpa only [dist_eq_norm] using hdist)

section CStarAlgebra

variable {A : Type*} [CStarAlgebra A]

/-- A uniform scalar approximation on a common spectral set controls the
operator approximation with the same error. -/
theorem norm_cfc_sub_polynomial_lt (f : ℝ → ℝ) (K : Set ℝ)
    (hf : ContinuousOn f K) (p : ℝ[X]) (epsilon : ℝ) (hepsilon : 0 < epsilon)
    (hp : ∀ x ∈ K, ‖f x - p.eval x‖ < epsilon)
    (a : A) (ha : IsSelfAdjoint a) (hspectrum : spectrum ℝ a ⊆ K) :
    ‖cfc f a - Polynomial.aeval a p‖ < epsilon := by
  rw [← cfc_polynomial p a ha,
    ← cfc_sub f p.eval a (hf.mono hspectrum) p.continuous.continuousOn]
  exact norm_cfc_lt hepsilon (fun x hx => hp x (hspectrum hx))

/-- The actual CFC is continuous on self-adjoint operators whose real
spectra stay in a fixed compact set, for a function continuous on that set. -/
theorem continuousOn_cfc_of_compact_window (f : ℝ → ℝ) (K : Set ℝ)
    (hK : IsCompact K) (hf : ContinuousOn f K) :
    ContinuousOn (fun a : A => cfc f a)
      {a | IsSelfAdjoint a ∧ spectrum ℝ a ⊆ K} := by
  intro a ha
  apply Metric.continuousWithinAt_iff.mpr
  intro epsilon hepsilon
  have hepsilon3 : 0 < epsilon / 3 := by linarith
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K hK f hf
    (epsilon / 3) hepsilon3
  obtain ⟨delta, hdelta, hpcont⟩ := Metric.continuousAt_iff.mp
    (p.continuousAt_aeval (a := a)) (epsilon / 3) hepsilon3
  refine ⟨delta, hdelta, fun b hb hab => ?_⟩
  have herrora := norm_cfc_sub_polynomial_lt f K hf p (epsilon / 3) hepsilon3 hp a ha.1 ha.2
  have herrorb := norm_cfc_sub_polynomial_lt f K hf p (epsilon / 3) hepsilon3 hp b hb.1 hb.2
  have hmiddle := hpcont hab
  have hfirst : dist (cfc f b) (Polynomial.aeval b p) < epsilon / 3 := by
    simpa only [dist_eq_norm] using herrorb
  have hlast : dist (Polynomial.aeval a p) (cfc f a) < epsilon / 3 := by
    simpa only [dist_eq_norm, norm_sub_rev] using herrora
  calc
    dist (cfc f b) (cfc f a) ≤
        dist (cfc f b) (Polynomial.aeval b p) + dist (Polynomial.aeval b p) (cfc f a) :=
      dist_triangle _ _ _
    _ ≤ dist (cfc f b) (Polynomial.aeval b p) +
        (dist (Polynomial.aeval b p) (Polynomial.aeval a p) +
          dist (Polynomial.aeval a p) (cfc f a)) :=
      add_le_add_left (dist_triangle _ _ _) _
    _ < epsilon := by linarith

/-- Local common-window version for a continuous operator family. -/
theorem continuousAt_cfc_of_local_spectral_window
    {X : Type*} [TopologicalSpace X] (H : X → A) (x : X)
    (hH : ContinuousAt H x) (f : ℝ → ℝ) (K : Set ℝ) (hK : IsCompact K)
    (hf : ContinuousOn f K)
    (hnear : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (H t) ∧ spectrum ℝ (H t) ⊆ K) :
    ContinuousAt (fun t => cfc f (H t)) x := by
  have htendsto : Tendsto H (𝓝 x)
      (𝓝[{a : A | IsSelfAdjoint a ∧ spectrum ℝ a ⊆ K}] H x) :=
    tendsto_nhdsWithin_iff.mpr ⟨hH, hnear⟩
  exact (continuousOn_cfc_of_compact_window f K hK hf (H x) hnear.self_of_nhds).tendsto.comp htendsto

variable [Nontrivial A]

/-- A real spectral window follows from the operator norm bound. -/
theorem real_spectrum_subset_Icc_of_norm_le (a : A) {R : ℝ} (hbound : ‖a‖ ≤ R) :
    spectrum ℝ a ⊆ Icc (-R) R := by
  intro y hy
  have hnorm : ‖y‖ ≤ R := (spectrum.norm_le_norm_of_mem hy).trans hbound
  exact abs_le.mp hnorm

theorem continuousAt_cfc_of_local_norm_bound
    {X : Type*} [TopologicalSpace X] (H : X → A) (x : X)
    (hH : ContinuousAt H x) (f : ℝ → ℝ) (R : ℝ)
    (hf : ContinuousOn f (Icc (-R) R))
    (hnear : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (H t) ∧ ‖H t‖ ≤ R) :
    ContinuousAt (fun t => cfc f (H t)) x := by
  apply continuousAt_cfc_of_local_spectral_window H x hH f (Icc (-R) R) isCompact_Icc hf
  filter_upwards [hnear] with t ht
  exact ⟨ht.1, real_spectrum_subset_Icc_of_norm_le (H t) ht.2⟩

/-- For a globally continuous real scalar function, continuity of the
operator family supplies its own local norm bound. Only local self-adjointness
remains as an explicit condition on the operator family. -/
theorem continuousAt_cfc_of_continuous
    {X : Type*} [TopologicalSpace X] (H : X → A) (x : X)
    (hH : ContinuousAt H x) (f : ℝ → ℝ) (hf : Continuous f)
    (hself : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (H t)) :
    ContinuousAt (fun t => cfc f (H t)) x := by
  have hbound : ∀ᶠ t in 𝓝 x, ‖H t‖ < ‖H x‖ + 1 :=
    hH.norm.eventually (gt_mem_nhds (by linarith : ‖H x‖ < ‖H x‖ + 1))
  apply continuousAt_cfc_of_local_norm_bound H x hH f (‖H x‖ + 1) hf.continuousOn
  filter_upwards [hself, hbound] with t ht hb
  exact ⟨ht, hb.le⟩

end CStarAlgebra

end CriticalDTM

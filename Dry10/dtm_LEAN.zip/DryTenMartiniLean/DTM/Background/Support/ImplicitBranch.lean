import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-!
# Scalar implicit-function machinery

These are generic helpers specializing Mathlib's real inverse-function
theorem to the graph-coordinate map (t,E) -> (t,F(t,E)). Invertibility is
proved from the nonzero energy coefficient; the local inverse applied to
(t,0) supplies the energy branch and the quotient derivative. The spectral
interpretation is supplied in
MagneticBranch and continuity of the slope in BranchRegularity. This file
does not prove analyticity or global continuation.
-/

/-!
# A local branch through a nondegenerate scalar zero

This is the ordinary two-variable implicit function theorem, with its
derivative and local uniqueness made explicit. It is independent of the
spectral interpretation: applications must supply the strict derivative
and the nonzero energy derivative of their scalar function.
-/

noncomputable section

namespace CriticalDTM

open Filter
open scoped Topology

/-- A linear functional on the real coordinate plane is determined by its
two coordinate values. -/
/- Routine two-coordinate expansion of a real continuous
linear functional; used to compute the inverse graph derivative. -/
theorem plane_linear_map_coordinates (D : (ℝ × ℝ) →L[ℝ] ℝ) (x y : ℝ) :
    D (x, y) = x * D (1, 0) + y * D (0, 1) := by
  have hp : (x, y) = x • ((1, 0) : ℝ × ℝ) + y • ((0, 1) : ℝ × ℝ) := by
    ext <;> simp
  rw [hp, map_add, map_smul, map_smul]
  rfl

/-- Derivative of the graph-coordinate map `(t,E) ↦ (t,F(t,E))`. -/
def graphDerivative (D : (ℝ × ℝ) →L[ℝ] ℝ) : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ) :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).prod D

/- Routine explicit linear inversion. Nonzero D(0,1) permits
solving D(u,y)=v as y=(v-u*D(1,0))/D(0,1), proving bijectivity. -/
theorem graphDerivative_bijective (D : (ℝ × ℝ) →L[ℝ] ℝ)
    (hD : D (0, 1) ≠ 0) : Function.Bijective (graphDerivative D) := by
  constructor
  · rintro ⟨px, py⟩ ⟨qx, qy⟩ hpq
    change (px, D (px, py)) = (qx, D (qx, qy)) at hpq
    have hfst : px = qx := congrArg Prod.fst hpq
    have hsnd : D (px, py) = D (qx, qy) := congrArg Prod.snd hpq
    apply Prod.ext hfst
    rw [plane_linear_map_coordinates D px py,
      plane_linear_map_coordinates D qx qy, hfst] at hsnd
    exact mul_right_cancel₀ hD (add_left_cancel hsnd)
  · rintro ⟨u, v⟩
    refine ⟨(u, (v - u * D (1, 0)) / D (0, 1)), ?_⟩
    apply Prod.ext
    · rfl
    · change D (u, (v - u * D (1, 0)) / D (0, 1)) = v
      rw [plane_linear_map_coordinates, div_mul_cancel₀ _ hD]
      ring

/-- The graph derivative is invertible exactly when its energy coefficient
is nonzero. Only the sufficient direction is needed here. -/
def graphDerivativeEquiv (D : (ℝ × ℝ) →L[ℝ] ℝ) (hD : D (0, 1) ≠ 0) :
    (ℝ × ℝ) ≃L[ℝ] (ℝ × ℝ) :=
  ContinuousLinearEquiv.ofBijective (graphDerivative D)
    (LinearMap.ker_eq_bot.mpr (graphDerivative_bijective D hD).1)
    (LinearMap.range_eq_top.mpr (graphDerivative_bijective D hD).2)

@[simp] theorem graphDerivativeEquiv_coe (D : (ℝ × ℝ) →L[ℝ] ℝ)
    (hD : D (0, 1) ≠ 0) :
    (graphDerivativeEquiv D hD : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) = graphDerivative D := by
  apply ContinuousLinearEquiv.coe_ofBijective

/- Routine formula for the inverse derivative. At direction
(1,0), the second coordinate is the implicit slope -D(1,0)/D(0,1). -/
theorem graphDerivativeEquiv_symm_apply (D : (ℝ × ℝ) →L[ℝ] ℝ)
    (hD : D (0, 1) ≠ 0) (u v : ℝ) :
    (graphDerivativeEquiv D hD).symm (u, v) =
      (u, (v - u * D (1, 0)) / D (0, 1)) := by
  apply (graphDerivativeEquiv D hD).injective
  rw [ContinuousLinearEquiv.apply_symm_apply]
  change (u, v) = (u, D (u, (v - u * D (1, 0)) / D (0, 1)))
  rw [plane_linear_map_coordinates, div_mul_cancel₀ _ hD]
  congr 1
  ring

/-- If the scalar function has nondegenerate derivatives throughout a
neighborhood, the same branch is differentiable throughout a neighborhood
of the coupling. No regularity of the prescribed derivative field is
required beyond the hypotheses displayed here. -/
/- Generic neighborhood refinement. The same partial
homeomorphism is differentiated at nearby inverse images, using nonzero
energy derivatives there. Continuous dependence of the derivative field is
not asserted here; BranchRegularity proves the additional actual C1 claim. -/
theorem exists_local_zero_branch_differentiable
    {F : ℝ × ℝ → ℝ} {D : (ℝ × ℝ) → (ℝ × ℝ) →L[ℝ] ℝ} {lam m : ℝ}
    (hF : HasStrictFDerivAt F (D (lam, m)) (lam, m))
    (hzero : F (lam, m) = 0) (hD : D (lam, m) (0, 1) ≠ 0)
    (hnear : ∀ᶠ p in 𝓝 (lam, m),
      HasFDerivAt F (D p) p ∧ D p (0, 1) ≠ 0) :
    ∃ e : ℝ → ℝ,
      e lam = m ∧
      HasDerivAt e (-D (lam, m) (1, 0) / D (lam, m) (0, 1)) lam ∧
      ContinuousAt e lam ∧
      Tendsto (fun t => (t, e t)) (𝓝 lam) (𝓝 (lam, m)) ∧
      (∀ᶠ t in 𝓝 lam, F (t, e t) = 0 ∧
        HasDerivAt e (-D (t, e t) (1, 0) / D (t, e t) (0, 1)) t) ∧
      (∀ᶠ p in 𝓝 (lam, m), F p = 0 → p.2 = e p.1) := by
  let T : ℝ × ℝ → ℝ × ℝ := fun p => (p.1, F p)
  let J := graphDerivativeEquiv (D (lam, m)) hD
  have hT : HasStrictFDerivAt T (J : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) (lam, m) := by
    simpa only [J, graphDerivativeEquiv_coe, graphDerivative] using
      (ContinuousLinearMap.fst ℝ ℝ ℝ).hasStrictFDerivAt.prodMk hF
  let φ := hT.toPartialHomeomorph T
  let G : ℝ × ℝ → ℝ × ℝ := φ.symm
  let e : ℝ → ℝ := fun t => (G (t, 0)).2
  have hbase : T (lam, m) = (lam, 0) := by simp [T, hzero]
  have htarget : (lam, 0) ∈ φ.target := by
    simpa only [φ, hbase] using hT.image_mem_toPartialHomeomorph_target
  have hGbase : G (lam, 0) = (lam, m) := by
    simpa only [G, φ, ← hT.localInverse_def, hbase] using hT.localInverse_apply_image
  have hebase : e lam = m := congrArg Prod.snd hGbase
  have hGcont : ContinuousAt G (lam, 0) := φ.symm.continuousAt htarget
  have hGtend : Tendsto G (𝓝 (lam, 0)) (𝓝 (lam, m)) := by
    simpa only [hGbase] using hGcont.tendsto
  have hin : ContinuousAt (fun t : ℝ => (t, (0 : ℝ))) lam :=
    continuousAt_id.prodMk continuousAt_const
  have hecont : ContinuousAt e lam := by
    have hc : ContinuousAt (fun t : ℝ => G (t, 0)) lam :=
      hGcont.comp (f := fun t : ℝ => (t, 0)) hin
    exact hc.snd
  have hgraph : Tendsto (fun t => (t, e t)) (𝓝 lam) (𝓝 (lam, m)) := by
    simpa only [hebase] using tendsto_id.prodMk_nhds hecont
  have htargetNear : ∀ᶠ t in 𝓝 lam, (t, (0 : ℝ)) ∈ φ.target :=
    hin.eventually (φ.open_target.mem_nhds htarget)
  have hderivNear : ∀ᶠ t in 𝓝 lam,
      HasFDerivAt F (D (G (t, 0))) (G (t, 0)) ∧ D (G (t, 0)) (0, 1) ≠ 0 :=
    hin.eventually (hGtend.eventually hnear)
  have heproperties : ∀ᶠ t in 𝓝 lam, F (t, e t) = 0 ∧
      HasDerivAt e (-D (t, e t) (1, 0) / D (t, e t) (0, 1)) t := by
    filter_upwards [htargetNear, hderivNear] with t ht hd
    have hright : T (G (t, 0)) = (t, 0) := φ.right_inv ht
    have hfst : (G (t, 0)).1 = t := congrArg Prod.fst hright
    have hsnd : F (G (t, 0)) = 0 := congrArg Prod.snd hright
    have heq : (t, e t) = G (t, 0) := Prod.ext hfst.symm rfl
    constructor
    · rw [heq]
      exact hsnd
    · let Jt := graphDerivativeEquiv (D (G (t, 0))) hd.2
      have hTt : HasFDerivAt φ (Jt : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) (G (t, 0)) := by
        simpa only [φ, HasStrictFDerivAt.toPartialHomeomorph_coe, Jt,
          graphDerivativeEquiv_coe, graphDerivative] using
          (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.prodMk hd.1
      have hGt := φ.hasFDerivAt_symm ht hTt
      have hline := (hasDerivAt_id t).prodMk (hasDerivAt_const t (0 : ℝ))
      have hh := (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt t
        (hGt.comp_hasDerivAt t hline)
      change HasDerivAt e ((Jt.symm (1, 0)).2) t at hh
      simpa only [Jt, graphDerivativeEquiv_symm_apply, one_mul, zero_sub, heq] using hh
  have hederiv : HasDerivAt e (-D (lam, m) (1, 0) / D (lam, m) (0, 1)) lam := by
    simpa only [hebase] using heproperties.self_of_nhds.2
  have hunique : ∀ᶠ p in 𝓝 (lam, m), F p = 0 → p.2 = e p.1 := by
    filter_upwards [φ.open_source.mem_nhds hT.mem_toPartialHomeomorph_source] with p hp hz
    have hh : G (p.1, 0) = p := by
      simpa only [G, φ, HasStrictFDerivAt.toPartialHomeomorph_coe, T, hz] using φ.left_inv hp
    exact (congrArg Prod.snd hh).symm
  exact ⟨e, hebase, hederiv, hecont, hgraph, heproperties, hunique⟩

end CriticalDTM

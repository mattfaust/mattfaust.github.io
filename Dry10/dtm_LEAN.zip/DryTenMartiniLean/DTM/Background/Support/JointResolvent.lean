import DTM.NewResults.Calculus.CouplingCalculus
import Mathlib.Analysis.Calculus.Deriv.Prod

/-!
# Joint resolvent regularity in coupling and energy

The parameter pair is ordered as (coupling, energy). The common resolvent
domain is open in the two complex parameters, and the actual resolvent and
its root matrix element are jointly analytic there.
-/

noncomputable section

namespace CriticalDTM

abbrev LatticeOperator := LatticeHilbert →L[ℂ] LatticeHilbert

def pencilLinear (α : ℝ) : (ℂ × ℂ) →L[ℂ] LatticeOperator :=
  (ContinuousLinearMap.snd ℂ ℂ ℂ).smulRight 1 -
    (ContinuousLinearMap.fst ℂ ℂ ℂ).smulRight (verticalOperator α)

def magneticPencil (α : ℝ) (p : ℂ × ℂ) : LatticeOperator :=
  pencilLinear α p - hOperator α 0

theorem magneticPencil_eq (α : ℝ) (p : ℂ × ℂ) :
    magneticPencil α p = algebraMap ℂ LatticeOperator p.2 - hOperator α p.1 := by
  rw [hOperator_affine, Algebra.algebraMap_eq_smul_one]
  change p.2 • (1 : LatticeOperator) - p.1 • verticalOperator α - hOperator α 0 = _
  abel

def jointResolventDomain (α : ℝ) : Set (ℂ × ℂ) :=
  {p | p.2 ∈ resolventSet ℂ (hOperator α p.1)}

theorem magneticPencil_continuous (α : ℝ) : Continuous (magneticPencil α) :=
  (pencilLinear α).continuous.sub continuous_const

theorem jointResolventDomain_isOpen (α : ℝ) : IsOpen (jointResolventDomain α) := by
  have h := Units.isOpen.preimage (magneticPencil_continuous α)
  simpa only [jointResolventDomain, magneticPencil_eq, Set.preimage_setOf_eq,
    spectrum.mem_resolventSet_iff] using h

theorem magneticPencil_hasStrictFDerivAt (α : ℝ) (p : ℂ × ℂ) :
    HasStrictFDerivAt (magneticPencil α) (pencilLinear α) p :=
  (pencilLinear α).hasStrictFDerivAt.sub_const _

theorem magneticPencil_analyticAt (α : ℝ) (p : ℂ × ℂ) :
    AnalyticAt ℂ (magneticPencil α) p :=
  ((pencilLinear α).analyticAt p).sub analyticAt_const

def jointResolvent (α : ℝ) (p : ℂ × ℂ) : LatticeOperator :=
  resolvent (hOperator α p.1) p.2

theorem jointResolvent_eq_inverse (α : ℝ) (p : ℂ × ℂ) :
    jointResolvent α p = Ring.inverse (magneticPencil α p) := by
  rw [magneticPencil_eq]
  rfl

def jointResolventDifferential (α : ℝ) (p : ℂ × ℂ) :
    (ℂ × ℂ) →L[ℂ] LatticeOperator :=
  (-ContinuousLinearMap.mulLeftRight ℂ LatticeOperator
    (jointResolvent α p) (jointResolvent α p)).comp (pencilLinear α)

theorem jointResolvent_hasStrictFDerivAt (α : ℝ) (p : ℂ × ℂ)
    (hp : p ∈ jointResolventDomain α) :
    HasStrictFDerivAt (jointResolvent α) (jointResolventDifferential α p) p := by
  have hu : IsUnit (magneticPencil α p) := by
    rw [magneticPencil_eq]
    exact hp
  have hi := hasStrictFDerivAt_ringInverse (𝕜 := ℂ) hu.unit
  rw [hu.unit_spec] at hi
  have hc := hi.comp p (magneticPencil_hasStrictFDerivAt α p)
  simpa only [jointResolventDifferential, Function.comp_def, ← Ring.inverse_of_isUnit hu,
    ← jointResolvent_eq_inverse] using hc

theorem jointResolvent_analyticAt (α : ℝ) (p : ℂ × ℂ)
    (hp : p ∈ jointResolventDomain α) : AnalyticAt ℂ (jointResolvent α) p := by
  have hu : IsUnit (magneticPencil α p) := by
    rw [magneticPencil_eq]
    exact hp
  have hi := analyticAt_inverse (𝕜 := ℂ) hu.unit
  rw [hu.unit_spec] at hi
  simpa only [Function.comp_def, ← jointResolvent_eq_inverse] using
    hi.comp (magneticPencil_analyticAt α p)

def jointGreen (α : ℝ) (p : ℂ × ℂ) : ℂ :=
  projectedGreen (hOperator α p.1) hilbertRoot p.2

def jointGreenDifferential (α : ℝ) (p : ℂ × ℂ) : (ℂ × ℂ) →L[ℂ] ℂ :=
  (innerSL ℂ hilbertRoot).comp
    ((ContinuousLinearMap.apply ℂ LatticeHilbert hilbertRoot).comp
      (jointResolventDifferential α p))

theorem jointGreen_hasStrictFDerivAt (α : ℝ) (p : ℂ × ℂ)
    (hp : p ∈ jointResolventDomain α) :
    HasStrictFDerivAt (jointGreen α) (jointGreenDifferential α p) p := by
  have hr := (ContinuousLinearMap.apply ℂ LatticeHilbert hilbertRoot).hasStrictFDerivAt.comp p
    (jointResolvent_hasStrictFDerivAt α p hp)
  have hg := (innerSL ℂ hilbertRoot).hasStrictFDerivAt.comp p hr
  exact hg

theorem jointGreen_analyticAt (α : ℝ) (p : ℂ × ℂ)
    (hp : p ∈ jointResolventDomain α) : AnalyticAt ℂ (jointGreen α) p := by
  have hr : AnalyticAt ℂ (fun q : ℂ × ℂ => jointResolvent α q hilbertRoot) p :=
    ((ContinuousLinearMap.apply ℂ LatticeHilbert hilbertRoot).analyticAt
      (jointResolvent α p)).comp (jointResolvent_analyticAt α p hp)
  exact ((innerSL ℂ hilbertRoot).analyticAt (jointResolvent α p hilbertRoot)).comp
    (f := fun q : ℂ × ℂ => jointResolvent α q hilbertRoot) hr

end CriticalDTM

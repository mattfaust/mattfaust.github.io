import DTM.Background.Realization.MagneticSpectralMeasure

/-!
# Proof guide: local calculus

Spectral-integral bridge for the actual operator calculus. At a
real resolvent energy, log|E-x| and (E-x)^(-1) are continuous on the separated
compact spectrum. CFC identifies the half trace-log with the constructed root
spectral integral; the DOS measure bridge identifies that measure with the
DOS. This is neither a real Thouless formula nor fixed-measure coupling calculus.
-/

/-!
# Spectral integrals for the actual magnetic logarithmic potential

All formulas in this module are restricted to actual resolvent energies.
They identify the constructed fixed-trace potential with a logarithmic
integral for the constructed spectral measure, without assuming a Thouless
formula or identifying a measure with a finite-volume IDS.
-/

noncomputable section

namespace CriticalDTM

open MeasureTheory
open scoped ContinuousFunctionalCalculus

set_option maxHeartbeats 800000

section GenericCFC

variable {A : Type*} [CStarAlgebra A]

/- Invertibility of E*1-H excludes a zero of E-x anywhere on the spectrum, before a bounded continuous logarithm is used. -/
theorem spectral_shift_ne_zero {H : A} (energy : ℝ)
    (hunit : IsUnit (energy • (1 : A) - H))
    {x : ℝ} (hx : x ∈ spectrum ℝ H) : energy - x ≠ 0 := by
  intro hzero
  have heq : energy = x := sub_eq_zero.mp hzero
  subst x
  change ¬ IsUnit (algebraMap ℝ A energy - H) at hx
  exact hx (by simpa only [Algebra.algebraMap_eq_smul_one] using hunit)

theorem cfc_real_pencil (H : A) (hH : IsSelfAdjoint H) (energy : ℝ) :
    cfc (fun x : ℝ => energy - x) H = energy • (1 : A) - H := by
  rw [cfc_sub (fun _ : ℝ => energy) (fun x : ℝ => x) H,
    cfc_const energy H hH, cfc_id' ℝ H hH, Algebra.algebraMap_eq_smul_one]

/- The continuous spectral kernel (E-x)^(-1) represents the actual pencil inverse on its resolvent domain. -/
theorem cfc_inverse_real_pencil (H : A) (hH : IsSelfAdjoint H) (energy : ℝ)
    (hunit : IsUnit (energy • (1 : A) - H)) :
    cfc (fun x : ℝ => (energy - x)⁻¹) H =
      Ring.inverse (energy • (1 : A) - H) := by
  rw [cfc_inv (fun x : ℝ => energy - x) H
    (fun _ hx => spectral_shift_ne_zero energy hunit hx), cfc_real_pencil H hH energy]

/- Trace-potential identity: CFC composition and log((E-x)^2)=2*log|E-x| identify the square logarithm with twice the scalar log kernel. -/
theorem cfc_log_squared_real_pencil (H : A) (hH : IsSelfAdjoint H) (energy : ℝ)
    (hunit : IsUnit (energy • (1 : A) - H)) :
    CFC.log ((energy • (1 : A) - H) ^ 2) =
      (2 : ℝ) • cfc (fun x : ℝ => Real.log |energy - x|) H := by
  have hf : ContinuousOn (fun x : ℝ => (energy - x) ^ 2) (spectrum ℝ H) := by fun_prop
  have hlog : ContinuousOn Real.log ((fun x : ℝ => (energy - x) ^ 2) '' spectrum ℝ H) := by
    apply Real.continuousOn_log.mono
    rintro _ ⟨x, hx, rfl⟩
    exact pow_ne_zero 2 (spectral_shift_ne_zero energy hunit hx)
  have hlogabs : ContinuousOn (fun x : ℝ => Real.log |energy - x|) (spectrum ℝ H) :=
    ((continuous_const.sub continuous_id).continuousOn.abs).log
      (fun x hx => abs_ne_zero.mpr (spectral_shift_ne_zero energy hunit hx))
  have hsquare : cfc (fun x : ℝ => (energy - x) ^ 2) H =
      (energy • (1 : A) - H) ^ 2 := by
    rw [cfc_pow (fun x : ℝ => energy - x) 2 H, cfc_real_pencil H hH energy]
  calc
    CFC.log ((energy • (1 : A) - H) ^ 2) =
        cfc (fun x : ℝ => Real.log ((energy - x) ^ 2)) H := by
      change cfc Real.log _ = _
      rw [← hsquare]
      exact (cfc_comp' Real.log (fun x : ℝ => (energy - x) ^ 2) H hlog hf hH).symm
    _ = cfc (fun x : ℝ => (2 : ℝ) * Real.log |energy - x|) H := by
      apply cfc_congr
      intro x _
      change Real.log ((energy - x) ^ 2) = 2 * Real.log |energy - x|
      rw [Real.log_pow, Real.log_abs]
      norm_num
    _ = (2 : ℝ) • cfc (fun x : ℝ => Real.log |energy - x|) H :=
      cfc_const_mul 2 (fun x : ℝ => Real.log |energy - x|) H hlogabs

end GenericCFC

/-- Only continuity on the actual compact spectrum is needed for a spectral
test function; its behavior elsewhere is irrelevant. -/
/- Only continuity on the actual compact spectrum is required, not across the excluded singular energy E. -/
theorem magneticSpectralMeasure_integral_cfc_of_continuousOn (α lam : ℝ)
    (f : ℝ → ℝ)
    (hf : ContinuousOn f (spectrum ℝ (magneticAlgebraHamiltonian α lam))) :
    ∫ x : MagneticRealSpectrum α lam, f x ∂magneticSpectralMeasure α lam =
      magneticTraceReal α (cfc f (magneticAlgebraHamiltonian α lam)) := by
  rw [cfc_apply f (magneticAlgebraHamiltonian α lam)
    (magneticAlgebraHamiltonian_isSelfAdjoint α lam) hf]
  exact magneticSpectralMeasure_integral α lam ⟨_, hf.restrict⟩

theorem magnetic_spectral_shift_ne_zero (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (x : MagneticRealSpectrum α lam) : energy - (x : ℝ) ≠ 0 :=
  spectral_shift_ne_zero energy (magneticAlgebraPencil_isUnit α lam energy hm) x.property

/- Spectral separation proves continuity of log|E-x| on the compact spectral subtype. -/
theorem magnetic_log_kernel_continuous (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    Continuous (fun x : MagneticRealSpectrum α lam => Real.log |energy - (x : ℝ)|) :=
  (continuous_const.sub continuous_subtype_val).abs.log
    (fun x => abs_ne_zero.mpr (magnetic_spectral_shift_ne_zero α lam energy hm x))

theorem magnetic_green_kernel_continuous (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    Continuous (fun x : MagneticRealSpectrum α lam => (energy - (x : ℝ))⁻¹) :=
  (continuous_const.sub continuous_subtype_val).inv₀
    (magnetic_spectral_shift_ne_zero α lam energy hm)

/-- The actual trace-log potential is the logarithmic integral of the
constructed canonical spectral probability measure at a resolvent energy. -/
/- Apply the fixed trace to the CFC identity and cancel the factor two. No transfer Lyapunov exponent occurs. -/
theorem magneticLogPotential_eq_spectralIntegral (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticLogPotential α lam energy =
      ∫ x : MagneticRealSpectrum α lam,
        Real.log |energy - (x : ℝ)| ∂magneticSpectralMeasure α lam := by
  have hcont : ContinuousOn (fun x : ℝ => Real.log |energy - x|)
      (spectrum ℝ (magneticAlgebraHamiltonian α lam)) :=
    continuousOn_iff_continuous_restrict.mpr (magnetic_log_kernel_continuous α lam energy hm)
  change magneticTraceReal α
    (CFC.log ((energy • (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α lam) ^ 2)) / 2 = _
  rw [cfc_log_squared_real_pencil _ (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
    energy (magneticAlgebraPencil_isUnit α lam energy hm), map_smul]
  change (2 * magneticTraceReal α
    (cfc (fun x : ℝ => Real.log |energy - x|) (magneticAlgebraHamiltonian α lam))) / 2 = _
  rw [mul_div_cancel_left₀ _ (by norm_num : (2 : ℝ) ≠ 0)]
  exact (magneticSpectralMeasure_integral_cfc_of_continuousOn α lam _ hcont).symm

/-- The projected Green function is the Stieltjes integral of the same
constructed spectral probability measure, with convention `(E−x)⁻¹`. -/
/- Supporting energy interpretation: the same probability measure gives g(E)=integral (E-x)^(-1), with the stated sign convention. -/
theorem realProjectedGreen_eq_spectralIntegral (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot energy =
      ∫ x : MagneticRealSpectrum α lam,
        (energy - (x : ℝ))⁻¹ ∂magneticSpectralMeasure α lam := by
  have hcont : ContinuousOn (fun x : ℝ => (energy - x)⁻¹)
      (spectrum ℝ (magneticAlgebraHamiltonian α lam)) :=
    continuousOn_iff_continuous_restrict.mpr (magnetic_green_kernel_continuous α lam energy hm)
  rw [magneticSpectralMeasure_integral_cfc_of_continuousOn α lam _ hcont,
    cfc_inverse_real_pencil _ (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
      energy (magneticAlgebraPencil_isUnit α lam energy hm)]
  exact (magneticTraceReal_inverse_eq_green α lam energy hm).symm

/-- The pushforward change of variables is valid for any test function;
global continuity at the omitted resolvent energy is not required. -/
/- Push the compact-spectrum measure to the real line without imposing global continuity at E. -/
theorem magneticRealSpectralMeasure_integral_eq_subtype (α lam : ℝ) (f : ℝ → ℝ) :
    ∫ x, f x ∂magneticRealSpectralMeasure α lam =
      ∫ x : MagneticRealSpectrum α lam, f x ∂magneticSpectralMeasure α lam := by
  rw [magneticRealSpectralMeasure]
  exact (MeasurableEmbedding.subtype_coe
    (spectrum.isClosed (𝕜 := ℝ) (magneticAlgebraHamiltonian α lam)).measurableSet).integral_map f

/- Real-line bridge to Phi: combine this actual trace-log integral with the identification of the constructed measure as the DOS. -/
theorem magneticLogPotential_eq_realSpectralIntegral (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticLogPotential α lam energy =
      ∫ x : ℝ, Real.log |energy - x| ∂magneticRealSpectralMeasure α lam := by
  rw [magneticRealSpectralMeasure_integral_eq_subtype]
  exact magneticLogPotential_eq_spectralIntegral α lam energy hm

end CriticalDTM

import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Basic
import Mathlib.Analysis.CStarAlgebra.Spectrum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith

/-!
# Proof guide: local calculus

Positive rescaling for the tracial logarithm derivative. The explicit fixed
basepoint scale c=(norm(C)^2+1)^(-1) gives norm(1-c C^2)<1 for an invertible
self-adjoint C. Compact spectral calculus and exclusion of zero prove strictness;
continuity later makes this a uniform local bound. No logarithm derivative is
assumed, and the scale is not a parameter-dependent normalization.
-/

/-!
# Positive rescaling of an invertible self-adjoint square

The explicit scale `c = (‖C‖²+1)⁻¹` puts `c • C²` strictly within distance
one of the identity. The strict estimate follows from the actual continuous
functional calculus on the compact spectrum of `C`, using invertibility to
exclude zero. No inverse-norm lower bound is assumed.
-/

noncomputable section

namespace CriticalDTM

variable {A : Type*} [CStarAlgebra A]

/- Spectral check: invertibility excludes zero from the real spectrum, providing strictness in the logarithmic-series radius. -/
theorem real_spectral_ne_zero_of_isUnit {C : A} (hC : IsUnit C)
    {x : ℝ} (hx : x ∈ spectrum ℝ C) : x ≠ 0 := by
  intro hx0
  subst x
  exact (spectrum.zero_not_mem_iff ℝ).mpr hC hx

/- Logarithm domain: spectral mapping sends each nonzero real spectral value to a positive square. -/
theorem selfAdjoint_square_spectrum_pos {C : A} (hC : IsSelfAdjoint C)
    (hinv : IsUnit C) {x : ℝ} (hx : x ∈ spectrum ℝ (C * C)) : 0 < x := by
  have hmap : spectrum ℝ (C * C) = (fun t : ℝ => t ^ 2) '' spectrum ℝ C := by
    rw [← pow_two, ← cfc_pow_id (R := ℝ) C 2 hC]
    exact cfc_map_spectrum (fun t : ℝ => t ^ 2) C hC
  rw [hmap] at hx
  obtain ⟨t, ht, rfl⟩ := hx
  exact sq_pos_of_ne_zero (real_spectral_ne_zero_of_isUnit hinv ht)

/- Explicit scale: 0<c*x^2<1 on the compact spectrum. Its continuous maximum gives an operator defect with norm strictly below one. -/
theorem selfAdjoint_square_rescaling_bound {C : A} (hC : IsSelfAdjoint C)
    (hinv : IsUnit C) : ‖1 - (‖C‖ ^ 2 + 1)⁻¹ • (C * C)‖ < 1 := by
  let c : ℝ := (‖C‖ ^ 2 + 1)⁻¹
  have hden : 0 < ‖C‖ ^ 2 + 1 := by positivity
  have hc : 0 < c := inv_pos.mpr hden
  have hs : ∀ t ∈ spectrum ℝ C, ‖1 - c * t ^ 2‖ < 1 := by
    intro t ht
    have ht0 := real_spectral_ne_zero_of_isUnit hinv ht
    have htbound : |t| ≤ ‖C‖ := by
      have h := norm_apply_le_norm_cfc (fun x : ℝ => x) C ht (by fun_prop) hC
      simpa only [Real.norm_eq_abs, cfc_id' ℝ C hC] using h
    have ht2 : t ^ 2 ≤ ‖C‖ ^ 2 := by
      have h := (sq_le_sq₀ (abs_nonneg t) (norm_nonneg C)).mpr htbound
      simpa only [sq_abs] using h
    have hpos : 0 < c * t ^ 2 := mul_pos hc (sq_pos_of_ne_zero ht0)
    have hlt : c * t ^ 2 < 1 := by
      dsimp [c]
      rw [mul_comm, ← div_eq_mul_inv]
      exact (div_lt_one hden).mpr (by linarith)
    rw [Real.norm_eq_abs]
    exact abs_lt.mpr ⟨by linarith, by linarith⟩
  have hnorm : ‖cfc (fun t : ℝ => 1 - c * t ^ 2) C‖ < 1 :=
    norm_cfc_lt zero_lt_one hs
  have heq : cfc (fun t : ℝ => 1 - c * t ^ 2) C = 1 - c • (C * C) := by
    rw [cfc_sub (fun _ : ℝ => 1) (fun t : ℝ => c * t ^ 2) C,
      cfc_const_one ℝ C hC, cfc_const_mul c (fun t : ℝ => t ^ 2) C,
      cfc_pow_id (R := ℝ) C 2 hC, pow_two]
  rw [heq] at hnorm
  exact hnorm

/- Local construction input: an actual positive scale is supplied, not an assumed logarithm-differentiability statement. -/
theorem exists_positive_selfAdjoint_square_rescaling {C : A}
    (hC : IsSelfAdjoint C) (hinv : IsUnit C) :
    ∃ c : ℝ, 0 < c ∧ ‖1 - c • (C * C)‖ < 1 := by
  refine ⟨(‖C‖ ^ 2 + 1)⁻¹, ?_, selfAdjoint_square_rescaling_bound hC hinv⟩
  positivity

end CriticalDTM

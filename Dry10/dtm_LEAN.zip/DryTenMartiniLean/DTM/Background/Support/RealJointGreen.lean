import DTM.Background.Support.JointResolvent

/-!
# Actual joint Green derivative and energy nondegeneracy

These routine operator-calculus helpers restrict the complex joint
resolvent derivative to real (coupling, energy) coordinates and take the
root matrix entry's real part. The energy coefficient is -||R Omega||^2,
strictly negative because Omega != 0 and R is invertible. This supplies the
hypotheses of the local implicit-function theorem. It is not a theorem of
analytic branch regularity and contains no critical persistence argument.
-/

/-!
# A real joint Green function with a nonzero energy derivative

These are the actual operator hypotheses for the implicit-function theorem.
They are derived from the jointly analytic resolvent and the negative squared
norm formula. The coordinates are (coupling, energy).
-/

noncomputable section

namespace CriticalDTM

def realPairToComplex : (ℝ × ℝ) →L[ℝ] (ℂ × ℂ) :=
  (Complex.ofRealCLM.comp (ContinuousLinearMap.fst ℝ ℝ ℝ)).prod
    (Complex.ofRealCLM.comp (ContinuousLinearMap.snd ℝ ℝ ℝ))

@[simp] theorem realPairToComplex_apply (p : ℝ × ℝ) :
    realPairToComplex p = ((p.1 : ℂ), (p.2 : ℂ)) := rfl

def realJointResolventDomain (α : ℝ) : Set (ℝ × ℝ) :=
  {p | (p.2 : ℂ) ∈ resolventSet ℂ (hOperator α (p.1 : ℂ))}

/- Routine openness: the real joint resolvent domain is the
continuous preimage of the complex joint domain. -/
theorem realJointResolventDomain_isOpen (α : ℝ) : IsOpen (realJointResolventDomain α) :=
  (jointResolventDomain_isOpen α).preimage realPairToComplex.continuous

def realJointGreen (α : ℝ) (p : ℝ × ℝ) : ℝ :=
  (jointGreen α (realPairToComplex p)).re

def realJointGreenDifferential (α : ℝ) (p : ℝ × ℝ) : (ℝ × ℝ) →L[ℝ] ℝ :=
  Complex.reCLM.comp
    (((jointGreenDifferential α (realPairToComplex p)).restrictScalars ℝ).comp
      realPairToComplex)

/- Routine restriction of scalars and composition with the
real-part functional. The strict derivative is proved for the actual
operator expression, not supplied as an application-specific assumption. -/
theorem realJointGreen_hasStrictFDerivAt (α : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    HasStrictFDerivAt (realJointGreen α) (realJointGreenDifferential α p) p := by
  have hc := (jointGreen_hasStrictFDerivAt α (realPairToComplex p) hp).restrictScalars ℝ
  have hr := hc.comp p realPairToComplex.hasStrictFDerivAt
  exact Complex.reCLM.hasStrictFDerivAt.comp p hr

/-- The energy partial derivative is the negative squared actual column norm. -/
/- Identify the energy direction by derivative uniqueness:
compose with the line t -> (lambda,t), then compare with the independently
proved real-energy root Green derivative -||R Omega||^2. -/
theorem realJointGreen_energy_partial (α lam m : ℝ)
    (hm : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    realJointGreenDifferential α (lam, m) (0, 1) =
      -(‖resolvent (hOperator α (lam : ℂ)) (m : ℂ) hilbertRoot‖ ^ 2) := by
  have hline := (hasDerivAt_const m lam).prodMk (hasDerivAt_id m)
  have hchain := (realJointGreen_hasStrictFDerivAt α (lam, m) hm).hasFDerivAt.comp_hasDerivAt
    m hline
  have hactual : HasDerivAt (fun t : ℝ => realJointGreen α (lam, t))
      (-(‖resolvent (hOperator α (lam : ℂ)) (m : ℂ) hilbertRoot‖ ^ 2)) m := by
    simpa only [realJointGreen, realPairToComplex_apply, jointGreen, projectedGreen,
      Complex.ofReal_re] using
      (projected_green_hasDerivAt (hOperator α (lam : ℂ))
        (hOperator_isSelfAdjoint α lam) hilbertRoot m hm).real_of_complex
  exact hchain.unique hactual

/- Strict sign uses the nonzero actual resolvent column;
invertibility sends R Omega = 0 back to the impossible Omega = 0. -/
theorem realJointGreen_energy_partial_neg (α lam m : ℝ)
    (hm : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    realJointGreenDifferential α (lam, m) (0, 1) < 0 := by
  rw [realJointGreen_energy_partial α lam m hm]
  have hn := actual_resolvent_column_ne_zero (hOperator α (lam : ℂ)) hilbertRoot
    hilbertRoot_ne_zero (m : ℂ) hm
  exact neg_neg_of_pos (sq_pos_of_pos (norm_pos_iff.mpr hn))

/- Routine nondegeneracy corollary used as the denominator
condition in the graph inverse and in the continuous slope quotient. -/
theorem realJointGreen_energy_partial_ne_zero (α lam m : ℝ)
    (hm : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    realJointGreenDifferential α (lam, m) (0, 1) ≠ 0 :=
  ne_of_lt (realJointGreen_energy_partial_neg α lam m hm)

end CriticalDTM

import DTM.NewResults.Boundary.Stationary
import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.Analysis.Complex.RealDeriv

/-!
# Analytic facts about the actual operator resolvent

Here `resolvent H z` is mathlib's inverse of `z • 1 - H` in the
Banach algebra of bounded operators. Membership in `resolventSet ℂ H`
is required wherever inversion or differentiation is used.

The derivative formula is proved using mathlib's Banach-algebra resolvent
theorem, not assumed. At real energies the resolvent of a self-adjoint
operator is self-adjoint, so the projected Green function has derivative
`-‖R root‖²`. These results supply analytic inputs for the abstract stationary
argument, but do not define an almost Mathieu operator or establish its
spectral gap structure.
-/

noncomputable section

namespace CriticalDTM

open scoped Topology

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]

/-- Differentiability of the actual bounded-operator resolvent. -/
theorem operator_resolvent_hasDerivAt
    (H : E →L[ℂ] E) (z : ℂ) (hz : z ∈ resolventSet ℂ H) :
    HasDerivAt (resolvent H)
      (-(resolvent H z * resolvent H z)) z := by
  simpa only [pow_two] using spectrum.hasDerivAt_resolvent hz

/-- Self-adjointness of a resolvent at a real energy. The statement also
holds at spectral energies under mathlib's totalized inverse convention,
but its analytic uses below always require resolvent-set membership. -/
theorem real_resolvent_isSelfAdjoint
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (m : ℝ) :
    IsSelfAdjoint (resolvent H (m : ℂ)) := by
  have hm : IsSelfAdjoint (m : ℂ) := Complex.conj_ofReal m
  have hshift : IsSelfAdjoint (algebraMap ℂ (E →L[ℂ] E) (m : ℂ) - H) :=
    (hm.algebraMap (E →L[ℂ] E)).sub hH
  change star (Ring.inverse (algebraMap ℂ (E →L[ℂ] E) (m : ℂ) - H)) =
    Ring.inverse (algebraMap ℂ (E →L[ℂ] E) (m : ℂ) - H)
  rw [← Ring.inverse_star, hshift.star_eq]

/-- Applying the operator derivative to a fixed root gives the column
derivative `-R² root`. -/
theorem resolvent_column_hasDerivAt
    (H : E →L[ℂ] E) (root : E) (z : ℂ) (hz : z ∈ resolventSet ℂ H) :
    HasDerivAt (fun w => resolvent H w root)
      (-resolvent H z (resolvent H z root)) z := by
  have hd := (operator_resolvent_hasDerivAt H z hz).clm_apply
    (hasDerivAt_const z root)
  simpa only [map_zero, add_zero, ContinuousLinearMap.mul_apply,
    ContinuousLinearMap.neg_apply] using hd

omit [CompleteSpace E] in
/-- The actual resolvent column of a nonzero root is nonzero. -/
theorem actual_resolvent_column_ne_zero
    (H : E →L[ℂ] E) (root : E) (hroot : root ≠ 0)
    (z : ℂ) (hz : z ∈ resolventSet ℂ H) :
    resolvent H z root ≠ 0 := by
  apply resolvent_column_ne_zero (algebraMap ℂ (E →L[ℂ] E) z - H)
    (resolvent H z) root hroot
  intro x
  have hproduct := Ring.mul_inverse_cancel
    (algebraMap ℂ (E →L[ℂ] E) z - H) hz
  have happlied := congrArg (fun A : E →L[ℂ] E => A x) hproduct
  simpa only [resolvent, ContinuousLinearMap.mul_apply,
    ContinuousLinearMap.one_apply] using happlied

/-- The projected Green function has the negative squared resolvent-column
norm as its complex derivative at every real resolvent energy. -/
theorem projected_green_hasDerivAt
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E)
    (m : ℝ) (hm : (m : ℂ) ∈ resolventSet ℂ H) :
    HasDerivAt (fun z => @inner ℂ E _ root (resolvent H z root))
      ((-(‖resolvent H (m : ℂ) root‖ ^ 2) : ℝ) : ℂ) (m : ℂ) := by
  have hR : SymmetricOperator (resolvent H (m : ℂ)) :=
    (symmetricOperator_iff_isSelfAdjoint _).mpr (real_resolvent_isSelfAdjoint H hH m)
  have hvalue : @inner ℂ E _ root
      (-resolvent H (m : ℂ) (resolvent H (m : ℂ) root)) =
      ((-(‖resolvent H (m : ℂ) root‖ ^ 2) : ℝ) : ℂ) := by
    rw [inner_neg_right, ← hR root (resolvent H (m : ℂ) root),
      inner_self_eq_norm_sq_to_K]
    simp only [Complex.ofReal_neg, Complex.ofReal_pow]
    rfl
  have hd := (innerSL ℂ root).hasFDerivAt.comp_hasDerivAt (m : ℂ)
    (resolvent_column_hasDerivAt H root (m : ℂ) hm)
  simpa only [Function.comp_def, innerSL_apply, hvalue] using hd

/-- The real-energy version used for the energy derivative in the paper.
The function remains complex-valued; its derivative is explicitly real. -/
theorem projected_green_hasRealDerivAt
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E)
    (m : ℝ) (hm : (m : ℂ) ∈ resolventSet ℂ H) :
    HasDerivAt (fun t : ℝ => @inner ℂ E _ root (resolvent H (t : ℂ) root))
      ((-(‖resolvent H (m : ℂ) root‖ ^ 2) : ℝ) : ℂ) m :=
  (projected_green_hasDerivAt H hH root m hm).comp_ofReal

end CriticalDTM

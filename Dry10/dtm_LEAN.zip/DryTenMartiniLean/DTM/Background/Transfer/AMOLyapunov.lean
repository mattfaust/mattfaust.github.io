import DTM.Background.Transfer.AMOTransfer
import Mathlib.Analysis.Subadditive
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Topology.Semicontinuous

/-!
# The phase-averaged transfer Lyapunov exponent

Every finite level is the phase average of the logarithm of the actual
Euclidean operator norm of the almost Mathieu transfer product. Periodic
change of variables proves subadditivity; Fekete's lemma then identifies
the real-valued infimum with the limit. Neither a density-of-states
potential nor a spectral vanishing property is used to define this exponent.
-/

noncomputable section

open Filter MeasureTheory Set
open scoped Topology

namespace CriticalDTM

/-- Logarithm of the actual finite transfer-product operator norm. -/
def amoTransferLogNorm (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) : ℝ :=
  Real.log (amoTransferNorm (amoTransferProduct α lam z θ n))

/-- Phase average with normalized Lebesgue measure on one radian period. -/
def amoTransferLogAverage (α lam : ℝ) (z : ℂ) (n : ℕ) : ℝ :=
  (∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm α lam z θ n) / (2 * Real.pi)

/-- Finite-scale averaged Lyapunov exponent; the unused zero scale equals zero. -/
def amoFiniteLyapunov (α lam : ℝ) (z : ℂ) (n : ℕ) : ℝ :=
  amoTransferLogAverage α lam z n / (n : ℝ)

/-- The averaged transfer exponent, defined independently of the DOS potential. -/
def amoLyapunov (α lam : ℝ) (z : ℂ) : ℝ :=
  sInf ((fun n => amoFiniteLyapunov α lam z n) '' Ici 1)

theorem amoTransferLogNorm_nonneg (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    0 ≤ amoTransferLogNorm α lam z θ n :=
  Real.log_nonneg (one_le_amoTransferProduct_norm α lam z θ n)

@[simp] theorem amoTransferLogNorm_zero (α lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransferLogNorm α lam z θ 0 = 0 := by
  simp [amoTransferLogNorm]

@[simp] theorem amoTransferLogAverage_zero (α lam : ℝ) (z : ℂ) :
    amoTransferLogAverage α lam z 0 = 0 := by
  simp [amoTransferLogAverage]

@[simp] theorem amoFiniteLyapunov_zero (α lam : ℝ) (z : ℂ) :
    amoFiniteLyapunov α lam z 0 = 0 := by
  simp [amoFiniteLyapunov]

/-- The finite logarithm is continuous because determinant one excludes zero norm. -/
theorem continuous_amoTransferLogNorm (n : ℕ) :
    Continuous (fun p : ℝ × ℝ × ℂ × ℝ =>
      amoTransferLogNorm p.1 p.2.1 p.2.2.1 p.2.2.2 n) := by
  exact (continuous_amoTransferNorm.comp (continuous_amoTransferProduct n)).log
    (fun p => ne_of_gt (amoTransferProduct_norm_pos p.1 p.2.1 p.2.2.1 p.2.2.2 n))

theorem continuous_amoTransferLogNorm_phase (α lam : ℝ) (z : ℂ) (n : ℕ) :
    Continuous (fun θ => amoTransferLogNorm α lam z θ n) := by
  have h := (continuous_amoTransferLogNorm n).comp
    (show Continuous (fun θ : ℝ => (α, lam, z, θ)) by fun_prop)
  exact h

theorem amoTransferLogNorm_intervalIntegrable (α lam : ℝ) (z : ℂ) (n : ℕ) (a b : ℝ) :
    IntervalIntegrable (fun θ => amoTransferLogNorm α lam z θ n) volume a b :=
  (continuous_amoTransferLogNorm_phase α lam z n).intervalIntegrable a b

theorem amoTransferLogNorm_periodic (α lam : ℝ) (z : ℂ) (n : ℕ) :
    Function.Periodic (fun θ => amoTransferLogNorm α lam z θ n) (2 * Real.pi) := by
  intro θ
  exact congrArg (fun M => Real.log (amoTransferNorm M))
    (amoTransferProduct_periodic α lam z n θ)

/-- The integrated finite logarithm is invariant under every real phase shift. -/
theorem amoTransferLogNorm_integral_shift (α lam : ℝ) (z : ℂ) (n : ℕ) (t : ℝ) :
    (∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm α lam z (θ + t) n) =
      ∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm α lam z θ n := by
  rw [intervalIntegral.integral_comp_add_right
    (fun θ => amoTransferLogNorm α lam z θ n) t]
  simpa only [zero_add, add_comm (2 * Real.pi) t] using
    (amoTransferLogNorm_periodic α lam z n).intervalIntegral_add_eq t 0

/-- Pointwise subadditivity, with the phase shift dictated by the transfer cocycle. -/
theorem amoTransferLogNorm_add_le (α lam : ℝ) (z : ℂ) (θ : ℝ) (m n : ℕ) :
    amoTransferLogNorm α lam z θ (m + n) ≤
      amoTransferLogNorm α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m +
        amoTransferLogNorm α lam z θ n := by
  unfold amoTransferLogNorm
  rw [amoTransferProduct_add]
  calc
    Real.log (amoTransferNorm
        (amoTransferProduct α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m *
          amoTransferProduct α lam z θ n)) ≤
        Real.log (amoTransferNorm
          (amoTransferProduct α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m) *
            amoTransferNorm (amoTransferProduct α lam z θ n)) := by
      apply Real.log_le_log
      · rw [← amoTransferProduct_add]
        exact amoTransferProduct_norm_pos α lam z θ (m + n)
      · exact amoTransferNorm_mul_le _ _
    _ = _ := Real.log_mul
      (ne_of_gt (amoTransferProduct_norm_pos α lam z _ m))
      (ne_of_gt (amoTransferProduct_norm_pos α lam z θ n))

/-- Subadditivity is proved by integrating the true shifted cocycle bound. -/
theorem amoTransferLogAverage_subadditive (α lam : ℝ) (z : ℂ) :
    Subadditive (amoTransferLogAverage α lam z) := by
  intro m n
  unfold amoTransferLogAverage
  rw [← add_div]
  apply div_le_div_of_nonneg_right _ (by positivity)
  have hm : IntervalIntegrable
      (fun θ => amoTransferLogNorm α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m)
      volume 0 (2 * Real.pi) :=
    ((continuous_amoTransferLogNorm_phase α lam z m).comp
      (show Continuous (fun θ : ℝ => θ + 2 * Real.pi * α * (n : ℝ)) from
        continuous_id.add continuous_const)).intervalIntegrable _ _
  have hn := amoTransferLogNorm_intervalIntegrable α lam z n 0 (2 * Real.pi)
  calc
    (∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm α lam z θ (m + n)) ≤
        ∫ θ in (0 : ℝ)..(2 * Real.pi),
          (amoTransferLogNorm α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m +
            amoTransferLogNorm α lam z θ n) := by
      exact intervalIntegral.integral_mono (by positivity)
        (amoTransferLogNorm_intervalIntegrable α lam z (m + n) 0 (2 * Real.pi))
        (hm.add hn) (fun θ => amoTransferLogNorm_add_le α lam z θ m n)
    _ = (∫ θ in (0 : ℝ)..(2 * Real.pi),
          amoTransferLogNorm α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m) +
        ∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm α lam z θ n :=
      intervalIntegral.integral_add hm hn
    _ = _ := by rw [amoTransferLogNorm_integral_shift]

theorem amoTransferLogAverage_nonneg (α lam : ℝ) (z : ℂ) (n : ℕ) :
    0 ≤ amoTransferLogAverage α lam z n := by
  apply div_nonneg _ (by positivity)
  exact intervalIntegral.integral_nonneg (by positivity)
    (fun θ _ => amoTransferLogNorm_nonneg α lam z θ n)

theorem amoFiniteLyapunov_nonneg (α lam : ℝ) (z : ℂ) (n : ℕ) :
    0 ≤ amoFiniteLyapunov α lam z n :=
  div_nonneg (amoTransferLogAverage_nonneg α lam z n) (Nat.cast_nonneg n)

theorem amoFiniteLyapunov_bddBelow (α lam : ℝ) (z : ℂ) :
    BddBelow (range (amoFiniteLyapunov α lam z)) := by
  refine ⟨0, ?_⟩
  rintro _ ⟨n, rfl⟩
  exact amoFiniteLyapunov_nonneg α lam z n

theorem amoLyapunov_nonneg (α lam : ℝ) (z : ℂ) : 0 ≤ amoLyapunov α lam z := by
  apply le_csInf (show ((fun n => amoFiniteLyapunov α lam z n) '' Ici 1).Nonempty from
    ⟨amoFiniteLyapunov α lam z 1, 1, by simp, rfl⟩)
  rintro _ ⟨n, _, rfl⟩
  exact amoFiniteLyapunov_nonneg α lam z n

/-- Every positive finite level bounds the real-valued transfer exponent from above. -/
theorem amoLyapunov_le_finite (α lam : ℝ) (z : ℂ) {n : ℕ} (hn : 1 ≤ n) :
    amoLyapunov α lam z ≤ amoFiniteLyapunov α lam z n :=
  csInf_le ((amoFiniteLyapunov_bddBelow α lam z).mono (image_subset_range _ _))
    ⟨n, hn, rfl⟩

/-- Fekete convergence of the actual normalized phase integrals. -/
theorem tendsto_amoFiniteLyapunov (α lam : ℝ) (z : ℂ) :
    Tendsto (amoFiniteLyapunov α lam z) atTop (𝓝 (amoLyapunov α lam z)) := by
  have h := (amoTransferLogAverage_subadditive α lam z).tendsto_lim
    (amoFiniteLyapunov_bddBelow α lam z)
  simpa only [Subadditive.lim, amoLyapunov, amoFiniteLyapunov] using h

/-- Continuity of every phase-averaged finite level in frequency, coupling and energy. -/
theorem continuous_amoTransferLogAverage (n : ℕ) :
    Continuous (fun p : ℝ × ℝ × ℂ => amoTransferLogAverage p.1 p.2.1 p.2.2 n) := by
  have hc : Continuous (fun p : (ℝ × ℝ × ℂ) × ℝ =>
      amoTransferLogNorm p.1.1 p.1.2.1 p.1.2.2 p.2 n) := by
    have h := (continuous_amoTransferLogNorm n).comp
      (show Continuous (fun p : (ℝ × ℝ × ℂ) × ℝ =>
        (p.1.1, p.1.2.1, p.1.2.2, p.2)) by fun_prop)
    exact h
  have h : Continuous (fun p : ℝ × ℝ × ℂ =>
      ∫ θ in Icc 0 (2 * Real.pi), amoTransferLogNorm p.1 p.2.1 p.2.2 θ n) :=
    continuous_parametric_integral_of_continuous
      (f := fun (p : ℝ × ℝ × ℂ) (θ : ℝ) => amoTransferLogNorm p.1 p.2.1 p.2.2 θ n)
      hc isCompact_Icc
  have heq (p : ℝ × ℝ × ℂ) :
      (∫ θ in Icc 0 (2 * Real.pi), amoTransferLogNorm p.1 p.2.1 p.2.2 θ n) =
        ∫ θ in (0 : ℝ)..(2 * Real.pi), amoTransferLogNorm p.1 p.2.1 p.2.2 θ n := by
    rw [integral_Icc_eq_integral_Ioc, intervalIntegral.integral_of_le (by positivity)]
  simpa only [amoTransferLogAverage, heq] using h.div_const (2 * Real.pi)

theorem continuous_amoFiniteLyapunov (n : ℕ) :
    Continuous (fun p : ℝ × ℝ × ℂ => amoFiniteLyapunov p.1 p.2.1 p.2.2 n) :=
  (continuous_amoTransferLogAverage n).div_const (n : ℝ)

/-- Joint upper semicontinuity of the independently defined transfer exponent. -/
theorem amoLyapunov_upperSemicontinuous :
    UpperSemicontinuous (fun p : ℝ × ℝ × ℂ => amoLyapunov p.1 p.2.1 p.2.2) := by
  intro p c hc
  obtain ⟨y, hy, hyc⟩ := exists_lt_of_csInf_lt
    (show ((fun n => amoFiniteLyapunov p.1 p.2.1 p.2.2 n) '' Ici 1).Nonempty from
      ⟨amoFiniteLyapunov p.1 p.2.1 p.2.2 1, 1, by simp, rfl⟩) hc
  rcases hy with ⟨n, hn, rfl⟩
  filter_upwards [(continuous_amoFiniteLyapunov n).continuousAt (gt_mem_nhds hyc)] with q hq
  exact (amoLyapunov_le_finite q.1 q.2.1 q.2.2 hn).trans_lt hq

end CriticalDTM

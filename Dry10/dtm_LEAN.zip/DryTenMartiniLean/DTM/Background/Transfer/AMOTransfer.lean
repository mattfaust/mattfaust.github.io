import DTM.Background.Realization.AlmostMathieu
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.LinearCombination

/-!
# Actual almost Mathieu transfer matrices

The energy is complex and the phase is in radians. Products act on the
column `(u(k), u(k-1))`, with later sites multiplying on the left.
`amoTransferNorm` is explicitly the Euclidean operator norm. In particular
it is not the default entrywise supremum norm on matrices.
-/

noncomputable section

open Filter Matrix
open scoped Topology Matrix Matrix.L2OpNorm

namespace CriticalDTM

abbrev AMOTransferMatrix := Matrix (Fin 2) (Fin 2) ℂ

/-- One receiving-row transfer step for the actual almost Mathieu equation. -/
def amoTransfer (lam : ℝ) (z : ℂ) (θ : ℝ) : AMOTransferMatrix :=
  !![z - ((2 * lam * Real.cos θ : ℝ) : ℂ), -1; 1, 0]

@[simp] theorem amoTransfer_det (lam : ℝ) (z : ℂ) (θ : ℝ) :
    (amoTransfer lam z θ).det = 1 := by
  simp [amoTransfer, Matrix.det_fin_two]

/-- The ordered product from site zero through site `n-1`. -/
def amoTransferProduct (α lam : ℝ) (z : ℂ) (θ : ℝ) : ℕ → AMOTransferMatrix
  | 0 => 1
  | n + 1 => amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
      amoTransferProduct α lam z θ n

@[simp] theorem amoTransferProduct_zero (α lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransferProduct α lam z θ 0 = 1 := rfl

@[simp] theorem amoTransferProduct_succ (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ (n + 1) =
      amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
        amoTransferProduct α lam z θ n := rfl

@[simp] theorem amoTransferProduct_det (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    (amoTransferProduct α lam z θ n).det = 1 := by
  induction n with
  | zero => simp
  | succ n ih => simp [Matrix.det_mul, ih]

/-- The genuine transfer cocycle, with its phase shift and multiplication order. -/
theorem amoTransferProduct_add (α lam : ℝ) (z : ℂ) (θ : ℝ) (m n : ℕ) :
    amoTransferProduct α lam z θ (m + n) =
      amoTransferProduct α lam z (θ + 2 * Real.pi * α * (n : ℝ)) m *
        amoTransferProduct α lam z θ n := by
  induction m with
  | zero => simp
  | succ m ih =>
      have hphase : θ + 2 * Real.pi * α * ((m + n : ℕ) : ℝ) =
          (θ + 2 * Real.pi * α * (n : ℝ)) + 2 * Real.pi * α * (m : ℝ) := by
        push_cast
        ring
      rw [Nat.succ_add, amoTransferProduct_succ, ih, amoTransferProduct_succ, hphase]
      simp only [mul_assoc]

theorem amoTransfer_periodic (lam : ℝ) (z : ℂ) :
    Function.Periodic (amoTransfer lam z) (2 * Real.pi) := by
  intro θ
  simp only [amoTransfer, Real.cos_add_two_pi]

theorem amoTransferProduct_periodic (α lam : ℝ) (z : ℂ) (n : ℕ) :
    Function.Periodic (fun θ => amoTransferProduct α lam z θ n) (2 * Real.pi) := by
  induction n with
  | zero => intro θ; rfl
  | succ n ih =>
      intro θ
      simp only [amoTransferProduct_succ, ih θ]
      rw [show θ + 2 * Real.pi + 2 * Real.pi * α * (n : ℝ) =
        (θ + 2 * Real.pi * α * (n : ℝ)) + 2 * Real.pi by ring]
      rw [amoTransfer_periodic lam z]

/-- Joint continuity in coupling, complex energy and radian phase. -/
theorem continuous_amoTransfer :
    Continuous (fun p : ℝ × ℂ × ℝ => amoTransfer p.1 p.2.1 p.2.2) := by
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j
  · change Continuous (fun p : ℝ × ℂ × ℝ => p.2.1 - ((2 * p.1 * Real.cos p.2.2 : ℝ) : ℂ))
    fun_prop
  · exact continuous_const
  · exact continuous_const
  · exact continuous_const

/-- Finite transfer products are jointly continuous, including the frequency. -/
theorem continuous_amoTransferProduct (n : ℕ) :
    Continuous (fun p : ℝ × ℝ × ℂ × ℝ =>
      amoTransferProduct p.1 p.2.1 p.2.2.1 p.2.2.2 n) := by
  induction n with
  | zero => exact continuous_const
  | succ n ih =>
      exact (continuous_amoTransfer.comp
        (show Continuous (fun p : ℝ × ℝ × ℂ × ℝ =>
          (p.2.1, p.2.2.1, p.2.2.2 + 2 * Real.pi * p.1 * (n : ℝ))) by
          fun_prop)).mul ih

/-- Explicit Euclidean operator norm, not an entrywise matrix norm. -/
def amoTransferNorm (M : AMOTransferMatrix) : ℝ :=
  ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M‖

@[simp] theorem amoTransferNorm_one : amoTransferNorm 1 = 1 := by
  simp [amoTransferNorm]

theorem amoTransferNorm_nonneg (M : AMOTransferMatrix) : 0 ≤ amoTransferNorm M :=
  norm_nonneg _

/-- Submultiplicativity comes from composition of Euclidean operators. -/
theorem amoTransferNorm_mul_le (M N : AMOTransferMatrix) :
    amoTransferNorm (M * N) ≤ amoTransferNorm M * amoTransferNorm N := by
  simpa only [amoTransferNorm, map_mul] using
    norm_mul_le (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M)
      (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) N)

theorem continuous_amoTransferNorm : Continuous amoTransferNorm := by
  change Continuous (fun M : AMOTransferMatrix => ‖M‖)
  exact continuous_norm

/-- Every matrix entry is bounded by the explicitly chosen Euclidean operator norm. -/
theorem norm_entry_le_amoTransferNorm (M : AMOTransferMatrix) (i j : Fin 2) :
    ‖M i j‖ ≤ amoTransferNorm M := by
  let T := Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M
  let v : EuclideanSpace ℂ (Fin 2) := EuclideanSpace.single j 1
  have hentry : (T v) i = M i j := by
    change (M *ᵥ Pi.single j 1) i = M i j
    rw [Matrix.mulVec_single_one]
    rfl
  calc
    ‖M i j‖ = ‖(T v) i‖ := congrArg norm hentry.symm
    _ ≤ ‖T v‖ := PiLp.norm_apply_le _ _
    _ ≤ ‖T‖ * ‖v‖ := T.le_opNorm v
    _ = amoTransferNorm M := by simp [T, v, amoTransferNorm]

/-- An elementary upper bound for the Euclidean operator norm, useful when
all four entries have been compared with a Dirichlet determinant. -/
theorem amoTransferNorm_le_sum_norm_entries (M : AMOTransferMatrix) :
    amoTransferNorm M ≤ ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ := by
  have hl1 (x : EuclideanSpace ℂ (Fin 2)) : ‖x‖ ≤ ∑ i : Fin 2, ‖x i‖ := by
    have hx : x = ∑ i : Fin 2, EuclideanSpace.single i (x i) := by
      ext j
      fin_cases j <;> simp [EuclideanSpace.single_apply]
    calc
      ‖x‖ = ‖∑ i : Fin 2, EuclideanSpace.single i (x i)‖ := congrArg norm hx
      _ ≤ ∑ i : Fin 2, ‖EuclideanSpace.single i (x i)‖ := norm_sum_le _ _
      _ = _ := by simp
  unfold amoTransferNorm
  apply ContinuousLinearMap.opNorm_le_bound _ (by positivity)
  intro x
  calc
    ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x‖ ≤
        ∑ i : Fin 2, ‖(Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x) i‖ := hl1 _
    _ = ∑ i : Fin 2, ‖∑ j : Fin 2, M i j * x j‖ := rfl
    _ ≤ ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ * ‖x j‖ := by
      apply Finset.sum_le_sum
      intro i _
      simpa only [norm_mul] using norm_sum_le (Finset.univ : Finset (Fin 2))
        (fun j => M i j * x j)
    _ ≤ ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ * ‖x‖ := by
      apply Finset.sum_le_sum
      intro i _
      exact Finset.sum_le_sum fun j _ =>
        mul_le_mul_of_nonneg_left (PiLp.norm_apply_le x j) (norm_nonneg _)
    _ = (∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖) * ‖x‖ := by
      simp only [Finset.sum_mul]

theorem amoTransferNorm_le_four_entries (M : AMOTransferMatrix) :
    amoTransferNorm M ≤ ‖M 0 0‖ + ‖M 0 1‖ + ‖M 1 0‖ + ‖M 1 1‖ := by
  simpa only [Fin.sum_univ_two, ← add_assoc] using amoTransferNorm_le_sum_norm_entries M

/-- Determinant one forces operator norm at least one. If the norm were
less than one, the powers would converge to zero, contradicting their
constant determinant. This also avoids any unproved norm-equivalence limit. -/
theorem one_le_amoTransferNorm_of_det_one (M : AMOTransferMatrix) (hM : M.det = 1) :
    1 ≤ amoTransferNorm M := by
  by_contra h
  have hnorm : ‖M‖ < 1 := lt_of_not_ge h
  have ht := (continuous_id.matrix_det :
    Continuous (fun N : AMOTransferMatrix => N.det)).tendsto 0
  have hz : Tendsto (fun _ : ℕ => (1 : ℂ)) atTop (𝓝 0) := by
    simpa only [Function.comp_def, id_eq, Matrix.det_pow, hM, one_pow, Matrix.det_zero] using
      ht.comp (tendsto_pow_atTop_nhds_zero_of_norm_lt_one hnorm)
  exact one_ne_zero (tendsto_nhds_unique tendsto_const_nhds hz)

theorem one_le_amoTransferProduct_norm (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    1 ≤ amoTransferNorm (amoTransferProduct α lam z θ n) :=
  one_le_amoTransferNorm_of_det_one _ (amoTransferProduct_det α lam z θ n)

theorem amoTransferProduct_norm_pos (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    0 < amoTransferNorm (amoTransferProduct α lam z θ n) :=
  zero_lt_one.trans_le (one_le_amoTransferProduct_norm α lam z θ n)

end CriticalDTM

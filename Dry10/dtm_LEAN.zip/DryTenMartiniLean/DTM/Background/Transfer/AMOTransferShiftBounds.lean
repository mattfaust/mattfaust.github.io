import DTM.Background.Transfer.AMOLyapunov

/-!
# Uniform one-step and phase-shift bounds for actual AMO transfer products

Both the literal transfer matrix and its explicit inverse have Euclidean
operator norm at most `K = ‖z‖ + 2|λ| + 2`, uniformly in radian phase.
The actual cocycle identity then bounds the change of the finite logarithm
under one base rotation by `2 log K`. These finite algebraic estimates do
not assert a large-deviation estimate or any spectral upper bound.
-/

noncomputable section

open Matrix MeasureTheory
open scoped Matrix

namespace CriticalDTM

/-- A phase-independent bound for a one-site transfer and its inverse. -/
def amoTransferBound (lam : ℝ) (z : ℂ) : ℝ := ‖z‖ + 2 * |lam| + 2

theorem two_le_amoTransferBound (lam : ℝ) (z : ℂ) : 2 ≤ amoTransferBound lam z := by
  unfold amoTransferBound
  linarith [norm_nonneg z, abs_nonneg lam]

theorem amoTransferBound_pos (lam : ℝ) (z : ℂ) : 0 < amoTransferBound lam z :=
  (by norm_num : (0 : ℝ) < 2).trans_le (two_le_amoTransferBound lam z)

theorem amoTransferBound_one_le (lam : ℝ) (z : ℂ) : 1 ≤ amoTransferBound lam z :=
  (by norm_num : (1 : ℝ) ≤ 2).trans (two_le_amoTransferBound lam z)

/-- The inverse is an explicit matrix, not a totalized inverse at a singular input. -/
def amoTransferInv (lam : ℝ) (z : ℂ) (θ : ℝ) : AMOTransferMatrix :=
  !![0, 1; -1, z - ((2 * lam * Real.cos θ : ℝ) : ℂ)]

@[simp] theorem amoTransfer_mul_inv (lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransfer lam z θ * amoTransferInv lam z θ = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Matrix.mul_apply, Fin.sum_univ_two, amoTransfer, amoTransferInv]

@[simp] theorem amoTransfer_inv_mul (lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransferInv lam z θ * amoTransfer lam z θ = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Matrix.mul_apply, Fin.sum_univ_two, amoTransfer, amoTransferInv]

private theorem amoTransfer_diagonal_norm_le (lam : ℝ) (z : ℂ) (θ : ℝ) :
    ‖z - ((2 * lam * Real.cos θ : ℝ) : ℂ)‖ ≤ ‖z‖ + 2 * |lam| := by
  have hv : ‖((2 * lam * Real.cos θ : ℝ) : ℂ)‖ ≤ 2 * |lam| := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_mul, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]
    simpa only [mul_one] using
      mul_le_mul_of_nonneg_left (Real.abs_cos_le_one θ) (by positivity : 0 ≤ 2 * |lam|)
  exact (norm_sub_le _ _).trans (add_le_add_left hv _)

/-- Uniform Euclidean operator-norm bound for the literal one-step matrix. -/
theorem amoTransfer_norm_le_bound (lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransferNorm (amoTransfer lam z θ) ≤ amoTransferBound lam z := by
  have h := amoTransferNorm_le_four_entries (amoTransfer lam z θ)
  change amoTransferNorm (amoTransfer lam z θ) ≤
    ‖z - ((2 * lam * Real.cos θ : ℝ) : ℂ)‖ + ‖(-1 : ℂ)‖ + ‖(1 : ℂ)‖ + ‖(0 : ℂ)‖ at h
  simp only [norm_neg, norm_one, norm_zero, add_zero] at h
  have hd := amoTransfer_diagonal_norm_le lam z θ
  unfold amoTransferBound
  linarith

/-- The explicit inverse obeys exactly the same phase-independent norm bound. -/
theorem amoTransferInv_norm_le_bound (lam : ℝ) (z : ℂ) (θ : ℝ) :
    amoTransferNorm (amoTransferInv lam z θ) ≤ amoTransferBound lam z := by
  have h := amoTransferNorm_le_four_entries (amoTransferInv lam z θ)
  change amoTransferNorm (amoTransferInv lam z θ) ≤
    ‖(0 : ℂ)‖ + ‖(1 : ℂ)‖ + ‖(-1 : ℂ)‖ +
      ‖z - ((2 * lam * Real.cos θ : ℝ) : ℂ)‖ at h
  simp only [norm_neg, norm_one, norm_zero, zero_add] at h
  have hd := amoTransfer_diagonal_norm_le lam z θ
  unfold amoTransferBound
  linarith

/-- Iterated submultiplicativity gives a bound at every phase and length. -/
theorem amoTransferProduct_norm_le_pow (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferNorm (amoTransferProduct α lam z θ n) ≤ amoTransferBound lam z ^ n := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [amoTransferProduct_succ]
      calc
        amoTransferNorm (amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
            amoTransferProduct α lam z θ n) ≤
            amoTransferNorm (amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ))) *
              amoTransferNorm (amoTransferProduct α lam z θ n) := amoTransferNorm_mul_le _ _
        _ ≤ amoTransferBound lam z * amoTransferBound lam z ^ n :=
          mul_le_mul (amoTransfer_norm_le_bound lam z _) ih
            (amoTransferNorm_nonneg _) (amoTransferBound_pos lam z).le
        _ = _ := (pow_succ' _ _).symm

/-- Two descriptions of the same length-`n+1` cocycle give the exact
one-step phase intertwining relation, with no commutation of transfer factors. -/
theorem amoTransferProduct_shift_intertwine
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z (θ + 2 * Real.pi * α) n * amoTransfer lam z θ =
      amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
        amoTransferProduct α lam z θ n := by
  simpa only [amoTransferProduct_succ, amoTransferProduct_zero, Nat.cast_one,
    Nat.cast_zero, mul_zero, add_zero, mul_one] using
    (amoTransferProduct_add α lam z θ n 1).symm

/-- Moving the base phase forward exposes only the two endpoint transfers. -/
theorem amoTransferProduct_shift_eq
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z (θ + 2 * Real.pi * α) n =
      amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
        amoTransferProduct α lam z θ n * amoTransferInv lam z θ := by
  calc
    amoTransferProduct α lam z (θ + 2 * Real.pi * α) n =
        (amoTransferProduct α lam z (θ + 2 * Real.pi * α) n * amoTransfer lam z θ) *
          amoTransferInv lam z θ := by
      simp only [mul_assoc, amoTransfer_mul_inv, mul_one]
    _ = _ := by rw [amoTransferProduct_shift_intertwine]

/-- The reverse endpoint identity is also an actual matrix equality. -/
theorem amoTransferProduct_eq_inv_mul_shift
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferProduct α lam z θ n =
      amoTransferInv lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
        amoTransferProduct α lam z (θ + 2 * Real.pi * α) n * amoTransfer lam z θ := by
  calc
    amoTransferProduct α lam z θ n =
        amoTransferInv lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
          (amoTransfer lam z (θ + 2 * Real.pi * α * (n : ℝ)) *
            amoTransferProduct α lam z θ n) := by
      rw [← mul_assoc, amoTransfer_inv_mul, one_mul]
    _ = _ := by
      rw [← amoTransferProduct_shift_intertwine]
      simp only [mul_assoc]

private theorem amoTransferNorm_sandwich_le
    (A M B : AMOTransferMatrix) {K : ℝ} (hK : 0 ≤ K)
    (hA : amoTransferNorm A ≤ K) (hB : amoTransferNorm B ≤ K) :
    amoTransferNorm (A * M * B) ≤ K ^ 2 * amoTransferNorm M := by
  calc
    amoTransferNorm (A * M * B) ≤
        (amoTransferNorm A * amoTransferNorm M) * amoTransferNorm B :=
      (amoTransferNorm_mul_le _ _).trans
        (mul_le_mul_of_nonneg_right (amoTransferNorm_mul_le _ _) (amoTransferNorm_nonneg _))
    _ ≤ (K * amoTransferNorm M) * K :=
      mul_le_mul (mul_le_mul_of_nonneg_right hA (amoTransferNorm_nonneg _)) hB
        (amoTransferNorm_nonneg _) (mul_nonneg hK (amoTransferNorm_nonneg _))
    _ = _ := by ring

theorem amoTransferProduct_shift_norm_le
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferNorm (amoTransferProduct α lam z (θ + 2 * Real.pi * α) n) ≤
      amoTransferBound lam z ^ 2 * amoTransferNorm (amoTransferProduct α lam z θ n) := by
  rw [amoTransferProduct_shift_eq]
  exact amoTransferNorm_sandwich_le _ _ _ (amoTransferBound_pos lam z).le
    (amoTransfer_norm_le_bound lam z _) (amoTransferInv_norm_le_bound lam z _)

theorem amoTransferProduct_norm_le_shift
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferNorm (amoTransferProduct α lam z θ n) ≤
      amoTransferBound lam z ^ 2 *
        amoTransferNorm (amoTransferProduct α lam z (θ + 2 * Real.pi * α) n) := by
  conv_lhs => rw [amoTransferProduct_eq_inv_mul_shift]
  exact amoTransferNorm_sandwich_le _ _ _ (amoTransferBound_pos lam z).le
    (amoTransferInv_norm_le_bound lam z _) (amoTransfer_norm_le_bound lam z _)

/-- The finite logarithm is almost invariant under one base rotation,
with a length-independent error proved from the actual endpoint matrices. -/
theorem amoTransferLogNorm_shift_abs_sub_le
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    |amoTransferLogNorm α lam z (θ + 2 * Real.pi * α) n - amoTransferLogNorm α lam z θ n| ≤
      2 * Real.log (amoTransferBound lam z) := by
  have hK := pow_ne_zero 2 (amoTransferBound_pos lam z).ne'
  have hf := Real.log_le_log (amoTransferProduct_norm_pos α lam z _ n)
    (amoTransferProduct_shift_norm_le α lam z θ n)
  have hb := Real.log_le_log (amoTransferProduct_norm_pos α lam z θ n)
    (amoTransferProduct_norm_le_shift α lam z θ n)
  rw [Real.log_mul hK (amoTransferProduct_norm_pos α lam z θ n).ne', Real.log_pow] at hf
  rw [Real.log_mul hK (amoTransferProduct_norm_pos α lam z _ n).ne', Real.log_pow] at hb
  norm_num only [Nat.cast_ofNat] at hf hb
  unfold amoTransferLogNorm
  exact abs_le.mpr ⟨by linarith, by linarith⟩

/-- The pointwise normalized logarithm has a one-step error of order `1/n`. -/
theorem amoTransferLogNorm_div_shift_abs_sub_le
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) (hn : 0 < n) :
    |amoTransferLogNorm α lam z (θ + 2 * Real.pi * α) n / (n : ℝ) -
      amoTransferLogNorm α lam z θ n / (n : ℝ)| ≤
        (2 * Real.log (amoTransferBound lam z)) / (n : ℝ) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  rw [← sub_div, abs_div, abs_of_pos hn']
  exact div_le_div_of_nonneg_right (amoTransferLogNorm_shift_abs_sub_le α lam z θ n) hn'.le

/-- Uniform pointwise finite-scale upper bound, with no spectral restriction on `z`. -/
theorem amoTransferLogNorm_le_mul_log_bound
    (α lam : ℝ) (z : ℂ) (θ : ℝ) (n : ℕ) :
    amoTransferLogNorm α lam z θ n ≤ (n : ℝ) * Real.log (amoTransferBound lam z) := by
  simpa only [amoTransferLogNorm, Real.log_pow] using
    Real.log_le_log (amoTransferProduct_norm_pos α lam z θ n)
      (amoTransferProduct_norm_le_pow α lam z θ n)

theorem amoTransferLogAverage_le_mul_log_bound
    (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoTransferLogAverage α lam z n ≤ (n : ℝ) * Real.log (amoTransferBound lam z) := by
  have hperiod : 0 < 2 * Real.pi := by positivity
  have hi := intervalIntegral.integral_mono hperiod.le
    (amoTransferLogNorm_intervalIntegrable α lam z n 0 (2 * Real.pi))
    (continuous_const.intervalIntegrable 0 (2 * Real.pi))
    (fun θ => amoTransferLogNorm_le_mul_log_bound α lam z θ n)
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hi
  apply (div_le_iff₀ hperiod).mpr
  simpa only [mul_comm] using hi

theorem amoFiniteLyapunov_le_log_bound (α lam : ℝ) (z : ℂ) (n : ℕ) :
    amoFiniteLyapunov α lam z n ≤ Real.log (amoTransferBound lam z) := by
  cases n with
  | zero => simpa only [amoFiniteLyapunov_zero] using
      Real.log_nonneg (amoTransferBound_one_le lam z)
  | succ n =>
      apply (div_le_iff₀ (show (0 : ℝ) < ((n + 1 : ℕ) : ℝ) by positivity)).mpr
      simpa only [mul_comm] using amoTransferLogAverage_le_mul_log_bound α lam z (n + 1)

theorem amoLyapunov_le_log_bound (α lam : ℝ) (z : ℂ) :
    amoLyapunov α lam z ≤ Real.log (amoTransferBound lam z) :=
  (amoLyapunov_le_finite α lam z (n := 1) le_rfl).trans (amoFiniteLyapunov_le_log_bound α lam z 1)

end CriticalDTM

import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Data.Real.Irrational
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith

/-!
# Proof guide: inverse-phase boundary algebra

The model-specific cancellation uses inverse magnetic phases x y = 1 and x ≠ 1,
not invertibility of the averaged coefficient (1 + x)/2. Irrationality proves the
required nonunit phase at each nonzero diagonal coordinate. The antidiagonal proof
is the same finite algebra after swapping phases and north/south entries. The phase
laws and the final equal-sums-to-half-sum identity are routine supporting facts.
-/

/-!
# The diagonal row calculation

This module proves the inverse-phase boundary algebra directly from the
two receiving-row formulas. The parameters x and y are inverse phases.
No summability or spectral assumption occurs here.
-/

namespace CriticalDTM

/-- The phase in the Landau receiving-row formula. -/
noncomputable def magneticPhase (α : ℝ) (n : ℤ) : ℂ :=
  Complex.exp (((2 * Real.pi * α * (n : ℝ) : ℝ) : ℂ) * Complex.I)

theorem magneticPhase_zero (α : ℝ) : magneticPhase α 0 = 1 := by
  simp [magneticPhase]

theorem magneticPhase_add (α : ℝ) (m n : ℤ) :
    magneticPhase α (m + n) = magneticPhase α m * magneticPhase α n := by
  simp only [magneticPhase, Int.cast_add, mul_add, Complex.ofReal_add, add_mul,
    Complex.exp_add]

theorem magneticPhase_mul_neg (α : ℝ) (n : ℤ) :
    magneticPhase α n * magneticPhase α (-n) = 1 := by
  rw [← magneticPhase_add]
  simp [magneticPhase_zero]

theorem magneticPhase_ne_one {α : ℝ} (hα : Irrational α)
    {n : ℤ} (hn : n ≠ 0) : magneticPhase α n ≠ 1 := by
  intro h
  /- The inverse-phase boundary calculation: a phase equal to one would give α n = m for an integer m.
     For n ≠ 0 this contradicts irrationality; no lower bound on |1 - exp(2πiαn)|
     is needed. -/
  obtain ⟨m, hm⟩ := Complex.exp_eq_one_iff.mp h
  have hi := congrArg Complex.im hm
  simp [Complex.mul_re, Complex.mul_im] at hi
  have heq : α * (n : ℝ) = (m : ℝ) := by
    nlinarith [Real.pi_pos]
  exact (hα.mul_intCast hn).ne_int m heq

end CriticalDTM

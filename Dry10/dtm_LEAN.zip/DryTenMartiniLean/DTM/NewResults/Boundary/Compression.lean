import DTM.NewResults.Boundary.ConeGeometry
import DTM.NewResults.Boundary.BoundaryAlgebra

/-!
# Proof guide: pointwise compatible-vector compression

The model-specific calculation is made on arbitrary functions on the entire
integer lattice before any Hilbert-space lifting. hRow and conjugateRow are the
two direct complex-linear receiving rows; averageRow is exactly their half-sum.
Input projection keeps only retained sites and the output projection is separate.
The compression equality holds only for compatible inputs with zero root value:
it is not the operator identity QH = K on all vectors, and not [Q,H] = 0.
-/

/-!
# Pointwise magnetic compression

This is the lattice identity underlying the cone-compression calculation.  All operators here act
pointwise on arbitrary complex-valued functions on the infinite lattice.
No finite-volume approximation, summability assumption, or spectral theorem
is used.  The bounded-operator and resolvent realizations are separate tasks.
-/

namespace CriticalDTM

noncomputable def hRow (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) : ℂ :=
  u (east s) + u (west s) +
    lam * magneticPhase α s.1 * u (north s) +
    lam * magneticPhase α (-s.1) * u (south s)

noncomputable def conjugateRow (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) : ℂ :=
  magneticPhase α s.2 * u (east s) + magneticPhase α (-s.2) * u (west s) +
    lam * u (north s) + lam * u (south s)

noncomputable def phaseAverage (α : ℝ) (n : ℤ) : ℂ :=
  (1 + magneticPhase α n) / 2

noncomputable def averageRow (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) : ℂ :=
  phaseAverage α s.2 * u (east s) + phaseAverage α (-s.2) * u (west s) +
    lam * phaseAverage α s.1 * u (north s) +
    lam * phaseAverage α (-s.1) * u (south s)

theorem averageRow_eq_half_sum (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) :
    averageRow α lam u s = (hRow α lam u s + conjugateRow α lam u s) / 2 := by
  /- Cone-compression setup: averaging the two full receiving rows gives precisely
     the coefficients t_k,t_{-k},λt_j,λt_{-j}; no boundary deletion has yet occurred. -/
  unfold averageRow phaseAverage hRow conjugateRow
  ring

end CriticalDTM

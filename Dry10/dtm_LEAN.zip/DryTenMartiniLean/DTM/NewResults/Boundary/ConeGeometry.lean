import Mathlib.Data.Real.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.SplitIfs

/-!
# Proof guide: the four boundary rays and the origin

This is the exact integer geometry of the retained region |j| ≤ |k| with the
single physical origin excluded. It is supporting discrete geometry for the
model-specific row balance, not a new spectral input. Every nonzero diagonal site
is assigned to one of four signed rays. The strict-vertical one-step argument
explicitly allows the origin, whose input value is handled separately in the cone-compression calculation.
The weight qWeight is 1 in the strict vertical region, 1/2 on the nonzero diagonals,
and 0 elsewhere; it is not the retained-site projection.
-/

/-!
# Integer cone geometry

This file isolates the discrete geometry used in the diagonal compression.
It contains no operator-theoretic or spectral assumptions.
-/

namespace CriticalDTM

abbrev Site := ℤ × ℤ

def origin : Site := (0, 0)

def east (s : Site) : Site := (s.1 + 1, s.2)
def west (s : Site) : Site := (s.1 - 1, s.2)
def north (s : Site) : Site := (s.1, s.2 + 1)
def south (s : Site) : Site := (s.1, s.2 - 1)

def vertical (s : Site) : Prop := |s.1| < |s.2|
def horizontal (s : Site) : Prop := |s.2| < |s.1|
def boundary (s : Site) : Prop := s ≠ origin ∧ |s.1| = |s.2|
def retained (s : Site) : Prop := |s.1| ≤ |s.2| ∧ s ≠ origin

instance : DecidablePred vertical := fun s =>
  inferInstanceAs (Decidable (|s.1| < |s.2|))

instance : DecidablePred boundary := fun s =>
  inferInstanceAs (Decidable (s ≠ origin ∧ |s.1| = |s.2|))

/- Boundary algebra and cone compression: the diagonal half-weight records equality of retained
   and omitted boundary-row contributions. The origin has weight zero and is
   not one of the four diagonal rays. -/
noncomputable def qWeight (s : Site) : ℝ :=
  if vertical s then 1 else if boundary s then 1 / 2 else 0

@[simp] theorem origin_not_vertical : ¬ vertical origin := by
  simp [vertical, origin]

@[simp] theorem origin_not_boundary : ¬ boundary origin := by
  simp [boundary]

theorem vertical_ne_origin {s : Site} (h : vertical s) : s ≠ origin := by
  intro hs
  subst s
  exact origin_not_vertical h

theorem boundary_not_vertical {s : Site} (h : boundary s) : ¬ vertical s := by
  unfold boundary vertical at *
  omega

theorem retained_iff_vertical_or_boundary (s : Site) :
    retained s ↔ vertical s ∨ boundary s := by
  constructor
  · rintro ⟨hle, hne⟩
    rcases lt_or_eq_of_le hle with hlt | heq
    · exact Or.inl hlt
    · exact Or.inr ⟨hne, heq⟩
  · rintro (hv | hb)
    · exact ⟨le_of_lt hv, vertical_ne_origin hv⟩
    · exact ⟨le_of_eq hb.2, hb.1⟩

theorem horizontal_not_retained {s : Site} (h : horizontal s) : ¬ retained s := by
  intro hr
  exact (not_lt_of_ge hr.1) h

theorem qWeight_nonneg (s : Site) : 0 ≤ qWeight s := by
  unfold qWeight
  split_ifs <;> norm_num

theorem qWeight_le_one (s : Site) : qWeight s ≤ 1 := by
  unfold qWeight
  split_ifs <;> norm_num

@[simp] theorem qWeight_origin : qWeight origin = 0 := by
  simp [qWeight]

theorem qWeight_of_vertical {s : Site} (h : vertical s) : qWeight s = 1 := by
  simp [qWeight, h]

theorem qWeight_of_boundary {s : Site} (h : boundary s) : qWeight s = 1 / 2 := by
  simp [qWeight, h, boundary_not_vertical h]

theorem qWeight_of_not_retained {s : Site} (h : ¬ retained s) : qWeight s = 0 := by
  have hv : ¬ vertical s := fun hv => h ((retained_iff_vertical_or_boundary s).2 (.inl hv))
  have hb : ¬ boundary s := fun hb => h ((retained_iff_vertical_or_boundary s).2 (.inr hb))
  simp [qWeight, hv, hb]

theorem qWeight_of_horizontal {s : Site} (h : horizontal s) : qWeight s = 0 :=
  qWeight_of_not_retained (horizontal_not_retained h)

/-! A single lattice step cannot cross from the strict vertical cone into the
strict horizontal cone. Equality (a boundary site) is allowed. -/

theorem vertical_east_not_horizontal {s : Site} (h : vertical s) :
    ¬ horizontal (east s) := by
  /- East input: strict verticality gives the integer margin
     |k| ≥ |j| + 1, while an east step changes |j| by at most one.
     The endpoint therefore cannot be strictly horizontal. -/
  have ha : |s.1 + 1| ≤ |s.1| + 1 := by simpa using abs_add s.1 (1 : ℤ)
  unfold vertical at h
  unfold horizontal east
  dsimp
  omega

theorem vertical_west_not_horizontal {s : Site} (h : vertical s) :
    ¬ horizontal (west s) := by
  /- West input: the same integer margin and |j - 1| ≤ |j| + 1
     exclude a strictly horizontal endpoint. -/
  have ha : |s.1 - 1| ≤ |s.1| + 1 := by
    simpa only [abs_neg, abs_one] using abs_sub s.1 (1 : ℤ)
  unfold vertical at h
  unfold horizontal west
  dsimp
  omega

theorem vertical_north_not_horizontal {s : Site} (h : vertical s) :
    ¬ horizontal (north s) := by
  /- North input: |k + 1| ≥ |k| - 1 ≥ |j|.
     A retained boundary endpoint, or the origin, is allowed. -/
  have ha : |s.2| ≤ |s.2 + 1| + 1 := by
    simpa only [add_sub_cancel_right, abs_one] using abs_sub (s.2 + 1) (1 : ℤ)
  unfold vertical at h
  unfold horizontal north
  dsimp
  omega

theorem vertical_south_not_horizontal {s : Site} (h : vertical s) :
    ¬ horizontal (south s) := by
  /- South input: |k - 1| ≥ |k| - 1 ≥ |j|.
     This is why the zero-root condition is needed after projection. -/
  have ha : |s.2| ≤ |s.2 - 1| + 1 := by
    simpa only [sub_add_cancel, abs_one] using abs_add (s.2 - 1) (1 : ℤ)
  unfold vertical at h
  unfold horizontal south
  dsimp
  omega

/-! The four nonzero diagonal rays, with the exact two-and-two classification
of their neighbours. The direction names describe the lattice step; membership
in a region describes the endpoint of that step. -/

/- Ray (r,r), r > 0: west and north are retained strict-vertical
   inputs; east and south are omitted strict-horizontal inputs. The proof
   uses |r - 1| = r - 1, including r = 1. -/
theorem positive_diagonal_neighbors (r : ℤ) (hr : 0 < r) :
    horizontal (east (r, r)) ∧ vertical (west (r, r)) ∧
    vertical (north (r, r)) ∧ horizontal (south (r, r)) := by
  have h0 : 0 ≤ r := by omega
  have hp : 0 ≤ r + 1 := by omega
  have hm : 0 ≤ r - 1 := by omega
  simp only [horizontal, vertical, east, west, north, south,
    abs_of_nonneg h0, abs_of_nonneg hp, abs_of_nonneg hm]
  omega

/- Ray (r,r), r < 0: east and south are retained; west and north
   are omitted. The sign reversal exchanges the two regional sums, including
   r = -1; it does not change their equality. -/
theorem negative_diagonal_neighbors (r : ℤ) (hr : r < 0) :
    vertical (east (r, r)) ∧ horizontal (west (r, r)) ∧
    horizontal (north (r, r)) ∧ vertical (south (r, r)) := by
  have h0 : r ≤ 0 := by omega
  have hp : r + 1 ≤ 0 := by omega
  have hm : r - 1 ≤ 0 := by omega
  simp only [horizontal, vertical, east, west, north, south,
    abs_of_nonpos h0, abs_of_nonpos hp, abs_of_nonpos hm]
  omega

/- Ray (r,-r), r > 0: west and south are retained, whereas east
   and north are omitted. These are the negative-slope balance terms. -/
theorem positive_antidiagonal_neighbors (r : ℤ) (hr : 0 < r) :
    horizontal (east (r, -r)) ∧ vertical (west (r, -r)) ∧
    horizontal (north (r, -r)) ∧ vertical (south (r, -r)) := by
  have h0 : 0 ≤ r := by omega
  have hp : 0 ≤ r + 1 := by omega
  have hm : 0 ≤ r - 1 := by omega
  have hn : -r ≤ 0 := by omega
  have hnp : -r + 1 ≤ 0 := by omega
  have hnm : -r - 1 ≤ 0 := by omega
  simp only [horizontal, vertical, east, west, north, south,
    abs_of_nonneg h0, abs_of_nonneg hp, abs_of_nonneg hm,
    abs_of_nonpos hn, abs_of_nonpos hnp, abs_of_nonpos hnm]
  omega

/- Ray (r,-r), r < 0: east and north are retained; west and south
   are omitted. This fourth case cannot be suppressed by an unsigned picture. -/
theorem negative_antidiagonal_neighbors (r : ℤ) (hr : r < 0) :
    vertical (east (r, -r)) ∧ horizontal (west (r, -r)) ∧
    vertical (north (r, -r)) ∧ horizontal (south (r, -r)) := by
  have h0 : r ≤ 0 := by omega
  have hp : r + 1 ≤ 0 := by omega
  have hm : r - 1 ≤ 0 := by omega
  have hn : 0 ≤ -r := by omega
  have hnp : 0 ≤ -r + 1 := by omega
  have hnm : 0 ≤ -r - 1 := by omega
  simp only [horizontal, vertical, east, west, north, south,
    abs_of_nonpos h0, abs_of_nonpos hp, abs_of_nonpos hm,
    abs_of_nonneg hn, abs_of_nonneg hnp, abs_of_nonneg hnm]
  omega

theorem boundary_four_rays {s : Site} (h : boundary s) :
    (∃ r : ℤ, 0 < r ∧ s = (r, r)) ∨
    (∃ r : ℤ, r < 0 ∧ s = (r, r)) ∨
    (∃ r : ℤ, 0 < r ∧ s = (r, -r)) ∨
    (∃ r : ℤ, r < 0 ∧ s = (r, -r)) := by
  rcases s with ⟨j, k⟩
  rcases h with ⟨hne, heq⟩
  dsimp at heq
  /- The inverse-phase boundary calculation: a diagonal site with first coordinate zero would also have
     second coordinate zero. Excluding the physical origin therefore supplies
     the nonzero integer required by irrational phase cancellation. -/
  have hj : j ≠ 0 := by
    intro hj
    have hk : k = 0 := by simpa [hj] using heq.symm
    exact hne (by simp [origin, hj, hk])
  /- Equality of the absolute coordinates gives k = j or k = -j; the sign
     of the nonzero j then gives exactly the four rays used in the compression. -/
  have hdiag : k = j ∨ k = -j := by
    exact abs_eq_abs.mp heq.symm
  rcases hdiag with hk | hk
  · rcases lt_or_gt_of_ne hj with hj | hj
    · exact Or.inr (Or.inl ⟨j, hj, by simp [hk]⟩)
    · exact Or.inl ⟨j, hj, by simp [hk]⟩
  · rcases lt_or_gt_of_ne hj with hj | hj
    · exact Or.inr (Or.inr (Or.inr ⟨j, hj, by simp [hk]⟩))
    · exact Or.inr (Or.inr (Or.inl ⟨j, hj, by simp [hk]⟩))

end CriticalDTM

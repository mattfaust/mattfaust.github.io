import DTM.Background.Realization.MagneticOperators
import DTM.NewResults.Boundary.StationaryResolvent
import Mathlib.Algebra.Module.LinearMap.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.Module

/-!
# Proof guide: actual inverse and magnetic compatibility

All inverse identities are proved from membership in the actual bounded-operator
resolvent set. No totalized inverse at a spectral energy is used as a genuine
inverse. The row-constructed complex-linear partner commutes with H and shares
its root action; this instantiates the rooted linear algebra without an
antiunitary construction. The removed-column source retains both (1-zg)Ω and gHΩ.
-/

/-!
# Compatibility of actual magnetic resolvent columns

All inverses in this file are mathlib's actual bounded-operator resolvent.
The inverse identities are proved from resolvent-set membership, and global
magnetic commutation then supplies the compatibility of the rooted column.
-/

noncomputable section

namespace CriticalDTM

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]

theorem actual_resolvent_left_identity
    (H : E →L[ℂ] E) (z : ℂ) (hz : z ∈ resolventSet ℂ H) (u : E) :
    z • resolvent H z u - H (resolvent H z u) = u := by
  /- Resolvent support: resolvent-set membership gives (zI-H)R=I.
     Applying that bounded-operator identity to u gives the full left source equation. -/
  have h := congrArg (fun A : E →L[ℂ] E => A u)
    (Ring.mul_inverse_cancel (algebraMap ℂ (E →L[ℂ] E) z - H) hz)
  change (algebraMap ℂ (E →L[ℂ] E) z - H) (resolvent H z u) = u
  simpa only [resolvent, ContinuousLinearMap.mul_apply,
    ContinuousLinearMap.one_apply] using h

theorem actual_resolvent_right_identity
    (H : E →L[ℂ] E) (z : ℂ) (hz : z ∈ resolventSet ℂ H) (u : E) :
    resolvent H z (z • u - H u) = u := by
  /- The other inverse identity R(zI-H)=I supplies injectivity of zI-H.
     Both sides of the inverse are used, rather than an assumed formal inverse. -/
  have h := congrArg (fun A : E →L[ℂ] E => A u)
    (Ring.inverse_mul_cancel (algebraMap ℂ (E →L[ℂ] E) z - H) hz)
  change resolvent H z ((algebraMap ℂ (E →L[ℂ] E) z - H) u) = u
  simpa only [resolvent, ContinuousLinearMap.mul_apply,
    ContinuousLinearMap.one_apply] using h

end CriticalDTM

import DTM.Background.Realization.MagneticOperators
import DTM.NewResults.Boundary.StationaryResolvent

/-!
# Proof guide: physical root and source

The source is the one unit coordinate vector at (0,0), not one root in every
fiber or a deleted diagonal. Pairing with Ω reads its coordinate, so subtracting
gΩ gives q(0,0)=0. Expanding HΩ keeps all four nearest neighbors; applying Q
then kills only Ω and the horizontal source entries, leaving λ times the two
vertical unit entries. These are routine exact coordinate facts essential to
the model-specific sourced identity. Inner products are conjugate-linear first.
-/

/-!
# Root and vertical source for the actual magnetic lattice operator

The root is the unit vector at `(0,0)`. Its Green matrix element is exactly
the root coordinate of the resolvent column. The diagonal cone weight removes
the root and the horizontal part of the magnetic operator's root source.
-/

noncomputable section

namespace CriticalDTM

/-- The canonical lattice root is nonzero. -/
theorem hilbertRoot_ne_zero : hilbertRoot ≠ 0 := by
  intro hzero
  /- Resolvent support: the unit root cannot vanish because its origin
     coordinate is one. -/
  have h := congrArg (fun u : MagneticHilbert => u origin) hzero
  simp at h

/-- Pairing with the unit root reads off a vector's root coordinate. -/
theorem inner_hilbertRoot (u : LatticeHilbert) :
    @inner ℂ LatticeHilbert _ hilbertRoot u = u origin := by
  /- The unit coefficient at the origin makes ⟨Ω,u⟩ exactly u(0,0),
     with no normalization factor. -/
  simp [hilbertRoot, lp.inner_single_left]

/-- The two vertical nearest-neighbor source vectors. -/
def verticalRoot : LatticeHilbert :=
  lp.single 2 (0, 1) 1 + lp.single 2 (0, -1) 1

/-- A diagonal weight multiplies each basis vector by its weight. -/
theorem coneWeightOperator_single (s : Site) (a : ℂ) :
    coneWeightOperator (lp.single 2 s a) = (qWeight s : ℂ) • lp.single 2 s a := by
  apply lp.ext
  funext t
  /- Routine multiplier action: on the supporting site a coordinate unit
     vector is multiplied by qWeight(s), and all other coordinates remain zero. -/
  by_cases ht : t = s
  · subst t
    simp [coneWeightOperator_apply]
  · simp [coneWeightOperator_apply, lp.single_apply_ne, ht]

/-- The root is annihilated by the cone weight. -/
theorem coneWeightOperator_root_zero : coneWeightOperator hilbertRoot = 0 := by
  rw [hilbertRoot, coneWeightOperator_single, qWeight_origin]
  simp

/-- Explicit expansion of the magnetic root source into four basis vectors. -/
theorem hOperator_root_expansion (alpha : ℝ) (lam : ℂ) :
    hOperator alpha lam hilbertRoot =
      lp.single 2 (-1, 0) 1 + lp.single 2 (1, 0) 1 +
        lam • lp.single 2 (0, -1) 1 + lam • lp.single 2 (0, 1) 1 := by
  apply lp.ext
  funext s
  /- Physical source expansion: whenever an input root coordinate is nonzero,
     the relevant magnetic phase is one. Thus HΩ has all four displayed
     neighbor sources, with λ on the vertical pair. -/
  have hn := magneticPhase_mul_latticeRoot alpha Prod.fst (by rfl) (north s)
  have hs := magneticPhase_mul_latticeRoot alpha (fun t => -t.1) (by rfl) (south s)
  dsimp [north, south] at hn hs
  rw [hOperator_apply]
  simp only [hRow, hilbertRoot_apply, north, south]
  rw [mul_assoc lam, hn, mul_assoc lam, hs]
  rcases s with ⟨j, k⟩
  simp [latticeRoot, east, west, north, south, origin, Prod.ext_iff,
    Pi.single_apply, add_eq_zero_iff_eq_neg, sub_eq_zero]

end CriticalDTM

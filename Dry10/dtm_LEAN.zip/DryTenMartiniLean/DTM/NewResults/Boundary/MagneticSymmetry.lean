import DTM.Background.Realization.MagneticOperators
import Mathlib.Analysis.InnerProductSpace.Adjoint

/-!
# Proof guide: adjoint reindexing

These are routine operator-support facts for the direct magnetic rows, not
boundary-balance assumptions. Reindex the genuine ℓ² inner-product series by
the lattice step and conjugate its unit phase to identify the reverse adjoint.
Adding each step to its reverse and using real coupling proves self-adjointness
of H and of the complex-linear partner. The identifier conjugateOperator does
not denote an antiunitary map.
-/

/-!
# Self-adjointness of the magnetic operators

Each reverse magnetic step is the adjoint of its forward step.  The proof
reindexes the Hilbert-space inner product by the actual lattice bijection.
It does not infer self-adjointness from diagonal boundary balance.
-/

noncomputable section

namespace CriticalDTM

theorem magneticPhase_conj (α : ℝ) (n : ℤ) :
    starRingEnd ℂ (magneticPhase α n) = magneticPhase α (-n) := by
  /- The conjugate of exp(2πiαn) is exp(-2πiαn), exactly the phase required
     for the reverse magnetic step. -/
  unfold magneticPhase
  rw [← Complex.exp_conj]
  congr 1
  simp [map_mul, map_ofNat]

theorem twistedOperator_inner_pair (e : Site ≃ Site) (w w' : Site → ℂ)
    (hw : ∀ s, ‖w s‖ = 1) (hw' : ∀ s, ‖w' s‖ = 1)
    (hp : ∀ s, w' (e s) = starRingEnd ℂ (w s)) (u v : MagneticHilbert) :
    @inner ℂ _ _ (twistedOperator e w hw u) v =
      @inner ℂ _ _ u (twistedOperator e.symm w' hw' v) := by
  /- Cone-compression support: reindex the convergent inner-product sum by the
     lattice bijection. The reverse step has conjugate phase at the shifted
     site, yielding the adjoint relation term by term. -/
  rw [lp.inner_eq_tsum, lp.inner_eq_tsum]
  rw [← e.tsum_eq (fun s => @inner ℂ _ _ (u s) (twistedOperator e.symm w' hw' v s))]
  apply tsum_congr
  intro s
  simp only [twistedOperator_apply, Equiv.symm_apply_apply, hp]
  change @inner ℂ _ _ ((w s) • u (e s)) (v s) =
    @inner ℂ _ _ (u (e s)) ((starRingEnd ℂ (w s)) • v s)
  simp [inner_smul_left, inner_smul_right]
  ring

theorem pairedOperators_isSelfAdjoint (A B : MagneticHilbert →L[ℂ] MagneticHilbert)
    (hp : ∀ u v, @inner ℂ _ _ (A u) v = @inner ℂ _ _ u (B v)) :
    IsSelfAdjoint (A + B) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro u v
  /- Conjugating the forward adjoint identity with the two vectors exchanged
     also gives the reverse identity. Their sum is symmetric. -/
  have hb := congrArg (starRingEnd ℂ) (hp v u)
  simp only [inner_conj_symm] at hb
  change @inner ℂ _ _ ((A + B) u) v = @inner ℂ _ _ u ((A + B) v)
  simp only [ContinuousLinearMap.add_apply, inner_add_left, inner_add_right]
  rw [hp, ← hb]
  exact add_comm _ _

theorem twistedPair_isSelfAdjoint (e : Site ≃ Site) (w w' : Site → ℂ)
    (hw : ∀ s, ‖w s‖ = 1) (hw' : ∀ s, ‖w' s‖ = 1)
    (hp : ∀ s, w' (e s) = starRingEnd ℂ (w s)) :
    IsSelfAdjoint (twistedOperator e w hw + twistedOperator e.symm w' hw') :=
  pairedOperators_isSelfAdjoint _ _ (twistedOperator_inner_pair e w w' hw hw' hp)

theorem hOperator_isSelfAdjoint (α lam : ℝ) :
    IsSelfAdjoint (hOperator α (lam : ℂ)) := by
  /- Pair east with west and north with south. The latter pair has conjugate
     magnetic phases and is multiplied by real λ; hence the entire H is symmetric. -/
  unfold hOperator
  rw [add_assoc, ← smul_add]
  apply IsSelfAdjoint.add
  · apply twistedPair_isSelfAdjoint
    intro s
    simp
  · apply IsSelfAdjoint.smul
    · simp [isSelfAdjoint_iff]
    · apply twistedPair_isSelfAdjoint
      intro s
      simp only [northEquiv, north]
      exact (magneticPhase_conj α s.1).symm

theorem conjugateOperator_isSelfAdjoint (α lam : ℝ) :
    IsSelfAdjoint (conjugateOperator α (lam : ℂ)) := by
  /- For the partner, pair the phase-weighted horizontal steps and the plain
     vertical steps. This independent reindexing proof, not boundary balance,
     supplies its self-adjointness. -/
  unfold conjugateOperator
  rw [add_assoc, ← smul_add]
  apply IsSelfAdjoint.add
  · apply twistedPair_isSelfAdjoint
    intro s
    simp only [eastEquiv, east]
    exact (magneticPhase_conj α s.2).symm
  · apply IsSelfAdjoint.smul
    · simp [isSelfAdjoint_iff]
    · apply twistedPair_isSelfAdjoint
      intro s
      simp

end CriticalDTM

import DTM.NewResults.Chiral.Current

/-!
# The Green coupling pairing for the stationary magnetic response

The pairing below uses the genuine resolvent column and the vertical source
bonds. Its equality with the logarithmic-potential coupling derivative is
proved by the trace calculus; it is not asserted by this definition.
-/

noncomputable section

namespace CriticalDTM

/-- The Green pairing appearing in the coupling derivative formula.
The equality with that derivative is not part of this definition. -/
/- Stationary-response notation bridge: this defines a Green quantity, not a
   potential or Lyapunov exponent. Its equality with ∂λΦ is a separate
   proved theorem, so the derivative sign is not built into a definition. -/
def greenCouplingValue (α lam m : ℝ) : ℝ :=
  -(@inner ℂ LatticeHilbert _
    (removedColumn (hOperator α (lam : ℂ)) hilbertRoot (m : ℂ)) verticalRoot).re

end CriticalDTM

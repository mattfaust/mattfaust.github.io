import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Tactic.Ring

/-!
# Inner-product symmetry and nonvanishing of the resolvent source

The inner-product symmetry condition is equivalent to self-adjointness on a
Hilbert space. Applying a left inverse shows that the resolvent image of a
nonzero source cannot vanish. These abstract statements support the magnetic
response calculation without defining the magnetic operators or their height.
-/

/-!
# Operator hypotheses

The space is complex, and every operator below is a continuous linear map.
Self-adjointness is expressed by inner-product symmetry. The nonvanishing
argument takes the left-inverse identity and the nonzero source as explicit
hypotheses; the magnetic specialization supplies these hypotheses.
-/

noncomputable section

namespace CriticalDTM

open Complex
open scoped Topology

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

/-- Inner-product characterization of self-adjointness for a bounded operator. -/
def SymmetricOperator (A : E →L[ℂ] E) : Prop :=
  ∀ x y, @inner ℂ E _ (A x) y = @inner ℂ E _ x (A y)

/-- On a Hilbert space this explicit symmetry is exactly mathlib's
operator-theoretic self-adjointness, with no weaker substitute. -/
theorem symmetricOperator_iff_isSelfAdjoint [CompleteSpace E] (A : E →L[ℂ] E) :
    SymmetricOperator A ↔ IsSelfAdjoint A :=
  ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.symm

/-- A left inverse prevents the resolvent column of a nonzero root from
vanishing. No injectivity assumption on an unbounded operator is hidden here. -/
theorem resolvent_column_ne_zero
    (A R : E →L[ℂ] E) (root : E) (hroot : root ≠ 0)
    (hleft : ∀ x, A (R x) = x) : R root ≠ 0 := by
  intro hzero
  /- Stationary-response support: if RΩ vanished, applying its left inverse would
     give Ω=0. The positive denominator therefore follows from the nonzero root. -/
  have := hleft root
  rw [hzero, map_zero] at this
  exact hroot this.symm

end CriticalDTM

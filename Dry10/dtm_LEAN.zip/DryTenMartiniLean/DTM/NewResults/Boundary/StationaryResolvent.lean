import DTM.Background.Support.ResolventAnalysis
import DTM.NewResults.Boundary.WeightBounds

/-!
# Proof guide: actual column derivatives and ratio

This is the bridge from abstract stationary algebra to the genuine resolvent
and cone multiplier. At a real resolvent energy g′=-‖RΩ‖², and the removed-column
derivative is -R²Ω-g′Ω; the root-subtraction derivative is kept. At g(E)=0,
q=RΩ≠0. The active real-part theorem assumes only the locally valid weighted
equation and ell=-Re⟨q,v⟩ in addition to the stated resolvent hypotheses; magnetic
source assembly and potential calculus discharge those two bridges in their own
modules. It does not identify ell with a transfer Lyapunov derivative by definition.
-/

/-!
# The stationary bound for actual resolvents and the actual cone weight

This module joins the operator-resolvent analysis, the square-summable lattice
weight, and the stationary cancellation argument. Derivatives, nonvanishing
of the resolvent column, and the quadratic-form bounds are proved internally.

The local weighted equation remains an explicit application hypothesis, as
does the identity identifying the scalar `ell` with minus the Green pairing.
Consequently this theorem verifies the stationary step once those two bridges
are established; it is not the complete dry Ten Martini theorem.
-/

noncomputable section

namespace CriticalDTM

open scoped Topology

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]

/-- Root matrix element of the actual bounded-operator resolvent. -/
def projectedGreen (H : E →L[ℂ] E) (root : E) (z : ℂ) : ℂ :=
  @inner ℂ E _ root (resolvent H z root)

/-- The resolvent column with its projected root term subtracted. For a unit
root vector this removes its component in the root direction. -/
def removedColumn (H : E →L[ℂ] E) (root : E) (z : ℂ) : E :=
  resolvent H z root - projectedGreen H root z • root

omit [CompleteSpace E] in
/-- At a zero of the projected Green function the removed column is the
ordinary resolvent column. -/
theorem removedColumn_eq_resolvent_of_zero
    (H : E →L[ℂ] E) (root : E) (z : ℂ)
    (hzero : projectedGreen H root z = 0) :
    removedColumn H root z = resolvent H z root := by
  /- At the Green zero, and only after specializing there, the removed
     column agrees with the full resolvent column. The unweighted source
     is still the original root. -/
  simp only [removedColumn, hzero, zero_smul, sub_zero]

end CriticalDTM

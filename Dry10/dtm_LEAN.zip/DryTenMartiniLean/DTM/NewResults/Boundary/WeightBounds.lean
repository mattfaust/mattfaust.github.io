import DTM.NewResults.Boundary.ConeGeometry
import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.InnerProductSpace.Positive

/-!
# Proof guide: positive contraction

These are routine but necessary Hilbert-space supporting facts, not an assumed
formal weight bound. Multiplication by a real weight in [0,1] preserves genuine
square summability by domination. Real diagonal coefficients prove symmetry,
and absolutely convergent coordinate sums give 0 ≤ Re⟨u,Qu⟩ ≤ ‖u‖². Specializing
to qWeight gives the exact half-weighted cone used in the model-specific proof.
-/

/-!
# The actual diagonal weight on the lattice Hilbert space

We construct multiplication by a real weight in `[0,1]` as a continuous linear
operator on mathlib's genuine square-summable sequence space.  The cone weight
`qWeight` is then a specialization.  No operator or quadratic-form bound is
assumed in this file.
-/

noncomputable section

namespace CriticalDTM

abbrev LatticeHilbert := ℓ²(Site, ℂ)

variable {ι : Type*}

private theorem summable_sq_norm (u : ℓ²(ι, ℂ)) :
    Summable (fun i => ‖u i‖ ^ (2 : ℕ)) := by
  have h := (lp.memℓp u).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  simpa using h

private theorem norm_sq_eq_tsum (u : ℓ²(ι, ℂ)) :
    ‖u‖ ^ (2 : ℕ) = ∑' i, ‖u i‖ ^ (2 : ℕ) := by
  have h := lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) u
  simpa using h

variable (w : ι → ℝ) (hw0 : ∀ i, 0 ≤ w i) (hw1 : ∀ i, w i ≤ 1)

include hw0 hw1

private theorem weighted_coordinate_norm_le (u : ℓ²(ι, ℂ)) (i : ι) :
    ‖(w i : ℂ) * u i‖ ≤ ‖u i‖ := by
  /- Cone-compression support: multiplication by a real coefficient between zero
     and one cannot increase any coordinate norm. -/
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hw0 i)]
  simpa only [one_mul] using mul_le_mul_of_nonneg_right (hw1 i) (norm_nonneg (u i))

/-- Pointwise multiplication preserves square summability by domination. -/
def weightedVector (u : ℓ²(ι, ℂ)) : ℓ²(ι, ℂ) :=
  ⟨fun i => (w i : ℂ) * u i, by
    /- The squared weighted coordinates are bounded by the summable squared
       coordinates of u. Thus Q u is an actual ℓ² vector, not a formal sequence. -/
    apply memℓp_gen
    have h : Summable (fun i => ‖(w i : ℂ) * u i‖ ^ (2 : ℕ)) :=
      Summable.of_nonneg_of_le (fun i => sq_nonneg _)
        (fun i => (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).2
          (weighted_coordinate_norm_le w hw0 hw1 u i)) (summable_sq_norm u)
    simpa using h⟩

@[simp] theorem weightedVector_apply (u : ℓ²(ι, ℂ)) (i : ι) :
    weightedVector w hw0 hw1 u i = (w i : ℂ) * u i := rfl

theorem weightedVector_norm_le (u : ℓ²(ι, ℂ)) :
    ‖weightedVector w hw0 hw1 u‖ ≤ ‖u‖ := by
  apply (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  /- Summing the coordinate square bounds proves the norm contraction,
     including for infinitely supported vectors. -/
  rw [norm_sq_eq_tsum, norm_sq_eq_tsum]
  exact Summable.tsum_le_tsum
    (fun i => (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).2
      (weighted_coordinate_norm_le w hw0 hw1 u i))
    (summable_sq_norm (weightedVector w hw0 hw1 u)) (summable_sq_norm u)

/-- Real diagonal multiplication, constructed as a bounded complex-linear map. -/
def weightedOperator : ℓ²(ι, ℂ) →L[ℂ] ℓ²(ι, ℂ) :=
  LinearMap.mkContinuous
    { toFun := weightedVector w hw0 hw1
      map_add' := by
        intro u v
        apply lp.ext
        funext i
        simp [weightedVector_apply, mul_add]
      map_smul' := by
        intro c u
        apply lp.ext
        funext i
        simp [weightedVector_apply, mul_left_comm] }
    1 (fun u => by simpa using weightedVector_norm_le w hw0 hw1 u)

theorem weightedOperator_isSelfAdjoint : IsSelfAdjoint (weightedOperator w hw0 hw1) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro u v
  /- Cone-compression support: the coefficients are real, so they pass between the
     two entries of the conjugate-linear-first inner product without changing.
     The ℓ² inner-product series justifies this coordinatewise symmetry. -/
  rw [lp.inner_eq_tsum, lp.inner_eq_tsum]
  apply tsum_congr
  intro i
  change @inner ℂ _ _ ((w i : ℂ) • u i) (v i) = @inner ℂ _ _ (u i) ((w i : ℂ) • v i)
  simp only [inner_smul_left, inner_smul_right, Complex.conj_ofReal]

omit hw0 hw1

/-- The exact diagonal weight used in the manuscript, on `ℓ²(ℤ²,ℂ)`. -/
def coneWeightOperator : LatticeHilbert →L[ℂ] LatticeHilbert :=
  weightedOperator qWeight qWeight_nonneg qWeight_le_one

@[simp] theorem coneWeightOperator_apply (u : LatticeHilbert) (s : Site) :
    coneWeightOperator u s = (qWeight s : ℂ) * u s := rfl

theorem coneWeightOperator_isSelfAdjoint : IsSelfAdjoint coneWeightOperator :=
  weightedOperator_isSelfAdjoint qWeight qWeight_nonneg qWeight_le_one

/- The stationary height-response calculation: specialize the proved scalar-sum bounds to the cone
   weights 1, 1/2, and 0. These are the only positivity and contractivity
   inputs to the stationary ratio. -/

end CriticalDTM

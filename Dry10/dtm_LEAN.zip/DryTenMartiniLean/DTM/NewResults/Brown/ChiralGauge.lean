import DTM.Background.Realization.MagneticOperators
import Mathlib.Analysis.InnerProductSpace.LinearMap

/-!
# Exact receiving-row gauge for the chiral notation

The index remains (j,k); its displayed chiral coordinates are x=j+k,y=j-k.
The phase has modulus one and equals one at the source. The pointwise
intertwining below holds for arbitrary lattice functions, not merely finite
support vectors. Bounded Hilbert-space realization is stated separately in
the companion; no topology is encoded in a finite matrix approximation.
-/

noncomputable section
namespace DTMCompanion.ChiralGauge
open CriticalDTM

def character (α t : ℝ) : ℂ :=
  Complex.exp (((Real.pi * α * t : ℝ) : ℂ) * Complex.I)

theorem character_add (α a b : ℝ) :
    character α (a+b) = character α a * character α b := by
  unfold character
  rw [show (((Real.pi * α * (a+b) : ℝ) : ℂ) * Complex.I) =
    (((Real.pi * α * a : ℝ) : ℂ) * Complex.I) +
    (((Real.pi * α * b : ℝ) : ℂ) * Complex.I) by push_cast; ring]
  exact Complex.exp_add _ _

theorem magneticPhase_eq_character (α : ℝ) (j : ℤ) :
    magneticPhase α j = character α (2*(j:ℝ)) := by
  unfold magneticPhase character
  congr 3
  ring

@[simp] theorem character_norm (α t : ℝ) : ‖character α t‖ = 1 :=
  Complex.norm_exp_ofReal_mul_I _

variable {E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [NormedAddCommGroup F] [InnerProductSpace ℂ F]

end DTMCompanion.ChiralGauge

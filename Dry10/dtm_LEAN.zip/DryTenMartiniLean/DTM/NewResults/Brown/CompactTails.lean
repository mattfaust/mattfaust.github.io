import DTM.NewResults.Brown.ScalarTails
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Analysis.Normed.Algebra.Spectrum

/-!
# Uniform Brown tails on a compact separated real spectral set

Compactness upgrades the pointwise inside/outside ratios to strict uniform
norm bounds. The resulting series converge in the supremum norm. This is
the norm convergence required before applying the continuous functional
calculus or interchanging the Fourier integral with the series.
-/

noncomputable section
namespace DTMCompanion.Brown
open Filter
open scoped Topology

variable {X : Type*} [TopologicalSpace X] [CompactSpace X]

def insideIndicator (r : ℝ) (f : C(X, ℝ)) (hsep : ∀ x, |f x| ≠ r) : C(X, ℝ) where
  toFun x := if |f x| < r then 1 else 0
  continuous_toFun := by
    apply continuous_iff_continuousAt.mpr
    intro x
    by_cases hx : |f x| < r
    · have hnear : ∀ᶠ y in 𝓝 x, |f y| < r :=
        (f.continuous.continuousAt.abs).eventually (gt_mem_nhds hx)
      apply (show ContinuousAt (fun _ : X => (1 : ℝ)) x from continuousAt_const).congr_of_eventuallyEq
      filter_upwards [hnear] with y hy
      simp [hy, hx]
    · have hx' : r < |f x| := lt_of_le_of_ne (le_of_not_gt hx) (hsep x).symm
      have hnear : ∀ᶠ y in 𝓝 x, r < |f y| :=
        (f.continuous.continuousAt.abs).eventually (lt_mem_nhds hx')
      apply (show ContinuousAt (fun _ : X => (0 : ℝ)) x from continuousAt_const).congr_of_eventuallyEq
      filter_upwards [hnear] with y hy
      simp [not_lt_of_gt hy, hx]

def insideRatio (r : ℝ) (f : C(X, ℝ)) (hsep : ∀ x, |f x| ≠ r) : C(X, ℝ) :=
  r⁻¹ • (f * insideIndicator r f hsep)

def insideCoefficient (r : ℝ) (f : C(X, ℝ)) (hsep : ∀ x, |f x| ≠ r)
    (n : ℕ) : C(X, ℝ) :=
  r⁻¹ • ((insideRatio r f hsep) ^ n * insideIndicator r f hsep)

omit [CompactSpace X] in
theorem insideCoefficient_apply (r : ℝ) (f : C(X, ℝ))
    (hsep : ∀ x, |f x| ≠ r) (n : ℕ) (x : X) :
    insideCoefficient r f hsep n x = insideKernel r (f x) n := by
  by_cases hx : |f x| < r
  · simp [insideCoefficient, insideRatio, insideIndicator, insideKernel,
      insideTail, hx, div_eq_mul_inv, mul_comm]
  · simp [insideCoefficient, insideRatio, insideIndicator, insideKernel, hx]

end DTMCompanion.Brown

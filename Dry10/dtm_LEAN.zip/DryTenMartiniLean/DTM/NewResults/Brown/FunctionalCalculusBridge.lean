import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Instances

/-! # Pointwise adapters for continuous functional calculus

The adapters below transfer an already continuous spectral function to the
usual bare-function CFC notation; continuity is derived from the equality.
-/

namespace DTMCompanion.Brown
open scoped ContinuousFunctionalCalculus

theorem cfcHom_eq_cfc_of_pointwise
    {𝕜 A : Type*} [RCLike 𝕜] [NormedRing A] [StarRing A] [NormedAlgebra 𝕜 A]
    {p : A → Prop} [ContinuousFunctionalCalculus 𝕜 A p]
    {a : A} (ha : p a) (f : C(spectrum 𝕜 a, 𝕜)) (g : 𝕜 → 𝕜)
    (heq : ∀ x : spectrum 𝕜 a, f x = g x) :
    cfcHom ha f = cfc g a := by
  have hf : ContinuousOn g (spectrum 𝕜 a) := by
    apply continuousOn_iff_continuous_restrict.mpr
    have hfun : (spectrum 𝕜 a).restrict g = f := funext fun x => (heq x).symm
    rw [hfun]
    exact f.continuous
  rw [cfc_apply g a ha hf]
  congr 1
  ext x
  exact heq x

end DTMCompanion.Brown

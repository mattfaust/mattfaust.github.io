import DTM.Background.AllCouplingExtension.MagneticDOSDuality
import DTM.Background.EmpiricalIDS.AMOEmpiricalCDF
import DTM.NewResults.Brown.SpectralCircle
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Instances

/-! # The actual operator Fourier integral and its two spectral tails -/

noncomputable section
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 200000
namespace CriticalDTM
open DTMCompanion.Brown Complex MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

local instance brownFourier_realNormedSpace (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

abbrev BrownComplexSpectrum (α lam : ℝ) := spectrum ℂ (magneticAlgebraHamiltonian α lam)

def brownComplexCoordinate (α lam : ℝ) : C(BrownComplexSpectrum α lam, ℝ) :=
  ⟨fun x => (x : ℂ).re, Complex.continuous_re.comp continuous_subtype_val⟩

end CriticalDTM

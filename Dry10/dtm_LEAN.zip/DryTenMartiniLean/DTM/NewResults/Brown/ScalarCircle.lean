import DTM.NewResults.Brown.ScalarTails
import Mathlib.Analysis.Complex.CauchyIntegral

/-! # Actual circle integrals of the scalar Brown resolvent

The coefficients here are defined by Bochner circle integrals, not by the
geometric-series formulas. The latter formulas are derived below.
-/

noncomputable section
namespace DTMCompanion.Brown
open Complex Metric Set
open scoped Topology

def scalarMoment (r t : ℝ) (n : ℕ) : ℂ :=
  (2 * Real.pi * I)⁻¹ * ∮ z in C(0, 1), z ^ n * ((r : ℂ) * z - t)⁻¹

def scalarFourier (r t : ℝ) (n : ℤ) : ℂ :=
  (2 * Real.pi * I)⁻¹ * ∮ z in C(0, 1), z ^ (-n - 1) * ((r : ℂ) * z - t)⁻¹

theorem two_pi_I_ne_zero : (2 * Real.pi * I : ℂ) ≠ 0 := by
  exact mul_ne_zero (mul_ne_zero (by norm_num) (by exact_mod_cast Real.pi_ne_zero)) I_ne_zero

theorem scalar_denominator_ne_zero {r t : ℝ} (hr : 0 < r) (hsep : |t| ≠ r)
    {z : ℂ} (hz : z ∈ sphere 0 1) : (r : ℂ) * z - t ≠ 0 := by
  intro heq
  have hnorm := congrArg norm (sub_eq_zero.mp heq)
  have hz' : ‖z‖ = 1 := by simpa using hz
  simp only [norm_mul, norm_real, Real.norm_eq_abs, hz', mul_one, abs_of_pos hr] at hnorm
  exact hsep hnorm.symm

theorem scalarMoment_inside {r t : ℝ} (hr : 0 < r) (ht : |t| < r) (n : ℕ) :
    scalarMoment r t n = (insideTail r t n : ℂ) := by
  have hr0 : (r : ℂ) ≠ 0 := by exact_mod_cast hr.ne'
  have hw : (t : ℂ) / r ∈ ball 0 1 := by
    simpa [Complex.norm_div, abs_of_pos hr, div_lt_one hr] using ht
  have hc := ((differentiable_id.pow n).differentiableOn :
    DifferentiableOn ℂ (fun z : ℂ => z ^ n) (closedBall 0 1)).circleIntegral_sub_inv_smul hw
  have heq : (fun z : ℂ => z ^ n * ((r : ℂ) * z - t)⁻¹) =
      (fun z : ℂ => (r : ℂ)⁻¹ * ((z - (t : ℂ) / r)⁻¹ * z ^ n)) := by
    funext z
    have hden : (r : ℂ) * z - t = r * (z - (t : ℂ) / r) := by field_simp; ring
    rw [hden, mul_inv_rev]
    ring
  unfold scalarMoment
  rw [heq, circleIntegral.integral_const_mul]
  simp only [smul_eq_mul, id_eq] at hc
  rw [hc]
  dsimp [insideTail]
  push_cast
  field_simp [two_pi_I_ne_zero]

theorem scalarMoment_outside {r t : ℝ} (hr : 0 < r) (ht : r < |t|) (n : ℕ) :
    scalarMoment r t n = 0 := by
  have hden : ∀ z ∈ closedBall (0 : ℂ) 1, (r : ℂ) * z - t ≠ 0 := by
    intro z hz h
    have hnorm := congrArg norm (sub_eq_zero.mp h)
    have hz' : ‖z‖ ≤ 1 := by simpa using hz
    simp only [norm_mul, norm_real, Real.norm_eq_abs, abs_of_pos hr] at hnorm
    have : |t| ≤ r := by nlinarith [norm_nonneg z]
    exact (not_le_of_gt ht) this
  have hd : DifferentiableOn ℂ
      (fun z : ℂ => z ^ n * ((r : ℂ) * z - t)⁻¹) (closedBall 0 1) := by
    apply (differentiable_id.pow n).differentiableOn.mul
    apply (((differentiable_const (r : ℂ)).mul differentiable_id).sub
      (differentiable_const (t : ℂ))).differentiableOn.inv
    exact hden
  have hc := Complex.circleIntegral_eq_zero_of_differentiable_on_off_countable
    (E := ℂ) (c := 0) (R := 1) (by norm_num) (s := ∅) Set.countable_empty
    hd.continuousOn
    (fun z hz => hd.differentiableAt
      (Filter.mem_of_superset (isOpen_ball.mem_nhds hz.1) ball_subset_closedBall))
  simp only [scalarMoment, hc, mul_zero]

theorem scalarFourier_negative (r t : ℝ) (n : ℕ) :
    scalarFourier r t (-(n : ℤ) - 1) = scalarMoment r t n := by
  simp [scalarFourier, scalarMoment]

theorem scalarFourier_inside_negative {r t : ℝ} (hr : 0 < r) (ht : |t| < r)
    (n : ℕ) : scalarFourier r t (-(n : ℤ) - 1) = (insideTail r t n : ℂ) := by
  rw [scalarFourier_negative]
  exact scalarMoment_inside hr ht n

theorem scalarFourier_outside_negative {r t : ℝ} (hr : 0 < r) (ht : r < |t|)
    (n : ℕ) : scalarFourier r t (-(n : ℤ) - 1) = 0 := by
  rw [scalarFourier_negative]
  exact scalarMoment_outside hr ht n

end DTMCompanion.Brown

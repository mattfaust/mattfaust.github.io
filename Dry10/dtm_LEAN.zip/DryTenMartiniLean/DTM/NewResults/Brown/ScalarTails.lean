import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

/-!
# Scalar spectral kernels of the Brown inverse

The two series below are the inside and outside geometric expansions of the
literal scalar resolvent.  These results are analytic lemmas for the later
continuous-functional-calculus construction, not assumptions identifying an
arbitrary family with the physical Fourier coefficients.
-/

noncomputable section
namespace DTMCompanion.Brown

def insideTail (r t : ℝ) (n : ℕ) : ℝ := r⁻¹ * (t / r) ^ n

def insideKernel (r t : ℝ) (n : ℕ) : ℝ :=
  if |t| < r then insideTail r t n else 0

end DTMCompanion.Brown

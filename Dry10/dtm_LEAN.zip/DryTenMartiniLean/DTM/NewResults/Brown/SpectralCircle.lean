import DTM.NewResults.Brown.CompactTails
import DTM.NewResults.Brown.ScalarCircle
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

/-! # Circle integration in the compact spectral function algebra

The spectral coefficients are Bochner integrals in the supremum norm. Point
evaluation commutes with this integral by a proved continuous-linear-map
identity; the resulting scalar integral is the actual scalar Brown coefficient.
-/

noncomputable section
namespace DTMCompanion.Brown
open Complex Metric Set MeasureTheory
open scoped Topology
variable {X : Type*} [TopologicalSpace X] [CompactSpace X]

def complexify (f : C(X, ℝ)) : C(X, ℂ) :=
  ⟨fun x => (f x : ℂ), Complex.continuous_ofReal.comp f.continuous⟩

def spectralCircleKernel (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) (θ : ℝ) : C(X, ℂ) where
  toFun x := ((r : ℂ) * circleMap 0 1 θ - f x)⁻¹
  continuous_toFun :=
    (continuous_const.sub (Complex.continuous_ofReal.comp f.continuous)).inv₀
      (fun x => scalar_denominator_ne_zero hr (hsep x)
        (circleMap_mem_sphere 0 (by norm_num : (0 : ℝ) ≤ 1) θ))

omit [CompactSpace X] in
theorem spectralCircleKernel_continuous (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) : Continuous (spectralCircleKernel r f hr hsep) := by
  have hjoint : Continuous (fun p : ℝ × X =>
      ((r : ℂ) * circleMap 0 1 p.1 - f p.2)⁻¹) := by
    apply ((continuous_const.mul ((continuous_circleMap 0 1).comp continuous_fst)).sub
      (Complex.continuous_ofReal.comp (f.continuous.comp continuous_snd))).inv₀
    intro p
    exact scalar_denominator_ne_zero hr (hsep p.2)
      (circleMap_mem_sphere 0 (by norm_num : (0 : ℝ) ≤ 1) p.1)
  exact (ContinuousMap.curry ⟨_, hjoint⟩).continuous

def spectralCircleIntegrand (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) (n : ℤ) (θ : ℝ) : C(X, ℂ) :=
  (deriv (circleMap 0 1) θ * (circleMap 0 1 θ) ^ (-n - 1)) •
    spectralCircleKernel r f hr hsep θ

theorem spectralCircleIntegrand_continuous (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) (n : ℤ) :
    Continuous (spectralCircleIntegrand r f hr hsep n) := by
  unfold spectralCircleIntegrand
  apply Continuous.smul
  · apply Continuous.mul
    · change Continuous (fun θ : ℝ => deriv (circleMap 0 1) θ)
      simp only [deriv_circleMap]
      exact (continuous_circleMap 0 1).mul (show Continuous (fun _ : ℝ => I) from continuous_const)
    · apply (continuous_circleMap 0 1).zpow₀
      intro θ
      left
      exact circleMap_ne_center (by norm_num : (1 : ℝ) ≠ 0)
  · exact spectralCircleKernel_continuous r f hr hsep

def spectralCircleCoefficient (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) (n : ℤ) : C(X, ℂ) :=
  (2 * Real.pi * I : ℂ)⁻¹ •
    ∫ θ in (0 : ℝ)..(2 * Real.pi), spectralCircleIntegrand r f hr hsep n θ

theorem spectralCircleCoefficient_apply (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) (n : ℤ) (x : X) :
    spectralCircleCoefficient r f hr hsep n x = scalarFourier r (f x) n := by
  have hi : IntervalIntegrable (spectralCircleIntegrand r f hr hsep n)
      volume 0 (2 * Real.pi) :=
    (spectralCircleIntegrand_continuous r f hr hsep n).intervalIntegrable 0 (2 * Real.pi)
  have hmap := (ContinuousMap.evalCLM (R := ℂ) (M := ℂ) x).intervalIntegral_comp_comm hi
  simp only [ContinuousMap.evalCLM_apply] at hmap
  unfold spectralCircleCoefficient scalarFourier circleIntegral
  change (2 * Real.pi * I : ℂ)⁻¹ *
    ((∫ θ in (0 : ℝ)..(2 * Real.pi), spectralCircleIntegrand r f hr hsep n θ) x) = _
  rw [← hmap]
  congr 1
  apply intervalIntegral.integral_congr
  intro θ _
  simp only [ContinuousMap.evalCLM_apply, spectralCircleIntegrand, ContinuousMap.smul_apply,
    smul_eq_mul, spectralCircleKernel, ContinuousMap.coe_mk, mul_assoc]

theorem spectralCircleCoefficient_negative (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r)
    (hsep : ∀ x, |f x| ≠ r) (n : ℕ) :
    spectralCircleCoefficient r f hr hsep (-(n : ℤ) - 1) =
      complexify (insideCoefficient r f hsep n) := by
  ext x
  rw [spectralCircleCoefficient_apply]
  change _ = (insideCoefficient r f hsep n x : ℂ)
  rw [insideCoefficient_apply]
  by_cases hx : |f x| < r
  · simp only [insideKernel, if_pos hx]
    exact scalarFourier_inside_negative hr hx n
  · simp only [insideKernel, if_neg hx, Complex.ofReal_zero]
    exact scalarFourier_outside_negative hr
      (lt_of_le_of_ne (le_of_not_gt hx) (hsep x).symm) n

omit [CompactSpace X] in
theorem spectralCircleKernel_map_continuous {A : Type*} [NormedAddCommGroup A]
    [NormedSpace ℂ A] (L : C(X, ℂ) →L[ℂ] A)
    (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r) (hsep : ∀ x, |f x| ≠ r) :
    Continuous (fun θ => L (spectralCircleKernel r f hr hsep θ)) :=
  L.continuous.comp (spectralCircleKernel_continuous r f hr hsep)

theorem spectralCircleCoefficient_map {A : Type*} [NormedAddCommGroup A]
    [NormedSpace ℂ A] [CompleteSpace A] (L : C(X, ℂ) →L[ℂ] A)
    (r : ℝ) (f : C(X, ℝ)) (hr : 0 < r) (hsep : ∀ x, |f x| ≠ r) (n : ℤ) :
    L (spectralCircleCoefficient r f hr hsep n) =
      (2 * Real.pi * I : ℂ)⁻¹ • ∫ θ in (0 : ℝ)..(2 * Real.pi),
        (deriv (circleMap 0 1) θ * circleMap 0 1 θ ^ (-n - 1)) •
          L (spectralCircleKernel r f hr hsep θ) := by
  have hi := (spectralCircleIntegrand_continuous r f hr hsep n).intervalIntegrable
    (μ := volume) 0 (2 * Real.pi)
  unfold spectralCircleCoefficient
  rw [map_smul, ← L.intervalIntegral_comp_comm hi]
  congr 1
  apply intervalIntegral.integral_congr
  intro θ _
  exact L.map_smul _ _

end DTMCompanion.Brown

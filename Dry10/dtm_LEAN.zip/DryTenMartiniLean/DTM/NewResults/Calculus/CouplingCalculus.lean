import DTM.NewResults.Boundary.MagneticSource
import DTM.NewResults.Boundary.MagneticSymmetry
import Mathlib.Tactic.Module

/-!
# Proof guide: local calculus

Operator-norm coupling calculus for the physical potential derivative
and the local Green-zero branch. The explicit vertical operator B is
the derivative of H_lambda=A+lambda B, and inversion gives the ordered derivative
R B R. No spectral measure is held fixed during coupling differentiation; no
logarithmic or Lyapunov derivative is assumed here.
-/

/-!
# Actual dependence of the magnetic operator and resolvent on coupling

The coupling derivative is proved in operator norm for the constructed
magnetic operator. In particular, these results do not differentiate a fixed
spectral measure or assume the desired Lyapunov derivative identity.
-/

noncomputable section

namespace CriticalDTM

/-- The vertical hopping operator, the actual derivative of H with respect
to the coupling. -/
/- Define the actual operator B by its two twisted vertical shifts before using any of its properties. -/
def verticalOperator (α : ℝ) : LatticeHilbert →L[ℂ] LatticeHilbert :=
  twistedOperator northEquiv (fun s => magneticPhase α s.1)
    (fun s => magneticPhase_norm α s.1) +
  twistedOperator northEquiv.symm (fun s => magneticPhase α (-s.1))
    (fun s => magneticPhase_norm α (-s.1))

/- This exact operator equality gives the coupling derivative -B of the unscaled pencil E*1-H_lambda. -/
theorem hOperator_affine (α : ℝ) (lam : ℂ) :
    hOperator α lam = hOperator α 0 + lam • verticalOperator α := by
  simp [hOperator, verticalOperator, smul_add, add_assoc]

theorem verticalOperator_eq_difference (α : ℝ) :
    verticalOperator α = hOperator α 1 - hOperator α 0 := by
  rw [hOperator_affine α 1, one_smul]
  abel

/- Physical operator norm bound: norm(H_lambda-H_mu)<=2*|lambda-mu| supplies genuine norm continuity of the physical pencil. -/

theorem hOperator_hasDerivAt (α : ℝ) (lam : ℂ) :
    HasDerivAt (hOperator α) (verticalOperator α) lam := by
  have h := ((hasDerivAt_id lam).smul_const (verticalOperator α)).const_add
    (hOperator α 0)
  simpa only [one_smul, ← hOperator_affine] using h

/- Restrict the complex affine coupling derivative to real parameters; its value is B. -/

theorem hOperator_continuous (α : ℝ) : Continuous (hOperator α) :=
  continuous_iff_continuousAt.mpr (fun lam => (hOperator_hasDerivAt α lam).continuousAt)

/- Physical source: B*Omega=v is exactly the two vertical root neighbors. The origin and source have not been rescaled. -/
theorem verticalOperator_root (α : ℝ) : verticalOperator α hilbertRoot = verticalRoot := by
  rw [verticalOperator_eq_difference]
  simp only [ContinuousLinearMap.sub_apply, hOperator_root_expansion]
  simp only [one_smul, zero_smul, add_zero, verticalRoot]
  abel

/- Auxiliary joint regularity: apply the fixed root matrix element to R*B*R. At a real energy self-adjointness gives <R*Omega,B*R*Omega>. -/

end CriticalDTM

import DTM.NewResults.Calculus.TraceGreenBridge
import DTM.NewResults.Calculus.TracialLogDerivative
import DTM.NewResults.Continuation.GapMaximum

/-!
# Proof guide: local calculus

Local calculus for the physical logarithmic potential.
The CFC value is one half of magneticTraceReal(log((E*1-H_lambda)^2)). Its DOS
integral interpretation comes from MagneticIntegralBridge; its agreement with
the global positive representative in the needed regime follows from potential normalization via
LogPotentialExtension/LogPotentialBoundary. The total Lean CFC.log definition is
NOT a bounded logarithm assertion at spectral energies. Every analytic conclusion
requires actual resolvent membership; no real-gap transfer-L equality is claimed.
-/

/-!
# The actual magnetic logarithmic potential

The potential is one half of the constructed canonical trace of the continuous
functional calculus logarithm of the squared magnetic pencil. Its energy and
coupling derivatives follow from the proved tracial logarithm theorem. This
module does not identify this potential with a transfer-matrix Lyapunov exponent.
The definition is total because `CFC.log` is total; all analytic conclusions
here require the energy to lie in the actual resolvent set.
-/

noncomputable section

namespace CriticalDTM

open scoped Topology

local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

local instance (α : ℝ) : Module ℝ (magneticAlgebra α) :=
  @Algebra.toModule ℝ (magneticAlgebra α) _ _
    (magneticAlgebra_realNormedAlgebra α).toAlgebra

def magneticAlgebraVertical (α : ℝ) : magneticAlgebra α :=
  ⟨verticalOperator α, verticalOperator_mem_magneticAlgebra α⟩

def magneticAlgebraHamiltonian (α lam : ℝ) : magneticAlgebra α :=
  (⟨hOperator α 0, hOperator_mem_magneticAlgebra α 0⟩ : magneticAlgebra α) +
    lam • magneticAlgebraVertical α

/- The unscaled pencil E*1-H_lambda lies in the fixed magnetic algebra. No sqrt(lambda) energy or extra logarithmic normalization is introduced. -/
def magneticAlgebraPencil (α lam energy : ℝ) : magneticAlgebra α :=
  energy • (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α lam

@[simp] theorem magneticAlgebraHamiltonian_coe (α lam : ℝ) :
    (magneticAlgebraHamiltonian α lam : MagneticBoundedOperator) =
      hOperator α (lam : ℂ) := by
  change hOperator α 0 + lam • verticalOperator α = _
  rw [hOperator_affine α (lam : ℂ), Complex.coe_smul]

theorem magneticAlgebraHamiltonian_isSelfAdjoint (α lam : ℝ) :
    IsSelfAdjoint (magneticAlgebraHamiltonian α lam) := by
  apply Subtype.ext
  change star (magneticAlgebraHamiltonian α lam : MagneticBoundedOperator) = _
  rw [magneticAlgebraHamiltonian_coe]
  exact hOperator_isSelfAdjoint α lam

@[simp] theorem magneticAlgebraPencil_coe (α lam energy : ℝ) :
    (magneticAlgebraPencil α lam energy : MagneticBoundedOperator) =
      algebraMap ℂ MagneticBoundedOperator (energy : ℂ) -
        hOperator α (lam : ℂ) := by
  change energy • (1 : MagneticBoundedOperator) -
    (magneticAlgebraHamiltonian α lam : MagneticBoundedOperator) = _
  rw [magneticAlgebraHamiltonian_coe, Algebra.algebraMap_eq_smul_one, Complex.coe_smul]

theorem magneticAlgebraPencil_isSelfAdjoint (α lam energy : ℝ) :
    IsSelfAdjoint (magneticAlgebraPencil α lam energy) := by
  apply Subtype.ext
  change star (magneticAlgebraPencil α lam energy : MagneticBoundedOperator) = _
  rw [magneticAlgebraPencil_coe]
  rw [Algebra.algebraMap_eq_smul_one]
  exact ((show IsSelfAdjoint (energy : ℂ) from Complex.conj_ofReal energy).smul
    (IsSelfAdjoint.one MagneticBoundedOperator)).sub (hOperator_isSelfAdjoint α lam)

/- Tracial logarithm and potential calculus: spectral permanence transports actual resolvent membership to invertibility in the closed star algebra. -/
theorem magneticAlgebraPencil_isUnit (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    IsUnit (magneticAlgebraPencil α lam energy) := by
  apply (magneticAlgebra α).coe_isUnit.mp
  rw [magneticAlgebraPencil_coe]
  exact hm

/- Multiplication by the actual pencil identifies its algebra inverse with the actual bounded-operator resolvent, not a postulated Green operator. -/
theorem magneticAlgebraPencil_inverse_coe (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    ((Ring.inverse (magneticAlgebraPencil α lam energy) : magneticAlgebra α) : MagneticBoundedOperator) =
      resolvent (hOperator α (lam : ℂ)) (energy : ℂ) := by
  have hleft := congrArg (fun A : magneticAlgebra α => (A : MagneticBoundedOperator))
    (Ring.inverse_mul_cancel _ (magneticAlgebraPencil_isUnit α lam energy hm))
  change ((Ring.inverse (magneticAlgebraPencil α lam energy) : magneticAlgebra α) : MagneticBoundedOperator) *
    (magneticAlgebraPencil α lam energy : MagneticBoundedOperator) = 1 at hleft
  rw [magneticAlgebraPencil_coe] at hleft
  exact left_inv_eq_right_inv hleft (Ring.mul_inverse_cancel _ hm)

/-- The CFC logarithmic potential of the actual magnetic operator. -/
/- Square-log normalization: the factor 1/2 compensates for the square logarithm. Global finiteness and spectral values belong to the logarithmic-potential normalization theorem, not this totalized definition. -/
def magneticLogPotential (α lam energy : ℝ) : ℝ :=
  magneticTraceReal α (CFC.log ((magneticAlgebraPencil α lam energy) ^ 2)) / 2

/- The unscaled energy pencil has derivative the identity. -/
theorem magneticAlgebraPencil_energy_hasDerivAt (α lam energy : ℝ) :
    HasDerivAt (magneticAlgebraPencil α lam) 1 energy := by
  simpa only [magneticAlgebraPencil, one_smul] using
    ((hasDerivAt_id energy).smul_const (1 : magneticAlgebra α)).sub_const
      (magneticAlgebraHamiltonian α lam)

/- The actual affine Hamiltonian gives pencil derivative -B, fixing the sign of the coupling derivative. -/

/- Sigma(C^(-1))=Re<Omega,R*Omega>=g at real resolvent energies. -/
theorem magneticTraceReal_inverse_eq_green (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticTraceReal α (Ring.inverse (magneticAlgebraPencil α lam energy)) =
      realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot energy := by
  rw [magneticTraceReal_apply, magneticAlgebraPencil_inverse_coe α lam energy hm,
    rootTrace_resolvent_eq_green]
  rfl

/- Sigma(C^(-1)*(-B)) equals the independently defined -Re<q,v> through the proved BR/RB root-trace bridge. -/

/- Energy derivatives: apply the tracial logarithm derivative to C(E)=E*1-H with derivative 1. This is the actual trace-log route, not an assumed real-gap Thouless derivative. -/
theorem magneticLogPotential_energy_hasDerivAt (α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    HasDerivAt (magneticLogPotential α lam)
      (realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot energy) energy := by
  have h := half_trace_cfc_log_sq_hasDerivAt (magneticTraceReal α)
    (magneticTraceReal_cyclic α) (magneticAlgebraPencil α lam) (fun _ => 1) energy
    (Filter.Eventually.of_forall (magneticAlgebraPencil_energy_hasDerivAt α lam))
    (Filter.Eventually.of_forall (magneticAlgebraPencil_isSelfAdjoint α lam))
    continuousAt_const (magneticAlgebraPencil_isUnit α lam energy hm)
  simpa only [magneticLogPotential, mul_one,
    magneticTraceReal_inverse_eq_green α lam energy hm] using h

/- Coupling derivative: apply the proved trace-log theorem with derivative -B, then identify its fixed trace with -Re<q,v>. -/

end CriticalDTM

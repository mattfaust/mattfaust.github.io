import DTM.Background.Realization.MagneticTraceCoupling
import DTM.NewResults.Boundary.Main
import DTM.Background.Labels.TraceProjection

/-!
# Proof guide: local calculus

Fixed real trace and source sign for the physical potential derivative.
Taking Re of the actual root functional gives the continuous real-linear trace
used in the tracial logarithm derivative. The Green coupling scalar is proved to equal minus
Re trace(BR)=minus Re trace(RB), connecting the stationary height-response calculation to an actual potential
derivative without defining a Lyapunov exponent or derivative by that scalar.
-/

/-!
# The actual canonical trace and the Green coupling value

The trace is the constructed normalized root functional, restricted to the
closed magnetic star algebra where cyclicity has been proved. Its product
with the coupling derivative is identified with the actual Green entries.
-/

noncomputable section

namespace CriticalDTM

instance magneticAlgebra_realNormedAlgebra (α : ℝ) :
    NormedAlgebra ℝ (magneticAlgebra α) :=
  NormedAlgebra.restrictScalars ℝ ℂ (magneticAlgebra α)

/- Concrete B-row: both vertical shifts and receiving-coordinate magnetic phases are retained; the phases at the physical origin are one. -/

/- Source-entry bridge: the root entry of B*A is the sum of the north and south entries of A*Omega. -/

/- Reality check: adjunction conjugates the actual vector-state root trace; no independent reality axiom is used. -/

/- Optional reality strengthening: adjunction reverses the self-adjoint factors, and cyclicity restores their traced order. -/

/- Trace-log order: cyclicity converts B*R to R*B, the inverse-times-pencil-derivative order, and preserves the minus sign. -/

/-- The real part of the actual canonical trace, on its actual traced algebra. -/
/- For the tracial logarithm and potential calculus, sigma is Re of the fixed root functional restricted to the actual closed magnetic algebra, not a coupling-dependent measure. -/
def magneticTraceReal (α : ℝ) : magneticAlgebra α →L[ℝ] ℝ :=
  Complex.reCLM.comp ((rootTrace.comp
    (magneticAlgebra α).toSubalgebra.toSubmodule.subtypeL).restrictScalars ℝ)

@[simp] theorem magneticTraceReal_apply (α : ℝ) (A : magneticAlgebra α) :
    magneticTraceReal α A = (rootTrace (A : MagneticBoundedOperator)).re := rfl

/- The cyclicity hypothesis is discharged by the actual magnetic-monomial/norm-closure trace theorem. -/
theorem magneticTraceReal_cyclic (α : ℝ) : CyclicTrace (magneticTraceReal α) := by
  intro A B
  exact congrArg Complex.re (rootTrace_magneticAlgebra_cyclic α A.property B.property)

theorem magneticTraceReal_one (α : ℝ) : magneticTraceReal α 1 = 1 := by
  simp

/-- Positivity is supplied by the actual root vector state. -/
/- Root-trace positivity: trace(A^*A)=norm(A*Omega)^2 for the one physical root, with no added Hilbert-space representation. -/
theorem magneticTraceReal_star_mul_self (α : ℝ) (A : magneticAlgebra α) :
    magneticTraceReal α (star A * A) =
      ‖(A : MagneticBoundedOperator) hilbertRoot‖ ^ 2 := by
  rw [magneticTraceReal_apply, rootTrace_eq_inner]
  change (@inner ℂ LatticeHilbert _ hilbertRoot
    (star (A : MagneticBoundedOperator) ((A : MagneticBoundedOperator) hilbertRoot))).re = _
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  exact inner_self_eq_norm_sq (𝕜 := ℂ) _

theorem magneticTraceReal_star_mul_self_nonneg (α : ℝ) (A : magneticAlgebra α) :
    0 ≤ magneticTraceReal α (star A * A) := by
  rw [magneticTraceReal_star_mul_self]
  positivity

end CriticalDTM

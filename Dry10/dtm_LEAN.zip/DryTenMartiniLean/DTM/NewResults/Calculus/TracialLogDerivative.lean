import DTM.Background.Labels.TraceProjection
import DTM.Background.Support.PositiveRescaling
import Mathlib.Analysis.Calculus.FDeriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.SmoothSeries
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.ExpLog
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic.Ring

/-!
# Proof guide: local calculus

Tracial logarithm derivative, complete power-series proof:
noncommutative product rule -> cyclic collapse -> uniform geometric bounds ->
infinite-series differentiation -> uniform spectral/CFC identification -> positive
rescaling -> two square-product terms -> one-half normalization. The application
uses magneticTraceReal. Inverse-curve derivatives are proved separately; the logarithm
proof does not use a resolvent-integral representation. All locality and bound
hypotheses are proved before the final derivative is invoked.
-/

/-!
# Verified ingredients for differentiating a tracial logarithm

This file proves derivatives of traced noncommutative powers, logarithmic
polynomial truncations, and the convergent local logarithmic series. It also
proves the traced inverse derivative used in integral representations.

Termwise differentiation is justified by an explicitly proved uniform
geometric bound. The series is identified with `CFC.log` through uniform
convergence on the spectrum. Positive rescaling then proves the actual CFC
trace derivative. The final theorem constructs the scale, neighborhood, and
uniform bounds for any locally self-adjoint continuously differentiable curve
through an invertible point; no logarithm derivative is assumed.
-/

noncomputable section

namespace CriticalDTM

open scoped Topology

variable {A : Type*} [NormedRing A] [NormedAlgebra ℝ A]

/-- The product-rule derivative of the noncommutative power map. -/
/- Noncommutative product rule: the recursive tangent records every placement of the derivative. It is not n*a^(n-1)*d as an operator identity. -/
def powerTangent (a d : A) : ℕ → A
  | 0 => 0
  | n + 1 => powerTangent a d n * a + a ^ n * d

/-- Genuine derivatives of powers require no commutation between a curve
and its derivative. -/
/- Differentiate each finite power by induction and the actual product rule; no commutation hypothesis appears. -/
theorem power_hasDerivAt
    (B : ℝ → A) (D : A) (x : ℝ) (hB : HasDerivAt B D x) (n : ℕ) :
    HasDerivAt (fun t => B t ^ n) (powerTangent (B x) D n) x := by
  induction n with
  | zero => simpa only [pow_zero, powerTangent] using hasDerivAt_const x (1 : A)
  | succ n ih => simpa only [pow_succ, powerTangent] using ih.mul hB

/-- Cyclicity collapses all terms in a power derivative under the trace.
An extra power on the right permits a direct induction. -/
/- Cyclic collapse: moving the final power to the front makes all traced product-rule terms equal. The extra right-hand power enables the induction. -/
theorem trace_powerTangent_mul_pow
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace) (a d : A) (n k : ℕ) :
    trace (powerTangent a d n * a ^ k) =
      (n : ℝ) * trace (a ^ (n + k - 1) * d) := by
  induction n generalizing k with
  | zero => simp [powerTangent]
  | succ n ih =>
      have hfirst : powerTangent a d n * a * a ^ k =
          powerTangent a d n * a ^ (k + 1) := by
        rw [mul_assoc, ← pow_succ']
      have hsecond : trace (a ^ n * d * a ^ k) = trace (a ^ (n + k) * d) := by
        rw [hcyclic (a ^ n * d) (a ^ k), ← mul_assoc, ← pow_add, Nat.add_comm k n]
      simp only [powerTangent, add_mul, map_add, hfirst, ih, hsecond]
      have hexp1 : n + (k + 1) - 1 = n + k := by omega
      have hexp2 : n + 1 + k - 1 = n + k := by omega
      rw [hexp1, hexp2, Nat.cast_add, Nat.cast_one]
      ring

/-- The familiar power derivative is valid under a cyclic trace even for a
noncommutative normed algebra. -/
theorem trace_power_hasDerivAt
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (B : ℝ → A) (D : A) (x : ℝ) (hB : HasDerivAt B D x) (n : ℕ) :
    HasDerivAt (fun t => trace (B t ^ n))
      ((n : ℝ) * trace (B x ^ (n - 1) * D)) x := by
  have htrace := trace_powerTangent_mul_pow trace hcyclic (B x) D n 0
  simp only [pow_zero, mul_one, Nat.add_zero] at htrace
  have hd := trace.hasFDerivAt.comp_hasDerivAt x (power_hasDerivAt B D x hB n)
  simpa only [Function.comp_def, htrace] using hd

/-- A single traced logarithmic series term has an elementary derivative. -/
/- Logarithmic-series term: division by n+1 cancels the number of equal cyclic summands. This is one scalar-term derivative, not yet the infinite sum. -/
theorem trace_logarithmic_term_hasDerivAt
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (B : ℝ → A) (D : A) (x : ℝ) (hB : HasDerivAt B D x) (n : ℕ) :
    HasDerivAt (fun t => trace (B t ^ (n + 1)) / (n + 1 : ℕ))
      (trace (B x ^ n * D)) x := by
  have hd := (trace_power_hasDerivAt trace hcyclic B D x hB (n + 1)).div_const
    (n + 1 : ℕ)
  simpa only [Nat.add_sub_cancel, mul_div_cancel_left₀ _
    (show ((n + 1 : ℕ) : ℝ) ≠ 0 from Nat.cast_ne_zero.mpr (Nat.succ_ne_zero n))] using hd

section Inverse

variable [CompleteSpace A]

/-- Inversion has its actual noncommutative derivative on any differentiable
curve through an invertible element. -/
/- Supporting inverse calculus: the derivative is -B^(-1)*D*B^(-1), with both inverse factors in their actual order. This is not a logarithm-integral proof. -/
theorem inverse_curve_hasDerivAt
    (B : ℝ → A) (D : A) (x : ℝ) (hB : HasDerivAt B D x)
    (hunit : IsUnit (B x)) :
    HasDerivAt (fun t => Ring.inverse (B t))
      (-(Ring.inverse (B x) * D * Ring.inverse (B x))) x := by
  have hi := hasFDerivAt_ringInverse (𝕜 := ℝ) hunit.unit
  rw [hunit.unit_spec] at hi
  have hd := hi.comp_hasDerivAt x hB
  simpa only [Function.comp_def, ContinuousLinearMap.neg_apply,
    ContinuousLinearMap.mulLeftRight_apply, ← Ring.inverse_of_isUnit hunit] using hd

end Inverse

section Series

variable [NormOneClass A]

/- Value majorant: boundedness of the functional and submultiplicativity give |trace(b^n)| <= norm(trace)*r^n. -/
private theorem trace_power_norm_le
    (trace : A →L[ℝ] ℝ) (b : A) (r : ℝ) (hb : ‖b‖ ≤ r) (n : ℕ) :
    ‖trace (b ^ n)‖ ≤ ‖trace‖ * r ^ n := by
  apply (trace.le_opNorm (b ^ n)).trans
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg trace)
  exact (norm_pow_le b n).trans (pow_le_pow_left₀ (norm_nonneg b) hb n)

/- Derivative majorant: |trace(b^n*d)| <= norm(trace)*r^n*M uniformly on the chosen neighborhood. This summable bound is essential. -/
private theorem trace_power_mul_norm_le
    (trace : A →L[ℝ] ℝ) (b d : A) (r M : ℝ)
    (hr : 0 ≤ r) (hb : ‖b‖ ≤ r) (hd : ‖d‖ ≤ M) (n : ℕ) :
    ‖trace (b ^ n * d)‖ ≤ ‖trace‖ * (r ^ n * M) := by
  apply (trace.le_opNorm (b ^ n * d)).trans
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg trace)
  apply (norm_mul_le (b ^ n) d).trans
  exact mul_le_mul ((norm_pow_le b n).trans (pow_le_pow_left₀ (norm_nonneg b) hb n))
    hd (norm_nonneg d) (pow_nonneg hr n)

/-- The convergent logarithmic series representing the trace of `log (1-b)`
near the identity. Its identification with the CFC logarithm is not yet used. -/
def tracialLogSeries (trace : A →L[ℝ] ℝ) (b : A) : ℝ :=
  -∑' n : ℕ, trace (b ^ (n + 1)) / (n + 1 : ℕ)

/- Convergence before differentiation: a geometric majorant bounds the actual scalar logarithmic terms; formal power-series notation alone does not supply convergence. -/
theorem tracial_log_terms_summable
    (trace : A →L[ℝ] ℝ) (b : A) (r : ℝ)
    (hr0 : 0 ≤ r) (hr1 : r < 1) (hb : ‖b‖ ≤ r) :
    Summable (fun n : ℕ => trace (b ^ (n + 1)) / (n + 1 : ℕ)) := by
  have hmajor : Summable (fun n : ℕ => ‖trace‖ * r ^ (n + 1)) := by
    simpa only [pow_succ'] using
      ((summable_geometric_of_lt_one hr0 hr1).mul_left r).mul_left ‖trace‖
  apply Summable.of_norm_bounded _ hmajor
  intro n
  have hn : ‖((n + 1 : ℕ) : ℝ)‖ = ((n + 1 : ℕ) : ℝ) :=
    Real.norm_of_nonneg (Nat.cast_nonneg _)
  rw [norm_div, hn]
  apply (div_le_self (norm_nonneg _) (show 1 ≤ ((n + 1 : ℕ) : ℝ) from by
    exact_mod_cast Nat.succ_le_succ (Nat.zero_le n))).trans
  exact trace_power_norm_le trace b r hb (n + 1)

variable [CompleteSpace A]

/-- Differentiating the actual infinite logarithmic series under a proved
uniform geometric majorant. The derivative sum is evaluated by the Banach
algebra geometric-series inverse identity. -/
/- Infinite differentiation: one open connected neighborhood, radius r<1, and derivative bound M feed the termwise-differentiation theorem. The norm-convergent geometric inverse evaluates the resulting derivative sum. -/
theorem tracialLogSeries_hasDerivAt
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (B D : ℝ → A) (s : Set ℝ) (hsopen : IsOpen s) (hsconnected : IsPreconnected s)
    (r M x : ℝ) (hr0 : 0 ≤ r) (hr1 : r < 1) (hx : x ∈ s)
    (hB : ∀ t ∈ s, HasDerivAt B (D t) t)
    (hbounded : ∀ t ∈ s, ‖B t‖ ≤ r) (hDbounded : ∀ t ∈ s, ‖D t‖ ≤ M) :
    HasDerivAt (fun t => tracialLogSeries trace (B t))
      (-trace (Ring.inverse (1 - B x) * D x)) x := by
  have hmajor : Summable (fun n : ℕ => ‖trace‖ * (r ^ n * M)) :=
    ((summable_geometric_of_lt_one hr0 hr1).mul_right M).mul_left ‖trace‖
  have hsum := tracial_log_terms_summable trace (B x) r hr0 hr1 (hbounded x hx)
  have hd := hasDerivAt_tsum_of_isPreconnected hmajor hsopen hsconnected
    (fun n t ht => trace_logarithmic_term_hasDerivAt trace hcyclic B (D t) t (hB t ht) n)
    (fun n t ht => trace_power_mul_norm_le trace (B t) (D t) r M hr0
      (hbounded t ht) (hDbounded t ht) n) hx hsum hx
  have hgeometric := trace.hasSum
    ((hasSum_geom_series_inverse (B x) ((hbounded x hx).trans_lt hr1)).mul_right (D x))
  have hresult := hd.neg
  rw [hgeometric.tsum_eq] at hresult
  exact hresult

end Series

/-- The two product-rule terms for a square agree after applying a cyclic
trace and cancel one copy of the inverse. -/
/- Last algebraic step: trace(C^(-2)*(D*C+C*D))=2*trace(C^(-1)*D). One term uses cyclicity and the other inverse cancellation, never commutation of C and D. -/
theorem trace_inverse_square_product_rule
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (C D : A) (hC : IsUnit C) :
    trace (Ring.inverse (C ^ 2) * (D * C + C * D)) =
      2 * trace (Ring.inverse C * D) := by
  have hleft : trace ((Ring.inverse C) ^ 2 * (D * C)) = trace (Ring.inverse C * D) := by
    calc
      trace ((Ring.inverse C) ^ 2 * (D * C)) =
          trace (((Ring.inverse C) ^ 2 * D) * C) := by rw [mul_assoc]
      _ = trace (C * ((Ring.inverse C) ^ 2 * D)) := hcyclic _ _
      _ = trace (((C * Ring.inverse C) * Ring.inverse C) * D) := by
        simp only [pow_two, mul_assoc]
      _ = trace (Ring.inverse C * D) := by
        rw [Ring.mul_inverse_cancel C hC, one_mul]
  have hright : (Ring.inverse C) ^ 2 * (C * D) = Ring.inverse C * D := by
    calc
      (Ring.inverse C) ^ 2 * (C * D) = Ring.inverse C * ((Ring.inverse C * C) * D) := by
        simp only [pow_two, mul_assoc]
      _ = Ring.inverse C * D := by rw [Ring.inverse_mul_cancel C hC, one_mul]
  rw [← Ring.inverse_pow, mul_add, map_add, hleft, hright]
  ring

section CFCIdentification

open scoped ContinuousFunctionalCalculus

variable [StarRing A] [CompleteSpace A] [NormOneClass A]
  [ContinuousFunctionalCalculus ℝ A IsSelfAdjoint]

/-- The local logarithmic series is exactly the trace of the CFC logarithm,
proved by uniform convergence on the spectrum and the continuous CFC map. -/
/- CFC identification of the rescaled logarithmic series: the scalar logarithmic series converges in continuous-function norm on the compact spectrum. The continuous CFC map and fixed trace transport this actual sum. -/
theorem tracialLogSeries_eq_cfc_log_one_sub
    (trace : A →L[ℝ] ℝ) (b : A) (hb : IsSelfAdjoint b) (hbnorm : ‖b‖ < 1) :
    tracialLogSeries trace b = trace (CFC.log (1 - b)) := by
  let idS : C(spectrum ℝ b, ℝ) := (ContinuousMap.id ℝ).restrict (spectrum ℝ b)
  let fn : ℕ → C(spectrum ℝ b, ℝ) := fun n =>
    (((n + 1 : ℕ) : ℝ)⁻¹) • idS ^ (n + 1)
  have hfapply (n : ℕ) (x : spectrum ℝ b) :
      fn n x = (x : ℝ) ^ (n + 1) / (n + 1 : ℕ) := by
    simp [fn, idS, div_eq_mul_inv, mul_comm]
  have hxnorm (x : spectrum ℝ b) : ‖(x : ℝ)‖ ≤ ‖b‖ :=
    spectrum.norm_le_norm_of_mem x.property
  have hxlt (x : spectrum ℝ b) : |(x : ℝ)| < 1 :=
    (hxnorm x).trans_lt hbnorm
  have hxpos (x : spectrum ℝ b) : 0 < 1 - (x : ℝ) :=
    sub_pos.mpr ((le_abs_self (x : ℝ)).trans_lt (hxlt x))
  have hcont : Continuous (fun x : spectrum ℝ b => Real.log (1 - (x : ℝ))) :=
    (continuous_const.sub continuous_subtype_val).log (fun x => (hxpos x).ne')
  let flog : C(spectrum ℝ b, ℝ) := ⟨fun x => -Real.log (1 - (x : ℝ)), hcont.neg⟩
  have hmajor : Summable (fun n : ℕ => ‖b‖ ^ (n + 1)) := by
    simpa only [pow_succ'] using
      (summable_geometric_of_lt_one (norm_nonneg b) hbnorm).mul_left ‖b‖
  have hsfn : Summable fn := by
    apply Summable.of_norm_bounded _ hmajor
    intro n
    apply (ContinuousMap.norm_le _ (pow_nonneg (norm_nonneg b) _)).mpr
    intro x
    rw [hfapply, norm_div, Real.norm_of_nonneg (Nat.cast_nonneg _)]
    apply (div_le_self (norm_nonneg _) (show 1 ≤ ((n + 1 : ℕ) : ℝ) from by
      exact_mod_cast Nat.succ_le_succ (Nat.zero_le n))).trans
    rw [norm_pow]
    exact pow_le_pow_left₀ (norm_nonneg _) (hxnorm x) (n + 1)
  have hsum : HasSum fn flog := by
    have heq : (∑' n, fn n) = flog := by
      apply ContinuousMap.ext
      intro x
      have hev := (ContinuousMap.evalCLM ℝ x).hasSum hsfn.hasSum
      change HasSum (fun n => fn n x) ((∑' n, fn n) x) at hev
      simp only [hfapply] at hev
      exact hev.unique (by simpa only [Nat.cast_add, Nat.cast_one] using
        Real.hasSum_pow_div_log_of_abs_lt_one (hxlt x))
    exact heq ▸ hsfn.hasSum
  have hid : cfcHom hb idS = b := cfcHom_id hb
  have hmap (n : ℕ) : cfcL hb (fn n) = (((n + 1 : ℕ) : ℝ)⁻¹) • b ^ (n + 1) := by
    change cfcHom hb ((((n + 1 : ℕ) : ℝ)⁻¹) • idS ^ (n + 1)) = _
    rw [map_smul, map_pow, hid]
  have hlogcont : ContinuousOn (fun x : ℝ => Real.log (1 - x)) (spectrum ℝ b) :=
    continuousOn_iff_continuous_restrict.mpr hcont
  have hlogimage : ContinuousOn Real.log ((fun x : ℝ => 1 - x) '' spectrum ℝ b) := by
    apply Real.continuousOn_log.mono
    rintro _ ⟨x, hx, rfl⟩
    exact (hxpos ⟨x, hx⟩).ne'
  have honesub : cfc (fun x : ℝ => 1 - x) b = 1 - b := by
    calc
      cfc (fun x : ℝ => 1 - x) b = cfc (fun _ : ℝ => 1) b - cfc (fun x : ℝ => x) b :=
        cfc_sub (fun _ : ℝ => 1) (fun x : ℝ => x) b continuousOn_const continuousOn_id
      _ = 1 - b := by rw [cfc_const_one ℝ b hb, cfc_id' ℝ b hb]
  have hflog : cfcL hb flog = -CFC.log (1 - b) := by
    calc
      cfcL hb flog = cfc (fun x : ℝ => -Real.log (1 - x)) b :=
        (cfc_eq_cfcL hb hlogcont.neg).symm
      _ = -cfc (fun x : ℝ => Real.log (1 - x)) b :=
        cfc_neg (fun x : ℝ => Real.log (1 - x)) b
      _ = -CFC.log (1 - b) := by
        congr 1
        change cfc (fun x : ℝ => Real.log (1 - x)) b = cfc Real.log (1 - b)
        calc
          cfc (fun x : ℝ => Real.log (1 - x)) b =
              cfc Real.log (cfc (fun x : ℝ => 1 - x) b) :=
            cfc_comp' Real.log (fun x : ℝ => 1 - x) b hlogimage
              (continuous_const.sub continuous_id).continuousOn hb
          _ = cfc Real.log (1 - b) := by rw [honesub]
  have htraced := trace.hasSum ((cfcL hb).hasSum hsum)
  have hterms : HasSum (fun n : ℕ => trace (b ^ (n + 1)) / (n + 1 : ℕ))
      (-trace (CFC.log (1 - b))) := by
    simpa only [hmap, map_smul, smul_eq_mul, hflog, map_neg,
      div_eq_mul_inv, mul_comm] using htraced
  change -(∑' n : ℕ, trace (b ^ (n + 1)) / (n + 1 : ℕ)) = _
  rw [hterms.tsum_eq, neg_neg]

/-- The derivative of the actual CFC logarithm near the identity. Both the
series identification and differentiation of the infinite series are proved. -/
/- Replace the differentiated series by the actual CFC logarithm using their proved local equality. The logarithm derivative is a conclusion. -/
theorem trace_cfc_log_one_sub_hasDerivAt
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (B D : ℝ → A) (s : Set ℝ) (hsopen : IsOpen s) (hsconnected : IsPreconnected s)
    (r M x : ℝ) (hr0 : 0 ≤ r) (hr1 : r < 1) (hx : x ∈ s)
    (hB : ∀ t ∈ s, HasDerivAt B (D t) t)
    (hself : ∀ t ∈ s, IsSelfAdjoint (B t))
    (hbounded : ∀ t ∈ s, ‖B t‖ ≤ r) (hDbounded : ∀ t ∈ s, ‖D t‖ ≤ M) :
    HasDerivAt (fun t => trace (CFC.log (1 - B t)))
      (-trace (Ring.inverse (1 - B x) * D x)) x := by
  apply (tracialLogSeries_hasDerivAt trace hcyclic B D s hsopen hsconnected
    r M x hr0 hr1 hx hB hbounded hDbounded).congr_of_eventuallyEq
  filter_upwards [hsopen.mem_nhds hx] with t ht
  exact (tracialLogSeries_eq_cfc_log_one_sub trace (B t) (hself t ht)
    ((hbounded t ht).trans_lt hr1)).symm

/-- Positive rescaling permits the tracial logarithm derivative at an
arbitrary positive invertible curve whose scaled defect is uniformly below
one. The hypotheses are norm/differentiability conditions, not a logarithm
derivative formula. -/
/- Fixed positive rescaling: differentiate 1-c*B, evaluate its geometric inverse, and subtract the constant trace(log(c)*1). Do not differentiate the fixed scale c. -/
theorem trace_cfc_log_hasDerivAt_of_scaled_defect
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (B D : ℝ → A) (s : Set ℝ) (hsopen : IsOpen s) (hsconnected : IsPreconnected s)
    (c r M x : ℝ) (hc : 0 < c) (hr0 : 0 ≤ r) (hr1 : r < 1) (hx : x ∈ s)
    (hB : ∀ t ∈ s, HasDerivAt B (D t) t)
    (hself : ∀ t ∈ s, IsSelfAdjoint (B t))
    (hpositive : ∀ t ∈ s, ∀ y ∈ spectrum ℝ (B t), 0 < y)
    (hbounded : ∀ t ∈ s, ‖1 - c • B t‖ ≤ r)
    (hDbounded : ∀ t ∈ s, ‖D t‖ ≤ M) :
    HasDerivAt (fun t => trace (CFC.log (B t)))
      (trace (Ring.inverse (B x) * D x)) x := by
  have hderiv : ∀ t ∈ s, HasDerivAt (fun u => 1 - c • B u) (-(c • D t)) t := by
    intro t ht
    simpa only [zero_sub] using (hasDerivAt_const t (1 : A)).sub ((hB t ht).const_smul c)
  have hdefself : ∀ t ∈ s, IsSelfAdjoint (1 - c • B t) := by
    intro t ht
    have hone : IsSelfAdjoint (1 : A) := IsSelfAdjoint.one A
    have hcB : IsSelfAdjoint (c • B t) := by
      simpa only [cfc_smul_id (R := ℝ) c (B t) (hself t ht)] using
        (cfc_predicate (fun y : ℝ => c • y) (B t))
    exact hone.sub hcB
  have hdefbound : ∀ t ∈ s, ‖-(c • D t)‖ ≤ c * M := by
    intro t ht
    rw [norm_neg, norm_smul, Real.norm_of_nonneg hc.le]
    exact mul_le_mul_of_nonneg_left (hDbounded t ht) hc.le
  have hd := trace_cfc_log_one_sub_hasDerivAt trace hcyclic
    (fun t => 1 - c • B t) (fun t => -(c • D t)) s hsopen hsconnected
    r (c * M) x hr0 hr1 hx hderiv hdefself hbounded hdefbound
  have hunit : IsUnit (B x) := spectrum.isUnit_of_zero_not_mem ℝ
    (fun hz => (hpositive x hx 0 hz).false)
  have hscaled : IsUnit (c • B x) := by
    simpa only [sub_sub_cancel] using
      isUnit_one_sub_of_norm_lt_one ((hbounded x hx).trans_lt hr1)
  have hinverse : Ring.inverse (c • B x) * (c • D x) = Ring.inverse (B x) * D x := by
    calc
      Ring.inverse (c • B x) * (c • D x) =
          Ring.inverse (c • B x) * (c • (B x * (Ring.inverse (B x) * D x))) := by
        rw [← mul_assoc (B x), Ring.mul_inverse_cancel (B x) hunit, one_mul]
      _ = Ring.inverse (c • B x) * ((c • B x) * (Ring.inverse (B x) * D x)) := by
        rw [smul_mul_assoc]
      _ = Ring.inverse (B x) * D x := by
        rw [← mul_assoc, Ring.inverse_mul_cancel _ hscaled, one_mul]
  have hdscaled : HasDerivAt (fun t => trace (CFC.log (c • B t)))
      (trace (Ring.inverse (B x) * D x)) x := by
    simpa only [sub_sub_cancel, mul_neg, map_neg, neg_neg, hinverse] using hd
  have hdsub := hdscaled.sub_const (trace (algebraMap ℝ A (Real.log c)))
  apply hdsub.congr_of_eventuallyEq
  filter_upwards [hsopen.mem_nhds hx] with t ht
  rw [CFC.log_smul (B t) (hpositive t ht) hc (hself t ht), map_add, add_sub_cancel_left]

/-- Specialization to the square of a self-adjoint curve. The noncommutative
product rule and cyclicity supply the factor two; no commutation of `C` with
its derivative is required. -/
/- Square specialization: the genuine product-rule derivative is D*C+C*D. The factor two emerges only after applying cyclicity under the trace. -/
theorem trace_cfc_log_sq_hasDerivAt_of_scaled_defect
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (C D : ℝ → A) (s : Set ℝ) (hsopen : IsOpen s) (hsconnected : IsPreconnected s)
    (c r M x : ℝ) (hc : 0 < c) (hr0 : 0 ≤ r) (hr1 : r < 1) (hx : x ∈ s)
    (hC : ∀ t ∈ s, HasDerivAt C (D t) t)
    (hself : ∀ t ∈ s, IsSelfAdjoint (C t))
    (hpositive : ∀ t ∈ s, ∀ y ∈ spectrum ℝ ((C t) ^ 2), 0 < y)
    (hbounded : ∀ t ∈ s, ‖1 - c • (C t) ^ 2‖ ≤ r)
    (hDbounded : ∀ t ∈ s, ‖D t * C t + C t * D t‖ ≤ M) :
    HasDerivAt (fun t => trace (CFC.log ((C t) ^ 2)))
      (2 * trace (Ring.inverse (C x) * D x)) x := by
  have hsqderiv : ∀ t ∈ s,
      HasDerivAt (fun u => (C u) ^ 2) (D t * C t + C t * D t) t := by
    intro t ht
    simpa only [pow_two] using (hC t ht).mul (hC t ht)
  have hunitSq : IsUnit ((C x) ^ 2) := spectrum.isUnit_of_zero_not_mem ℝ
    (fun hz => (hpositive x hx 0 hz).false)
  have hunit : IsUnit (C x) := (isUnit_pow_iff (by decide : (2 : ℕ) ≠ 0)).mp hunitSq
  have hd := trace_cfc_log_hasDerivAt_of_scaled_defect trace hcyclic
    (fun t => (C t) ^ 2) (fun t => D t * C t + C t * D t)
    s hsopen hsconnected c r M x hc hr0 hr1 hx hsqderiv
    (fun t ht => (hself t ht).pow 2) hpositive hbounded hDbounded
  rw [trace_inverse_square_product_rule trace hcyclic (C x) (D x) hunit] at hd
  exact hd

end CFCIdentification

section CStarApplication

variable {B : Type*} [CStarAlgebra B] [Nontrivial B]

/-- The full local tracial logarithm derivative for a self-adjoint `C¹` curve
through an invertible point. The scale, neighborhood, and uniform bounds are
constructed internally. No logarithm derivative or series identity is assumed. -/
/- Construct all local hypotheses: choose c at the basepoint, r=(defect_norm+1)/2, and a square-derivative bound M. Continuity and open invertibility give one connected ball with all bounds and positivity. -/
theorem trace_cfc_log_sq_hasDerivAt
    (trace : B →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (C D : ℝ → B) (x : ℝ)
    (hderiv : ∀ᶠ t in 𝓝 x, HasDerivAt C (D t) t)
    (hself : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (C t))
    (hD : ContinuousAt D x) (hunit : IsUnit (C x)) :
    HasDerivAt (fun t => trace (CFC.log ((C t) ^ 2)))
      (2 * trace (Ring.inverse (C x) * D x)) x := by
  have hCx : ContinuousAt C x := hderiv.self_of_nhds.continuousAt
  obtain ⟨c, hc, hscale⟩ := exists_positive_selfAdjoint_square_rescaling
    hself.self_of_nhds hunit
  have hscale' : ‖1 - c • (C x) ^ 2‖ < 1 := by simpa only [pow_two] using hscale
  let r : ℝ := (‖1 - c • (C x) ^ 2‖ + 1) / 2
  let M : ℝ := ‖D x * C x + C x * D x‖ + 1
  have hr0 : 0 ≤ r := by dsimp [r]; positivity
  have hr1 : r < 1 := by dsimp [r]; linarith
  have hdeflt : ‖1 - c • (C x) ^ 2‖ < r := by dsimp [r]; linarith
  have hDlt : ‖D x * C x + C x * D x‖ < M := by dsimp [M]; linarith
  have hcontdef : ContinuousAt (fun t => ‖1 - c • (C t) ^ 2‖) x :=
    (continuousAt_const.sub ((hCx.pow 2).const_smul c)).norm
  have hcontD : ContinuousAt (fun t => ‖D t * C t + C t * D t‖) x :=
    ((hD.mul hCx).add (hCx.mul hD)).norm
  have hnearUnit : ∀ᶠ t in 𝓝 x, IsUnit (C t) :=
    hCx.eventually (Units.isOpen.mem_nhds hunit)
  have hnearDef : ∀ᶠ t in 𝓝 x, ‖1 - c • (C t) ^ 2‖ < r :=
    hcontdef.eventually (gt_mem_nhds hdeflt)
  have hnearD : ∀ᶠ t in 𝓝 x, ‖D t * C t + C t * D t‖ < M :=
    hcontD.eventually (gt_mem_nhds hDlt)
  have hnear := hderiv.and (hself.and (hnearUnit.and (hnearDef.and hnearD)))
  obtain ⟨epsilon, hepsilon, hball⟩ := Metric.mem_nhds_iff.mp hnear
  apply trace_cfc_log_sq_hasDerivAt_of_scaled_defect trace hcyclic C D
    (Metric.ball x epsilon) Metric.isOpen_ball (convex_ball x epsilon).isPreconnected
    c r M x hc hr0 hr1 (Metric.mem_ball_self hepsilon)
    (fun t ht => (hball ht).1) (fun t ht => (hball ht).2.1) ?_
    (fun t ht => (hball ht).2.2.2.1.le) (fun t ht => (hball ht).2.2.2.2.le)
  intro t ht y hy
  exact selfAdjoint_square_spectrum_pos (hball ht).2.1 (hball ht).2.2.1
    (by simpa only [pow_two] using hy)

/-- The one-half normalization used for the logarithmic potential. -/
/- Final statement: divide the proved square-log derivative by two. This is the normalization of the physical logarithmic potential. -/
theorem half_trace_cfc_log_sq_hasDerivAt
    (trace : B →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (C D : ℝ → B) (x : ℝ)
    (hderiv : ∀ᶠ t in 𝓝 x, HasDerivAt C (D t) t)
    (hself : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (C t))
    (hD : ContinuousAt D x) (hunit : IsUnit (C x)) :
    HasDerivAt (fun t => trace (CFC.log ((C t) ^ 2)) / 2)
      (trace (Ring.inverse (C x) * D x)) x := by
  have hd := (trace_cfc_log_sq_hasDerivAt trace hcyclic C D x hderiv hself hD hunit).div_const 2
  simpa only [mul_div_cancel_left₀ _ (by norm_num : (2 : ℝ) ≠ 0)] using hd

end CStarApplication

end CriticalDTM

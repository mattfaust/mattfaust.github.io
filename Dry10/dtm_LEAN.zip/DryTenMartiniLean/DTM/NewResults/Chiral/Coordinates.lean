import DTM.NewResults.Chiral.Current
import Mathlib.Data.Real.Sign
import DTM.NewResults.Brown.ChiralGauge

/-!
# Exact angular weight under the chiral coordinate change

The change x=j+k, y=j-k turns vertical/horizontal cones into opposite/same-sign
quadrants. The cone weight Q is zero at the origin. Consequently the
correct full-space identity is I/2+Lz = Q+P0/2, not I/2+Lz=Q.
No claim about a Hilbert-space hopping-gauge equivalence is made in this file.
-/
noncomputable section
namespace CriticalDTM.Chiral
open scoped InnerProductSpace

/-- The paper's angular polarization in integer chiral coordinates. -/
def polarization (x y : ℤ) : ℝ := -Real.sign ((x : ℝ) * (y : ℝ)) / 2

/-- The coordinate product is exactly the difference of square radii. -/
theorem chiral_product (j k : ℤ) :
    (((j + k : ℤ) : ℝ) * ((j - k : ℤ) : ℝ)) = (j : ℝ)^2 - (k : ℝ)^2 := by
  push_cast
  ring

/-- Pointwise weight conversion, with the non-optional half-root correction. -/
theorem weight_coordinate_identity (j k : ℤ) :
    qWeight (j,k) + (if (j,k) = origin then (1 / 2 : ℝ) else 0) =
      1 / 2 + polarization (j+k) (j-k) := by
  by_cases hroot : (j,k) = origin
  · have hj : j = 0 := congrArg Prod.fst hroot
    have hk : k = 0 := congrArg Prod.snd hroot
    subst j; subst k
    simp [qWeight, vertical, boundary, origin, polarization]
  · rw [if_neg hroot, add_zero]
    rcases lt_trichotomy |j| |k| with hv |hb |hh
    · rw [qWeight_of_vertical (s := (j,k)) hv]
      have habs : |(j : ℝ)| < |(k : ℝ)| := by exact_mod_cast hv
      have hsq : (j : ℝ)^2 < (k : ℝ)^2 := by
        nlinarith [sq_abs (j : ℝ), sq_abs (k : ℝ), abs_nonneg (j : ℝ), abs_nonneg (k : ℝ)]
      rw [polarization, chiral_product, Real.sign_of_neg (sub_neg.mpr hsq)]
      norm_num
    · rw [qWeight_of_boundary ⟨hroot,hb⟩]
      have habs : |(j : ℝ)| = |(k : ℝ)| := by exact_mod_cast hb
      have hsq : (j : ℝ)^2 - (k : ℝ)^2 = 0 := by
        nlinarith [congrArg (fun r : ℝ => r^2) habs, sq_abs (j : ℝ), sq_abs (k : ℝ)]
      rw [polarization, chiral_product, hsq]
      simp
    · rw [qWeight_of_horizontal (s := (j,k)) hh]
      have habs : |(k : ℝ)| < |(j : ℝ)| := by exact_mod_cast hh
      have hsq : (k : ℝ)^2 < (j : ℝ)^2 := by
        nlinarith [sq_abs (j : ℝ), sq_abs (k : ℝ), abs_nonneg (j : ℝ), abs_nonneg (k : ℝ)]
      rw [polarization, chiral_product, Real.sign_of_pos (sub_pos.mpr hsq)]
      norm_num

/-- The actual square-space operator constructed in Current.lean has exactly
the paper's -sign(xy)/2 multiplier in chiral coordinates. -/
theorem angular_coordinate_action (u : LatticeHilbert) (j k : ℤ) :
    angular u (j,k) = (polarization (j+k) (j-k) : ℂ) * u (j,k) := by
  have hw := weight_coordinate_identity j k
  rw [angular_apply]
  simp only [lp.coeFn_add, lp.coeFn_sub, lp.coeFn_smul, Pi.add_apply, Pi.sub_apply,
    Pi.smul_apply, smul_eq_mul, coneWeightOperator_apply, inner_hilbertRoot]
  by_cases hroot : (j,k) = origin
  · have hj : j = 0 := congrArg Prod.fst hroot
    have hk : k = 0 := congrArg Prod.snd hroot
    subst j; subst k
    simp [origin, polarization, qWeight, vertical, boundary, latticeRoot]
  · simp only [if_neg hroot, add_zero] at hw
    have hweight : (qWeight (j,k) : ℂ) = 1 / 2 + (polarization (j+k) (j-k) : ℂ) := by
      rw [hw]
      push_cast
      norm_num
    have hr : hilbertRoot (j,k) = 0 := by
      simp [hilbertRoot_apply, latticeRoot, Pi.single_apply, hroot]
    rw [hr, hweight]
    ring

end CriticalDTM.Chiral

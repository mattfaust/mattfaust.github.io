import DTM.NewResults.Spin.MagneticData
import DTM.NewResults.Spin.Vacancy

/-!
# A sourced angular-current identity on the actual square model

The source-supported commutator follows from punctured-axis row cancellation,
skew-adjoint column cancellation, and restoration of the source contribution.
The physical theorem assumes irrational frequency and common-action vectors.
The operator is the pullback of the paper's angular multiplier. The root
correction accounts for the cone weight being zero at the root, whereas
I/2+Lz is one half there. The coordinate adapter transports the multiplier
through the chiral gauge.
-/

noncomputable section
namespace CriticalDTM.Chiral
open scoped InnerProductSpace

section Abstract
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

end Abstract

/-- The pullback of Lz to square coordinates, including the origin correction. -/
def angular : LatticeHilbert →L[ℂ] LatticeHilbert :=
  coneWeightOperator - (1 / 2 : ℂ) • 1 +
    (1 / 2 : ℂ) • Spin.rootProjection hilbertRoot

@[simp] theorem angular_apply (u : LatticeHilbert) :
    angular u = coneWeightOperator u - (1 / 2 : ℂ) • u +
      (1 / 2 : ℂ) • (⟪hilbertRoot, u⟫_ℂ • hilbertRoot) := rfl

theorem angular_root : angular hilbertRoot = 0 := by
  simp [angular_apply, coneWeightOperator_root_zero, inner_self_eq_norm_sq_to_K,
    Spin.magnetic_root_unit]

theorem angular_symmetric : SymmetricOperator angular := by
  intro v w
  simp only [angular_apply, inner_add_left, inner_sub_left, inner_smul_left,
    inner_add_right, inner_sub_right, inner_smul_right,
    map_div₀, map_one, map_ofNat, coneWeightOperator_isSelfAdjoint.isSymmetric.apply_clm,
    ← inner_conj_symm v hilbertRoot]
  ring

/-- Vectors on which the actual two square magnetic actions agree. -/
def commonSpace (α lam : ℝ) : Submodule ℂ LatticeHilbert :=
  LinearMap.ker ((hOperator α (lam : ℂ)).toLinearMap -
    (conjugateOperator α (lam : ℂ)).toLinearMap)

@[simp] theorem mem_commonSpace (α lam : ℝ) (u : LatticeHilbert) :
    u ∈ commonSpace α lam ↔ hOperator α (lam : ℂ) u =
      conjugateOperator α (lam : ℂ) u := by
  simp [commonSpace, LinearMap.mem_ker, sub_eq_zero]

/-- The physical source belongs to the common-action subspace. -/
theorem root_mem_commonSpace (α lam : ℝ) : hilbertRoot ∈ commonSpace α lam :=
  (mem_commonSpace α lam hilbertRoot).mpr (magnetic_operators_agree_on_root α _)

/-! ## Punctured-axis rows, then columns

The following block replaces the compression-based proof.  The diagonal
projection is used only to write a bounded row/column decomposition of a
commutator; no compressed Hamiltonian or cone invariance is invoked.
-/

/-- The two chiral coordinate axes, pulled back to |j|=|k|. -/
def axisWeight (s : Site) : ℝ := if |s.1| = |s.2| then 1 else 0

private theorem axisWeight_nonneg (s : Site) : 0 ≤ axisWeight s := by
  unfold axisWeight
  split_ifs <;> norm_num

private theorem axisWeight_le_one (s : Site) : axisWeight s ≤ 1 := by
  unfold axisWeight
  split_ifs <;> norm_num

/-- Includes the root; its punctured part is axisProjection-rootProjection. -/
def axisProjection : LatticeHilbert →L[ℂ] LatticeHilbert :=
  weightedOperator axisWeight axisWeight_nonneg axisWeight_le_one

@[simp] theorem axisProjection_apply (u : LatticeHilbert) (s : Site) :
    axisProjection u s = (axisWeight s : ℂ) * u s := rfl

theorem axisProjection_symmetric : SymmetricOperator axisProjection :=
  (weightedOperator_isSelfAdjoint axisWeight axisWeight_nonneg
    axisWeight_le_one).isSymmetric

/-- Scalar angular value, zero on both full axes (also at the source). -/
def angularValue (s : Site) : ℂ :=
  if |s.1| = |s.2| then 0 else if vertical s then 1 / 2 else -(1 / 2)

theorem angularValue_vertical {s : Site} (hs : vertical s) :
    angularValue s = 1 / 2 := by
  have hne : |s.1| ≠ |s.2| := ne_of_lt hs
  simp [angularValue, hne, hs]

theorem angularValue_horizontal {s : Site} (hs : horizontal s) :
    angularValue s = -(1 / 2) := by
  have hne : |s.1| ≠ |s.2| := (ne_of_lt hs).symm
  have hv : ¬ vertical s := not_lt_of_ge (le_of_lt hs)
  simp [angularValue, hne, hv]

theorem angularValue_axis {s : Site} (hs : |s.1| = |s.2|) :
    angularValue s = 0 := by simp [angularValue, hs]

/-- The actual bounded angular operator has this receiving-site multiplier. -/
theorem angular_apply_site (u : LatticeHilbert) (s : Site) :
    angular u s = angularValue s * u s := by
  rw [angular_apply]
  simp only [lp.coeFn_add, lp.coeFn_sub, lp.coeFn_smul, Pi.add_apply,
    Pi.sub_apply, Pi.smul_apply, smul_eq_mul, coneWeightOperator_apply,
    inner_hilbertRoot]
  by_cases hroot : s = origin
  · subst s
    simp [origin, angularValue, hilbertRoot_apply, latticeRoot, qWeight, vertical, boundary]
  · have hr : hilbertRoot s = 0 := by
      simp [hilbertRoot_apply, latticeRoot, Pi.single_apply, hroot]
    rw [hr]
    rcases lt_trichotomy |s.1| |s.2| with hv | ha | hh
    · rw [qWeight_of_vertical hv, angularValue_vertical hv]
      push_cast
      ring
    · rw [qWeight_of_boundary ⟨hroot, ha⟩, angularValue_axis ha]
      push_cast
      ring
    · rw [qWeight_of_horizontal hh, angularValue_horizontal hh]
      push_cast
      ring

/-- A nearest-neighbour angular jump has an axis endpoint.  Stated with the
exact two no-crossing implications so that the four lattice directions can
share the same scalar computation. -/
theorem angular_edge_axis_split (s t : Site)
    (hst : vertical s → ¬ horizontal t)
    (hts : vertical t → ¬ horizontal s) :
    angularValue s - angularValue t =
      (axisWeight s : ℂ) * (angularValue s - angularValue t) +
      (angularValue s - angularValue t) * (axisWeight t : ℂ) := by
  by_cases hs : |s.1| = |s.2|
  · by_cases ht : |t.1| = |t.2|
    · simp [angularValue, axisWeight, hs, ht]
    · simp [angularValue, axisWeight, hs, ht]
  · by_cases ht : |t.1| = |t.2|
    · simp [angularValue, axisWeight, hs, ht]
    · have heq : vertical s ↔ vertical t := by
        constructor
        · intro hv
          have hh := hst hv
          unfold vertical horizontal at *
          omega
        · intro hv
          have hh := hts hv
          unfold vertical horizontal at *
          omega
      simp [angularValue, axisWeight, hs, ht, heq]

/-- H_+ as an actual bounded operator, prior to any source pairing. -/
def averageOperator (α lam : ℝ) : LatticeHilbert →L[ℂ] LatticeHilbert :=
  (1 / 2 : ℂ) • (hOperator α (lam : ℂ) + conjugateOperator α (lam : ℂ))

theorem averageOperator_apply_site (α lam : ℝ) (u : LatticeHilbert) (s : Site) :
    averageOperator α lam u s = averageRow α (lam : ℂ) u s := by
  simp only [averageOperator, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.add_apply, lp.coeFn_smul, lp.coeFn_add, Pi.smul_apply,
    Pi.add_apply, smul_eq_mul, hOperator_apply, conjugateOperator_apply,
    averageRow_eq_half_sum]
  ring

theorem averageOperator_symmetric (α lam : ℝ) :
    SymmetricOperator (averageOperator α lam) := by
  intro v w
  simp only [averageOperator, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.add_apply, inner_smul_left, inner_smul_right,
    inner_add_left, inner_add_right, map_div₀, map_one, map_ofNat,
    (hOperator_isSelfAdjoint α lam).isSymmetric.apply_clm,
    (conjugateOperator_isSelfAdjoint α lam).isSymmetric.apply_clm]

theorem averageOperator_eq_on_common (α lam : ℝ) (u : LatticeHilbert)
    (hu : u ∈ commonSpace α lam) :
    averageOperator α lam u = hOperator α (lam : ℂ) u := by
  have h := (mem_commonSpace α lam u).mp hu
  simp only [averageOperator, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.add_apply, ← h]
  module

/-- The angular current of H_+. -/
def axisCurrent (α lam : ℝ) : LatticeHilbert →L[ℂ] LatticeHilbert :=
  angular * averageOperator α lam - averageOperator α lam * angular

/-- Finite receiving-row expression, with the four hopping coefficients kept. -/
theorem axisCurrent_apply_site (α lam : ℝ) (u : LatticeHilbert) (s : Site) :
    axisCurrent α lam u s =
      phaseAverage α s.2 * (angularValue s - angularValue (east s)) * u (east s) +
      phaseAverage α (-s.2) * (angularValue s - angularValue (west s)) * u (west s) +
      (lam : ℂ) * phaseAverage α s.1 *
        (angularValue s - angularValue (north s)) * u (north s) +
      (lam : ℂ) * phaseAverage α (-s.1) *
        (angularValue s - angularValue (south s)) * u (south s) := by
  simp only [axisCurrent, ContinuousLinearMap.sub_apply,
    ContinuousLinearMap.mul_apply, lp.coeFn_sub, Pi.sub_apply,
    angular_apply_site, averageOperator_apply_site, averageRow]
  ring

/-- Row/column support is a global bounded-operator identity.  It makes no
claim that either open cone is invariant under either Hamiltonian. -/
theorem axisCurrent_row_column (α lam : ℝ) (u : LatticeHilbert) :
    axisCurrent α lam u = axisProjection (axisCurrent α lam u) +
      axisCurrent α lam (axisProjection u) := by
  apply lp.ext
  funext s
  have he := angular_edge_axis_split s (east s) vertical_east_not_horizontal
    (fun ht => by simpa [west, east] using vertical_west_not_horizontal ht)
  have hw := angular_edge_axis_split s (west s) vertical_west_not_horizontal
    (fun ht => by simpa [east, west] using vertical_east_not_horizontal ht)
  have hn := angular_edge_axis_split s (north s) vertical_north_not_horizontal
    (fun ht => by simpa [south, north] using vertical_south_not_horizontal ht)
  have hs := angular_edge_axis_split s (south s) vertical_south_not_horizontal
    (fun ht => by simpa [north, south] using vertical_north_not_horizontal ht)
  simp only [lp.coeFn_add, Pi.add_apply, axisProjection_apply, axisCurrent_apply_site]
  linear_combination
    phaseAverage α s.2 * u (east s) * he +
    phaseAverage α (-s.2) * u (west s) * hw +
    (lam : ℂ) * phaseAverage α s.1 * u (north s) * hn +
    (lam : ℂ) * phaseAverage α (-s.1) * u (south s) * hs

end CriticalDTM.Chiral

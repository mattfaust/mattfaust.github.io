import DTM.NewResults.Continuation.MagneticBranch

/-!
# C1 regularity of the local Green-zero branch

This is a routine regularity refinement of the actual implicit branch in
MagneticBranch. The actual two Green partial derivatives are continuous by
the resolvent product formula; the energy partial is nonzero. Their quotient
is therefore a continuous slope. The final theorem gives a branch and a
continuous derivative throughout a neighborhood. The critical deduction
uses this local C1 conclusion in the local right-extension argument; no global branch is constructed.
-/

/-!
# Continuous slopes of actual magnetic Green-zero branches

The implicit derivative is a quotient of actual Green partial derivatives.
Their continuity follows from the actual resolvent, and its denominator is
strictly negative. Thus the branch supplied by the implicit-function theorem
has a derivative continuous at its initial point.
-/

noncomputable section

namespace CriticalDTM

open Filter
open scoped Topology

/- Explicit differential: evaluate -R (v_E I - v_lambda B) R
at the root and take its real part. Coordinates are (coupling, energy). -/
theorem realJointGreenDifferential_apply (α : ℝ) (p v : ℝ × ℝ) :
    realJointGreenDifferential α p v =
      (@inner ℂ LatticeHilbert _ hilbertRoot
        ((-(jointResolvent α (realPairToComplex p) *
          pencilLinear α (realPairToComplex v) *
          jointResolvent α (realPairToComplex p))) hilbertRoot)).re := by
  rfl

/- Routine continuity of each partial derivative. Use actual
joint resolvent continuity, multiplication of bounded operators, evaluation
at the root, the fixed inner product functional, and real part. -/
theorem realJointGreen_partial_continuousAt (α : ℝ) (p v : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    ContinuousAt (fun q => realJointGreenDifferential α q v) p := by
  have hr : ContinuousAt (fun q : ℝ × ℝ =>
      jointResolvent α (realPairToComplex q)) p :=
    (jointResolvent_hasStrictFDerivAt α (realPairToComplex p) hp).continuousAt.comp
      realPairToComplex.continuous.continuousAt
  have hm : ContinuousAt (fun q : ℝ × ℝ =>
      -(jointResolvent α (realPairToComplex q) *
        pencilLinear α (realPairToComplex v) *
        jointResolvent α (realPairToComplex q))) p :=
    ((hr.mul continuousAt_const).mul hr).neg
  have he := (ContinuousLinearMap.apply ℂ LatticeHilbert hilbertRoot).continuous.continuousAt.comp hm
  have hi := (innerSL ℂ hilbertRoot).continuous.continuousAt.comp he
  simpa only [realJointGreenDifferential_apply] using Complex.continuous_re.continuousAt.comp hi

/- The implicit slope -g_lambda/g_E. The denominator is the
negative squared norm of the actual resolvent column. -/
def magneticBranchSlope (α : ℝ) (p : ℝ × ℝ) : ℝ :=
  -realJointGreenDifferential α p (1, 0) / realJointGreenDifferential α p (0, 1)

/- Routine quotient continuity with the nonzero denominator
proved in RealJointGreen, rather than assumed branch regularity. -/
theorem magneticBranchSlope_continuousAt (α : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    ContinuousAt (magneticBranchSlope α) p :=
  (realJointGreen_partial_continuousAt α p (1, 0) hp).neg.div
    (realJointGreen_partial_continuousAt α p (0, 1) hp)
    (realJointGreen_energy_partial_ne_zero α p.1 p.2 hp)

/- Exact C1 output. Reuse the differentiable local zero branch
and compose the continuous implicit slope with its graph. The eventually
clause gives resolvent membership, stationarity, differentiability, and
continuity of the derivative at every point of a smaller neighborhood. -/
theorem magnetic_green_local_c1_zero_branch (α lam m : ℝ)
    (hm : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (m : ℂ) = 0) :
    ∃ e d : ℝ → ℝ,
      e lam = m ∧ ContinuousAt e lam ∧ ContinuousAt d lam ∧
      HasDerivAt e (d lam) lam ∧
      (∀ᶠ t : ℝ in 𝓝 lam,
        (e t : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) ∧
        projectedGreen (hOperator α (t : ℂ)) hilbertRoot (e t : ℂ) = 0 ∧
        HasDerivAt e (d t) t ∧ ContinuousAt d t) := by
  obtain ⟨e, he, hd, hc, ht, hnear, _⟩ := magnetic_green_local_zero_branch α lam m hm hzero
  refine ⟨e, fun t => magneticBranchSlope α (t, e t), he, hc, ?_, ?_, ?_⟩
  · change Tendsto _ _ (𝓝 (magneticBranchSlope α (lam, e lam)))
    rw [he]
    exact Filter.Tendsto.comp (magneticBranchSlope_continuousAt α (lam, m) hm) ht
  · simpa only [he] using hd
  · filter_upwards [hnear] with t h
    refine ⟨h.1, h.2.1, h.2.2, ?_⟩
    exact ContinuousAt.comp (f := fun s : ℝ => (s, e s))
      (magneticBranchSlope_continuousAt α (t, e t) h.1)
      (continuousAt_id.prodMk h.2.2.continuousAt)

end CriticalDTM

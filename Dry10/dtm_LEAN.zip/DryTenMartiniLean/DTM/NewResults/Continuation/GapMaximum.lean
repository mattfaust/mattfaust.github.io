import DTM.Problem.Definitions.GapComponents
import DTM.NewResults.Boundary.StationaryResolvent
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.LocalExtr.Basic

/-!
# Routine calculus and the actual gap maximum

The scalar strict-concavity and extreme-value arguments are routine helpers,
not separate critical deductions. The spectral specialization proves the
strict decrease of the actual root Green function from the negative square
norm derivative. Continuity, zero endpoint values, and the identity L' = g
remain explicit inputs here; the manuscript's selected-energy specialization
supplies them for the actual DOS potential. No real-gap equality
with the transfer Lyapunov exponent or analytic branch is claimed.
-/

/-!
# Positive interior maxima of spectral-gap height functions

We prove the existence and uniqueness part of the paper's gap-maximum lemma.
For the actual self-adjoint resolvent, the decreasing derivative is proved
from `g' = -||R root||^2`, not assumed. The identification `L' = g`, continuity
at the spectral endpoints, and zero endpoint values remain explicit inputs.
Coupling-branch regularity is supplied downstream by BranchRegularity as C1;
no analyticity of the branch is asserted or required.
-/

noncomputable section

namespace CriticalDTM

open Set
open scoped Topology

/-- A strictly decreasing derivative gives strict concavity up to the
endpoints when the function extends continuously there. -/
/- Routine real calculus. Apply Mathlib's strict-concavity
criterion on the closed interval; the derivative comparison is needed only
in its interior, while endpoint continuity is supplied separately. -/
theorem strictConcaveOn_of_decreasing_gap_derivative
    {L g : ℝ → ℝ} {a b : ℝ}
    (hcont : ContinuousOn L (Icc a b))
    (hderiv : ∀ x ∈ Ioo a b, HasDerivAt L (g x) x)
    (hanti : StrictAntiOn g (Ioo a b)) : StrictConcaveOn ℝ (Icc a b) L := by
  apply StrictAntiOn.strictConcaveOn_of_deriv (convex_Icc a b) hcont
  intro x hx y hy hxy
  have hx' : x ∈ Ioo a b := by simpa only [interior_Icc] using hx
  have hy' : y ∈ Ioo a b := by simpa only [interior_Icc] using hy
  rw [(hderiv x hx').deriv, (hderiv y hy').deriv]
  exact hanti hx' hy' hxy

/-- Zero endpoint values and strict concavity force positive interior values. -/
/- Routine strict-concavity consequence: every interior point
lies above the chord joining the two zero endpoints. -/
theorem strictConcave_zero_endpoints_positive
    {L : ℝ → ℝ} {a b x : ℝ} (hab : a < b)
    (hconcave : StrictConcaveOn ℝ (Icc a b) L)
    (ha : L a = 0) (hb : L b = 0) (hx : x ∈ Ioo a b) : 0 < L x := by
  have hsegment : x ∈ openSegment ℝ a b := by
    rw [openSegment_eq_Ioo hab]
    exact hx
  have h := hconcave.lt_on_openSegment
    (show a ∈ Icc a b from ⟨le_rfl, hab.le⟩)
    (show b ∈ Icc a b from ⟨hab.le, le_rfl⟩) (ne_of_lt hab) hsegment
  simpa only [ha, hb, min_self] using h

/-- The unique positive maximum is interior and stationary. Uniqueness of the
stationary energy is included separately from uniqueness of the maximizer. -/
/- Routine scalar assembly. The extreme-value theorem gives a
maximum; positivity at the midpoint excludes both zero endpoints; Fermat's
rule gives stationarity. Strict concavity gives a unique maximizer and
strict decrease of g gives a unique zero. -/
theorem exists_unique_positive_gap_maximum
    {L g : ℝ → ℝ} {a b : ℝ} (hab : a < b)
    (hcont : ContinuousOn L (Icc a b))
    (ha : L a = 0) (hb : L b = 0)
    (hderiv : ∀ x ∈ Ioo a b, HasDerivAt L (g x) x)
    (hanti : StrictAntiOn g (Ioo a b)) :
    ∃ m ∈ Ioo a b, 0 < L m ∧ g m = 0 ∧ IsMaxOn L (Icc a b) m ∧
      (∀ x ∈ Icc a b, IsMaxOn L (Icc a b) x → x = m) ∧
      (∀ x ∈ Ioo a b, g x = 0 → x = m) := by
  have hconcave := strictConcaveOn_of_decreasing_gap_derivative hcont hderiv hanti
  obtain ⟨m, hm, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hab.le) hcont
  have hmid : (a + b) / 2 ∈ Ioo a b := by constructor <;> linarith
  have hpositive : 0 < L m :=
    (strictConcave_zero_endpoints_positive hab hconcave ha hb hmid).trans_le
      (hmax ⟨hmid.1.le, hmid.2.le⟩)
  have hma : m ≠ a := by
    intro heq
    rw [heq, ha] at hpositive
    exact (lt_irrefl (0 : ℝ)) hpositive
  have hmb : m ≠ b := by
    intro heq
    rw [heq, hb] at hpositive
    exact (lt_irrefl (0 : ℝ)) hpositive
  have hmin : m ∈ Ioo a b :=
    ⟨lt_of_le_of_ne hm.1 hma.symm, lt_of_le_of_ne hm.2 hmb⟩
  have hlocal : IsLocalMax L m := hmax.isLocalMax (Icc_mem_nhds hmin.1 hmin.2)
  have hzero : g m = 0 := hlocal.hasDerivAt_eq_zero (hderiv m hmin)
  refine ⟨m, hmin, hpositive, hzero, hmax, ?_, ?_⟩
  · intro x hx hxmax
    exact hconcave.eq_of_isMaxOn hxmax hmax hx hm
  · intro x hx hxzero
    exact hanti.injOn hx hmin (hxzero.trans hzero.symm)

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]

/-- The real-valued root Green function on the real energy axis. -/
def realProjectedGreen (H : E →L[ℂ] E) (root : E) (x : ℝ) : ℝ :=
  (projectedGreen H root (x : ℂ)).re

/-- At a real energy, the projected Green function of a self-adjoint operator
is real. This identifies real stationarity with complex Green-function zero. -/
/- Gap maxima and local Green-zero branches, real/complex dictionary. Self-adjointness of
the real-energy resolvent makes the scalar root Green function real, so a
zero of its real part is a zero of the full complex value. -/
theorem projectedGreen_eq_realProjectedGreen
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E) (x : ℝ) :
    projectedGreen H root (x : ℂ) = (realProjectedGreen H root x : ℂ) := by
  have hR := (real_resolvent_isSelfAdjoint H hH x).isSymmetric
  have hconj : starRingEnd ℂ (projectedGreen H root (x : ℂ)) =
      projectedGreen H root (x : ℂ) := by
    unfold projectedGreen
    rw [inner_conj_symm]
    exact hR root root
  have him := congrArg Complex.im hconj
  simp only [Complex.conj_im] at him
  apply Complex.ext
  · rfl
  · simp only [Complex.ofReal_im]
    linarith

/-- The actual real Green derivative is the negative squared column norm. -/
/- The gap-maximum argument uses the actual resolvent derivative, not an assumed sign:
take the real part of the already proved derivative -||R root||^2. -/
theorem realProjectedGreen_hasDerivAt
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E)
    (x : ℝ) (hx : (x : ℂ) ∈ resolventSet ℂ H) :
    HasDerivAt (realProjectedGreen H root)
      (-(‖resolvent H (x : ℂ) root‖ ^ 2)) x := by
  have h := Complex.reCLM.hasFDerivAt.comp_hasDerivAt x
    (projected_green_hasRealDerivAt H hH root x hx)
  simpa only [Function.comp_def, Complex.reCLM_apply, Complex.ofReal_re,
    realProjectedGreen, projectedGreen] using h

/-- Nonzero root and resolvent membership make this derivative strictly
negative, rather than merely nonpositive. -/
/- Nondegeneracy. A nonzero root and invertibility imply
R root != 0, making the squared norm strictly positive. -/
theorem realProjectedGreen_deriv_neg
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E) (hroot : root ≠ 0)
    (x : ℝ) (hx : (x : ℂ) ∈ resolventSet ℂ H) :
    deriv (realProjectedGreen H root) x < 0 := by
  rw [(realProjectedGreen_hasDerivAt H hH root x hx).deriv]
  exact neg_neg_of_pos (sq_pos_of_pos
    (norm_pos_iff.mpr (actual_resolvent_column_ne_zero H root hroot (x : ℂ) hx)))

/-- The actual Green function is strictly decreasing on every real interval
in the resolvent set. -/
/- Routine mean-value consequence of the negative derivative
on every interval contained in the real resolvent set. -/
theorem realProjectedGreen_strictAntiOn
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E) (hroot : root ≠ 0)
    {a b : ℝ} (hresolvent : ∀ x ∈ Ioo a b, (x : ℂ) ∈ resolventSet ℂ H) :
    StrictAntiOn (realProjectedGreen H root) (Ioo a b) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioo a b)
  · intro x hx
    exact (realProjectedGreen_hasDerivAt H hH root x (hresolvent x hx)).continuousAt.continuousWithinAt
  · intro x hx
    have hx' : x ∈ Ioo a b := by simpa only [interior_Ioo] using hx
    exact realProjectedGreen_deriv_neg H hH root hroot x (hresolvent x hx')

/-- The full positive-maximizer conclusion on a genuine bounded spectral gap.
The decreasing Green derivative is proved internally. `L' = Re g` and the
continuous zero endpoint values are the remaining Lyapunov/Thouless inputs. -/
/- Exact spectral declaration. Combine the internally proved
Green strict decrease with the explicit continuous height, zero endpoint
values, and height derivative. The spectral endpoints and nonempty full
gap are assumptions, not inferred from a proposed label. -/
theorem spectral_gap_unique_positive_maximum
    (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (root : E) (hroot : root ≠ 0)
    {a b : ℝ} (hgap : IsSpectralGap {x : ℝ | (x : ℂ) ∈ spectrum ℂ H} a b)
    (L : ℝ → ℝ) (hcont : ContinuousOn L (Icc a b))
    (ha : L a = 0) (hb : L b = 0)
    (hderiv : ∀ x ∈ Ioo a b, HasDerivAt L (realProjectedGreen H root x) x) :
    ∃ m ∈ Ioo a b, 0 < L m ∧ projectedGreen H root (m : ℂ) = 0 ∧
      IsMaxOn L (Icc a b) m ∧
      (∀ x ∈ Icc a b, IsMaxOn L (Icc a b) x → x = m) ∧
      (∀ x ∈ Ioo a b, projectedGreen H root (x : ℂ) = 0 → x = m) := by
  have hresolvent : ∀ x ∈ Ioo a b, (x : ℂ) ∈ resolventSet ℂ H := by
    intro x hx
    exact spectrum.not_mem_iff.mp (hgap.interior_avoids hx)
  have hanti := realProjectedGreen_strictAntiOn H hH root hroot hresolvent
  obtain ⟨m, hm, hpositive, hzero, hmax, hunique, hzeroUnique⟩ :=
    exists_unique_positive_gap_maximum hgap.endpoints_ordered hcont ha hb hderiv hanti
  refine ⟨m, hm, hpositive, ?_, hmax, hunique, ?_⟩
  · rw [projectedGreen_eq_realProjectedGreen H hH root m, hzero, Complex.ofReal_zero]
  · intro x hx hxzero
    apply hzeroUnique x hx
    simp only [realProjectedGreen, hxzero, Complex.zero_re]

end CriticalDTM

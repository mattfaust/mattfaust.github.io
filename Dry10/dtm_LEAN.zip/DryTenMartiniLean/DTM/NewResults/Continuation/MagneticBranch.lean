import DTM.Background.Support.ImplicitBranch
import DTM.Background.Support.RealJointGreen
import DTM.NewResults.Continuation.GapMaximum

/-!
# The actual local Green-zero branch

This module specializes the routine real implicit-function machinery to
the actual magnetic root Green function. The joint domain is open, the
strict derivative is known, and the energy derivative is nonzero. The
output here is locally differentiable, with the explicit quotient slope;
BranchRegularity upgrades it to C1. None of these statements constructs a
global labelled branch or asserts an analytic maximizing branch. These
results supply the local right extension in the continuation proof.
-/

/-!
# Differentiable branches of actual magnetic Green-function zeros

Every real resolvent zero of the root Green function has a unique local
differentiable branch as the coupling varies. Joint regularity and the
nonzero energy derivative are proved for the actual operator, and staying
in the resolvent set is a consequence of its open joint domain.

The final theorem starts with an actual bounded spectral gap and obtains
the initial zero and positive maximum from explicit height-function inputs.
It does not identify an abstract height with the Lyapunov exponent or
continue a branch across an entire coupling interval.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

theorem realJointGreen_eq_realProjectedGreen (α lam x : ℝ) :
    realJointGreen α (lam, x) =
      realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot x := rfl

/-- A real zero of the real-part formulation is a zero of the full complex
Green function, since the real-energy resolvent is self-adjoint. -/
/- Routine real/complex zero equivalence, justified by
self-adjointness of the real-energy resolvent rather than an extra reality
assumption on an abstract scalar function. -/
theorem realJointGreen_zero_iff (α lam x : ℝ) :
    realJointGreen α (lam, x) = 0 ↔
      projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (x : ℂ) = 0 := by
  rw [projectedGreen_eq_realProjectedGreen (hOperator α (lam : ℂ))
    (hOperator_isSelfAdjoint α lam) hilbertRoot x]
  simp only [realJointGreen_eq_realProjectedGreen, Complex.ofReal_eq_zero]

/-- Exact local continuation of an actual Green zero. In addition to the
zero equation, the theorem gives its derivative throughout a neighborhood
and uniqueness among every sufficiently nearby real Green zero. -/
/- Actual specialization. Openness supplies a neighborhood
of true resolvent points. RealJointGreen supplies the strict derivative and
nonzero energy derivative; ImplicitBranch supplies the branch and nearby
zero uniqueness. Shrinking the graph neighborhood retains invertibility. -/
theorem magnetic_green_local_zero_branch
    (α lam m : ℝ)
    (hm : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (m : ℂ) = 0) :
    ∃ e : ℝ → ℝ,
      e lam = m ∧
      HasDerivAt e
        (-realJointGreenDifferential α (lam, m) (1, 0) /
          realJointGreenDifferential α (lam, m) (0, 1)) lam ∧
      ContinuousAt e lam ∧
      Tendsto (fun t => (t, e t)) (𝓝 lam) (𝓝 (lam, m)) ∧
      (∀ᶠ t : ℝ in 𝓝 lam,
        (e t : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) ∧
        projectedGreen (hOperator α (t : ℂ)) hilbertRoot (e t : ℂ) = 0 ∧
        HasDerivAt e
          (-realJointGreenDifferential α (t, e t) (1, 0) /
            realJointGreenDifferential α (t, e t) (0, 1)) t) ∧
      (∀ᶠ p in 𝓝 (lam, m),
        projectedGreen (hOperator α (p.1 : ℂ)) hilbertRoot (p.2 : ℂ) = 0 →
          p.2 = e p.1) := by
  have hdomain : ∀ᶠ p in 𝓝 (lam, m), p ∈ realJointResolventDomain α :=
    (realJointResolventDomain_isOpen α).mem_nhds hm
  have hnear : ∀ᶠ p in 𝓝 (lam, m),
      HasFDerivAt (realJointGreen α) (realJointGreenDifferential α p) p ∧
        realJointGreenDifferential α p (0, 1) ≠ 0 := by
    filter_upwards [hdomain] with p hp
    exact ⟨(realJointGreen_hasStrictFDerivAt α p hp).hasFDerivAt,
      realJointGreen_energy_partial_ne_zero α p.1 p.2 hp⟩
  obtain ⟨e, he, hederiv, hecont, hgraph, heprop, hunique⟩ :=
    exists_local_zero_branch_differentiable
      (realJointGreen_hasStrictFDerivAt α (lam, m) hm)
      ((realJointGreen_zero_iff α lam m).mpr hzero)
      (realJointGreen_energy_partial_ne_zero α lam m hm) hnear
  refine ⟨e, he, hederiv, hecont, hgraph, ?_, ?_⟩
  · filter_upwards [heprop, hgraph.eventually hdomain] with t ht hres
    exact ⟨hres, (realJointGreen_zero_iff α t (e t)).mp ht.1, ht.2⟩
  · filter_upwards [hunique] with p hp hz
    exact hp ((realJointGreen_zero_iff α p.1 p.2).mpr hz)

end CriticalDTM

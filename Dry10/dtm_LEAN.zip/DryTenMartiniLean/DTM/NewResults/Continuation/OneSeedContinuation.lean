import DTM.Background.Labels.MagneticLabelProperties
import DTM.Background.Potential.LogPotentialBoundary
import DTM.Background.SpectralVanishing.AMOSpectralLyapunov

/-!
# Compact one-seed continuation helpers

The manuscript continuation uses the compact stationary-superlevel and
maximal-coupling lemmas below. They supply the fixed energy window,
compactness, and terminal-coupling argument for the physical specialization.
-/

/-!
# Persistence from one labelled seed gap

A single actual labelled gap at positive coupling is enough to continue that
label to any larger coupling at most one. The proof maximizes coupling on a
compact set of labelled stationary points with a fixed positive lower height.
Upper semicontinuity and spectral vanishing keep limits in the resolvent;
the actual implicit branch and its checked height monotonicity rule out an
earlier maximal coupling. No global branch, uniqueness of the labelled gap,
or gap-opening premise at every intermediate coupling is used.

The helpers list their analytic inputs. The physical specialization in
ManuscriptContinuation supplies the actual logarithmic potential and spectral
vanishing. Existence of a single seed gap remains an explicit input there.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

/-- A compact family with a larger-coupling point to the right of every
nonterminal point contains a point at the terminal coupling. -/
/- Persistence from one seed, routine extreme-value helper, not a separate critical theorem.
Maximize the first coordinate on a nonempty compact set. A strictly larger
coordinate to the right of each nonterminal point forces the maximum to be
the target. No spectral or gap-opening fact occurs in this helper. -/
theorem compact_coupling_reaches_target
    {S : Set (ℝ × ℝ)} {target : ℝ}
    (hcompact : IsCompact S) (hne : S.Nonempty)
    (hbound : ∀ p ∈ S, p.1 ≤ target)
    (hright : ∀ p ∈ S, p.1 < target → ∃ q ∈ S, p.1 < q.1) :
    ∃ E : ℝ, (target, E) ∈ S := by
  obtain ⟨p, hp, hmax⟩ := hcompact.exists_isMaxOn hne continuous_fst.continuousOn
  have heq : p.1 = target := by
    apply le_antisymm (hbound p hp)
    by_contra h
    obtain ⟨q, hq, hpq⟩ := hright p hp (lt_of_not_ge h)
    exact (not_lt_of_ge (hmax hq)) hpq
  refine ⟨p.2, ?_⟩
  simpa only [← heq, Prod.mk.eta] using hp

/-- Interior labels force a real resolvent energy between actual spectral
points, so the elementary operator bound supplies a fixed energy window. -/
/- Stationary-superlevel compactness and right extension, routine energy-window check. Exterior labels 0 and 1,
resolvent membership, and an interior label give spectral points on both
sides. The actual operator norm bound for 0 <= t <= 1 puts the energy in
[-4,4]; no continuity of gap endpoints is required. -/
theorem magnetic_resolvent_energy_bound_of_interior_label
    (α : ℝ) (N : ℝ → ℝ) {t E label : ℝ}
    (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hexterior : HasExteriorLabels (magneticRealSpectrumSet α t) N)
    (hres : (E : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)))
    (hlabel : N E = label) (hinterior : label ∈ Ioo (0 : ℝ) 1) :
    E ∈ Icc (-4 : ℝ) 4 := by
  obtain ⟨⟨a, ha, haE⟩, ⟨b, hb, hEb⟩⟩ :=
    spectral_points_both_sides_of_label hexterior (spectrum.not_mem_iff.mpr hres)
      hlabel hinterior
  exact energy_between_spectral_edges_mem_Icc α ht0 ht1 ha hb haE.le hEb.le

/-- The compactness set used by the continuation proof. Membership contains
actual resolvent and Green-zero conditions, not an abstract gap proxy. -/
/- Definition used in stationary-superlevel compactness and right extension. Membership records
an actual resolvent point, an actual Green zero, the fixed label, and a
fixed height lower bound inside [s,target] x [-4,4]. It does not encode an
assumed globally selected branch or initially open intermediate gaps. -/
def magneticStationarySuperlevel
    (α : ℝ) (L N : ℝ × ℝ → ℝ) (label c s target : ℝ) : Set (ℝ × ℝ) :=
  {p | p.1 ∈ Icc s target ∧ p.2 ∈ Icc (-4 : ℝ) 4 ∧
    IsLabelledMagneticStationaryPoint α N label p.1 p.2 ∧ c ≤ L p}

/-- Positive height excludes spectral limits; only then are continuity of
the actual joint Green function and local label constancy invoked. -/
/- Stationary-superlevel compactness, critical compactness step. Positive c, upper semicontinuity,
spectral zero on the entire closed coupling interval, and joint local label
constancy are explicit. Sequence closedness in the fixed compact rectangle
is proved in the logically necessary order below. -/
theorem magneticStationarySuperlevel_isCompact
    (α : ℝ) (L N : ℝ × ℝ → ℝ) (label c s target : ℝ)
    (hc : 0 < c) (husc : UpperSemicontinuous L)
    (hzero : ∀ t ∈ Icc s target, ∀ E ∈ magneticRealSpectrumSet α t, L (t, E) = 0)
    (hlocal : JointResolventLabelLocallyConstant α N) :
    IsCompact (magneticStationarySuperlevel α L N label c s target) := by
  have hclosed : IsClosed (magneticStationarySuperlevel α L N label c s target) := by
    apply IsSeqClosed.isClosed
    intro u p hu hlim
    have hrect : p ∈ Icc s target ×ˢ Icc (-4 : ℝ) 4 :=
      (isClosed_Icc.prod isClosed_Icc).mem_of_tendsto hlim
        (Eventually.of_forall fun n => ⟨(hu n).1, (hu n).2.1⟩)
    /- Stationary-superlevel compactness, first step: upper semicontinuity preserves c <= L at the
    limit. This step does not yet give resolvent membership. -/
    have hheight : c ≤ L p := lower_bound_at_upperSemicontinuous_limit (husc p)
      hlim (Eventually.of_forall fun n => (hu n).2.2.2)
    /- Stationary-superlevel compactness, second step: if the limit were spectral, hzero would give
    L p = 0, contradicting 0 < c <= L p. This exclusion must precede use of
    the joint Green derivative or the locally constant resolvent label. -/
    have hres : (p.2 : ℂ) ∈ resolventSet ℂ (hOperator α (p.1 : ℂ)) := by
      apply spectrum.not_mem_iff.mp
      intro hp
      have hz := hzero p.1 hrect.1 p.2 hp
      have hbad : c ≤ 0 := by simpa only [Prod.mk.eta, hz] using hheight
      exact (not_le_of_gt hc) hbad
    have hzseq : ∀ n, realJointGreen α (u n) = 0 := fun n =>
      (realJointGreen_zero_iff α (u n).1 (u n).2).mpr (hu n).2.2.1.2.1
    /- Stationary-superlevel compactness, third step: hres is now proved, so actual joint Green
    continuity at p preserves stationarity. No continuity on the spectral
    boundary has been assumed. -/
    have hgreen : realJointGreen α p = 0 := by
      apply tendsto_nhds_unique
        ((realJointGreen_hasStrictFDerivAt α p hres).continuousAt.tendsto.comp hlim)
      simpa only [Function.comp_def, hzseq] using
        (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℝ)) atTop (𝓝 0))
    /- Stationary-superlevel compactness, fourth step: a sequence point eventually lies in the
    constant-label resolvent neighborhood of p. This gives the limiting label
    without an assumed global IDS continuity theorem. -/
    have hlabel : N p = label := by
      obtain ⟨n, hn⟩ := (hlim.eventually (hlocal p hres)).exists
      exact hn.symm.trans (hu n).2.2.1.2.2
    exact ⟨hrect.1, hrect.2,
      ⟨hres, (realJointGreen_zero_iff α p.1 p.2).mp hgreen, hlabel⟩, hheight⟩
  exact (isCompact_Icc.prod isCompact_Icc).of_isClosed_subset hclosed
    (fun _ hp => ⟨hp.1, hp.2.1⟩)

end CriticalDTM

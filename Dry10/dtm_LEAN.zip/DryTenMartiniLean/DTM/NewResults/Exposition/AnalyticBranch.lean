import DTM.NewResults.Continuation.BranchRegularity
import Mathlib.Analysis.Calculus.FDeriv.Analytic

/-!
# Analytic regularity of the selected gap-energy branch

The graph-coordinate inverse is analytic. Applied to the Green-function
zero, this proves the analytic regularity of the selected gap energy and
identifies it with the local branch used in continuation.
-/
noncomputable section
namespace CriticalDTM
open Filter Set
open scoped Topology

theorem realJointGreen_analyticAt (α : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    AnalyticAt ℝ (realJointGreen α) p := by
  have h := (jointGreen_analyticAt α (realPairToComplex p) hp).restrictScalars (𝕜 := ℝ)
  exact (Complex.reCLM.analyticAt _).comp (h.comp (realPairToComplex.analyticAt p))

/-- Analytic form of the actual graph-coordinate implicit construction. -/
theorem exists_local_analytic_zero_branch
    {F : ℝ × ℝ → ℝ} {D : (ℝ × ℝ) →L[ℝ] ℝ} {lam m : ℝ}
    (hF : HasStrictFDerivAt F D (lam,m)) (hFa : AnalyticAt ℝ F (lam,m))
    (hzero : F (lam,m)=0) (hD : D (0,1)≠0) :
    ∃ e : ℝ → ℝ, e lam=m ∧ AnalyticAt ℝ e lam ∧
      Tendsto (fun t => (t,e t)) (𝓝 lam) (𝓝 (lam,m)) ∧
      (∀ᶠ t : ℝ in 𝓝 lam, F (t,e t)=0) ∧
      (∀ᶠ p : ℝ × ℝ in 𝓝 (lam,m), F p=0 → p.2=e p.1) := by
  let T : ℝ × ℝ → ℝ × ℝ := fun p => (p.1,F p)
  let J := graphDerivativeEquiv D hD
  have hT : HasStrictFDerivAt T (J : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) (lam,m) := by
    simpa only [J, graphDerivativeEquiv_coe, graphDerivative] using
      (ContinuousLinearMap.fst ℝ ℝ ℝ).hasStrictFDerivAt.prodMk hF
  have hTa : AnalyticAt ℝ T (lam,m) :=
    (ContinuousLinearMap.fst ℝ ℝ ℝ).analyticAt (lam,m) |>.prod hFa
  have hbase : T (lam,m)=(lam,0) := by simp [T,hzero]
  let G := hT.localInverse T J (lam,m)
  let e : ℝ → ℝ := fun t => (G (t,0)).2
  have hGbase : G (lam,0)=(lam,m) := by
    simpa only [G,hbase] using hT.localInverse_apply_image
  have he : e lam=m := congrArg Prod.snd hGbase
  have hGa : AnalyticAt ℝ G (lam,0) := by
    have hh := (hT.toPartialHomeomorph T).analyticAt_symm'
      hT.mem_toPartialHomeomorph_source hTa hT.hasFDerivAt.fderiv
    simpa only [HasStrictFDerivAt.toPartialHomeomorph_coe, hbase] using hh
  have hea : AnalyticAt ℝ e lam := by
    have hin : AnalyticAt ℝ (fun t : ℝ => (t,(0:ℝ))) lam :=
      analyticAt_id.prod analyticAt_const
    have hg : AnalyticAt ℝ (fun t : ℝ => G (t,0)) lam := hGa.comp_of_eq hin rfl
    exact ((ContinuousLinearMap.snd ℝ ℝ ℝ).analyticAt (G (lam,0))).comp_of_eq hg rfl
  have hgraph : Tendsto (fun t => (t,e t)) (𝓝 lam) (𝓝 (lam,m)) := by
    simpa only [he] using tendsto_id.prodMk_nhds hea.continuousAt
  have hin : ContinuousAt (fun t : ℝ => (t,(0:ℝ))) lam := by fun_prop
  have hright : ∀ᶠ t : ℝ in 𝓝 lam, T (G (t,0))=(t,0) := by
    have hh : ∀ᶠ y in 𝓝 (lam,0), T (G y)=y := by
      simpa only [G,hbase] using hT.eventually_right_inverse
    exact hin.eventually hh
  have hezero : ∀ᶠ t : ℝ in 𝓝 lam, F (t,e t)=0 := by
    filter_upwards [hright] with t ht
    have hfst := congrArg Prod.fst ht
    have hsnd := congrArg Prod.snd ht
    change F (t,(G (t,0)).2)=0
    have heq : (t,(G (t,0)).2)=G (t,0) := Prod.ext hfst.symm rfl
    rw [heq]
    exact hsnd
  have hunique : ∀ᶠ p : ℝ × ℝ in 𝓝 (lam,m), F p=0 → p.2=e p.1 := by
    filter_upwards [hT.eventually_left_inverse] with p hp hz
    have hh : G (p.1,0)=p := by simpa only [G,T,hz] using hp
    exact (congrArg Prod.snd hh).symm
  exact ⟨e,he,hea,hgraph,hezero,hunique⟩

/-- Every actual real magnetic Green zero has a locally real-analytic branch,
with actual resolvent membership and local uniqueness. -/
theorem magnetic_green_local_analytic_zero_branch (α lam m : ℝ)
    (hm : (m:ℂ) ∈ resolventSet ℂ (hOperator α (lam:ℂ)))
    (hzero : projectedGreen (hOperator α (lam:ℂ)) hilbertRoot (m:ℂ)=0) :
    ∃ e : ℝ → ℝ, e lam=m ∧ AnalyticAt ℝ e lam ∧
      (∀ᶠ t : ℝ in 𝓝 lam, (e t:ℂ) ∈ resolventSet ℂ (hOperator α (t:ℂ)) ∧
        projectedGreen (hOperator α (t:ℂ)) hilbertRoot (e t:ℂ)=0) ∧
      (∀ᶠ p : ℝ × ℝ in 𝓝 (lam,m),
        projectedGreen (hOperator α (p.1:ℂ)) hilbertRoot (p.2:ℂ)=0 → p.2=e p.1) := by
  obtain ⟨e,he,hea,hgraph,hezero,hunique⟩ := exists_local_analytic_zero_branch
    (realJointGreen_hasStrictFDerivAt α (lam,m) hm)
    (realJointGreen_analyticAt α (lam,m) hm)
    ((realJointGreen_zero_iff α lam m).mpr hzero)
    (realJointGreen_energy_partial_ne_zero α lam m hm)
  have hdomain : ∀ᶠ p : ℝ × ℝ in 𝓝 (lam,m), p ∈ realJointResolventDomain α :=
    (realJointResolventDomain_isOpen α).mem_nhds hm
  refine ⟨e,he,hea,?_,?_⟩
  · filter_upwards [hezero,hgraph.eventually hdomain] with t ht hres
    exact ⟨hres,(realJointGreen_zero_iff α t (e t)).mp ht⟩
  · filter_upwards [hunique] with p hp hz
    exact hp ((realJointGreen_zero_iff α p.1 p.2).mpr hz)

end CriticalDTM

import DTM.NewResults.Chiral.Current
import Mathlib.Analysis.InnerProductSpace.Projection

/-!
# The closed cyclic source space

This module constructs the closure of the complex polynomial source span,
and proves its inclusion in the larger common-action space used by the native
current theorem. Thus passing from the manuscript's cyclic space to that
native theorem does not assume invariance of an angular sector.
-/

noncomputable section
namespace CriticalDTM.Chiral
open scoped InnerProductSpace

/-- The actual closed polynomial source span, with no common-action equation
inserted into its definition. -/
def cyclicSpace (α lam : ℝ) : Submodule ℂ LatticeHilbert :=
  (Submodule.span ℂ (Set.range fun n : ℕ =>
    ((hOperator α (lam : ℂ)) ^ n) hilbertRoot)).topologicalClosure

instance cyclicSpace_completeSpace (α lam : ℝ) : CompleteSpace (cyclicSpace α lam) := by
  unfold cyclicSpace
  infer_instance

theorem source_power_mem_cyclicSpace (α lam : ℝ) (n : ℕ) :
    ((hOperator α (lam : ℂ)) ^ n) hilbertRoot ∈ cyclicSpace α lam :=
  Submodule.le_topologicalClosure _ (Submodule.subset_span ⟨n, rfl⟩)

theorem root_mem_cyclicSpace (α lam : ℝ) :
    hilbertRoot ∈ cyclicSpace α lam := by
  simpa using source_power_mem_cyclicSpace α lam 0

theorem cyclicSpace_isClosed (α lam : ℝ) :
    IsClosed (cyclicSpace α lam : Set LatticeHilbert) :=
  Submodule.isClosed_topologicalClosure _

theorem hOperator_mem_cyclicSpace (α lam : ℝ) (u : LatticeHilbert)
    (hu : u ∈ cyclicSpace α lam) :
    hOperator α (lam : ℂ) u ∈ cyclicSpace α lam := by
  let S := Submodule.span ℂ (Set.range fun n : ℕ =>
    ((hOperator α (lam : ℂ)) ^ n) hilbertRoot)
  have hspan : Set.MapsTo (hOperator α (lam : ℂ)) (S : Set LatticeHilbert) S := by
    intro v hv
    induction hv using Submodule.span_induction with
    | mem v hv =>
        obtain ⟨n, rfl⟩ := hv
        exact Submodule.subset_span ⟨n + 1, by simp [pow_succ']⟩
    | zero => simp
    | add v w _ _ hv hw => simpa using S.add_mem hv hw
    | smul c v _ hv => simpa using S.smul_mem c hv
  exact hspan.closure (hOperator α (lam : ℂ)).continuous hu

/-- Self-adjointness makes the orthogonal complement invariant as well. -/
theorem hOperator_mem_cyclicSpace_orthogonal (α lam : ℝ) (u : LatticeHilbert)
    (hu : u ∈ (cyclicSpace α lam)ᗮ) :
    hOperator α (lam : ℂ) u ∈ (cyclicSpace α lam)ᗮ := by
  intro v hv
  rw [← (hOperator_isSelfAdjoint α lam).isSymmetric.apply_clm]
  exact hu _ (hOperator_mem_cyclicSpace α lam v hv)

/-- The cyclic orthogonal projection commutes with the physical Hamiltonian.
This is the actual reducing-space statement, obtained from the two invariant
orthogonal summands. -/
theorem cyclicSpace_projection_hOperator (α lam : ℝ) (u : LatticeHilbert) :
    ((cyclicSpace α lam).orthogonalProjection (hOperator α (lam : ℂ) u) :
        LatticeHilbert) =
      hOperator α (lam : ℂ) ((cyclicSpace α lam).orthogonalProjection u) := by
  apply Submodule.eq_orthogonalProjection_of_mem_orthogonal
  · exact hOperator_mem_cyclicSpace α lam _
      ((cyclicSpace α lam).orthogonalProjection u).property
  · rw [← map_sub]
    exact hOperator_mem_cyclicSpace_orthogonal α lam _
      ((cyclicSpace α lam).sub_orthogonalProjection_mem_orthogonal u)

/-- Every genuine complex resolvent preserves the original cyclic space.
The proof uses its commuting orthogonal projection and both actual inverse
identities, and is therefore valid inside spectral gaps as well as outside
the operator norm disk. -/
theorem resolvent_mem_cyclicSpace (α lam : ℝ) (z : ℂ)
    (hz : z ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (u : LatticeHilbert) (hu : u ∈ cyclicSpace α lam) :
    resolvent (hOperator α (lam : ℂ)) z u ∈ cyclicSpace α lam := by
  let H := hOperator α (lam : ℂ)
  let R := resolvent H z
  let S := cyclicSpace α lam
  let P : LatticeHilbert →L[ℂ] LatticeHilbert :=
    S.subtypeL.comp S.orthogonalProjection
  have hcomm (v : LatticeHilbert) : P (H v) = H (P v) :=
    cyclicSpace_projection_hOperator α lam v
  have hPu : P u = u := Submodule.orthogonalProjection_eq_self_iff.mpr hu
  have heq : z • P (R u) - H (P (R u)) = u := by
    calc
      _ = P (z • R u - H (R u)) := by rw [map_sub, map_smul, hcomm]
      _ = P u := congrArg P (actual_resolvent_left_identity H z hz u)
      _ = u := hPu
  have hback := congrArg R heq
  rw [actual_resolvent_right_identity H z hz] at hback
  exact hback ▸ (S.orthogonalProjection (R u)).property

end CriticalDTM.Chiral

import Mathlib.Analysis.InnerProductSpace.Positive

/-!
# Orthogonal compression on the compatible, root-free Hilbert space

The common orbital space used here is the closed equalizer `ker (H - Hpartner)`.
It contains the source-generated orbital space, but avoids a polynomial-density
argument. Commutation makes this equalizer invariant, and self-adjointness makes
it reducing. Removing the common root gives the actual vacancy space.

The magnetic input is the bounded identity `Q (H u) = K u` on compatible,
root-free vectors. If `Q` kills the root, the product of its compression and the
vacancy Hamiltonian is the compression of `K`. Symmetry of this product proves
conservation. No stationary norm identity or differentiation enters this proof.
-/

noncomputable section

namespace CriticalDTM.Spin

open scoped InnerProductSpace

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

/-- Orthogonal compression, with codomain the subspace rather than the ambient space. -/
def compression (D : Submodule ℂ E) [CompleteSpace D] (A : E →L[ℂ] E) : D →L[ℂ] D :=
  D.orthogonalProjection ∘L A ∘L D.subtypeL

@[simp] theorem compression_apply (D : Submodule ℂ E) [CompleteSpace D]
    (A : E →L[ℂ] E) (u : D) :
    compression D A u = D.orthogonalProjection (A u) := rfl

/-- Compression preserves all matrix elements between vectors of the subspace. -/
@[simp] theorem inner_compression (D : Submodule ℂ E) [CompleteSpace D]
    (A : E →L[ℂ] E) (u v : D) :
    ⟪u, compression D A v⟫_ℂ = ⟪(u : E), A v⟫_ℂ := by
  simp only [compression_apply, Submodule.inner_orthogonalProjection_eq_of_mem_left]

@[simp] theorem compression_inner (D : Submodule ℂ E) [CompleteSpace D]
    (A : E →L[ℂ] E) (u v : D) :
    ⟪compression D A u, v⟫_ℂ = ⟪A u, (v : E)⟫_ℂ := by
  simp only [compression_apply, Submodule.inner_orthogonalProjection_eq_of_mem_right]

end CriticalDTM.Spin

import DTM.NewResults.Boundary.MagneticResolvent
import DTM.NewResults.Boundary.MagneticSource
import DTM.NewResults.Boundary.MagneticSymmetry

/-!
# The magnetic data needed by the vacancy-source proof

The model-dependent input remains the existing four-ray boundary calculation.
All operators below are the genuine bounded lattice operators.  In particular,
`magnetic_rootfree_compression` holds for every root-free vector on which the
left and right magnetic actions agree; it is not limited to resolvent columns.
No stationary-height estimate or derivative is used in this module.
-/

noncomputable section

namespace CriticalDTM.Spin

open scoped InnerProductSpace

/-- The physical root has the standard unit normalization. -/
theorem magnetic_root_unit : ‖hilbertRoot‖ = 1 := by
  simp [hilbertRoot, lp.norm_single]

end CriticalDTM.Spin

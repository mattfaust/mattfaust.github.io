import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Algebra.Algebra.Spectrum.Basic
import Mathlib.Tactic.Module

/-!
# The full rank-one vacancy eigenline and its original source

At a genuine resolvent energy, every solution of `H w = z • w + c • root`
is `(-c) • R root`. At a zero of the root Green function this identifies the
**entire** scalar vacancy eigenspace, not only a source-generated subspace,
with the span of the full resolvent column.

The vacancy is the two-sided rank-one compression, restricted by an explicit
root-orthogonality condition. This condition is retained even at energy zero;
the deleted root is not counted as a vacancy eigenvector. Symmetry and a unit
root then give the source normalization `⟪H root, R root⟫ = -1`.

The core results take direct inverse identities. The final results instantiate
Mathlib's actual resolvent with explicit resolvent-set membership. Only basic
algebraic spectrum theory is imported; the argument does not use stationary
positivity, resolvent differentiation, or a tensor-product/doublet claim.
-/

open scoped InnerProductSpace ComplexInnerProductSpace

namespace CriticalDTM.Spin

section SourceAlgebra
variable {E : Type*} [AddCommGroup E] [Module ℂ E]

/-- The full inverse fixes the source coefficient, including its minus sign.
No orthogonality, symmetry, or boundedness hypothesis is needed here. -/
theorem source_eq_neg_smul_resolventColumn
    (H R : E →ₗ[ℂ] E) (z : ℂ) (root w : E) (c : ℂ)
    (hright : ∀ x, R (z • x - H x) = x)
    (hsource : H w = z • w + c • root) :
    w = (-c) • R root := by
  calc
    w = R (z • w - H w) := (hright w).symm
    _ = R ((-c) • root) := by rw [hsource]; congr 1; module
    _ = (-c) • R root := R.map_smul _ _

end SourceAlgebra

section Vacancy
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

/-- The rank-one map `x ↦ ⟪root,x⟫ root`. It is the orthogonal projection
onto the root line when `‖root‖ = 1`. -/
noncomputable def rootProjection (root : E) : E →L[ℂ] E :=
  (innerSL ℂ root).smulRight root

@[simp] theorem rootProjection_apply (root x : E) :
    rootProjection root x = ⟪root, x⟫ • root := rfl

/-- The quadratic-form ratio of a nonzero eigenvector is the real part
of its eigenvalue. No positivity or symmetry is assumed. -/
theorem eigenpair_inner_re_div_norm_sq
    (T : E →L[ℂ] E) (r : E) (hr : r ≠ 0) (c : ℂ)
    (heigen : T r = c • r) :
    (⟪r, T r⟫).re / ‖r‖ ^ 2 = c.re := by
  have hn : ‖r‖ ^ 2 ≠ 0 := pow_ne_zero 2 (norm_ne_zero_iff.mpr hr)
  rw [heigen, inner_smul_right, inner_self_eq_norm_sq_to_K]
  change (c * ((‖r‖ : ℂ) ^ 2)).re / ‖r‖ ^ 2 = c.re
  rw [← Complex.ofReal_pow, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    mul_zero, sub_zero, mul_div_assoc, div_self hn, mul_one]

/-- A nonzero invariant line for a symmetric operator has a real eigenvalue. -/
theorem real_eigenpair_of_mem_span
    (T : E →L[ℂ] E) (hT : T.toLinearMap.IsSymmetric)
    (r : E) (hr : r ≠ 0) (hline : T r ∈ Submodule.span ℂ {r}) :
    ∃ s : ℝ, T r = (s : ℂ) • r := by
  obtain ⟨c, hc⟩ := Submodule.mem_span_singleton.mp hline
  have hsym : (starRingEnd ℂ) c * ⟪r, r⟫ = c * ⟪r, r⟫ := by
    calc
      (starRingEnd ℂ) c * ⟪r, r⟫ = ⟪T r, r⟫ := by rw [← hc, inner_smul_left]
      _ = ⟪r, T r⟫ := hT r r
      _ = c * ⟪r, r⟫ := by rw [← hc, inner_smul_right]
  have hreal : (starRingEnd ℂ) c = c :=
    mul_right_cancel₀ (inner_self_ne_zero.mpr hr) hsym
  obtain ⟨s, hs⟩ := Complex.conj_eq_iff_real.mp hreal
  exact ⟨s, by rw [← hs]; exact hc.symm⟩

end Vacancy

section ActualResolvent
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

/-- The actual resolvent has the right inverse identity under
resolvent-set membership. -/
theorem resolvent_right_identity
    (H : E →L[ℂ] E) (z : ℂ) (hz : z ∈ resolventSet ℂ H) (u : E) :
    resolvent H z (z • u - H u) = u := by
  have h := congrArg (fun A : E →L[ℂ] E => A u)
    (Ring.inverse_mul_cancel (algebraMap ℂ (E →L[ℂ] E) z - H) hz)
  change resolvent H z ((algebraMap ℂ (E →L[ℂ] E) z - H) u) = u
  simpa only [resolvent, ContinuousLinearMap.mul_apply,
    ContinuousLinearMap.one_apply] using h

/-- Source uniqueness specialized to the actual bounded-operator resolvent. -/
theorem source_eq_neg_smul_actual_resolvent
    (H : E →L[ℂ] E) (z : ℂ) (hz : z ∈ resolventSet ℂ H)
    (root w : E) (c : ℂ) (hsource : H w = z • w + c • root) :
    w = (-c) • resolvent H z root :=
  source_eq_neg_smul_resolventColumn H.toLinearMap (resolvent H z).toLinearMap
    z root w c (resolvent_right_identity H z hz) hsource

end ActualResolvent
end CriticalDTM.Spin

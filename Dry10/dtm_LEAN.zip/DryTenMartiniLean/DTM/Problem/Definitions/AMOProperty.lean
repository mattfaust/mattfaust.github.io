import DTM.Background.Realization.AMOSpectralMeasure
import DTM.Problem.Definitions.GapComponents

/-!
# Explicit Dry Ten Martini statements for the actual one-dimensional AMO

The spectrum is that of `almostMathieuOperator` on `ℓ²(ℤ, ℂ)`, and the label
function is its phase-averaged root spectral mass. A gap has spectral endpoints,
positive length, and no spectrum in its entire interior. Thus the assertions
below concern full bounded gaps, not small nonspectral subintervals.

These are definitions of mathematical propositions. In particular, the final
one-input implication is a target, not a theorem. No identification with the
magnetic spectrum or magnetic lower mass is assumed by this module.
-/

noncomputable section

namespace CriticalDTM

open Set

/-- Every nonzero integer label occurs in a full bounded spectral gap for every
radian phase of the actual AMO. Irrationality is supplied explicitly in the
global statements, rather than making this predicate vacuous at other inputs. -/
def AMODryTenMartini (α lam : ℝ) : Prop :=
  ∀ θ : ℝ, ∀ n : ℤ, n ≠ 0 → ∃ a b : ℝ,
    IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam θ)
      (almostMathieuIDS α lam) (arithmeticGapLabel α n) a b

end CriticalDTM

import Mathlib.Topology.Order.Monotone
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.LocallyConstant.Basic
import Mathlib.Data.Real.Irrational
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Tactic.Linarith

/-!
# Actual bounded gaps of a closed real spectral set

The set `S` is explicit. A gap here has real spectral endpoints and an open
interior avoiding `S`; hence it is a full bounded gap, rather than an arbitrary
small nonspectral interval. Its maximality is proved below.
Local constancy of the label function and its exterior values remain explicit
application hypotheses. No identification of an IDS or AMO spectrum is assumed
by naming these abstract objects.
-/

noncomputable section

namespace CriticalDTM

open Set Filter
open scoped Topology

/-- A bounded spectral gap has ordered spectral endpoints and empty spectral
interior. The endpoint conditions force maximality among open nonspectral
intervals containing one of its points. -/
structure IsSpectralGap (S : Set ℝ) (a b : ℝ) : Prop where
  endpoints_ordered : a < b
  left_mem : a ∈ S
  right_mem : b ∈ S
  interior_avoids : Ioo a b ⊆ Sᶜ

/-- A closed real spectral set has a bounded gap around every nonspectral
point with at least one spectral point on each side. -/
theorem exists_spectral_gap_of_two_sided
    {S : Set ℝ} (hclosed : IsClosed S) {E : ℝ} (hE : E ∉ S)
    (hleft : ∃ s ∈ S, s < E) (hright : ∃ s ∈ S, E < s) :
    ∃ a b : ℝ, IsSpectralGap S a b ∧ E ∈ Ioo a b := by
  let A := S ∩ Iic E
  let B := S ∩ Ici E
  have hAclosed : IsClosed A := hclosed.inter isClosed_Iic
  have hBclosed : IsClosed B := hclosed.inter isClosed_Ici
  have hAne : A.Nonempty := by
    obtain ⟨s, hs, hsE⟩ := hleft
    exact ⟨s, hs, hsE.le⟩
  have hBne : B.Nonempty := by
    obtain ⟨s, hs, hEs⟩ := hright
    exact ⟨s, hs, hEs.le⟩
  have hAbdd : BddAbove A := ⟨E, fun _ hs => hs.2⟩
  have hBbdd : BddBelow B := ⟨E, fun _ hs => hs.2⟩
  have ha : sSup A ∈ A := hAclosed.csSup_mem hAne hAbdd
  have hb : sInf B ∈ B := hBclosed.csInf_mem hBne hBbdd
  have haE : sSup A < E := lt_of_le_of_ne ha.2 (by
    intro heq
    exact hE (heq ▸ ha.1))
  have hEb : E < sInf B := lt_of_le_of_ne hb.2 (by
    intro heq
    exact hE (heq.symm ▸ hb.1))
  refine ⟨sSup A, sInf B, ⟨haE.trans hEb, ha.1, hb.1, ?_⟩, haE, hEb⟩
  intro x hx hxS
  rcases le_total x E with hxE | hEx
  · have hxa : x ≤ sSup A := le_csSup hAbdd ⟨hxS, hxE⟩
    exact (not_lt_of_ge hxa) hx.1
  · have hbx : sInf B ≤ x := csInf_le hBbdd ⟨hxS, hEx⟩
    exact (not_lt_of_ge hbx) hx.2

/-- Local constancy at every nonspectral point. -/
def LocallyConstantOff (S : Set ℝ) (N : ℝ → ℝ) : Prop :=
  ∀ E ∉ S, ∀ᶠ x in 𝓝 E, N x = N E

/-- A full bounded spectral gap on which the specified label function has
the specified constant value. -/
def IsLabelledSpectralGap (S : Set ℝ) (N : ℝ → ℝ) (label a b : ℝ) : Prop :=
  IsSpectralGap S a b ∧ ∀ x ∈ Ioo a b, N x = label

/-- A locally constant label is constant on the entire bounded gap. -/
theorem IsSpectralGap.label_constant
    {S : Set ℝ} {N : ℝ → ℝ} {a b : ℝ} (hgap : IsSpectralGap S a b)
    (hlocal : LocallyConstantOff S N) {x y : ℝ}
    (hx : x ∈ Ioo a b) (hy : y ∈ Ioo a b) : N x = N y := by
  letI : PreconnectedSpace (Ioo a b) :=
    isPreconnected_iff_preconnectedSpace.mp isPreconnected_Ioo
  have hf : IsLocallyConstant (fun t : Ioo a b => N t.1) := by
    apply (IsLocallyConstant.iff_eventually_eq _).mpr
    intro t
    exact continuous_subtype_val.continuousAt.eventually
      (hlocal t.1 (hgap.interior_avoids t.2))
  exact hf.apply_eq_of_preconnectedSpace ⟨x, hx⟩ ⟨y, hy⟩

/-- The standard values on the two exterior spectral regions. -/
def HasExteriorLabels (S : Set ℝ) (N : ℝ → ℝ) : Prop :=
  (∀ E, (∀ s ∈ S, E < s) → N E = 0) ∧
  (∀ E, (∀ s ∈ S, s < E) → N E = 1)

/-- An interior label at a nonspectral point forces spectral points on both
sides, so the containing gap is bounded. -/
theorem spectral_points_both_sides_of_label
    {S : Set ℝ} {N : ℝ → ℝ} (hexterior : HasExteriorLabels S N)
    {E label : ℝ} (hE : E ∉ S) (hlabel : N E = label)
    (hinterior : label ∈ Ioo (0 : ℝ) 1) :
    (∃ s ∈ S, s < E) ∧ (∃ s ∈ S, E < s) := by
  constructor
  · by_contra hleft
    have hall : ∀ s ∈ S, E < s := by
      intro s hs
      have hle : E ≤ s := le_of_not_gt (fun hlt => hleft ⟨s, hs, hlt⟩)
      exact lt_of_le_of_ne hle (by intro heq; exact hE (heq.symm ▸ hs))
    have hzero := hexterior.1 E hall
    rw [hlabel] at hzero
    exact (ne_of_gt hinterior.1) hzero
  · by_contra hright
    have hall : ∀ s ∈ S, s < E := by
      intro s hs
      have hle : s ≤ E := le_of_not_gt (fun hlt => hright ⟨s, hs, hlt⟩)
      exact lt_of_le_of_ne hle (by intro heq; exact hE (heq ▸ hs))
    have hone := hexterior.2 E hall
    rw [hlabel] at hone
    exact (ne_of_lt hinterior.2) hone

/-- A nonspectral point with an interior label lies in a uniquely determined
bounded maximal gap, and the label is constant throughout that gap. -/
theorem exists_labelled_spectral_gap
    {S : Set ℝ} (hclosed : IsClosed S) {N : ℝ → ℝ}
    (hlocal : LocallyConstantOff S N) (hexterior : HasExteriorLabels S N)
    {E label : ℝ} (hE : E ∉ S) (hlabel : N E = label)
    (hinterior : label ∈ Ioo (0 : ℝ) 1) :
    ∃ a b : ℝ, IsSpectralGap S a b ∧ E ∈ Ioo a b ∧
      ∀ x ∈ Ioo a b, N x = label := by
  obtain ⟨hleft, hright⟩ := spectral_points_both_sides_of_label hexterior hE hlabel hinterior
  obtain ⟨a, b, hgap, hEin⟩ := exists_spectral_gap_of_two_sided hclosed hE hleft hright
  refine ⟨a, b, hgap, hEin, ?_⟩
  intro x hx
  exact (hgap.label_constant hlocal hx hEin).trans hlabel

/-- The arithmetic allowed label attached to an integer. -/
def arithmeticGapLabel (α : ℝ) (n : ℤ) : ℝ := Int.fract ((n : ℝ) * α)

theorem arithmeticGapLabel_mem_Ioo {α : ℝ} (hα : Irrational α)
    {n : ℤ} (hn : n ≠ 0) : arithmeticGapLabel α n ∈ Ioo (0 : ℝ) 1 := by
  refine ⟨Int.fract_pos.mpr ?_, Int.fract_lt_one _⟩
  exact (hα.intCast_mul hn).ne_int _

end CriticalDTM

import DTM.NewResults.Chiral.Coordinates
import DTM.NewResults.Calculus.MagneticPotential

/-!
# Sector-parity normalization

The supporting angular operator is normalized as -Lz/2. This file proves the
conversion pointwise, including the origin, and transports the actual
magnetic-current proof to the sector-parity normalization.
No current identity, positivity assertion, or gap-opening axiom is added.

The underlying lattice operators in this file are in Landau
gauge. The multiplier is unchanged by the diagonal symmetric gauge.
-/

noncomputable section
namespace DTMAudit
open CriticalDTM CriticalDTM.Chiral
open scoped InnerProductSpace Topology

/-- Sector parity in the unitarily equivalent Landau lattice gauge. -/
def Lz : LatticeHilbert →L[ℂ] LatticeHilbert := (-2 : ℂ) • angular

/-- Literal sign of the difference of squared coordinates, with zero on
both diagonals, including the origin. -/
theorem Lz_apply (u : LatticeHilbert) (n m : ℤ) :
    Lz u (n,m) = (Real.sign ((n : ℝ)^2 - (m : ℝ)^2) : ℂ) * u (n,m) := by
  simp only [Lz, ContinuousLinearMap.smul_apply, lp.coeFn_smul,
    Pi.smul_apply, smul_eq_mul, angular_coordinate_action,
    polarization, chiral_product]
  push_cast
  ring

theorem Lz_root : Lz hilbertRoot = 0 := by
  simp only [Lz, ContinuousLinearMap.smul_apply, angular_root, smul_zero]

theorem Lz_symmetric : SymmetricOperator Lz := by
  intro u v
  simp only [Lz, ContinuousLinearMap.smul_apply, inner_smul_left,
    inner_smul_right, map_neg, map_ofNat]
  rw [angular_symmetric u v]

/-- Source removal in the paper subtracts one scalar mean. -/
def centered (u : LatticeHilbert) : LatticeHilbert :=
  u - ⟪hilbertRoot, u⟫_ℂ • hilbertRoot

theorem centered_root_pairing (u : LatticeHilbert) :
    ⟪hilbertRoot, centered u⟫_ℂ = 0 := by
  simp [centered, inner_sub_right, inner_smul_right,
    inner_self_eq_norm_sq_to_K, Spin.magnetic_root_unit]

end DTMAudit

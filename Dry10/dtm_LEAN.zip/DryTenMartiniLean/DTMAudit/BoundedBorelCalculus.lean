import DTMAudit.BoundedSourceLimits
import DTMAudit.BoundedSpectralApproximation
import Mathlib.MeasureTheory.Function.Holder

/-! Actual full-space real bounded Borel calculus, from spectral L2 approximation.
Root identity, norm bound, self-adjointness, AE independence, and algebra laws
are proved for the constructed operators. -/

set_option autoImplicit false
set_option maxHeartbeats 1200000
noncomputable section
namespace DTMAudit.BoundedBorelCalculus
open CriticalDTM DTMAudit.SpectralSources DTMAudit.BoundedSpectralApproximation
open DTMAudit.BoundedSourceLimits MeasureTheory Filter
open scoped Topology ContinuousFunctionalCalculus

local instance spectralCompactSpace (α lam : ℝ) : CompactSpace (MagneticRealSpectrum α lam) :=
  isCompact_iff_compactSpace.mp (spectrum.isCompact (magneticAlgebraHamiltonian α lam))

/-- Continuous approximants are constructed from the actual bounded measurable function. -/
def boundedApproximant (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    ℕ → C(MagneticRealSpectrum α lam, ℝ) :=
  Classical.choose (exists_bounded_continuous_source_approx α lam f hf C hC hb)

theorem boundedApproximant_spec (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    (∀ n x, ‖boundedApproximant α lam f hf C hC hb n x‖ ≤ C) ∧
      (∀ n, ‖FullFermiProjection.spectralOperator α lam (boundedApproximant α lam f hf C hC hb n)‖ ≤ C) ∧
      Tendsto (fun n => ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ
        (boundedApproximant α lam f hf C hC hb n)) atTop
        (𝓝 (boundedSpectralL2 α lam f hf C hb)) ∧
      Tendsto (fun n => continuousSource α lam (boundedApproximant α lam f hf C hC hb n)) atTop
        (𝓝 (spectralSource α lam (boundedSpectralL2 α lam f hf C hb))) :=
  Classical.choose_spec (exists_bounded_continuous_source_approx α lam f hf C hC hb)

def boundedAlgebra (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) (n : ℕ) : magneticAlgebra α :=
  cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) (boundedApproximant α lam f hf C hC hb n)

theorem boundedAlgebra_bound (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    ∀ n, ‖(boundedAlgebra α lam f hf C hC hb n).val‖ ≤ C :=
  (boundedApproximant_spec α lam f hf C hC hb).2.1

theorem boundedAlgebra_source_tendsto (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    Tendsto (fun n => (boundedAlgebra α lam f hf C hC hb n).val hilbertRoot) atTop
      (𝓝 (spectralSource α lam (boundedSpectralL2 α lam f hf C hb))) :=
  (boundedApproximant_spec α lam f hf C hC hb).2.2.2

/-- The full-lattice functional calculus of an essentially bounded real spectral function. -/
def boundedOperator (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) : MagneticBoundedOperator :=
  sourceLimitOperator α (boundedAlgebra α lam f hf C hC hb)
    (spectralSource α lam (boundedSpectralL2 α lam f hf C hb))
    (boundedAlgebra_source_tendsto α lam f hf C hC hb) C (boundedAlgebra_bound α lam f hf C hC hb)

theorem boundedOperator_root (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    boundedOperator α lam f hf C hC hb hilbertRoot =
      spectralSource α lam (boundedSpectralL2 α lam f hf C hb) := sourceLimitOperator_root ..

theorem boundedOperator_right_commute (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) (A : magneticAlgebra α) :
    Commute (boundedOperator α lam f hf C hC hb) (rightAlgebraAction α A) :=
  sourceLimitOperator_right_commute ..

/-- The Borel operator depends only on the actual spectral AE class, not its bound. -/
theorem boundedOperator_congr (α lam : ℝ) (f g : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam))
    (hg : AEStronglyMeasurable g (magneticSpectralMeasure α lam)) (C D : ℝ) (hC : 0 ≤ C) (hD : 0 ≤ D)
    (hb : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C)
    (hc : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖g x‖ ≤ D)
    (hfg : f =ᵐ[magneticSpectralMeasure α lam] g) :
    boundedOperator α lam f hf C hC hb = boundedOperator α lam g hg D hD hc := by
  apply operator_eq_of_root α _ _ (boundedOperator_right_commute α lam f hf C hC hb)
    (boundedOperator_right_commute α lam g hg D hD hc)
  rw [boundedOperator_root, boundedOperator_root]
  apply congrArg (spectralSource α lam)
  apply Lp.ext
  exact (boundedSpectralL2_coeFn α lam f hf C hb).trans
    (hfg.trans (boundedSpectralL2_coeFn α lam g hg D hc).symm)

end DTMAudit.BoundedBorelCalculus

import DTMAudit.FullFermiProjection

/-! Actual strong limits from uniformly bounded trace-source columns; full-space bounds, self-adjointness, commutation, and uniqueness. -/

set_option autoImplicit false
noncomputable section
namespace DTMAudit.BoundedSourceLimits
open CriticalDTM DTMAudit.TraceVectorization

/-- Traciality makes taking the adjoint isometric for the actual root norm. -/
theorem star_root_norm (α : ℝ) (A : magneticAlgebra α) :
    ‖(star A : magneticAlgebra α).val hilbertRoot‖ = ‖A.val hilbertRoot‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [← magneticTraceReal_star_mul_self, ← magneticTraceReal_star_mul_self,
    star_star, magneticTraceReal_cyclic]

/-- Right multiplication is bounded for the actual trace norm. -/
theorem right_root_norm_le (α : ℝ) (A B : magneticAlgebra α) :
    ‖(A * B : magneticAlgebra α).val hilbertRoot‖ ≤ ‖B.val‖ * ‖A.val hilbertRoot‖ := by
  rw [← star_root_norm α (A * B), star_mul]
  calc
    _ ≤ ‖(star B : magneticAlgebra α).val‖ * ‖(star A : magneticAlgebra α).val hilbertRoot‖ :=
      (star B : magneticAlgebra α).val.le_opNorm _
    _ = _ := by
      rw [star_root_norm]
      change ‖star B.val‖ * _ = _
      exact congrArg (fun r : ℝ => r * ‖A.val hilbertRoot‖) (norm_star B.val)

/-- Right multiplication by any actual algebra element, bounded in trace norm. -/
def rightAlgebraLinear (α : ℝ) (B : magneticAlgebra α) :
    TraceAlgebra α →ₗ[ℂ] MagneticHilbert where
  toFun A := ((show magneticAlgebra α from A) * B).val hilbertRoot
  map_add' A C := by simp [add_mul]
  map_smul' c A := by simp

def rightAlgebraBounded (α : ℝ) (B : magneticAlgebra α) :
    TraceAlgebra α →L[ℂ] MagneticHilbert :=
  (rightAlgebraLinear α B).mkContinuous ‖B.val‖ (fun A => right_root_norm_le α A B)

/-- A genuine full-lattice right action of every magnetic-algebra element. -/
def rightAlgebraAction (α : ℝ) (B : magneticAlgebra α) : MagneticBoundedOperator :=
  (rightAlgebraBounded α B).extend (traceVectorize α).toContinuousLinearMap
    (traceVectorize_dense α) (traceVectorize α).isometry.isUniformInducing

theorem rightAlgebraAction_vectorize (α : ℝ) (B : magneticAlgebra α) (A : TraceAlgebra α) :
    rightAlgebraAction α B (traceVectorize α A) =
      ((show magneticAlgebra α from A) * B).val hilbertRoot :=
  ContinuousLinearMap.extend_eq _ _ _ _ A

theorem rightAlgebraAction_root (α : ℝ) (B : magneticAlgebra α) :
    rightAlgebraAction α B hilbertRoot = B.val hilbertRoot := by
  have h := rightAlgebraAction_vectorize α B (1 : magneticAlgebra α)
  change rightAlgebraAction α B ((1 : MagneticBoundedOperator) hilbertRoot) =
    (1 * B : magneticAlgebra α).val hilbertRoot at h
  simpa only [ContinuousLinearMap.one_apply, one_mul] using h

theorem rightAlgebraAction_commute (α : ℝ) (A B : magneticAlgebra α) :
    Commute A.val (rightAlgebraAction α B) := by
  change A.val * rightAlgebraAction α B = rightAlgebraAction α B * A.val
  apply ContinuousLinearMap.ext
  intro u
  change A.val (rightAlgebraAction α B u) = rightAlgebraAction α B (A.val u)
  refine (traceVectorize_dense α).induction_on u ?_ ?_
  · exact isClosed_eq (A.val.continuous.comp (rightAlgebraAction α B).continuous)
      ((rightAlgebraAction α B).continuous.comp A.val.continuous)
  · intro C
    change A.val (rightAlgebraAction α B (traceVectorize α C)) =
      rightAlgebraAction α B (traceVectorize α (A * (show magneticAlgebra α from C)))
    rw [rightAlgebraAction_vectorize, rightAlgebraAction_vectorize]
    rfl

open Filter
open scoped Topology

/-- Convergence on the trace root propagates to every algebra vector. -/
theorem root_tendsto_on_algebraVector (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (h : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (B : magneticAlgebra α) :
    Tendsto (fun n => (F n).val (B.val hilbertRoot)) atTop (𝓝 (rightAlgebraAction α B v)) := by
  have hv := ((rightAlgebraAction α B).continuous.tendsto v).comp h
  have heq (n : ℕ) : (F n).val (B.val hilbertRoot) =
      rightAlgebraAction α B ((F n).val hilbertRoot) := by
    rw [← rightAlgebraAction_root α B]
    exact congrArg (fun T : MagneticBoundedOperator => T hilbertRoot)
      (rightAlgebraAction_commute α (F n) B).eq
  simpa only [Function.comp_def, ← heq] using hv

/-- A uniformly bounded algebra sequence with a convergent root column defines
an actual bounded map on the dense trace algebra. -/
def sourceLimitLinear (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v)) :
    TraceAlgebra α →ₗ[ℂ] MagneticHilbert where
  toFun A := rightAlgebraAction α (show magneticAlgebra α from A) v
  map_add' A B := by
    have ha := root_tendsto_on_algebraVector α F v hv A
    have hb := root_tendsto_on_algebraVector α F v hv B
    have hab := root_tendsto_on_algebraVector α F v hv (A + B)
    apply tendsto_nhds_unique hab
    change Tendsto (fun n => (F n).val (A.val hilbertRoot + B.val hilbertRoot)) atTop _
    simpa only [map_add] using ha.add hb
  map_smul' c A := by
    have ha := root_tendsto_on_algebraVector α F v hv A
    have hca := root_tendsto_on_algebraVector α F v hv (c • A)
    apply tendsto_nhds_unique hca
    change Tendsto (fun n => (F n).val (c • A.val hilbertRoot)) atTop _
    simpa only [map_smul] using ha.const_smul c

theorem sourceLimitLinear_bound (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) (A : TraceAlgebra α) :
    ‖sourceLimitLinear α F v hv A‖ ≤ C * ‖A‖ := by
  have ht := (root_tendsto_on_algebraVector α F v hv A).norm
  apply le_of_tendsto ht
  exact Filter.Eventually.of_forall fun n =>
    ((F n).val.le_opNorm _).trans
      (mul_le_mul_of_nonneg_right (hC n) (norm_nonneg _))

def sourceLimitBounded (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) : TraceAlgebra α →L[ℂ] MagneticHilbert :=
  (sourceLimitLinear α F v hv).mkContinuous C (sourceLimitLinear_bound α F v hv C hC)

def sourceLimitOperator (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) : MagneticBoundedOperator :=
  (sourceLimitBounded α F v hv C hC).extend (traceVectorize α).toContinuousLinearMap
    (traceVectorize_dense α) (traceVectorize α).isometry.isUniformInducing

theorem sourceLimitOperator_vectorize (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) (A : TraceAlgebra α) :
    sourceLimitOperator α F v hv C hC (traceVectorize α A) = rightAlgebraAction α A v :=
  ContinuousLinearMap.extend_eq _ _ _ _ A

theorem sourceLimitOperator_bound (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) : ‖sourceLimitOperator α F v hv C hC‖ ≤ C := by
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0)
  apply ContinuousLinearMap.opNorm_le_bound _ hC0
  intro u
  refine (traceVectorize_dense α).induction_on u ?_ ?_
  · exact isClosed_le (sourceLimitOperator α F v hv C hC).continuous.norm
      (continuous_const.mul continuous_norm)
  · intro A
    rw [sourceLimitOperator_vectorize]
    simpa only [(traceVectorize α).norm_map] using sourceLimitLinear_bound α F v hv C hC A

/-- Uniform operator bounds propagate the already proved dense-source limit
into strong convergence on every lattice vector. -/
theorem sourceLimitOperator_tendsto (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) (u : MagneticHilbert) :
    Tendsto (fun n => (F n).val u) atTop (𝓝 (sourceLimitOperator α F v hv C hC u)) := by
  let S := sourceLimitOperator α F v hv C hC
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0)
  have hS : ‖S‖ ≤ C := sourceLimitOperator_bound α F v hv C hC
  apply Metric.tendsto_atTop.mpr
  intro ε hε
  obtain ⟨A, hA⟩ := (traceVectorize_dense α).exists_dist_lt u
    (show 0 < ε / (3 * (C + 1)) by positivity)
  let a := traceVectorize α A
  have ha : C * dist u a < ε / 3 := by
    have h := (mul_lt_mul_left (show 0 < C + 1 by positivity)).mpr hA
    have heq : (C + 1) * (ε / (3 * (C + 1))) = ε / 3 := by
      field_simp
      ring
    rw [heq] at h
    change (C + 1) * dist u a < ε / 3 at h
    nlinarith [dist_nonneg (x := u) (y := a)]
  have hta : Tendsto (fun n => (F n).val a) atTop (𝓝 (S a)) := by
    rw [show S a = rightAlgebraAction α A v from sourceLimitOperator_vectorize α F v hv C hC A]
    exact root_tendsto_on_algebraVector α F v hv A
  obtain ⟨N, hN⟩ := Metric.tendsto_atTop.mp hta (ε / 3) (by positivity)
  refine ⟨N, fun n hn => ?_⟩
  have hleft : dist ((F n).val u) ((F n).val a) < ε / 3 :=
    ((F n).val.dist_le_opNorm u a).trans_lt
      ((mul_le_mul_of_nonneg_right (hC n) dist_nonneg).trans_lt ha)
  have hright : dist (S a) (S u) < ε / 3 := by
    apply (S.dist_le_opNorm a u).trans_lt
    rw [dist_comm a u]
    exact (mul_le_mul_of_nonneg_right hS dist_nonneg).trans_lt ha
  have hmid := hN n hn
  have hd := dist_triangle ((F n).val u) ((F n).val a) (S u)
  have hd' := dist_triangle ((F n).val a) (S a) (S u)
  change dist ((F n).val u) (S u) < ε
  linarith

theorem sourceLimitOperator_root (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) :
    sourceLimitOperator α F v hv C hC hilbertRoot = v :=
  tendsto_nhds_unique (sourceLimitOperator_tendsto α F v hv C hC hilbertRoot) hv

/-- Commutation with a fixed bounded operator passes to the actual strong limit. -/
theorem sourceLimitOperator_commute (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) (B : MagneticBoundedOperator)
    (hB : ∀ n, Commute (F n).val B) :
    Commute (sourceLimitOperator α F v hv C hC) B := by
  change sourceLimitOperator α F v hv C hC * B = B * sourceLimitOperator α F v hv C hC
  apply ContinuousLinearMap.ext
  intro u
  change sourceLimitOperator α F v hv C hC (B u) = B (sourceLimitOperator α F v hv C hC u)
  have hl := sourceLimitOperator_tendsto α F v hv C hC (B u)
  have hr := (B.continuous.tendsto _).comp (sourceLimitOperator_tendsto α F v hv C hC u)
  apply tendsto_nhds_unique hl
  have heq : (fun n => (F n).val (B u)) = (fun n => B ((F n).val u)) := by
    funext n
    exact congrArg (fun A : MagneticBoundedOperator => A u) (hB n).eq
  simpa only [heq, Function.comp_def] using hr

theorem sourceLimitOperator_right_commute (α : ℝ) (F : ℕ → magneticAlgebra α)
    (v : MagneticHilbert) (hv : Tendsto (fun n => (F n).val hilbertRoot) atTop (𝓝 v))
    (C : ℝ) (hC : ∀ n, ‖(F n).val‖ ≤ C) (A : magneticAlgebra α) :
    Commute (sourceLimitOperator α F v hv C hC) (rightAlgebraAction α A) :=
  sourceLimitOperator_commute α F v hv C hC _ (fun n => rightAlgebraAction_commute α (F n) A)

/-- A bounded left multiplier is determined by its root column. This uses the
actual dense trace algebra, not a cyclicity assumption for the Hamiltonian. -/
theorem operator_eq_of_root (α : ℝ) (A B : MagneticBoundedOperator)
    (hA : ∀ F : magneticAlgebra α, Commute A (rightAlgebraAction α F))
    (hB : ∀ F : magneticAlgebra α, Commute B (rightAlgebraAction α F))
    (hroot : A hilbertRoot = B hilbertRoot) : A = B := by
  apply ContinuousLinearMap.ext
  intro u
  refine (traceVectorize_dense α).induction_on u (isClosed_eq A.continuous B.continuous) ?_
  intro F
  change A (F.val hilbertRoot) = B (F.val hilbertRoot)
  rw [← rightAlgebraAction_root α F]
  have ha := congrArg (fun T : MagneticBoundedOperator => T hilbertRoot) (hA F).eq
  have hb := congrArg (fun T : MagneticBoundedOperator => T hilbertRoot) (hB F).eq
  change A (rightAlgebraAction α F hilbertRoot) = rightAlgebraAction α F (A hilbertRoot) at ha
  change B (rightAlgebraAction α F hilbertRoot) = rightAlgebraAction α F (B hilbertRoot) at hb
  rw [ha, hb, hroot]

end DTMAudit.BoundedSourceLimits

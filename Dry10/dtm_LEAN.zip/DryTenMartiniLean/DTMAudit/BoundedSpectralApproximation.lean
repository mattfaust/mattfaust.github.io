import DTMAudit.FullFermiProjection

/-! Uniformly bounded real continuous approximants to every essentially bounded spectral function, using clipping and actual spectral L2 density. -/

set_option autoImplicit false
noncomputable section
namespace DTMAudit.BoundedSpectralApproximation
open CriticalDTM DTMAudit.SpectralSources MeasureTheory Filter
open scoped Topology ContinuousFunctionalCalculus

local instance spectralCompactSpace (α lam : ℝ) : CompactSpace (MagneticRealSpectrum α lam) :=
  isCompact_iff_compactSpace.mp (spectrum.isCompact (magneticAlgebraHamiltonian α lam))

/-- Clipping to the real interval [-C,C]. -/
def clipReal (C x : ℝ) : ℝ := max (-C) (min C x)

theorem clipReal_norm_le {C : ℝ} (hC : 0 ≤ C) (x : ℝ) : ‖clipReal C x‖ ≤ C := by
  rw [Real.norm_eq_abs, abs_le]
  exact ⟨le_max_left _ _, max_le (by linarith) (min_le_left _ _)⟩

/-- Clipping cannot increase distance to any point already within the bound. -/
theorem clipReal_sub_norm_le {C y : ℝ} (hC : 0 ≤ C) (hy : ‖y‖ ≤ C) (x : ℝ) :
    ‖clipReal C x - y‖ ≤ ‖x - y‖ := by
  have hy' := abs_le.mp hy
  rcases le_or_gt x (-C) with hx | hx
  · have hxc : x ≤ C := by linarith
    rw [clipReal, min_eq_right hxc, max_eq_left hx, Real.norm_eq_abs, Real.norm_eq_abs,
      abs_of_nonpos (by linarith : -C - y ≤ 0), abs_of_nonpos (by linarith : x - y ≤ 0)]
    linarith
  · rcases le_or_gt x C with hxC | hxC
    · rw [clipReal, min_eq_right hxC, max_eq_right hx.le]
    · rw [clipReal, min_eq_left hxC.le, max_eq_right (by linarith : -C ≤ C),
        Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (by linarith : 0 ≤ C - y),
        abs_of_nonneg (by linarith : 0 ≤ x - y)]
      linarith

def clipContinuous (α lam C : ℝ) (g : C(MagneticRealSpectrum α lam, ℝ)) :
    C(MagneticRealSpectrum α lam, ℝ) :=
  ⟨fun x => clipReal C (g x), continuous_const.max (continuous_const.min g.continuous)⟩

theorem clipContinuous_bound (α lam C : ℝ) (hC : 0 ≤ C)
    (g : C(MagneticRealSpectrum α lam, ℝ)) (x : MagneticRealSpectrum α lam) :
    ‖clipContinuous α lam C g x‖ ≤ C := clipReal_norm_le hC _

/-- The clipping operation contracts L² distance to the actual bounded target. -/
theorem clipContinuous_L2_error_le (α lam C : ℝ) (hC : 0 ≤ C)
    (u : SpectralL2 α lam) (hu : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖u x‖ ≤ C)
    (g : C(MagneticRealSpectrum α lam, ℝ)) :
    ‖ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ (clipContinuous α lam C g) - u‖ ≤
      ‖ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ g - u‖ := by
  apply Lp.norm_le_norm_of_ae_le
  filter_upwards [hu,
    Lp.coeFn_sub (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ (clipContinuous α lam C g)) u,
    Lp.coeFn_sub (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ g) u,
    ContinuousMap.coeFn_toLp (𝕜 := ℝ) (p := 2) (magneticSpectralMeasure α lam) (clipContinuous α lam C g),
    ContinuousMap.coeFn_toLp (𝕜 := ℝ) (p := 2) (magneticSpectralMeasure α lam) g]
    with x hx hs ht hc hg
  simp only [hs, ht, Pi.sub_apply, hc, hg]
  exact clipReal_sub_norm_le hC hx (g x)

set_option maxHeartbeats 800000 in
/-- Every essentially bounded spectral L² vector has continuous approximants
with the same uniform bound, constructed from actual continuous-test density. -/
theorem exists_bounded_continuous_L2_approx (α lam C : ℝ) (hC : 0 ≤ C)
    (u : SpectralL2 α lam) (hu : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖u x‖ ≤ C) :
    ∃ g : ℕ → C(MagneticRealSpectrum α lam, ℝ),
      (∀ n x, ‖g n x‖ ≤ C) ∧
      Tendsto (fun n => ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ (g n)) atTop (𝓝 u) := by
  have hd (n : ℕ) : ∃ g : C(MagneticRealSpectrum α lam, ℝ),
      dist u (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ g) < 1 / ((n : ℝ) + 1) :=
    (continuousTests_dense α lam).exists_dist_lt u (by positivity)
  choose g hg using hd
  refine ⟨fun n => clipContinuous α lam C (g n), fun n x => clipContinuous_bound α lam C hC (g n) x, ?_⟩
  rw [tendsto_iff_norm_sub_tendsto_zero]
  have herror (n : ℕ) :
      ‖ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ (clipContinuous α lam C (g n)) - u‖ ≤
        1 / ((n : ℝ) + 1) := by
    apply (clipContinuous_L2_error_le α lam C hC u hu (g n)).trans
    rw [← dist_eq_norm, dist_comm]
    exact (hg n).le
  exact squeeze_zero (fun _ => norm_nonneg _) herror tendsto_one_div_add_atTop_nhds_zero_nat

/-- The actual L² class of an essentially bounded measurable spectral function. -/
def boundedSpectralL2 (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ)
    (hbound : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) : SpectralL2 α lam :=
  (MemLp.of_bound hf C hbound).toLp f

@[simp] theorem boundedSpectralL2_coeFn (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ)
    (hbound : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    (boundedSpectralL2 α lam f hf C hbound : MagneticRealSpectrum α lam → ℝ) =ᵐ[magneticSpectralMeasure α lam] f :=
  MemLp.coeFn_toLp _

/-- No approximation premise: measurability and the bound construct the sequence. -/
theorem exists_bounded_continuous_approx (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hbound : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    ∃ g : ℕ → C(MagneticRealSpectrum α lam, ℝ),
      (∀ n x, ‖g n x‖ ≤ C) ∧
      Tendsto (fun n => ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ (g n)) atTop
        (𝓝 (boundedSpectralL2 α lam f hf C hbound)) := by
  apply exists_bounded_continuous_L2_approx α lam C hC
  filter_upwards [boundedSpectralL2_coeFn α lam f hf C hbound, hbound] with x hx hb
  simpa only [hx] using hb

/-- The uniform scalar bound is exactly a bound on the actual CFC operators. -/
theorem spectralOperator_norm_le (α lam C : ℝ) (hC : 0 ≤ C)
    (g : C(MagneticRealSpectrum α lam, ℝ)) (hg : ∀ x, ‖g x‖ ≤ C) :
    ‖FullFermiProjection.spectralOperator α lam g‖ ≤ C := by
  change ‖(cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) g : magneticAlgebra α)‖ ≤ C
  rw [norm_cfcHom _ _ (magneticAlgebraHamiltonian_isSelfAdjoint α lam)]
  exact (g.norm_le hC).mpr hg

/-- Bounded continuous approximants converge in source norm through the actual
isometric spectral-source extension, and their full operators have the same bound. -/
theorem exists_bounded_continuous_source_approx (α lam : ℝ) (f : MagneticRealSpectrum α lam → ℝ)
    (hf : AEStronglyMeasurable f (magneticSpectralMeasure α lam)) (C : ℝ) (hC : 0 ≤ C)
    (hbound : ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖f x‖ ≤ C) :
    ∃ g : ℕ → C(MagneticRealSpectrum α lam, ℝ),
      (∀ n x, ‖g n x‖ ≤ C) ∧
      (∀ n, ‖FullFermiProjection.spectralOperator α lam (g n)‖ ≤ C) ∧
      Tendsto (fun n => ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ (g n)) atTop
        (𝓝 (boundedSpectralL2 α lam f hf C hbound)) ∧
      Tendsto (fun n => continuousSource α lam (g n)) atTop
        (𝓝 (spectralSource α lam (boundedSpectralL2 α lam f hf C hbound))) := by
  obtain ⟨g, hg, ht⟩ := exists_bounded_continuous_approx α lam f hf C hC hbound
  refine ⟨g, hg, fun n => spectralOperator_norm_le α lam C hC (g n) (hg n), ht, ?_⟩
  have hs := ((spectralSource α lam).continuous.tendsto _).comp ht
  simpa only [Function.comp_def, spectralSource_continuous] using hs

end DTMAudit.BoundedSpectralApproximation

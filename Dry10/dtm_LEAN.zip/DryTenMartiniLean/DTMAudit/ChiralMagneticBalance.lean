import DTMAudit.Angular
import DTMAudit.MeasurableFamily
import Mathlib.MeasureTheory.Function.ConvergenceInMeasure
import DTMAudit.BoundedBorelCalculus
import DTMAudit.FermiSpan
import DTM.Background.IndependentSeeds.CosineResonanceAlgebra

/-!
# The centered chiral proof of magnetic balance

The centered operators below are unitary transports of the actual magnetic
left/right actions. The stationary space is the image of the closed span of
physical Fermi sources, not a space defined by a current equation.
-/
noncomputable section
set_option maxHeartbeats 800000
namespace DTMAudit.ChiralMagneticBalance
open CriticalDTM CriticalDTM.Chiral DTMCompanion.ChiralGauge
open scoped InnerProductSpace

abbrev basis (n m : ℤ) : LatticeHilbert := lp.single 2 (n,m) (1 : ℂ)

def transport (α : ℝ) (A : LatticeHilbert →L[ℂ] LatticeHilbert) :
    LatticeHilbert →L[ℂ] LatticeHilbert :=
  (SymmetricGauge.unitary α : LatticeHilbert →L[ℂ] LatticeHilbert) * A *
    ((SymmetricGauge.unitary α).symm : LatticeHilbert →L[ℂ] LatticeHilbert)

@[simp] theorem transport_apply (α : ℝ) (A : LatticeHilbert →L[ℂ] LatticeHilbert)
    (u : LatticeHilbert) :
    transport α A u = SymmetricGauge.unitary α (A ((SymmetricGauge.unitary α).symm u)) := rfl

@[simp] theorem transport_unitary (α : ℝ) (A : LatticeHilbert →L[ℂ] LatticeHilbert)
    (u : LatticeHilbert) :
    transport α A (SymmetricGauge.unitary α u) = SymmetricGauge.unitary α (A u) := by
  simp [transport_apply]

def mean (α lam : ℝ) := transport α (averageOperator α lam)
def difference (α lam : ℝ) := transport α (Paired.differenceOperator α lam)
def current (α lam : ℝ) : LatticeHilbert →L[ℂ] LatticeHilbert :=
  Lz * mean α lam - mean α lam * Lz

@[simp] theorem basis_inner (n m : ℤ) (u : LatticeHilbert) :
    ⟪basis n m, u⟫_ℂ = u (n,m) := by
  simp [basis, lp.inner_single_left]

theorem transport_symmetric (α : ℝ) (A : LatticeHilbert →L[ℂ] LatticeHilbert)
    (hA : SymmetricOperator A) : SymmetricOperator (transport α A) := by
  intro u v
  obtain ⟨u, rfl⟩ := (SymmetricGauge.unitary α).surjective u
  obtain ⟨v, rfl⟩ := (SymmetricGauge.unitary α).surjective v
  simpa only [transport_unitary, LinearIsometryEquiv.inner_map_map] using hA u v

theorem mean_symmetric (α lam : ℝ) : SymmetricOperator (mean α lam) :=
  transport_symmetric α _ (averageOperator_symmetric α lam)

theorem difference_symmetric (α lam : ℝ) : SymmetricOperator (difference α lam) := by
  apply transport_symmetric
  intro u v
  simp only [Paired.differenceOperator, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.sub_apply, inner_smul_left, inner_smul_right,
    inner_sub_left, inner_sub_right, map_div₀, map_one, map_ofNat,
    (hOperator_isSelfAdjoint α lam).isSymmetric.apply_clm,
    (conjugateOperator_isSelfAdjoint α lam).isSymmetric.apply_clm]

theorem mean_row (α lam : ℝ) (u : LatticeHilbert) (n m : ℤ) :
    mean α lam u (n,m) =
      (Real.cos (Real.pi*α*(m : ℝ)) : ℂ) * (u (n-1,m) + u (n+1,m)) +
      (lam : ℂ) * (Real.cos (Real.pi*α*(n : ℝ)) : ℂ) *
        (u (n,m-1) + u (n,m+1)) := by
  obtain ⟨u, rfl⟩ := (SymmetricGauge.unitary α).surjective u
  simpa only [mean, transport_unitary] using SymmetricGauge.unitary_average_row α lam u n m

theorem difference_row (α lam : ℝ) (u : LatticeHilbert) (n m : ℤ) :
    difference α lam u (n,m) =
      Complex.I * (Real.sin (Real.pi*α*(m : ℝ)) : ℂ) * (u (n-1,m) - u (n+1,m)) -
      Complex.I * (lam : ℂ) * (Real.sin (Real.pi*α*(n : ℝ)) : ℂ) *
        (u (n,m-1) - u (n,m+1)) := by
  obtain ⟨u, rfl⟩ := (SymmetricGauge.unitary α).surjective u
  simpa only [difference, transport_unitary, Paired.differenceOperator,
    ContinuousLinearMap.smul_apply, ContinuousLinearMap.sub_apply] using
      SymmetricGauge.unitary_difference_row α lam u n m

theorem mean_column (α lam : ℝ) (n m : ℤ) :
    mean α lam (basis n m) =
      (Real.cos (Real.pi*α*(m : ℝ)) : ℂ) • (basis (n+1) m + basis (n-1) m) +
      ((lam : ℂ) * (Real.cos (Real.pi*α*(n : ℝ)) : ℂ)) •
        (basis n (m+1) + basis n (m-1)) := by
  apply ext_inner_right ℂ
  intro u
  rw [mean_symmetric, basis_inner, mean_row]
  simp only [inner_add_left, inner_smul_left, basis_inner,
    map_mul, Complex.conj_ofReal]
  ring

theorem difference_column (α lam : ℝ) (n m : ℤ) :
    difference α lam (basis n m) =
      (Complex.I * (Real.sin (Real.pi*α*(m : ℝ)) : ℂ)) •
        (basis (n+1) m - basis (n-1) m) -
      (Complex.I * (lam : ℂ) * (Real.sin (Real.pi*α*(n : ℝ)) : ℂ)) •
        (basis n (m+1) - basis n (m-1)) := by
  apply ext_inner_right ℂ
  intro u
  rw [difference_symmetric, basis_inner, difference_row]
  simp only [inner_sub_left, inner_smul_left, basis_inner,
    map_mul, Complex.conj_ofReal, Complex.conj_I]
  ring

theorem Lz_basis (n m : ℤ) :
    Lz (basis n m) = (-2 * angularValue (n,m)) • basis n m := by
  apply lp.ext
  funext s
  simp only [Lz, ContinuousLinearMap.smul_apply, angular_apply_site,
    lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  by_cases hs : s = (n,m)
  · subst s
    ring
  · simp [basis, lp.single_apply_ne, hs, Ne.symm hs]

/-- The two outgoing bonds of one directed branch, before the common phase. -/
def outgoing (lam : ℝ) (σ ε n : ℤ) : LatticeHilbert :=
  basis (n+ε) (σ*n) + (lam : ℂ) • basis n (σ*(n-ε))

theorem Lz_basis_horizontal {n m : ℤ} (h : horizontal (n,m)) :
    Lz (basis n m) = basis n m := by
  rw [Lz_basis, angularValue_horizontal h]
  norm_num

theorem Lz_basis_vertical {n m : ℤ} (h : vertical (n,m)) :
    Lz (basis n m) = -basis n m := by
  rw [Lz_basis, angularValue_vertical h]
  norm_num

/-- Both endpoints of a nonzero outgoing leg have the same angular sign.
The only geometric input is the already checked four nearest-neighbor rays. -/
theorem outgoing_angular (lam : ℝ) {σ ε n : ℤ}
    (hσ : σ = 1 ∨ σ = -1) (hε : ε = 1 ∨ ε = -1) (hn : n ≠ 0) :
    Lz (outgoing lam σ ε n) =
      ((ε : ℂ) * (Real.sign (n : ℝ) : ℂ)) • outgoing lam σ ε n := by
  rcases lt_or_gt_of_ne hn with hn | hn
  all_goals
    have hp := positive_diagonal_neighbors n
    have hm := negative_diagonal_neighbors n
    have hap := positive_antidiagonal_neighbors n
    have ham := negative_antidiagonal_neighbors n
  · obtain ⟨hE,hW,hN,hS⟩ := hm hn
    obtain ⟨haE,haW,haN,haS⟩ := ham hn
    have hr : (n : ℝ) < 0 := by exact_mod_cast hn
    rcases hσ with rfl | rfl <;> rcases hε with rfl | rfl <;>
      simp only [outgoing, one_mul, neg_one_mul, add_neg, sub_neg_eq_add,
        neg_sub, map_add, map_smul, Int.cast_one, Int.cast_neg,
        show n + (-1) = n-1 by omega, show 1-n = -n+1 by omega,
        show -(n+1) = -n-1 by omega,
        Real.sign_of_neg hr, Complex.ofReal_neg, Complex.ofReal_one,
        mul_neg_one, neg_mul_neg, one_mul, neg_smul, one_smul]
    · rw [Lz_basis_vertical hE, Lz_basis_vertical hS]
      module
    · rw [Lz_basis_horizontal hW, Lz_basis_horizontal hN]
      module
    · rw [Lz_basis_vertical haE, Lz_basis_vertical haN]
      module
    · rw [Lz_basis_horizontal haW, Lz_basis_horizontal haS]
      module
  · obtain ⟨hE,hW,hN,hS⟩ := hp hn
    obtain ⟨haE,haW,haN,haS⟩ := hap hn
    have hr : 0 < (n : ℝ) := by exact_mod_cast hn
    rcases hσ with rfl | rfl <;> rcases hε with rfl | rfl <;>
      simp only [outgoing, one_mul, neg_one_mul, add_neg, sub_neg_eq_add,
        neg_sub, map_add, map_smul, Int.cast_one, Int.cast_neg,
        show n + (-1) = n-1 by omega, show 1-n = -n+1 by omega,
        show -(n+1) = -n-1 by omega,
        Real.sign_of_pos hr, Complex.ofReal_one, mul_one, neg_smul, one_smul]
    · rw [Lz_basis_horizontal hE, Lz_basis_horizontal hS]
    · rw [Lz_basis_vertical hW, Lz_basis_vertical hN]
      module
    · rw [Lz_basis_horizontal haE, Lz_basis_horizontal haN]
    · rw [Lz_basis_vertical haW, Lz_basis_vertical haS]
      module

/-- The full mean column is the cosine-weighted sum of the two legs. -/
theorem mean_boundary_column (α lam : ℝ) {σ : ℤ}
    (hσ : σ = 1 ∨ σ = -1) (n : ℤ) :
    mean α lam (basis n (σ*n)) =
      (Real.cos (Real.pi*α*(n : ℝ)) : ℂ) •
        (outgoing lam σ 1 n + outgoing lam σ (-1) n) := by
  rcases hσ with rfl | rfl <;>
    simp only [mean_column, outgoing, one_mul, neg_one_mul, Int.cast_neg,
      mul_neg, Real.cos_neg, add_neg, sub_neg_eq_add, neg_sub]
  all_goals
    simp only [show n + (-1) = n-1 by omega, show 1-n = -n+1 by omega,
      show -(n+1) = -n-1 by omega]
    module

/-- The difference column is i σ times the sine-weighted leg difference. -/
theorem difference_boundary_column (α lam : ℝ) {σ : ℤ}
    (hσ : σ = 1 ∨ σ = -1) (n : ℤ) :
    difference α lam (basis n (σ*n)) =
      (Complex.I * (σ : ℂ) * (Real.sin (Real.pi*α*(n : ℝ)) : ℂ)) •
        (outgoing lam σ 1 n - outgoing lam σ (-1) n) := by
  rcases hσ with rfl | rfl <;>
    simp only [difference_column, outgoing, one_mul, neg_one_mul, Int.cast_neg,
      Int.cast_one, mul_neg, Real.sin_neg, Complex.ofReal_neg, add_neg,
      sub_neg_eq_add, neg_sub]
  all_goals
    simp only [show n + (-1) = n-1 by omega, show 1-n = -n+1 by omega,
      show -(n+1) = -n-1 by omega]
    module

theorem unitary_Lz (α : ℝ) (u : LatticeHilbert) :
    Lz (SymmetricGauge.unitary α u) = SymmetricGauge.unitary α (Lz u) := by
  simp only [Lz, ContinuousLinearMap.smul_apply, SymmetricGauge.unitary_angular,
    map_smul]

theorem unitary_diagonal (α : ℝ) (u : LatticeHilbert) :
    axisProjection (SymmetricGauge.unitary α u) =
      SymmetricGauge.unitary α (axisProjection u) := by
  apply lp.ext
  funext s
  simp only [axisProjection_apply, SymmetricGauge.unitary_apply]
  ring

theorem current_unitary (α lam : ℝ) (u : LatticeHilbert) :
    current α lam (SymmetricGauge.unitary α u) =
      (-2 : ℂ) • SymmetricGauge.unitary α (axisCurrent α lam u) := by
  simp only [current, ContinuousLinearMap.sub_apply, ContinuousLinearMap.mul_apply,
    mean, transport_unitary, unitary_Lz, axisCurrent, map_sub,
    Lz, ContinuousLinearMap.smul_apply, map_smul]
  simp only [SymmetricGauge.unitary_angular, transport_unitary]
  module

/-- The nearest-neighbor row/column support is transported through the diagonal
unitary; the underlying proof uses the no-cone-crossing geometry. -/
theorem current_row_column (α lam : ℝ) (u : LatticeHilbert) :
    current α lam u = axisProjection (current α lam u) +
      current α lam (axisProjection u) := by
  obtain ⟨u,rfl⟩ := (SymmetricGauge.unitary α).surjective u
  rw [unitary_diagonal, current_unitary, current_unitary, map_smul,
    unitary_diagonal]
  rw [← smul_add, ← map_add, ← axisCurrent_row_column]

theorem diagonal_Lz (u : LatticeHilbert) : axisProjection (Lz u) = 0 := by
  apply lp.ext
  funext s
  simp only [axisProjection_apply, Lz, ContinuousLinearMap.smul_apply,
    lp.coeFn_smul, Pi.smul_apply, smul_eq_mul, angular_apply_site,
    lp.coeFn_zero, Pi.zero_apply]
  by_cases hs : |s.1| = |s.2|
  · rw [angularValue_axis hs]
    ring
  · simp [axisWeight, hs]

theorem Lz_diagonal (u : LatticeHilbert) : Lz (axisProjection u) = 0 := by
  apply lp.ext
  funext s
  have h := congrArg (fun v : LatticeHilbert => v s) (diagonal_Lz u)
  simp only [axisProjection_apply, Lz, ContinuousLinearMap.smul_apply,
    lp.coeFn_smul, Pi.smul_apply, smul_eq_mul, angular_apply_site,
    lp.coeFn_zero, Pi.zero_apply] at h ⊢
  linear_combination h

theorem current_unitary_commutator (α lam : ℝ) (u : LatticeHilbert) :
    current α lam (SymmetricGauge.unitary α u) =
      SymmetricGauge.unitary α
        (Lz (averageOperator α lam u) - averageOperator α lam (Lz u)) := by
  simp only [current, ContinuousLinearMap.sub_apply, ContinuousLinearMap.mul_apply,
    mean, transport_unitary, unitary_Lz, map_sub]

end DTMAudit.ChiralMagneticBalance

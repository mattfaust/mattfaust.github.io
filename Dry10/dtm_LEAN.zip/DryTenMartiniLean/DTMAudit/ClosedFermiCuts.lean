import DTMAudit.SpectralPVM
import DTM.Background.Exposition.SingularLogIntegral

set_option autoImplicit false
set_option maxHeartbeats 400000
noncomputable section
namespace DTMAudit.ClosedFermiCuts
open CriticalDTM DTMAudit.SpectralSources DTMAudit.BoundedBorelCalculus DTMAudit.SpectralPVM
open MeasureTheory

def closedLowerSpectrum (α lam E : ℝ) : Set (MagneticRealSpectrum α lam) :=
  {x | x.val ≤ E}

theorem closedLowerSpectrum_measurable (α lam E : ℝ) :
    MeasurableSet (closedLowerSpectrum α lam E) :=
  (isClosed_le continuous_subtype_val continuous_const).measurableSet

/-- There is no spectral mass at the endpoint, including when it lies in the spectrum. -/
theorem closedLower_indicator_ae (α lam E : ℝ) :
    indicatorFunction α lam (closedLowerSpectrum α lam E) =ᵐ[magneticSpectralMeasure α lam]
      indicatorFunction α lam (magneticLowerSpectrum α lam E) := by
  filter_upwards [(magnetic_logKernel_integrable_and_ae_ne α lam E).2] with x hx
  have hne : x.val ≠ E := hx
  have hm : x ∈ closedLowerSpectrum α lam E ↔ x ∈ magneticLowerSpectrum α lam E :=
    le_iff_lt_or_eq.trans (or_iff_left hne)
  classical
  by_cases h : x ∈ magneticLowerSpectrum α lam E
  · simp [indicatorFunction, h, hm.mpr h]
  · simp [indicatorFunction, h, mt hm.mp h]

/-- The manuscript's closed lower cut is exactly the constructed strict lower-cut operator. -/
theorem closedLowerProjection_eq_lower (α lam E : ℝ) :
    indicatorProjection α lam (closedLowerSpectrum α lam E)
      (closedLowerSpectrum_measurable α lam E) = FullFermiProjection.lowerProjection α lam E := by
  rw [← indicatorProjection_lower]
  unfold indicatorProjection
  apply boundedOperator_congr
  exact closedLower_indicator_ae α lam E

end DTMAudit.ClosedFermiCuts

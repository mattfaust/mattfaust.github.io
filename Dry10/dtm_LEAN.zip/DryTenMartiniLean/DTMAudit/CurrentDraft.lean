import DTMAudit.ManuscriptEndpoint

/-!
# The current manuscript's full theorem, displayed without project aliases

`h lam φ` is the bounded operator on `ℓ²(ℤ, ℂ)` whose action is specified
in the first conjunct. The phase `φ` is measured in radians; `lam` denotes
the manuscript's coupling `λ` (`λ` itself is Lean's function syntax).

The matrix written inside the limit is the Dirichlet restriction to the
sites `0, …, L`: the two off-diagonals are 1 and the diagonal is the literal
cosine potential. The roots of its characteristic polynomial form a
multiset, so `countP` counts eigenvalues with their algebraic multiplicities.
The matrix is Hermitian, hence those eigenvalues are real. The denominator
`L + 1` is exactly the number of retained sites.

The witnesses `a < b` precede the universal phase quantifier. Thus they are
common positive-width gap endpoints in the actual operator spectrum for
every phase. Every interior energy has normalized Dirichlet counts tending
to the fractional part of `n * α`. No definition from the companion is
needed to read the theorem's type, and no model or seed assumption is added.
-/

noncomputable section
namespace CurrentDraft
open Filter
open scoped Topology

/-- Dry Ten Martini for every irrational frequency and nonzero real coupling,
with the literal operator, finite-volume counts, and common gap endpoints. -/
-- Manuscript Theorem 1.5.
theorem dry_ten_martini :
    ∀ α : ℝ, Irrational α →
    ∃ h : ℝ → ℝ → (ℓ²(ℤ, ℂ) →L[ℂ] ℓ²(ℤ, ℂ)),
      (∀ (lam φ : ℝ) (ψ : ℓ²(ℤ, ℂ)) (j : ℤ),
        h lam φ ψ j = ψ (j + 1) + ψ (j - 1) +
          ((2 * lam * Real.cos (2 * Real.pi * α * (j : ℝ) + φ) : ℝ) : ℂ) * ψ j) ∧
      ∀ lam : ℝ, lam ≠ 0 → ∀ n : ℤ, n ≠ 0 →
        ∃ a b : ℝ, a < b ∧ ∀ φ : ℝ,
          (a : ℂ) ∈ spectrum ℂ (h lam φ) ∧
          (b : ℂ) ∈ spectrum ℂ (h lam φ) ∧
          ∀ E : ℝ, a < E → E < b →
            (E : ℂ) ∉ spectrum ℂ (h lam φ) ∧
            Tendsto
              (fun L : ℕ =>
                (((Matrix.charpoly (fun i j : Fin (L + 1) =>
                  (if (i.val : ℤ) + 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
                  (if (i.val : ℤ) - 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
                  (if i = j then
                    ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + φ) : ℝ) : ℂ)
                   else 0))).roots.countP
                    (fun z : ℂ => z.re < E) : ℕ) : ℝ) / ((L + 1 : ℕ) : ℝ))
              atTop (𝓝 (Int.fract ((n : ℝ) * α))) := by
  intro α hα
  obtain ⟨h, hrow, hgap⟩ := DTMAudit.ManuscriptEndpoint.nonzero_statement α hα
  refine ⟨h, hrow, ?_⟩
  dsimp only at hgap
  intro lam hlam n hn
  obtain ⟨a, b, hab, hphase⟩ := hgap lam hlam n hn
  refine ⟨a, b, hab, ?_⟩
  intro φ
  obtain ⟨ha, hb, hinterior⟩ := hphase φ
  refine ⟨ha, hb, ?_⟩
  intro E hEa hEb
  obtain ⟨hE, hlimit⟩ := hinterior E hEa hEb
  refine ⟨hE, ?_⟩
  have hfinite : ∀ L : ℕ,
      (fun i j : Fin (L + 1) =>
        h lam φ (lp.single 2 (j.val : ℤ) (1 : ℂ)) (i.val : ℤ)) =
      (fun i j : Fin (L + 1) =>
        (if (i.val : ℤ) + 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
        (if (i.val : ℤ) - 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
        (if i = j then
          ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + φ) : ℝ) : ℂ)
         else 0)) := by
    intro L
    funext i j
    rw [hrow]
    simp only [lp.single_apply, Pi.single_apply]
    by_cases hij : i = j
    · subst j
      simp
    · have hval : (i.val : ℤ) ≠ (j.val : ℤ) := by
        exact_mod_cast (Fin.val_ne_of_ne hij)
      simp [hij, hval]
  simpa only [hfinite] using hlimit

end CurrentDraft

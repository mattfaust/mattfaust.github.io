import DTMAudit.SpectralSources
import Mathlib.MeasureTheory.Function.AEEqOfIntegral
import Mathlib.MeasureTheory.PiSystem

/-! # The full Fermi-source span

All real lower-threshold spectral sources generate exactly the independently
defined closed polynomial cyclic space. The proof uses the generating lower-cut
pi-system and the actual spectral L2 source construction.
-/
noncomputable section
namespace DTMAudit.FermiSpan
open MeasureTheory Set
open scoped InnerProductSpace

/-- Indicator vectors of a generating pi-system containing the whole space
have dense real span in L² of every finite measure. -/
theorem eq_top_of_generating_indicators
    {X : Type*} [MeasurableSpace X] (μ : Measure X) [IsFiniteMeasure μ]
    (S : Submodule ℝ (Lp ℝ 2 μ)) (hS : IsClosed (S : Set (Lp ℝ 2 μ)))
    (G : Set (Set X)) (hgen : ‹MeasurableSpace X› = MeasurableSpace.generateFrom G)
    (hpi : IsPiSystem G) (huniv : Set.univ ∈ G)
    (hmeas : ∀ s ∈ G, MeasurableSet s)
    (hmem : ∀ s (hs : s ∈ G),
      indicatorConstLp 2 (hmeas s hs) (measure_ne_top μ s) (1 : ℝ) ∈ S) :
    S = ⊤ := by
  have horth : Sᗮ = ⊥ := by
    apply le_antisymm ?_ bot_le
    intro f hf
    have hzero (s : Set X) (hs : s ∈ G) : ∫ x in s, f x ∂μ = 0 :=
      (L2.inner_indicatorConstLp_one (hmeas s hs) (measure_ne_top μ s) f).symm.trans
        (Submodule.inner_right_of_mem_orthogonal (hmem s hs) hf)
    have hint : Integrable (fun x => f x) μ := by
      simpa only [IntegrableOn, Measure.restrict_univ] using
        (integrableOn_Lp_of_measure_ne_top f (by norm_num : (1 : ENNReal) ≤ 2)
          (measure_ne_top μ Set.univ))
    have htotal : ∫ x, f x ∂μ = 0 := by
      simpa only [Measure.restrict_univ] using hzero Set.univ huniv
    have hall : ∀ s : Set X, MeasurableSet s → ∫ x in s, f x ∂μ = 0 := by
      refine MeasurableSpace.induction_on_inter hgen hpi ?_ ?_ ?_ ?_
      · simp
      · intro s hs
        exact hzero s hs
      · intro s hs ih
        have hc := integral_add_compl hs hint
        rw [ih, zero_add, htotal] at hc
        exact hc
      · intro s hd hs ih
        rw [integral_iUnion hs hd hint.integrableOn]
        simp only [ih, tsum_zero]
    have hae : (fun x => f x) =ᵐ[μ] 0 :=
      hint.ae_eq_zero_of_forall_setIntegral_eq_zero (fun s hs _ => hall s hs)
    change f = 0
    apply Lp.ext
    exact hae.trans (Lp.coeFn_zero ℝ 2 μ).symm
  calc
    S = S.topologicalClosure := hS.submodule_topologicalClosure_eq.symm
    _ = Sᗮᗮ := (Submodule.orthogonal_orthogonal_eq_closure S).symm
    _ = ⊤ := by rw [horth, Submodule.bot_orthogonal_eq_top]

open CriticalDTM CriticalDTM.Chiral DTMAudit.SpectralSources
open scoped ContinuousFunctionalCalculus

local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

/-- Strict lower cuts generate the actual compact spectral measurable space. -/
theorem lowerCuts_generate (α lam : ℝ) :
    (inferInstance : MeasurableSpace (MagneticRealSpectrum α lam)) =
      MeasurableSpace.generateFrom (Set.range (magneticLowerSpectrum α lam)) := by
  change MeasurableSpace.comap (fun x : MagneticRealSpectrum α lam => (x : ℝ)) (borel ℝ) = _
  rw [borel_eq_generateFrom_Iio, MeasurableSpace.comap_generateFrom]
  congr 1
  ext s
  constructor
  · rintro ⟨t, ⟨E, rfl⟩, rfl⟩
    exact ⟨E, rfl⟩
  · rintro ⟨E, rfl⟩
    exact ⟨Iio E, ⟨E, rfl⟩, rfl⟩

theorem lowerCuts_piSystem (α lam : ℝ) :
    IsPiSystem (Set.range (magneticLowerSpectrum α lam)) := by
  rintro s ⟨E, rfl⟩ t ⟨F, rfl⟩ _
  refine ⟨min E F, ?_⟩
  ext x
  simp only [magneticLowerSpectrum, mem_setOf_eq, mem_inter_iff, lt_min_iff]

/-- Compactness supplies a cut above the entire spectrum. -/
theorem univ_mem_lowerCuts (α lam : ℝ) :
    Set.univ ∈ Set.range (magneticLowerSpectrum α lam) := by
  have hc : IsCompact (spectrum ℝ (magneticAlgebraHamiltonian α lam)) := spectrum.isCompact _
  obtain ⟨M, hM⟩ := hc.bddAbove
  refine ⟨M + 1, ?_⟩
  ext x
  change (x : ℝ) < M + 1 ↔ True
  exact ⟨fun _ => trivial, fun _ => lt_of_le_of_lt (hM x.property) (lt_add_one M)⟩

/-- All real threshold indicators have dense real span in the actual spectral L² space. -/
theorem thresholdL2_span_dense (α lam : ℝ) :
    (Submodule.span ℝ (Set.range (thresholdL2 α lam))).topologicalClosure = ⊤ := by
  apply eq_top_of_generating_indicators (magneticSpectralMeasure α lam) _
    (Submodule.isClosed_topologicalClosure _) (Set.range (magneticLowerSpectrum α lam))
    (lowerCuts_generate α lam) (lowerCuts_piSystem α lam) (univ_mem_lowerCuts α lam)
    (by rintro s ⟨E, rfl⟩; exact lowerSpectrum_measurable α lam E)
  rintro s ⟨E, rfl⟩
  apply Submodule.le_topologicalClosure
  exact Submodule.subset_span ⟨E, rfl⟩

/-- The closed complex span of all actual lower-threshold sources. -/
def thresholdSourceSpace (α lam : ℝ) : Submodule ℂ MagneticHilbert :=
  (Submodule.span ℂ (Set.range (thresholdSource α lam))).topologicalClosure

/-- Real spectral L² sources are limits of linear combinations of threshold sources. -/
theorem spectralSource_mem_thresholdSourceSpace (α lam : ℝ) (u : SpectralL2 α lam) :
    spectralSource α lam u ∈ thresholdSourceSpace α lam := by
  let T : Submodule ℝ (SpectralL2 α lam) :=
    ((thresholdSourceSpace α lam).restrictScalars ℝ).comap (spectralSource α lam).toLinearMap
  have hT : IsClosed (T : Set (SpectralL2 α lam)) :=
    (Submodule.isClosed_topologicalClosure _).preimage (spectralSource α lam).continuous
  have hspan : Submodule.span ℝ (Set.range (thresholdL2 α lam)) ≤ T := by
    apply Submodule.span_le.mpr
    rintro _ ⟨E, rfl⟩
    change thresholdSource α lam E ∈ thresholdSourceSpace α lam
    exact Submodule.le_topologicalClosure _ (Submodule.subset_span ⟨E, rfl⟩)
  have htop : (Submodule.span ℝ (Set.range (thresholdL2 α lam))).topologicalClosure ≤ T :=
    Submodule.topologicalClosure_minimal _ hspan hT
  rw [thresholdL2_span_dense] at htop
  exact htop (Submodule.mem_top : u ∈ (⊤ : Submodule ℝ (SpectralL2 α lam)))

/-- Every polynomial source power belongs to the all-threshold source span. -/
theorem powerSource_mem_thresholdSourceSpace (α lam : ℝ) (n : ℕ) :
    ((hOperator α (lam : ℂ)) ^ n) hilbertRoot ∈ thresholdSourceSpace α lam := by
  let f : C(MagneticRealSpectrum α lam, ℝ) :=
    ((ContinuousMap.id ℝ).restrict (spectrum ℝ (magneticAlgebraHamiltonian α lam))) ^ n
  have hmem := spectralSource_mem_thresholdSourceSpace α lam
    (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ f)
  rw [spectralSource_continuous] at hmem
  have hcfc : cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f =
      (magneticAlgebraHamiltonian α lam) ^ n := by
    dsimp only [f]
    rw [map_pow, cfcHom_id]
  change (((cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f :
    magneticAlgebra α) : MagneticBoundedOperator) hilbertRoot) ∈ _ at hmem
  rw [hcfc] at hmem
  have hpow : (((magneticAlgebraHamiltonian α lam) ^ n : magneticAlgebra α) : MagneticBoundedOperator) =
      (hOperator α (lam : ℂ)) ^ n := by
    simpa only [StarSubalgebra.subtype_apply, magneticAlgebraHamiltonian_coe] using
      map_pow (magneticAlgebra α).subtype (magneticAlgebraHamiltonian α lam) n
  rw [hpow] at hmem
  exact hmem

/-- The actual closed complex span of all lower-threshold
source vectors equals the independently defined closed polynomial cyclic space. -/
theorem thresholdSourceSpace_eq_cyclicSpace (α lam : ℝ) :
    thresholdSourceSpace α lam = cyclicSpace α lam := by
  apply le_antisymm
  · apply Submodule.topologicalClosure_minimal
    · apply Submodule.span_le.mpr
      rintro _ ⟨E, rfl⟩
      exact thresholdSource_mem_cyclic α lam E
    · exact cyclicSpace_isClosed α lam
  · apply Submodule.topologicalClosure_minimal
    · apply Submodule.span_le.mpr
      rintro _ ⟨n, rfl⟩
      exact powerSource_mem_thresholdSourceSpace α lam n
    · exact Submodule.isClosed_topologicalClosure _

end DTMAudit.FermiSpan

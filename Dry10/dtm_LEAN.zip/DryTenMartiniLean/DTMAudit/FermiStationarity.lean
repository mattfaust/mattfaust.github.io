import DTMAudit.Paired
import DTMAudit.TraceVectorization
import DTM.Background.Labels.MagneticProjectionContinuity

/-!
# Stationarity of the actual Fermi-projector source

The lower spectral projection is the existing CFC projection, with its trace
already identified as the IDS mass. Its source belongs to the independently
defined closed polynomial cyclic space. Thus its stationarity is proved, not
inserted as a hypothesis on a newly named projection.

This module treats cuts in the resolvent set. Arbitrary bounded Borel functions
on the spectrum and the full von Neumann trace completion require a separate
extension; none is silently supplied by the continuous functional calculus.
-/

noncomputable section
namespace DTMAudit.FermiStationarity
open CriticalDTM CriticalDTM.Chiral DTMAudit.Paired
open scoped ContinuousFunctionalCalculus

theorem polynomial_source_mem_cyclic (α lam : ℝ) (p : Polynomial ℝ) :
    Polynomial.aeval (hOperator α (lam : ℂ)) p hilbertRoot ∈ cyclicSpace α lam := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
      simpa using (cyclicSpace α lam).add_mem hp hq
  | monomial n r =>
      simpa [Polynomial.aeval_monomial, Algebra.smul_def,
        ContinuousLinearMap.mul_apply] using
        (cyclicSpace α lam).smul_mem (r : ℂ) (source_power_mem_cyclicSpace α lam n)

/-- Continuous functional calculus of the physical Hamiltonian preserves the
source cyclic space, by uniform polynomial approximation on its spectrum. -/
theorem cfc_source_mem_cyclic (α lam : ℝ) (f : ℝ → ℝ)
    (hf : ContinuousOn f (spectrum ℝ (hOperator α (lam : ℂ)))) :
    cfc f (hOperator α (lam : ℂ)) hilbertRoot ∈ cyclicSpace α lam := by
  change cfc f (hOperator α (lam : ℂ)) hilbertRoot ∈
    (cyclicSpace α lam : Set LatticeHilbert)
  rw [← (cyclicSpace_isClosed α lam).closure_eq]
  apply Metric.mem_closure_iff.mpr
  intro ε hε
  let H := hOperator α (lam : ℂ)
  let K := spectrum ℝ H
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation K (spectrum.isCompact H) f
    hf ε hε
  refine ⟨Polynomial.aeval H p hilbertRoot, polynomial_source_mem_cyclic α lam p, ?_⟩
  have happrox := norm_cfc_sub_polynomial_lt f K hf p ε hε hp H
    (hOperator_isSelfAdjoint α lam) Set.Subset.rfl
  calc
    dist (cfc f H hilbertRoot) (Polynomial.aeval H p hilbertRoot) =
        ‖(cfc f H - Polynomial.aeval H p) hilbertRoot‖ := by
          rw [dist_eq_norm, ContinuousLinearMap.sub_apply]
    _ ≤ ‖cfc f H - Polynomial.aeval H p‖ * ‖hilbertRoot‖ :=
      (cfc f H - Polynomial.aeval H p).le_opNorm hilbertRoot
    _ < ε := by simpa only [hilbertRoot_norm, mul_one] using happrox

end DTMAudit.FermiStationarity

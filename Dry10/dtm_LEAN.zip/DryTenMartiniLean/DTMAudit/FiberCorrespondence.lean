import DTMAudit.PhaseFourierUnitary
import DTMAudit.TraceVectorization
import DTM.Background.Realization.AMOMagneticMeasureBridge

/-!
# Actual polynomial origin columns and phase Fourier correspondence

The phase Hilbert space uses normalized Haar measure on `AddCircle 1`, with
`θ = 2πt`. This file identifies the completed root-trace space with that actual
Bochner L2 space by proving agreement on a dense core of paired magnetic and
original almost-Mathieu polynomial operators. Covariance is proved for those
families and gives the literal right-origin-column row. Both natural completed
multiplication actions agree with the original fiber formulas on this core.
The symmetric Fourier Hilbert basis is identified with the manuscript's explicit symmetric
phase-Fourier modes, including the radian-coordinate substitution.

The full phase Fourier and trace equivalences are unitary. Literal pointwise
fiber formulas in this file are statements on the proved dense polynomial core;
this file does not construct the algebra of all bounded measurable covariant
families or a general Borel functional calculus in that family realization.
-/

noncomputable section
set_option maxHeartbeats 800000
set_option linter.unnecessarySimpa false
namespace DTMAudit.FiberCorrespondence
open CriticalDTM PhaseFourier PhaseCoordinates MeasureTheory

abbrev phaseMeasure := @AddCircle.haarAddCircle 1 inferInstance

end DTMAudit.FiberCorrespondence

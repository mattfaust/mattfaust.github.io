import DTMAudit.SpectralSources

/-!
# Actual whole-space Fermi projections at every real cut

For every real E, take the orthogonal projection onto the closed range of the
continuous functional calculus of x ↦ max (E - x) 0. This acts on the entire
magnetic lattice Hilbert space, is self-adjoint and idempotent, and commutes
with both magnetic actions. All these cut projections commute with one another and are nested with the
cut. Their differences give actual half-open finite-interval projections.

The rational continuous cutoffs w / (w + 1/(n+1)) converge in the actual spectral
L² space to the strict lower-set indicator. The residual identity
w * (1 - g_n) = (1/(n+1)) * g_n then identifies the whole-space projection's
root vector with the independently constructed threshold source. Thus its
trace is the actual IDS at every real threshold, including spectral cuts.
At resolvent cuts the operator equals the existing continuous-CFC projection.

This module does not construct a countably additive PVM on arbitrary Borel
sets or a functional calculus for all bounded Borel functions. Those are
additional operator-level extensions, not implicit consequences claimed here.
-/

set_option autoImplicit false

noncomputable section
namespace DTMAudit.FullFermiProjection
open CriticalDTM Set
open scoped ContinuousFunctionalCalculus

abbrev Op := MagneticBoundedOperator
abbrev Hilbert := MagneticHilbert

/-- The support space of a bounded operator on the full magnetic Hilbert space. -/
def supportSpace (A : Op) : Submodule ℂ Hilbert :=
  (LinearMap.range A.toLinearMap).topologicalClosure

instance supportSpace_complete (A : Op) : CompleteSpace (supportSpace A) := by
  unfold supportSpace
  infer_instance

/-- A genuine bounded orthogonal projection acting on every lattice vector. -/
def supportProjection (A : Op) : Op :=
  (supportSpace A).subtypeL.comp (supportSpace A).orthogonalProjection

theorem supportSpace_invariant (A B : Op) (hAB : Commute A B) :
    Set.MapsTo B (supportSpace A) (supportSpace A) := by
  have hr : Set.MapsTo B (LinearMap.range A.toLinearMap) (LinearMap.range A.toLinearMap) := by
    rintro _ ⟨u, rfl⟩
    exact ⟨B u, (congrArg (fun T : Op => T u) hAB.eq)⟩
  exact hr.closure B.continuous

theorem orthogonal_invariant (K : Submodule ℂ Hilbert) (B : Op)
    (hB : IsSelfAdjoint B) (hK : Set.MapsTo B K K) :
    Set.MapsTo B Kᗮ Kᗮ := by
  intro u hu v hv
  rw [← hB.isSymmetric.apply_clm]
  exact hu (B v) (hK hv)

theorem supportProjection_commute (A B : Op) (hAB : Commute A B)
    (hB : IsSelfAdjoint B) : Commute (supportProjection A) B := by
  change supportProjection A * B = B * supportProjection A
  apply ContinuousLinearMap.ext
  intro u
  change ((supportSpace A).orthogonalProjection (B u) : Hilbert) =
    B ((supportSpace A).orthogonalProjection u)
  apply (supportSpace A).eq_orthogonalProjection_of_mem_orthogonal
  · exact supportSpace_invariant A B hAB ((supportSpace A).orthogonalProjection u).property
  · rw [← map_sub]
    exact orthogonal_invariant (supportSpace A) B hB (supportSpace_invariant A B hAB)
      ((supportSpace A).sub_orthogonalProjection_mem_orthogonal u)

def cutWeight (E x : ℝ) : ℝ := max (E - x) 0

theorem cutWeight_continuous (E : ℝ) : Continuous (cutWeight E) :=
  (continuous_const.sub continuous_id).max continuous_const

def cutWeightOperator (α lam E : ℝ) : Op :=
  cfc (cutWeight E) (hOperator α (lam : ℂ))

/-- The strict lower spectral cut, realized on the entire magnetic lattice. -/
def lowerProjection (α lam E : ℝ) : Op :=
  supportProjection (cutWeightOperator α lam E)

theorem cutWeightOperator_commute_h (α lam E : ℝ) :
    Commute (cutWeightOperator α lam E) (hOperator α (lam : ℂ)) := by
  have h := cfc_commute_cfc (cutWeight E) (id : ℝ → ℝ) (hOperator α (lam : ℂ))
  simpa only [cfc_id ℝ (hOperator α (lam : ℂ)) (hOperator_isSelfAdjoint α lam), cutWeightOperator] using h

theorem lowerProjection_commute_h (α lam E : ℝ) :
    Commute (lowerProjection α lam E) (hOperator α (lam : ℂ)) :=
  supportProjection_commute _ _ (cutWeightOperator_commute_h α lam E)
    (hOperator_isSelfAdjoint α lam)

local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)

local instance spectralCompactSpace (α lam : ℝ) : CompactSpace (MagneticRealSpectrum α lam) :=
  isCompact_iff_compactSpace.mp (spectrum.isCompact (magneticAlgebraHamiltonian α lam))

theorem cutWeightOperator_mem_algebra (α lam E : ℝ) :
    cutWeightOperator α lam E ∈ magneticAlgebra α := by
  unfold cutWeightOperator
  rw [← magneticAlgebraHamiltonian_cfc_coe α lam _ (cutWeight_continuous E)]
  exact Subtype.property _

theorem lowerProjection_commute_conjugate (α lam E : ℝ) :
    Commute (lowerProjection α lam E) (conjugateOperator α (lam : ℂ)) := by
  apply supportProjection_commute
  · exact TraceVectorization.closure_conjugate_commute α (lam : ℂ)
      (cutWeightOperator_mem_algebra α lam E)
  · exact conjugateOperator_isSelfAdjoint α lam

def spectralOperator (α lam : ℝ) : C(MagneticRealSpectrum α lam, ℝ) →+* Op :=
  (magneticAlgebra α).subtype.toRingHom.comp
    (cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam)).toRingHom

def cutWeightOnSpectrum (α lam E : ℝ) : C(MagneticRealSpectrum α lam, ℝ) :=
  ⟨fun x => cutWeight E x, (cutWeight_continuous E).comp continuous_subtype_val⟩

theorem cutWeightOperator_eq_spectralOperator (α lam E : ℝ) :
    cutWeightOperator α lam E = spectralOperator α lam (cutWeightOnSpectrum α lam E) := by
  unfold cutWeightOperator
  rw [← magneticAlgebraHamiltonian_cfc_coe α lam _ (cutWeight_continuous E)]
  rw [cfc_apply (cutWeight E) (magneticAlgebraHamiltonian α lam)
    (magneticAlgebraHamiltonian_isSelfAdjoint α lam) (cutWeight_continuous E).continuousOn]
  rfl

open SpectralSources MeasureTheory Filter
open scoped Topology

def regularizer (n : ℕ) : ℝ := 1 / ((n : ℝ) + 1)

theorem regularizer_pos (n : ℕ) : 0 < regularizer n := by
  unfold regularizer
  positivity

def inverseRegularizedWeight (α lam E : ℝ) (n : ℕ) : C(MagneticRealSpectrum α lam, ℝ) :=
  ⟨fun x => (cutWeight E x + regularizer n)⁻¹,
    ((cutWeightOnSpectrum α lam E).continuous.add continuous_const).inv₀ (fun _ =>
      ne_of_gt (add_pos_of_nonneg_of_pos (le_max_right _ _) (regularizer_pos n)))⟩

def cutoffApprox (α lam E : ℝ) (n : ℕ) : C(MagneticRealSpectrum α lam, ℝ) :=
  cutWeightOnSpectrum α lam E * inverseRegularizedWeight α lam E n

theorem cutoffApprox_apply (α lam E : ℝ) (n : ℕ) (x : MagneticRealSpectrum α lam) :
    cutoffApprox α lam E n x = cutWeight E x / (cutWeight E x + regularizer n) := by
  rfl

theorem cutoffApprox_bounds (α lam E : ℝ) (n : ℕ) (x : MagneticRealSpectrum α lam) :
    0 ≤ cutoffApprox α lam E n x ∧ cutoffApprox α lam E n x ≤ 1 := by
  rw [cutoffApprox_apply]
  have hw : 0 ≤ cutWeight E x := le_max_right _ _
  have he := regularizer_pos n
  exact ⟨div_nonneg hw (by positivity), (div_le_one (by positivity)).mpr (by linarith)⟩

theorem cutoffApprox_tendsto (α lam E : ℝ) (x : MagneticRealSpectrum α lam) :
    Tendsto (fun n => cutoffApprox α lam E n x) atTop
      (𝓝 ((magneticLowerSpectrum α lam E).indicator (fun _ => (1 : ℝ)) x)) := by
  simp only [cutoffApprox_apply]
  by_cases hx : x.val < E
  · have hw : cutWeight E x ≠ 0 := ne_of_gt (lt_max_of_lt_left (sub_pos.mpr hx))
    have ht := (tendsto_const_nhds (x := cutWeight E x)).div
      (tendsto_const_nhds.add tendsto_one_div_add_atTop_nhds_zero_nat) (by simpa using hw)
    simpa only [regularizer, add_zero, div_self hw,
      Set.indicator_of_mem (show x ∈ magneticLowerSpectrum α lam E from hx)] using ht
  · have hw : cutWeight E x = 0 := max_eq_right (sub_nonpos.mpr (not_lt.mp hx))
    simpa only [hw, zero_div,
      Set.indicator_of_not_mem (show x ∉ magneticLowerSpectrum α lam E from hx)] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℝ)) atTop (𝓝 0))

theorem cutoffApprox_L2_tendsto (α lam E : ℝ) :
    Tendsto (fun n => ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ
      (cutoffApprox α lam E n)) atTop (𝓝 (thresholdL2 α lam E)) := by
  let μ := magneticSpectralMeasure α lam
  let χ := (magneticLowerSpectrum α lam E).indicator (fun _ => (1 : ℝ))
  let f := fun n => ContinuousMap.toLp 2 μ ℝ (cutoffApprox α lam E n)
  have hχ : Measurable χ := measurable_const.indicator (lowerSpectrum_measurable α lam E)
  have hi : (thresholdL2 α lam E : MagneticRealSpectrum α lam → ℝ) =ᵐ[μ] χ :=
    indicatorConstLp_coeFn
  have hnorm (n : ℕ) : ‖f n - thresholdL2 α lam E‖ ^ 2 =
      ∫ x, (cutoffApprox α lam E n x - χ x) ^ 2 ∂μ := by
    rw [← real_inner_self_eq_norm_sq, L2.inner_def]
    apply integral_congr_ae
    filter_upwards [Lp.coeFn_sub (f n) (thresholdL2 α lam E), hi,
      ContinuousMap.coeFn_toLp (𝕜 := ℝ) (p := 2) μ (cutoffApprox α lam E n)] with x hs hx hf
    simp only [hs, Pi.sub_apply, f, hf, hx, real_inner_comm, RCLike.inner_apply,
      starRingEnd_apply, star_trivial, sq]
  have ht : Tendsto (fun n => ∫ x, (cutoffApprox α lam E n x - χ x) ^ 2 ∂μ)
      atTop (𝓝 0) := by
    have h := tendsto_integral_of_dominated_convergence (μ := μ) (fun _ => (1 : ℝ))
      (F := fun n x => (cutoffApprox α lam E n x - χ x) ^ 2) (f := fun _ => (0 : ℝ))
      (fun n => (((cutoffApprox α lam E n).continuous.measurable.sub hχ).pow_const 2).aestronglyMeasurable)
      (integrable_const 1) (fun n => Filter.Eventually.of_forall (fun x => by
        have hb := cutoffApprox_bounds α lam E n x
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        by_cases hx : x ∈ magneticLowerSpectrum α lam E
        · simp only [χ, Set.indicator_of_mem hx]
          nlinarith [sq_nonneg (cutoffApprox α lam E n x)]
        · simp only [χ, Set.indicator_of_not_mem hx, sub_zero]
          nlinarith))
      (Filter.Eventually.of_forall (fun x => by
        have hx := ((cutoffApprox_tendsto α lam E x).sub
          (tendsto_const_nhds (x := χ x))).pow 2
        simpa only [χ, sub_self, zero_pow (by decide : 2 ≠ 0)] using hx))
    simpa only [integral_zero] using h
  have hs : Tendsto (fun n => ‖f n - thresholdL2 α lam E‖ ^ 2) atTop (𝓝 0) := by
    simpa only [hnorm] using ht
  have hn := (Real.continuous_sqrt.tendsto 0).comp hs
  rw [tendsto_iff_norm_sub_tendsto_zero]
  simpa only [Function.comp_def, Real.sqrt_sq_eq_abs, abs_norm, Real.sqrt_zero, f] using hn

theorem continuousSource_mul (α lam : ℝ) (f g : C(MagneticRealSpectrum α lam, ℝ)) :
    spectralOperator α lam f (continuousSource α lam g) = continuousSource α lam (f * g) := by
  change (spectralOperator α lam f * spectralOperator α lam g) hilbertRoot =
    spectralOperator α lam (f * g) hilbertRoot
  rw [map_mul]

theorem cutoffApprox_source_tendsto (α lam E : ℝ) :
    Tendsto (fun n => continuousSource α lam (cutoffApprox α lam E n)) atTop
      (𝓝 (thresholdSource α lam E)) := by
  have h := ((spectralSource α lam).continuous.tendsto (thresholdL2 α lam E)).comp
    (cutoffApprox_L2_tendsto α lam E)
  simpa only [Function.comp_def, spectralSource_continuous, thresholdSource] using h

theorem cutoffApprox_source_mem_support (α lam E : ℝ) (n : ℕ) :
    continuousSource α lam (cutoffApprox α lam E n) ∈ supportSpace (cutWeightOperator α lam E) := by
  apply (LinearMap.range (cutWeightOperator α lam E).toLinearMap).le_topologicalClosure
  refine ⟨continuousSource α lam (inverseRegularizedWeight α lam E n), ?_⟩
  change cutWeightOperator α lam E (continuousSource α lam (inverseRegularizedWeight α lam E n)) = _
  rw [cutWeightOperator_eq_spectralOperator, continuousSource_mul]
  rfl

theorem thresholdSource_mem_support (α lam E : ℝ) :
    thresholdSource α lam E ∈ supportSpace (cutWeightOperator α lam E) :=
  (LinearMap.range (cutWeightOperator α lam E).toLinearMap).isClosed_topologicalClosure.mem_of_tendsto
    (cutoffApprox_source_tendsto α lam E)
    (Filter.Eventually.of_forall (cutoffApprox_source_mem_support α lam E))

theorem cutoffApprox_residual (α lam E : ℝ) (n : ℕ) :
    cutWeightOnSpectrum α lam E - cutWeightOnSpectrum α lam E * cutoffApprox α lam E n =
      regularizer n • cutoffApprox α lam E n := by
  ext x
  change cutWeight E x - cutWeight E x * cutoffApprox α lam E n x =
    regularizer n * cutoffApprox α lam E n x
  rw [cutoffApprox_apply]
  have hn : cutWeight E x + regularizer n ≠ 0 :=
    ne_of_gt (add_pos_of_nonneg_of_pos (le_max_right _ _) (regularizer_pos n))
  field_simp
  ring

theorem cutoffApprox_source_residual (α lam E : ℝ) (n : ℕ) :
    cutWeightOperator α lam E (hilbertRoot - continuousSource α lam (cutoffApprox α lam E n)) =
      regularizer n • continuousSource α lam (cutoffApprox α lam E n) := by
  rw [map_sub, cutWeightOperator_eq_spectralOperator, continuousSource_mul]
  change continuousSource α lam (cutWeightOnSpectrum α lam E) -
      continuousSource α lam (cutWeightOnSpectrum α lam E * cutoffApprox α lam E n) = _
  rw [← map_sub, cutoffApprox_residual, map_smul]

theorem thresholdSource_residual_ker (α lam E : ℝ) :
    cutWeightOperator α lam E (hilbertRoot - thresholdSource α lam E) = 0 := by
  have hsource := cutoffApprox_source_tendsto α lam E
  have hl := ((cutWeightOperator α lam E).continuous.tendsto _).comp
    ((tendsto_const_nhds (x := hilbertRoot)).sub hsource)
  have hr := tendsto_one_div_add_atTop_nhds_zero_nat.smul hsource
  have hr' : Tendsto (fun n => cutWeightOperator α lam E
      (hilbertRoot - continuousSource α lam (cutoffApprox α lam E n))) atTop (𝓝 0) := by
    simpa only [cutoffApprox_source_residual, regularizer, zero_smul] using hr
  exact tendsto_nhds_unique hl hr'

theorem ker_mem_support_orthogonal (A : Op) (hA : IsSelfAdjoint A) {u : Hilbert} (hu : A u = 0) :
    u ∈ (supportSpace A)ᗮ := by
  have h : ∀ v ∈ supportSpace A, @inner ℂ Hilbert _ v u = 0 := by
    apply closure_minimal
    · rintro _ ⟨v, rfl⟩
      change @inner ℂ Hilbert _ (A v) u = 0
      rw [hA.isSymmetric.apply_clm, hu, inner_zero_right]
    · exact isClosed_eq (continuous_id.inner continuous_const) continuous_const
  exact h

/-- Every real threshold has the previously constructed IDS source as its actual projection root. -/
theorem lowerProjection_root (α lam E : ℝ) :
    lowerProjection α lam E hilbertRoot = thresholdSource α lam E := by
  apply (supportSpace (cutWeightOperator α lam E)).eq_orthogonalProjection_of_mem_orthogonal
  · exact thresholdSource_mem_support α lam E
  · exact ker_mem_support_orthogonal _ (cfc_predicate _ _)
      (thresholdSource_residual_ker α lam E)

end DTMAudit.FullFermiProjection

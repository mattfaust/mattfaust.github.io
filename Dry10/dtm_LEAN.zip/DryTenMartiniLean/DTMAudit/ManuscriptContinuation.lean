import DTMAudit.ManuscriptRieszContinuity
import DTMAudit.ManuscriptPotential
import DTMAudit.ManuscriptCouplingSelected
import DTMAudit.ManuscriptSignDuality
import DTM.Background.IndependentSeeds.AMOCosineSeed
import DTM.Background.AllCouplingExtension.AMOAubryDuality
import DTMMinimal.Statement

/-! # Compact continuation of the manuscript's literal logarithmic height

The response interface below is discharged by the manuscript's positive-square
trace derivative and direct lattice commutator calculation in the final endpoint
module. The potential, initial selected energy, label continuity,
and compact stationary-set argument are instantiated here with their actual
physical definitions.
-/
noncomputable section
namespace DTMAudit.ManuscriptContinuation
open CriticalDTM Set Filter
open scoped Topology

/-- A local interface, proved for the physical family before final use. -/
def StationaryHeightMonotonicity (α : ℝ) : Prop :=
  ∀ (energy velocity : ℝ → ℝ) (s : Set ℝ),
    IsOpen s → Convex ℝ s →
    (∀ t ∈ s, 0 < t) →
    (∀ t ∈ s, (energy t : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ))) →
    (∀ t ∈ s, projectedGreen (hOperator α (t : ℂ)) hilbertRoot (energy t : ℂ) = 0) →
    (∀ t ∈ s, HasDerivAt energy (velocity t) t) →
    (∀ t ∈ s, ContinuousAt velocity t) →
    MonotoneOn (fun t => magneticLogPotential α t (energy t)) s

theorem magneticStationarySuperlevel_right_extension
    {α : ℝ} (hmonotone : StationaryHeightMonotonicity α) (L N : ℝ × ℝ → ℝ)
    {label c s target : ℝ} (hs : 0 < s) (htarget : target ≤ 1)
    (hinterior : label ∈ Ioo (0 : ℝ) 1)
    (hlocal : JointResolventLabelLocallyConstant α N)
    (hexterior : ∀ t ∈ Icc s target,
      HasExteriorLabels (magneticRealSpectrumSet α t) (fun E => N (t, E)))
    (hagree : ∀ t ∈ Icc s target, ∀ E : ℝ,
      (E : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) →
        L (t, E) = magneticLogPotential α t E)
    {p : ℝ × ℝ} (hp : p ∈ magneticStationarySuperlevel α L N label c s target)
    (hpt : p.1 < target) :
    ∃ q ∈ magneticStationarySuperlevel α L N label c s target, p.1 < q.1 := by
  have hp0 : 0 < p.1 := hs.trans_le hp.1.1
  have hstationary := hp.2.2.1
  /- The local right-extension step uses the proved C1 Green-zero branch. Its derivative
  and continuity are proved in BranchRegularity; no analytic branch or
  already continued gap is supplied as a hypothesis. -/
  obtain ⟨e, d, he, hecont, _, _, hnear⟩ :=
    magnetic_green_local_c1_zero_branch α p.1 p.2 hstationary.1 hstationary.2.1
  have hgraph : Tendsto (fun t => (t, e t)) (𝓝 p.1) (𝓝 p) := by
    simpa only [id_eq, he, Prod.mk.eta] using (continuousAt_id.prodMk hecont).tendsto
  have hlabels : ∀ᶠ t in 𝓝 p.1, N (t, e t) = label := by
    filter_upwards [hgraph.eventually (hlocal p hstationary.1)] with t ht
    exact ht.trans hstationary.2.2
  obtain ⟨epsilon, hepsilon, hball⟩ := Metric.mem_nhds_iff.mp
    ((lt_mem_nhds hp0).and (hnear.and hlabels))
  /- The local right-extension step invokes the actual stationary path derivative and weighted
  magnetic sign supplied by the physical response interface, then the ordinary mean-value theorem.
  The conclusion is monotonicity of height, not of its derivative. -/
  have hmono : MonotoneOn (fun t => magneticLogPotential α t (e t))
      (Metric.ball p.1 epsilon) :=
    hmonotone e d (Metric.ball p.1 epsilon)
      Metric.isOpen_ball (convex_ball p.1 epsilon)
      (fun _ ht => (hball ht).1) (fun _ ht => (hball ht).2.1.1)
      (fun _ ht => (hball ht).2.1.2.1) (fun _ ht => (hball ht).2.1.2.2.1)
      (fun _ ht => (hball ht).2.1.2.2.2)
  obtain ⟨t, hpt', htupper⟩ := exists_between
    (lt_min hpt (lt_add_of_pos_right p.1 hepsilon))
  have htball : t ∈ Metric.ball p.1 epsilon := by
    rw [Metric.mem_ball, Real.dist_eq, abs_of_pos (sub_pos.mpr hpt')]
    linarith [(lt_min_iff.mp htupper).2]
  have ht : t ∈ Icc s target :=
    ⟨hp.1.1.trans hpt'.le, (lt_min_iff.mp htupper).1.le⟩
  have htstationary : IsLabelledMagneticStationaryPoint α N label t (e t) :=
    ⟨(hball htball).2.1.1, (hball htball).2.1.2.1, (hball htball).2.2⟩
  /- The local right-extension step checks the fixed energy box anew from the preserved interior
  label and exterior values; it is not assumed that a small local curve
  stays in the box merely because its initial point does. -/
  have htbound : e t ∈ Icc (-4 : ℝ) 4 :=
    magnetic_resolvent_energy_bound_of_interior_label α (fun E => N (t, E))
      (hs.le.trans ht.1) (ht.2.trans htarget) (hexterior t ht)
      htstationary.1 htstationary.2.2 hinterior
  /- The local right-extension step transfers the actual logarithmic-potential comparison back
  to the generic L using resolvent agreement at the old and new points. -/
  have hheight : c ≤ L (t, e t) := calc
    c ≤ L p := hp.2.2.2
    _ = magneticLogPotential α p.1 (e p.1) := by
      simpa only [he, Prod.mk.eta] using hagree p.1 hp.1 p.2 hstationary.1
    _ ≤ magneticLogPotential α t (e t) :=
      hmono (Metric.mem_ball_self hepsilon) htball hpt'.le
    _ = L (t, e t) := (hagree t ht (e t) htstationary.1).symm
  exact ⟨(t, e t), ⟨ht, htbound, htstationary, hheight⟩, hpt'⟩

/-- A positive stationary seed reaches the target without assuming a
stationary branch, intermediate gaps, or uniqueness. This is the inner
continuation step; the next theorem obtains the positive seed from a gap. -/
/- Persistence from a seed, inner deduction. The seed supplies nonemptiness;
the stationary-superlevel lemma supplies compactness; the local branch supplies
right extension. The maximum-coordinate helper reaches the target while preserving the
seed height. There is no globally selected stationary curve. -/
theorem magnetic_stationary_point_at_target_of_positive_seed
    {α : ℝ} (hmonotone : StationaryHeightMonotonicity α) (L N : ℝ × ℝ → ℝ)
    {s target label m : ℝ} (hs : 0 < s) (hst : s < target) (htarget : target ≤ 1)
    (hinterior : label ∈ Ioo (0 : ℝ) 1)
    (hseed : IsLabelledMagneticStationaryPoint α N label s m)
    (hpositive : 0 < L (s, m)) (husc : UpperSemicontinuous L)
    (hzero : ∀ t ∈ Icc s target, ∀ E ∈ magneticRealSpectrumSet α t, L (t, E) = 0)
    (hagree : ∀ t ∈ Icc s target, ∀ E : ℝ,
      (E : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) →
        L (t, E) = magneticLogPotential α t E)
    (hlocal : JointResolventLabelLocallyConstant α N)
    (hexterior : ∀ t ∈ Icc s target,
      HasExteriorLabels (magneticRealSpectrumSet α t) (fun E => N (t, E))) :
    ∃ E : ℝ, IsLabelledMagneticStationaryPoint α N label target E ∧
      L (s, m) ≤ L (target, E) := by
  let S := magneticStationarySuperlevel α L N label (L (s, m)) s target
  have hsI : s ∈ Icc s target := ⟨le_rfl, hst.le⟩
  have hm : m ∈ Icc (-4 : ℝ) 4 :=
    magnetic_resolvent_energy_bound_of_interior_label α (fun E => N (s, E))
      hs.le (hst.le.trans htarget) (hexterior s hsI) hseed.1 hseed.2.2 hinterior
  have hne : S.Nonempty := ⟨(s, m), ⟨hsI, hm, hseed, le_rfl⟩⟩
  have hcompact : IsCompact S := magneticStationarySuperlevel_isCompact
    α L N label (L (s, m)) s target hpositive husc hzero hlocal
  /- Persistence from the positive seed is concluded by maximizing coupling on the superlevel,
  not by gluing the local implicit branches into a global one. -/
  obtain ⟨E, hE⟩ := compact_coupling_reaches_target hcompact hne
    (fun _ hp => hp.1.2)
    (fun _ hp hpt => magneticStationarySuperlevel_right_extension
      hmonotone L N hs htarget hinterior hlocal hexterior hagree hp hpt)
  exact ⟨E, hE.2.2⟩

/-- The positive seed is the literal DOS maximum of the actual bounded gap. -/
theorem magnetic_labelled_gap_persists_from_one_seed
    {α : ℝ} (hα : Irrational α) (hmonotone : StationaryHeightMonotonicity α)
    {s target label : ℝ} (hs : 0 < s) (hst : s < target) (htarget : target ≤ 1)
    (hlabel : label ∈ Ioo (0 : ℝ) 1)
    (hseed : ∃ a b : ℝ, IsLabelledSpectralGap (magneticRealSpectrumSet α s)
      (magneticLowerMass α s) label a b) :
    ∃ a b : ℝ, IsLabelledSpectralGap (magneticRealSpectrumSet α target)
      (magneticLowerMass α target) label a b := by
  obtain ⟨a, b, hgap⟩ := hseed
  obtain ⟨m, hm, hpositive, hzero, _⟩ :=
    ManuscriptCouplingSelected.selected_gap_energy hα hs hgap.1
  have hmres := spectrum.not_mem_iff.mp (hgap.1.interior_avoids hm)
  have hseedpoint : IsLabelledMagneticStationaryPoint α
      (fun p => magneticLowerMass α p.1 p.2) label s m :=
    ⟨hmres, hzero, hgap.2 m hm⟩
  have hpos : 0 < ManuscriptPotential.height α (s, m) :=
    lt_of_le_of_lt (le_max_left 0 (Real.log s)) hpositive
  have hvanish : ∀ t ∈ Icc s target, ∀ E ∈ magneticRealSpectrumSet α t,
      ManuscriptPotential.height α (t, E) = 0 := by
    intro t ht E hE
    rw [ManuscriptPotential.height_spectral_value hα (hs.trans_le ht.1) E hE,
      max_eq_left (Real.log_nonpos (hs.le.trans ht.1) (ht.2.trans htarget))]
  obtain ⟨E, hE, _⟩ := magnetic_stationary_point_at_target_of_positive_seed
    hmonotone (ManuscriptPotential.height α) (fun p => magneticLowerMass α p.1 p.2)
    hs hst htarget hlabel hseedpoint hpos
    (ManuscriptPotential.height_upperSemicontinuous α) hvanish
    (fun t _ E hE => ManuscriptPotential.height_eq_magneticLogPotential α t E hE)
    (ManuscriptRieszContinuity.lowerMass_joint_label_locallyConstant α)
    (fun t _ => magneticLowerMass_hasExteriorLabels α t)
  have hlocal : LocallyConstantOff (magneticRealSpectrumSet α target)
      (magneticLowerMass α target) := by
    intro x hx
    exact (continuousAt_const.prodMk continuousAt_id).eventually
      (ManuscriptRieszContinuity.lowerMass_joint_label_locallyConstant α
        (target, x) (spectrum.not_mem_iff.mp hx))
  obtain ⟨a', b', hgap', _, hlabel'⟩ := exists_labelled_spectral_gap
    (magneticRealSpectrumSet_isClosed α target) hlocal
    (magneticLowerMass_hasExteriorLabels α target) (spectrum.not_mem_iff.mpr hE.1)
    hE.2.2 hlabel
  exact ⟨a', b', hgap', hlabel'⟩

theorem amo_labelled_gap_persists_from_one_seed
    {α : ℝ} (hα : Irrational α) (hmonotone : StationaryHeightMonotonicity α) {s target label θ₀ : ℝ}
    (hs : 0 < s) (hst : s < target) (htarget : target ≤ 1)
    (hlabel : label ∈ Ioo (0 : ℝ) 1)
    (hseed : ∃ a b : ℝ, IsLabelledSpectralGap
      (almostMathieuRealSpectrumSet α s θ₀) (almostMathieuIDS α s) label a b) :
    ∀ θ : ℝ, ∃ a b : ℝ, IsLabelledSpectralGap
      (almostMathieuRealSpectrumSet α target θ) (almostMathieuIDS α target) label a b := by
  have hIDS (lam : ℝ) : almostMathieuIDS α lam = magneticLowerMass α lam :=
    (funext (magneticLowerMass_eq_almostMathieuIDS α lam)).symm
  have hseedM : ∃ a b : ℝ, IsLabelledSpectralGap
      (magneticRealSpectrumSet α s) (magneticLowerMass α s) label a b := by
    simpa only [almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα, hIDS] using hseed
  obtain ⟨a, b, hgap⟩ := magnetic_labelled_gap_persists_from_one_seed
    hα hmonotone hs hst htarget hlabel hseedM
  intro θ
  refine ⟨a, b, ?_⟩
  simpa only [almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα, hIDS] using hgap

/-- The independently constructed small seeds start the source-response argument. -/
theorem subcritical_and_critical {α : ℝ} (hα : Irrational α) (hmonotone : StationaryHeightMonotonicity α)
    (lam : ℝ) (hlam : 0 < lam) (hle : lam ≤ 1) : AMODryTenMartini α lam := by
  intro θ n hn
  obtain ⟨s, hs, hslam, θ₀, a, b, hgap⟩ :=
    amo_arbitrarily_small_labelled_seeds hα n hn lam hlam
  exact amo_labelled_gap_persists_from_one_seed hα hmonotone hs hslam hle
    (arithmeticGapLabel_mem_Ioo hα hn) ⟨a, b, hgap⟩ θ

/-- Actual Aubry scaling extends this proof to every positive coupling. -/
theorem all_positive {α : ℝ} (hα : Irrational α) (hmonotone : StationaryHeightMonotonicity α)
    (lam : ℝ) (hlam : 0 < lam) : AMODryTenMartini α lam :=
  amo_all_positive_of_subcritical_and_critical hα (subcritical_and_critical hα hmonotone) lam hlam

/-- The human proof's actual lattice sign involution handles negative coupling. -/
theorem all_nonzero {α : ℝ} (hα : Irrational α)
    (hmonotone : StationaryHeightMonotonicity α) (lam : ℝ) (hlam : lam ≠ 0) :
    AMODryTenMartini α lam := by
  rcases lt_or_gt_of_ne hlam with hneg | hpos
  · intro θ n hn
    obtain ⟨a, b, hgap⟩ := all_positive hα hmonotone (-lam) (neg_pos.mpr hneg) 0 n hn
    exact ⟨a, b, (ManuscriptSignDuality.amo_labelled_gap_iff hα lam θ 0
      (arithmeticGapLabel α n) a b).mpr hgap⟩
  · exact all_positive hα hmonotone lam hpos

/-- The independent public specification has no response, height, seed,
or branch assumption after the final physical monotonicity adapter. -/
theorem nonzero_statement
    (hmonotone : ∀ α : ℝ, Irrational α → StationaryHeightMonotonicity α) :
    DTMMinimal.statement_nonzero := by
  intro α hα
  refine ⟨CriticalDTM.almostMathieuOperator α,
    CriticalDTM.almostMathieuOperator_apply α, ?_⟩
  dsimp only
  intro lam hlam n hn
  obtain ⟨a, b, hgap⟩ := all_nonzero hα (hmonotone α hα) lam hlam 0 n hn
  refine ⟨a, b, hgap.1.endpoints_ordered, ?_⟩
  intro θ
  have hphase := CriticalDTM.almostMathieuOperator_spectrum_phase_independent hα lam θ 0
  refine ⟨?_, ?_, ?_⟩
  · rw [hphase]
    exact hgap.1.left_mem
  · rw [hphase]
    exact hgap.1.right_mem
  intro E hEa hEb
  have hE : (E : ℂ) ∉ spectrum ℂ (CriticalDTM.almostMathieuOperator α lam θ) := by
    rw [hphase]
    exact hgap.1.interior_avoids ⟨hEa, hEb⟩
  refine ⟨hE, ?_⟩
  have hlabel : CriticalDTM.almostMathieuIDS α lam E = Int.fract ((n : ℝ) * α) :=
    hgap.2 E ⟨hEa, hEb⟩
  rw [← hlabel]
  exact CriticalDTM.tendsto_amoFinite_charpoly_count hα lam θ E hE

end DTMAudit.ManuscriptContinuation

import DTM.Background.Support.MagneticIntegralBridge
import DTM.Background.Labels.MagneticGapProjection
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.MeasureTheory.Function.LocallyIntegrable

/-!
# Direct DOS differentiation in the manuscript

This file differentiates the scalar DOS integral in the energy variable.
The proof uses differentiation under the integral sign.
-/

noncomputable section
namespace DTMAudit.ManuscriptCouplingEnergy
open CriticalDTM MeasureTheory Filter Set
open scoped Topology

/-- The positive distance used to differentiate the scalar logarithm locally
comes from the actual physical resolvent set. -/
theorem spectral_separation (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    ∃ δ > 0, ∀ x : MagneticRealSpectrum α lam, δ ≤ |E - (x : ℝ)| := by
  have hopen := (spectrum.isClosed (𝕜 := ℝ) (magneticAlgebraHamiltonian α lam)).isOpen_compl
  obtain ⟨δ, hδ, hball⟩ := Metric.isOpen_iff.mp hopen E
    (resolvent_energy_not_mem_magneticRealSpectrum α lam E hE)
  refine ⟨δ, hδ, fun x => ?_⟩
  by_contra hx
  have hmem : (x : ℝ) ∈ Metric.ball E δ := by
    simpa only [Metric.mem_ball, Real.dist_eq, abs_sub_comm] using lt_of_not_ge hx
  exact hball hmem x.property

/-- Direct differentiation under the DOS integral, justified by a uniform
spectral gap and the scalar logarithm derivative. -/
theorem dos_log_energy_hasDerivAt (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    HasDerivAt (fun t : ℝ => ∫ x : ℝ, Real.log |t - x|
      ∂magneticRealSpectralMeasure α lam)
      (realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot E) E := by
  obtain ⟨δ, hδ, hsep⟩ := spectral_separation α lam E hE
  have hnear (t : ℝ) (ht : t ∈ Metric.ball E (δ / 2))
      (x : MagneticRealSpectrum α lam) : δ / 2 < |t - (x : ℝ)| := by
    have ht' : |E - t| < δ / 2 := by
      simpa only [Metric.mem_ball, Real.dist_eq, abs_sub_comm] using ht
    have htri := abs_sub_le E t (x : ℝ)
    linarith [hsep x]
  have hne (t : ℝ) (ht : t ∈ Metric.ball E (δ / 2))
      (x : MagneticRealSpectrum α lam) : t - (x : ℝ) ≠ 0 :=
    abs_pos.mp (lt_trans (half_pos hδ) (hnear t ht x))
  have hint : Integrable (fun x : MagneticRealSpectrum α lam =>
      Real.log |E - (x : ℝ)|) (magneticSpectralMeasure α lam) :=
    (magnetic_log_kernel_continuous α lam E hE).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)
  have hderiv := (hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := magneticSpectralMeasure α lam)
    (F := fun t (x : MagneticRealSpectrum α lam) => Real.log |t - (x : ℝ)|)
    (F' := fun t (x : MagneticRealSpectrum α lam) => (t - (x : ℝ))⁻¹)
    (bound := fun _ => (δ / 2)⁻¹) (half_pos hδ)
    (Filter.Eventually.of_forall fun t => by
      exact (Real.measurable_log.comp
        ((continuous_const.sub continuous_subtype_val).abs.measurable)).aestronglyMeasurable)
    hint
    (magnetic_green_kernel_continuous α lam E hE).aestronglyMeasurable
    (ae_of_all _ fun x t ht => by
      rw [Real.norm_eq_abs, abs_inv]
      exact inv_anti₀ (half_pos hδ) (hnear t ht x).le)
    (integrable_const _)
    (ae_of_all _ fun x t ht => by
      simpa only [Real.log_abs, one_mul, id_eq, one_div] using
        ((hasDerivAt_id t).sub_const (x : ℝ)).log (hne t ht x))).2
  rw [← realProjectedGreen_eq_spectralIntegral α lam E hE] at hderiv
  have hfun : (fun t : ℝ => ∫ x : ℝ, Real.log |t - x|
      ∂magneticRealSpectralMeasure α lam) =
      (fun t : ℝ => ∫ x : MagneticRealSpectrum α lam,
        Real.log |t - (x : ℝ)| ∂magneticSpectralMeasure α lam) := by
    funext t
    exact magneticRealSpectralMeasure_integral_eq_subtype α lam _
  rw [hfun]
  exact hderiv

/-- Agreement with the repository's potential definition is used only as an
equality of functions near the energy, after the DOS derivative was proved. -/
theorem potential_energy_hasDerivAt (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    HasDerivAt (magneticLogPotential α lam)
      (realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot E) E := by
  apply (dos_log_energy_hasDerivAt α lam E hE).congr_of_eventuallyEq
  have hlocal : ∀ᶠ t : ℝ in 𝓝 E,
      (t : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) :=
    Complex.continuous_ofReal.continuousAt.preimage_mem_nhds
      ((spectrum.isOpen_resolventSet _).mem_nhds hE)
  filter_upwards [hlocal] with t ht
  exact magneticLogPotential_eq_realSpectralIntegral α lam t ht

end DTMAudit.ManuscriptCouplingEnergy

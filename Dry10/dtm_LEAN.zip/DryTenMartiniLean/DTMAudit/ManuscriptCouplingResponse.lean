import DTMAudit.ManuscriptPotential
import DTMAudit.ManuscriptTraceRiesz
import DTMAudit.ManuscriptLatticeResponse

/-! The manuscript's actual DOS-height derivative and magnetic-sector
response are combined only here, after both independent calculations. -/
noncomputable section
namespace DTMAudit.ManuscriptCouplingResponse
open CriticalDTM MeasureTheory Filter Set
open scoped InnerProductSpace Topology

-- Manuscript Theorem 4.1 and Theorem 3.6.
theorem height_path_formula {α : ℝ} (hα : Irrational α)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (energy lam : ℂ) = 0) :
    let height := fun l : ℝ => ManuscriptPotential.height α (l, energy l)
    let r := resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot
    HasDerivAt height (-(⟪r,verticalRoot⟫_ℂ).re) lam ∧
      lam * deriv height lam = (⟪r,r-Lz r⟫_ℂ).re / (2*‖r‖^2) ∧
      lam * deriv height lam ∈ Icc (0 : ℝ) 1 := by
  have hh := ManuscriptTraceRiesz.dos_height_stationary_path_hasDerivAt
    α energy velocity hU hlam he hd hE hzero
  dsimp only
  refine ⟨hh, ?_⟩
  simp only [ManuscriptPotential.height]
  rw [hh.deriv]
  exact ManuscriptLatticeResponse.insertion_response hα (hE lam hlam) hzero

/-- The logarithmic-potential name used by the continuation library denotes
the same DOS height on the actual resolvent neighborhood. -/
theorem potential_stationary_path_hasDerivAt {α : ℝ} (hα : Irrational α)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (energy lam : ℂ) = 0) :
    HasDerivAt (fun l => magneticLogPotential α l (energy l))
      (-(⟪resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot,
        verticalRoot⟫_ℂ).re) lam := by
  have _ := hα -- Retained in the public interface; the trace step itself needs no irrationality.
  have hh := ManuscriptTraceRiesz.dos_height_stationary_path_hasDerivAt
    α energy velocity hU hlam he hd hE hzero
  apply hh.congr_of_eventuallyEq
  filter_upwards [hU.mem_nhds hlam] with l hl
  exact (ManuscriptPotential.height_eq_magneticLogPotential α l (energy l) (hE l hl)).symm

/-- The exact physical monotonicity interface used in compact continuation.
Its sign comes from the actual R² test-vector magnetic balance, after the
canonical-trace/Riesz height derivative has identified the insertion. -/
theorem height_monotoneOn {α : ℝ} (hα : Irrational α)
    (energy velocity : ℝ → ℝ) (s : Set ℝ)
    (hs : IsOpen s) (hconv : Convex ℝ s)
    (hpositive : ∀ t ∈ s, 0 < t)
    (hres : ∀ t ∈ s, (energy t : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)))
    (hzero : ∀ t ∈ s, projectedGreen (hOperator α (t : ℂ)) hilbertRoot (energy t : ℂ) = 0)
    (he : ∀ t ∈ s, HasDerivAt energy (velocity t) t)
    (hv : ∀ t ∈ s, ContinuousAt velocity t) :
    MonotoneOn (fun t => magneticLogPotential α t (energy t)) s := by
  have hc : ContinuousOn velocity s := fun t ht => (hv t ht).continuousWithinAt
  have hd (t : ℝ) (ht : t ∈ s) :=
    potential_stationary_path_hasDerivAt hα energy velocity hs ht he hc hres (hzero t ht)
  apply monotoneOn_of_deriv_nonneg hconv
  · intro t ht
    exact (hd t ht).continuousAt.continuousWithinAt
  · intro t ht
    exact (hd t (interior_subset ht)).differentiableAt.differentiableWithinAt
  · intro t ht
    have ht' := interior_subset ht
    rw [(hd t ht').deriv]
    exact (mul_nonneg_iff_of_pos_left (hpositive t ht')).mp
      (ManuscriptLatticeResponse.insertion_response hα (hres t ht') (hzero t ht')).2.1

end DTMAudit.ManuscriptCouplingResponse

import DTMAudit.ManuscriptCouplingEnergy
import DTMAudit.RealThouless
import DTM.NewResults.Exposition.AnalyticBranch

/-!
# The selected gap energy, with direct DOS differentiation

The energy derivative supplied to strict concavity is the direct DOS
integral proof. Spectral normalization and real-energy continuity are the
external-input counterparts. The local analytic branch is the ordinary
resolvent implicit-function construction.
-/

noncomputable section
namespace DTMAudit.ManuscriptCouplingSelected
open CriticalDTM MeasureTheory Filter Set
open scoped Topology

/-- Every actual bounded AMO gap has a unique strict interior height maximum,
and its energy is characterized by the vanishing actual Green origin entry.
All positive couplings, including couplings greater than one, are retained. -/
theorem selected_gap_energy {α lam a b : ℝ} (hα : Irrational α) (hlam : 0 < lam)
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam) a b) :
    ∃ m ∈ Ioo a b,
      max 0 (Real.log lam) <
        (∫ x : ℝ, Real.log |m - x| ∂magneticRealSpectralMeasure α lam) ∧
      projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (m : ℂ) = 0 ∧
      IsMaxOn (fun E : ℝ => ∫ x : ℝ, Real.log |E - x|
        ∂magneticRealSpectralMeasure α lam) (Icc a b) m ∧
      (∀ E ∈ Icc a b, IsMaxOn (fun y : ℝ => ∫ x : ℝ, Real.log |y - x|
        ∂magneticRealSpectralMeasure α lam) (Icc a b) E → E = m) ∧
      (∀ E ∈ Ioo a b,
        projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (E : ℂ) = 0 → E = m) := by
  let L : ℝ → ℝ := fun E =>
    (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) -
      max 0 (Real.log lam)
  have hcont : ContinuousOn L (Icc a b) :=
    ((real_log_integral_continuous hα hlam).sub continuous_const).continuousOn
  have hboundary (E : ℝ) (hE : E ∈ magneticRealSpectrumSet α lam) : L E = 0 := by
    dsimp only [L]
    rw [← RealThouless.lyapunov_eq_log_integral,
      RealThouless.spectral_lyapunov_normalization hα hlam E hE, sub_self]
  have hderiv : ∀ E ∈ Ioo a b,
      HasDerivAt L (realProjectedGreen (hOperator α (lam : ℂ)) hilbertRoot E) E := by
    intro E hE
    exact (ManuscriptCouplingEnergy.dos_log_energy_hasDerivAt α lam E
      (spectrum.not_mem_iff.mp (hgap.interior_avoids hE))).sub_const _
  obtain ⟨m, hm, hpositive, hzero, hmax, hunique, hzeroUnique⟩ :=
    spectral_gap_unique_positive_maximum (hOperator α (lam : ℂ))
      (hOperator_isSelfAdjoint α lam) hilbertRoot hilbertRoot_ne_zero hgap L hcont
      (hboundary a hgap.left_mem) (hboundary b hgap.right_mem) hderiv
  refine ⟨m, hm, sub_pos.mp hpositive, hzero, ?_, ?_, hzeroUnique⟩
  · intro E hE
    have hh := hmax hE
    change L E ≤ L m at hh
    exact (sub_le_sub_iff_right _).mp hh
  · intro E hE hEmax
    apply hunique E hE
    intro y hy
    have hh := hEmax hy
    change (∫ x : ℝ, Real.log |y - x| ∂magneticRealSpectralMeasure α lam) ≤
      (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) at hh
    change L y ≤ L E
    exact sub_le_sub_right hh _

/-- The maximum furnished by direct DOS strict concavity has a locally real
analytic continuation, obtained from the actual Green function's analytic
implicit-function theorem. -/
-- Manuscript Lemma 3.4.
theorem selected_gap_energy_analytic_branch {α lam a b : ℝ}
    (hα : Irrational α) (hlam : 0 < lam)
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam) a b) :
    ∃ m ∈ Ioo a b, ∃ e : ℝ → ℝ,
      e lam = m ∧ AnalyticAt ℝ e lam ∧
      IsMaxOn (fun E : ℝ => ∫ x : ℝ, Real.log |E - x|
        ∂magneticRealSpectralMeasure α lam) (Icc a b) m ∧
      (∀ᶠ t : ℝ in 𝓝 lam,
        (e t : ℂ) ∈ resolventSet ℂ (hOperator α (t : ℂ)) ∧
        projectedGreen (hOperator α (t : ℂ)) hilbertRoot (e t : ℂ) = 0) ∧
      (∀ᶠ p : ℝ × ℝ in 𝓝 (lam, m),
        projectedGreen (hOperator α (p.1 : ℂ)) hilbertRoot (p.2 : ℂ) = 0 → p.2 = e p.1) := by
  obtain ⟨m, hm, _, hzero, hmax, _, _⟩ := selected_gap_energy hα hlam hgap
  obtain ⟨e, he, ha, hnear, hunique⟩ := magnetic_green_local_analytic_zero_branch α lam m
    (spectrum.not_mem_iff.mp (hgap.interior_avoids hm)) hzero
  exact ⟨m, hm, e, he, ha, hmax, hnear, hunique⟩

end DTMAudit.ManuscriptCouplingSelected

import DTMAudit.ManuscriptLatticeResponse
import DTM.NewResults.Spin.Compression
import Mathlib.Analysis.InnerProductSpace.ProdL2
import Mathlib.LinearAlgebra.UnitaryGroup
import DTMAudit.ManuscriptTraceRiesz

/-!
# Spin on the manuscript's actual centered spectral-source space

The subspace here is the closed span of the Fermi-projector sources, with
the origin removed. It is not replaced by the larger equalizer of the two
magnetic Hamiltonians. Conservation is deduced directly from the manuscript's
magnetic-balance identity, and the selected resolvent supplies its eigenline.
-/

set_option autoImplicit false
set_option maxHeartbeats 800000
noncomputable section
namespace DTMAudit.ManuscriptDualSpin
open CriticalDTM CriticalDTM.Chiral DTMAudit.FermiSpan
open scoped InnerProductSpace

/-- The manuscript's centered source space, literally `V ∩ e₀⊥`. -/
def centeredSpace (α lam : ℝ) : Submodule ℂ MagneticHilbert :=
  thresholdSourceSpace α lam ⊓ (ℂ ∙ hilbertRoot)ᗮ

@[simp] theorem mem_centeredSpace (α lam : ℝ) (u : MagneticHilbert) :
    u ∈ centeredSpace α lam ↔
      u ∈ thresholdSourceSpace α lam ∧ ⟪hilbertRoot,u⟫_ℂ = 0 := by
  simp only [centeredSpace, Submodule.mem_inf,
    Submodule.mem_orthogonal_singleton_iff_inner_right]

theorem centeredSpace_isClosed (α lam : ℝ) :
    IsClosed (centeredSpace α lam : Set MagneticHilbert) :=
  (Submodule.isClosed_topologicalClosure _).inter (ℂ ∙ hilbertRoot).isClosed_orthogonal

instance centeredSpace_completeSpace (α lam : ℝ) : CompleteSpace (centeredSpace α lam) :=
  (centeredSpace_isClosed α lam).completeSpace_coe

/-- The actual orthogonal projector onto the centered source space. -/
def centeredProjection (α lam : ℝ) : MagneticHilbert →L[ℂ] MagneticHilbert :=
  (centeredSpace α lam).subtypeL ∘L (centeredSpace α lam).orthogonalProjection

def centeredH (α lam : ℝ) : centeredSpace α lam →L[ℂ] centeredSpace α lam :=
  Spin.compression (centeredSpace α lam) (averageOperator α lam)

def centeredLz (α lam : ℝ) : centeredSpace α lam →L[ℂ] centeredSpace α lam :=
  Spin.compression (centeredSpace α lam) Lz

theorem centered_mem {α lam : ℝ} {u : MagneticHilbert}
    (hu : u ∈ thresholdSourceSpace α lam) : centered u ∈ centeredSpace α lam := by
  rw [mem_centeredSpace]
  exact ⟨(thresholdSourceSpace α lam).sub_mem hu
    ((thresholdSourceSpace α lam).smul_mem _
      (ManuscriptLatticeStationarity.source_mem α lam)), centered_root_pairing u⟩

/-- Within the spectral-source space, orthogonal projection deletes only the origin. -/
theorem projection_on_source {α lam : ℝ} {u : MagneticHilbert}
    (hu : u ∈ thresholdSourceSpace α lam) :
    ((centeredSpace α lam).orthogonalProjection u : MagneticHilbert) = centered u := by
  apply Submodule.eq_orthogonalProjection_of_mem_of_inner_eq_zero (centered_mem hu)
  intro w hw
  rw [centered, sub_sub_cancel, inner_smul_left,
    (mem_centeredSpace α lam w).mp hw |>.2, mul_zero]

theorem centeredH_coe (α lam : ℝ) (u : centeredSpace α lam) :
    (centeredH α lam u : MagneticHilbert) = centered (averageOperator α lam u) := by
  apply projection_on_source
  change averageOperator α lam (u : MagneticHilbert) ∈ thresholdSourceSpace α lam
  rw [ManuscriptLatticeStationarity.sources_mean_eq α lam u u.property.1]
  exact ManuscriptLatticeStationarity.sources_left_invariant α lam u u.property.1

theorem centeredH_symmetric (α lam : ℝ) :
    ∀ u v : centeredSpace α lam,
      ⟪centeredH α lam u,v⟫_ℂ = ⟪u,centeredH α lam v⟫_ℂ := by
  intro u v
  simp only [centeredH, Spin.compression_inner, Spin.inner_compression]
  exact averageOperator_symmetric α lam u v

theorem centeredLz_symmetric (α lam : ℝ) :
    ∀ u v : centeredSpace α lam,
      ⟪centeredLz α lam u,v⟫_ℂ = ⟪u,centeredLz α lam v⟫_ℂ := by
  intro u v
  simp only [centeredLz, Spin.compression_inner, Spin.inner_compression]
  exact Lz_symmetric u v

/-- Magnetic balance proves conservation for the actual centered compressions. -/
theorem centered_commute {α : ℝ} (hα : Irrational α) (lam : ℝ) :
    Commute (centeredLz α lam) (centeredH α lam) := by
  apply ContinuousLinearMap.ext
  intro w
  apply ext_inner_left ℂ
  intro v
  change ⟪v,centeredLz α lam (centeredH α lam w)⟫_ℂ =
    ⟪v,centeredH α lam (centeredLz α lam w)⟫_ℂ
  rw [← centeredH_symmetric]
  simp only [centeredLz, Spin.inner_compression]
  rw [centeredH_coe, centeredH_coe]
  simp only [centered, map_sub, map_smul, Lz_root, smul_zero, sub_zero,
    inner_sub_left, inner_smul_left]
  have hroot : ⟪hilbertRoot,Lz (w : MagneticHilbert)⟫_ℂ = 0 := by
    rw [← Lz_symmetric, Lz_root, inner_zero_left]
  rw [hroot, mul_zero, sub_zero]
  have h := ManuscriptLatticeBalance.source_balance hα lam v w v.property.1 w.property.1
  have hv := (mem_centeredSpace α lam v).mp v.property |>.2
  have hw := (mem_centeredSpace α lam w).mp w.property |>.2
  have hv' : ⟪(v : MagneticHilbert),hilbertRoot⟫_ℂ = 0 := by
    rw [← inner_conj_symm, hv, map_zero]
  rw [hw, hv', mul_zero, zero_mul, sub_self, inner_sub_right,
    ← averageOperator_symmetric] at h
  exact sub_eq_zero.mp h

/-- The full resolvent identifies every vector in a compressed energy eigenspace. -/
theorem centered_eigenvector_source {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (v : centeredSpace α lam) (hv : centeredH α lam v = (E : ℂ) • v) :
    ∃ c : ℂ, (v : MagneticHilbert) =
      c • resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot := by
  have h := congrArg (fun w : centeredSpace α lam => (w : MagneticHilbert)) hv
  dsimp only at h
  rw [centeredH_coe] at h
  change averageOperator α lam v - ⟪hilbertRoot,averageOperator α lam v⟫_ℂ • hilbertRoot =
    (E : ℂ) • (v : MagneticHilbert) at h
  have hs : hOperator α (lam : ℂ) v = (E : ℂ) • (v : MagneticHilbert) +
      ⟪hilbertRoot,averageOperator α lam v⟫_ℂ • hilbertRoot := by
    rw [← ManuscriptLatticeStationarity.sources_mean_eq α lam v v.property.1]
    exact sub_eq_iff_eq_add.mp h
  exact ⟨-⟪hilbertRoot,averageOperator α lam v⟫_ℂ,
    Spin.source_eq_neg_smul_actual_resolvent _ _ hE _ _ _ hs⟩

/-- At a zero of the diagonal Green function the full return lies in the vacancy. -/
def selectedSource {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    centeredSpace α lam :=
  ⟨_, (mem_centeredSpace α lam _).mpr
    ⟨(ManuscriptLatticeStationarity.resolvent_and_square_mem α lam _ hE).1,hzero⟩⟩

theorem selectedSource_ne_zero {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    selectedSource hE hzero ≠ 0 := by
  intro h
  exact actual_resolvent_column_ne_zero _ hilbertRoot hilbertRoot_ne_zero _ hE
    (congrArg (fun v : centeredSpace α lam => (v : MagneticHilbert)) h)

theorem selectedSource_energy {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    centeredH α lam (selectedSource hE hzero) = (E : ℂ) • selectedSource hE hzero := by
  apply Subtype.ext
  rw [centeredH_coe]
  change centered (averageOperator α lam
    (resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot)) = _
  rw [ManuscriptLatticeResponse.resolvent_equation_plus hE]
  have hp : ⟪hilbertRoot,(E : ℂ) •
      resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot - hilbertRoot⟫_ℂ = -1 := by
    rw [inner_sub_right, inner_smul_right, hzero, mul_zero,
      inner_self_eq_norm_sq_to_K, Spin.magnetic_root_unit]
    norm_num
  rw [centered, hp]
  change (E : ℂ) • resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot -
    hilbertRoot - (-1 : ℂ) • hilbertRoot =
    (E : ℂ) • resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
  module

/-- The selected energy eigenspace is exactly the line of the full resolvent return. -/
theorem selectedSource_eigenspace {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0)
    (v : centeredSpace α lam) :
    centeredH α lam v = (E : ℂ) • v ↔
      v ∈ Submodule.span ℂ {selectedSource hE hzero} := by
  constructor
  · intro hv
    obtain ⟨c,hc⟩ := centered_eigenvector_source hE v hv
    exact Submodule.mem_span_singleton.mpr ⟨c, Subtype.ext hc.symm⟩
  · intro hv
    obtain ⟨c,hc⟩ := Submodule.mem_span_singleton.mp hv
    rw [← hc, map_smul, selectedSource_energy hE hzero, smul_comm]

/-- Conservation preserves the actual selected return line. -/
theorem selectedSource_angular_line {α lam E : ℝ} (hα : Irrational α)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    centeredLz α lam (selectedSource hE hzero) ∈
      Submodule.span ℂ {selectedSource hE hzero} := by
  apply (selectedSource_eigenspace hE hzero _).mp
  calc
    centeredH α lam (centeredLz α lam (selectedSource hE hzero)) =
      centeredLz α lam (centeredH α lam (selectedSource hE hzero)) :=
      congrArg (fun A => A (selectedSource hE hzero)) (centered_commute hα lam).symm.eq
    _ = (E : ℂ) • centeredLz α lam (selectedSource hE hzero) := by
      rw [selectedSource_energy hE hzero, map_smul]

/-- The conserved angular eigenvalue is the manuscript's height-response coefficient. -/
theorem selectedSource_angular {α lam E : ℝ} (hα : Irrational α)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    centeredLz α lam (selectedSource hE hzero) =
      ((1 - 2*lam*greenCouplingValue α lam E : ℝ) : ℂ) • selectedSource hE hzero := by
  let r := selectedSource hE hzero
  obtain ⟨s,hs⟩ := Spin.real_eigenpair_of_mem_span (centeredLz α lam)
    (centeredLz_symmetric α lam) r (selectedSource_ne_zero hE hzero)
    (selectedSource_angular_line hα hE hzero)
  have hratio := Spin.eigenpair_inner_re_div_norm_sq (centeredLz α lam) r
    (selectedSource_ne_zero hE hzero) (s : ℂ) hs
  rw [Complex.ofReal_re] at hratio
  have hr := ManuscriptLatticeResponse.insertion_response hα hE hzero |>.1
  have hgreen : greenCouplingValue α lam E =
      -(⟪resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot,verticalRoot⟫_ℂ).re := by
    rw [greenCouplingValue, removedColumn_eq_resolvent_of_zero _ _ _ hzero]
  rw [← hgreen] at hr
  have hn : ‖r‖^2 ≠ 0 := pow_ne_zero 2 (norm_ne_zero_iff.mpr (selectedSource_ne_zero hE hzero))
  have hpair : ⟪r,centeredLz α lam r⟫_ℂ = ⟪(r : MagneticHilbert),Lz r⟫_ℂ :=
    Spin.inner_compression _ _ r r
  rw [hpair] at hratio
  change lam*greenCouplingValue α lam E = (⟪(r : MagneticHilbert),r-Lz r⟫_ℂ).re /
    (2*‖r‖^2) at hr
  have hself : (⟪(r : MagneticHilbert),r⟫_ℂ).re = ‖r‖^2 :=
    inner_self_eq_norm_sq (𝕜 := ℂ) (r : MagneticHilbert)
  rw [inner_sub_right, Complex.sub_re, hself] at hr
  have heq : s = 1-2*lam*greenCouplingValue α lam E := by
    rw [← hratio, mul_assoc 2 lam _, hr]
    have halgebra (a b : ℝ) (hb : b ≠ 0) : a/b = 1-2*((b-a)/(2*b)) := by
      field_simp
      ring
    exact halgebra _ _ hn
  rw [← heq]
  exact hs

/-- A root-fixing unitary that intertwines the physical Hamiltonians transports
the actual closed spectral-source spaces. -/
theorem source_map_of_intertwines (α lam mu : ℝ)
    (U : MagneticHilbert ≃ₗᵢ[ℂ] MagneticHilbert) (c : ℂ)
    (hroot : U hilbertRoot = hilbertRoot)
    (hinter : ∀ u, U (hOperator α (lam : ℂ) u) = c • hOperator α (mu : ℂ) (U u))
    {u : MagneticHilbert} (hu : u ∈ thresholdSourceSpace α lam) :
    U u ∈ thresholdSourceSpace α mu := by
  rw [thresholdSourceSpace_eq_cyclicSpace] at hu ⊢
  have hpow (n : ℕ) : U (((hOperator α (lam : ℂ))^n) hilbertRoot) =
      c^n • (((hOperator α (mu : ℂ))^n) hilbertRoot) := by
    induction n with
    | zero => simpa using hroot
    | succ n ih =>
      rw [pow_succ', ContinuousLinearMap.mul_apply, hinter, ih]
      simp only [map_smul, pow_succ', ContinuousLinearMap.mul_apply, smul_smul]
  have hle : cyclicSpace α lam ≤ (cyclicSpace α mu).comap U.toLinearEquiv.toLinearMap := by
    apply Submodule.topologicalClosure_minimal
    · apply Submodule.span_le.mpr
      rintro _ ⟨n,rfl⟩
      change U (((hOperator α (lam : ℂ))^n) hilbertRoot) ∈ cyclicSpace α mu
      rw [hpow]
      exact (cyclicSpace α mu).smul_mem _ (source_power_mem_cyclicSpace α mu n)
    · exact (cyclicSpace_isClosed α mu).preimage U.continuous
  exact hle hu

theorem rotation_source (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    {u : MagneticHilbert} (hu : u ∈ thresholdSourceSpace α lam) :
    magneticAubryEquiv α u ∈ thresholdSourceSpace α lam⁻¹ := by
  apply source_map_of_intertwines α lam lam⁻¹ (magneticAubryEquiv α) (lam : ℂ)
    (magneticAubryEquiv_root α) _ hu
  intro w
  simpa only [Complex.ofReal_inv] using
    magneticAubry_intertwines α (Complex.ofReal_ne_zero.mpr hlam) w

theorem inverse_rotation_intertwines (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    (u : MagneticHilbert) :
    (magneticAubryEquiv α).symm (hOperator α (lam⁻¹ : ℝ) u) =
      ((lam⁻¹ : ℝ) : ℂ) • hOperator α (lam : ℂ) ((magneticAubryEquiv α).symm u) := by
  apply (magneticAubryEquiv α).injective
  rw [LinearIsometryEquiv.apply_symm_apply, map_smul,
    magneticAubry_intertwines α (Complex.ofReal_ne_zero.mpr hlam),
    LinearIsometryEquiv.apply_symm_apply]
  simp [← Complex.ofReal_inv, smul_smul, hlam]

theorem inverse_rotation_source (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    {u : MagneticHilbert} (hu : u ∈ thresholdSourceSpace α lam⁻¹) :
    (magneticAubryEquiv α).symm u ∈ thresholdSourceSpace α lam := by
  apply source_map_of_intertwines α lam⁻¹ lam (magneticAubryEquiv α).symm (lam⁻¹ : ℝ)
    _ _ hu
  · exact (magneticAubryEquiv α).symm_apply_eq.mpr (magneticAubryEquiv_root α).symm
  · intro w
    simpa using inverse_rotation_intertwines α hlam w

theorem rotation_Lz (α : ℝ) (u : MagneticHilbert) :
    magneticAubryEquiv α (Lz u) = -Lz (magneticAubryEquiv α u) := by
  apply lp.ext
  funext s
  rcases s with ⟨n,m⟩
  simp only [magneticAubryEquiv_apply, Lz_apply, lp.coeFn_neg, Pi.neg_apply,
    Int.cast_neg, neg_sq]
  rw [show (m : ℝ)^2-(n : ℝ)^2 = -((n : ℝ)^2-(m : ℝ)^2) by ring,
    Real.sign_neg, Complex.ofReal_neg]
  ring

theorem rotation_centered_mem (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    {u : MagneticHilbert} (hu : u ∈ centeredSpace α lam) :
    magneticAubryEquiv α u ∈ centeredSpace α lam⁻¹ := by
  rw [mem_centeredSpace] at hu ⊢
  refine ⟨rotation_source α hlam hu.1, ?_⟩
  rw [← magneticAubryEquiv_root α, LinearIsometryEquiv.inner_map_map]
  exact hu.2

theorem inverse_rotation_centered_mem (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    {u : MagneticHilbert} (hu : u ∈ centeredSpace α lam⁻¹) :
    (magneticAubryEquiv α).symm u ∈ centeredSpace α lam := by
  rw [mem_centeredSpace] at hu ⊢
  refine ⟨inverse_rotation_source α hlam hu.1, ?_⟩
  have hroot : (magneticAubryEquiv α).symm hilbertRoot = hilbertRoot :=
    (magneticAubryEquiv α).symm_apply_eq.mpr (magneticAubryEquiv_root α).symm
  rw [← hroot, LinearIsometryEquiv.inner_map_map]
  exact hu.2

/-- The physical quarter-turn, restricted to the two actual centered source spaces. -/
def centeredRotation (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0) :
    centeredSpace α lam ≃ₗᵢ[ℂ] centeredSpace α lam⁻¹ where
  toFun u := ⟨magneticAubryEquiv α u,rotation_centered_mem α hlam u.property⟩
  invFun u := ⟨(magneticAubryEquiv α).symm u,inverse_rotation_centered_mem α hlam u.property⟩
  left_inv u := Subtype.ext ((magneticAubryEquiv α).symm_apply_apply u)
  right_inv u := Subtype.ext ((magneticAubryEquiv α).apply_symm_apply u)
  map_add' u v := Subtype.ext ((magneticAubryEquiv α).map_add u v)
  map_smul' c u := Subtype.ext ((magneticAubryEquiv α).map_smul c u)
  norm_map' u := (magneticAubryEquiv α).norm_map u

theorem rotation_centered (α : ℝ) (u : MagneticHilbert) :
    magneticAubryEquiv α (centered u) = centered (magneticAubryEquiv α u) := by
  have hp : ⟪hilbertRoot,magneticAubryEquiv α u⟫_ℂ = ⟪hilbertRoot,u⟫_ℂ := by
    conv_lhs => rw [← magneticAubryEquiv_root α]
    exact (magneticAubryEquiv α).inner_map_map hilbertRoot u
  simp only [centered, map_sub, map_smul, magneticAubryEquiv_root]
  rw [hp]

/-- Aubry scaling survives the actual centered compression. -/
theorem centeredRotation_H (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    (u : centeredSpace α lam) :
    centeredRotation α hlam (centeredH α lam u) =
      (lam : ℂ) • centeredH α lam⁻¹ (centeredRotation α hlam u) := by
  apply Subtype.ext
  change magneticAubryEquiv α (centeredH α lam u : MagneticHilbert) =
    (lam : ℂ) • (centeredH α lam⁻¹ (centeredRotation α hlam u) : MagneticHilbert)
  rw [centeredH_coe, rotation_centered, centeredH_coe,
    ManuscriptLatticeStationarity.sources_mean_eq α lam u u.property.1,
    ManuscriptLatticeStationarity.sources_mean_eq α lam⁻¹ _
      (centeredRotation α hlam u).property.1,
    magneticAubry_intertwines α (Complex.ofReal_ne_zero.mpr hlam)]
  simp only [centered, map_smul, inner_smul_right, smul_sub, smul_smul,
    Complex.ofReal_inv]
  rfl

/-- The angular compression changes sign under the same physical quarter-turn. -/
theorem centeredRotation_Lz (α : ℝ) {lam : ℝ} (hlam : lam ≠ 0)
    (u : centeredSpace α lam) :
    centeredRotation α hlam (centeredLz α lam u) =
      -centeredLz α lam⁻¹ (centeredRotation α hlam u) := by
  apply ext_inner_left ℂ
  intro v
  obtain ⟨w,rfl⟩ := (centeredRotation α hlam).surjective v
  rw [LinearIsometryEquiv.inner_map_map, inner_neg_right]
  simp only [centeredLz, Spin.inner_compression]
  change ⟪(w : MagneticHilbert),Lz u⟫_ℂ =
    -⟪magneticAubryEquiv α w,Lz (magneticAubryEquiv α u)⟫_ℂ
  rw [← inner_neg_right, ← rotation_Lz, LinearIsometryEquiv.inner_map_map]

/-- The Hilbert direct sum at reciprocal couplings. -/
abbrev DualSpace (α lam : ℝ) := WithLp 2 (centeredSpace α lam × centeredSpace α lam⁻¹)

def dualH (α lam : ℝ) : DualSpace α lam →L[ℂ] DualSpace α lam :=
  (WithLp.prodContinuousLinearEquiv 2 ℂ (centeredSpace α lam) (centeredSpace α lam⁻¹)).symm.toContinuousLinearMap ∘L
    ((centeredH α lam).prodMap ((lam : ℂ) • centeredH α lam⁻¹)) ∘L
    (WithLp.prodContinuousLinearEquiv 2 ℂ (centeredSpace α lam) (centeredSpace α lam⁻¹)).toContinuousLinearMap

def dualLz (α lam : ℝ) : DualSpace α lam →L[ℂ] DualSpace α lam :=
  (WithLp.prodContinuousLinearEquiv 2 ℂ (centeredSpace α lam) (centeredSpace α lam⁻¹)).symm.toContinuousLinearMap ∘L
    ((centeredLz α lam).prodMap (centeredLz α lam⁻¹)) ∘L
    (WithLp.prodContinuousLinearEquiv 2 ℂ (centeredSpace α lam) (centeredSpace α lam⁻¹)).toContinuousLinearMap

@[simp] theorem dualH_fst (α lam : ℝ) (v : DualSpace α lam) :
    (dualH α lam v).fst = centeredH α lam v.fst := rfl
@[simp] theorem dualH_snd (α lam : ℝ) (v : DualSpace α lam) :
    (dualH α lam v).snd = (lam : ℂ) • centeredH α lam⁻¹ v.snd := rfl
@[simp] theorem dualLz_fst (α lam : ℝ) (v : DualSpace α lam) :
    (dualLz α lam v).fst = centeredLz α lam v.fst := rfl
@[simp] theorem dualLz_snd (α lam : ℝ) (v : DualSpace α lam) :
    (dualLz α lam v).snd = centeredLz α lam⁻¹ v.snd := rfl

theorem dualH_symmetric (α lam : ℝ) :
    ∀ u v : DualSpace α lam, ⟪dualH α lam u,v⟫_ℂ = ⟪u,dualH α lam v⟫_ℂ := by
  intro u v
  simp only [WithLp.prod_inner_apply, dualH_fst, dualH_snd, inner_smul_left,
    inner_smul_right, Complex.conj_ofReal, centeredH_symmetric]

theorem dualLz_symmetric (α lam : ℝ) :
    ∀ u v : DualSpace α lam, ⟪dualLz α lam u,v⟫_ℂ = ⟪u,dualLz α lam v⟫_ℂ := by
  intro u v
  simp only [WithLp.prod_inner_apply, dualLz_fst, dualLz_snd, centeredLz_symmetric]

section SelectedDoublet
variable {α lam E : ℝ} (hlam : lam ≠ 0)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0)

/-- The normalized full-resolvent return used in the manuscript. -/
def unitSource : centeredSpace α lam :=
  ((‖selectedSource hE hzero‖⁻¹ : ℝ) : ℂ) • selectedSource hE hzero

theorem unitSource_norm : ‖unitSource hE hzero‖ = 1 := by
  rw [unitSource, norm_smul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (inv_nonneg.mpr (norm_nonneg _))]
  exact inv_mul_cancel₀ (norm_ne_zero_iff.mpr (selectedSource_ne_zero hE hzero))

theorem unitSource_energy : centeredH α lam (unitSource hE hzero) =
    (E : ℂ) • unitSource hE hzero := by
  rw [unitSource, map_smul, selectedSource_energy hE hzero, smul_comm]

theorem unitSource_angular (hα : Irrational α) :
    centeredLz α lam (unitSource hE hzero) =
      ((1-2*lam*greenCouplingValue α lam E : ℝ) : ℂ) • unitSource hE hzero := by
  rw [unitSource, map_smul, selectedSource_angular hα hE hzero, smul_comm]

/-- Concrete coordinates on the doublet, using the unit source and its physical rotation. -/
def doubletEmbedding : (Fin 2 → ℂ) →ₗ[ℂ] DualSpace α lam where
  toFun z := (WithLp.equiv 2 _).symm
    (z 0 • unitSource hE hzero, z 1 • centeredRotation α hlam (unitSource hE hzero))
  map_add' z w := by apply Prod.ext <;> simp [add_smul]
  map_smul' c z := by apply Prod.ext <;> simp [smul_smul]

@[simp] theorem doubletEmbedding_fst (z : Fin 2 → ℂ) :
    (doubletEmbedding hlam hE hzero z).fst = z 0 • unitSource hE hzero := rfl
@[simp] theorem doubletEmbedding_snd (z : Fin 2 → ℂ) :
    (doubletEmbedding hlam hE hzero z).snd =
      z 1 • centeredRotation α hlam (unitSource hE hzero) := rfl

/-- The doublet is the actual two-dimensional subspace of the paired orbital space. -/
def doubletSpace : Submodule ℂ (DualSpace α lam) := LinearMap.range (doubletEmbedding hlam hE hzero)

theorem doublet_inner (z w : Fin 2 → ℂ) :
    ⟪doubletEmbedding hlam hE hzero z,doubletEmbedding hlam hE hzero w⟫_ℂ =
      star (z 0)*w 0 + star (z 1)*w 1 := by
  have hnorm : ‖(unitSource hE hzero : MagneticHilbert)‖ = 1 := unitSource_norm hE hzero
  simp [WithLp.prod_inner_apply, inner_smul_left, inner_smul_right,
    inner_self_eq_norm_sq_to_K, unitSource_norm, hnorm]
  ring

/-- The scalar Hamiltonian restriction is derived from the resolvent and Aubry rotation. -/
theorem doublet_energy (z : Fin 2 → ℂ) :
    dualH α lam (doubletEmbedding hlam hE hzero z) =
      (E : ℂ) • doubletEmbedding hlam hE hzero z := by
  apply Prod.ext
  · change centeredH α lam (z 0 • unitSource hE hzero) =
      (E : ℂ) • (z 0 • unitSource hE hzero)
    rw [map_smul, unitSource_energy, smul_comm]
  · change (lam : ℂ) • centeredH α lam⁻¹
      (z 1 • centeredRotation α hlam (unitSource hE hzero)) =
      (E : ℂ) • (z 1 • centeredRotation α hlam (unitSource hE hzero))
    rw [map_smul, smul_comm (lam : ℂ), ← centeredRotation_H α hlam,
      unitSource_energy, map_smul, smul_comm]

/-- The angular restriction has the literal σz signs in the physical doublet. -/
theorem doublet_angular (hα : Irrational α) (z : Fin 2 → ℂ) :
    dualLz α lam (doubletEmbedding hlam hE hzero z) =
      ((1-2*lam*greenCouplingValue α lam E : ℝ) : ℂ) •
        doubletEmbedding hlam hE hzero ![z 0,-z 1] := by
  apply Prod.ext
  · change centeredLz α lam (z 0 • unitSource hE hzero) =
      ((1-2*lam*greenCouplingValue α lam E : ℝ) : ℂ) • (z 0 • unitSource hE hzero)
    rw [map_smul, unitSource_angular hE hzero hα, smul_comm]
  · change centeredLz α lam⁻¹ (z 1 • centeredRotation α hlam (unitSource hE hzero)) =
      ((1-2*lam*greenCouplingValue α lam E : ℝ) : ℂ) •
        (-z 1 • centeredRotation α hlam (unitSource hE hzero))
    have hrot := centeredRotation_Lz α hlam (unitSource hE hzero)
    rw [unitSource_angular hE hzero hα, map_smul] at hrot
    have hrot' := congrArg Neg.neg hrot
    simp only [neg_neg] at hrot'
    rw [map_smul, ← hrot']
    module

/-- Both actual operators preserve the physical doublet. -/
theorem doublet_invariant (hα : Irrational α) (v : DualSpace α lam)
    (hv : v ∈ doubletSpace hlam hE hzero) :
    dualH α lam v ∈ doubletSpace hlam hE hzero ∧
      dualLz α lam v ∈ doubletSpace hlam hE hzero := by
  obtain ⟨z,rfl⟩ := hv
  rw [doublet_energy, doublet_angular hlam hE hzero hα]
  exact ⟨(doubletSpace hlam hE hzero).smul_mem _ ⟨z,rfl⟩,
    (doubletSpace hlam hE hzero).smul_mem _ ⟨_,rfl⟩⟩

/-- Symmetry also preserves the orthogonal complement, so the doublet reduces both. -/
theorem doublet_orthogonal_invariant (hα : Irrational α) (v : DualSpace α lam)
    (hv : v ∈ (doubletSpace hlam hE hzero)ᗮ) :
    dualH α lam v ∈ (doubletSpace hlam hE hzero)ᗮ ∧
      dualLz α lam v ∈ (doubletSpace hlam hE hzero)ᗮ := by
  constructor
  · intro w hw
    rw [← dualH_symmetric]
    exact hv _ (doublet_invariant hlam hE hzero hα w hw).1
  · intro w hw
    rw [← dualLz_symmetric]
    exact hv _ (doublet_invariant hlam hE hzero hα w hw).2

/-- Every two-by-two matrix action commutes with the *derived* physical scalar restriction. -/
theorem doublet_matrix_conserved (M : Matrix (Fin 2) (Fin 2) ℂ) (z : Fin 2 → ℂ) :
    dualH α lam (doubletEmbedding hlam hE hzero (M.mulVec z)) =
      doubletEmbedding hlam hE hzero (M.mulVec ((E : ℂ) • z)) := by
  rw [doublet_energy]
  have hM : M.mulVec ((E : ℂ) • z) = (E : ℂ) • M.mulVec z :=
    (Matrix.toLin' M).map_smul (E : ℂ) z
  rw [hM, map_smul]

/-- Unitary matrices preserve the physical Hilbert inner product of the doublet. -/
theorem doublet_matrix_unitary (M : Matrix.unitaryGroup (Fin 2) ℂ)
    (z w : Fin 2 → ℂ) :
    ⟪doubletEmbedding hlam hE hzero (M.val.mulVec z),
      doubletEmbedding hlam hE hzero (M.val.mulVec w)⟫_ℂ =
      ⟪doubletEmbedding hlam hE hzero z,doubletEmbedding hlam hE hzero w⟫_ℂ := by
  have hp (a b : Fin 2 → ℂ) :
      ⟪doubletEmbedding hlam hE hzero a,doubletEmbedding hlam hE hzero b⟫_ℂ =
        dotProduct (star a) b := by
    rw [doublet_inner]
    simp [dotProduct, Fin.sum_univ_two]
  have hunit : M.val.conjTranspose*M.val = 1 := M.property.1
  rw [hp, hp, Matrix.star_mulVec, Matrix.dotProduct_mulVec,
    Matrix.vecMul_vecMul, hunit, Matrix.vecMul_one]

/-- The special-unitary group acts unitarily and conserves the physical paired Hamiltonian. -/
theorem conserved_SU2 (M : Matrix.specialUnitaryGroup (Fin 2) ℂ)
    (z w : Fin 2 → ℂ) :
    ⟪doubletEmbedding hlam hE hzero (M.val.mulVec z),
      doubletEmbedding hlam hE hzero (M.val.mulVec w)⟫_ℂ =
        ⟪doubletEmbedding hlam hE hzero z,doubletEmbedding hlam hE hzero w⟫_ℂ ∧
    dualH α lam (doubletEmbedding hlam hE hzero (M.val.mulVec z)) =
      doubletEmbedding hlam hE hzero (M.val.mulVec ((E : ℂ) • z)) :=
  ⟨doublet_matrix_unitary hlam hE hzero ⟨M.val,M.property.1⟩ z w,
    doublet_matrix_conserved hlam hE hzero M.val z⟩

end SelectedDoublet

/-- Pauli matrices in the physical doublet coordinates. -/
def sigmaX : Matrix (Fin 2) (Fin 2) ℂ := !![0,1;1,0]
def sigmaY : Matrix (Fin 2) (Fin 2) ℂ := !![0,-Complex.I;Complex.I,0]
def sigmaZ : Matrix (Fin 2) (Fin 2) ℂ := !![1,0;0,-1]

/-- The three spin-½ Lie commutators in the chosen physical coordinates. -/
def SpinHalfRelations : Prop :=
    ((1/2 : ℂ) • sigmaX)*((1/2 : ℂ) • sigmaY) -
        ((1/2 : ℂ) • sigmaY)*((1/2 : ℂ) • sigmaX) =
      Complex.I • ((1/2 : ℂ) • sigmaZ) ∧
    ((1/2 : ℂ) • sigmaY)*((1/2 : ℂ) • sigmaZ) -
        ((1/2 : ℂ) • sigmaZ)*((1/2 : ℂ) • sigmaY) =
      Complex.I • ((1/2 : ℂ) • sigmaX) ∧
    ((1/2 : ℂ) • sigmaZ)*((1/2 : ℂ) • sigmaX) -
        ((1/2 : ℂ) • sigmaX)*((1/2 : ℂ) • sigmaZ) =
      Complex.I • ((1/2 : ℂ) • sigmaY)

theorem pauli_half_commutators : SpinHalfRelations := by
  constructor
  · ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [sigmaX, sigmaY, sigmaZ, Matrix.mul_apply, Fin.sum_univ_two] <;>
      ring_nf
  constructor
  · ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [sigmaX, sigmaY, sigmaZ, Matrix.mul_apply, Fin.sum_univ_two] <;>
      ring_nf
  · ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [sigmaX, sigmaY, sigmaZ, Matrix.mul_apply, Fin.sum_univ_two] <;>
      ring_nf <;> norm_num [Complex.I_sq]

theorem sigmaZ_mulVec (z : Fin 2 → ℂ) : sigmaZ.mulVec z = ![z 0,-z 1] := by
  ext i
  fin_cases i <;> simp [sigmaZ, Matrix.mulVec, dotProduct, Fin.sum_univ_two]

/-- Literal form of the manuscript corollary along a local stationary height branch.
The height is the actual DOS logarithmic integral. The proof includes the
centered-source commutator, the simple full-resolvent eigenspace, the physical
quarter-turn, the Pauli algebra, and the unitary action; none is a hypothesis. -/
-- Manuscript Corollary 4.3.
theorem conserved_dual_spin_path {α : ℝ} (hα : Irrational α)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U) (hlam0 : lam ≠ 0)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (energy lam : ℂ) = 0) :
    let height := fun l : ℝ => ∫ x : ℝ, Real.log |energy l-x|
      ∂magneticRealSpectralMeasure α l
    let embed := doubletEmbedding hlam0 (hE lam hlam) hzero
    let S := doubletSpace hlam0 (hE lam hlam) hzero
    (∀ z : Fin 2 → ℂ,
      dualH α lam (embed z) = (energy lam : ℂ) • embed z ∧
      dualLz α lam (embed z) = ((1-2*lam*deriv height lam : ℝ) : ℂ) •
        embed (sigmaZ.mulVec z)) ∧
    (∀ v ∈ S, dualH α lam v ∈ S ∧ dualLz α lam v ∈ S) ∧
    (∀ v ∈ Sᗮ, dualH α lam v ∈ Sᗮ ∧ dualLz α lam v ∈ Sᗮ) ∧
    (∀ (M : Matrix.specialUnitaryGroup (Fin 2) ℂ) (z w : Fin 2 → ℂ),
      ⟪embed (M.val.mulVec z),embed (M.val.mulVec w)⟫_ℂ = ⟪embed z,embed w⟫_ℂ ∧
      dualH α lam (embed (M.val.mulVec z)) =
        embed (M.val.mulVec ((energy lam : ℂ) • z))) ∧
    SpinHalfRelations := by
  dsimp only
  have hderiv := (ManuscriptTraceRiesz.dos_height_stationary_path_hasDerivAt
    α energy velocity hU hlam he hd hE hzero).deriv
  have hgreen : greenCouplingValue α lam (energy lam) =
      -(⟪resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot,verticalRoot⟫_ℂ).re := by
    rw [greenCouplingValue, removedColumn_eq_resolvent_of_zero _ _ _ hzero]
  refine ⟨?_, doublet_invariant hlam0 (hE lam hlam) hzero hα,
    doublet_orthogonal_invariant hlam0 (hE lam hlam) hzero hα,
    conserved_SU2 hlam0 (hE lam hlam) hzero, pauli_half_commutators⟩
  intro z
  refine ⟨doublet_energy hlam0 (hE lam hlam) hzero z, ?_⟩
  rw [hderiv, ← hgreen, sigmaZ_mulVec]
  exact doublet_angular hlam0 (hE lam hlam) hzero hα z

end DTMAudit.ManuscriptDualSpin

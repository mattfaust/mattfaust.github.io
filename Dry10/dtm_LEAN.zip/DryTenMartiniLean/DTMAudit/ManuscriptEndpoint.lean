import DTMAudit.ManuscriptContinuation
import DTMAudit.ManuscriptCouplingResponse
import DTMAudit.ManuscriptHeightDuality

/-! # The unconditional endpoint of the manuscript's displayed proof

The only local response interface in compact continuation is discharged here
by the literal phase/Riesz derivative and arbitrary-test/R² lattice proof.
-/
noncomputable section
namespace DTMAudit.ManuscriptEndpoint
open CriticalDTM Set

theorem physical_monotonicity {α : ℝ} (hα : Irrational α) :
    ManuscriptContinuation.StationaryHeightMonotonicity α :=
  ManuscriptCouplingResponse.height_monotoneOn hα

-- Manuscript Theorem 1.5.
theorem nonzero_statement : DTMMinimal.statement_nonzero :=
  ManuscriptContinuation.nonzero_statement (fun _ hα => physical_monotonicity hα)

/-- The closed coupling interval includes the seed itself without invoking
the strict-extension argument at an equal endpoint. -/
-- Manuscript Theorem 3.10.
theorem persistence {α s : ℝ} (hα : Irrational α) (hs : 0 < s)
    (n : ℤ) (hn : n ≠ 0)
    (hseed : ∃ a b : ℝ, IsLabelledSpectralGap (magneticRealSpectrumSet α s)
      (magneticLowerMass α s) (arithmeticGapLabel α n) a b) :
    ∀ target ∈ Icc s 1, ∃ a b : ℝ,
      IsLabelledSpectralGap (magneticRealSpectrumSet α target)
        (magneticLowerMass α target) (arithmeticGapLabel α n) a b := by
  intro target ht
  rcases eq_or_lt_of_le ht.1 with heq | hlt
  · simpa only [← heq] using hseed
  · exact ManuscriptContinuation.magnetic_labelled_gap_persists_from_one_seed
      hα (physical_monotonicity hα) hs hlt ht.2 (arithmeticGapLabel_mem_Ioo hα hn) hseed

end DTMAudit.ManuscriptEndpoint

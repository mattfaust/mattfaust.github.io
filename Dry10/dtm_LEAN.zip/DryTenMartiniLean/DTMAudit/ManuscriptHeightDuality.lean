import DTMAudit.ManuscriptLatticeResponse
import DTMAudit.ManuscriptCouplingEnergy

/-!
# Actual DOS and selected-gap height duality

The logarithmic scaling is derived from the independently proved Aubry
push-forward equality for the physical DOS measure. The selected-gap result
therefore concerns the actual AMO logarithmic potential, not an arbitrary
function postulated to satisfy duality.
-/

set_option autoImplicit false
set_option maxHeartbeats 800000
noncomputable section
namespace DTMAudit.ManuscriptHeightDuality
open CriticalDTM MeasureTheory Filter Set
open scoped Topology InnerProductSpace

/-- Aubry scaling of the actual DOS logarithmic integral, at every real energy. -/
theorem dos_potential_duality (α : ℝ) {lam : ℝ} (hlam : 0 < lam) (E : ℝ) :
    (∫ x : ℝ, Real.log |lam*E-x| ∂magneticRealSpectralMeasure α lam) =
      Real.log lam + ∫ x : ℝ, Real.log |E-x|
        ∂magneticRealSpectralMeasure α lam⁻¹ := by
  rw [magneticRealSpectralMeasure_aubry α hlam,
    integral_map (φ := fun x : ℝ => lam*x) (f := fun x : ℝ => Real.log |lam*E-x|)
      (continuous_const.mul continuous_id).measurable.aemeasurable
      ((show Measurable (fun x : ℝ => Real.log |lam*E-x|) from
        (continuous_const.sub continuous_id).abs.measurable.log).aestronglyMeasurable)]
  have hne : ∀ᵐ x : ℝ ∂magneticRealSpectralMeasure α lam⁻¹, x ≠ E := by
    apply ae_iff.mpr
    simpa only [not_not, Set.setOf_eq_eq_singleton] using
      magneticRealSpectralMeasure_singleton_eq_zero α lam⁻¹ E
  calc
    _ = ∫ x : ℝ, (Real.log lam + Real.log |E-x|)
        ∂magneticRealSpectralMeasure α lam⁻¹ := by
      apply integral_congr_ae
      filter_upwards [hne] with x hx
      rw [show lam*E-lam*x = lam*(E-x) by ring, abs_mul, abs_of_pos hlam,
        Real.log_mul (ne_of_gt hlam) (abs_ne_zero.mpr (sub_ne_zero.mpr hx.symm))]
    _ = _ := by
      rw [integral_add (integrable_const _) (magnetic_realLogKernel_integrable α lam⁻¹ E)]
      simp

/-- The reciprocal energy is an actual resolvent point, by spectral scaling. -/
theorem reciprocal_resolvent (α : ℝ) {lam E : ℝ} (hlam : 0 < lam)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    ((E/lam : ℝ) : ℂ) ∈ resolventSet ℂ (hOperator α (lam⁻¹ : ℝ)) := by
  apply spectrum.not_mem_iff.mp
  intro hs
  have ha := magnetic_spectrum_aubry α (Complex.ofReal_ne_zero.mpr (ne_of_gt hlam)) (E : ℂ)
  have hs' : (E : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ)) := by
    apply ha.mpr
    simpa only [Complex.ofReal_div, Complex.ofReal_inv] using hs
  exact (spectrum.not_mem_iff.mpr hE) hs'

/-- On every physical gap the same identity holds for the repository's
logarithmic potential, using its proved agreement with the DOS definition. -/
theorem potential_duality (α : ℝ) {lam E : ℝ} (hlam : 0 < lam)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticLogPotential α lam E =
      Real.log lam + magneticLogPotential α lam⁻¹ (E/lam) := by
  rw [magneticLogPotential_eq_realSpectralIntegral α lam E hE,
    magneticLogPotential_eq_realSpectralIntegral α lam⁻¹ (E/lam)
      (reciprocal_resolvent α hlam hE)]
  simpa only [mul_div_cancel₀ E (ne_of_gt hlam)] using dos_potential_duality α hlam (E/lam)

/-- A maximum on an open physical gap has zero origin resolvent pairing. -/
theorem maximizing_energy_zero (α lam : ℝ) {a b m : ℝ}
    (hgap : IsSpectralGap {x : ℝ | (x : ℂ) ∈ spectrum ℂ (hOperator α (lam : ℂ))} a b)
    (hm : m ∈ Ioo a b) (hmax : IsMaxOn (magneticLogPotential α lam) (Ioo a b) m) :
    projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (m : ℂ) = 0 := by
  have hres : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) :=
    spectrum.not_mem_iff.mp (hgap.interior_avoids hm)
  have hd := ManuscriptCouplingEnergy.potential_energy_hasDerivAt α lam m hres
  have hz := (hmax.isLocalMax (isOpen_Ioo.mem_nhds hm)).hasDerivAt_eq_zero hd
  rw [projectedGreen_eq_realProjectedGreen _ (hOperator_isSelfAdjoint α lam), hz,
    Complex.ofReal_zero]

/-- Equal actual IDS values place two resolvent energies in the same bounded
gap, at every real coupling. The proof uses the proved faithful spectral cut. -/
theorem same_label_same_gap (α lam : ℝ) {a b x y : ℝ}
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam) a b)
    (hx : x ∈ Ioo a b)
    (hy : (y : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hmass : magneticLowerMass α lam y = magneticLowerMass α lam x) : y ∈ Ioo a b := by
  have hxres : (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) :=
    spectrum.not_mem_iff.mp (hgap.interior_avoids hx)
  have hcuts := magneticLowerMass_eq_implies_same_spectral_cut α lam x y hxres hy hmass.symm
  have hay : a < y := (hcuts a hgap.left_mem).mp hx.1
  have hyb : y ≤ b := le_of_not_gt (fun hby =>
    (not_lt_of_ge hx.2.le) ((hcuts b hgap.right_mem).mpr hby))
  have hyne : y ≠ b := by
    intro heq
    exact (spectrum.not_mem_iff.mpr hy) (heq.symm ▸ hgap.right_mem)
  exact ⟨hay,lt_of_le_of_ne hyb hyne⟩

/-- Positive scaling transports an actual bounded magnetic spectral gap. -/
theorem scaled_gap (α : ℝ) {lam a b : ℝ} (hlam : 0 < lam)
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam⁻¹) a b) :
    IsSpectralGap (magneticRealSpectrumSet α lam) (lam*a) (lam*b) := by
  have hspec (x : ℝ) : lam*x ∈ magneticRealSpectrumSet α lam ↔
      x ∈ magneticRealSpectrumSet α lam⁻¹ := by
    simpa only [magneticRealSpectrumSet, Set.mem_setOf_eq, Complex.ofReal_mul,
      Complex.ofReal_inv] using magnetic_spectrum_aubry_mul α
        (Complex.ofReal_ne_zero.mpr (ne_of_gt hlam)) (x : ℂ)
  refine ⟨mul_lt_mul_of_pos_left hgap.endpoints_ordered hlam,
    (hspec a).mpr hgap.left_mem, (hspec b).mpr hgap.right_mem, ?_⟩
  intro x hx hxs
  have hin : x/lam ∈ Ioo a b :=
    ⟨(lt_div_iff₀ hlam).mpr (by simpa only [mul_comm] using hx.1),
      (div_lt_iff₀ hlam).mpr (by simpa only [mul_comm] using hx.2)⟩
  apply hgap.interior_avoids hin
  apply (hspec (x/lam)).mp
  simpa only [mul_div_cancel₀ x (ne_of_gt hlam)] using hxs

/-- The scaled reciprocal maximizer is a maximizer of the actual λ potential. -/
theorem scaled_maximum (α : ℝ) {lam a b m : ℝ} (hlam : 0 < lam)
    (hgap : IsSpectralGap (magneticRealSpectrumSet α lam⁻¹) a b)
    (hm : m ∈ Ioo a b)
    (hmax : IsMaxOn (magneticLogPotential α lam⁻¹) (Ioo a b) m) :
    IsMaxOn (magneticLogPotential α lam) (Ioo (lam*a) (lam*b)) (lam*m) := by
  have hg := scaled_gap α hlam hgap
  have hmm : lam*m ∈ Ioo (lam*a) (lam*b) :=
    ⟨mul_lt_mul_of_pos_left hm.1 hlam,mul_lt_mul_of_pos_left hm.2 hlam⟩
  intro x hx
  have hin : x/lam ∈ Ioo a b :=
    ⟨(lt_div_iff₀ hlam).mpr (by simpa only [mul_comm] using hx.1),
      (div_lt_iff₀ hlam).mpr (by simpa only [mul_comm] using hx.2)⟩
  change magneticLogPotential α lam x ≤ magneticLogPotential α lam (lam*m)
  rw [potential_duality α hlam (spectrum.not_mem_iff.mp (hg.interior_avoids hx)),
    potential_duality α hlam (spectrum.not_mem_iff.mp (hg.interior_avoids hmm)),
    mul_div_cancel_left₀ m (ne_of_gt hlam)]
  exact add_le_add_left (hmax hin) _

/-- Uniqueness identifies the two selected energies by their actual IDS label.
The scaling of the selected energies is a conclusion, not a branch premise. -/
theorem selected_energy_duality (α : ℝ) {lam label a b c d m mdual : ℝ}
    (hlam : 0 < lam)
    (hgap : IsLabelledSpectralGap (magneticRealSpectrumSet α lam)
      (magneticLowerMass α lam) label a b)
    (hdual : IsLabelledSpectralGap (magneticRealSpectrumSet α lam⁻¹)
      (magneticLowerMass α lam⁻¹) label c d)
    (hm : m ∈ Ioo a b) (hmdual : mdual ∈ Ioo c d)
    (hmax : IsMaxOn (magneticLogPotential α lam) (Ioo a b) m)
    (hmaxdual : IsMaxOn (magneticLogPotential α lam⁻¹) (Ioo c d) mdual) :
    m = lam*mdual := by
  have hg := scaled_gap α hlam hdual.1
  have hscaled : lam*mdual ∈ Ioo (lam*c) (lam*d) :=
    ⟨mul_lt_mul_of_pos_left hmdual.1 hlam,mul_lt_mul_of_pos_left hmdual.2 hlam⟩
  have hmres : (m : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)) :=
    spectrum.not_mem_iff.mp (hgap.1.interior_avoids hm)
  have hmass : magneticLowerMass α lam m = magneticLowerMass α lam (lam*mdual) := by
    rw [magneticLowerMass_aubry α hlam, hgap.2 m hm, hdual.2 mdual hmdual]
  have hmin := same_label_same_gap α lam hg hscaled hmres hmass
  have hz := maximizing_energy_zero α lam hgap.1 hm hmax
  have hzdual := maximizing_energy_zero α lam hg hscaled
    (scaled_maximum α hlam hdual.1 hmdual hmaxdual)
  apply (realProjectedGreen_strictAntiOn _ (hOperator_isSelfAdjoint α lam)
    hilbertRoot hilbertRoot_ne_zero (fun x hx =>
      spectrum.not_mem_iff.mp (hg.interior_avoids hx))).injOn hmin hscaled
  exact (congrArg Complex.re hz).trans (congrArg Complex.re hzdual).symm

/-- η_n(λ) = log λ + η_n(1/λ) for the actual same-labelled gap maxima. -/
theorem selected_height_duality (α : ℝ) {lam label a b c d m mdual : ℝ}
    (hlam : 0 < lam)
    (hgap : IsLabelledSpectralGap (magneticRealSpectrumSet α lam)
      (magneticLowerMass α lam) label a b)
    (hdual : IsLabelledSpectralGap (magneticRealSpectrumSet α lam⁻¹)
      (magneticLowerMass α lam⁻¹) label c d)
    (hm : m ∈ Ioo a b) (hmdual : mdual ∈ Ioo c d)
    (hmax : IsMaxOn (magneticLogPotential α lam) (Ioo a b) m)
    (hmaxdual : IsMaxOn (magneticLogPotential α lam⁻¹) (Ioo c d) mdual) :
    magneticLogPotential α lam m = Real.log lam + magneticLogPotential α lam⁻¹ mdual := by
  have he := selected_energy_duality α hlam hgap hdual hm hmdual hmax hmaxdual
  rw [potential_duality α hlam (spectrum.not_mem_iff.mp (hgap.1.interior_avoids hm)),
    he, mul_div_cancel_left₀ mdual (ne_of_gt hlam)]

/-- Selection data for an actual labelled gap. This predicate contains no
duality law, derivative value, monotonicity assertion, or gap-opening claim. -/
def IsSelectedGapEnergy (α label lam m : ℝ) : Prop :=
  ∃ a b : ℝ, IsLabelledSpectralGap (magneticRealSpectrumSet α lam)
      (magneticLowerMass α lam) label a b ∧ m ∈ Ioo a b ∧
      IsMaxOn (magneticLogPotential α lam) (Ioo a b) m

/-- Pointwise selected-height duality needs only the actual two gap selections. -/
theorem selected_height_duality_of_selection (α : ℝ) {label lam m mdual : ℝ}
    (hlam : 0 < lam) (hm : IsSelectedGapEnergy α label lam m)
    (hmdual : IsSelectedGapEnergy α label lam⁻¹ mdual) :
    magneticLogPotential α lam m = Real.log lam + magneticLogPotential α lam⁻¹ mdual := by
  obtain ⟨a,b,hgap,hm,hmax⟩ := hm
  obtain ⟨c,d,hgapdual,hmdual,hmaxdual⟩ := hmdual
  exact selected_height_duality α hlam hgap hgapdual hm hmdual hmax hmaxdual

/-- The actual selected AMO height has derivative 1/2 at critical coupling.
Selection and differentiability are local branch premises, so this does not
presume regularity for a collapsed gap or use duality to prove gap opening. -/
-- Manuscript Corollary 4.2.
theorem selected_critical_height_derivative (α label : ℝ) (energy : ℝ → ℝ) {d : ℝ}
    (hselected : ∀ᶠ t : ℝ in 𝓝 1, IsSelectedGapEnergy α label t (energy t))
    (hd : HasDerivAt (fun t => magneticLogPotential α t (energy t)) d 1) : d = 1/2 := by
  let height := fun t => magneticLogPotential α t (energy t)
  have hinv : Tendsto (fun t : ℝ => t⁻¹) (𝓝 1) (𝓝 1) := by
    simpa only [inv_one] using (continuousAt_inv₀ (by norm_num : (1 : ℝ) ≠ 0)).tendsto
  have hdual : ∀ᶠ t : ℝ in 𝓝 1, height t = Real.log t + height t⁻¹ := by
    filter_upwards [hselected, hinv.eventually hselected,
      Ioi_mem_nhds (by norm_num : (0 : ℝ) < 1)] with t ht hti htpos
    exact selected_height_duality_of_selection α htpos ht hti
  have hdinv : HasDerivAt (fun t : ℝ => height t⁻¹) (-d) 1 := by
    have hd' : HasDerivAt height d (1 : ℝ)⁻¹ := by simpa only [inv_one] using hd
    have h := hd'.comp 1 (hasDerivAt_inv (by norm_num : (1 : ℝ) ≠ 0))
    simpa only [inv_one, one_pow, neg_mul, mul_neg, mul_one, one_mul] using h
  have hsum : HasDerivAt (fun t : ℝ => Real.log t + height t⁻¹) (1-d) 1 := by
    simpa only [inv_one, sub_eq_add_neg] using
      (Real.hasDerivAt_log (by norm_num : (1 : ℝ) ≠ 0)).add hdinv
  have hsecond : HasDerivAt height (1-d) 1 :=
    hsum.congr_of_eventuallyEq hdual
  have heq := hd.unique hsecond
  linarith

end DTMAudit.ManuscriptHeightDuality

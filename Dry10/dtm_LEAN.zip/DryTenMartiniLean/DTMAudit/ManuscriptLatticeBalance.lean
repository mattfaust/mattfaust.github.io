import DTMAudit.ManuscriptLatticeStationarity
import DTMAudit.ChiralMagneticBalance

/-!
# The manuscript's diagonal-column proof of magnetic balance

The existing coordinate calculations are used only for the actual operator
columns, diagonal geometry, and change of basis. The stationary-source result
is proved anew by the two projection-pairing cancellations written in the text.
-/

set_option autoImplicit false
set_option maxHeartbeats 800000
noncomputable section
namespace DTMAudit.ManuscriptLatticeBalance
open CriticalDTM CriticalDTM.Chiral DTMCompanion.ChiralGauge
open DTMAudit.ChiralMagneticBalance
open scoped InnerProductSpace

/-- The manuscript's sine/cosine boundary identity, derived from the concrete
columns and the signs of their four neighboring sites. -/
theorem boundary_column (α lam : ℝ) {σ n : ℤ}
    (hσ : σ = 1 ∨ σ = -1) (hn : n ≠ 0) :
    (Real.sin (Real.pi*α*(n : ℝ)) : ℂ) • Lz (mean α lam (basis n (σ*n))) =
      (-Complex.I * (σ : ℂ) * (Real.sign (n : ℝ) : ℂ) *
        (Real.cos (Real.pi*α*(n : ℝ)) : ℂ)) •
        difference α lam (basis n (σ*n)) := by
  have hoP := outgoing_angular lam hσ (Or.inl rfl) hn
  have hoM := outgoing_angular lam hσ (Or.inr rfl) hn
  rw [mean_boundary_column α lam hσ n, map_smul, map_add, hoP, hoM,
    difference_boundary_column α lam hσ n]
  have hsq : (σ : ℂ)^2 = 1 := by rcases hσ with rfl | rfl <;> norm_num
  simp only [Int.cast_one, Int.cast_neg, one_mul, neg_one_mul,
    smul_add, smul_sub, smul_smul]
  ring_nf
  simp [Complex.I_sq, hsq, sub_eq_add_neg]

/-- Irrationality and stationarity kill each nonzero diagonal column pairing. -/
theorem punctured_column_pairing {α : ℝ} (hα : Irrational α) (lam : ℝ)
    (v : LatticeHilbert) (hv : difference α lam v = 0)
    {σ n : ℤ} (hσ : σ = 1 ∨ σ = -1) (hn : n ≠ 0) :
    ⟪v, Lz (mean α lam (basis n (σ*n)))⟫_ℂ = 0 := by
  have h := congrArg (fun u : LatticeHilbert => ⟪v,u⟫_ℂ)
    (boundary_column α lam hσ hn)
  dsimp only at h
  rw [inner_smul_right, inner_smul_right, ← difference_symmetric, hv,
    inner_zero_left, mul_zero] at h
  have hsin : (Real.sin (Real.pi*α*(n : ℝ)) : ℂ) ≠ 0 := by
    exact_mod_cast sin_pi_mul_irrational_int_ne_zero hα hn
  exact (mul_eq_zero.mp h).resolve_left hsin

/-- Expanding the diagonal projection in its basis leaves only the origin.
This coefficient proof justifies that expansion for arbitrary ℓ² vectors. -/
theorem diagonal_pairing_source {α : ℝ} (hα : Irrational α) (lam : ℝ)
    (v : LatticeHilbert) (hv : difference α lam v = 0) :
    axisProjection (mean α lam (Lz v)) =
      Spin.rootProjection hilbertRoot (mean α lam (Lz v)) := by
  have hcoeff {σ n : ℤ} (hσ : σ = 1 ∨ σ = -1) (hn : n ≠ 0) :
      mean α lam (Lz v) (n,σ*n) = 0 := by
    rw [← basis_inner, ← mean_symmetric, ← Lz_symmetric,
      ← inner_conj_symm (Lz (mean α lam (basis n (σ*n)))) v,
      punctured_column_pairing hα lam v hv hσ hn, map_zero]
  apply lp.ext
  funext s
  by_cases hroot : s = origin
  · subst s
    simp [axisProjection_apply, axisWeight, Spin.rootProjection_apply,
      inner_hilbertRoot, hilbertRoot_apply, latticeRoot, origin]
  · have hr : hilbertRoot s = 0 := by
      simp [hilbertRoot_apply, latticeRoot, Pi.single_apply, hroot]
    simp only [Spin.rootProjection_apply, lp.coeFn_smul, Pi.smul_apply,
      smul_eq_mul, hr, mul_zero, axisProjection_apply]
    by_cases hs : |s.1| = |s.2|
    · have hz : mean α lam (Lz v) s = 0 := by
        rcases boundary_four_rays ⟨hroot,hs⟩ with ⟨n,hn,rfl⟩ | ⟨n,hn,rfl⟩ |
          ⟨n,hn,rfl⟩ | ⟨n,hn,rfl⟩
        · simpa using hcoeff (σ := 1) (Or.inl rfl) (ne_of_gt hn)
        · simpa using hcoeff (σ := 1) (Or.inl rfl) (ne_of_lt hn)
        · simpa using hcoeff (σ := -1) (Or.inr rfl) (ne_of_gt hn)
        · simpa using hcoeff (σ := -1) (Or.inr rfl) (ne_of_lt hn)
      rw [hz, mul_zero]
    · simp [axisWeight, hs]

/-- First of the two separate origin cancellations in the human proof. -/
theorem first_projection_pairing {α : ℝ} (hα : Irrational α) (lam : ℝ)
    (v w : LatticeHilbert) (hv : difference α lam v = 0) :
    ⟪v,Lz (mean α lam (axisProjection w))⟫_ℂ =
      ⟪v,Lz (mean α lam hilbertRoot)⟫_ℂ * ⟪hilbertRoot,w⟫_ℂ := by
  rw [← Lz_symmetric, ← mean_symmetric, ← axisProjection_symmetric,
    diagonal_pairing_source hα lam v hv, Spin.rootProjection_apply,
    inner_smul_left, inner_conj_symm, mean_symmetric, Lz_symmetric]

/-- Second origin cancellation, using stationarity of w. -/
theorem second_projection_pairing {α : ℝ} (hα : Irrational α) (lam : ℝ)
    (v w : LatticeHilbert) (hw : difference α lam w = 0) :
    ⟪v,axisProjection (mean α lam (Lz w))⟫_ℂ =
      ⟪v,hilbertRoot⟫_ℂ * ⟪Lz (mean α lam hilbertRoot),w⟫_ℂ := by
  rw [diagonal_pairing_source hα lam w hw, Spin.rootProjection_apply,
    inner_smul_right, ← mean_symmetric, ← Lz_symmetric, mul_comm]

/-- Every sector-changing nearest-neighbor bond touches the diagonal. -/
theorem diagonal_support (α lam : ℝ) (w : LatticeHilbert) :
    current α lam w = Lz (mean α lam (axisProjection w)) -
      axisProjection (mean α lam (Lz w)) := by
  rw [current_row_column]
  simp only [current, ContinuousLinearMap.sub_apply, ContinuousLinearMap.mul_apply,
    map_sub, diagonal_Lz, Lz_diagonal, map_zero, sub_zero, zero_sub]
  abel

/-- Subtract the two projection pairings, exactly as in the manuscript. -/
-- Manuscript Lemma 2.4.
theorem magnetic_balance {α : ℝ} (hα : Irrational α) (lam : ℝ)
    (v w : LatticeHilbert) (hv : difference α lam v = 0) (hw : difference α lam w = 0) :
    ⟪v,current α lam w⟫_ℂ =
      ⟪v,Lz (mean α lam hilbertRoot)⟫_ℂ * ⟪hilbertRoot,w⟫_ℂ -
      ⟪v,hilbertRoot⟫_ℂ * ⟪Lz (mean α lam hilbertRoot),w⟫_ℂ := by
  rw [diagonal_support, inner_sub_right, first_projection_pairing hα lam v w hv,
    second_projection_pairing hα lam v w hw]

/-- Return the balance identity to the original physical lattice coordinates;
stationarity here comes from the direct commuting-projector proof. -/
theorem source_balance {α : ℝ} (hα : Irrational α) (lam : ℝ)
    (v w : LatticeHilbert) (hv : v ∈ FermiSpan.thresholdSourceSpace α lam)
    (hw : w ∈ FermiSpan.thresholdSourceSpace α lam) :
    ⟪v,Lz (averageOperator α lam w) - averageOperator α lam (Lz w)⟫_ℂ =
      ⟪v,Lz (averageOperator α lam hilbertRoot)⟫_ℂ * ⟪hilbertRoot,w⟫_ℂ -
      ⟪v,hilbertRoot⟫_ℂ * ⟪Lz (averageOperator α lam hilbertRoot),w⟫_ℂ := by
  have hstationary (u : LatticeHilbert) (hu : u ∈ FermiSpan.thresholdSourceSpace α lam) :
      difference α lam (SymmetricGauge.unitary α u) = 0 := by
    simp only [difference, transport_unitary,
      ManuscriptLatticeStationarity.sources_stationary α lam u hu, map_zero]
  have h := magnetic_balance hα lam
    (SymmetricGauge.unitary α v) (SymmetricGauge.unitary α w)
    (hstationary v hv) (hstationary w hw)
  rw [← SymmetricGauge.unitary_root α] at h
  simpa only [current_unitary_commutator, mean, transport_unitary, unitary_Lz,
    LinearIsometryEquiv.inner_map_map] using h

end DTMAudit.ManuscriptLatticeBalance

import DTMAudit.ManuscriptLatticeBalance
import DTMAudit.PhaseDerivative

/-!
# The manuscript's arbitrary-test quotient and second-resolvent response

The order is the human proof: origin return and source calibration; magnetic
balance with w = R e and arbitrary v; then v = R² e, cancellation of one
physical resolvent, and division only after establishing the positive denominator. No resolvent of H+
and no invariance of the source space under Lz is asserted or used.
-/

set_option autoImplicit false
set_option maxHeartbeats 800000
noncomputable section
namespace DTMAudit.ManuscriptLatticeResponse
open CriticalDTM CriticalDTM.Chiral DTMAudit.FermiSpan
open scoped InnerProductSpace Topology

/-- The resolvent equation uses H+ only on the already stationary return. -/
theorem resolvent_equation_plus {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    averageOperator α lam r = (E : ℂ) • r - hilbertRoot := by
  dsimp only
  rw [ManuscriptLatticeStationarity.sources_mean_eq α lam _
    (ManuscriptLatticeStationarity.resolvent_and_square_mem α lam (E : ℂ) hE).1]
  apply eq_sub_iff_add_eq.mpr
  simpa only [add_comm] using (sub_eq_iff_eq_add.mp
    (actual_resolvent_left_identity (hOperator α (lam : ℂ)) _ hE hilbertRoot)).symm

/-- The origin-return identity is derived in the response proof itself. -/
theorem origin_return {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    ⟪resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot,
      averageOperator α lam hilbertRoot⟫_ℂ = -1 := by
  have hz : ⟪resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot,hilbertRoot⟫_ℂ = 0 := by
    rw [← inner_conj_symm, hzero, map_zero]
  rw [← averageOperator_symmetric, resolvent_equation_plus hE,
    inner_sub_left, inner_smul_left, hz, mul_zero, inner_self_eq_norm_sq_to_K,
    Spin.magnetic_root_unit]
  norm_num

/-- Apply magnetic balance with arbitrary v, before any division or R² choice. -/
theorem arbitrary_test_balance {α lam E : ℝ} (hα : Irrational α)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0)
    (v : LatticeHilbert) (hv : v ∈ thresholdSourceSpace α lam) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    ⟪v,Lz (averageOperator α lam r) - averageOperator α lam (Lz r)⟫_ℂ =
      -⟪v,hilbertRoot⟫_ℂ * ⟪hilbertRoot,averageOperator α lam (Lz r)⟫_ℂ := by
  dsimp only
  rw [ManuscriptLatticeBalance.source_balance hα lam v _ hv
      (ManuscriptLatticeStationarity.resolvent_and_square_mem α lam (E : ℂ) hE).1,
    hzero, mul_zero, zero_sub, Lz_symmetric, averageOperator_symmetric]
  ring

/-- The same resolvent equation and Lz e = 0 evaluate the commutator. -/
theorem commutator_resolvent {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    Lz (averageOperator α lam r) - averageOperator α lam (Lz r) =
      (E : ℂ) • Lz r - averageOperator α lam (Lz r) := by
  dsimp only
  rw [resolvent_equation_plus hE, map_sub, map_smul, Lz_root, sub_zero]

/-- The denominator becomes a strictly positive norm square at v = R² e. -/
theorem second_return_denominator {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    ⟪resolvent (hOperator α (lam : ℂ)) (E : ℂ) r,hilbertRoot⟫_ℂ =
        ((‖r‖^2 : ℝ) : ℂ) ∧ 0 < ‖r‖^2 := by
  dsimp only
  constructor
  · rw [(real_resolvent_isSelfAdjoint _ (hOperator_isSelfAdjoint α lam) E).isSymmetric.apply_clm,
      inner_self_eq_norm_sq_to_K, Complex.ofReal_pow]
    rfl
  · exact sq_pos_of_pos (norm_pos_iff.mpr
      (actual_resolvent_column_ne_zero _ hilbertRoot hilbertRoot_ne_zero _ hE))

/-- Moving the self-adjoint pencil to R² e cancels precisely one resolvent. -/
theorem second_return_cancellation {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    ⟪resolvent (hOperator α (lam : ℂ)) (E : ℂ) r,
      Lz (averageOperator α lam r) - averageOperator α lam (Lz r)⟫_ℂ =
      ⟪r,Lz r⟫_ℂ := by
  let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
  let s := resolvent (hOperator α (lam : ℂ)) (E : ℂ) r
  have hs : (E : ℂ) • s - averageOperator α lam s = r := by
    rw [ManuscriptLatticeStationarity.sources_mean_eq α lam s
      (ManuscriptLatticeStationarity.resolvent_and_square_mem α lam (E : ℂ) hE).2]
    exact actual_resolvent_left_identity _ _ hE r
  change ⟪s,Lz (averageOperator α lam r) - averageOperator α lam (Lz r)⟫_ℂ = _
  rw [commutator_resolvent hE, inner_sub_right, ← averageOperator_symmetric]
  change ⟪s,(E : ℂ) • Lz r⟫_ℂ - ⟪averageOperator α lam s,Lz r⟫_ℂ = ⟪r,Lz r⟫_ℂ
  calc
    _ = ⟪(E : ℂ) • s - averageOperator α lam s,Lz r⟫_ℂ := by
      simp only [inner_sub_left, inner_smul_left, inner_smul_right, Complex.conj_ofReal]
    _ = _ := by rw [hs]

/-- Choose R² e in the undivided arbitrary-test balance. Cancel one resolvent
and establish the positive denominator ‖R e‖² before making the quotient. -/
theorem origin_angular_quotient {α lam E : ℝ} (hα : Irrational α)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    ⟪hilbertRoot,averageOperator α lam (Lz r)⟫_ℂ =
      -⟪r,Lz r⟫_ℂ / ((‖r‖^2 : ℝ) : ℂ) := by
  have hb := arbitrary_test_balance hα hE hzero
    (resolvent (hOperator α (lam : ℂ)) (E : ℂ)
      (resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot))
    (ManuscriptLatticeStationarity.resolvent_and_square_mem α lam (E : ℂ) hE).2
  have hd := second_return_denominator hE
  dsimp only at hb hd ⊢
  rw [second_return_cancellation hE, hd.1] at hb
  have hd0 : ((‖resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot‖^2 : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast ne_of_gt hd.2
  apply (eq_div_iff hd0).mpr
  linear_combination hb

/-- The sector sign on a single lattice basis vector, directly from Lz. -/
theorem Lz_single (n m : ℤ) (a : ℂ) :
    Lz (lp.single 2 (n,m) a) =
      (Real.sign ((n : ℝ)^2-(m : ℝ)^2) : ℂ) • lp.single 2 (n,m) a := by
  apply lp.ext
  funext s
  rcases s with ⟨p,q⟩
  rw [Lz_apply]
  by_cases hs : (p,q) = (n,m)
  · obtain ⟨rfl,rfl⟩ := Prod.mk.inj hs
    simp
  · simp [lp.single_apply_ne, hs]

/-- The physical derivative column is calibrated by its four lattice bonds. -/
theorem source_calibration (α lam : ℝ) :
    (lam : ℂ) • verticalRoot = (1/2 : ℂ) •
      (averageOperator α lam hilbertRoot - Lz (averageOperator α lam hilbertRoot)) := by
  rw [averageOperator_eq_on_common α lam hilbertRoot (root_mem_commonSpace α lam),
    hOperator_root_expansion]
  simp only [map_add, map_smul, Lz_single]
  norm_num [Real.sign, verticalRoot]
  module

/-- The source insertion equals the height-origin expression, before magnetic
balance is applied. This uses only calibration and the origin-return equation. -/
theorem height_origin {α lam E : ℝ}
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    lam * (-(⟪r,verticalRoot⟫_ℂ).re) = 1/2 +
      (⟪hilbertRoot,averageOperator α lam (Lz r)⟫_ℂ).re / 2 := by
  let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
  have hc := congrArg (fun u : LatticeHilbert => (⟪r,u⟫_ℂ).re) (source_calibration α lam)
  have hp : (⟪r,Lz (averageOperator α lam hilbertRoot)⟫_ℂ).re =
      (⟪hilbertRoot,averageOperator α lam (Lz r)⟫_ℂ).re := by
    rw [← Lz_symmetric, ← averageOperator_symmetric]
    exact inner_re_symm (𝕜 := ℂ) _ _
  dsimp only at hc ⊢
  rw [inner_smul_right, inner_smul_right, inner_sub_right, origin_return hE hzero] at hc
  have half : (1/2 : ℂ) = ((1/2 : ℝ) : ℂ) := by norm_num
  rw [half, Complex.re_ofReal_mul, Complex.re_ofReal_mul, Complex.sub_re] at hc
  norm_num at hc
  rw [hp] at hc
  change lam * -(⟪r,verticalRoot⟫_ℂ).re =
    1/2 + (⟪hilbertRoot,averageOperator α lam (Lz r)⟫_ℂ).re / 2
  linarith

/-- The norm bound follows directly from the pointwise values of sgn. -/
theorem Lz_contracts (u : LatticeHilbert) : ‖Lz u‖ ≤ ‖u‖ := by
  have hnorm (v : LatticeHilbert) : ‖v‖^2 = ∑' s, ‖v s‖^2 := by
    simpa using lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) v
  have hsumm (v : LatticeHilbert) : Summable (fun s => ‖v s‖^2) := by
    simpa using (lp.memℓp v).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  apply (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [hnorm, hnorm]
  apply Summable.tsum_le_tsum _ (hsumm _) (hsumm _)
  rintro ⟨n,m⟩
  rw [Lz_apply]
  rcases Real.sign_apply_eq ((n : ℝ)^2-(m : ℝ)^2) with h | h | h <;>
    simp [h, sq_nonneg]

/-- The final response quotient, proved along the literal R² test-vector route. -/
theorem insertion_response {α lam E : ℝ} (hα : Irrational α)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hzero : ⟪hilbertRoot,resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot⟫_ℂ = 0) :
    let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
    lam * (-(⟪r,verticalRoot⟫_ℂ).re) =
        (⟪r,r-Lz r⟫_ℂ).re / (2*‖r‖^2) ∧
      lam * (-(⟪r,verticalRoot⟫_ℂ).re) ∈ Set.Icc (0 : ℝ) 1 := by
  let r := resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot
  have hn := (second_return_denominator hE).2
  change 0 < ‖r‖^2 at hn
  have hq := congrArg Complex.re (origin_angular_quotient hα hE hzero)
  change (⟪hilbertRoot,averageOperator α lam (Lz r)⟫_ℂ).re = _ at hq
  simp only [Complex.div_ofReal_re, Complex.neg_re] at hq
  have hd := height_origin hE hzero
  change lam * -(⟪r,verticalRoot⟫_ℂ).re = _ at hd
  rw [hq] at hd
  have hself : (⟪r,r⟫_ℂ).re = ‖r‖^2 := inner_self_eq_norm_sq (𝕜 := ℂ) r
  have heq : lam * -(⟪r,verticalRoot⟫_ℂ).re = (⟪r,r-Lz r⟫_ℂ).re / (2*‖r‖^2) := by
    rw [hd, inner_sub_right, Complex.sub_re, hself]
    change 1/2 + -(⟪r,Lz r⟫_ℂ).re / ‖r‖^2 / 2 = _
    field_simp [ne_of_gt hn]
    ring
  refine ⟨heq, ?_⟩
  have hb : |(⟪r,Lz r⟫_ℂ).re| ≤ ‖r‖^2 := by
    calc
      |(⟪r,Lz r⟫_ℂ).re| ≤ ‖⟪r,Lz r⟫_ℂ‖ := Complex.abs_re_le_norm _
      _ ≤ ‖r‖ * ‖Lz r‖ := norm_inner_le_norm _ _
      _ ≤ ‖r‖ * ‖r‖ := mul_le_mul_of_nonneg_left (Lz_contracts r) (norm_nonneg _)
      _ = ‖r‖^2 := (pow_two _).symm
  rw [heq, inner_sub_right, Complex.sub_re, hself]
  exact ⟨div_nonneg (by linarith [(abs_le.mp hb).2]) (by positivity),
    (div_le_one (by positivity : 0 < 2*‖r‖^2)).mpr (by linarith [(abs_le.mp hb).1])⟩

end DTMAudit.ManuscriptLatticeResponse

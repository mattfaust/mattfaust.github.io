import DTMAudit.ClosedFermiCuts
import DTMAudit.FermiSpan

/-!
# Direct lattice proof of stationary spectral sources

This follows the manuscript's proof in its original lattice representation:
the concrete magnetic actions commute, agree at the origin, and commute with
the actual spectral cut. No vectorized stationary-source theorem is used.
The closed source space is the independently defined span of Fermi sources.
-/

set_option autoImplicit false
noncomputable section
namespace DTMAudit.ManuscriptLatticeStationarity
open CriticalDTM CriticalDTM.Chiral
open DTMAudit.SpectralSources DTMAudit.FermiSpan DTMAudit.FullFermiProjection
open scoped InnerProductSpace

/-- The two concrete lattice actions commute and have the same origin column. -/
theorem commuting_common_origin (α lam : ℝ) :
    Commute (hOperator α (lam : ℂ)) (conjugateOperator α (lam : ℂ)) ∧
    hOperator α (lam : ℂ) hilbertRoot = conjugateOperator α (lam : ℂ) hilbertRoot := by
  constructor
  · apply ContinuousLinearMap.ext
    intro u
    exact magnetic_operators_commute α (lam : ℂ) u
  · exact magnetic_operators_agree_on_root α (lam : ℂ)

/-- Move each Hamiltonian through the Fermi projector, then use their common
origin column. This is the displayed spectral-calculus calculation in Section 2. -/
theorem threshold_actions_agree (α lam E : ℝ) :
    hOperator α (lam : ℂ) (thresholdSource α lam E) =
      conjugateOperator α (lam : ℂ) (thresholdSource α lam E) := by
  rw [← lowerProjection_root]
  have hleft := congrArg (fun A : MagneticBoundedOperator => A hilbertRoot)
    (lowerProjection_commute_h α lam E).eq
  have hright := congrArg (fun A : MagneticBoundedOperator => A hilbertRoot)
    (lowerProjection_commute_conjugate α lam E).eq
  simp only [ContinuousLinearMap.mul_apply] at hleft hright
  rw [← hleft, (commuting_common_origin α lam).2, hright]

/-- The literal closed-cut Fermi projection in the manuscript has the same
stationarity, including when the cut energy lies in the spectrum. -/
-- Manuscript Lemma 2.2.
theorem closed_fermi_stationary (α lam E : ℝ) :
    (hOperator α (lam : ℂ) - conjugateOperator α (lam : ℂ))
      (SpectralPVM.indicatorProjection α lam
        (ClosedFermiCuts.closedLowerSpectrum α lam E)
        (ClosedFermiCuts.closedLowerSpectrum_measurable α lam E) hilbertRoot) = 0 := by
  rw [ClosedFermiCuts.closedLowerProjection_eq_lower, lowerProjection_root]
  exact sub_eq_zero.mpr (threshold_actions_agree α lam E)

/-- Linearity and continuity extend the equality to the closed Fermi span. -/
theorem sources_actions_agree (α lam : ℝ) (u : MagneticHilbert)
    (hu : u ∈ thresholdSourceSpace α lam) :
    hOperator α (lam : ℂ) u = conjugateOperator α (lam : ℂ) u := by
  have hspan : thresholdSourceSpace α lam ≤
      LinearMap.ker (hOperator α (lam : ℂ) -
        conjugateOperator α (lam : ℂ)).toLinearMap := by
    apply Submodule.topologicalClosure_minimal
    · apply Submodule.span_le.mpr
      rintro _ ⟨E, rfl⟩
      exact sub_eq_zero.mpr (threshold_actions_agree α lam E)
    · exact isClosed_eq (hOperator α (lam : ℂ) -
        conjugateOperator α (lam : ℂ)).continuous continuous_const
  exact sub_eq_zero.mp (hspan hu)

theorem sources_common (α lam : ℝ) (u : MagneticHilbert)
    (hu : u ∈ thresholdSourceSpace α lam) : u ∈ commonSpace α lam :=
  (mem_commonSpace α lam u).mpr (sources_actions_agree α lam u hu)

theorem sources_stationary (α lam : ℝ) (u : MagneticHilbert)
    (hu : u ∈ thresholdSourceSpace α lam) : Paired.differenceOperator α lam u = 0 := by
  simp [Paired.differenceOperator, sources_actions_agree α lam u hu]

theorem sources_mean_eq (α lam : ℝ) (u : MagneticHilbert)
    (hu : u ∈ thresholdSourceSpace α lam) :
    averageOperator α lam u = hOperator α (lam : ℂ) u :=
  averageOperator_eq_on_common α lam u (sources_common α lam u hu)

/-- Spectral polynomial approximation gives the invariance required in the
manuscript after the direct commuting-projector calculation. -/
theorem sources_left_invariant (α lam : ℝ) (u : MagneticHilbert)
    (hu : u ∈ thresholdSourceSpace α lam) :
    hOperator α (lam : ℂ) u ∈ thresholdSourceSpace α lam := by
  rw [thresholdSourceSpace_eq_cyclicSpace] at hu ⊢
  exact hOperator_mem_cyclicSpace α lam u hu

theorem source_mem (α lam : ℝ) : hilbertRoot ∈ thresholdSourceSpace α lam := by
  rw [thresholdSourceSpace_eq_cyclicSpace]
  exact root_mem_cyclicSpace α lam

/-- The actual physical resolvent preserves the Fermi source space. -/
theorem resolvent_mem (α lam : ℝ) (z : ℂ)
    (hz : z ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (u : MagneticHilbert) (hu : u ∈ thresholdSourceSpace α lam) :
    resolvent (hOperator α (lam : ℂ)) z u ∈ thresholdSourceSpace α lam := by
  rw [thresholdSourceSpace_eq_cyclicSpace] at hu ⊢
  exact resolvent_mem_cyclicSpace α lam z hz u hu

/-- Both test vectors used later, R e and R² e, are in the stationary space. -/
theorem resolvent_and_square_mem (α lam : ℝ) (z : ℂ)
    (hz : z ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    resolvent (hOperator α (lam : ℂ)) z hilbertRoot ∈ thresholdSourceSpace α lam ∧
    resolvent (hOperator α (lam : ℂ)) z
      (resolvent (hOperator α (lam : ℂ)) z hilbertRoot) ∈ thresholdSourceSpace α lam := by
  have hr := resolvent_mem α lam z hz hilbertRoot (source_mem α lam)
  exact ⟨hr, resolvent_mem α lam z hz _ hr⟩

end DTMAudit.ManuscriptLatticeStationarity

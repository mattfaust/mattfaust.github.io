import DTM.Background.Support.MagneticIntegralBridge

/-! Lemma 3.5: differentiate the positive square of the physical pencil.
The local logarithm calculus is applied before the two square-product terms
are collapsed by the canonical trace. No logarithmic contour is used. -/
noncomputable section
set_option maxHeartbeats 1200000
namespace DTMAudit.ManuscriptPositiveSquare
open CriticalDTM MeasureTheory Filter Set
open scoped Topology

/-- The uncontracted positive-square logarithm derivative. The fixed positive
rescaling, connected neighborhood, and uniform bounds are constructed from
invertibility and C1 regularity. This applies the established positive CFC-log
calculus to `C²` with its genuine noncommutative product-rule derivative. -/
theorem half_square_log_hasDerivAt {A : Type*} [CStarAlgebra A] [Nontrivial A]
    (trace : A →L[ℝ] ℝ) (hcyclic : CyclicTrace trace)
    (C D : ℝ → A) (x : ℝ)
    (hderiv : ∀ᶠ t in 𝓝 x, HasDerivAt C (D t) t)
    (hself : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (C t))
    (hD : ContinuousAt D x) (hunit : IsUnit (C x)) :
    HasDerivAt (fun t => trace (CFC.log ((C t) ^ 2)) / 2)
      (trace ((Ring.inverse (C x)) ^ 2 * (D x * C x + C x * D x)) / 2) x := by
  have hCx : ContinuousAt C x := hderiv.self_of_nhds.continuousAt
  obtain ⟨c, hc, hscale⟩ := exists_positive_selfAdjoint_square_rescaling
    hself.self_of_nhds hunit
  have hscale' : ‖1 - c • (C x) ^ 2‖ < 1 := by simpa only [pow_two] using hscale
  let r : ℝ := (‖1 - c • (C x) ^ 2‖ + 1) / 2
  let M : ℝ := ‖D x * C x + C x * D x‖ + 1
  have hr0 : 0 ≤ r := by dsimp [r]; positivity
  have hr1 : r < 1 := by dsimp [r]; linarith
  have hdeflt : ‖1 - c • (C x) ^ 2‖ < r := by dsimp [r]; linarith
  have hDlt : ‖D x * C x + C x * D x‖ < M := by dsimp [M]; linarith
  have hcontdef : ContinuousAt (fun t => ‖1 - c • (C t) ^ 2‖) x :=
    (continuousAt_const.sub ((hCx.pow 2).const_smul c)).norm
  have hcontD : ContinuousAt (fun t => ‖D t * C t + C t * D t‖) x :=
    ((hD.mul hCx).add (hCx.mul hD)).norm
  have hnearUnit : ∀ᶠ t in 𝓝 x, IsUnit (C t) :=
    hCx.eventually (Units.isOpen.mem_nhds hunit)
  have hnearDef : ∀ᶠ t in 𝓝 x, ‖1 - c • (C t) ^ 2‖ < r :=
    hcontdef.eventually (gt_mem_nhds hdeflt)
  have hnearD : ∀ᶠ t in 𝓝 x, ‖D t * C t + C t * D t‖ < M :=
    hcontD.eventually (gt_mem_nhds hDlt)
  obtain ⟨ε, hε, hball⟩ := Metric.mem_nhds_iff.mp
    (hderiv.and (hself.and (hnearUnit.and (hnearDef.and hnearD))))
  have hsq : ∀ t ∈ Metric.ball x ε,
      HasDerivAt (fun u => (C u) ^ 2) (D t * C t + C t * D t) t := by
    intro t ht
    simpa only [pow_two] using ((hball ht).1).mul ((hball ht).1)
  have hp : ∀ t ∈ Metric.ball x ε, ∀ y ∈ spectrum ℝ ((C t) ^ 2), 0 < y := by
    intro t ht y hy
    exact selfAdjoint_square_spectrum_pos (hball ht).2.1 (hball ht).2.2.1
      (by simpa only [pow_two] using hy)
  have hlog := trace_cfc_log_hasDerivAt_of_scaled_defect trace hcyclic
    (fun t => (C t) ^ 2) (fun t => D t * C t + C t * D t)
    (Metric.ball x ε) Metric.isOpen_ball (convex_ball x ε).isPreconnected
    c r M x hc hr0 hr1 (Metric.mem_ball_self hε) hsq
    (fun t ht => ((hball ht).2.1).pow 2) hp
    (fun t ht => (hball ht).2.2.2.1.le)
    (fun t ht => (hball ht).2.2.2.2.le)
  simpa only [Ring.inverse_pow] using hlog.div_const 2

local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)
local instance (α : ℝ) : Module ℝ (magneticAlgebra α) :=
  @Algebra.toModule ℝ (magneticAlgebra α) _ _
    (magneticAlgebra_realNormedAlgebra α).toAlgebra

/-- The DOS integral is exactly one half of the canonical trace logarithm
of the square of `E·1−H`, using spectral calculus and the actual DOS measure. -/
theorem dos_height_eq_half_square_log (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    (∫ y : ℝ, Real.log |E-y| ∂magneticRealSpectralMeasure α lam) =
      magneticTraceReal α (CFC.log ((magneticAlgebraPencil α lam E) ^ 2)) / 2 :=
  (magneticLogPotential_eq_realSpectralIntegral α lam E hE).symm

/-- The moving physical pencil has derivative `E'·1−∂λH`. -/
theorem pencil_path_hasDerivAt (α : ℝ) (energy velocity : ℝ → ℝ) (t : ℝ)
    (he : HasDerivAt energy (velocity t) t) :
    HasDerivAt (fun l => magneticAlgebraPencil α l (energy l))
      (velocity t • (1 : magneticAlgebra α) - magneticAlgebraVertical α) t := by
  have hH := ((hasDerivAt_id t).smul_const (magneticAlgebraVertical α)).const_add
    (⟨hOperator α 0, hOperator_mem_magneticAlgebra α 0⟩ : magneticAlgebra α)
  simpa only [magneticAlgebraPencil, magneticAlgebraHamiltonian, one_smul] using
    (he.smul_const (1 : magneticAlgebra α)).sub hH

/-- The uncontracted manuscript formula `½ τ(R² ((E−H)²)')`, with actual
bounded operators. The energy velocity is retained for the subsequent chain
rule, and specializing it to zero gives the fixed-energy calculation. -/
theorem dos_height_square_path_hasDerivAt (α : ℝ)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ))) :
    HasDerivAt (fun l : ℝ => ∫ y : ℝ, Real.log |energy l-y|
      ∂magneticRealSpectralMeasure α l)
      ((rootTrace ((resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ)) ^ 2 *
        ((velocity lam • (1 : MagneticBoundedOperator) - verticalOperator α) *
          (algebraMap ℂ MagneticBoundedOperator (energy lam : ℂ) - hOperator α (lam : ℂ)) +
         (algebraMap ℂ MagneticBoundedOperator (energy lam : ℂ) - hOperator α (lam : ℂ)) *
          (velocity lam • (1 : MagneticBoundedOperator) - verticalOperator α)))).re / 2) lam := by
  have hp : ∀ᶠ l in 𝓝 lam, HasDerivAt
      (fun l => magneticAlgebraPencil α l (energy l))
      (velocity l • (1 : magneticAlgebra α) - magneticAlgebraVertical α) l := by
    filter_upwards [hU.mem_nhds hlam] with l hl
    exact pencil_path_hasDerivAt α energy velocity l (he l hl)
  have h := half_square_log_hasDerivAt (magneticTraceReal α) (magneticTraceReal_cyclic α)
    (fun l => magneticAlgebraPencil α l (energy l))
    (fun l => velocity l • (1 : magneticAlgebra α) - magneticAlgebraVertical α) lam hp
    (Eventually.of_forall (fun l => magneticAlgebraPencil_isSelfAdjoint α l (energy l)))
    (((hd.continuousAt (hU.mem_nhds hlam)).smul_const (1 : magneticAlgebra α)).sub_const
      (magneticAlgebraVertical α))
    (magneticAlgebraPencil_isUnit α lam (energy lam) (hE lam hlam))
  have hco : magneticTraceReal α
      ((Ring.inverse (magneticAlgebraPencil α lam (energy lam))) ^ 2 *
        ((velocity lam • (1 : magneticAlgebra α) - magneticAlgebraVertical α) *
          magneticAlgebraPencil α lam (energy lam) +
         magneticAlgebraPencil α lam (energy lam) *
          (velocity lam • (1 : magneticAlgebra α) - magneticAlgebraVertical α))) =
      (rootTrace ((resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ)) ^ 2 *
        ((velocity lam • (1 : MagneticBoundedOperator) - verticalOperator α) *
          (algebraMap ℂ MagneticBoundedOperator (energy lam : ℂ) - hOperator α (lam : ℂ)) +
         (algebraMap ℂ MagneticBoundedOperator (energy lam : ℂ) - hOperator α (lam : ℂ)) *
          (velocity lam • (1 : MagneticBoundedOperator) - verticalOperator α)))).re := by
    rw [magneticTraceReal_apply]
    change (rootTrace ((((Ring.inverse (magneticAlgebraPencil α lam (energy lam)) :
      magneticAlgebra α) : MagneticBoundedOperator)) ^ 2 *
        ((velocity lam • (1 : MagneticBoundedOperator) - verticalOperator α) *
          (magneticAlgebraPencil α lam (energy lam) : MagneticBoundedOperator) +
         (magneticAlgebraPencil α lam (energy lam) : MagneticBoundedOperator) *
          (velocity lam • (1 : MagneticBoundedOperator) - verticalOperator α)))).re = _
    rw [magneticAlgebraPencil_inverse_coe α lam (energy lam) (hE lam hlam),
      magneticAlgebraPencil_coe]
  rw [hco] at h
  apply h.congr_of_eventuallyEq
  filter_upwards [hU.mem_nhds hlam] with l hl
  exact dos_height_eq_half_square_log α l (energy l) (hE l hl)

/-- Canonical-trace cyclicity collapses the two actual product-rule terms.
The result explicitly separates the energy and coupling derivatives. -/
theorem physical_square_trace_chain_rule (α lam E v : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    (rootTrace ((resolvent (hOperator α (lam : ℂ)) (E : ℂ)) ^ 2 *
      ((v • (1 : MagneticBoundedOperator) - verticalOperator α) *
        (algebraMap ℂ MagneticBoundedOperator (E : ℂ) - hOperator α (lam : ℂ)) +
       (algebraMap ℂ MagneticBoundedOperator (E : ℂ) - hOperator α (lam : ℂ)) *
        (v • (1 : MagneticBoundedOperator) - verticalOperator α)))).re / 2 =
      v * (rootTrace (resolvent (hOperator α (lam : ℂ)) (E : ℂ))).re -
        (rootTrace (resolvent (hOperator α (lam : ℂ)) (E : ℂ) * verticalOperator α)).re := by
  have h := trace_inverse_square_product_rule (magneticTraceReal α)
    (magneticTraceReal_cyclic α) (magneticAlgebraPencil α lam E)
    (v • (1 : magneticAlgebra α) - magneticAlgebraVertical α)
    (magneticAlgebraPencil_isUnit α lam E hE)
  rw [← Ring.inverse_pow] at h
  simp only [magneticTraceReal_apply] at h
  change (rootTrace
    (((Ring.inverse (magneticAlgebraPencil α lam E) : magneticAlgebra α) :
      MagneticBoundedOperator) ^ 2 *
      ((v • (1 : MagneticBoundedOperator) - verticalOperator α) *
        (magneticAlgebraPencil α lam E : MagneticBoundedOperator) +
       (magneticAlgebraPencil α lam E : MagneticBoundedOperator) *
        (v • (1 : MagneticBoundedOperator) - verticalOperator α)))).re =
    2 * (rootTrace (((Ring.inverse (magneticAlgebraPencil α lam E) : magneticAlgebra α) :
      MagneticBoundedOperator) * (v • (1 : MagneticBoundedOperator) - verticalOperator α))).re at h
  rw [magneticAlgebraPencil_inverse_coe α lam E hE, magneticAlgebraPencil_coe] at h
  rw [h, mul_div_cancel_left₀ _ (by norm_num : (2 : ℝ) ≠ 0), mul_sub,
    mul_smul_comm, mul_one, map_sub]
  simp only [Complex.sub_re]
  rw [← Complex.coe_smul, map_smul]
  simp only [smul_eq_mul, Complex.re_ofReal_mul]

/-- Positive-square differentiation followed by trace cyclicity is the full
ordinary chain rule for the physical DOS height along an energy branch. -/
theorem dos_height_path_trace_hasDerivAt (α : ℝ)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ))) :
    HasDerivAt (fun l : ℝ => ∫ y : ℝ, Real.log |energy l-y|
      ∂magneticRealSpectralMeasure α l)
      (velocity lam * (rootTrace (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ))).re -
       (rootTrace (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) * verticalOperator α)).re) lam := by
  have h := dos_height_square_path_hasDerivAt α energy velocity hU hlam he hd hE
  rw [physical_square_trace_chain_rule α lam (energy lam) (velocity lam) (hE lam hlam)] at h
  exact h

end DTMAudit.ManuscriptPositiveSquare

import DTMAudit.RealThouless
import DTMAudit.ManuscriptCouplingEnergy

/-! The manuscript's potential is the ordinary DOS logarithmic integral.
Its upper semicontinuity is proved by decreasing continuous logarithmic
regularizations, with no positive-part replacement of the potential. -/
noncomputable section
namespace DTMAudit.ManuscriptPotential
open CriticalDTM MeasureTheory Set Filter
open scoped Topology

def height (α : ℝ) (p : ℝ × ℝ) : ℝ :=
  ∫ x : ℝ, Real.log |p.2 - x| ∂magneticRealSpectralMeasure α p.1

theorem regularizations_bddBelow (α : ℝ) (p : ℝ × ℝ) :
    BddBelow (range fun n => magneticRegularizedLogPotential α n p) := by
  refine ⟨0, ?_⟩
  rintro _ ⟨n, rfl⟩
  exact magneticRegularizedLogPotential_nonneg α p.1 p.2 n

theorem height_eq_iInf (α : ℝ) (p : ℝ × ℝ) :
    height α p = ⨅ n : ℕ, magneticRegularizedLogPotential α n p := by
  unfold height
  rw [magneticRealSpectralMeasure_integral_eq_subtype]
  exact (tendsto_nhds_unique
    (tendsto_atTop_ciInf (magneticRegularizedLogPotential_antitone α p)
      (regularizations_bddBelow α p))
    (magneticRegularizedLogPotential_tendsto_singularIntegral α p.1 p.2)).symm

/-- Lemma 3.3: the infimum of the continuous decreasing regularizations. -/
-- Manuscript Lemma 3.3.
theorem height_upperSemicontinuous (α : ℝ) : UpperSemicontinuous (height α) := by
  have heq : height α = fun p => ⨅ n : ℕ, magneticRegularizedLogPotential α n p :=
    funext (height_eq_iInf α)
  rw [heq]
  exact upperSemicontinuous_ciInf (regularizations_bddBelow α) fun n =>
    (magneticRegularizedLogPotential_continuous α n).upperSemicontinuous

theorem height_eq_magneticLogPotential (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    height α (lam, E) = magneticLogPotential α lam E :=
  real_log_integral_eq_resolvent_height α lam E hE

theorem height_spectral_value {α lam : ℝ} (hα : Irrational α) (hlam : 0 < lam)
    (E : ℝ) (hE : E ∈ magneticRealSpectrumSet α lam) :
    height α (lam, E) = max 0 (Real.log lam) := by
  change (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) = _
  rw [← RealThouless.lyapunov_eq_log_integral]
  exact RealThouless.spectral_lyapunov_normalization hα hlam E hE

end DTMAudit.ManuscriptPotential

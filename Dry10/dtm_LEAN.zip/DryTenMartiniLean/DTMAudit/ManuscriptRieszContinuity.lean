import DTMAudit.Paired
import DTM.Background.Labels.MagneticLabelProperties
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.Analysis.Calculus.MeanValue

/-! A fixed local Riesz contour for the actual Fermi projection.
The bound M is held fixed as the coupling varies. Unlike lowerCircleCenter,
this center does not depend on the Hamiltonian at the current coupling.
The static scalar circle calculation is the usual Riesz formula; it does
not use continuity of the continuous functional calculus. -/

noncomputable section
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 200000
namespace DTMAudit.ManuscriptRieszContinuity
open CriticalDTM DTMCompanion.Brown Complex MeasureTheory Set Filter
open scoped Topology ContinuousFunctionalCalculus
local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)
local instance (α : ℝ) : Module ℝ (magneticAlgebra α) :=
  @Algebra.toModule ℝ (magneticAlgebra α) _ _
    (magneticAlgebra_realNormedAlgebra α).toAlgebra

/-- Differentiation of a Banach-valued integral over a fixed compact interval.
Joint continuity of the partial derivative supplies the local uniform bound. -/
private theorem compactInterval_hasDerivAt
    {A : Type*} [NormedAddCommGroup A] [NormedSpace ℝ A] [CompleteSpace A]
    (F D : ℝ → ℝ → A) {a b : ℝ} (hab : a ≤ b)
    {U : Set ℝ} (hU : IsOpen U) {p : ℝ} (hp : p ∈ U)
    (hF : ∀ q ∈ U, ContinuousOn (F q) (Icc a b))
    (hD : ContinuousOn (fun q : ℝ × ℝ => D q.1 q.2) (U ×ˢ Icc a b))
    (hderiv : ∀ q ∈ U, ∀ t ∈ Icc a b, HasDerivAt (fun u => F u t) (D q t) q) :
    HasDerivAt (fun q => ∫ t in a..b, F q t) (∫ t in a..b, D p t) p := by
  obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hU p hp
  have hclosed : Metric.closedBall p (ε / 2) ⊆ U := by
    intro q hq
    apply hball
    rw [Metric.mem_ball]
    exact lt_of_le_of_lt (Metric.mem_closedBall.mp hq) (by linarith)
  have hcompact : IsCompact (Metric.closedBall p (ε / 2) ×ˢ Icc a b) :=
    (isCompact_closedBall p (ε / 2)).prod isCompact_Icc
  obtain ⟨C, hC⟩ := hcompact.exists_bound_of_continuousOn
    (hD.mono (prod_mono hclosed Subset.rfl))
  letI : MeasureSpace (Icc a b) := Measure.Subtype.measureSpace
  letI : IsFiniteMeasure (volume : Measure (Icc a b)) := ⟨by
    rw [Measure.Subtype.volume_univ measurableSet_Icc.nullMeasurableSet]
    exact isCompact_Icc.measure_lt_top⟩
  have hFc : ∀ q ∈ U, Continuous (fun t : Icc a b => F q t) :=
    fun q hq => continuousOn_iff_continuous_restrict.mp (hF q hq)
  have hDc : Continuous (fun t : Icc a b => D p t) := by
    apply continuousOn_iff_continuous_restrict.mp
    exact hD.comp (continuous_const.prodMk continuous_id).continuousOn
      (fun t ht => ⟨hp, ht⟩)
  have hd := (hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := volume) (F := fun q (t : Icc a b) => F q t)
    (F' := fun q (t : Icc a b) => D q t) (bound := fun _ => C) (half_pos hε)
    (by filter_upwards [hU.mem_nhds hp] with q hq
        exact (hFc q hq).aestronglyMeasurable)
    ((hFc p hp).integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _))
    hDc.aestronglyMeasurable
    (ae_of_all _ fun t q hq => hC (q, t) ⟨Metric.mem_closedBall.mpr
      (Metric.mem_ball.mp hq).le, t.property⟩)
    (integrable_const _)
    (ae_of_all _ fun t q hq => hderiv q
      (hclosed (Metric.mem_closedBall.mpr (Metric.mem_ball.mp hq).le)) t t.property)).2
  simpa only [integral_subtype measurableSet_Icc, integral_Icc_eq_integral_Ioc,
    intervalIntegral.integral_of_le hab] using hd

def fixedCircleCenter (_α _lam E M : ℝ) : ℝ :=
  -(M + |E| + 1)

def fixedCircleRadius (α lam E M : ℝ) : ℝ := E - fixedCircleCenter α lam E M

theorem fixedCircleRadius_pos (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M) : 0 < fixedCircleRadius α lam E M := by
  unfold fixedCircleRadius fixedCircleCenter
  have := norm_nonneg (magneticAlgebraHamiltonian α lam)
  have := neg_abs_le E
  linarith

def fixedShiftedSpectralCoordinate (α lam E M : ℝ) : C(BrownComplexSpectrum α lam, ℝ) :=
  brownComplexCoordinate α lam - ContinuousMap.const _ (fixedCircleCenter α lam E M)

theorem fixedShiftedSpectralCoordinate_pos (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (x : BrownComplexSpectrum α lam) : 0 < fixedShiftedSpectralCoordinate α lam E M x := by
  have hx : ‖(x : ℂ)‖ ≤ ‖magneticAlgebraHamiltonian α lam‖ :=
    spectrum.norm_le_norm_of_mem (𝕜 := ℂ) (a := magneticAlgebraHamiltonian α lam) x.property
  have hxre := Complex.abs_re_le_norm (x : ℂ)
  have hneg := neg_abs_le (x : ℂ).re
  change 0 < (x : ℂ).re - (-(M + |E| + 1))
  linarith [abs_nonneg E]

theorem fixedShiftedSpectralCoordinate_lt_iff (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (x : BrownComplexSpectrum α lam) :
    |fixedShiftedSpectralCoordinate α lam E M x| < fixedCircleRadius α lam E M ↔
      (x : ℂ).re < E := by
  rw [abs_of_pos (fixedShiftedSpectralCoordinate_pos α lam E M hM x)]
  change (x : ℂ).re - fixedCircleCenter α lam E M < E - fixedCircleCenter α lam E M ↔ _
  exact sub_lt_sub_iff_right _

theorem fixedCircle_separation (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    ∀ x : BrownComplexSpectrum α lam,
      |fixedShiftedSpectralCoordinate α lam E M x| ≠ fixedCircleRadius α lam E M := by
  intro x hx
  rw [abs_of_pos (fixedShiftedSpectralCoordinate_pos α lam E M hM x)] at hx
  change (x : ℂ).re - fixedCircleCenter α lam E M = E - fixedCircleCenter α lam E M at hx
  have heq : (x : ℂ).re = E := sub_left_injective hx
  have hreal := (magneticAlgebraHamiltonian_isSelfAdjoint α lam).mem_spectrum_eq_re x.property
  have hxreal : (x : ℂ).re ∈ spectrum ℝ (magneticAlgebraHamiltonian α lam) := by
    apply (magneticAlgebraHamiltonian_isSelfAdjoint α lam).coe_mem_spectrum_complex.mp
    rw [← hreal]
    exact x.property
  exact resolvent_energy_not_mem_magneticRealSpectrum α lam E hE (heq ▸ hxreal)

def fixedCircle (α lam E M : ℝ) (θ : ℝ) : ℂ :=
  (fixedCircleCenter α lam E M : ℂ) + (fixedCircleRadius α lam E M : ℂ) * circleMap 0 1 θ

theorem fixedCircle_deriv (α lam E M θ : ℝ) :
    deriv (fixedCircle α lam E M) θ =
      (fixedCircleRadius α lam E M : ℂ) * deriv (circleMap 0 1) θ := by
  simpa only [deriv_circleMap] using
    ((hasDerivAt_circleMap 0 1 θ).const_mul (fixedCircleRadius α lam E M : ℂ)
      |>.const_add (fixedCircleCenter α lam E M : ℂ)).deriv

def fixedCircleInverse (α lam E M θ : ℝ) : magneticAlgebra α :=
  Ring.inverse ((fixedCircle α lam E M θ) • 1 - magneticAlgebraHamiltonian α lam)

theorem fixedCircle_kernel_cfc (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) (θ : ℝ) :
    cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam).isStarNormal
      (spectralCircleKernel (fixedCircleRadius α lam E M) (fixedShiftedSpectralCoordinate α lam E M)
        (fixedCircleRadius_pos α lam E M hM) (fixedCircle_separation α lam E M hM hE) θ) =
      fixedCircleInverse α lam E M θ := by
  let H := magneticAlgebraHamiltonian α lam
  let hH := magneticAlgebraHamiltonian_isSelfAdjoint α lam
  let F := cfcHom (R := ℂ) hH.isStarNormal
  let z := fixedCircle α lam E M θ
  let P : C(spectrum ℂ H, ℂ) := ContinuousMap.const _ z -
    (ContinuousMap.id ℂ).restrict (spectrum ℂ H)
  let K := spectralCircleKernel (fixedCircleRadius α lam E M) (fixedShiftedSpectralCoordinate α lam E M)
    (fixedCircleRadius_pos α lam E M hM) (fixedCircle_separation α lam E M hM hE) θ
  have hP : F P = z • (1 : magneticAlgebra α) - H := by
    dsimp [P]
    rw [map_sub, cfcHom_id]
    congr 1
    exact (F.commutes z).trans (Algebra.algebraMap_eq_smul_one z)
  have hK : K * P = 1 := by
    ext x
    change ((fixedCircleRadius α lam E M : ℂ) * circleMap 0 1 θ -
      fixedShiftedSpectralCoordinate α lam E M x)⁻¹ * (z - (x : ℂ)) = 1
    have heq : z - (x : ℂ) = (fixedCircleRadius α lam E M : ℂ) * circleMap 0 1 θ -
        fixedShiftedSpectralCoordinate α lam E M x := by
      rw [hH.mem_spectrum_eq_re x.property]
      change (fixedCircleCenter α lam E M : ℂ) +
        (fixedCircleRadius α lam E M : ℂ) * circleMap 0 1 θ - (x : ℂ).re =
        (fixedCircleRadius α lam E M : ℂ) * circleMap 0 1 θ -
          ((x : ℂ).re - fixedCircleCenter α lam E M : ℝ)
      push_cast
      ring
    rw [heq]
    exact inv_mul_cancel₀ (scalar_denominator_ne_zero (fixedCircleRadius_pos α lam E M hM)
      (fixedCircle_separation α lam E M hM hE x)
      (circleMap_mem_sphere 0 (by norm_num : (0 : ℝ) ≤ 1) θ))
  have hK' : P * K = 1 := by rw [mul_comm]; exact hK
  have hl : F K * (z • (1 : magneticAlgebra α) - H) = 1 := by
    rw [← hP, ← map_mul, hK, map_one]
  have hh : (z • (1 : magneticAlgebra α) - H) * F K = 1 := by
    rw [← hP, ← map_mul, hK', map_one]
  have hu : IsUnit (z • (1 : magneticAlgebra α) - H) := ⟨⟨_, F K, hh, hl⟩, rfl⟩
  change F K = Ring.inverse (z • (1 : magneticAlgebra α) - H)
  exact left_inv_eq_right_inv hl (Ring.mul_inverse_cancel _ hu)

theorem fixedCircle_resolvent (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) (θ : ℝ) :
    fixedCircle α lam E M θ ∈ resolventSet ℂ (hOperator α (lam : ℂ)) := by
  have halg : fixedCircle α lam E M θ ∈
      resolventSet ℂ (magneticAlgebraHamiltonian α lam) := by
    apply spectrum.not_mem_iff.mp
    intro hz
    let x : BrownComplexSpectrum α lam := ⟨fixedCircle α lam E M θ, hz⟩
    have hreal := (magneticAlgebraHamiltonian_isSelfAdjoint α lam).mem_spectrum_eq_re hz
    have hn := scalar_denominator_ne_zero (fixedCircleRadius_pos α lam E M hM)
      (fixedCircle_separation α lam E M hM hE x)
      (circleMap_mem_sphere 0 (by norm_num : (0 : ℝ) ≤ 1) θ)
    apply hn
    change (fixedCircleRadius α lam E M : ℂ) * circleMap 0 1 θ -
      ((fixedCircle α lam E M θ).re - fixedCircleCenter α lam E M : ℝ) = 0
    rw [Complex.ofReal_sub, ← hreal]
    unfold fixedCircle
    ring
  change IsUnit (algebraMap ℂ MagneticBoundedOperator (fixedCircle α lam E M θ) -
    hOperator α (lam : ℂ))
  have hcoe := (magneticAlgebra α).coe_isUnit.mpr halg
  change IsUnit ((fixedCircle α lam E M θ) • (1 : MagneticBoundedOperator) -
    (magneticAlgebraHamiltonian α lam : MagneticBoundedOperator)) at hcoe
  simpa only [magneticAlgebraHamiltonian_coe, Algebra.algebraMap_eq_smul_one] using hcoe

theorem fixedCircleInverse_continuous (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    Continuous (fixedCircleInverse α lam E M) := by
  have hc := spectralCircleKernel_map_continuous
    (cfcL (R := ℂ) (magneticAlgebraHamiltonian_isSelfAdjoint α lam).isStarNormal)
    (fixedCircleRadius α lam E M) (fixedShiftedSpectralCoordinate α lam E M)
    (fixedCircleRadius_pos α lam E M hM) (fixedCircle_separation α lam E M hM hE)
  simpa only [cfcL_apply, fixedCircle_kernel_cfc α lam E M hM hE] using hc

theorem fixedCircle_deriv_continuous (α lam E M : ℝ) :
    Continuous (deriv (fixedCircle α lam E M)) := by
  change Continuous (fun θ => deriv (fixedCircle α lam E M) θ)
  simp_rw [fixedCircle_deriv, deriv_circleMap]
  exact continuous_const.mul ((continuous_circleMap 0 1).mul continuous_const)

def fixedCircleCoefficient (α lam E M : ℝ) : magneticAlgebra α :=
  (2 * Real.pi * I : ℂ)⁻¹ • ∫ θ in (0 : ℝ)..(2 * Real.pi),
    deriv (circleMap 0 1) θ • fixedCircleInverse α lam E M θ

theorem fixedCircleCoefficient_eq_cfcHom (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    fixedCircleCoefficient α lam E M =
      cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam).isStarNormal
        (spectralCircleCoefficient (fixedCircleRadius α lam E M)
          (fixedShiftedSpectralCoordinate α lam E M) (fixedCircleRadius_pos α lam E M hM)
          (fixedCircle_separation α lam E M hM hE) (-1)) := by
  let L := cfcL (R := ℂ) (magneticAlgebraHamiltonian_isSelfAdjoint α lam).isStarNormal
  change _ = L (spectralCircleCoefficient _ _ _ _ _)
  rw [spectralCircleCoefficient_map]
  have he : -(-1 : ℤ) - 1 = 0 := by norm_num
  simp only [he, zpow_zero, mul_one]
  unfold fixedCircleCoefficient
  congr 1
  apply intervalIntegral.integral_congr
  intro θ _
  simp only [L, cfcL_apply, fixedCircle_kernel_cfc α lam E M hM hE]

theorem fixedCircleCoefficient_eq_gapProjection (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    (fixedCircleRadius α lam E M : ℂ) • fixedCircleCoefficient α lam E M =
      magneticGapProjection α lam E hE := by
  rw [fixedCircleCoefficient_eq_cfcHom α lam E M hM hE]
  have hn := spectralCircleCoefficient_negative (fixedCircleRadius α lam E M)
    (fixedShiftedSpectralCoordinate α lam E M) (fixedCircleRadius_pos α lam E M hM)
    (fixedCircle_separation α lam E M hM hE) 0
  norm_num at hn
  rw [hn]
  have hg : magneticGapProjection α lam E hE =
      cfc (fun t : ℝ => if t < E then 1 else 0) (magneticAlgebraHamiltonian α lam) := by
    apply cfcHom_eq_cfc_of_pointwise (magneticAlgebraHamiltonian_isSelfAdjoint α lam)
    intro x
    rfl
  rw [hg, cfc_real_eq_complex _ (magneticAlgebraHamiltonian_isSelfAdjoint α lam), ← map_smul]
  apply cfcHom_eq_cfc_of_pointwise (𝕜 := ℂ)
    (magneticAlgebraHamiltonian_isSelfAdjoint α lam).isStarNormal
  intro x
  change (fixedCircleRadius α lam E M : ℂ) *
    (insideCoefficient (fixedCircleRadius α lam E M) (fixedShiftedSpectralCoordinate α lam E M)
      (fixedCircle_separation α lam E M hM hE) 0 x : ℂ) = _
  rw [insideCoefficient_apply]
  by_cases hx : (x : ℂ).re < E
  · have hxi := (fixedShiftedSpectralCoordinate_lt_iff α lam E M hM x).mpr hx
    simp [insideKernel, insideTail, hxi, hx, (fixedCircleRadius_pos α lam E M hM).ne']
  · have hxi : ¬ |fixedShiftedSpectralCoordinate α lam E M x| < fixedCircleRadius α lam E M :=
      mt (fixedShiftedSpectralCoordinate_lt_iff α lam E M hM x).mp hx
    simp [insideKernel, hxi, hx]

theorem fixedCircleIntegral_eq_gapProjection (α lam E M : ℝ)
    (hM : ‖magneticAlgebraHamiltonian α lam‖ ≤ M)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    (2 * Real.pi * I : ℂ)⁻¹ •
      (∫ θ in (0 : ℝ)..(2 * Real.pi), deriv (fixedCircle α lam E M) θ •
        fixedCircleInverse α lam E M θ) = magneticGapProjection α lam E hE := by
  simp_rw [fixedCircle_deriv, mul_smul]
  rw [intervalIntegral.integral_smul, smul_comm]
  exact fixedCircleCoefficient_eq_gapProjection α lam E M hM hE

/-- Couplings for which one fixed circle separates the spectrum. -/
def fixedCircleParameterDomain (α E M : ℝ) : Set ℝ :=
  {lam | ‖magneticAlgebraHamiltonian α lam‖ < M ∧
    (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))}

theorem fixedCircleParameterDomain_isOpen (α E M : ℝ) :
    IsOpen (fixedCircleParameterDomain α E M) := by
  have hnorm : IsOpen {lam : ℝ | ‖magneticAlgebraHamiltonian α lam‖ < M} :=
    isOpen_lt (magneticAlgebraHamiltonian_continuous α).norm continuous_const
  have hres : IsOpen {lam : ℝ |
      (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))} :=
    (realJointResolventDomain_isOpen α).preimage
      (continuous_id.prodMk continuous_const)
  exact hnorm.inter hres

theorem fixedCircleInverse_joint_continuous (α E M : ℝ) :
    Continuous (fun p : fixedCircleParameterDomain α E M × ℝ =>
      fixedCircleInverse α p.1.1 E M p.2) := by
  rw [continuous_iff_continuousAt]
  intro p
  have hu : IsUnit ((fixedCircle α p.1.1 E M p.2) •
      (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α p.1.1) := by
    apply (magneticAlgebra α).coe_isUnit.mp
    change IsUnit ((fixedCircle α p.1.1 E M p.2) •
      (1 : MagneticBoundedOperator) -
      (magneticAlgebraHamiltonian α p.1.1 : MagneticBoundedOperator))
    rw [magneticAlgebraHamiltonian_coe]
    have hr : IsUnit (algebraMap ℂ MagneticBoundedOperator
        (fixedCircle α p.1.1 E M p.2) - hOperator α (p.1.1 : ℂ)) :=
      fixedCircle_resolvent α p.1.1 E M p.1.2.1.le p.1.2.2 p.2
    simpa only [Algebra.algebraMap_eq_smul_one] using hr
  have hi := NormedRing.inverse_continuousAt hu.unit
  rw [hu.unit_spec] at hi
  have hc : Continuous (fun q : fixedCircleParameterDomain α E M × ℝ =>
      fixedCircle α q.1.1 E M q.2) := by
    unfold fixedCircle fixedCircleRadius fixedCircleCenter
    exact continuous_const.add
      (continuous_const.mul ((continuous_circleMap 0 1).comp continuous_snd))
  have hpencil : ContinuousAt (fun q : fixedCircleParameterDomain α E M × ℝ =>
      fixedCircle α q.1.1 E M q.2 • (1 : magneticAlgebra α) -
        magneticAlgebraHamiltonian α q.1.1) p :=
    (hc.smul continuous_const |>.sub
      ((magneticAlgebraHamiltonian_continuous α).comp
        (continuous_subtype_val.comp continuous_fst))).continuousAt
  exact hi.comp (f := fun q : fixedCircleParameterDomain α E M × ℝ =>
    fixedCircle α q.1.1 E M q.2 • (1 : magneticAlgebra α) -
      magneticAlgebraHamiltonian α q.1.1) hpencil

def fixedCircleIntegral (α E M lam : ℝ) : magneticAlgebra α :=
  (2 * Real.pi * I : ℂ)⁻¹ •
    ∫ θ in (0 : ℝ)..(2 * Real.pi), deriv (fixedCircle α lam E M) θ •
      fixedCircleInverse α lam E M θ

/-- The Hamiltonian depends affinely on the real coupling inside the
fixed magnetic algebra. -/
theorem magneticHamiltonian_hasDerivAt (α lam : ℝ) :
    HasDerivAt (magneticAlgebraHamiltonian α) (magneticAlgebraVertical α) lam := by
  simpa only [magneticAlgebraHamiltonian, one_smul] using
    ((hasDerivAt_id lam).smul_const (magneticAlgebraVertical α)).const_add
      (⟨hOperator α 0, hOperator_mem_magneticAlgebra α 0⟩ : magneticAlgebra α)

/-- The fixed-contour resolvent derivative is R (∂λ H) R in the
magnetic algebra, with its noncommuting factors in this order. -/
theorem fixedCircleInverse_hasDerivAt (α E M lam θ : ℝ)
    (hlam : lam ∈ fixedCircleParameterDomain α E M) :
    HasDerivAt (fun l => fixedCircleInverse α l E M θ)
      (fixedCircleInverse α lam E M θ * magneticAlgebraVertical α *
        fixedCircleInverse α lam E M θ) lam := by
  have hu : IsUnit ((fixedCircle α lam E M θ) •
      (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α lam) := by
    apply (magneticAlgebra α).coe_isUnit.mp
    change IsUnit ((fixedCircle α lam E M θ) • (1 : MagneticBoundedOperator) -
      (magneticAlgebraHamiltonian α lam : MagneticBoundedOperator))
    rw [magneticAlgebraHamiltonian_coe]
    simpa only [Algebra.algebraMap_eq_smul_one] using
      fixedCircle_resolvent α lam E M hlam.1.le hlam.2 θ
  have hp := (magneticHamiltonian_hasDerivAt α lam).const_sub
    ((fixedCircle α lam E M θ) • (1 : magneticAlgebra α))
  have hd := inverse_curve_hasDerivAt
    (fun l => (fixedCircle α lam E M θ) • (1 : magneticAlgebra α) -
      magneticAlgebraHamiltonian α l) (-magneticAlgebraVertical α) lam hp hu
  change HasDerivAt (fun l => Ring.inverse
    ((fixedCircle α lam E M θ) • (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α l))
    (Ring.inverse ((fixedCircle α lam E M θ) • (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α lam) *
      magneticAlgebraVertical α *
      Ring.inverse ((fixedCircle α lam E M θ) • (1 : magneticAlgebra α) - magneticAlgebraHamiltonian α lam)) lam
  simpa only [mul_neg, neg_mul, neg_neg] using hd

/-- Differentiating the actual Riesz projector under its fixed contour. -/
theorem fixedCircleIntegral_hasDerivAt (α E M lam : ℝ)
    (hlam : lam ∈ fixedCircleParameterDomain α E M) :
    HasDerivAt (fixedCircleIntegral α E M)
      ((2 * Real.pi * I : ℂ)⁻¹ • ∫ θ in (0 : ℝ)..(2 * Real.pi),
        deriv (fixedCircle α lam E M) θ •
          (fixedCircleInverse α lam E M θ * magneticAlgebraVertical α *
            fixedCircleInverse α lam E M θ)) lam := by
  have hR : ContinuousOn (fun p : ℝ × ℝ => fixedCircleInverse α p.1 E M p.2)
      (fixedCircleParameterDomain α E M ×ˢ univ) := by
    rw [continuousOn_iff_continuous_restrict]
    let f : (fixedCircleParameterDomain α E M ×ˢ (univ : Set ℝ)) →
        fixedCircleParameterDomain α E M × ℝ :=
      fun p => (⟨p.1.1, p.property.1⟩, p.1.2)
    have hf : Continuous f :=
      ((continuous_fst.comp continuous_subtype_val).subtype_mk
        (fun p => p.property.1)).prodMk
          (continuous_snd.comp continuous_subtype_val)
    have hh := (fixedCircleInverse_joint_continuous α E M).comp hf
    simpa only [f, Function.comp_def] using hh
  have hc : Continuous (fun θ : ℝ => deriv (fixedCircle α lam E M) θ) :=
    fixedCircle_deriv_continuous α lam E M
  have hD := (hc.comp continuous_snd).continuousOn.smul
    ((hR.mul (continuousOn_const (c := magneticAlgebraVertical α))).mul hR)
  have hh := compactInterval_hasDerivAt
    (fun l θ => deriv (fixedCircle α lam E M) θ • fixedCircleInverse α l E M θ)
    (fun l θ => deriv (fixedCircle α lam E M) θ •
      (fixedCircleInverse α l E M θ * magneticAlgebraVertical α *
        fixedCircleInverse α l E M θ))
    Real.two_pi_pos.le (fixedCircleParameterDomain_isOpen α E M) hlam
    (fun l hl => ((fixedCircle_deriv_continuous α lam E M).smul
      (fixedCircleInverse_continuous α l E M hl.1.le hl.2)).continuousOn)
    (hD.mono (prod_mono Subset.rfl (subset_univ _)))
    (fun l hl θ _ => (fixedCircleInverse_hasDerivAt α E M l θ hl).const_smul _)
  simpa only [fixedCircleIntegral, fixedCircle, fixedCircleRadius, fixedCircleCenter] using
    hh.const_smul (2 * Real.pi * I : ℂ)⁻¹

/-- Differentiate P²=P, remove its diagonal corner, and apply the fixed
canonical trace. This is the derivative argument in the manuscript. -/
theorem fixedCircleTrace_hasDerivAt_zero (α E M lam : ℝ)
    (hlam : lam ∈ fixedCircleParameterDomain α E M) :
    HasDerivAt (fun l => magneticTraceReal α (fixedCircleIntegral α E M l)) 0 lam := by
  apply trace_projection_hasDerivAt_zero (magneticTraceReal α)
    (magneticTraceReal_cyclic α) (fixedCircleIntegral α E M) _ lam
    (fixedCircleIntegral_hasDerivAt α E M lam hlam)
  filter_upwards [(fixedCircleParameterDomain_isOpen α E M).mem_nhds hlam] with l hl
  rw [fixedCircleIntegral, fixedCircleIntegral_eq_gapProjection α l E M hl.1.le hl.2]
  exact magneticGapProjection_idempotent α l E hl.2

/-- Vanishing derivative makes the projector trace constant on a small
coupling interval. -/
theorem fixedCircleTrace_eventually_eq (α E M lam : ℝ)
    (hlam : lam ∈ fixedCircleParameterDomain α E M) :
    ∀ᶠ l in 𝓝 lam, magneticTraceReal α (fixedCircleIntegral α E M l) =
      magneticTraceReal α (fixedCircleIntegral α E M lam) := by
  obtain ⟨a, b, hlamab, hab⟩ := mem_nhds_iff_exists_Ioo_subset.mp
    ((fixedCircleParameterDomain_isOpen α E M).mem_nhds hlam)
  filter_upwards [isOpen_Ioo.mem_nhds hlamab] with l hl
  exact isOpen_Ioo.is_const_of_deriv_eq_zero (convex_Ioo a b).isPreconnected
    (fun t ht => (fixedCircleTrace_hasDerivAt_zero α E M t (hab ht)).differentiableAt.differentiableWithinAt)
    (fun t ht => (fixedCircleTrace_hasDerivAt_zero α E M t (hab ht)).deriv) hl hlamab

/-- Moving a cut within one gap does not change its spectral projection. -/
theorem gapProjection_eq_of_common_gap (α lam E F a b : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hF : (F : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ)))
    (hEa : E ∈ Ioo a b) (hFa : F ∈ Ioo a b)
    (hgap : ∀ x ∈ Ioo a b, (x : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    magneticGapProjection α lam E hE = magneticGapProjection α lam F hF := by
  unfold magneticGapProjection
  congr 1
  ext x
  have havoid : (x : ℝ) ≤ a ∨ b ≤ (x : ℝ) := by
    by_cases hxa : (x : ℝ) ≤ a
    · exact Or.inl hxa
    · right
      by_contra hbx
      exact resolvent_energy_not_mem_magneticRealSpectrum α lam x
        (hgap x ⟨lt_of_not_ge hxa, lt_of_not_ge hbx⟩) x.property
  rcases havoid with hx | hx
  · simp only [magneticLowerSpectrumIndicator_apply,
      if_pos (hx.trans_lt hEa.1), if_pos (hx.trans_lt hFa.1)]
  · simp only [magneticLowerSpectrumIndicator_apply,
      if_neg (not_lt_of_ge (hEa.2.le.trans hx)),
      if_neg (not_lt_of_ge (hFa.2.le.trans hx))]

/-- On a common gap, the fixed-contour projector has zero traced
coupling derivative; moving the cut within that gap leaves it unchanged.
Thus the actual IDS is locally constant in both parameters. -/
-- Manuscript Lemma 3.9.
theorem lowerMass_isLocallyConstant (α : ℝ) :
    IsLocallyConstant (fun p : realJointResolventDomain α =>
      magneticLowerMass α p.1.1 p.1.2) := by
  apply (IsLocallyConstant.iff_eventually_eq _).mpr
  intro p
  obtain ⟨a, b, hpab, hnear⟩ := magnetic_common_gap_neighborhood α p.1 p.2
  let M := ‖magneticAlgebraHamiltonian α p.1.1‖ + 1
  have hpM : p.1.1 ∈ fixedCircleParameterDomain α p.1.2 M :=
    ⟨by dsimp [M]; linarith, p.2⟩
  have hnorm : Continuous (fun q : realJointResolventDomain α =>
      ‖magneticAlgebraHamiltonian α q.1.1‖) :=
    (magneticAlgebraHamiltonian_continuous α).norm.comp
      (continuous_fst.comp continuous_subtype_val)
  have hlt : ‖magneticAlgebraHamiltonian α p.1.1‖ < M := by dsimp [M]; linarith
  have hM : ∀ᶠ q : realJointResolventDomain α in 𝓝 p,
      ‖magneticAlgebraHamiltonian α q.1.1‖ < M :=
    hnorm.continuousAt.eventually (isOpen_Iio.mem_nhds hlt)
  have htrace := (continuous_fst.comp
    (continuous_subtype_val : Continuous (Subtype.val : realJointResolventDomain α → ℝ × ℝ))).continuousAt.eventually
      (fixedCircleTrace_eventually_eq α p.1.2 M p.1.1 hpM)
  filter_upwards [continuous_subtype_val.continuousAt.eventually hnear, hM, htrace]
    with q hq hqM hqtrace
  have hres := hq.2 p.1.2 hpab
  rw [magneticLowerMass_eq_projection_trace α q.1.1 q.1.2 q.2,
    magneticLowerMass_eq_projection_trace α p.1.1 p.1.2 p.2,
    gapProjection_eq_of_common_gap α q.1.1 q.1.2 p.1.2 a b
      q.2 hres hq.1 hpab hq.2]
  simpa only [Function.comp_def, fixedCircleIntegral,
    fixedCircleIntegral_eq_gapProjection α q.1.1 p.1.2 M hqM.le hres,
    fixedCircleIntegral_eq_gapProjection α p.1.1 p.1.2 M hpM.1.le p.2] using hqtrace

theorem lowerMass_eventually_eq (α : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ realJointResolventDomain α) :
    ∀ᶠ q in 𝓝 p, magneticLowerMass α q.1 q.2 = magneticLowerMass α p.1 p.2 := by
  rw [← (realJointResolventDomain_isOpen α).isOpenEmbedding_subtypeVal.map_nhds_eq
    (⟨p, hp⟩ : realJointResolventDomain α)]
  exact (lowerMass_isLocallyConstant α).eventually_eq
    (⟨p, hp⟩ : realJointResolventDomain α)

theorem lowerMass_joint_label_locallyConstant (α : ℝ) :
    JointResolventLabelLocallyConstant α (fun p => magneticLowerMass α p.1 p.2) := by
  intro p hp
  exact lowerMass_eventually_eq α p hp

end DTMAudit.ManuscriptRieszContinuity

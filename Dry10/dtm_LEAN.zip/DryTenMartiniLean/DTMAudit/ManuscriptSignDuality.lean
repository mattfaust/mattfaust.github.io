import DTM.Background.AllCouplingExtension.MagneticDOSDuality
import DTM.Background.Realization.AMOMagneticSpectrum

/-! The manuscript's literal lattice sign involution. Multiplication by
(-1)^m reverses vertical hopping, fixes the source, and therefore transports
the actual spectrum and density of states from λ to -λ. No phase-shift
identity is used. -/

set_option autoImplicit false
noncomputable section
namespace DTMAudit.ManuscriptSignDuality
open CriticalDTM MeasureTheory Set

private theorem sign_norm (m : ℤ) : ‖(-1 : ℂ)^m‖ = 1 := by simp

private theorem sign_squared (m : ℤ) : (-1 : ℂ)^m * (-1 : ℂ)^m = 1 := by
  rw [← mul_zpow]
  norm_num

/-- The source's standard (Landau-gauge) lattice basis is multiplied by
exactly the integer power appearing in the manuscript. -/
def signEquiv : MagneticHilbert ≃ₗᵢ[ℂ] MagneticHilbert where
  toFun := twistedVector (Equiv.refl Site) (fun s => (-1 : ℂ)^s.2)
    (fun s => sign_norm s.2)
  invFun := twistedVector (Equiv.refl Site) (fun s => (-1 : ℂ)^s.2)
    (fun s => sign_norm s.2)
  left_inv := by
    intro u
    apply lp.ext
    funext s
    simp only [twistedVector_apply, Equiv.refl_apply, ← mul_assoc, sign_squared, one_mul]
  right_inv := by
    intro u
    apply lp.ext
    funext s
    simp only [twistedVector_apply, Equiv.refl_apply, ← mul_assoc, sign_squared, one_mul]
  map_add' := by intro u v; apply lp.ext; funext s; simp [mul_add]
  map_smul' := by intro c u; apply lp.ext; funext s; simp [mul_left_comm]
  norm_map' := twistedVector_norm (Equiv.refl Site) (fun s => (-1 : ℂ)^s.2)
    (fun s => sign_norm s.2)

@[simp] theorem signEquiv_apply (u : MagneticHilbert) (s : Site) :
    signEquiv u s = (-1 : ℂ)^s.2 * u s := rfl

theorem signEquiv_involutive : Function.Involutive signEquiv := signEquiv.left_inv

@[simp] theorem signEquiv_twice (u : MagneticHilbert) : signEquiv (signEquiv u) = u :=
  signEquiv_involutive u

@[simp] theorem signEquiv_origin (u : MagneticHilbert) : signEquiv u origin = u origin := by
  simp [origin]

@[simp] theorem signEquiv_root : signEquiv hilbertRoot = hilbertRoot := by
  apply lp.ext
  funext s
  by_cases hs : s = origin
  · subst s
    simp [origin]
  · simp [latticeRoot,hs]

/-- The intertwining is checked at every receiving row, for every ℓ² vector. -/
theorem intertwines (α : ℝ) (z : ℂ) (u : MagneticHilbert) :
    signEquiv (hOperator α z u) = hOperator α (-z) (signEquiv u) := by
  apply lp.ext
  funext s
  rcases s with ⟨n,m⟩
  simp only [signEquiv_apply,hOperator_apply,hRow,east,west,north,south]
  simp only [zpow_add₀ (by norm_num : (-1 : ℂ) ≠ 0),
    zpow_sub₀ (by norm_num : (-1 : ℂ) ≠ 0),zpow_one,div_neg,div_one]
  ring

/-- The displayed conjugation S H S* is conjugation by this unitary. -/
def operatorEquiv : MagneticBoundedOperator ≃ₐ[ℂ] MagneticBoundedOperator where
  toFun A := signEquiv.toContinuousLinearEquiv.toContinuousLinearMap.comp
    (A.comp signEquiv.symm.toContinuousLinearEquiv.toContinuousLinearMap)
  invFun A := signEquiv.symm.toContinuousLinearEquiv.toContinuousLinearMap.comp
    (A.comp signEquiv.toContinuousLinearEquiv.toContinuousLinearMap)
  left_inv A := by ext u; simp [← mul_assoc,sign_squared]
  right_inv A := by ext u; simp [← mul_assoc,sign_squared]
  map_mul' A B := by ext u; simp
  map_add' A B := by ext u; simp
  commutes' c := by ext u; simp [Algebra.algebraMap_eq_smul_one,← mul_assoc,sign_squared]

theorem conjugacy (α : ℝ) (z : ℂ) : operatorEquiv (hOperator α z) = hOperator α (-z) := by
  apply ContinuousLinearMap.ext
  intro u
  change signEquiv (hOperator α z (signEquiv.symm u)) = _
  rw [intertwines,LinearIsometryEquiv.apply_symm_apply]

theorem spectrum_eq (α : ℝ) (z : ℂ) :
    spectrum ℂ (hOperator α (-z)) = spectrum ℂ (hOperator α z) := by
  simpa only [conjugacy] using AlgEquiv.spectrum_eq operatorEquiv (hOperator α z)

theorem realSpectrum_eq (α lam : ℝ) :
    magneticRealSpectrumSet α (-lam) = magneticRealSpectrumSet α lam := by
  unfold magneticRealSpectrumSet
  simp only [Complex.ofReal_neg,spectrum_eq]

theorem intertwines_pow (α : ℝ) (z : ℂ) (k : ℕ) (u : MagneticHilbert) :
    signEquiv (((hOperator α z)^k) u) = ((hOperator α (-z))^k) (signEquiv u) := by
  induction k with
  | zero => simp
  | succ k ih => rw [pow_succ',ContinuousLinearMap.mul_apply,intertwines,ih,
      pow_succ',ContinuousLinearMap.mul_apply]

/-- Root moments agree by the fixed source and unitarity alone. -/
theorem rootTrace_pow (α : ℝ) (z : ℂ) (k : ℕ) :
    rootTrace ((hOperator α z)^k) = rootTrace ((hOperator α (-z))^k) := by
  have h := congrArg (fun u : MagneticHilbert => u origin)
    (intertwines_pow α z k hilbertRoot)
  simpa only [signEquiv_origin,signEquiv_root,rootTrace_apply] using h

/-- Equality of actual compactly supported DOS probability measures. -/
theorem dos_eq (α lam : ℝ) :
    magneticRealSpectralMeasure α lam = magneticRealSpectralMeasure α (-lam) := by
  let μ : ProbabilityMeasure ℝ := ⟨magneticRealSpectralMeasure α lam,inferInstance⟩
  let ν : ProbabilityMeasure ℝ := ⟨magneticRealSpectralMeasure α (-lam),inferInstance⟩
  have hμ : (μ : Measure ℝ) (Icc (-(2+2*|lam|)) (2+2*|lam|))=1 :=
    magneticRealSpectralMeasure_window α lam
  have hν : (ν : Measure ℝ) (Icc (-(2+2*|lam|)) (2+2*|lam|))=1 := by
    simpa only [abs_neg] using magneticRealSpectralMeasure_window α (-lam)
  have heq : μ=ν := by
    apply probabilityMeasure_eq_of_compact_moments μ ν _ _ hμ hν
    intro k
    change (∫ x : ℝ,x^k ∂magneticRealSpectralMeasure α lam) =
      ∫ x : ℝ,x^k ∂magneticRealSpectralMeasure α (-lam)
    rw [magneticRealSpectralMeasure_moment,magneticRealSpectralMeasure_moment,
      Complex.ofReal_neg,rootTrace_pow]
  exact congrArg (fun ρ : ProbabilityMeasure ℝ => (ρ : Measure ℝ)) heq

theorem lowerMass_eq (α lam E : ℝ) : magneticLowerMass α lam E = magneticLowerMass α (-lam) E := by
  unfold magneticLowerMass
  rw [dos_eq]

/-- The same actual open interval and the same DOS label transfer under λ↦-λ. -/
theorem labelled_gap_iff (α lam label a b : ℝ) :
    IsLabelledSpectralGap (magneticRealSpectrumSet α lam) (magneticLowerMass α lam) label a b ↔
    IsLabelledSpectralGap (magneticRealSpectrumSet α (-lam)) (magneticLowerMass α (-lam)) label a b := by
  rw [realSpectrum_eq]
  have hm : magneticLowerMass α lam = magneticLowerMass α (-lam) := funext (lowerMass_eq α lam)
  rw [hm]

/-- Specialization to the actual almost Mathieu spectral gaps at arbitrary
phases, using the existing physical lattice/fiber realization bridge. -/
theorem amo_labelled_gap_iff {α : ℝ} (hα : Irrational α) (lam θ φ label a b : ℝ) :
    IsLabelledSpectralGap (almostMathieuRealSpectrumSet α lam θ)
      (almostMathieuIDS α lam) label a b ↔
    IsLabelledSpectralGap (almostMathieuRealSpectrumSet α (-lam) φ)
      (almostMathieuIDS α (-lam)) label a b := by
  have hm (l : ℝ) : almostMathieuIDS α l = magneticLowerMass α l :=
    funext (fun E => (magneticLowerMass_eq_almostMathieuIDS α l E).symm)
  rw [almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα,
    almostMathieuRealSpectrumSet_eq_magneticRealSpectrumSet hα,hm lam,hm (-lam)]
  exact labelled_gap_iff α lam label a b

end DTMAudit.ManuscriptSignDuality

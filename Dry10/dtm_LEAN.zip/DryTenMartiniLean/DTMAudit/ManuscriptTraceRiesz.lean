import DTMAudit.ManuscriptPositiveSquare
import DTMAudit.PhaseDerivative

/-! Lemma 3.5: the literal DOS-height derivative from the positive square of
the physical pencil, canonical-trace cyclicity, and the ordinary chain rule.
The DOS derivative and selected-height endpoint use `ManuscriptPositiveSquare`. -/
noncomputable section
set_option maxHeartbeats 1200000
namespace DTMAudit.ManuscriptTraceRiesz
open CriticalDTM MeasureTheory Filter Set Complex
open scoped Topology

private theorem coupling_domain_isOpen (α : ℝ) (z : ℂ) :
    IsOpen {l : ℝ | z ∈ resolventSet ℂ (hOperator α (l : ℂ))} := by
  exact Units.isOpen.preimage (continuous_const.sub
    ((hOperator_continuous α).comp Complex.continuous_ofReal))

/-- The physical DOS logarithmic height along a C1 energy path. Positive-square
trace-log differentiation gives both terms; canonical-trace cyclicity gives
the coupling insertion and self-adjointness evaluates it at the origin. -/
theorem dos_height_path_hasDerivAt (α : ℝ)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ))) :
    HasDerivAt (fun l : ℝ => ∫ x : ℝ, Real.log |energy l-x|
      ∂magneticRealSpectralMeasure α l)
      (velocity lam * (projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (energy lam : ℂ)).re -
       (@inner ℂ MagneticHilbert _
         (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot) verticalRoot).re) lam := by
  have h := ManuscriptPositiveSquare.dos_height_path_trace_hasDerivAt
    α energy velocity hU hlam he hd hE
  rw [rootTrace_resolvent_eq_green] at h
  have hsource : rootTrace
      (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) * verticalOperator α) =
      @inner ℂ MagneticHilbert _
        (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot) verticalRoot := by
    rw [rootTrace_eq_inner, ContinuousLinearMap.mul_apply, verticalOperator_root]
    exact ((real_resolvent_isSelfAdjoint _ (hOperator_isSelfAdjoint α lam)
      (energy lam)).isSymmetric.apply_clm hilbertRoot verticalRoot).symm
  rwa [hsource] at h

/-- At the selected energy, the vanishing origin Green entry cancels the
energy velocity, leaving exactly the physical vertical source insertion. -/
theorem dos_height_stationary_path_hasDerivAt (α : ℝ)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (energy lam : ℂ) = 0) :
    HasDerivAt (fun l : ℝ => ∫ x : ℝ, Real.log |energy l-x|
      ∂magneticRealSpectralMeasure α l)
      (-(@inner ℂ MagneticHilbert _
        (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot) verticalRoot).re) lam := by
  simpa only [hzero, Complex.zero_re, mul_zero, zero_sub] using
    dos_height_path_hasDerivAt α energy velocity hU hlam he hd hE

/-- The fixed-energy coupling derivative displayed in the manuscript.
This specialization has no energy-branch or stationarity hypothesis. -/
theorem dos_height_coupling_hasDerivAt (α : ℝ)
    (lam E : ℝ) (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    HasDerivAt (fun l : ℝ => ∫ x : ℝ, Real.log |E-x|
      ∂magneticRealSpectralMeasure α l)
      (-(@inner ℂ MagneticHilbert _
        (resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot) verticalRoot).re) lam := by
  simpa only [zero_mul, zero_sub] using dos_height_path_hasDerivAt α
    (fun _ => E) (fun _ => 0)
    (coupling_domain_isOpen α (E : ℂ)) hE
    (fun l _ => hasDerivAt_const l E) continuousOn_const (fun _ hl => hl)

/-- Evaluation of the canonical trace at the origin gives the manuscript's
source pairing. Self-adjointness is used only at the real gap energy. -/
theorem trace_resolvent_source_pairing (α lam E : ℝ) :
    rootTrace (resolvent (hOperator α (lam : ℂ)) (E : ℂ) * verticalOperator α) =
      @inner ℂ MagneticHilbert _
        (resolvent (hOperator α (lam : ℂ)) (E : ℂ) hilbertRoot) verticalRoot := by
  rw [rootTrace_eq_inner, ContinuousLinearMap.mul_apply, verticalOperator_root]
  exact ((real_resolvent_isSelfAdjoint _ (hOperator_isSelfAdjoint α lam)
    E).isSymmetric.apply_clm hilbertRoot verticalRoot).symm

/-- The fixed-energy canonical-trace identity, obtained by differentiating
the positive square, applying trace cyclicity to the two product-rule terms,
and identifying the actual pencil inverse with the physical resolvent. -/
theorem dos_height_coupling_trace_hasDerivAt (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    HasDerivAt (fun l : ℝ => ∫ x : ℝ, Real.log |E-x|
      ∂magneticRealSpectralMeasure α l)
      (-(rootTrace (resolvent (hOperator α (lam : ℂ)) (E : ℂ) *
        verticalOperator α)).re) lam := by
  rw [trace_resolvent_source_pairing]
  exact dos_height_coupling_hasDerivAt α lam E hE

/-- The manuscript's exact weighted insertion at a selected energy. The
common-origin identity differentiates to the source derivative of H+, and
unitarity transports the two actual vectors to the symmetric gauge. -/
-- Manuscript Lemma 3.5.
theorem selected_height_weighted_insertion (α : ℝ)
    (energy velocity : ℝ → ℝ) {U : Set ℝ} (hU : IsOpen U)
    {lam : ℝ} (hlam : lam ∈ U)
    (he : ∀ l ∈ U, HasDerivAt energy (velocity l) l)
    (hd : ContinuousOn velocity U)
    (hE : ∀ l ∈ U, (energy l : ℂ) ∈ resolventSet ℂ (hOperator α (l : ℂ)))
    (hzero : projectedGreen (hOperator α (lam : ℂ)) hilbertRoot (energy lam : ℂ) = 0) :
    lam * deriv (fun l : ℝ => ∫ x : ℝ, Real.log |energy l-x|
      ∂magneticRealSpectralMeasure α l) lam =
    -(@inner ℂ MagneticHilbert _
       (SymmetricGauge.unitary α
         (resolvent (hOperator α (lam : ℂ)) (energy lam : ℂ) hilbertRoot))
       ((lam : ℂ) • deriv (PhaseDerivative.source α) lam)).re := by
  rw [(dos_height_stationary_path_hasDerivAt α energy velocity hU hlam he hd hE hzero).deriv,
    (PhaseDerivative.source_hasDerivAt α lam).deriv, inner_smul_right,
    LinearIsometryEquiv.inner_map_map, Complex.re_ofReal_mul]
  ring

end DTMAudit.ManuscriptTraceRiesz

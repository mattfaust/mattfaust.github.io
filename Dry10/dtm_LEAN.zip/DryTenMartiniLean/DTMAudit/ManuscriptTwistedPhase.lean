import DTM.Background.Realization.AlmostMathieu
import DTMAudit.PhaseDerivative
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv

/-!
# The literal twisted one-dimensional Landau fiber

The phase parameters are radians. All differentiations below take place
in the Banach space of bounded operators on the actual ℓ²(ℤ,ℂ) fiber.
The receiving row and zero-horizontal-phase AMO identification are proved
before the coupling/second-phase-derivative identity.
-/

noncomputable section
namespace DTMAudit.ManuscriptTwistedPhase
open CriticalDTM PhaseDerivative

def hopping (kx : ℝ) : AMOBoundedOperator :=
  phase Complex.I kx • amoShift + phase (-Complex.I) kx • star amoShift

/-- The actual bounded twisted fiber, with the usual AMO cosine multiplier. -/
def twistedFiber (α lam kx ky : ℝ) : AMOBoundedOperator :=
  hopping kx + ((2 * lam : ℝ) : ℂ) • amoCosOperator α ky

theorem twistedFiber_apply (α lam kx ky : ℝ) (u : AMOHilbert) (j : ℤ) :
    twistedFiber α lam kx ky u j =
      Complex.exp (Complex.I * (kx : ℂ)) * u (j+1) +
      Complex.exp (-(Complex.I * (kx : ℂ))) * u (j-1) +
      ((2 * lam * Real.cos (2 * Real.pi * α * (j : ℝ) + ky) : ℝ) : ℂ) * u j := by
  simp [twistedFiber, hopping, phase, mul_assoc, mul_comm]

def cosineVelocity (α ky : ℝ) : AMOBoundedOperator :=
  (-Real.sin ky : ℂ) • amoCosOperator α 0 +
    (Real.cos ky : ℂ) • amoCosOperator α (Real.pi / 2)

theorem cosine_hasDerivAt (α ky : ℝ) :
    HasDerivAt (amoCosOperator α) (cosineVelocity α ky) ky := by
  have hc := Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt ky (Real.hasDerivAt_cos ky)
  have hs := Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt ky (Real.hasDerivAt_sin ky)
  have hd := (hc.smul_const (amoCosOperator α 0)).add
    (hs.smul_const (amoCosOperator α (Real.pi / 2)))
  simpa only [Function.comp_def, Complex.ofRealCLM_apply,
    ← amoCosOperator_eq_cos_smul_add_sin_smul, cosineVelocity, Complex.ofReal_neg] using hd

theorem cosine_deriv (α : ℝ) : deriv (amoCosOperator α) = cosineVelocity α := by
  funext ky
  exact (cosine_hasDerivAt α ky).deriv

theorem cosine_second_hasDerivAt (α ky : ℝ) :
    HasDerivAt (deriv (amoCosOperator α)) (-amoCosOperator α ky) ky := by
  rw [cosine_deriv]
  have hs := Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt ky (Real.hasDerivAt_sin ky).neg
  have hc := Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt ky (Real.hasDerivAt_cos ky)
  have hd := (hs.smul_const (amoCosOperator α 0)).add
    (hc.smul_const (amoCosOperator α (Real.pi / 2)))
  convert hd using 1
  · ext x
    simp only [cosineVelocity, Function.comp_def, Complex.ofRealCLM_apply, Complex.ofReal_neg]
  · rw [amoCosOperator_eq_cos_smul_add_sin_smul α ky]
    simp only [Complex.ofRealCLM_apply, Complex.ofReal_neg, neg_smul, neg_add_rev]
    abel

def hoppingVelocity (kx : ℝ) : AMOBoundedOperator :=
  (phase Complex.I kx * Complex.I) • amoShift +
    (phase (-Complex.I) kx * (-Complex.I)) • star amoShift

theorem hopping_hasDerivAt (kx : ℝ) :
    HasDerivAt hopping (hoppingVelocity kx) kx :=
  ((phase_hasDerivAt Complex.I kx).smul_const amoShift).add
    ((phase_hasDerivAt (-Complex.I) kx).smul_const (star amoShift))

theorem hopping_deriv : deriv hopping = hoppingVelocity := by
  funext kx
  exact (hopping_hasDerivAt kx).deriv

theorem hopping_second_hasDerivAt (kx : ℝ) :
    HasDerivAt (deriv hopping) (-hopping kx) kx := by
  rw [hopping_deriv]
  have hd := (((phase_hasDerivAt Complex.I kx).mul_const Complex.I).smul_const amoShift).add
    (((phase_hasDerivAt (-Complex.I) kx).mul_const (-Complex.I)).smul_const (star amoShift))
  convert hd using 1
  simp only [hopping, mul_assoc, Complex.I_mul_I, neg_mul_neg, mul_neg_one, neg_smul]
  abel

/-- Genuine derivative in the physical coupling, in operator norm. -/
theorem twistedFiber_coupling_hasDerivAt (α lam kx ky : ℝ) :
    HasDerivAt (fun t => twistedFiber α t kx ky) ((2 : ℂ) • amoCosOperator α ky) lam := by
  have hc := Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt lam ((hasDerivAt_id lam).const_mul 2)
  simpa only [Function.comp_def, Complex.ofRealCLM_apply, mul_one, twistedFiber]
    using (hc.smul_const (amoCosOperator α ky)).const_add (hopping kx)

theorem twistedFiber_kx_hasDerivAt (α lam kx ky : ℝ) :
    HasDerivAt (fun k => twistedFiber α lam k ky) (hoppingVelocity kx) kx :=
  (hopping_hasDerivAt kx).add_const _

theorem twistedFiber_kx_deriv (α lam ky : ℝ) :
    deriv (fun k => twistedFiber α lam k ky) = hoppingVelocity := by
  funext kx
  exact (twistedFiber_kx_hasDerivAt α lam kx ky).deriv

theorem twistedFiber_kx_second_hasDerivAt (α lam kx ky : ℝ) :
    HasDerivAt (deriv (fun k => twistedFiber α lam k ky)) (-hopping kx) kx := by
  rw [twistedFiber_kx_deriv, ← hopping_deriv]
  exact hopping_second_hasDerivAt kx

theorem twistedFiber_ky_hasDerivAt (α lam kx ky : ℝ) :
    HasDerivAt (fun k => twistedFiber α lam kx k)
      (((2 * lam : ℝ) : ℂ) • cosineVelocity α ky) ky :=
  ((cosine_hasDerivAt α ky).const_smul ((2 * lam : ℝ) : ℂ)).const_add _

theorem twistedFiber_ky_deriv (α lam kx : ℝ) :
    deriv (fun k => twistedFiber α lam kx k) =
      fun k => ((2 * lam : ℝ) : ℂ) • cosineVelocity α k := by
  funext ky
  exact (twistedFiber_ky_hasDerivAt α lam kx ky).deriv

theorem twistedFiber_ky_second_hasDerivAt (α lam kx ky : ℝ) :
    HasDerivAt (deriv (fun k => twistedFiber α lam kx k))
      (-((2 * lam : ℝ) : ℂ) • amoCosOperator α ky) ky := by
  rw [twistedFiber_ky_deriv, ← cosine_deriv]
  simpa only [smul_neg, neg_smul] using
    (cosine_second_hasDerivAt α ky).const_smul ((2 * lam : ℝ) : ℂ)

/-- The exact displayed Landau identity, at arbitrary horizontal and vertical
phases, for bounded operators on the physical one-dimensional fiber. -/
theorem landau_coupling_phase_identity (α lam kx ky : ℝ) :
    ((2 * lam : ℝ) : ℂ) • deriv (fun t => twistedFiber α t kx ky) lam =
      deriv (deriv (fun k => twistedFiber α lam k ky)) kx -
        deriv (deriv (fun k => twistedFiber α lam kx k)) ky + twistedFiber α lam kx ky := by
  rw [(twistedFiber_coupling_hasDerivAt α lam kx ky).deriv,
    (twistedFiber_kx_second_hasDerivAt α lam kx ky).deriv,
    (twistedFiber_ky_second_hasDerivAt α lam kx ky).deriv, twistedFiber]
  module

end DTMAudit.ManuscriptTwistedPhase

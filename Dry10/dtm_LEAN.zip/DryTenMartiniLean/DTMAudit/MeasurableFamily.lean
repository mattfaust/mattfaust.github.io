import DTMAudit.FiberCorrespondence
import Mathlib.MeasureTheory.Function.StronglyMeasurable.Lemmas
import DTM.Background.Realization.AMOPhaseFaithful

/-!
# All bounded measurable covariant families and their trace completion

Families are actual bounded operators on the original chain Hilbert space,
strongly measurable on every vector orbit and essentially uniformly bounded,
with almost-everywhere covariance under actual integer shifts. This uses strong
operator measurability, not the stricter operator-norm Bochner measurability.

The source map is the literal fiber origin column. Its genuine Haar-averaged
trace pairing, positivity, cyclicity, normalization and faithfulness modulo
almost-everywhere equality are proved. Left and right multiplication are actual
fiber products; both are proved bounded in the trace norm before completion.

The source-column submodule realizes the quotient by equality almost everywhere.
Its Hilbert completion is onto the actual normalized Bochner phase L2 space;
density is proved using the explicit original magnetic monomial families. The
Fourier and magnetic-trace identifications agree on those monomials.
Both natural multiplication actions are extended continuously from the genuine
source products, with their source-class formulas and norm estimates proved.

Operator bounds are arbitrary nonnegative essential uniform bound witnesses.
This module does not construct a von Neumann algebra typeclass, prove normality
of the trace, or identify arbitrary bounded-Borel spectral fiber families with
an operator functional calculus. Such spectral source identifications remain
separate from the all-family trace-space realization proved here.
-/

noncomputable section
set_option maxHeartbeats 800000
open MeasureTheory Filter Topology
open scoped NNReal
namespace DTMAudit.MeasurableFamily
open CriticalDTM PhaseFourier FiberCorrespondence

/-- Strong-operator measurability requires measurable vector orbits, not
Bochner measurability in the nonseparable operator-norm topology. -/
def SOTMeasurable (A : AddCircle (1 : ℝ) → AMOBoundedOperator) : Prop :=
  ∀ u : AMOHilbert, AEStronglyMeasurable (fun t => A t u) phaseMeasure

/-- Countably many measurable coordinates suffice for strong measurability in
the actual infinite chain Hilbert space. -/
theorem aestronglyMeasurable_of_coordinates {f : AddCircle (1 : ℝ) → AMOHilbert}
    (hf : ∀ n : ℤ, AEStronglyMeasurable (fun t => f t n) phaseMeasure) :
    AEStronglyMeasurable f phaseMeasure := by
  classical
  apply aestronglyMeasurable_of_tendsto_ae (atTop : Filter (Finset ℤ))
    (f := fun s t => ∑ n ∈ s, lp.single 2 n (f t n))
  · intro s
    exact Finset.aestronglyMeasurable_sum s (fun n _ =>
      (PhaseCoordinates.siteSingle n).continuous.comp_aestronglyMeasurable (hf n))
  · exact Filter.Eventually.of_forall fun t => lp.hasSum_single (by norm_num) (f t)

theorem star_apply_coordinate (A : AMOBoundedOperator) (u : AMOHilbert) (n : ℤ) :
    star A u n = @inner ℂ AMOHilbert _ (A (lp.single 2 n (1 : ℂ))) u := by
  have h := ContinuousLinearMap.adjoint_inner_right A (lp.single 2 n (1 : ℂ)) u
  simpa only [← ContinuousLinearMap.star_eq_adjoint, lp.inner_single_left,
    RCLike.inner_apply, map_one, one_mul, mul_one] using h

theorem SOTMeasurable.star {A : AddCircle (1 : ℝ) → AMOBoundedOperator}
    (hA : SOTMeasurable A) : SOTMeasurable (fun t => star (A t)) := by
  intro u
  apply aestronglyMeasurable_of_coordinates
  intro n
  simp only [star_apply_coordinate]
  exact (hA (lp.single 2 n (1 : ℂ))).inner aestronglyMeasurable_const

theorem SOTMeasurable.apply (A : AddCircle (1 : ℝ) → AMOBoundedOperator)
    (hA : SOTMeasurable A) {f : AddCircle (1 : ℝ) → AMOHilbert}
    (hf : AEStronglyMeasurable f phaseMeasure) :
    AEStronglyMeasurable (fun t => A t (f t)) phaseMeasure := by
  classical
  have aux : ∀ (g : AddCircle (1 : ℝ) → AMOHilbert), StronglyMeasurable g →
      AEStronglyMeasurable (fun t => A t (g t)) phaseMeasure := by
    intro g hg
    induction g, hg using StronglyMeasurable.induction' with
    | const u => exact hA u
    | @pcw f g s hf hg hs ihf ihg =>
      have heq : (fun t => A t ((s.piecewise f g) t)) =
          s.piecewise (fun t => A t (f t)) (fun t => A t (g t)) := by
        funext t
        by_cases ht : t ∈ s <;> simp [Set.piecewise, ht]
      rw [heq]
      exact AEStronglyMeasurable.piecewise hs ihf.restrict ihg.restrict
    | @lim f g hf hg ih hlim =>
      apply aestronglyMeasurable_of_tendsto_ae atTop ih
      exact Filter.Eventually.of_forall fun t => ((A t).continuous.tendsto (g t)).comp (hlim t)
  apply (aux (hf.mk f) hf.stronglyMeasurable_mk).congr
  filter_upwards [hf.ae_eq_mk] with t ht
  rw [ht]

/-- Actual operators with an essential uniform bound; the bound is a witness. -/
structure BoundedFamily where
  fiber : AddCircle (1 : ℝ) → AMOBoundedOperator
  measurable : SOTMeasurable fiber
  bound : ℝ≥0
  norm_le_bound : ∀ᵐ t ∂phaseMeasure, ‖fiber t‖ ≤ bound

def BoundedFamily.adjoint (A : BoundedFamily) : BoundedFamily where
  fiber t := star (A.fiber t)
  measurable := A.measurable.star
  bound := A.bound
  norm_le_bound := by simpa only [ContinuousLinearMap.star_eq_adjoint,
    ContinuousLinearMap.adjoint.norm_map] using A.norm_le_bound

def BoundedFamily.add (A B : BoundedFamily) : BoundedFamily where
  fiber t := A.fiber t + B.fiber t
  measurable u := (A.measurable u).add (B.measurable u)
  bound := A.bound + B.bound
  norm_le_bound := by
    filter_upwards [A.norm_le_bound, B.norm_le_bound] with t hA hB
    exact (norm_add_le _ _).trans (add_le_add hA hB)

/-- Covariance of the original family is an almost-everywhere operator identity
under the actual integer chain shift. -/
def Covariant (α : ℝ) (A : AddCircle (1 : ℝ) → AMOBoundedOperator) : Prop :=
  ∀ k : ℤ, (fun t => A (t + ((α * (k : ℝ) : ℝ) : AddCircle (1 : ℝ)))) =ᵐ[phaseMeasure]
    fun t => amoShiftConjugation k (A t)

structure CovariantFamily (α : ℝ) extends BoundedFamily where
  covariance : Covariant α fiber

def CovariantFamily.zero (α : ℝ) : CovariantFamily α where
  fiber _ := 0
  measurable _ := aestronglyMeasurable_const
  bound := 0
  norm_le_bound := Filter.Eventually.of_forall fun _ => by simp
  covariance _ := Filter.Eventually.of_forall fun _ => (map_zero _).symm

end DTMAudit.MeasurableFamily

set_option synthInstance.maxHeartbeats 200000
namespace DTMAudit.MeasurableFamily
open CriticalDTM PhaseFourier FiberCorrespondence MeasureTheory
open scoped Topology

end DTMAudit.MeasurableFamily

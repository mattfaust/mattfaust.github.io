import DTM.NewResults.Exposition.CyclicSpace
import DTM.NewResults.Brown.ChiralGauge
import Mathlib.Data.Matrix.ConjTranspose
import Mathlib.Data.Matrix.Notation
import Mathlib.Tactic.FinCases
import DTM.NewResults.Brown.MagneticFourier
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Tactic.NoncommRing
import Mathlib.MeasureTheory.Integral.CircleIntegral
import DTM.NewResults.Brown.FunctionalCalculusBridge
import Mathlib.Analysis.Matrix
import Mathlib.LinearAlgebra.Matrix.Hermitian
import Mathlib.Analysis.Calculus.Deriv.Star
import Mathlib.Topology.ContinuousMap.Units
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic
import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Topology.ContinuousMap.StarOrdered
import Mathlib.Analysis.CStarAlgebra.CStarMatrix

/-!
# The paired magnetic difference operator on the infinite lattice

The operator is half the difference between the actual magnetic Hamiltonian
and its commuting magnetic partner, in the existing lattice representation.
-/

noncomputable section
namespace DTMAudit.Paired
open CriticalDTM CriticalDTM.Chiral
open scoped InnerProductSpace

/-- `H₋` in the actual lattice representation. -/
def differenceOperator (α lam : ℝ) : MagneticBoundedOperator :=
  (1 / 2 : ℂ) • (hOperator α (lam : ℂ) - conjugateOperator α (lam : ℂ))

end DTMAudit.Paired

import DTMAudit.Angular
import DTMAudit.SymmetricGauge
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

/-!
# Radian hopping phases and the coupling insertion

The radian phase derivative is proved by differentiating the actual exponential phases.
The row is the symmetric-gauge mean row, with independent
horizontal and vertical radian phases. All derivatives below are `deriv`,
supported by explicit `HasDerivAt` proofs.
-/

noncomputable section
namespace DTMAudit.PhaseDerivative
open CriticalDTM

/-- A radian phase with a constant complex generator. -/
def phase (c : ℂ) (k : ℝ) : ℂ := Complex.exp ((k : ℂ) * c)

theorem phase_hasDerivAt (c : ℂ) (k : ℝ) :
    HasDerivAt (phase c) (phase c k * c) k := by
  simpa only [phase, Complex.ofRealCLM_apply, Complex.ofReal_one, one_mul]
    using ((Complex.ofRealCLM.hasDerivAt (x := k)).mul_const c).cexp

/-- The actual bounded mean operator's source, in symmetric gauge. The gauge
fixes the source, so this is the source column of the transported operator. -/
def source (α lam : ℝ) : MagneticHilbert :=
  SymmetricGauge.unitary α (Chiral.averageOperator α lam hilbertRoot)

theorem source_eq (α lam : ℝ) :
    source α lam = SymmetricGauge.unitary α (hOperator α (lam : ℂ) hilbertRoot) := by
  rw [source, Chiral.averageOperator_eq_on_common α lam hilbertRoot
    (Chiral.root_mem_commonSpace α lam)]

theorem source_hasDerivAt (α lam : ℝ) :
    HasDerivAt (source α) (SymmetricGauge.unitary α verticalRoot) lam := by
  have h := (hOperator_hasDerivAt α (lam : ℂ)).clm_apply
    (hasDerivAt_const (lam : ℂ) hilbertRoot)
  have hs : HasDerivAt (fun t : ℝ => hOperator α (t : ℂ) hilbertRoot)
      verticalRoot lam := by
    simpa only [Function.comp_def, Complex.ofRealCLM_apply, Complex.ofReal_one,
      one_smul, map_zero, add_zero, verticalOperator_root]
      using h.scomp lam Complex.ofRealCLM.hasDerivAt
  let J := (SymmetricGauge.unitary α : MagneticHilbert →L[ℂ] MagneticHilbert).restrictScalars ℝ
  have hj := J.hasFDerivAt.comp_hasDerivAt lam hs
  change HasDerivAt
    (fun t : ℝ => SymmetricGauge.unitary α (hOperator α (t : ℂ) hilbertRoot))
    (SymmetricGauge.unitary α verticalRoot) lam at hj
  have heq : source α = fun t : ℝ =>
      SymmetricGauge.unitary α (hOperator α (t : ℂ) hilbertRoot) := by
    funext t
    exact source_eq α t
  rw [heq]
  exact hj

end DTMAudit.PhaseDerivative

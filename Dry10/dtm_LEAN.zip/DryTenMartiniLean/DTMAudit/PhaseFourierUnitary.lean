import Mathlib.Analysis.Fourier.AddCircle
import DTMAudit.SymmetricGauge
import Mathlib.MeasureTheory.Function.L2Space

/-! # Fourier coordinates for vectorized phase families

The normalized phase-family Hilbert space is a genuine Bochner L² space.
This file constructs its unitary to the magnetic lattice and proves the exact
Fourier coefficient formula and Parseval identity, including the symmetric gauge.
The algebraic identification of covariant kernels is proved separately. -/
noncomputable section
set_option maxHeartbeats 800000
open MeasureTheory
open scoped ENNReal
namespace DTMAudit.PhaseFourier

instance : Fact (0 < (1 : ℝ)) := ⟨by norm_num⟩
abbrev PhaseL2 := Lp ℂ 2 (@AddCircle.haarAddCircle 1 inferInstance)

end DTMAudit.PhaseFourier

open MeasureTheory
open scoped ENNReal
set_option maxHeartbeats 800000

noncomputable section
namespace DTMAudit.PhaseCoordinates

abbrev Site := lp (fun _ : ℤ => ℂ) 2

variable {X : Type*} [MeasurableSpace X] (μ : Measure X)

def siteSingle (n : ℤ) : ℂ →ₗᵢ[ℂ] Site where
  toLinearMap := lp.lsingle (𝕜 := ℂ) (E := fun _ : ℤ => ℂ) 2 n
  norm_map' z := by
    change ‖lp.single (E := fun _ : ℤ => ℂ) 2 n z‖ = ‖z‖
    exact lp.norm_single (E := fun _ : ℤ => ℂ) (p := 2) (by norm_num) n z

end DTMAudit.PhaseCoordinates


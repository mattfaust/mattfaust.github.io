import DTM.Background.Exposition.SingularLogIntegral
import DTM.Background.AllCouplingExtension.MagneticDOSDuality
import DTM.Background.SpectralVanishing.AMOSpectralLyapunov

/-! Exact all-energy logarithmic-potential scaling and the all-positive
spectral normalization. The singular point is
handled by the proved atom-free spectral measure; log(0) is not used to
justify a false pointwise log-product identity. -/
noncomputable section
namespace DTMAudit
open CriticalDTM MeasureTheory Set

/-- Aubry scaling for the actual singular spectral integrals at all energies. -/
theorem potential_aubry (α : ℝ) {lam : ℝ} (hlam : 0 < lam) (E : ℝ) :
    (∫ x : ℝ, Real.log |lam * E - x| ∂magneticRealSpectralMeasure α lam) =
      Real.log lam +
      ∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam⁻¹ := by
  rw [magneticRealSpectralMeasure_aubry α hlam,
    integral_map (φ := fun x : ℝ => lam * x)
      (f := fun x : ℝ => Real.log |lam * E - x|)
      (continuous_const.mul continuous_id).measurable.aemeasurable
      ((continuous_const.sub continuous_id).abs.measurable.log.aestronglyMeasurable)]
  have hne : ∀ᵐ x ∂magneticRealSpectralMeasure α lam⁻¹, x ≠ E := by
    apply ae_iff.mpr
    simpa using magneticRealSpectralMeasure_singleton_eq_zero α lam⁻¹ E
  calc
    _ = ∫ x : ℝ, (Real.log lam + Real.log |E - x|)
        ∂magneticRealSpectralMeasure α lam⁻¹ := by
      apply integral_congr_ae
      filter_upwards [hne] with x hx
      rw [← mul_sub, abs_mul, abs_of_pos hlam,
        Real.log_mul (ne_of_gt hlam) (abs_ne_zero.mpr (sub_ne_zero.mpr hx.symm))]
    _ = _ := by
      rw [integral_add (integrable_const _) (magnetic_realLogKernel_integrable α lam⁻¹ E)]
      simp

/-- The same exact identity for the globally defined extended potential. -/
theorem total_potential_aubry (α : ℝ) {lam : ℝ} (hlam : 0 < lam) (E : ℝ) :
    magneticTotalLogPotential α (lam, lam * E) =
      (Real.log lam : EReal) + magneticTotalLogPotential α (lam⁻¹, E) := by
  rw [magneticTotalLogPotential_eq_singularIntegral,
    magneticTotalLogPotential_eq_singularIntegral, potential_aubry α hlam E,
    EReal.coe_add]

/-- Spectral potential normalization for every positive coupling, including supercritical. -/
theorem spectral_potential_normalization {α lam : ℝ}
    (hα : Irrational α) (hlam : 0 < lam) (E : ℝ)
    (hE : E ∈ magneticRealSpectrumSet α lam) :
    magneticTotalLogPotential α (lam,E) = (max 0 (Real.log lam) : ℝ) := by
  by_cases hsmall : lam ≤ 1
  · rw [magneticTotalLogPotential_eq_zero_on_spectrum hα hlam hsmall E hE]
    have hlog : Real.log lam ≤ 0 := Real.log_nonpos hlam.le hsmall
    simp [max_eq_left hlog]
  · have hlarge : 1 < lam := lt_of_not_ge hsmall
    have hinv : lam⁻¹ ≤ 1 := (inv_le_one₀ hlam).mpr hlarge.le
    have hspec : E / lam ∈ magneticRealSpectrumSet α lam⁻¹ := by
      have h := (magnetic_spectrum_aubry α
        (Complex.ofReal_ne_zero.mpr (ne_of_gt hlam)) (E : ℂ)).mp hE
      simpa only [← Complex.ofReal_inv, ← Complex.ofReal_div] using h
    have hid : lam * (E / lam) = E := by field_simp
    rw [← hid, total_potential_aubry α hlam (E / lam),
      magneticTotalLogPotential_eq_zero_on_spectrum hα (inv_pos.mpr hlam) hinv
        (E / lam) hspec, add_zero]
    have hlog : 0 ≤ Real.log lam := Real.log_nonneg hlarge.le
    simp only [max_eq_right hlog]

end DTMAudit

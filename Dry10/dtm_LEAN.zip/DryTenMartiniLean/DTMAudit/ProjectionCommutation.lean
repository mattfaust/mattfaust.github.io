import DTMAudit.BoundedSourceLimits

set_option autoImplicit false
noncomputable section
namespace DTMAudit.ProjectionCommutation
open CriticalDTM DTMAudit.FullFermiProjection DTMAudit.BoundedSourceLimits

/-- A subspace invariant under B* has a B-invariant orthogonal complement. -/
theorem orthogonal_invariant_of_adjoint (K : Submodule ℂ MagneticHilbert)
    (B : MagneticBoundedOperator) (hK : Set.MapsTo (star B : MagneticBoundedOperator) K K) :
    Set.MapsTo B Kᗮ Kᗮ := by
  intro u hu v hv
  rw [← ContinuousLinearMap.adjoint_inner_left]
  exact hu _ (by simpa only [ContinuousLinearMap.star_eq_adjoint] using hK hv)

/-- For self-adjoint A, its support projection commutes with every operator
commuting with A; the second operator need not be self-adjoint. -/
theorem supportProjection_commute_of_selfAdjoint (A B : MagneticBoundedOperator)
    (hA : IsSelfAdjoint A) (hAB : Commute A B) :
    Commute (supportProjection A) B := by
  have hABstar : Commute A (star B) := by
    have h := congrArg star hAB.eq
    simpa only [star_mul, hA.star_eq] using h.symm
  change supportProjection A * B = B * supportProjection A
  apply ContinuousLinearMap.ext
  intro u
  change ((supportSpace A).orthogonalProjection (B u) : MagneticHilbert) =
    B ((supportSpace A).orthogonalProjection u)
  apply (supportSpace A).eq_orthogonalProjection_of_mem_orthogonal
  · exact supportSpace_invariant A B hAB ((supportSpace A).orthogonalProjection u).property
  · rw [← map_sub]
    exact orthogonal_invariant_of_adjoint (supportSpace A) B
      (supportSpace_invariant A (star B) hABstar)
      ((supportSpace A).sub_orthogonalProjection_mem_orthogonal u)

/-- Every actual lower projection commutes with the entire right magnetic algebra. -/
theorem lowerProjection_right_commute (α lam E : ℝ) (B : magneticAlgebra α) :
    Commute (lowerProjection α lam E) (rightAlgebraAction α B) := by
  apply supportProjection_commute_of_selfAdjoint
  · exact cfc_predicate _ _
  · exact rightAlgebraAction_commute α
      ⟨cutWeightOperator α lam E, cutWeightOperator_mem_algebra α lam E⟩ B

/-- A full-space right-commuting operator with the actual threshold root is
exactly the already constructed lower spectral projection. -/
theorem eq_lowerProjection_of_root (α lam E : ℝ) (T : MagneticBoundedOperator)
    (hT : ∀ B : magneticAlgebra α, Commute T (rightAlgebraAction α B))
    (hroot : T hilbertRoot = SpectralSources.thresholdSource α lam E) :
    T = lowerProjection α lam E := by
  apply operator_eq_of_root α T (lowerProjection α lam E) hT
    (lowerProjection_right_commute α lam E)
  exact hroot.trans (lowerProjection_root α lam E).symm

end DTMAudit.ProjectionCommutation

import DTMAudit.SpectralHeight

/-! # The real-energy Thouless identity for the actual transfer exponent

Every transfer-matrix entry is a Dirichlet determinant, possibly with one
or both endpoints removed. Its zeros are real. Moving vertically away from
the real energy axis therefore increases its modulus. A fixed factor four
compares the transfer norms; after dividing their logarithms by the length,
this factor disappears. The established nonreal identity and its boundary
limit then give equality at every real energy.

External-input correspondence for manuscript Theorem 3.2:
* [34] Thouless (1972): the density-of-states--Lyapunov identity.
* [6] Avron--Simon: the Thouless identity, with [11] Craig--Simon,
  Theorem 4.2, for its real-energy extension.
* [10] Bourgain--Jitomirskaya (2002), Theorem 1: continuity; Corollary 2:
  the spectral value max(0, log lam) at irrational frequency.

This module and its dependencies prove the AMO conclusions required at those
citation sites, including logarithmic integrability, energy continuity, and
spectral normalization. They provide replacement proofs of those conclusions,
not a formalization of every argument in the cited papers. The real-energy
identity uses the vertical determinant comparison described above instead of
Craig--Simon's subharmonic-extension proof. Spectral vanishing uses the proved
record-scale positive-persistence estimates. -/

noncomputable section
namespace DTMAudit.RealThouless
open CriticalDTM MeasureTheory Filter Set
open scoped Topology

theorem determinant_real_norm_le (α lam θ : ℝ) (n : ℕ) (z : ℂ) :
    ‖Matrix.det ((z.re : ℂ) • (1 : Matrix (Fin n) (Fin n) ℂ) -
      amoFiniteMatrix α lam θ n)‖ ≤
    ‖Matrix.det (z • (1 : Matrix (Fin n) (Fin n) ℂ) - amoFiniteMatrix α lam θ n)‖ := by
  rw [amoFiniteMatrix_det_sub_eq_prod, amoFiniteMatrix_det_sub_eq_prod, norm_prod, norm_prod]
  apply Finset.prod_le_prod
  · intro i _
    exact norm_nonneg _
  · intro i _
    simpa only [← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs,
      Complex.sub_re, Complex.ofReal_re] using
      Complex.abs_re_le_norm (z - (amoFiniteEigenvalues α lam θ n i : ℂ))

theorem transfer_norm_real_le (α lam θ : ℝ) (n : ℕ) (z : ℂ) :
    amoTransferNorm (amoTransferProduct α lam (z.re : ℂ) θ (n + 2)) ≤
      4 * amoTransferNorm (amoTransferProduct α lam z θ (n + 2)) := by
  have h00 : ‖amoTransferProduct α lam (z.re : ℂ) θ (n + 2) 0 0‖ ≤
      amoTransferNorm (amoTransferProduct α lam z θ (n + 2)) := by
    apply le_trans _ (norm_entry_le_amoTransferNorm _ 0 0)
    rw [← amoFiniteMatrix_det_eq_transferProduct, ← amoFiniteMatrix_det_eq_transferProduct]
    exact determinant_real_norm_le α lam θ (n + 2) z
  have h10 : ‖amoTransferProduct α lam (z.re : ℂ) θ (n + 2) 1 0‖ ≤
      amoTransferNorm (amoTransferProduct α lam z θ (n + 2)) := by
    apply le_trans _ (norm_entry_le_amoTransferNorm _ 1 0)
    rw [amoTransferProduct_entry10, amoTransferProduct_entry10]
    exact determinant_real_norm_le α lam θ (n + 1) z
  have h01 : ‖amoTransferProduct α lam (z.re : ℂ) θ (n + 2) 0 1‖ ≤
      amoTransferNorm (amoTransferProduct α lam z θ (n + 2)) := by
    apply le_trans _ (norm_entry_le_amoTransferNorm _ 0 1)
    rw [amoTransferProduct_entry01, amoTransferProduct_entry01, norm_neg, norm_neg]
    exact determinant_real_norm_le α lam _ (n + 1) z
  have h11 : ‖amoTransferProduct α lam (z.re : ℂ) θ (n + 2) 1 1‖ ≤
      amoTransferNorm (amoTransferProduct α lam z θ (n + 2)) := by
    apply le_trans _ (norm_entry_le_amoTransferNorm _ 1 1)
    rw [amoTransferProduct_entry11, amoTransferProduct_entry11, norm_neg, norm_neg]
    exact determinant_real_norm_le α lam _ n z
  have h := amoTransferNorm_le_four_entries (amoTransferProduct α lam (z.re : ℂ) θ (n + 2))
  linarith

theorem transfer_log_norm_real_le (α lam θ : ℝ) (n : ℕ) (z : ℂ) :
    amoTransferLogNorm α lam (z.re : ℂ) θ (n + 2) ≤
      Real.log 4 + amoTransferLogNorm α lam z θ (n + 2) := by
  have h := Real.log_le_log (amoTransferProduct_norm_pos α lam (z.re : ℂ) θ (n + 2))
    (transfer_norm_real_le α lam θ n z)
  rw [Real.log_mul (by norm_num : (4 : ℝ) ≠ 0)
    (ne_of_gt (amoTransferProduct_norm_pos α lam z θ (n + 2)))] at h
  exact h

theorem finite_lyapunov_real_le (α lam : ℝ) (n : ℕ) (z : ℂ) :
    amoFiniteLyapunov α lam (z.re : ℂ) (n + 2) ≤
      Real.log 4 / ((n + 2 : ℕ) : ℝ) + amoFiniteLyapunov α lam z (n + 2) := by
  have hperiod : 0 < 2 * Real.pi := by positivity
  have hreal := amoTransferLogNorm_intervalIntegrable α lam (z.re : ℂ) (n + 2) 0 (2 * Real.pi)
  have hcplx := amoTransferLogNorm_intervalIntegrable α lam z (n + 2) 0 (2 * Real.pi)
  have hi := intervalIntegral.integral_mono hperiod.le hreal
    ((continuous_const.intervalIntegrable 0 (2 * Real.pi)).add hcplx)
    (fun θ => transfer_log_norm_real_le α lam θ n z)
  rw [intervalIntegral.integral_add
    (continuous_const.intervalIntegrable 0 (2 * Real.pi)) hcplx] at hi
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hi
  have havg := (div_le_div_of_nonneg_right hi hperiod.le)
  rw [add_div, mul_div_cancel_left₀ _ hperiod.ne'] at havg
  have hn : (0 : ℝ) < ((n + 2 : ℕ) : ℝ) := by positivity
  have h := div_le_div_of_nonneg_right havg hn.le
  simpa only [add_div, amoFiniteLyapunov, amoTransferLogAverage] using h

theorem lyapunov_real_le_complex (α lam : ℝ) (z : ℂ) :
    amoLyapunov α lam (z.re : ℂ) ≤ amoLyapunov α lam z := by
  have hl := (tendsto_amoFiniteLyapunov α lam (z.re : ℂ)).comp (tendsto_add_atTop_nat 2)
  have hr := ((tendsto_const_div_atTop_nhds_zero_nat (Real.log 4)).comp
    (tendsto_add_atTop_nat 2)).add
      ((tendsto_amoFiniteLyapunov α lam z).comp (tendsto_add_atTop_nat 2))
  simpa only [zero_add] using le_of_tendsto_of_tendsto hl hr
    (Filter.Eventually.of_forall (fun n => finite_lyapunov_real_le α lam n z))

/-- The independently defined transfer exponent equals the total spectral potential. -/
theorem lyapunov_eq_total_potential (α lam E : ℝ) :
    (amoLyapunov α lam (E : ℂ) : EReal) = magneticTotalLogPotential α (lam, E) := by
  rw [← amoTotalLogPotential_eq_magnetic]
  apply le_antisymm _ (amoTotalLogPotential_le_amoLyapunov α lam E)
  apply ge_of_tendsto' (amoComplexLogPotential_tendsto_total α lam E)
  intro n
  rw [amoComplexLogPotential_eq_amoLyapunov α lam
    (by simpa using logRegularizationScale_pos n)]
  apply EReal.coe_le_coe_iff.mpr
  simpa using lyapunov_real_le_complex α lam
    ((E : ℂ) + (logRegularizationScale n : ℂ) * Complex.I)

/-- Real-energy Thouless formula, with no spectral, irrationality or coupling restriction. -/
theorem lyapunov_eq_log_integral (α lam E : ℝ) :
    amoLyapunov α lam (E : ℂ) =
      ∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam := by
  apply EReal.coe_injective
  rw [lyapunov_eq_total_potential, magneticTotalLogPotential_eq_singularIntegral]

/-- Explicit quantitative finiteness and nonnegativity, from determinant
one and the uniform one-step transfer bound.  Integrability is a separate
conjunct so that a totalized Bochner integral cannot hide divergence. -/
theorem log_integral_integrable_and_bounds (α lam E : ℝ) :
    Integrable (fun x : ℝ => Real.log |E - x|) (magneticRealSpectralMeasure α lam) ∧
      0 ≤ (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) ∧
      (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) ≤
        Real.log (|E| + 2 * |lam| + 2) := by
  refine ⟨magnetic_realLogKernel_integrable α lam E, ?_, ?_⟩
  · rw [← lyapunov_eq_log_integral]
    exact amoLyapunov_nonneg α lam (E : ℂ)
  · rw [← lyapunov_eq_log_integral]
    simpa only [amoTransferBound, Complex.norm_real, Real.norm_eq_abs] using
      amoLyapunov_le_log_bound α lam (E : ℂ)

/-- The cited spectral normalization for the independently defined transfer exponent. -/
theorem spectral_lyapunov_normalization {α lam : ℝ}
    (hα : Irrational α) (hlam : 0 < lam) (E : ℝ)
    (hE : E ∈ magneticRealSpectrumSet α lam) :
    amoLyapunov α lam (E : ℂ) = max 0 (Real.log lam) := by
  apply EReal.coe_injective
  rw [lyapunov_eq_total_potential, DTMAudit.spectral_potential_normalization hα hlam E hE]

/-- Manuscript Theorem 3.2: logarithmic integrability, continuity,
nonnegativity, and the spectral value max(0, log lam). Together with
`lyapunov_eq_log_integral`, this supplies the required Thouless,
Avron--Simon/Craig--Simon, and Bourgain--Jitomirskaya conclusions through the
replacement proofs described above, without asserting identity of proofs. -/
theorem normalization_statement {α lam : ℝ}
    (hα : Irrational α) (hlam : 0 < lam) :
    (∀ E : ℝ, Integrable (fun x : ℝ => Real.log |E - x|)
      (magneticRealSpectralMeasure α lam)) ∧
    Continuous (fun E : ℝ =>
      ∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) ∧
    (∀ E : ℝ, 0 ≤ ∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) ∧
    (∀ E ∈ magneticRealSpectrumSet α lam,
      (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) =
        max 0 (Real.log lam)) := by
  refine ⟨magnetic_realLogKernel_integrable α lam,
    DTMAudit.real_log_integral_continuous hα hlam,
    fun E => (log_integral_integrable_and_bounds α lam E).2.1, ?_⟩
  intro E hE
  rw [← lyapunov_eq_log_integral]
  exact spectral_lyapunov_normalization hα hlam E hE

end DTMAudit.RealThouless

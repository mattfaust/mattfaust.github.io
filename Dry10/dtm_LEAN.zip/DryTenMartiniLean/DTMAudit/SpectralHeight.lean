import DTMAudit.PotentialDuality
import DTM.Background.Potential.LogPotentialBoundary

/-! # The full real spectral complement from the logarithmic height

Strict positivity is local: a nonnegative strictly concave function cannot
vanish at an interior point. Applying this on a small resolvent interval
handles bounded gaps and the exterior components by the same argument.
Spectral normalization and Aubry scaling then give the all-positive-coupling
equivalence, without an additional Lyapunov or gap-existence assumption. -/

noncomputable section
namespace DTMAudit
open CriticalDTM Set MeasureTheory
open scoped Topology

theorem real_log_integral_eq_resolvent_height (α lam E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (hOperator α (lam : ℂ))) :
    (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) =
      magneticLogPotential α lam E := by
  apply EReal.coe_injective
  rw [← magneticTotalLogPotential_eq_singularIntegral,
    magneticTotalLogPotential_eq_magneticLogPotential α lam E hE]

theorem real_log_integral_continuous_of_spectral_vanishing (α lam : ℝ)
    (hzero : ∀ E ∈ magneticRealSpectrumSet α lam,
      magneticTotalLogPotential α (lam, E) = 0) :
    Continuous (fun E : ℝ =>
      ∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) := by
  have heq (E : ℝ) :
      (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) =
        magneticPositiveLogPotential α (lam, E) := by
    by_cases hs : E ∈ magneticRealSpectrumSet α lam
    · have hz : (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) = 0 := by
        apply EReal.coe_injective
        rw [← magneticTotalLogPotential_eq_singularIntegral, hzero E hs, EReal.coe_zero]
      rw [hz, magneticPositiveLogPotential_eq_zero_of_total_eq_zero α (lam, E) (hzero E hs)]
    · have hr := spectrum.not_mem_iff.mp hs
      rw [real_log_integral_eq_resolvent_height α lam E hr,
        magneticPositiveLogPotential_eq_of_spectral_vanishing α lam hzero E hr]
  simpa only [heq] using
    magneticPositiveLogPotential_energy_continuous_of_spectral_vanishing α lam hzero

/-- The finite singular logarithmic integral is continuous at every real energy. -/
theorem real_log_integral_continuous {α lam : ℝ}
    (hα : Irrational α) (hlam : 0 < lam) :
    Continuous (fun E : ℝ =>
      ∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) := by
  by_cases hsmall : lam ≤ 1
  · exact real_log_integral_continuous_of_spectral_vanishing α lam
      (magneticTotalLogPotential_eq_zero_on_spectrum hα hlam hsmall)
  · have hlarge : 1 < lam := lt_of_not_ge hsmall
    have hinv : lam⁻¹ ≤ 1 := (inv_le_one₀ hlam).mpr hlarge.le
    have hc := real_log_integral_continuous_of_spectral_vanishing α lam⁻¹
      (magneticTotalLogPotential_eq_zero_on_spectrum hα (inv_pos.mpr hlam) hinv)
    have heq (E : ℝ) :
        (∫ x : ℝ, Real.log |E - x| ∂magneticRealSpectralMeasure α lam) =
          Real.log lam +
            ∫ x : ℝ, Real.log |E / lam - x| ∂magneticRealSpectralMeasure α lam⁻¹ := by
      have h := potential_aubry α hlam (E / lam)
      have hid : lam * (E / lam) = E := by field_simp
      rwa [hid] at h
    simp_rw [heq]
    exact continuous_const.add (hc.comp (continuous_id.div_const lam))

end DTMAudit

import DTMAudit.BoundedSpectralApproximation
import Mathlib.Algebra.BigOperators.Group.Finset.Indicator

set_option autoImplicit false
set_option maxHeartbeats 1000000
noncomputable section
namespace DTMAudit.SpectralIndicators
open CriticalDTM DTMAudit.SpectralSources DTMAudit.BoundedSpectralApproximation MeasureTheory Set Filter
open scoped Topology symmDiff BigOperators

/-- The actual real spectral L² indicator of any measurable spectral set. -/
def spectralIndicatorL2 (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam)) (hs : MeasurableSet s) :
    SpectralL2 α lam := indicatorConstLp 2 hs (measure_ne_top (magneticSpectralMeasure α lam) s) (1 : ℝ)

theorem indicator_one_bound {X : Type*} (s : Set X) (x : X) :
    ‖s.indicator (fun _ => (1 : ℝ)) x‖ ≤ 1 := by
  classical
  by_cases hx : x ∈ s <;> simp [hx]

end DTMAudit.SpectralIndicators

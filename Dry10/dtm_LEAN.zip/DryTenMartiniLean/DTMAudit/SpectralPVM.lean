import DTMAudit.SpectralIndicators
import DTMAudit.BoundedBorelCalculus
import DTMAudit.ProjectionCommutation

set_option autoImplicit false
set_option maxHeartbeats 1200000
noncomputable section
namespace DTMAudit.SpectralPVM
open CriticalDTM DTMAudit.SpectralSources DTMAudit.BoundedSpectralApproximation MeasureTheory
open DTMAudit.BoundedBorelCalculus DTMAudit.BoundedSourceLimits
open DTMAudit.SpectralIndicators
open scoped ContinuousFunctionalCalculus Topology BigOperators

def indicatorFunction (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam)) :
    MagneticRealSpectrum α lam → ℝ := s.indicator (fun _ => 1)

theorem indicatorFunction_measurable (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam))
    (hs : MeasurableSet s) : Measurable (indicatorFunction α lam s) :=
  measurable_const.indicator hs

theorem indicatorFunction_bound (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam)) :
    ∀ᵐ x ∂magneticSpectralMeasure α lam, ‖indicatorFunction α lam s x‖ ≤ 1 :=
  Filter.Eventually.of_forall (indicator_one_bound s)

/-- The actual full-space spectral projection of every measurable spectral set. -/
def indicatorProjection (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam)) (hs : MeasurableSet s) :
    MagneticBoundedOperator :=
  boundedOperator α lam (indicatorFunction α lam s)
    (indicatorFunction_measurable α lam s hs).aestronglyMeasurable 1 zero_le_one
    (indicatorFunction_bound α lam s)

theorem indicatorProjection_root (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam)) (hs : MeasurableSet s) :
    indicatorProjection α lam s hs hilbertRoot = spectralSource α lam (spectralIndicatorL2 α lam s hs) := by
  exact boundedOperator_root _ _ _ _ _ _ _

theorem indicatorProjection_right_commute (α lam : ℝ) (s : Set (MagneticRealSpectrum α lam)) (hs : MeasurableSet s)
    (A : magneticAlgebra α) : Commute (indicatorProjection α lam s hs) (rightAlgebraAction α A) :=
  boundedOperator_right_commute ..

/-- On strict lower cuts this is exactly the existing whole-space Fermi operator. -/
theorem indicatorProjection_lower (α lam E : ℝ) :
    indicatorProjection α lam (magneticLowerSpectrum α lam E) (lowerSpectrum_measurable α lam E) =
      FullFermiProjection.lowerProjection α lam E := by
  apply ProjectionCommutation.eq_lowerProjection_of_root
  · exact indicatorProjection_right_commute α lam _ _
  · exact indicatorProjection_root α lam _ _

end DTMAudit.SpectralPVM

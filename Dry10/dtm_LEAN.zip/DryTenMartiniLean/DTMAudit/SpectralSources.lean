import DTMAudit.FermiStationarity
import Mathlib.MeasureTheory.Function.ContinuousMapDense
import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.MeasureTheory.Function.LpSpace.Indicator
import Mathlib.Topology.TietzeExtension

/-!
# Spectral L² source vectors at every real threshold

The source map begins with the actual continuous functional calculus and the
actual RMK magnetic spectral measure. Its L² norm identity and continuous-test
density construct an isometric extension to real spectral L². Every measurable
lower threshold indicator therefore supplies a stationary cyclic source,
whose squared norm is the actual IDS, including when the cut meets the spectrum.
At resolvent cuts these vectors equal the existing CFC projection sources.

The construction concerns source vectors. A bounded-Borel operator calculus,
a complex unitary onto the entire cyclic space, and the closed-span equality
for all threshold sources are separate statements and are not asserted here.
-/

set_option autoImplicit false

noncomputable section
namespace DTMAudit.SpectralSources
open CriticalDTM CriticalDTM.Chiral MeasureTheory
open DTMAudit.Paired Set
open scoped ContinuousFunctionalCalculus

local instance (α : ℝ) : NormedSpace ℝ (magneticAlgebra α) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra α)
local instance (α : ℝ) : Module ℝ (magneticAlgebra α) :=
  @Algebra.toModule ℝ (magneticAlgebra α) _ _
    (magneticAlgebra_realNormedAlgebra α).toAlgebra

local instance spectralCompactSpace (α lam : ℝ) : CompactSpace (MagneticRealSpectrum α lam) :=
  isCompact_iff_compactSpace.mp (spectrum.isCompact (magneticAlgebraHamiltonian α lam))

abbrev SpectralL2 (α lam : ℝ) := Lp ℝ 2 (magneticSpectralMeasure α lam)

/-- The source comes from the actual CFC, rather than an assumed spectral map. -/
def continuousSource (α lam : ℝ) : C(MagneticRealSpectrum α lam, ℝ) →ₗ[ℝ] MagneticHilbert where
  toFun f := ((cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f :
    magneticAlgebra α) : MagneticBoundedOperator) hilbertRoot
  map_add' f g := by simp
  map_smul' c f := by simp

/-- RMK plus the actual vector-state norm gives the spectral integral norm. -/
theorem continuousSource_norm_sq (α lam : ℝ) (f : C(MagneticRealSpectrum α lam, ℝ)) :
    ‖continuousSource α lam f‖ ^ 2 = ∫ x, f x * f x ∂magneticSpectralMeasure α lam := by
  let hH := magneticAlgebraHamiltonian_isSelfAdjoint α lam
  calc
    _ = magneticTraceReal α (star (cfcHom hH f) * cfcHom hH f) :=
      (magneticTraceReal_star_mul_self α (cfcHom hH f)).symm
    _ = magneticTraceReal α (cfcHom hH (f * f)) := by
      rw [(cfcHom_predicate hH f).star_eq]
      exact congrArg (magneticTraceReal α) (map_mul (cfcHom hH) f f).symm
    _ = _ := (magneticSpectralMeasure_integral α lam (f * f)).symm

/-- Continuous functions have the same L² norm as their actual CFC source. -/
theorem continuousSource_norm_L2 (α lam : ℝ) (f : C(MagneticRealSpectrum α lam, ℝ)) :
    ‖continuousSource α lam f‖ =
      ‖ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ f‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [continuousSource_norm_sq, ← real_inner_self_eq_norm_sq, L2.inner_def]
  apply integral_congr_ae
  filter_upwards [ContinuousMap.coeFn_toLp (𝕜 := ℝ) (p := 2) (magneticSpectralMeasure α lam) f] with x hx
  simp only [hx, real_inner_comm, RCLike.inner_apply, starRingEnd_apply, star_trivial]

/-- No extra measure hypothesis is needed for continuous-test density. -/
theorem continuousTests_dense (α lam : ℝ) :
    DenseRange (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ :
      C(MagneticRealSpectrum α lam, ℝ) →L[ℝ] SpectralL2 α lam) :=
  ContinuousMap.toLp_denseRange _ _ _ (by norm_num)

/-- The actual continuous CFC source already lies in the checked cyclic space. -/
theorem continuousSource_mem_cyclic (α lam : ℝ) (f : C(MagneticRealSpectrum α lam, ℝ)) :
    continuousSource α lam f ∈ cyclicSpace α lam := by
  obtain ⟨g, hg⟩ := f.exists_extension
    (spectrum.isClosed (magneticAlgebraHamiltonian α lam)).isClosedEmbedding_subtypeVal
  have hcfc : cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f =
      cfc g (magneticAlgebraHamiltonian α lam) := by
    rw [cfc_apply g _ (magneticAlgebraHamiltonian_isSelfAdjoint α lam) g.continuous.continuousOn]
    congr 1
    exact hg.symm
  change ((cfcHom (magneticAlgebraHamiltonian_isSelfAdjoint α lam) f :
    magneticAlgebra α) : MagneticBoundedOperator) hilbertRoot ∈ _
  rw [hcfc, magneticAlgebraHamiltonian_cfc_coe α lam g g.continuous]
  exact FermiStationarity.cfc_source_mem_cyclic α lam g g.continuous.continuousOn

/-- Faithfulness of the actual trace proves the continuous-test inclusion injective. -/
theorem continuousTests_injective (α lam : ℝ) :
    Function.Injective (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ :
      C(MagneticRealSpectrum α lam, ℝ) →L[ℝ] SpectralL2 α lam) := by
  intro f g hfg
  let j : C(MagneticRealSpectrum α lam, ℝ) →L[ℝ] SpectralL2 α lam :=
    ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ
  have hj : j (f - g) = 0 :=
    (map_sub j f g).trans (sub_eq_zero.mpr hfg)
  have hn : ‖continuousSource α lam (f - g)‖ = 0 :=
    (continuousSource_norm_L2 α lam (f - g)).trans
      ((congrArg (fun x : SpectralL2 α lam => ‖x‖) hj).trans norm_zero)
  have hs : continuousSource α lam f = continuousSource α lam g := by
    apply sub_eq_zero.mp
    exact (map_sub (continuousSource α lam) f g).symm.trans (norm_eq_zero.mp hn)
  apply (cfcHom_isClosedEmbedding (magneticAlgebraHamiltonian_isSelfAdjoint α lam)).injective
  apply TraceVectorization.vectorize_injective α
  exact hs

/-- The continuous tests inside the actual spectral L² space. -/
def TestRange (α lam : ℝ) : Submodule ℝ (SpectralL2 α lam) :=
  LinearMap.range (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ).toLinearMap

def continuousTestEquiv (α lam : ℝ) : C(MagneticRealSpectrum α lam, ℝ) ≃ₗ[ℝ] TestRange α lam :=
  LinearEquiv.ofInjective (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ).toLinearMap
    (continuousTests_injective α lam)

def testSource (α lam : ℝ) : TestRange α lam →ₗ[ℝ] MagneticHilbert :=
  (continuousSource α lam).comp (continuousTestEquiv α lam).symm.toLinearMap

@[simp] theorem testSource_equiv (α lam : ℝ) (f : C(MagneticRealSpectrum α lam, ℝ)) :
    testSource α lam (continuousTestEquiv α lam f) = continuousSource α lam f := by
  change continuousSource α lam ((continuousTestEquiv α lam).symm (continuousTestEquiv α lam f)) = _
  rw [LinearEquiv.symm_apply_apply]

/-- An actual isometry on the dense test range, not a postulated source map. -/
def testSourceIsometry (α lam : ℝ) : TestRange α lam →ₗᵢ[ℝ] MagneticHilbert where
  toLinearMap := testSource α lam
  norm_map' u := by
    let f := (continuousTestEquiv α lam).symm u
    have hu : continuousTestEquiv α lam f = u :=
      (continuousTestEquiv α lam).apply_symm_apply u
    have hv : ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ f = (u : SpectralL2 α lam) :=
      congrArg (fun x : TestRange α lam => (x : SpectralL2 α lam)) hu
    change ‖continuousSource α lam f‖ = ‖u‖
    exact (continuousSource_norm_L2 α lam f).trans
      (congrArg (fun x : SpectralL2 α lam => ‖x‖) hv)

theorem testRange_dense (α lam : ℝ) : DenseRange (TestRange α lam).subtypeL := by
  apply (continuousTests_dense α lam).mono
  rintro _ ⟨f, rfl⟩
  exact ⟨continuousTestEquiv α lam f, rfl⟩

/-- The actual continuous CFC source extends uniquely to the spectral L² space. -/
def spectralSource (α lam : ℝ) : SpectralL2 α lam →L[ℝ] MagneticHilbert :=
  (testSourceIsometry α lam).toContinuousLinearMap.extend (TestRange α lam).subtypeL
    (testRange_dense α lam) (TestRange α lam).subtypeₗᵢ.isometry.isUniformInducing

@[simp] theorem spectralSource_test (α lam : ℝ) (u : TestRange α lam) :
    spectralSource α lam u = testSource α lam u :=
  ContinuousLinearMap.extend_eq _ _ _ _ u

/-- Agreement with continuous functional calculus fixes the extension uniquely. -/
@[simp] theorem spectralSource_continuous (α lam : ℝ)
    (f : C(MagneticRealSpectrum α lam, ℝ)) :
    spectralSource α lam (ContinuousMap.toLp 2 (magneticSpectralMeasure α lam) ℝ f) =
      continuousSource α lam f := by
  change spectralSource α lam ((continuousTestEquiv α lam f : TestRange α lam) : SpectralL2 α lam) = _
  rw [spectralSource_test, testSource_equiv]

/-- Every spectral L² source, including discontinuous threshold indicators,
lies in the existing closed cyclic space. -/
theorem spectralSource_mem_cyclic (α lam : ℝ) (u : SpectralL2 α lam) :
    spectralSource α lam u ∈ cyclicSpace α lam := by
  refine (continuousTests_dense α lam).induction_on u ?_ ?_
  · exact (cyclicSpace_isClosed α lam).preimage (spectralSource α lam).continuous
  · intro f
    rw [spectralSource_continuous]
    exact continuousSource_mem_cyclic α lam f

theorem lowerSpectrum_measurable (α lam E : ℝ) :
    MeasurableSet (magneticLowerSpectrum α lam E) :=
  (isOpen_lt continuous_subtype_val continuous_const).measurableSet

/-- The lower threshold indicator in the actual spectral L² space, for every real cut. -/
def thresholdL2 (α lam E : ℝ) : SpectralL2 α lam :=
  indicatorConstLp 2 (lowerSpectrum_measurable α lam E)
    (measure_ne_top (magneticSpectralMeasure α lam) _) (1 : ℝ)

/-- Source of the measurable lower threshold, with no resolvent-set condition. -/
def thresholdSource (α lam E : ℝ) : MagneticHilbert :=
  spectralSource α lam (thresholdL2 α lam E)

theorem thresholdSource_mem_cyclic (α lam E : ℝ) :
    thresholdSource α lam E ∈ cyclicSpace α lam :=
  spectralSource_mem_cyclic α lam _

end DTMAudit.SpectralSources

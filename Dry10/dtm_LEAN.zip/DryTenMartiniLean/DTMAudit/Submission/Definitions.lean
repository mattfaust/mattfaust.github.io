import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Algebra.Algebra.Spectrum.Basic
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Irrational

/- Every theorem-specific definition is printed here, in dependency order.
   Only Mathlib is imported. The phase is measured in radians.
   `lam` denotes the coupling lambda; lambda itself is Lean syntax. -/

noncomputable section
namespace DryTenMartini

-- 1. Frequency and the Hilbert space of square-summable sequences.

def IrrationalFrequency (α : ℝ) : Prop :=
  ∀ p : ℤ, ∀ q : ℕ, q ≠ 0 → (p : ℝ) / (q : ℝ) ≠ α

abbrev SequenceSpace := lp (fun _ : ℤ => ℂ) 2

-- 2. The almost Mathieu operator and its bounded inverse.
-- `→L[ℂ]` means a bounded complex-linear operator.

def AMOFamily (α : ℝ)
    (h : ℝ → ℝ → (SequenceSpace →L[ℂ] SequenceSpace)) : Prop :=
  ∀ (lam φ : ℝ) (ψ : SequenceSpace) (j : ℤ),
    h lam φ ψ j =
      ψ (j + 1) + ψ (j - 1) +
      ((2 * lam * Real.cos
        (2 * Real.pi * α * (j : ℝ) + φ) : ℝ) : ℂ) * ψ j

-- Multiplication of operators is composition; `1` is the identity.
-- Its negation means that E belongs to the operator spectrum.
def InvertibleAt (h : SequenceSpace →L[ℂ] SequenceSpace)
    (E : ℝ) : Prop :=
  ∃ inverse : SequenceSpace →L[ℂ] SequenceSpace,
    ((E : ℂ) • 1 - h) * inverse = 1 ∧
    inverse * ((E : ℂ) • 1 - h) = 1

-- 3. Dirichlet eigenvalue counts on the sites 0,...,L.

def DirichletMatrix (α lam φ : ℝ) (L : ℕ) :
    Matrix (Fin (L + 1)) (Fin (L + 1)) ℂ :=
  fun i j =>
    (if (i.val : ℤ) + 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
    (if (i.val : ℤ) - 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
    (if i = j then
      ((2 * lam * Real.cos
        (2 * Real.pi * α * (i.val : ℝ) + φ) : ℝ) : ℂ)
     else 0)

-- The matrix is Hermitian, so its eigenvalues are real.
-- The roots form a multiset: countP includes algebraic multiplicities.
def NormalizedCount (α lam φ E : ℝ) (L : ℕ) : ℝ :=
  ((((Matrix.charpoly (DirichletMatrix α lam φ L)).roots.countP
      (fun z : ℂ => z.re < E) : ℕ) : ℝ) / ((L + 1 : ℕ) : ℝ))

-- 4. The gap label, written as an epsilon-cutoff limit.
-- The cutoff can depend on the phase and energy: no uniformity is assumed.

def HasGapLabel (α lam φ : ℝ) (n : ℤ) (E : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε →
    ∃ L0 : ℕ, ∀ L : ℕ, L0 ≤ L →
      |NormalizedCount α lam φ E L -
        ((n : ℝ) * α - (Int.floor ((n : ℝ) * α) : ℝ))| < ε

-- 5. A common open spectral gap with this label at every phase.
-- Its endpoints are in the spectrum, and every interior energy is out.

def CommonLabelledGap (α : ℝ)
    (h : ℝ → ℝ → (SequenceSpace →L[ℂ] SequenceSpace))
    (lam : ℝ) (n : ℤ) (a b : ℝ) : Prop :=
  a < b ∧ ∀ φ : ℝ,
    ¬ InvertibleAt (h lam φ) a ∧
    ¬ InvertibleAt (h lam φ) b ∧
    ∀ E : ℝ, a < E → E < b →
      InvertibleAt (h lam φ) E ∧ HasGapLabel α lam φ n E

end DryTenMartini

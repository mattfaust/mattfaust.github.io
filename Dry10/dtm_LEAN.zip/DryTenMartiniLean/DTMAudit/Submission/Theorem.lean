import DTMAudit.Submission.Definitions
import DTMAudit.CurrentDraft

namespace DryTenMartini

-- 6. Every allowed nonzero label is an open gap, at every nonzero coupling.
-- The same endpoints work for all phases: they are chosen in the definition
-- before the universal phase quantifier.

theorem dry_ten_martini :
    ∀ α : ℝ, IrrationalFrequency α →
      ∃ h : ℝ → ℝ → (SequenceSpace →L[ℂ] SequenceSpace),
        AMOFamily α h ∧
        ∀ lam : ℝ, lam ≠ 0 → ∀ n : ℤ, n ≠ 0 →
          ∃ a b : ℝ, CommonLabelledGap α h lam n a b := by
  have hirr (α : ℝ) : Irrational α ↔
      ∀ p : ℤ, ∀ q : ℕ, q ≠ 0 → (p : ℝ) / (q : ℝ) ≠ α := by
    constructor
    · intro h p q _ heq
      apply ((irrational_iff_ne_rational α).mp h p (q : ℤ))
      simpa only [Int.cast_natCast] using heq.symm
    · intro h
      rw [Irrational, Set.mem_range]
      rintro ⟨q, hq⟩
      exact h q.num q.den q.den_nz
        (by simpa only [Rat.cast_def] using hq)
  simpa only [IrrationalFrequency, AMOFamily, CommonLabelledGap,
    InvertibleAt, HasGapLabel, NormalizedCount, DirichletMatrix,
    hirr, not_exists, spectrum.not_mem_iff, spectrum.mem_iff,
    isUnit_iff_exists, Algebra.algebraMap_eq_smul_one,
    Metric.tendsto_atTop, Real.dist_eq, Int.fract,
    not_forall, not_not] using CurrentDraft.dry_ten_martini

end DryTenMartini

import DTMAudit.Submission.Definitions

namespace DryTenMartini

-- Unfolding every displayed definition gives exactly the literal statement.
-- Iff.rfl certifies definitional equality in both directions.
theorem exact_unfolding :
(    ∀ α : ℝ, IrrationalFrequency α →
      ∃ h : ℝ → ℝ → (SequenceSpace →L[ℂ] SequenceSpace),
        AMOFamily α h ∧
        ∀ lam : ℝ, lam ≠ 0 → ∀ n : ℤ, n ≠ 0 →
          ∃ a b : ℝ, CommonLabelledGap α h lam n a b) ↔
(-- Every irrational real frequency.
  ∀ α : ℝ,
    (∀ p : ℤ, ∀ q : ℕ, q ≠ 0 → (p : ℝ) / (q : ℝ) ≠ α) →

  -- Construct the actual almost Mathieu operators, for all real
  -- couplings and phases. The phase is measured in radians.
  ∃ h : ℝ → ℝ →
      (lp (fun _ : ℤ => ℂ) 2 →L[ℂ] lp (fun _ : ℤ => ℂ) 2),
    (∀ (lam φ : ℝ) (ψ : lp (fun _ : ℤ => ℂ) 2) (j : ℤ),
      h lam φ ψ j =
        ψ (j + 1) + ψ (j - 1) +
        ((2 * lam * Real.cos
          (2 * Real.pi * α * (j : ℝ) + φ) : ℝ) : ℂ) * ψ j) ∧

    -- Every nonzero real coupling and every nonzero integer label.
    ∀ lam : ℝ, lam ≠ 0 →
    ∀ n : ℤ, n ≠ 0 →

      -- A bounded open interval of positive width, with the SAME
      -- endpoints for EVERY phase.
      ∃ a b : ℝ, a < b ∧
      ∀ φ : ℝ,

        -- The left endpoint belongs to the operator spectrum:
        -- a I - h has no bounded two-sided inverse.
        (¬ ∃ inverse :
            lp (fun _ : ℤ => ℂ) 2 →L[ℂ] lp (fun _ : ℤ => ℂ) 2,
          ((a : ℂ) • 1 - h lam φ) * inverse = 1 ∧
          inverse * ((a : ℂ) • 1 - h lam φ) = 1) ∧

        -- The right endpoint also belongs to the spectrum.
        (¬ ∃ inverse :
            lp (fun _ : ℤ => ℂ) 2 →L[ℂ] lp (fun _ : ℤ => ℂ) 2,
          ((b : ℂ) • 1 - h lam φ) * inverse = 1 ∧
          inverse * ((b : ℂ) • 1 - h lam φ) = 1) ∧

        -- EVERY interior energy is outside the operator spectrum.
        ∀ E : ℝ, a < E → E < b →
          (∃ inverse :
              lp (fun _ : ℤ => ℂ) 2 →L[ℂ] lp (fun _ : ℤ => ℂ) 2,
            ((E : ℂ) • 1 - h lam φ) * inverse = 1 ∧
            inverse * ((E : ℂ) • 1 - h lam φ) = 1) ∧

          -- The normalized Dirichlet eigenvalue count converges
          -- to n * α minus its floor. The cutoff may depend on
          -- α, lam, n, φ, E, and ε; convergence is not asserted uniform.
          ∀ ε : ℝ, 0 < ε →
            ∃ L0 : ℕ, ∀ L : ℕ, L0 ≤ L →
              |((
                  (Matrix.charpoly
                    (fun i j : Fin (L + 1) =>
                      -- Dirichlet matrix on sites 0,...,L.
                      (if (i.val : ℤ) + 1 = (j.val : ℤ)
                       then (1 : ℂ) else 0) +
                      (if (i.val : ℤ) - 1 = (j.val : ℤ)
                       then (1 : ℂ) else 0) +
                      (if i = j then
                        ((2 * lam * Real.cos
                          (2 * Real.pi * α * (i.val : ℝ) + φ)
                            : ℝ) : ℂ)
                       else 0))).roots.countP
                    -- This Hermitian matrix has real eigenvalues.
                    -- The multiset counts algebraic multiplicities.
                    (fun z : ℂ => z.re < E) : ℕ) : ℝ)
                  / ((L + 1 : ℕ) : ℝ)
                - ((n : ℝ) * α - (Int.floor ((n : ℝ) * α) : ℝ))| < ε) := Iff.rfl

end DryTenMartini

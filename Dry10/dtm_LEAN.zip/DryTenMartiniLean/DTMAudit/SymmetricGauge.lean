import DTM.NewResults.Brown.ChiralGauge
import DTM.NewResults.Chiral.Current

/-!
# Symmetric phase-Fourier lattice gauge

The diagonal unitary has value exp(i*pi*alpha*n*m). It converts the
Landau rows into the symmetric magnetic lattice rows.
This is an actual unitary on the infinite lattice. This file does not claim
to construct the trace completion or its full L2 phase-Fourier unitary.
-/

noncomputable section
namespace DTMAudit.SymmetricGauge
open CriticalDTM DTMCompanion.ChiralGauge

def phase (α : ℝ) (s : Site) : ℂ := character α ((s.1 : ℝ) * (s.2 : ℝ))

def gauge (α : ℝ) (u : Site → ℂ) (s : Site) : ℂ := phase α s * u s

def operator (α : ℝ) : MagneticHilbert →L[ℂ] MagneticHilbert :=
  twistedOperator (Equiv.refl Site) (phase α) (fun _ => character_norm _ _)

def inverseOperator (α : ℝ) : MagneticHilbert →L[ℂ] MagneticHilbert :=
  twistedOperator (Equiv.refl Site)
    (fun s => character α (-((s.1 : ℝ) * (s.2 : ℝ))))
    (fun _ => character_norm _ _)

@[simp] theorem operator_apply (α : ℝ) (u : MagneticHilbert) (s : Site) :
    operator α u s = gauge α u s := rfl

@[simp] theorem inverseOperator_apply (α : ℝ) (u : MagneticHilbert) (s : Site) :
    inverseOperator α u s = character α (-((s.1 : ℝ) * (s.2 : ℝ))) * u s := rfl

theorem inverse_operator (α : ℝ) (u : MagneticHilbert) :
    inverseOperator α (operator α u) = u := by
  apply lp.ext
  funext s
  simp only [inverseOperator_apply, operator_apply, gauge, phase,
    ← mul_assoc, ← character_add, neg_add_cancel]
  simp [character]

theorem operator_inverse (α : ℝ) (u : MagneticHilbert) :
    operator α (inverseOperator α u) = u := by
  apply lp.ext
  funext s
  simp only [operator_apply, inverseOperator_apply, gauge, phase,
    ← mul_assoc, ← character_add, add_neg_cancel]
  simp [character]

def unitary (α : ℝ) : MagneticHilbert ≃ₗᵢ[ℂ] MagneticHilbert where
  toFun := operator α
  invFun := inverseOperator α
  left_inv := inverse_operator α
  right_inv := operator_inverse α
  map_add' := (operator α).map_add
  map_smul' := (operator α).map_smul
  norm_map' := twistedVector_norm (Equiv.refl Site) (phase α)
    (fun _ => character_norm _ _)

@[simp] theorem unitary_apply (α : ℝ) (u : MagneticHilbert) (s : Site) :
    unitary α u s = phase α s * u s := rfl

theorem unitary_root (α : ℝ) : unitary α hilbertRoot = hilbertRoot := by
  apply lp.ext
  funext s
  rw [unitary_apply]
  by_cases hs : s = origin
  · subst s
    simp [phase, origin, character]
  · have hr : hilbertRoot s = 0 := by
      simp [hilbertRoot_apply, latticeRoot, Pi.single_apply, hs]
    rw [hr, mul_zero]

def leftRow (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) : ℂ :=
  character α (-(s.2 : ℝ)) * u (east s) +
  character α (s.2 : ℝ) * u (west s) +
  lam * character α (s.1 : ℝ) * u (north s) +
  lam * character α (-(s.1 : ℝ)) * u (south s)

def rightRow (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) : ℂ :=
  character α (s.2 : ℝ) * u (east s) +
  character α (-(s.2 : ℝ)) * u (west s) +
  lam * character α (-(s.1 : ℝ)) * u (north s) +
  lam * character α (s.1 : ℝ) * u (south s)

theorem receiving_phases (α : ℝ) (n m : ℤ) :
    phase α (n,m) = character α (-(m : ℝ)) * phase α (n+1,m) ∧
    phase α (n,m) = character α (m : ℝ) * phase α (n-1,m) ∧
    phase α (n,m) * magneticPhase α n =
      character α (n : ℝ) * phase α (n,m+1) ∧
    phase α (n,m) * magneticPhase α (-n) =
      character α (-(n : ℝ)) * phase α (n,m-1) := by
  simp only [phase, magneticPhase_eq_character, ← character_add]
  refine ⟨?_, ?_, ?_, ?_⟩ <;> congr 1 <;> push_cast <;> ring

theorem right_receiving_phases (α : ℝ) (n m : ℤ) :
    phase α (n,m) * magneticPhase α m =
      character α (m : ℝ) * phase α (n+1,m) ∧
    phase α (n,m) * magneticPhase α (-m) =
      character α (-(m : ℝ)) * phase α (n-1,m) ∧
    phase α (n,m) = character α (-(n : ℝ)) * phase α (n,m+1) ∧
    phase α (n,m) = character α (n : ℝ) * phase α (n,m-1) := by
  simp only [phase, magneticPhase_eq_character, ← character_add]
  refine ⟨?_, ?_, ?_, ?_⟩ <;> congr 1 <;> push_cast <;> ring

theorem left_row_intertwining (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) :
    gauge α (hRow α lam u) s = leftRow α lam (gauge α u) s := by
  rcases s with ⟨n,m⟩
  obtain ⟨hE,hW,hN,hS⟩ := receiving_phases α n m
  simp only [gauge, leftRow, hRow, east, west, north, south]
  linear_combination hE * u (n+1,m) + hW * u (n-1,m) +
    lam * hN * u (n,m+1) + lam * hS * u (n,m-1)

theorem right_row_intertwining (α : ℝ) (lam : ℂ) (u : Site → ℂ) (s : Site) :
    gauge α (conjugateRow α lam u) s = rightRow α lam (gauge α u) s := by
  rcases s with ⟨n,m⟩
  obtain ⟨hE,hW,hN,hS⟩ := right_receiving_phases α n m
  simp only [gauge, rightRow, conjugateRow, east, west, north, south]
  linear_combination hE * u (n+1,m) + hW * u (n-1,m) +
    lam * hN * u (n,m+1) + lam * hS * u (n,m-1)

theorem unitary_hOperator (α : ℝ) (lam : ℂ) (u : MagneticHilbert) (s : Site) :
    unitary α (hOperator α lam u) s = leftRow α lam (unitary α u) s := by
  simpa only [unitary_apply, hOperator_apply, leftRow, gauge] using
    left_row_intertwining α lam u s

theorem unitary_conjugateOperator (α : ℝ) (lam : ℂ)
    (u : MagneticHilbert) (s : Site) :
    unitary α (conjugateOperator α lam u) s = rightRow α lam (unitary α u) s := by
  simpa only [unitary_apply, conjugateOperator_apply, rightRow, gauge] using
    right_row_intertwining α lam u s

theorem character_trig (α x : ℝ) :
    character α x = (Real.cos (Real.pi*α*x) : ℂ) +
      (Real.sin (Real.pi*α*x) : ℂ) * Complex.I := by
  rw [character, Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]

/-- Symmetric-gauge mean row, with the physical coupling retained. -/
theorem mean_row (α : ℝ) (lam : ℂ) (u : Site → ℂ) (n m : ℤ) :
    (leftRow α lam u (n,m) + rightRow α lam u (n,m)) / 2 =
      (Real.cos (Real.pi*α*(m : ℝ)) : ℂ) * (u (n-1,m) + u (n+1,m)) +
      lam * (Real.cos (Real.pi*α*(n : ℝ)) : ℂ) * (u (n,m-1) + u (n,m+1)) := by
  simp only [leftRow, rightRow, east, west, north, south, character_trig,
    mul_neg, Real.cos_neg, Real.sin_neg, Complex.ofReal_neg]
  ring

/-- Symmetric-gauge difference row, with its orientation and imaginary sign. -/
theorem difference_row (α : ℝ) (lam : ℂ) (u : Site → ℂ) (n m : ℤ) :
    (leftRow α lam u (n,m) - rightRow α lam u (n,m)) / 2 =
      Complex.I * (Real.sin (Real.pi*α*(m : ℝ)) : ℂ) *
        (u (n-1,m) - u (n+1,m)) -
      Complex.I * lam * (Real.sin (Real.pi*α*(n : ℝ)) : ℂ) *
        (u (n,m-1) - u (n,m+1)) := by
  simp only [leftRow, rightRow, east, west, north, south, character_trig,
    mul_neg, Real.cos_neg, Real.sin_neg, Complex.ofReal_neg]
  ring

/-- The manuscript's mean row is the actual transported bounded H+ operator. -/
theorem unitary_average_row (α lam : ℝ) (u : MagneticHilbert) (n m : ℤ) :
    unitary α (Chiral.averageOperator α lam u) (n,m) =
      (Real.cos (Real.pi*α*(m : ℝ)) : ℂ) *
        (unitary α u (n-1,m) + unitary α u (n+1,m)) +
      (lam : ℂ) * (Real.cos (Real.pi*α*(n : ℝ)) : ℂ) *
        (unitary α u (n,m-1) + unitary α u (n,m+1)) := by
  calc
    _ = (unitary α (hOperator α (lam : ℂ) u) (n,m) +
        unitary α (conjugateOperator α (lam : ℂ) u) (n,m)) / 2 := by
      simp only [Chiral.averageOperator, ContinuousLinearMap.smul_apply,
        ContinuousLinearMap.add_apply, map_smul, map_add, lp.coeFn_smul,
        lp.coeFn_add, Pi.add_apply, Pi.smul_apply, smul_eq_mul]
      ring
    _ = _ := by
      rw [unitary_hOperator, unitary_conjugateOperator]
      exact mean_row α (lam : ℂ) (unitary α u) n m

/-- The manuscript's difference row is the actual transported bounded H- action. -/
theorem unitary_difference_row (α lam : ℝ) (u : MagneticHilbert) (n m : ℤ) :
    unitary α ((1 / 2 : ℂ) •
      (hOperator α (lam : ℂ) u - conjugateOperator α (lam : ℂ) u)) (n,m) =
      Complex.I * (Real.sin (Real.pi*α*(m : ℝ)) : ℂ) *
        (unitary α u (n-1,m) - unitary α u (n+1,m)) -
      Complex.I * (lam : ℂ) * (Real.sin (Real.pi*α*(n : ℝ)) : ℂ) *
        (unitary α u (n,m-1) - unitary α u (n,m+1)) := by
  calc
    _ = (unitary α (hOperator α (lam : ℂ) u) (n,m) -
        unitary α (conjugateOperator α (lam : ℂ) u) (n,m)) / 2 := by
      simp only [map_smul, map_sub, lp.coeFn_smul, lp.coeFn_sub,
        Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
      ring
    _ = _ := by
      rw [unitary_hOperator, unitary_conjugateOperator]
      exact difference_row α (lam : ℂ) (unitary α u) n m

/-- The diagonal gauge preserves the angular multiplier, hence also Lz=-2L. -/
theorem unitary_angular (α : ℝ) (u : MagneticHilbert) :
    Chiral.angular (unitary α u) = unitary α (Chiral.angular u) := by
  apply lp.ext
  funext s
  rw [Chiral.angular_apply_site, unitary_apply, unitary_apply,
    Chiral.angular_apply_site]
  ring

end DTMAudit.SymmetricGauge

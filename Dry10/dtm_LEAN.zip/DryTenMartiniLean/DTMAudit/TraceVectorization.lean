import DTM.Background.Realization.MagneticTraceFaithful
import DTMAudit.SymmetricGauge
import Mathlib.Analysis.NormedSpace.OperatorNorm.Completeness
import Mathlib.Analysis.InnerProductSpace.Completion

/-!
# Trace vectorization on the actual magnetic algebra

Evaluation at the cyclic root identifies the canonical trace inner product
with the lattice inner product. Left multiplication by H becomes H, and
right multiplication becomes the commuting conjugate magnetic operator.
-/

noncomputable section
namespace DTMAudit.TraceVectorization
open CriticalDTM

/-- The source-side vectorization map is evaluation at the actual root. -/
def vectorize : MagneticBoundedOperator →L[ℂ] MagneticHilbert :=
  LinearMap.mkContinuous
    { toFun := fun A : MagneticBoundedOperator => A hilbertRoot
      map_add' := by intros; rfl
      map_smul' := by intros; rfl }
    1 (fun (A : MagneticBoundedOperator) => by simpa only [hilbertRoot_norm, mul_one, one_mul] using
      (A.le_opNorm hilbertRoot))

/-- Every magnetic monomial commutes with the right lattice action. -/
theorem monomial_conjugate_commute (α : ℝ) (lam : ℂ) (a : Site) :
    magneticMonomial α a * conjugateOperator α lam =
      conjugateOperator α lam * magneticMonomial α a := by
  apply ContinuousLinearMap.ext
  intro u
  apply lp.ext
  funext s
  simp only [ContinuousLinearMap.mul_apply, magneticMonomial_apply,
    conjugateOperator_apply, conjugateRow, east, west, north, south]
  simp only [mul_add, add_mul, magneticPhase_add, sub_eq_add_neg, neg_add_rev,
    add_assoc, mul_neg, neg_mul, magneticPhase_zero]
  ring

theorem polynomial_conjugate_commute (α : ℝ) (lam : ℂ)
    {A : MagneticBoundedOperator} (hA : A ∈ magneticPolynomialSpace α) :
    A * conjugateOperator α lam = conjugateOperator α lam * A := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    exact monomial_conjugate_commute α lam a
  | zero => simp
  | add A B hA hB ihA ihB => simp only [add_mul, mul_add, ihA, ihB]
  | smul c A hA ihA => simp only [smul_mul_assoc, mul_smul_comm, ihA]

/-- Continuity extends the right-action commutation to the norm closure. -/
theorem closure_conjugate_commute (α : ℝ) (lam : ℂ)
    {A : MagneticBoundedOperator} (hA : A ∈ magneticPolynomialClosure α) :
    A * conjugateOperator α lam = conjugateOperator α lam * A :=
  closure_minimal (fun _ h => polynomial_conjugate_commute α lam h)
    (isClosed_eq (continuous_id.mul continuous_const)
      (continuous_const.mul continuous_id)) hA

/-- Faithfulness makes vectorization injective on the closed magnetic algebra. -/
theorem vectorize_injective (α : ℝ) :
    Function.Injective (fun A : magneticAlgebra α => vectorize (A : MagneticBoundedOperator)) := by
  intro A B h
  change vectorize (A : MagneticBoundedOperator) = vectorize (B : MagneticBoundedOperator) at h
  have hz : vectorize ((A - B : magneticAlgebra α) : MagneticBoundedOperator) = 0 := by
    change vectorize ((A : MagneticBoundedOperator) - (B : MagneticBoundedOperator)) = 0
    rw [map_sub, h, sub_self]
  have hab : A - B = 0 := magneticTraceReal_faithful α (A - B) (by
    rw [magneticTraceReal_star_mul_self]
    change ‖vectorize ((A - B : magneticAlgebra α) : MagneticBoundedOperator)‖ ^ 2 = 0
    rw [hz, norm_zero, zero_pow (by decide)])
  exact sub_eq_zero.mp hab

/-- Polynomial vectorization as a linear map. -/
def polynomialVectorize (α : ℝ) : magneticPolynomialSpace α →ₗ[ℂ] MagneticHilbert :=
  vectorize.toLinearMap.comp (magneticPolynomialSpace α).subtype

/-- Every coordinate vector has an explicit magnetic polynomial preimage. -/
theorem single_mem_vectorize_range (α : ℝ) (s : Site) :
    lp.single 2 s (1 : ℂ) ∈ LinearMap.range (polynomialVectorize α) := by
  let c := magneticPhase α (s.2 * s.1)
  refine ⟨⟨c • magneticMonomial α (-s),
    (magneticPolynomialSpace α).smul_mem c
      (magneticMonomial_mem_polynomialSpace α (-s))⟩, ?_⟩
  change c • (magneticMonomial α (-s) hilbertRoot) = _
  rw [magneticMonomial_root]
  simp only [Prod.snd_neg, Prod.fst_neg, neg_neg, neg_mul, smul_smul]
  rw [show c = magneticPhase α (s.2 * s.1) from rfl,
    magneticPhase_mul_neg, one_smul]

/-- The polynomial trace vectors are dense in the full infinite lattice. -/
theorem polynomialVectorize_dense (α : ℝ) : DenseRange (polynomialVectorize α) := by
  let b : HilbertBasis Site ℂ MagneticHilbert := ⟨LinearIsometryEquiv.refl ℂ MagneticHilbert⟩
  have hspan : Submodule.span ℂ (Set.range b) ≤ LinearMap.range (polynomialVectorize α) := by
    apply Submodule.span_le.mpr
    rintro _ ⟨s, rfl⟩
    rw [← b.repr_symm_single]
    exact single_mem_vectorize_range α s
  have hclosure := Submodule.topologicalClosure_mono hspan
  rw [b.dense_span] at hclosure
  have htop : (LinearMap.range (polynomialVectorize α)).topologicalClosure = ⊤ :=
    top_unique hclosure
  apply dense_iff_closure_eq.mpr
  exact congrArg (fun S : Submodule ℂ MagneticHilbert => (S : Set MagneticHilbert)) htop

/-- The actual closed magnetic algebra, equipped below with its trace norm.
This type synonym keeps that norm distinct from the operator norm. -/
def TraceAlgebra (α : ℝ) : Type := magneticAlgebra α

instance (α : ℝ) : AddCommGroup (TraceAlgebra α) :=
  inferInstanceAs (AddCommGroup (magneticAlgebra α))

instance (α : ℝ) : Module ℂ (TraceAlgebra α) :=
  inferInstanceAs (Module ℂ (magneticAlgebra α))

/-- The underlying bounded operator of a trace vector. -/
def sourceOperator {α : ℝ} (A : TraceAlgebra α) : MagneticBoundedOperator :=
  (show magneticAlgebra α from A)

/-- Evaluation before completion, with the actual algebra as its domain. -/
def traceVectorizeLinear (α : ℝ) : TraceAlgebra α →ₗ[ℂ] MagneticHilbert where
  toFun := fun A => vectorize (sourceOperator A)
  map_add' := by intros; exact map_add vectorize _ _
  map_smul' := by intros; exact map_smul vectorize _ _

theorem traceVectorizeLinear_injective (α : ℝ) :
    Function.Injective (traceVectorizeLinear α) := vectorize_injective α

instance traceNormedAddCommGroup (α : ℝ) : NormedAddCommGroup (TraceAlgebra α) :=
  NormedAddCommGroup.induced _ _ (traceVectorizeLinear α)
    (traceVectorizeLinear_injective α)

instance traceNormedSpace (α : ℝ) : NormedSpace ℂ (TraceAlgebra α) :=
  NormedSpace.induced ℂ _ _ (traceVectorizeLinear α)

/-- The norm identity makes source vectorization an isometric linear embedding. -/
def traceVectorize (α : ℝ) : TraceAlgebra α →ₗᵢ[ℂ] MagneticHilbert where
  toLinearMap := traceVectorizeLinear α
  norm_map' _ := rfl

theorem traceVectorize_dense (α : ℝ) : DenseRange (traceVectorize α) := by
  apply (polynomialVectorize_dense α).mono
  rintro _ ⟨A, rfl⟩
  exact ⟨(⟨A.val, polynomialSpace_subset_magneticAlgebra α A.property⟩ : magneticAlgebra α), rfl⟩

end DTMAudit.TraceVectorization

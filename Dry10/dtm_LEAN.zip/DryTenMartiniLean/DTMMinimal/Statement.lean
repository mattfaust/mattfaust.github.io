import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Algebra.Algebra.Spectrum.Basic
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Irrational

/-!
# Independent positive and all-nonzero Dry Ten Martini specifications

This file imports only Mathlib and defines a proposition, not a proof.
The bounded physical operator family is constructed in the conclusion. Its
literal row has unit hopping and onsite term `2 * lam * cos (2 * pi * α * j + θ)`.
The phase is in radians. The Dirichlet matrix is the restriction to sites
`0,...,L`; its characteristic-polynomial roots are counted with multiplicity.
The same gap endpoints work for every phase. Every interior energy of each
positive-width spectral gap has the prescribed empirical limit. No operator-model, seed, height, spectral-vanishing, duality,
noncritical-opening, or convergence premise is supplied.
-/

namespace DTMMinimal

open Filter
open scoped Topology

/-- Full all-positive conclusion in literal Mathlib mathematics. -/
def statement : Prop :=
  ∀ α : ℝ, Irrational α →
  ∃ H : ℝ → ℝ → (ℓ²(ℤ, ℂ) →L[ℂ] ℓ²(ℤ, ℂ)),
    (∀ (lam θ : ℝ) (ψ : ℓ²(ℤ, ℂ)) (j : ℤ),
      H lam θ ψ j = ψ (j + 1) + ψ (j - 1) +
        ((2 * lam * Real.cos (2 * Real.pi * α * (j : ℝ) + θ) : ℝ) : ℂ) * ψ j) ∧
    let finiteH : ℝ → ℝ → (L : ℕ) → Matrix (Fin (L + 1)) (Fin (L + 1)) ℂ :=
      fun lam θ L (i j : Fin (L + 1)) => H lam θ (lp.single 2 (j.val : ℤ) (1 : ℂ)) (i.val : ℤ)
    let counts := fun (lam θ E : ℝ) (L : ℕ) =>
      (((finiteH lam θ L).charpoly.roots.countP (fun z : ℂ => z.re < E) : ℕ) : ℝ) /
        ((L + 1 : ℕ) : ℝ)
    ∀ lam : ℝ, 0 < lam → ∀ n : ℤ, n ≠ 0 →
      ∃ a b : ℝ, a < b ∧ ∀ θ : ℝ,
        (a : ℂ) ∈ spectrum ℂ (H lam θ) ∧
        (b : ℂ) ∈ spectrum ℂ (H lam θ) ∧
        ∀ E : ℝ, a < E → E < b →
          (E : ℂ) ∉ spectrum ℂ (H lam θ) ∧
          Tendsto (counts lam θ E) atTop (𝓝 (Int.fract ((n : ℝ) * α)))

/-- Literal all-nonzero specification. This repeats the physical row, finite
Dirichlet counts and every-phase conclusion; no sign-reduction premise is supplied. -/
def statement_nonzero : Prop :=
  ∀ α : ℝ, Irrational α →
  ∃ H : ℝ → ℝ → (ℓ²(ℤ, ℂ) →L[ℂ] ℓ²(ℤ, ℂ)),
    (∀ (lam θ : ℝ) (ψ : ℓ²(ℤ, ℂ)) (j : ℤ),
      H lam θ ψ j = ψ (j + 1) + ψ (j - 1) +
        ((2 * lam * Real.cos (2 * Real.pi * α * (j : ℝ) + θ) : ℝ) : ℂ) * ψ j) ∧
    let finiteH : ℝ → ℝ → (L : ℕ) → Matrix (Fin (L + 1)) (Fin (L + 1)) ℂ :=
      fun lam θ L (i j : Fin (L + 1)) => H lam θ (lp.single 2 (j.val : ℤ) (1 : ℂ)) (i.val : ℤ)
    let counts := fun (lam θ E : ℝ) (L : ℕ) =>
      (((finiteH lam θ L).charpoly.roots.countP (fun z : ℂ => z.re < E) : ℕ) : ℝ) /
        ((L + 1 : ℕ) : ℝ)
    ∀ lam : ℝ, lam ≠ 0 → ∀ n : ℤ, n ≠ 0 →
      ∃ a b : ℝ, a < b ∧ ∀ θ : ℝ,
        (a : ℂ) ∈ spectrum ℂ (H lam θ) ∧
        (b : ℂ) ∈ spectrum ℂ (H lam θ) ∧
        ∀ E : ℝ, a < E → E < b →
          (E : ℂ) ∉ spectrum ℂ (H lam θ) ∧
          Tendsto (counts lam θ E) atTop (𝓝 (Int.fract ((n : ℝ) * α)))

end DTMMinimal

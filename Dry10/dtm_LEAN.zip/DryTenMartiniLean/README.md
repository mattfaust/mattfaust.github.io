# The Dry Ten Martini Problem at Criticality — Lean companion

This package contains the Lean proofs and verification tools corresponding to
the accompanying manuscript. The theorem numbering is fixed by the manuscript
PDF's SHA-256 fingerprint:

```
fd882da347e2b67bd1a6bda63e806cb7776162e0c62937af7c319816abd7ff82
```

## Start here

- [Definitions](DTMAudit/Submission/Definitions.lean): every theorem-specific
  definition in Appendix A.1, including the AMO action, spectrum through bounded
  inverses, finite Dirichlet matrices, eigenvalue counts and limiting gap label.
- [Theorem 1.5](DTMAudit/Submission/Theorem.lean): the short theorem importing
  those definitions and its proof from the complete manuscript argument.
- [Expanded statement](DTMAudit/Submission/ExpandedStatement.lean): the literal
  proposition expressed with standard Lean and Mathlib objects.
- [Definitional correspondence](DTMAudit/Submission/Unfolding.lean): `Iff.rfl`
  checks that the displayed definitions expand to exactly that proposition.

The four modules above present the definitions, theorem and exact expansion
from Appendix A.1. Their statement checks are in
[audit/SubmissionSignatureAudit.lean](audit/SubmissionSignatureAudit.lean).

The source folders contain all supporting project proofs. Mathematical
background, physical operators and definitions are explicit Lean sources;
Mathlib and its dependencies are pinned by `lake-manifest.json`.

## Reproduce the verification

Requires Git, Python 3, and [elan](https://github.com/leanprover/elan).
The checked toolchain is Lean 4.19.0 with Mathlib v4.19.0 (the exact dependency
commits are pinned in the manifest). On macOS or Linux, run from this folder:

```sh
lake exe cache get
python3 tools/verify-source-build.py
python3 tools/verify-companion.py
```

The first command downloads the pinned library cache. The build script starts
with an empty project build directory and compiles every project source.
The verifier independently elaborates the specifications with project proof
artifacts excluded from their search path, checks statement correspondence
and proof dependencies, and replays all safe project logical declarations in
a separate kernel environment with no initially trusted project declarations.
Wrong-type and circular-proof rejection checks are included. Source, artifact,
configuration and verification-tool hashes are recorded.

The result is written to `audit/latest-verification.json`, with the source-build
record in `audit/latest-source-build.json`. The verification uses the standard
Lean axioms `propext`, `Classical.choice` and `Quot.sound`; the verifier rejects
custom project axioms and skipped safe logical declarations.

## Bundled verification result

The included source-build and full-verification records both report **PASS**:

- **223** project modules compiled from an empty project build directory.
- **3,612** safe logical declarations replayed in the kernel.
- **20** public proof and statement-check roots verified.
- **0** skipped safe logical declarations, custom project axioms, or project
  declarations in the initial replay environment.
- Exact agreement of the modular theorem with its fully expanded statement,
  including the `Iff.rfl` unfolding proof.

The only axioms used are `propext`, `Classical.choice` and `Quot.sound`.
The full records and file hashes are included under `audit/`.

## Correspondence with the main text

The numbered declarations carry source comments identifying their manuscript
location. The complete mapping, including supporting declarations, PDF pages
and scope, is in [CORRESPONDENCE.json](CORRESPONDENCE.json).

| Main-text result | Subject | Lean proof declarations |
|---|---|---|
| Theorem 1.5 (LE) | Dry Ten Martini | [`DryTenMartini.dry_ten_martini`](DTMAudit/Submission/Theorem.lean#L10)<br>[`DTMAudit.ManuscriptEndpoint.nonzero_statement`](DTMAudit/ManuscriptEndpoint.lean#L19)<br>[`CurrentDraft.dry_ten_martini`](DTMAudit/CurrentDraft.lean#L32) |
| Lemma 2.2 (L*) | Stationarity | [`DTMAudit.ManuscriptLatticeStationarity.closed_fermi_stationary`](DTMAudit/ManuscriptLatticeStationarity.lean#L46) |
| Lemma 2.4 (L*) | Magnetic balance | [`DTMAudit.ManuscriptLatticeBalance.magnetic_balance`](DTMAudit/ManuscriptLatticeBalance.lean#L112) |
| Theorem 3.2 (LE) | Thouless and Bourgain–Jitomirskaya | [`DTMAudit.RealThouless.lyapunov_eq_log_integral`](DTMAudit/RealThouless.lean#L121)<br>[`DTMAudit.RealThouless.normalization_statement`](DTMAudit/RealThouless.lean#L155) |
| Lemma 3.3 (L*) | Upper semicontinuity | [`DTMAudit.ManuscriptPotential.height_upperSemicontinuous`](DTMAudit/ManuscriptPotential.lean#L32) |
| Lemma 3.4 (L*) | Maximum height condition | [`DTMAudit.ManuscriptCouplingSelected.selected_gap_energy_analytic_branch`](DTMAudit/ManuscriptCouplingSelected.lean#L70) |
| Lemma 3.5 (L*) | Maximum-height derivative | [`DTMAudit.ManuscriptTraceRiesz.selected_height_weighted_insertion`](DTMAudit/ManuscriptTraceRiesz.lean#L99)<br>[`DTMAudit.ManuscriptTraceRiesz.dos_height_coupling_trace_hasDerivAt`](DTMAudit/ManuscriptTraceRiesz.lean#L86) |
| Theorem 3.6 (L*) | Monotonicity | [`DTMAudit.ManuscriptCouplingResponse.height_path_formula`](DTMAudit/ManuscriptCouplingResponse.lean#L13) |
| Theorem 3.7 (LE) | Fixed-label seed gaps | [`CriticalDTM.amo_arbitrarily_small_labelled_seeds`](DTM/Background/IndependentSeeds/AMOCosineSeed.lean#L180) |
| Lemma 3.9 (L*) | Constancy of the gap label | [`DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant`](DTMAudit/ManuscriptRieszContinuity.lean#L462) |
| Theorem 3.10 (L*) | Persistence from seed | [`DTMAudit.ManuscriptEndpoint.persistence`](DTMAudit/ManuscriptEndpoint.lean#L25) |
| Theorem 4.1 (L*) | Monotonicity | [`DTMAudit.ManuscriptCouplingResponse.height_path_formula`](DTMAudit/ManuscriptCouplingResponse.lean#L13) |
| Corollary 4.2 (L*) | Critical height | [`DTMAudit.ManuscriptHeightDuality.selected_critical_height_derivative`](DTMAudit/ManuscriptHeightDuality.lean#L199) |
| Corollary 4.3 (L*) | Conserved dual spin | [`DTMAudit.ManuscriptDualSpin.conserved_dual_spin_path`](DTMAudit/ManuscriptDualSpin.lean#L580) |

Equations (4.1) and (4.2) correspond to
`DTMAudit.ManuscriptTwistedPhase.twistedFiber_apply` and
`DTMAudit.ManuscriptTwistedPhase.landau_coupling_phase_identity`.
Lemma 2.2 and Lemma 3.4 use the supporting declarations listed in the
correspondence file in addition to their public root declarations.

## External inputs replaced by checked proofs

**Theorem 3.2 — Thouless and Bourgain–Jitomirskaya.**
[RealThouless.lean](DTMAudit/RealThouless.lean) identifies the exact citation
sites and supplies the real-energy DOS–Lyapunov identity, logarithmic
integrability, finiteness, nonnegativity, continuity in energy and the spectral
value `max 0 (Real.log lam)`. The external inputs in the manuscript are:

- [34] D. J. Thouless, *A relation between the density of states and range of
  localization for one dimensional random systems*, J. Phys. C 5, 77–81 (1972).
- [6] J. Avron and B. Simon, *Almost periodic Schrödinger operators. II. The
  integrated density of states*, Duke Math. J. 50, 369–391 (1983).
- [11] W. Craig and B. Simon, *Subharmonicity of the Lyaponov index*, Duke Math.
  J. 50, 551–560 (1983), Theorem 4.2 for the real-energy extension.
- [10] J. Bourgain and S. Jitomirskaya, *Continuity of the Lyapunov exponent for
  quasiperiodic operators with analytic potential*, J. Statist. Phys. 108,
  1203–1218 (2002), Theorem 1 for continuity and Corollary 2 for the spectral
  value (with cosine amplitude `2 * lam`).

**Theorem 3.7 — Fixed-label seed gaps.**
[AMOCosineSeed.lean](DTM/Background/IndependentSeeds/AMOCosineSeed.lean), at
`CriticalDTM.amo_arbitrarily_small_labelled_seeds`, identifies the input from
[19] B. Helffer, P. Kerdelhué and J. Sjöstrand, *Le papillon de Hofstadter
revisité*, Mémoires de la Société Mathématique de France, Nouvelle Série 43
(1990), Théorème 2.2 and Proposition 2.5. The proof constructs actual seed gaps
at arbitrarily small positive couplings for each fixed nonzero label, using
finite resonant vectors and the proved spectral and IDS constructions.

These proofs discharge the cited conclusions, rather than assuming them as
axioms. The manuscript's `LE` labels record replacement arguments; they do not
claim that every argument in the cited papers is reproduced. The final theorem
has no seed-gap or monotonicity hypothesis.

The uniform-in-label threshold discussed in Remark 3.8 is not claimed as an
additional verified result. Theorems 1.3 and 1.4 remain the manuscript's `W`
background assertions and are outside this companion's certification claim.

## Package contents

- `DTM/`, `DTMAudit/`, `DTMMinimal/`: explicit proof and definition sources.
- `audit/`: statement, proof-dependency and kernel-replay checks and their results.
- `tools/`: reproducible build and verification drivers.
- `lean-toolchain`, `lakefile.lean`, `lake-manifest.json`: pinned build configuration.
- `CORRESPONDENCE.json`: theorem-number, source and external-input mapping.
- `FILES.sha256`: hashes of the packaged files.

No precompiled project objects are required. Library dependencies are obtained
by Lake and are not vendored in the archive.

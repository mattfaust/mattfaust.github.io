import DTMAudit.Submission.Theorem
import DTMAudit.Submission.Unfolding
import DTMAudit.CurrentDraft
import DTMAudit.ManuscriptDualSpin
import DTMAudit.ManuscriptHeightDuality
import DTMAudit.ManuscriptTwistedPhase
import DTMAudit.RealThouless
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms

/-!
# Submission proof-value route audit

Every required declaration must occur in a proof VALUE, never merely an
import or theorem type. Complete project proof-value closures are always
recorded. For the main continuation argument only, the explicitly cited
external theorem counterparts may be stopping boundaries; their complete
implementation closures are recorded separately and replayed by KernelReplay.
These boundaries are checked theorem implementations, not axioms, and this
audit does not certify identity with the cited source proofs.

The physical positive-square derivative, printed height_path_formula,
differentiated fixed-Riesz label argument, literal phase curvature, and spin
root have no stopping boundaries. The lattice proof must retain arbitrary-test
balance before its positive R-squared specialization, without arbitrary-vector
division. Public roots are the theorem statements and proof identities listed
in ROOTS.json.
-/

example : DTMMinimal.statement_nonzero := DTMAudit.ManuscriptEndpoint.nonzero_statement

set_option maxHeartbeats 0
open Lean Lean.Elab.Command in
run_cmd do
  let env ← getEnv
  let allowedAxioms := #[`propext, `Classical.choice, `Quot.sound]
  let externalInputs : Array (Name × String) := #[
    (`DTMAudit.RealThouless.lyapunov_eq_log_integral,
      "Theorem 3.2: real-energy Thouless conclusion for the actual transfer exponent and DOS integral; source [34] (Thouless). The checked conclusion does not certify identity with the cited proof."),
    (`DTMAudit.RealThouless.spectral_lyapunov_normalization,
      "Theorem 3.2: spectral exponent max(0, log lambda), including subcritical zero; source [10] (Bourgain--Jitomirskaya), Theorem 1 and Corollary 2. Checked theorem counterpart."),
    (`DTMAudit.real_log_integral_continuous,
      "Theorem 3.2: real-energy continuity counterpart; source [11] (Craig--Simon), Theorem 4.2. Its energy calculus is separate from the coupling derivative."),
    (`CriticalDTM.amo_arbitrarily_small_labelled_seeds,
      "Theorem 3.7: arbitrarily small coupling seeds for each arithmetic label; source [19] (HKS), Theorems 2.2 and 2.5. Checked counterpart without assuming critical persistence.")]
  let boundaries := externalInputs.map Prod.fst
  let collect (target : Name) (stops : Array Name) : CommandElabM NameSet := do
    let mut pending := #[target]
    let mut visited : NameSet := {}
    while !pending.isEmpty do
      let n := pending.back!
      pending := pending.pop
      if !visited.contains n then
        let some idx := env.getModuleIdxFor? n | throwError "Unclassified constant: {n}"
        let mod := env.header.moduleNames[idx]!
        if #[`DTM, `DTMSpinSymmetry, `DTMMinimal, `DTMAudit].contains mod.getRoot then
          visited := visited.insert n
          unless stops.contains n do
            let info ← getConstInfo n
            if let some value := info.value? then
              pending := pending ++ value.getUsedConstants
    return visited
  let derivativeRequired := #[
    `DTMAudit.ManuscriptTraceRiesz.dos_height_path_hasDerivAt,
    `DTMAudit.ManuscriptPositiveSquare.half_square_log_hasDerivAt,
    `DTMAudit.ManuscriptPositiveSquare.dos_height_eq_half_square_log,
    `DTMAudit.ManuscriptPositiveSquare.pencil_path_hasDerivAt,
    `DTMAudit.ManuscriptPositiveSquare.dos_height_square_path_hasDerivAt,
    `DTMAudit.ManuscriptPositiveSquare.physical_square_trace_chain_rule,
    `DTMAudit.ManuscriptPositiveSquare.dos_height_path_trace_hasDerivAt,
    `CriticalDTM.exists_positive_selfAdjoint_square_rescaling,
    `CriticalDTM.selfAdjoint_square_spectrum_pos,
    `CriticalDTM.trace_cfc_log_hasDerivAt_of_scaled_defect,
    `CriticalDTM.trace_inverse_square_product_rule,
    `CriticalDTM.magneticAlgebraPencil_inverse_coe,
    `CriticalDTM.magneticAlgebraPencil_coe,
    `CriticalDTM.rootTrace_magneticAlgebra_cyclic,
    `CriticalDTM.cfc_log_squared_real_pencil]
  let latticeRequired := #[
    `DTMAudit.ManuscriptLatticeStationarity.commuting_common_origin,
    `DTMAudit.ManuscriptLatticeStationarity.threshold_actions_agree,
    `DTMAudit.ManuscriptLatticeStationarity.sources_actions_agree,
    `DTMAudit.ManuscriptLatticeStationarity.sources_mean_eq,
    `DTMAudit.ManuscriptLatticeStationarity.resolvent_and_square_mem,
    `DTMAudit.ManuscriptLatticeBalance.magnetic_balance,
    `DTMAudit.ManuscriptLatticeBalance.boundary_column,
    `DTMAudit.ManuscriptLatticeBalance.punctured_column_pairing,
    `DTMAudit.ManuscriptLatticeBalance.diagonal_pairing_source,
    `DTMAudit.ManuscriptLatticeResponse.source_calibration,
    `DTMAudit.ManuscriptLatticeResponse.Lz_single,
    `DTMAudit.ManuscriptLatticeResponse.origin_return,
    `DTMAudit.ManuscriptLatticeResponse.arbitrary_test_balance,
    `DTMAudit.ManuscriptLatticeResponse.second_return_denominator,
    `DTMAudit.ManuscriptLatticeResponse.second_return_cancellation,
    `DTMAudit.ManuscriptLatticeResponse.Lz_contracts,
    `DTMAudit.ManuscriptLatticeResponse.insertion_response]
  let labelDerivativeRequired := #[
    `DTMAudit.ManuscriptRieszContinuity.magneticHamiltonian_hasDerivAt,
    `DTMAudit.ManuscriptRieszContinuity.fixedCircleInverse_hasDerivAt,
    `DTMAudit.ManuscriptRieszContinuity.fixedCircleIntegral_hasDerivAt,
    `DTMAudit.ManuscriptRieszContinuity.fixedCircleTrace_hasDerivAt_zero,
    `DTMAudit.ManuscriptRieszContinuity.fixedCircleTrace_eventually_eq,
    `DTMAudit.ManuscriptRieszContinuity.fixedCircleIntegral_eq_gapProjection,
    `DTMAudit.ManuscriptRieszContinuity.gapProjection_eq_of_common_gap,
    `CriticalDTM.magneticGapProjection_idempotent,
    `CriticalDTM.magneticLowerMass_eq_projection_trace,
    `CriticalDTM.magneticTraceReal_cyclic,
    `CriticalDTM.projection_derivative_tangent,
    `CriticalDTM.trace_projection_tangent_zero,
    `CriticalDTM.trace_projection_hasDerivAt_zero]
  let labelConjugacyForbidden := #[
    `CriticalDTM.trace_projection_isLocallyConstant,
    `CriticalDTM.trace_projection_eventually_eq,
    `CriticalDTM.trace_projection_eq_of_preconnected,
    `CriticalDTM.trace_eq_of_projectionIntertwiner_isUnit,
    `CriticalDTM.projectionIntertwiner_intertwines,
    `CriticalDTM.projectionIntertwiner]
  let continuationRequired := labelDerivativeRequired ++ #[
    `DTMAudit.ManuscriptEndpoint.physical_monotonicity,
    `DTMAudit.ManuscriptCouplingResponse.height_monotoneOn,
    `DTMAudit.ManuscriptCouplingSelected.selected_gap_energy,
    `DTMAudit.ManuscriptCouplingEnergy.dos_log_energy_hasDerivAt,
    `DTMAudit.ManuscriptPotential.height,
    `DTMAudit.ManuscriptPotential.height_upperSemicontinuous,
    `DTMAudit.ManuscriptPotential.height_eq_iInf,
    `DTMAudit.ManuscriptPotential.height_spectral_value,
    `DTMAudit.ManuscriptRieszContinuity.lowerMass_joint_label_locallyConstant,
    `DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant,
    `DTMAudit.ManuscriptContinuation.magneticStationarySuperlevel_right_extension,
    `DTMAudit.ManuscriptContinuation.magnetic_stationary_point_at_target_of_positive_seed,
    `DTMAudit.ManuscriptContinuation.magnetic_labelled_gap_persists_from_one_seed,
    `CriticalDTM.magnetic_green_local_c1_zero_branch,
    `CriticalDTM.magneticStationarySuperlevel_isCompact,
    `CriticalDTM.compact_coupling_reaches_target]
  let positiveRequired := #[
    `DTMAudit.ManuscriptContinuation.all_positive,
    `DTMAudit.ManuscriptContinuation.subcritical_and_critical,
    `CriticalDTM.amo_labelled_gap_aubry,
    `CriticalDTM.magneticAubry_conjugacy,
    `CriticalDTM.magneticAubry_intertwines,
    `CriticalDTM.amo_arbitrarily_small_labelled_seeds]
  let signRequired := #[
    `DTMAudit.ManuscriptSignDuality.amo_labelled_gap_iff,
    `DTMAudit.ManuscriptSignDuality.intertwines,
    `DTMAudit.ManuscriptSignDuality.conjugacy,
    `DTMAudit.ManuscriptSignDuality.spectrum_eq,
    `DTMAudit.ManuscriptSignDuality.dos_eq,
    `DTMAudit.ManuscriptSignDuality.lowerMass_eq]
  let forbidden := #[
    `DTMAudit.ChiralSourceStationarity.source_stationary_of_fibers,
    `DTMAudit.ChiralSourceStationarity.vectorized_commutator,
    `DTMAudit.ChiralSourceStationarity.threshold_stationary,
    `DTMAudit.ChiralSourceStationarity.sources_stationary,
    `DTMAudit.PhysicalFermiStationarity.thresholdSource_stationary_from_fibers,
    `DTMAudit.ChiralMagneticBalance.boundary_balance,
    `DTMAudit.ChiralMagneticBalance.punctured_current_zero,
    `DTMAudit.ChiralMagneticBalance.source_current,
    `CriticalDTM.Chiral.second_return_balance,
    `CriticalDTM.Chiral.magnetic_second_return,
    `CriticalDTM.Chiral.punctured_axis_current_zero,
    `CriticalDTM.Chiral.magnetic_centered_response,
    `CriticalDTM.Chiral.magnetic_angular_green_bound,
    `CriticalDTM.magnetic_stationary_green_bound,
    `CriticalDTM.magnetic_selected_radius_continues,
    `CriticalDTM.radius_has_left_limit,
    `CriticalDTM.magnetic_labelled_gap_persists_by_radius,
    `CriticalDTM.magnetic_labelled_gap_persists_from_one_seed,
    `CriticalDTM.magnetic_stationary_point_at_target_of_positive_seed,
    `CriticalDTM.amo_dryTenMartini_all_positive,
    `CriticalDTM.amo_all_positive_dryTenMartini_of_arbitrarily_small_seeds,
    `CriticalDTM.Spin.magnetic_rootfree_compression,
    `CriticalDTM.magneticCompression,
    `DTMMinimal.full_dry_ten_martini,
    `DTMMinimal.full_dry_ten_martini_nonzero,
    `DTMMinimal.statement_proved,
    `DTMMinimal.nonzero_statement_proved]
  let forbiddenPrefixes := #[`DTMAudit.ChiralAngularResponse, `DTMAudit.SourceResponse,
    `DTMAudit.ChiralCoupling, `DTMAudit.ChiralPersistence, `DTMAudit.Persistence]
  let specializedDerivatives := #[
    `CriticalDTM.magneticLogPotential_energy_hasDerivAt,
    `CriticalDTM.magneticLogPotential_coupling_hasDerivAt,
    `CriticalDTM.magneticLogPotential_path_hasDerivAt,
    `CriticalDTM.magneticLogPotential_stationary_path_hasDerivAt,
    `CriticalDTM.half_trace_cfc_log_sq_hasDerivAt,
    `CriticalDTM.trace_cfc_log_sq_hasDerivAt]
  let contourDerivatives := #[
    `DTMAudit.ManuscriptTraceRiesz.fixed_contours_path_hasDerivAt,
    `DTMAudit.ManuscriptTraceCoupling.weighted_circle_hasDerivAt,
    `DTMAudit.ManuscriptTraceCoupling.trace_green_coupling_hasDerivAt]
  let noCyclic := #[`CriticalDTM.rootTrace_closure_cyclic,
    `CriticalDTM.rootTrace_polynomials_cyclic, `CriticalDTM.rootTrace_monomials_cyclic,
    `CriticalDTM.magneticTraceReal_cyclic, `DTMAudit.MeasurableFamily.CovariantFamily.trace_cyclic]
  -- Flags: cited boundaries enabled, literal phase cyclicity forbidden,
  -- external implementation (whose energy calculus is reported openly).
  let cases : Array (Name × Array Name × Bool × Bool × Bool) := #[
    (`DryTenMartini.dry_ten_martini,
      derivativeRequired ++ latticeRequired ++ continuationRequired ++ positiveRequired ++ signRequired ++
        #[`CurrentDraft.dry_ten_martini, `DTMAudit.ManuscriptEndpoint.nonzero_statement], true, false, false),
    (`DryTenMartini.exact_unfolding, #[`DryTenMartini.IrrationalFrequency,
      `DryTenMartini.SequenceSpace, `DryTenMartini.AMOFamily, `DryTenMartini.InvertibleAt,
      `DryTenMartini.DirichletMatrix, `DryTenMartini.NormalizedCount,
      `DryTenMartini.HasGapLabel, `DryTenMartini.CommonLabelledGap], false, false, false),
    (`CurrentDraft.dry_ten_martini,
      derivativeRequired ++ latticeRequired ++ continuationRequired ++ positiveRequired ++ signRequired ++
        #[`DTMAudit.ManuscriptEndpoint.nonzero_statement], true, false, false),
    (`DTMAudit.ManuscriptEndpoint.nonzero_statement,
      derivativeRequired ++ latticeRequired ++ continuationRequired ++ positiveRequired ++ signRequired,
      true, false, false),
    (`DTMAudit.ManuscriptLatticeStationarity.closed_fermi_stationary, #[
      `DTMAudit.ManuscriptLatticeStationarity.threshold_actions_agree,
      `DTMAudit.ManuscriptLatticeStationarity.commuting_common_origin,
      `DTMAudit.FullFermiProjection.lowerProjection_commute_h,
      `DTMAudit.FullFermiProjection.lowerProjection_commute_conjugate,
      `DTMAudit.ClosedFermiCuts.closedLowerProjection_eq_lower,
      `CriticalDTM.magnetic_operators_commute,
      `CriticalDTM.magnetic_operators_agree_on_root], false, false, false),
    (`DTMAudit.ManuscriptLatticeBalance.magnetic_balance, #[
      `DTMAudit.ManuscriptLatticeBalance.boundary_column,
      `DTMAudit.ManuscriptLatticeBalance.punctured_column_pairing,
      `DTMAudit.ManuscriptLatticeBalance.diagonal_pairing_source,
      `DTMAudit.ManuscriptLatticeBalance.first_projection_pairing,
      `DTMAudit.ManuscriptLatticeBalance.second_projection_pairing,
      `DTMAudit.ManuscriptLatticeBalance.diagonal_support], false, false, false),
    (`DTMAudit.RealThouless.lyapunov_eq_log_integral, #[
      `DTMAudit.RealThouless.lyapunov_eq_total_potential,
      `DTMAudit.RealThouless.lyapunov_real_le_complex,
      `DTMAudit.RealThouless.transfer_norm_real_le,
      `CriticalDTM.magneticTotalLogPotential_eq_singularIntegral], false, false, true),
    (`DTMAudit.RealThouless.normalization_statement, #[
      `DTMAudit.RealThouless.lyapunov_eq_log_integral,
      `DTMAudit.RealThouless.spectral_lyapunov_normalization,
      `CriticalDTM.magnetic_realLogKernel_integrable,
      `DTMAudit.real_log_integral_continuous], false, false, true),
    (`DTMAudit.ManuscriptPotential.height_upperSemicontinuous, #[
      `DTMAudit.ManuscriptPotential.height_eq_iInf,
      `DTMAudit.ManuscriptPotential.regularizations_bddBelow,
      `CriticalDTM.magneticRegularizedLogPotential_tendsto_singularIntegral,
      `CriticalDTM.magneticRegularizedLogPotential_continuous,
      `CriticalDTM.magneticRegularizedLogPotential_antitone], false, false, false),
    (`DTMAudit.ManuscriptCouplingSelected.selected_gap_energy_analytic_branch, #[
      `DTMAudit.ManuscriptCouplingSelected.selected_gap_energy,
      `DTMAudit.ManuscriptCouplingEnergy.dos_log_energy_hasDerivAt,
      `CriticalDTM.spectral_gap_unique_positive_maximum,
      `CriticalDTM.magnetic_green_local_analytic_zero_branch,
      `DTMAudit.real_log_integral_continuous,
      `DTMAudit.RealThouless.lyapunov_eq_log_integral,
      `DTMAudit.RealThouless.spectral_lyapunov_normalization], true, false, false),
    (`DTMAudit.ManuscriptTraceRiesz.selected_height_weighted_insertion,
      derivativeRequired ++ #[`DTMAudit.PhaseDerivative.source_hasDerivAt], false, false, false),
    (`DTMAudit.ManuscriptCouplingResponse.height_path_formula,
      derivativeRequired ++ latticeRequired, false, false, false),
    (`CriticalDTM.amo_arbitrarily_small_labelled_seeds, #[
      `CriticalDTM.amo_positive_lyapunov_principal_curve,
      `CriticalDTM.amo_small_seeds_of_positive_lyapunov_curve], false, false, true),
    (`DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant,
      labelDerivativeRequired, false, false, false),
    (`DTMAudit.ManuscriptEndpoint.persistence,
      derivativeRequired ++ latticeRequired ++ continuationRequired, true, false, false),
    (`DTMAudit.ManuscriptHeightDuality.selected_critical_height_derivative, #[
      `DTMAudit.ManuscriptHeightDuality.selected_height_duality_of_selection,
      `DTMAudit.ManuscriptHeightDuality.selected_height_duality,
      `DTMAudit.ManuscriptHeightDuality.dos_potential_duality,
      `CriticalDTM.magneticRealSpectralMeasure_aubry], false, false, false),
    (`DTMAudit.ManuscriptDualSpin.conserved_dual_spin_path,
      derivativeRequired ++ latticeRequired ++ #[
      `DTMAudit.ManuscriptDualSpin.centered_commute,
      `DTMAudit.ManuscriptDualSpin.selectedSource_eigenspace,
      `DTMAudit.ManuscriptDualSpin.selectedSource_angular,
      `DTMAudit.ManuscriptDualSpin.centeredRotation_H,
      `DTMAudit.ManuscriptDualSpin.centeredRotation_Lz,
      `DTMAudit.ManuscriptDualSpin.doublet_orthogonal_invariant,
      `DTMAudit.ManuscriptDualSpin.conserved_SU2,
      `DTMAudit.ManuscriptDualSpin.pauli_half_commutators,
      `DTMAudit.ManuscriptTraceRiesz.dos_height_stationary_path_hasDerivAt], false, false, false),
    (`DTMAudit.ManuscriptTwistedPhase.landau_coupling_phase_identity, #[
      `DTMAudit.ManuscriptTwistedPhase.twistedFiber,
      `DTMAudit.ManuscriptTwistedPhase.twistedFiber_coupling_hasDerivAt,
      `DTMAudit.ManuscriptTwistedPhase.twistedFiber_kx_second_hasDerivAt,
      `DTMAudit.ManuscriptTwistedPhase.twistedFiber_ky_second_hasDerivAt,
      `DTMAudit.ManuscriptTwistedPhase.hopping_hasDerivAt,
      `DTMAudit.ManuscriptTwistedPhase.hopping_second_hasDerivAt,
      `DTMAudit.ManuscriptTwistedPhase.cosine_hasDerivAt,
      `DTMAudit.ManuscriptTwistedPhase.cosine_second_hasDerivAt,
      `CriticalDTM.amoCosOperator], false, true, false),
    (`DTMAudit.ManuscriptTwistedPhase.twistedFiber_apply, #[
      `CriticalDTM.amoShift, `CriticalDTM.amoShift_star_apply,
      `CriticalDTM.amoCosOperator], false, true, false),
    (`DTMAudit.ManuscriptTraceRiesz.dos_height_coupling_trace_hasDerivAt,
      derivativeRequired, false, false, false)]
  let mut rows : Array Json := #[]
  for (target, required, useBoundaries, forbidCyclicity, externalImplementation) in cases do
    let targetInfo ← getConstInfo target
    unless targetInfo.isTheorem && !targetInfo.isUnsafe && targetInfo.value?.isSome do
      throwError "Submission root is not a safe theorem with a proof body: {target}"
    if target == `DTMAudit.ManuscriptTwistedPhase.twistedFiber_apply then
      unless targetInfo.type.getUsedConstants.contains `DTMAudit.ManuscriptTwistedPhase.twistedFiber do
        throwError "Literal twisted fiber missing from phase realization theorem type"
    let (_, axioms) := ((CollectAxioms.collect target).run env).run {}
    for ax in axioms.axioms do
      unless allowedAxioms.contains ax do
        throwError "Unexpected proof axiom for {target}: {ax}"
    let full ← collect target #[]
    let main ← if useBoundaries then collect target boundaries else pure full
    for n in required do
      unless main.contains n do
        throwError "Required proof-value dependency missing in {target}: {n}"
    if target == `DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant then
      for n in labelConjugacyForbidden do
        if full.contains n then
          throwError "Conjugacy substitutes for differentiation in the physical label proof: {n}"
    for n in forbidden do
      if full.contains n then
        throwError "Excluded endpoint anywhere in the complete proof of {target}: {n}"
    for n in specializedDerivatives do
      if !externalImplementation && main.contains n then
        throwError "Specialized logarithm derivative used in the main proof of {target}: {n}"
    if derivativeRequired.all main.contains then
      for n in contourDerivatives do
        if main.contains n then
          throwError "Contour derivative substituted for positive-square proof in {target}: {n}"
    for n in full do
      if forbiddenPrefixes.any (fun p => p.isPrefixOf n) then
        throwError "Excluded endpoint namespace used in {target}: {n}"
    if forbidCyclicity then
      for n in noCyclic do
        if full.contains n then
          throwError "Trace cyclicity used in the complete literal phase/Riesz derivative closure {target}: {n}"
    if target == `DTMAudit.ManuscriptTraceRiesz.dos_height_coupling_trace_hasDerivAt ||
        target == `DTMAudit.ManuscriptTraceRiesz.dos_height_stationary_path_hasDerivAt then
      for n in #[`DTMAudit.ManuscriptCouplingRiesz.dos_height_path_hasDerivAt,
        `DTMAudit.ManuscriptCouplingDifferentiation.phase_resolvent_origin_hasDerivAt_shifted,
        `DTMAudit.ManuscriptCouplingPhase.physical_diagonal_insertion] do
        if full.contains n then
          throwError "Phase-coordinate derivative used in direct trace proof {target}: {n}"
    if latticeRequired.all main.contains then
      if main.contains `DTMAudit.ManuscriptLatticeResponse.arbitrary_test_quotient then
        throwError "Arbitrary-vector division precedes the positive R-squared specialization in {target}"
    rows := rows.push <| Json.mkObj [
      ("theorem", toJson target.toString), ("status", toJson "PASS"),
      ("required_proof_value_dependencies", toJson (required.map Name.toString)),
      ("proof_values_only", toJson true),
      ("proof_axioms", toJson ((axioms.axioms.qsort Name.lt).map Name.toString)),
      ("external_counterpart_implementation", toJson externalImplementation),
      ("nearby_conjugacy_forbidden_in_complete_label_closure", toJson
        (target == `DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant)),
      ("external_input_boundaries_enabled", toJson useBoundaries),
      ("encountered_external_inputs", toJson ((boundaries.filter main.contains).map Name.toString)),
      ("cyclicity_forbidden_in_complete_closure", toJson forbidCyclicity),
      ("cyclic_trace_infrastructure_in_complete_closure",
        toJson ((noCyclic.filter full.contains).map Name.toString)),
      ("positive_square_route_checked_without_boundaries", toJson
        (derivativeRequired.all full.contains && !useBoundaries)),
      ("specialized_derivatives_below_cited_boundaries",
        toJson ((specializedDerivatives.filter fun n => full.contains n && !main.contains n).map Name.toString)),
      ("main_project_dependency_count", toJson main.size),
      ("main_project_dependencies", toJson ((main.toArray.qsort Name.lt).map Name.toString)),
      ("complete_project_dependency_count", toJson full.size),
      ("complete_project_dependencies", toJson ((full.toArray.qsort Name.lt).map Name.toString))]
  let mut inputRows : Array Json := #[]
  for (n, reason) in externalInputs do
    let closure ← collect n #[]
    inputRows := inputRows.push <| Json.mkObj [
      ("theorem", toJson n.toString), ("role", toJson reason),
      ("checked_theorem_counterpart_not_an_axiom", toJson true),
      ("cited_source_proof_identity_certified", toJson false),
      ("specialized_derivative_dependencies",
        toJson ((specializedDerivatives.filter closure.contains).map Name.toString)),
      ("complete_project_dependencies", toJson ((closure.toArray.qsort Name.lt).map Name.toString))]
  let some destination ← IO.getEnv "CURRENT_DRAFT_ROUTE_OUTPUT"
    | throwError "CURRENT_DRAFT_ROUTE_OUTPUT must be set"
  IO.FS.writeFile destination
    ((Json.mkObj [("status", toJson "PASS"),
      ("scope", toJson "submission statements: modular and literal all-nonzero theorem; physical lattice and printed response; positive-square derivative; differentiated Riesz labels; compact continuation; duality, spin and phase curvature; checked external theorem counterparts"),
      ("independent_all_nonzero_assignment", toJson true),
      ("cited_external_proof_identity_certified", toJson false),
      ("required_dependencies_use_proof_values_not_types_or_imports", toJson true),
      ("external_inputs", .arr inputRows),
      ("forbidden_complete_closure_fallbacks", toJson (forbidden.map Name.toString)),
      ("contour_derivative_forbidden_in_positive_square_route", toJson (contourDerivatives.map Name.toString)),
      ("label_conjugacy_forbidden", toJson (labelConjugacyForbidden.map Name.toString)),
      ("forbidden_main_derivatives", toJson (specializedDerivatives.map Name.toString)),
      ("forbidden_complete_closure_prefixes", toJson (forbiddenPrefixes.map Name.toString)),
      ("roots", .arr rows)]).pretty ++ "\n")
  IO.println "CURRENT_DRAFT_ROUTE_PASS: all submission roots retain their required proof-value routes; cited external proof identity is not certified."

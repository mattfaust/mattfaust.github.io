import DTMMinimal.Statement
import DTMAudit.CurrentDraft
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms

/-! The complete printed theorem is independently restated below. Its raw
elaborated type is additionally classified by actual defining module, including
implicit instances. No mathematical or generated-proof project constant is
allowed in the public type. The separate Mathlib-only specification is checked
independently and the actual manuscript endpoint has that exact proposition.
The explicit finite-matrix statement is derived from it in DTMAudit.CurrentDraft;
we do not claim that this conversion is mere definitional equality. -/

noncomputable section
open Filter
open scoped Topology
example :
    ∀ α : ℝ, Irrational α →
    ∃ h : ℝ → ℝ → (ℓ²(ℤ, ℂ) →L[ℂ] ℓ²(ℤ, ℂ)),
      (∀ (lam φ : ℝ) (ψ : ℓ²(ℤ, ℂ)) (j : ℤ),
        h lam φ ψ j = ψ (j + 1) + ψ (j - 1) +
          ((2 * lam * Real.cos (2 * Real.pi * α * (j : ℝ) + φ) : ℝ) : ℂ) * ψ j) ∧
      ∀ lam : ℝ, lam ≠ 0 → ∀ n : ℤ, n ≠ 0 →
        ∃ a b : ℝ, a < b ∧ ∀ φ : ℝ,
          (a : ℂ) ∈ spectrum ℂ (h lam φ) ∧
          (b : ℂ) ∈ spectrum ℂ (h lam φ) ∧
          ∀ E : ℝ, a < E → E < b →
            (E : ℂ) ∉ spectrum ℂ (h lam φ) ∧
            Tendsto
              (fun L : ℕ =>
                (((Matrix.charpoly (fun i j : Fin (L + 1) =>
                  (if (i.val : ℤ) + 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
                  (if (i.val : ℤ) - 1 = (j.val : ℤ) then (1 : ℂ) else 0) +
                  (if i = j then
                    ((2 * lam * Real.cos (2 * Real.pi * α * (i.val : ℝ) + φ) : ℝ) : ℂ)
                   else 0))).roots.countP
                    (fun z : ℂ => z.re < E) : ℕ) : ℝ) / ((L + 1 : ℕ) : ℝ))
              atTop (𝓝 (Int.fract ((n : ℝ) * α))) := CurrentDraft.dry_ten_martini

example : DTMMinimal.statement_nonzero := DTMAudit.ManuscriptEndpoint.nonzero_statement

set_option maxHeartbeats 0
open Lean in
run_cmd do
  let env ← getEnv
  let allowedAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let target := `CurrentDraft.dry_ten_martini
  let info ← getConstInfo target
  unless info.isTheorem && !info.isUnsafe && info.value?.isSome do
    throwError "Not a safe theorem with a proof body: {target}"
  unless info.levelParams.isEmpty do
    throwError "Unexpected universe parameters: {target}"
  if info.type.hasFVar || info.type.hasMVar || info.type.hasLooseBVars then
    throwError "Open or unresolved theorem type: {target}"
  let mut binderNames : Array Name := #[]
  let mut cursor := info.type
  while cursor.isForall do
    match cursor with
    | .forallE binderName _ body binderInfo =>
      unless binderInfo == .default do
        throwError "Unexpected implicit/typeclass root binder in {target}: {binderName}"
      binderNames := binderNames.push binderName
      cursor := body
    | _ => pure ()
  unless binderNames.size == 2 && binderNames[0]! == `α do
    throwError "The public root must have exactly explicit α and Irrational α binders: {binderNames}"
  let targetModule := env.header.moduleNames[(env.getModuleIdxFor? target).get!]!
  unless targetModule == `DTMAudit.CurrentDraft do
    throwError "Unexpected defining module for public theorem: {targetModule}"
  let constants := info.type.getUsedConstants.qsort Name.lt
  let mut listed : Array Json := #[]
  for c in constants do
    let some idx := env.getModuleIdxFor? c
      | throwError "Unclassified public type constant: {c}"
    let mod := env.header.moduleNames[idx]!
    unless #[`Init, `Mathlib].contains mod.getRoot do
      throwError "Nonlibrary constant in raw public type: {c} from {mod}"
    listed := listed.push <| Json.mkObj [
      ("constant", toJson c.toString), ("defining_module", toJson mod.toString)]
  let (_, st) := ((CollectAxioms.collect target).run env).run {}
  for ax in st.axioms do
    unless allowedAxioms.contains ax do
      throwError "Unexpected public theorem proof axiom: {ax}"
  for ax in allowedAxioms do
    unless st.axioms.contains ax do
      throwError "Expected standard axiom absent from report: {ax}"
  let specification := `DTMMinimal.statement_nonzero
  let specInfo ← getConstInfo specification
  let some specValue := specInfo.value?
    | throwError "Independent specification is not a transparent definition"
  let mut specConstants : Array Json := #[]
  let mut pending := specInfo.type.getUsedConstants ++ specValue.getUsedConstants
  let mut visited : NameSet := {}
  let mut expandedProofs : Array Name := #[]
  while !pending.isEmpty do
    let c := pending.back!
    pending := pending.pop
    if !visited.contains c then
      visited := visited.insert c
      let some idx := env.getModuleIdxFor? c
        | throwError "Unclassified independent-specification constant: {c}"
      let mod := env.header.moduleNames[idx]!
      if #[`Init, `Mathlib].contains mod.getRoot then
        specConstants := specConstants.push <| Json.mkObj [
          ("constant", toJson c.toString), ("defining_module", toJson mod.toString)]
      else
        -- Lean may share generated proofs between the independent specifications.
        -- Only these proof abbreviations may be expanded; no project mathematics.
        let isGeneratedProof := #[`DTMMinimal.statement, `DTMMinimal.statement_nonzero].any fun owner =>
          let proofPrefix := owner.toString ++ "._proof_"
          c.toString.startsWith proofPrefix && (c.toString.drop proofPrefix.length).toNat?.isSome
        unless mod == `DTMMinimal.Statement && isGeneratedProof do
          throwError "Nonlibrary mathematical constant in independent specification: {c} from {mod}"
        let proofInfo ← getConstInfo c
        unless proofInfo.isTheorem && !proofInfo.isUnsafe do
          throwError "Generated specification proof is not safe: {c}"
        let some proofValue := proofInfo.value? | throwError "Missing generated proof body: {c}"
        expandedProofs := expandedProofs.push c
        pending := pending ++ proofInfo.type.getUsedConstants ++ proofValue.getUsedConstants
  let endpoint := `DTMAudit.ManuscriptEndpoint.nonzero_statement
  let endpointInfo ← getConstInfo endpoint
  unless endpointInfo.isTheorem && !endpointInfo.isUnsafe &&
      endpointInfo.type == mkConst specification && endpointInfo.value?.isSome do
    throwError "Manuscript endpoint is not the exact independent proposition assignment"
  let some literalValue := info.value? | throwError "Missing public theorem proof"
  unless literalValue.getUsedConstants.contains endpoint do
    throwError "Literal matrix theorem does not use the independently specified manuscript endpoint"
  let mut newDeclarations : Array Name := #[]
  for (name, declaration) in env.constants do
    if let some idx := env.getModuleIdxFor? name then
      if #[`DTMMinimal.Statement, `DTMAudit.CurrentDraft].contains env.header.moduleNames[idx]! then
        if declaration.isUnsafe then throwError "Unsafe declaration in public statement modules: {name}"
        newDeclarations := newDeclarations.push name
  let (_, allState) :=
    (((newDeclarations.qsort Name.lt).forM CollectAxioms.collect).run env).run {}
  for ax in allState.axioms do
    unless allowedAxioms.contains ax do
      throwError "Unexpected axiom in public statement modules: {ax}"
  let result := Json.mkObj [
    ("status", toJson "PASS"),
    ("theorem", toJson target.toString),
    ("module", toJson targetModule.toString),
    ("complete_literal_type_independently_restated", toJson true),
    ("literal_operator_row_finite_matrix_counts_spectrum_and_limit", toJson true),
    ("raw_public_type_project_constants", toJson (0 : Nat)),
    ("universe_parameters", toJson (info.levelParams.map Name.toString)),
    ("explicit_root_binders", toJson (binderNames.map Name.toString)),
    ("implicit_or_typeclass_root_binders", toJson (0 : Nat)),
    ("type_constants_including_implicit_arguments", .arr listed),
    ("proof_axioms", toJson ((st.axioms.qsort Name.lt).map Name.toString)),
    ("independent_specification", toJson specification.toString),
    ("independent_specification_constants", .arr specConstants),
    ("independent_specification_generated_proofs_expanded", toJson (expandedProofs.map Name.toString)),
    ("exact_independent_proposition_assignment", toJson endpoint.toString),
    ("literal_matrix_conversion_checked_in_public_theorem", toJson true),
    ("all_statement_module_declarations", toJson ((newDeclarations.qsort Name.lt).map Name.toString)),
    ("all_statement_module_axioms", toJson ((allState.axioms.qsort Name.lt).map Name.toString)),
    ("method", toJson "Independent complete literal statement assignment; classification of every constant of the raw public type by defining module, allowing only Init and Mathlib; independent proposition inspection and exact manuscript endpoint assignment."),
    ("scope", toJson "Signature and axiom inspection only. Cache-free specification re-elaboration and full project-free kernel replay are separate mandatory driver checks. Mathematical intention and cited proof correspondence require human review.")]
  let some output ← IO.getEnv "CURRENT_DRAFT_SIGNATURE_OUTPUT"
    | throwError "CURRENT_DRAFT_SIGNATURE_OUTPUT must be set"
  IO.FS.writeFile output (result.pretty ++ "\n")
  IO.println "CURRENT_DRAFT_SIGNATURE_PASS: complete literal all-nonzero theorem type, no project constants, independent specification assignment, and exactly the standard three axioms."

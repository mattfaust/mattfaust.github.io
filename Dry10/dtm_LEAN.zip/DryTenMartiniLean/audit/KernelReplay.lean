import Lean
import Lean.Replay
import Lean.Util.ForEachExpr

/-!
# Fresh kernel replay of the submission project

All retained safe logical declarations from the DTM, DTMSpinSymmetry,
DTMMinimal and DTMAudit module roots are replayed into a separate project-free
environment containing only pinned libraries. Source/artifact hashes and
complete module coverage are checked before and after replay. Wrong-type and
circular proofs are mandatory negative controls. No theorem hypothesis is
discharged by replay: the separate current-draft signature audit verifies the
complete printed public contract, while internal conditional lemmas retain
their stated premises.

Explicit submission roots are supplied by JSON. Discovery and kernel
rules are unchanged: unmodified Lean.Environment.replay is invoked, with no
trusted project declarations, no skipped safe logical declarations, and no
custom project axioms. This is stronger than an import-only frontend check;
it does not by itself establish human mathematical intention or identity with
the cited proofs of external results.
-/


set_option maxHeartbeats 0
set_option maxRecDepth 100000

open Lean

namespace DirectSpinKernelReplay

def require (condition : Bool) (message : String) : IO Unit :=
  unless condition do throw <| IO.userError message

def exceptIO {α : Type} (result : Except String α) : IO α :=
  match result with
  | .ok value => pure value
  | .error message => throw <| IO.userError message

def isProject (name : Name) : Bool :=
  #[`DTM, `DTMSpinSymmetry, `DTMMinimal, `DTMAudit].contains name.getRoot

def owner (env : Environment) (name : Name) : Name :=
  match env.getModuleIdxFor? name with
  | some index => env.header.moduleNames[index]!
  | none => .anonymous

/-- GNU/Linux and stock macOS SHA256 tools. The POSIX availability guard
selects `shasum` only when the GNU executable is unavailable. A running hash
command's failure or malformed digest remains fatal. The file is an argv
argument, never interpolated into shell source. -/
def sha256 (path : System.FilePath) : IO String := do
  let result ← IO.Process.output {
    cmd := "/bin/sh"
    args := #["-c",
      "if command -v sha256sum >/dev/null 2>&1; then exec sha256sum -- \"$1\"; else exec shasum -a 256 -- \"$1\"; fi",
      "dtm-sha256", path.toString] }
  require (result.exitCode == 0) s!"SHA256 command failed for {path}: {result.stderr}"
  let digest := (result.stdout.splitOn " ").head!
  require (digest.length == 64 && digest.toList.all ("0123456789abcdef".contains ·))
    s!"Invalid SHA256 output for {path}"
  pure digest

structure ModuleSnapshot where
  name : Name
  relativeSource : String
  source : System.FilePath
  artifact : System.FilePath
  sourceHash : String
  artifactHash : String
  classification : String
  deriving Inhabited

def discover (root : System.FilePath) : IO (Array (Name × String)) := do
  let mut files : Array System.FilePath := #[]
  for stem in #["DTM", "DTMSpinSymmetry", "DTMMinimal", "DTMAudit"] do
    let top := root / (stem ++ ".lean")
    if ← top.pathExists then files := files.push top
    let directory := root / stem
    if ← directory.isDir then files := files ++ (← directory.walkDir)
  let mut result := #[]
  for file in files do
    if file.extension == some "lean" then
      require (file.toString.startsWith (root.toString ++ "/"))
        s!"Source escapes project root: {file}"
      let relative := file.toString.drop (root.toString.length + 1)
      let name := (relative.dropRight 5).splitOn "/" |>.foldl Name.str .anonymous
      require (isProject name) s!"Not a DTM source module: {file}"
      result := result.push (name, relative)
  result := result.qsort fun a b => Name.lt a.1 b.1
  let mut seen : NameSet := {}
  for (name, _) in result do
    require (!seen.contains name) s!"Duplicate source module: {name}"
    seen := seen.insert name
  require (!result.isEmpty) "No DTM source modules discovered"
  pure result

def snapshot (root : System.FilePath) : IO (Array ModuleSnapshot) := do
  let mut result : Array ModuleSnapshot := #[]
  for (name, relative) in ← discover root do
    let source := root / relative
    let artifact ← IO.FS.realPath (← findOLean name)
    let expected ← IO.FS.realPath
      (root / ".lake/build/lib/lean" / ((relative.dropRight 5) ++ ".olean"))
    require (artifact == expected) s!"Wrong-project artifact for {name}: {artifact}"
    let sourceMeta ← source.metadata
    let artifactMeta ← artifact.metadata
    require (!(artifactMeta.modified < sourceMeta.modified))
      s!"Stale .olean: {name}; rebuild every DTM module before auditing"
    let sourceHash ← sha256 source
    let artifactHash ← sha256 artifact
    let classification := "project_module"
    result := result.push {
      name := name
      relativeSource := relative
      source := source
      artifact := artifact
      sourceHash := sourceHash
      artifactHash := artifactHash
      classification := classification }
  pure result

def verifySnapshot (root : System.FilePath) (modules : Array ModuleSnapshot) : IO Unit := do
  let current ← discover root
  require (current.map Prod.fst == modules.map (·.name))
    "Project module set changed while the audit was running"
  for m in modules do
    require ((← sha256 m.source) == m.sourceHash)
      s!"Source changed during audit: {m.name}"
    require ((← sha256 m.artifact) == m.artifactHash)
      s!"Artifact changed during audit: {m.name}"

def loadSource (modules : Array ModuleSnapshot) : IO Environment := do
  let env ← importModules (modules.map fun m => ({ module := m.name } : Import)) {} 0
    (loadExts := false)
  let loaded := env.header.moduleNames.filter isProject
  for m in modules do
    require (loaded.contains m.name) s!"Source module was not imported: {m.name}"
  for m in loaded do
    require (modules.any (·.name == m)) s!"Imported DTM module has no discovered source: {m}"
  require (loaded.size == modules.size) "Source/import module coverage mismatch"
  pure env

/-- Includes structure-projection references as well as ordinary constants. -/
def expressionDependencies (expression : Expr) : IO NameSet := do
  let names ← IO.mkRef ({} : NameSet)
  expression.forEach fun e => do
    match e with
    | .const name _ => names.modify (·.insert name)
    | .proj name _ _ => names.modify (·.insert name)
    | _ => pure ()
  names.get

/-- Checked declaration dependencies, including inductive and recursor metadata. -/
def declarationDependencies (info : ConstantInfo) : IO NameSet := do
  let mut names ← expressionDependencies info.type
  if let some value := info.value? then
    names := names ++ (← expressionDependencies value)
  match info with
  | .opaqueInfo value => names := names ++ (← expressionDependencies value.value)
  | .inductInfo value => names := names ++ .ofList (value.all ++ value.ctors)
  | .ctorInfo value => names := names.insert value.induct
  | .recInfo value =>
    names := names ++ .ofList value.all
    for rule in value.rules do
      names := (names.insert rule.ctor) ++ (← expressionDependencies rule.rhs)
  | _ => pure ()
  pure names

abbrev DependencyCache := IO.Ref (Std.HashMap Name NameSet)

structure Closure where
  visited : NameSet := {}
  axioms : NameSet := {}
  parents : Std.HashMap Name Name := {}

def closure (env : Environment) (roots : Array Name) (cache : DependencyCache)
    (initialParents : Std.HashMap Name Name := {}) : IO Closure := do
  let mut result : Closure := { parents := initialParents }
  let mut pending := roots
  while !pending.isEmpty do
    let name := pending.back!
    pending := pending.pop
    if !result.visited.contains name then
      result := { result with visited := result.visited.insert name }
      let some info := env.checked.get.find? name
        | throw <| IO.userError s!"Logical dependency missing from kernel map: {name}"
      require (!info.isUnsafe && !info.isPartial)
        s!"Unsafe/partial declaration reachable from logical roots: {name}"
      if info matches .axiomInfo _ then
        result := { result with axioms := result.axioms.insert name }
      let dependencies ← match (← cache.get)[name]? with
        | some dependencies => pure dependencies
        | none => do
          let dependencies ← declarationDependencies info
          cache.modify (·.insert name dependencies)
          pure dependencies
      for dependency in dependencies do
        if !result.visited.contains dependency then
          if !result.parents.contains dependency then
            result := { result with parents := result.parents.insert dependency name }
          pending := pending.push dependency
  pure result

def allowedAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def checkAxioms (result : Closure) : IO Unit := do
  for name in result.axioms do
    require (allowedAxioms.contains name) s!"Unexpected mathematical axiom: {name}"

def moduleJson (m : ModuleSnapshot) : Json := Json.mkObj [
  ("module", toJson m.name.toString), ("source", toJson m.relativeSource),
  ("source_sha256", toJson m.sourceHash), ("artifact", toJson (".lake/build/lib/lean/" ++ (m.relativeSource.dropRight 5) ++ ".olean")),
  ("artifact_sha256", toJson m.artifactHash), ("owner_classification", toJson m.classification)]

structure Inventory where
  safe : Std.HashMap Name ConstantInfo
  unsafeNames : NameSet
  partialNames : NameSet
  names : Array Name
  inductives : Nat
  constructors : Nat
  recursors : Nat

def inventory (source : Environment) (modules : Array ModuleSnapshot) : IO Inventory := do
  let mut safe : Std.HashMap Name ConstantInfo := {}
  let mut unsafeNames : NameSet := {}
  let mut partialNames : NameSet := {}
  let mut names : Array Name := #[]
  let mut inductives := 0
  let mut constructors := 0
  let mut recursors := 0
  for (name, elabInfo) in source.constants do
    if isProject (owner source name) then
      require (modules.any (·.name == owner source name))
        s!"Unlisted project declaration owner: {name}: {owner source name}"
      -- Compiler specializations may be .axiomInfo with isUnsafe = true.
      -- Classify only by the actual safety flag, not the constructor or name;
      -- every excluded runtime name must be unreachable before and after replay.
      if elabInfo.isUnsafe then
        unsafeNames := unsafeNames.insert name
      else
        if elabInfo matches .axiomInfo _ then
          throw <| IO.userError s!"Project mathematical axiom is forbidden: {name}"
        let some info := source.checked.get.find? name
          | throw <| IO.userError s!"Safe declaration missing from kernel map: {name}"
        require (info.name == name && info.type == elabInfo.type &&
            info.value? == elabInfo.value? && info.levelParams == elabInfo.levelParams)
          s!"Logical/elaborator declaration mismatch: {name}"
        if info.isPartial then
          require (name.toString.endsWith "._unsafe_rec")
            s!"Unexpected partial declaration (not a generated recursion companion): {name}"
          partialNames := partialNames.insert name
        else
          require (!info.isUnsafe) s!"Unexpected unsafe checked declaration: {name}"
          match info with
          | .axiomInfo _ => throw <| IO.userError s!"Project axiom is forbidden: {name}"
          | .opaqueInfo _ => throw <| IO.userError s!"Unexpected safe opaque project declaration: {name}"
          | .quotInfo _ => throw <| IO.userError s!"Unexpected project quotient primitive: {name}"
          | .inductInfo _ => inductives := inductives + 1
          | .ctorInfo _ => constructors := constructors + 1
          | .recInfo _ => recursors := recursors + 1
          | _ => pure ()
          safe := safe.insert name info
          names := names.push name
  names := names.qsort Name.lt
  require (!names.isEmpty) "No safe project declarations found"
  for name in partialNames do
    let original := name.getPrefix
    require (safe.contains original && owner source original == owner source name)
      s!"Generated partial companion has no matching safe logical definition: {name}"
  pure {
    safe := safe
    unsafeNames := unsafeNames
    partialNames := partialNames
    names := names
    inductives := inductives
    constructors := constructors
    recursors := recursors }

def audit : IO Unit := do
  initSearchPath (← findSysroot)
  let root ← IO.FS.realPath ((← IO.getEnv "DTM_SPIN_LEAN_ROOT").getD ".")
  let baselinePath : System.FilePath :=
    (← IO.getEnv "DTM_SPIN_BASE_MANIFEST").getD "audit/baseline.json"
  let baseline ← exceptIO (Json.parse (← IO.FS.readFile baselinePath))
  let _ ← exceptIO baseline.getObj?
  require (baseline.compress == "{}") "Replay configuration must be the empty object"
  let baselineHash ← sha256 baselinePath
  let some output ← IO.getEnv "DTM_SPIN_KERNEL_REPLAY_OUTPUT"
    | throw <| IO.userError "DTM_SPIN_KERNEL_REPLAY_OUTPUT is required"
  let modules ← snapshot root
  let source ← loadSource modules
  let inv ← inventory source modules
  let safe := inv.safe
  let unsafeNames := inv.unsafeNames
  let partialNames := inv.partialNames
  let names := inv.names
  let inductives := inv.inductives
  let constructors := inv.constructors
  let recursors := inv.recursors
  let mut moduleRows := #[]
  let mut classRows := #[]
  for m in modules do
    moduleRows := moduleRows.push <| Json.mkObj [
      ("module", toJson m.name.toString), ("owner_classification", toJson m.classification),
      ("safe_logical_declarations", toJson (names.filter (owner source · == m.name)).size),
      ("unsafe_runtime_artifacts", toJson (unsafeNames.toArray.filter (owner source · == m.name)).size),
      ("partial_runtime_companions", toJson (partialNames.toArray.filter (owner source · == m.name)).size)]
  for classification in #["project_module"] do
    let classModules := modules.filter (·.classification == classification)
    let belongs := fun n => classModules.any (·.name == owner source n)
    classRows := classRows.push <| Json.mkObj [
      ("owner_classification", toJson classification), ("modules", toJson classModules.size),
      ("safe_logical_declarations", toJson (names.filter belongs).size),
      ("unsafe_runtime_artifacts", toJson (unsafeNames.toArray.filter belongs).size),
      ("partial_runtime_companions", toJson (partialNames.toArray.filter belongs).size)]
  IO.println s!"DYNAMIC INVENTORY: {modules.size} modules; {names.size} safe logical declarations; {unsafeNames.size} unsafe and {partialNames.size} partial runtime artifacts excluded"
  let cacheBefore ← IO.mkRef ({} : Std.HashMap Name NameSet)
  let unionBefore ← closure source names cacheBefore
  checkAxioms unionBefore
  for name in unionBefore.visited do
    require (!unsafeNames.contains name && !partialNames.contains name)
      s!"Excluded runtime artifact reached by a safe logical target: {name}"
    if isProject (owner source name) then
      require (safe.contains name) s!"Unclassified project logical dependency: {name}"
  IO.println "ALL-SAFE LOGICAL CLOSURE PASS: excluded runtime artifacts unreachable"

  -- Create a genuinely distinct base with only vetted library modules.
  let trustedModules := source.header.moduleNames.filter (fun m => !isProject m)
  let trustedRoots : Array Name := #[`Init, `Lean, `Std, `Mathlib,
    `Batteries, `Aesop, `Qq, `ProofWidgets, `ImportGraph,
    `LeanSearchClient, `Plausible, `Cli, `Lake]
  for m in trustedModules do
    require (trustedRoots.contains m.getRoot) s!"Unvetted trusted-base module: {m}"
  let trustedImports := trustedModules.map (fun m => ({ module := m } : Import))
  IO.println s!"IMPORTING PROJECT-FREE TRUSTED BASE: {trustedImports.size} library module records"
  let base ← importModules trustedImports {} 0 (loadExts := false)
  for m in base.header.moduleNames do
    require (!isProject m) s!"Project module leaked into trusted base: {m}"
  for name in names ++ partialNames.toArray ++ unsafeNames.toArray do
    require ((base.find? name).isNone && (base.checked.get.find? name).isNone)
      s!"Project declaration already present in initial base: {name}"
  require ((base.find? `False).isSome && (base.find? `True.intro).isSome)
    "Negative-control foundations absent"
  IO.println "PROJECT-FREE BASE CHECK PASS"

  -- These malformed declarations are raw isolated data, never project axioms.
  let replayError (constants : Std.HashMap Name ConstantInfo) : IO String := do
    try
      let _ ← Lean.Environment.replay constants base
      pure ""
    catch error => pure error.toString
  let wrongName := `SpinReplayNegativeControl.wrongType
  require ((base.find? wrongName).isNone) "Wrong-type negative-control name collision"
  let wrong : ConstantInfo := .thmInfo {
    name := wrongName, levelParams := [], type := mkConst `False, value := mkConst `True.intro }
  let wrongMap : Std.HashMap Name ConstantInfo := ({} : Std.HashMap Name ConstantInfo).insert wrongName wrong
  let wrongError ← replayError wrongMap
  require (!wrongError.isEmpty) "Kernel replay accepted True.intro as a proof of False"
  let circularName := `SpinReplayNegativeControl.selfReference
  require ((base.find? circularName).isNone) "Circular negative-control name collision"
  let circular : ConstantInfo := .thmInfo {
    name := circularName, levelParams := [], type := mkConst `False, value := mkConst circularName }
  let circularMap : Std.HashMap Name ConstantInfo :=
    ({} : Std.HashMap Name ConstantInfo).insert circularName circular
  let circularError ← replayError circularMap
  require (!circularError.isEmpty) "Kernel replay accepted a self-referential proof"
  IO.println "RAW NEGATIVE CONTROLS PASS: wrong-type and circular proofs rejected"

  -- Keep the exact kernel environment between module batches; reset only
  -- transient frontend private-name aliases, as in the reviewed replay tool.
  let targetModules := source.header.moduleNames.filter isProject
  let dependencyMap ← cacheBefore.get
  let mut replayed := base
  let mut completed := 0
  let mut replayedCount := 0
  for moduleName in targetModules do
    let mut batch : Std.HashMap Name ConstantInfo := {}
    let mut normalized : NameSet := {}
    for name in names do
      if owner source name == moduleName then
        let normalizedName := privateToUserName name
        require (!normalized.contains normalizedName)
          s!"Same-module normalized-name collision needs review: {moduleName}: {name}"
        normalized := normalized.insert normalizedName
        batch := batch.insert name safe[name]!
    for (name, _) in batch.toList do
      require ((replayed.checked.get.find? name).isNone)
        s!"Batch declaration already present before replay: {name}"
      let some dependencies := dependencyMap[name]?
        | throw <| IO.userError s!"Missing checked dependency inventory: {name}"
      for dependency in dependencies do
        if isProject (owner source dependency) && !batch.contains dependency then
          require ((replayed.checked.get.find? dependency).isSome)
            s!"Original module order lacks a checked dependency: {moduleName}: {name} -> {dependency}"
    let cleanFrontend := Lean.Environment.ofKernelEnv replayed.toKernelEnv
    replayed ← Lean.Environment.replay batch cleanFrontend
    replayedCount := replayedCount + batch.size
    completed := completed + 1
    if completed % 20 == 0 || completed == targetModules.size then
      IO.println s!"REPLAYED {completed}/{targetModules.size} modules, {replayedCount}/{names.size} declarations"
      (← IO.getStdout).flush
  require (replayedCount == names.size) "Incomplete safe declaration replay coverage"
  require (completed == modules.size) "Incomplete source module batch coverage"
  for name in names do
    let some actual := replayed.checked.get.find? name
      | throw <| IO.userError s!"Safe target omitted from checked replay result: {name}"
    let expected := safe[name]!
    require (actual.type == expected.type && actual.value? == expected.value? &&
        actual.levelParams == expected.levelParams)
      s!"Replay changed a stored logical declaration: {name}"
  for name in unsafeNames.toArray ++ partialNames.toArray do
    require ((replayed.checked.get.find? name).isNone && (replayed.find? name).isNone)
      s!"Excluded runtime artifact was installed during replay: {name}"
  let cacheAfter ← IO.mkRef ({} : Std.HashMap Name NameSet)
  let unionAfter ← closure replayed names cacheAfter
  checkAxioms unionAfter
  for name in unionAfter.visited do
    require (!unsafeNames.contains name && !partialNames.contains name)
      s!"Excluded runtime artifact reached after replay: {name}"
  let some rootsPath ← IO.getEnv "DTM_MINIMAL_REPLAY_ROOTS"
    | throw <| IO.userError "DTM_MINIMAL_REPLAY_ROOTS is required"
  let rootsHash ← sha256 rootsPath
  let rootsJson ← exceptIO (Json.parse (← IO.FS.readFile rootsPath))
  let rootStrings ← exceptIO (fromJson? rootsJson : Except String (Array String))
  require (!rootStrings.isEmpty) "No public roots requested"
  let roots := rootStrings.map (fun s => s.splitOn "." |>.foldl Name.str .anonymous)
  let mut rootRows := #[]
  for theoremName in roots do
    let some info := replayed.checked.get.find? theoremName
      | throw <| IO.userError s!"Required root was not replayed: {theoremName}"
    require (safe.contains theoremName)
      s!"Requested root is not a freshly replayed project declaration: {theoremName}"
    require info.isTheorem s!"Required replay root is not a theorem: {theoremName}"
    let used ← closure replayed #[theoremName] cacheAfter
    checkAxioms used
    rootRows := rootRows.push <| Json.mkObj [
      ("theorem", toJson theoremName.toString), ("kernel_replayed", toJson true),
      ("axioms", toJson ((used.axioms.toArray.qsort Name.lt).map Name.toString))]
  require ((← sha256 rootsPath) == rootsHash) "Requested-root list changed during replay"
  verifySnapshot root modules
  require ((← sha256 baselinePath) == baselineHash) "Empty replay configuration changed during replay"
  let report := Json.mkObj [
    ("status", toJson "PASS"),
    ("method", toJson "Unmodified Lean.Environment.replay / checked addDeclCore; all current project safe declarations; separate project-free library base; original-module batches reset only frontend private-name bookkeeping via ofKernelEnv"),
    ("actual_kernel_replay_performed", toJson true),
    ("import_only_check", toJson false),
    ("trusted_library_proofs_replayed", toJson false),
    ("route_dependency_audit", toJson "Separate matched-route and exact-statement reports required"),
    ("all_discovered_project_modules_imported", toJson true),
    ("source_artifact_snapshot_stable", toJson true),
    ("project_module_count", toJson modules.size),
    ("replayed_module_batches", toJson completed),
    ("safe_logical_declarations_replayed", toJson replayedCount),
    ("logical_declarations_skipped", toJson (0 : Nat)),
    ("custom_project_axioms", toJson (0 : Nat)),
    ("project_declarations_in_initial_base", toJson (0 : Nat)),
    ("runtime_artifacts_reachable_from_any_safe_logical_target", toJson (0 : Nat)),
    ("unsafe_runtime_artifacts_excluded", toJson unsafeNames.size),
    ("partial_runtime_companions_excluded", toJson partialNames.size),
    ("partial_companion_names", toJson ((partialNames.toArray.qsort Name.lt).map Name.toString)),
    ("unsafe_artifact_names", toJson ((unsafeNames.toArray.qsort Name.lt).map Name.toString)),
    ("inductives_rechecked", toJson inductives),
    ("constructors_regenerated_and_compared", toJson constructors),
    ("recursors_regenerated_and_compared", toJson recursors),
    ("all_batch_dependencies_checked_or_in_current_batch", toJson true),
    ("stored_types_values_and_universe_parameters_preserved", toJson true),
    ("wrong_type_negative_control_rejected", toJson true),
    ("wrong_type_negative_control_error", toJson wrongError),
    ("self_reference_negative_control_rejected", toJson true),
    ("self_reference_negative_control_error", toJson circularError),
    ("axioms_used", toJson ((unionAfter.axioms.toArray.qsort Name.lt).map Name.toString)),
    ("requested_roots_sha256", toJson rootsHash),
    ("empty_replay_configuration_sha256", toJson baselineHash),
    ("all_module_classifications_are_project_module", toJson true),
    ("classification_counts", .arr classRows), ("module_declaration_counts", .arr moduleRows),
    ("trusted_import_modules", toJson (trustedModules.map Name.toString)),
    ("modules", .arr (modules.map moduleJson)), ("roots", .arr rootRows)]
  IO.FS.writeFile output (report.pretty ++ "\n")
  IO.println s!"FULL PROJECT KERNEL REPLAY PASS: {replayedCount} safe declarations in {completed} modules; {output}"

end DirectSpinKernelReplay

def main : IO Unit := DirectSpinKernelReplay.audit

import DTMAudit.Submission.Theorem
import DTMAudit.Submission.ExpandedStatement
import DTMAudit.Submission.Unfolding
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms

/-! Exact submission contract: the modular theorem has the expanded proposition
as its type by definitional equality. The unfolding theorem has those two
propositions as its sides and is proved by Iff.rfl. The expanded proposition
contains only Init/Mathlib constants after expanding its compiler-generated
proof abbreviations; every modular definition is inspected separately. -/

example : dryTenMartiniStatement := DryTenMartini.dry_ten_martini

set_option maxHeartbeats 0
open Lean Lean.Elab.Command in
run_cmd do
  let env ← getEnv
  let allowedAxioms := #[`propext, `Classical.choice, `Quot.sound]
  let specification := `dryTenMartiniStatement
  let specInfo ← getConstInfo specification
  unless specInfo.isDefinition && !specInfo.isUnsafe && specInfo.type == mkSort .zero &&
      specInfo.levelParams.isEmpty do
    throwError "Expanded statement is not a closed safe proposition definition"
  let some expanded := specInfo.value? | throwError "Expanded statement has no value"
  if expanded.hasFVar || expanded.hasMVar || expanded.hasLooseBVars then
    throwError "Expanded statement has unresolved or free variables"
  let definitions := #[`DryTenMartini.IrrationalFrequency, `DryTenMartini.SequenceSpace,
    `DryTenMartini.AMOFamily, `DryTenMartini.InvertibleAt, `DryTenMartini.DirichletMatrix,
    `DryTenMartini.NormalizedCount, `DryTenMartini.HasGapLabel, `DryTenMartini.CommonLabelledGap]
  let classify (proposition : Expr) (allowDefinitions : Bool) : CommandElabM Json := do
    let raw := proposition.getUsedConstants.qsort Name.lt
    let mut pending := raw
    let mut visited : NameSet := {}
    let mut libraries : Array Json := #[]
    let mut proofs : Array Name := #[]
    let mut expandedDefinitions : Array Name := #[]
    let mut rawRows : Array Json := #[]
    for n in raw do
      let some idx := env.getModuleIdxFor? n | throwError "Unclassified constant: {n}"
      rawRows := rawRows.push <| Json.mkObj [
        ("constant", toJson n.toString),
        ("defining_module", toJson env.header.moduleNames[idx]!.toString)]
    while !pending.isEmpty do
      let n := pending.back!
      pending := pending.pop
      if !visited.contains n then
        visited := visited.insert n
        let info ← getConstInfo n
        let some idx := env.getModuleIdxFor? n | throwError "Unclassified constant: {n}"
        let mod := env.header.moduleNames[idx]!
        if #[`Init, `Mathlib].contains mod.getRoot then
          libraries := libraries.push <| Json.mkObj [
            ("constant", toJson n.toString), ("defining_module", toJson mod.toString)]
        else
          let isDefinition := allowDefinitions && definitions.contains n &&
            mod == `DTMAudit.Submission.Definitions && info.isDefinition && !info.isUnsafe
          let owners := if allowDefinitions then definitions else #[specification]
          let isGenerated := owners.any fun owner =>
            let proofPrefix := owner.toString ++ "._proof_"
            n.toString.startsWith proofPrefix && (n.toString.drop proofPrefix.length).toNat?.isSome
          let proofModule := if allowDefinitions then `DTMAudit.Submission.Definitions
            else `DTMAudit.Submission.ExpandedStatement
          let isProof := isGenerated && mod == proofModule && info.isTheorem && !info.isUnsafe
          unless isDefinition || isProof do
            throwError "Unpermitted project or third-party mathematical constant: {n} from {mod}"
          let some value := info.value? | throwError "Expanded declaration has no checked body: {n}"
          if isDefinition then expandedDefinitions := expandedDefinitions.push n
          else proofs := proofs.push n
          pending := pending ++ info.type.getUsedConstants ++ value.getUsedConstants
    return Json.mkObj [
      ("raw_constant_count", toJson raw.size), ("raw_constants", .arr rawRows),
      ("compiler_generated_proofs_expanded", toJson (proofs.map Name.toString)),
      ("modular_definitions_expanded", toJson (expandedDefinitions.map Name.toString)),
      ("only_init_and_mathlib_after_expansion", toJson true),
      ("unpermitted_mathematical_constants", toJson (0 : Nat)),
      ("library_constants", .arr libraries)]
  let expandedReport ← classify expanded false
  let modular ← getConstInfo `DryTenMartini.dry_ten_martini
  let unfolding ← getConstInfo `DryTenMartini.exact_unfolding
  for info in #[modular, unfolding] do
    unless info.isTheorem && !info.isUnsafe && info.value?.isSome && info.levelParams.isEmpty do
      throwError "Submission declaration is not a safe closed theorem: {info.name}"
    if info.type.hasFVar || info.type.hasMVar || info.type.hasLooseBVars then
      throwError "Submission theorem type is open: {info.name}"
  unless ← liftTermElabM (Meta.isDefEq modular.type expanded) do
    throwError "Modular theorem type differs from the expanded proposition"
  unless unfolding.type.isAppOfArity `Iff 2 do
    throwError "Unfolding theorem is not an equivalence"
  let sides := unfolding.type.getAppArgs
  unless ← liftTermElabM (Meta.isDefEq sides[0]! modular.type) do
    throwError "Unfolding left side differs from the modular theorem type"
  unless ← liftTermElabM (Meta.isDefEq sides[1]! expanded) do
    throwError "Unfolding right side differs from the expanded proposition"
  unless unfolding.value?.get!.isAppOfArity `Iff.rfl 1 do
    throwError "Unfolding proof is not literally Iff.rfl"
  unless modular.value?.get!.getUsedConstants.contains `CurrentDraft.dry_ten_martini do
    throwError "Submission theorem does not use the checked literal theorem"
  let modularReport ← classify modular.type true
  let mut rows : Array Json := #[]
  for target in #[`DryTenMartini.dry_ten_martini, `DryTenMartini.exact_unfolding] do
    let info ← getConstInfo target
    let (_, state) := ((CollectAxioms.collect target).run env).run {}
    for ax in state.axioms do
      unless allowedAxioms.contains ax do throwError "Unexpected proof axiom in {target}: {ax}"
    for ax in allowedAxioms do
      unless state.axioms.contains ax do throwError "Missing expected standard axiom in {target}: {ax}"
    rows := rows.push <| Json.mkObj [
      ("theorem", toJson target.toString), ("safe_theorem_with_body", toJson true),
      ("universe_parameters", toJson (info.levelParams.map Name.toString)),
      ("proof_axioms", toJson ((state.axioms.qsort Name.lt).map Name.toString))]
  let mut binderNames : Array Name := #[]
  let mut cursor := modular.type
  while cursor.isForall do
    match cursor with
    | .forallE name _ body binderInfo =>
      unless binderInfo == .default do throwError "Implicit or typeclass public premise: {name}"
      binderNames := binderNames.push name
      cursor := body
    | _ => pure ()
  unless binderNames.size == 2 && binderNames[0]! == `α do
    throwError "Unexpected submission root premises: {binderNames}"
  let some destination ← IO.getEnv "SUBMISSION_SIGNATURE_OUTPUT"
    | throwError "SUBMISSION_SIGNATURE_OUTPUT must be set"
  IO.FS.writeFile destination <| (Json.mkObj [
    ("status", toJson "PASS"), ("theorem", toJson "DryTenMartini.dry_ten_martini"),
    ("expanded_specification", toJson specification.toString),
    ("definitionally_exact_expanded_assignment", toJson true),
    ("unfolding_both_sides_definitionally_exact", toJson true),
    ("unfolding_proof_is_Iff_rfl", toJson true),
    ("derives_from_literal_public_theorem", toJson true),
    ("implicit_or_typeclass_outer_premises", toJson (0 : Nat)),
    ("explicit_outer_binders", toJson (binderNames.map Name.toString)),
    ("expanded_statement", expandedReport), ("modular_type", modularReport),
    ("theorems", .arr rows)]).pretty ++ "\n"
  IO.println "SUBMISSION_SIGNATURE_PASS: exact expanded type, explicit modular definitions, Iff.rfl unfolding, and standard axioms."

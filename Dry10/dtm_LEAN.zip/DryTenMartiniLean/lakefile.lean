import Lake
open Lake DSL

package «critical-dtm-minimal» where
  leanOptions := #[⟨`warningAsError, true⟩]

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "v4.19.0"

lean_lib DTM where
  globs := #[.submodules `DTM]

@[default_target]
lean_lib DTMMinimal where
  globs := #[.submodules `DTMMinimal]

@[default_target]
lean_lib DTMAudit where
  globs := #[.submodules `DTMAudit]

#!/usr/bin/env python3
"""Audit the already source-built submission project. This does not rebuild Mathlib.

Run from formalization after a clean source build:
    python3 tools/verify-companion.py
The independent specification is re-elaborated with the project cache removed.
All retained safe project declarations are replayed into a project-free base.
Only submission roots are public audit targets. Cited source proof identity
is not inferred from checked replacement proofs of the cited external inputs.
"""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import re
import resource
import subprocess
import time


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    bundle = Path(__file__).resolve().parent.parent
    project = bundle
    audit = bundle / 'audit'
    logs = audit / ('verified-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d-%H%M%S'))
    logs.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, LEAN_NUM_THREADS='1')
    env['PATH'] = str(Path.home() / '.elan/bin') + os.pathsep + env.get('PATH', '')
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    try:
        resource.setrlimit(resource.RLIMIT_STACK,
                          (128 * 1024 * 1024 if hard == resource.RLIM_INFINITY else min(128 * 1024 * 1024, hard), hard))
    except (ValueError, OSError) as error:
        # macOS sandbox rejects even resetting its reported existing limit.
        # Retain that limit; every Lean/kernel check and failure rule is unchanged.
        print('STACK_LIMIT_UNCHANGED: ' + str(error), flush=True)
    started = time.time()

    def output(command):
        return subprocess.check_output(command, cwd=project, env=env, text=True).strip()

    def run(command, name, local_env):
        print('CHECK ' + name, flush=True)
        with (logs / name).open('w') as log:
            process = subprocess.Popen(command, cwd=project, env=local_env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in process.stdout:
                print(line, end='', flush=True)
                log.write(line)
                log.flush()
            code = process.wait()
        text = (logs / name).read_text()
        require(code == 0, f'{name}: nonzero exit {code}')
        require(not re.search(r'PANIC|: error:|: warning:', text),
                f'{name}: panic/error/warning (a PASS line cannot override it)')

    version = output(['lean', '--version'])
    require('version 4.19.0' in version, 'Wrong Lean version: ' + version)
    require(output(['lean', '--githash']) == '6caaee842e9495688c1567e78c0e68dbb96942aa', 'Wrong Lean binary commit')
    configs = {n: sha(project / n) for n in ['lean-toolchain', 'lake-manifest.json', 'lakefile.lean']}
    manifest = json.loads((project / 'lake-manifest.json').read_text())
    packages = []
    for package in manifest['packages']:
        path = project / manifest['packagesDir'] / package['name']
        revision = output(['git', '-C', str(path), 'rev-parse', 'HEAD'])
        dirty = output(['git', '-C', str(path), 'status', '--porcelain', '--untracked-files=no'])
        require(revision == package['rev'] and not dirty, 'Changed dependency: ' + package['name'])
        packages.append({'name': package['name'], 'revision': revision, 'tracked_tree_clean': True})
    def discover_modules():
        return sorted([p for folder in ['DTM', 'DTMSpinSymmetry', 'DTMMinimal', 'DTMAudit']
                       if (project / folder).is_dir() for p in (project / folder).rglob('*.lean')]
                      + [project / (n + '.lean') for n in ['DTM', 'DTMSpinSymmetry', 'DTMMinimal', 'DTMAudit']
                         if (project / (n + '.lean')).is_file()])

    modules = discover_modules()
    sources = {str(p.relative_to(project)): sha(p) for p in modules}
    source_build = json.loads((audit / 'latest-source-build.json').read_text())
    require(source_build['status'] == 'PASS' and source_build['project_build_started_empty']
            and source_build['sources_unchanged'] and source_build['source_hashes'] == sources
            and source_build['configurations_unchanged'] and source_build['configuration_hashes'] == configs
            and source_build['no_panic_error_or_warning'],
            'No matching successful fresh project source build')
    cache = project / '.lake/build/lib/lean'
    objects = {name: cache / Path(name).with_suffix('.olean') for name in sources}
    require(all(p.is_file() for p in objects.values()), 'First build every retained source module')
    object_hashes = {name: sha(path) for name, path in objects.items()}
    audit_files = [audit / 'KernelReplay.lean', audit / 'CurrentDraftSignatureAudit.lean',
                   audit / 'CurrentDraftRouteAudit.lean', audit / 'SubmissionSignatureAudit.lean', audit / 'ROOTS.json',
                   audit / 'baseline.json', audit / 'latest-source-build.json',
                   project / 'tools/verify-source-build.py', Path(__file__)]
    audit_hashes = {str(p.relative_to(bundle)): sha(p) for p in audit_files}
    roots = json.loads((audit / 'ROOTS.json').read_text())
    expected_roots = [
        'DTMAudit.ManuscriptEndpoint.nonzero_statement',
        'DTMAudit.ManuscriptLatticeStationarity.closed_fermi_stationary',
        'DTMAudit.ManuscriptLatticeBalance.magnetic_balance',
        'DTMAudit.RealThouless.lyapunov_eq_log_integral',
        'DTMAudit.RealThouless.normalization_statement',
        'DTMAudit.ManuscriptPotential.height_upperSemicontinuous',
        'DTMAudit.ManuscriptCouplingSelected.selected_gap_energy_analytic_branch',
        'DTMAudit.ManuscriptTraceRiesz.selected_height_weighted_insertion',
        'DTMAudit.ManuscriptCouplingResponse.height_path_formula',
        'CriticalDTM.amo_arbitrarily_small_labelled_seeds',
        'DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant',
        'DTMAudit.ManuscriptEndpoint.persistence',
        'DTMAudit.ManuscriptHeightDuality.selected_critical_height_derivative',
        'DTMAudit.ManuscriptDualSpin.conserved_dual_spin_path',
        'DTMAudit.ManuscriptTwistedPhase.landau_coupling_phase_identity',
        'DTMAudit.ManuscriptTwistedPhase.twistedFiber_apply',
        'DTMAudit.ManuscriptTraceRiesz.dos_height_coupling_trace_hasDerivAt',
        'CurrentDraft.dry_ten_martini',
        'DryTenMartini.dry_ten_martini',
        'DryTenMartini.exact_unfolding',
    ]
    require(isinstance(roots, list) and all(isinstance(root, str) for root in roots)
            and len(roots) == len(set(roots))
            and set(roots) == set(expected_roots), 'Unexpected submission public roots')
    lean_path = output(['lake', 'env', 'printenv', 'LEAN_PATH'])
    parts = lean_path.split(os.pathsep)
    trusted = [p for p in parts if (project / p).resolve() != cache.resolve()]
    require(len(trusted) < len(parts), 'Failed to exclude the project cache')
    isolated = dict(env, LEAN_PATH=os.pathsep.join(trusted))
    full = dict(env, LEAN_PATH=lean_path,
                CURRENT_DRAFT_SIGNATURE_OUTPUT=str(logs / 'current-draft-signature.json'),
                CURRENT_DRAFT_ROUTE_OUTPUT=str(logs / 'current-draft-route.json'),
                SUBMISSION_SIGNATURE_OUTPUT=str(logs / 'submission-signature.json'),
                DTM_SPIN_LEAN_ROOT=str(project), DTM_SPIN_BASE_MANIFEST=str(audit / 'baseline.json'),
                DTM_SPIN_KERNEL_REPLAY_OUTPUT=str(logs / 'kernel-replay.json'),
                DTM_MINIMAL_REPLAY_ROOTS=str(audit / 'ROOTS.json'))
    common = ['lean', '-j1', '-s131072', '-DwarningAsError=true']
    independent_root = logs / 'independent'
    independent_sources = ['DTMMinimal/Statement.lean',
                           'DTMAudit/Submission/Definitions.lean',
                           'DTMAudit/Submission/ExpandedStatement.lean',
                           'DTMAudit/Submission/Unfolding.lean']
    independent_hashes = {}
    isolated_with_definitions = dict(isolated,
        LEAN_PATH=str(independent_root) + os.pathsep + isolated['LEAN_PATH'])
    for source in independent_sources:
        independent = independent_root / Path(source).with_suffix('.olean')
        independent.parent.mkdir(parents=True, exist_ok=True)
        run(common + ['--root=' + str(project), '-o', str(independent), str(project / source)],
            'independent-' + Path(source).as_posix().replace('/', '-').replace('.lean', '.log'),
            isolated_with_definitions)
        independent_hashes[source] = sha(independent)
        require(independent_hashes[source] == sha(objects[source]),
                'Independent artifact differs from source-built module: ' + source)
    run(common + [str(audit / 'CurrentDraftSignatureAudit.lean')], 'current-draft-signature.log', full)
    run(common + [str(audit / 'SubmissionSignatureAudit.lean')], 'submission-signature.log', full)
    run(common + [str(audit / 'CurrentDraftRouteAudit.lean')], 'current-draft-route.log', full)
    run(common + ['--run', str(audit / 'KernelReplay.lean')], 'kernel-replay.log', full)
    signature = json.loads((logs / 'current-draft-signature.json').read_text())
    submission = json.loads((logs / 'submission-signature.json').read_text())
    route = json.loads((logs / 'current-draft-route.json').read_text())
    replay = json.loads((logs / 'kernel-replay.json').read_text())
    require(signature['status'] == submission['status'] == route['status'] == replay['status'] == 'PASS', 'Non-PASS audit report')
    require(signature['theorem'] == 'CurrentDraft.dry_ten_martini'
            and signature['complete_literal_type_independently_restated']
            and signature['literal_operator_row_finite_matrix_counts_spectrum_and_limit']
            and signature['raw_public_type_project_constants'] == 0
            and signature['implicit_or_typeclass_root_binders'] == 0
            and signature['universe_parameters'] == []
            and signature['independent_specification'] == 'DTMMinimal.statement_nonzero'
            and signature['exact_independent_proposition_assignment'] ==
                'DTMAudit.ManuscriptEndpoint.nonzero_statement'
            and signature['literal_matrix_conversion_checked_in_public_theorem'],
            'Public contract is not the complete independent literal current theorem')
    require(set(signature['proof_axioms']) == {'propext', 'Classical.choice', 'Quot.sound'},
            'Unexpected public theorem axioms')
    require(submission['theorem'] == 'DryTenMartini.dry_ten_martini'
            and submission['expanded_specification'] == 'dryTenMartiniStatement'
            and submission['definitionally_exact_expanded_assignment']
            and submission['unfolding_both_sides_definitionally_exact']
            and submission['unfolding_proof_is_Iff_rfl']
            and submission['derives_from_literal_public_theorem']
            and submission['implicit_or_typeclass_outer_premises'] == 0,
            'Submission theorem or unfolding does not match the expanded specification')
    for key in ['expanded_statement', 'modular_type']:
        require(submission[key]['only_init_and_mathlib_after_expansion']
                and submission[key]['unpermitted_mathematical_constants'] == 0,
                'Unpermitted constant in submission contract: ' + key)
    require([row['theorem'] for row in submission['theorems']] ==
            ['DryTenMartini.dry_ten_martini', 'DryTenMartini.exact_unfolding'],
            'Missing submission theorem signature')
    for row in submission['theorems']:
        require(row['safe_theorem_with_body'] and row['universe_parameters'] == []
                and set(row['proof_axioms']) == {'propext', 'Classical.choice', 'Quot.sound'},
                'Unsafe or axiom-dependent submission declaration')
    route_names = [row['theorem'] for row in route['roots']]
    require(len(route_names) == len(set(route_names)) and set(route_names) == set(roots),
            'Route audit does not cover exactly the submission roots')
    require(route['required_dependencies_use_proof_values_not_types_or_imports']
            and not route['cited_external_proof_identity_certified'],
            'Route audit scope is not the declared submission scope')
    boundary_free = {
        'DTMAudit.ManuscriptTraceRiesz.dos_height_coupling_trace_hasDerivAt',
        'DTMAudit.ManuscriptTraceRiesz.selected_height_weighted_insertion',
        'DTMAudit.ManuscriptCouplingResponse.height_path_formula',
        'DTMAudit.ManuscriptRieszContinuity.lowerMass_isLocallyConstant',
        'DTMAudit.ManuscriptDualSpin.conserved_dual_spin_path',
        'DTMAudit.ManuscriptTwistedPhase.landau_coupling_phase_identity',
        'DTMAudit.ManuscriptTwistedPhase.twistedFiber_apply',
    }
    for row in route['roots']:
        require(row['status'] == 'PASS' and row['proof_values_only'],
                'A submission route is not a passing proof-value audit')
        if row['theorem'] in boundary_free:
            require(not row['external_input_boundaries_enabled'],
                    'Stopping boundary in required complete proof route: ' + row['theorem'])
    require(replay['project_module_count'] == len(modules), 'Incomplete module replay')
    require(replay['logical_declarations_skipped'] == 0 and replay['project_declarations_in_initial_base'] == 0,
            'Replay skipped declarations or trusted project facts')
    require(replay['actual_kernel_replay_performed'] and not replay['import_only_check'], 'Not an actual replay')
    require(replay['wrong_type_negative_control_rejected'] and replay['self_reference_negative_control_rejected'],
            'Negative controls failed')
    require(replay['runtime_artifacts_reachable_from_any_safe_logical_target'] == 0 and replay['custom_project_axioms'] == 0,
            'Unexpected runtime or axiom dependency')
    require(set(replay['axioms_used']) == {'propext', 'Classical.choice', 'Quot.sound'}, 'Unexpected logical axioms')
    require([row['theorem'] for row in replay['roots']] == roots, 'Wrong replay roots')
    require(discover_modules() == modules, 'Project module inventory changed during verification')
    for name, digest in sources.items():
        require(sha(project / name) == digest and sha(objects[name]) == object_hashes[name], 'Changed source/artifact: ' + name)
    for name, digest in configs.items():
        require(sha(project / name) == digest, 'Changed configuration: ' + name)
    for name, digest in audit_hashes.items():
        require(sha(bundle / name) == digest, 'Changed audit source: ' + name)
    result = {'status': 'PASS', 'seconds': time.time() - started, 'lean_version': version,
              'method': 'Literal and modular submission signatures, exact expanded proposition and Iff.rfl unfolding, independent cache-free module elaboration with identical artifact hashes, proof-value routes, and complete safe-declaration kernel replay into a project-free base',
              'scope': 'Submission theorem statements and proof support; checked counterparts for cited external inputs without certification of cited proof identity',
              'submission_endpoint': 'DryTenMartini.dry_ten_martini',
              'literal_endpoint': 'CurrentDraft.dry_ten_martini',
              'unfolding_endpoint': 'DryTenMartini.exact_unfolding',
              'independently_specified_endpoint': 'DTMAudit.ManuscriptEndpoint.nonzero_statement',
              'current_spin_endpoint': 'DTMAudit.ManuscriptDualSpin.conserved_dual_spin_path',
              'current_normalization_endpoint': 'DTMAudit.RealThouless.normalization_statement',
              'cited_external_proof_identity_certified': False,
              'retained_project_modules': len(modules),
              'safe_logical_declarations_replayed': replay['safe_logical_declarations_replayed'],
              'roots': roots, 'dependencies': packages, 'source_hashes': sources, 'object_hashes': object_hashes,
              'configuration_hashes': configs, 'audit_source_hashes': audit_hashes,
              'fresh_source_build': 'audit/latest-source-build.json',
              'independent_artifact_sha256': independent_hashes,
              'independent_sources_project_cache_excluded': True,
              'independent_specification_matches_project_artifact': True,
              'trusted_library_cache_reused': True,
              'proof_correspondence_and_mathematical_intention_require_human_review': True,
              'reports': {'signature': str((logs / 'current-draft-signature.json').relative_to(bundle)),
                          'submission_signature': str((logs / 'submission-signature.json').relative_to(bundle)),
                          'kernel_replay': str((logs / 'kernel-replay.json').relative_to(bundle)),
                          'current_draft_route': str((logs / 'current-draft-route.json').relative_to(bundle))}}
    (logs / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    (audit / 'latest-verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print('SUBMISSION VERIFICATION PASS — full report: ' + str(logs / 'result.json'))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Build every project source from an empty project cache; keep library caches."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import re
import subprocess
import time

project = Path(__file__).resolve().parent.parent
stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d-%H%M%S')
logs = project / 'audit' / ('source-build-' + stamp)
logs.mkdir(parents=True)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sources():
    paths = [p for folder in ['DTM', 'DTMSpinSymmetry', 'DTMMinimal', 'DTMAudit']
             if (project / folder).is_dir() for p in (project / folder).rglob('*.lean')]
    paths += [project / (name + '.lean') for name in ['DTM', 'DTMSpinSymmetry', 'DTMMinimal', 'DTMAudit']
              if (project / (name + '.lean')).is_file()]
    return {str(p.relative_to(project)): sha(p) for p in sorted(paths)}


hashes = sources()
configs = {name: sha(project / name) for name in ['lean-toolchain', 'lake-manifest.json', 'lakefile.lean']}
build = project / '.lake/build'
backup = project / '.lake' / ('build-backup-' + stamp)
backed_up = build.exists()
if backed_up:
    build.rename(backup)
started_empty = not build.exists()
env = dict(os.environ)
env['PATH'] = str(Path.home() / '.elan/bin') + os.pathsep + env.get('PATH', '')
command = ['lake', 'build', 'DTM', 'DTMMinimal', 'DTMAudit']
start = time.time()
print('Fresh project source build; pinned dependency cache retained.', flush=True)
with (logs / 'build.log').open('w') as log:
    process = subprocess.Popen(command, cwd=project, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, bufsize=1)
    for i, line in enumerate(process.stdout):
        log.write(line)
        log.flush()
        if i % 50 == 0 or 'error' in line.lower() or 'warning' in line.lower():
            print(line, end='', flush=True)
    code = process.wait()
unchanged = sources() == hashes
configs_unchanged = all(sha(project / name) == digest for name, digest in configs.items())
clean_log = not re.search(r'PANIC|: error:|: warning:', (logs / 'build.log').read_text())
passed = code == 0 and unchanged and configs_unchanged and started_empty and clean_log
result = {'status': 'PASS' if passed else 'FAIL', 'command': command,
          'seconds': time.time() - start, 'exit_code': code, 'source_hashes': hashes,
          'configuration_hashes': configs, 'configurations_unchanged': configs_unchanged,
          'sources_unchanged': unchanged, 'project_build_started_empty': started_empty,
          'no_panic_error_or_warning': clean_log,
          'pinned_dependency_cache_reused': True,
          'build_backup_directory': str(backup.relative_to(project)) if backed_up else None,
          'log': str((logs / 'build.log').relative_to(project))}
(logs / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
(project / 'audit/latest-source-build.json').write_text(json.dumps(result, indent=2) + '\n')
print('SOURCE BUILD ' + result['status'] + ' in %.1f seconds' % result['seconds'], flush=True)
if not passed:
    raise SystemExit(1)

import PaperUAMO.InteriorFrameAnalytic
import PaperUAMO.InteriorFrameDegree
import UAMODraft.FrameContinuity

noncomputable section
namespace PaperUAMO.BoundaryProfileAnalytic
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed Filter
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

theorem coefficient_analyticAt (m : ℕ) (k : ℤ) (x : Variables m) :
    AnalyticAt ℝ (fun y : Variables m => coefficient m y k) x := by
  unfold coefficient
  split_ifs
  · exact analyticAt_const
  · exact (ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).analyticAt x
  · exact analyticAt_const

theorem fourierProfile_analyticAt (m : ℕ) (s : Fin 2) (k : ℤ) (x : Variables m) :
    AnalyticAt ℝ (fun y : Variables m => fourierProfile m y s k) x := by
  unfold fourierProfile
  split_ifs
  · exact coefficient_analyticAt m k x
  · exact analyticAt_const

theorem physicalProfile_analytic_parameter {m : ℕ} (hm : 0<m)
    (x : ℝ → Variables m) {t : ℝ} (hxa : AnalyticAt ℝ x t) (y : ℝ) :
    AnalyticAt ℝ (fun lam => physicalProfile m (x lam) y) t := by
  apply AnalyticAt.pi
  intro s
  simp_rw [physicalProfile_sum m hm]
  apply Finset.analyticAt_sum
  intro k _
  exact ((fourierProfile_analyticAt m s k (x t)).comp hxa).mul analyticAt_const

theorem physicalProfile_analytic_phase (m : ℕ) (hm : 0<m)
    (x : Variables m) (y : ℝ) :
    AnalyticAt ℝ (physicalProfile m x) y := by
  apply AnalyticAt.pi
  intro s
  simp_rw [physicalProfile_sum m hm]
  apply Finset.analyticAt_sum
  intro k _
  simp_rw [weylPhase_zpow]
  apply analyticAt_const.mul
  apply analyticAt_cexp.restrictScalars.comp
  exact ((Complex.ofRealCLM.analyticAt _).comp
    ((analyticAt_const.mul analyticAt_id).mul analyticAt_const)).mul analyticAt_const

theorem halfPhase_analyticAt (m : ℕ) (y : ℝ) :
    AnalyticAt ℝ (halfPhase m) y := by
  unfold halfPhase
  apply analyticAt_cexp.restrictScalars.comp
  exact ((Complex.ofRealCLM.analyticAt _).comp
    (analyticAt_const.mul analyticAt_id)).mul analyticAt_const

theorem pairedRealFrame_analytic_phase (m : ℕ) (hm : 0<m)
    (x : Variables m) (y : ℝ)
    (hsig : 0<profileSignature (physicalProfile m x y)) (i j : Fin 2) :
    AnalyticAt ℝ
      (fun z => InteriorFrame.pairedRealFrame m (physicalProfile m x) z i j) y := by
  have h := InteriorFrameAnalytic.realFrameOf_analyticAt
    (physicalProfile_analytic_phase m hm x y) (halfPhase_analyticAt m y) hsig 1
  exact analyticAt_pi_iff.mp (analyticAt_pi_iff.mp h i) j

theorem pairedRealFrame_analytic_parameter {m : ℕ} (hm : 0<m)
    (x : ℝ → Variables m) {t : ℝ} (hxa : AnalyticAt ℝ x t) (y : ℝ)
    (hsig : 0<profileSignature (physicalProfile m (x t) y)) (i j : Fin 2) :
    AnalyticAt ℝ
      (fun lam => InteriorFrame.pairedRealFrame m (physicalProfile m (x lam)) y i j) t := by
  have h := InteriorFrameAnalytic.realFrameOf_analyticAt
    (physicalProfile_analytic_parameter hm x hxa y)
    (show AnalyticAt ℝ (fun _ : ℝ => halfPhase m y) t from analyticAt_const) hsig 1
  exact analyticAt_pi_iff.mp (analyticAt_pi_iff.mp h i) j

theorem pairedRealFrame_analytic_eventually {m : ℕ} (hm : 0<m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0) :
    ∀ᶠ lam in 𝓝 (0:ℝ), ∀ y : ℝ,
      0<profileSignature (physicalProfile m (x lam) y) ∧
      (∀ i j : Fin 2, AnalyticAt ℝ
        (fun z => InteriorFrame.pairedRealFrame m (physicalProfile m (x lam)) z i j) y) ∧
      (∀ i j : Fin 2, AnalyticAt ℝ
        (fun u => InteriorFrame.pairedRealFrame m (physicalProfile m (x u)) y i j) lam) := by
  filter_upwards [branch_normalized_frame hm x hx0 hxa,hxa.eventually_analyticAt]
    with lam hpositive hlocal y
  exact ⟨(hpositive y).1,
    pairedRealFrame_analytic_phase m hm (x lam) y (hpositive y).1,
    pairedRealFrame_analytic_parameter hm x hlocal y (hpositive y).1⟩

end PaperUAMO.BoundaryProfileAnalytic

import UAMODraft.ProfileFrame
import UAMODraft.Center

noncomputable section
namespace PaperUAMO.BoundaryProfileData
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed Asymptotics Filter Matrix
open scoped Topology

theorem analytic_physical_residual_bound {z : ℂ} (hz : z≠0) {α : ℝ}
    (hα : Irrational α) (m : ℕ) (hm : Odd m) (hres : z^2=(weylPhase α)^m)
    (x : ℝ→Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0,
      finiteSystem m (by obtain ⟨j,hj⟩ := hm; omega) z (weylPhase α) lam (x lam)=0) :
    ∃ R δ : ℝ, 0<R ∧ 0<δ ∧ ∀ (lam θ : ℝ) (s : Fin 2), |lam|<δ →
      ‖(boundaryNumerator lam (phaseCenter m (by obtain ⟨j,hj⟩ := hm; omega) z (x lam)) θ*ᵥ
          physicalProfile m (x lam) θ-
        (z*(amplitude m (by obtain ⟨j,hj⟩ := hm; omega) (x lam):ℂ)) •
          physicalProfile m (x lam) (θ+α)) s-
        (if s=1 then survivingCoefficient m z (weylPhase α)*(lam:ℂ)^m*
          (weylPhase θ)^(-(m:ℤ)) else 0)‖ ≤ R*|lam|^(m+1) := by
  have hm0 : 0<m := by obtain ⟨j,hj⟩ := hm; omega
  have hneg := negative_residual_asymptotic hz (Complex.exp_ne_zero _)
    (weylPhase_noIntegerResonance hα) m hm hres x hx0 hxa hxe
  have hpos := positive_residual_asymptotic hz (Complex.exp_ne_zero _)
    (weylPhase_noIntegerResonance hα) m hm0 hres x hx0 hxa hxe
  obtain ⟨Cneg,hCneg,hnb⟩ := hneg.exists_pos
  obtain ⟨Cpos,hCpos,hpb⟩ := hpos.exists_pos
  have hevent : ∀ᶠ lam in nhds 0, ∀ (θ : ℝ) (s : Fin 2),
      ‖(boundaryNumerator lam (phaseCenter m hm0 z (x lam)) θ*ᵥphysicalProfile m (x lam) θ-
          (z*(amplitude m hm0 (x lam):ℂ)) • physicalProfile m (x lam) (θ+α)) s-
        (if s=1 then survivingCoefficient m z (weylPhase α)*(lam:ℂ)^m*
          (weylPhase θ)^(-(m:ℤ)) else 0)‖ ≤ (Cneg+Cpos)*|lam|^(m+1) := by
    filter_upwards [hxe,hnb.bound,hpb.bound] with lam hfinite hn hp
    intro θ s
    rw [physicalProfile_residual_two_modes m hm z α lam θ (x lam) hfinite s]
    fin_cases s
    · simp only [Fin.zero_eta,Fin.mk_one,show (0:Fin 2)≠1 by decide,if_false,sub_zero,
        norm_mul,norm_zpow,weylPhase_norm,one_zpow,mul_one]
      simp only [norm_mul,Real.norm_eq_abs,abs_pow] at hp
      exact hp.trans (mul_le_mul_of_nonneg_right (show Cpos≤Cneg+Cpos by linarith)
        (pow_nonneg (abs_nonneg _) _))
    · simp only [Fin.mk_one,if_true,← sub_mul,norm_mul,norm_zpow,weylPhase_norm,one_zpow,mul_one]
      simp only [Real.norm_eq_abs,abs_pow] at hn
      exact hn.trans (mul_le_mul_of_nonneg_right (show Cneg≤Cneg+Cpos by linarith)
        (pow_nonneg (abs_nonneg _) _))
  obtain ⟨δ,hδ,hδb⟩ := Metric.eventually_nhds_iff.mp hevent
  refine ⟨Cneg+Cpos,δ,by positivity,hδ,?_⟩
  intro lam θ s hlam
  exact hδb (by simpa only [Real.dist_eq,sub_zero] using hlam) θ s

theorem analytic_branch_uniform_bounds {z : ℂ} (hz : z≠0) {α : ℝ}
    (hα : Irrational α) (m : ℕ) (hm : Odd m) (hres : z^2=(weylPhase α)^m)
    (x : ℝ→Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0,
      finiteSystem m (by obtain ⟨j,hj⟩ := hm; omega) z (weylPhase α) lam (x lam)=0) :
    ∃ A P R δ : ℝ, 0<A ∧ 0<P ∧ 0<R ∧ 0<δ ∧
      ∀lam:ℝ, 0≤lam → lam<δ →
        |amplitude m (by obtain ⟨j,hj⟩ := hm; omega) (x lam)-1|≤A*lam ∧
        (∀θ:ℝ, ‖physicalProfile m (x lam) θ 0-1‖≤P*lam ∧
          ‖physicalProfile m (x lam) θ 1‖≤P*lam) ∧
        ∀(θ:ℝ)(s:Fin 2),
          ‖(boundaryNumerator lam (phaseCenter m (by obtain ⟨j,hj⟩ := hm; omega) z (x lam)) θ*ᵥ
              physicalProfile m (x lam) θ-
            (z*(amplitude m (by obtain ⟨j,hj⟩ := hm; omega) (x lam):ℂ)) •
              physicalProfile m (x lam) (θ+α)) s-
            (if s=1 then survivingCoefficient m z (weylPhase α)*(lam:ℂ)^m*
              (weylPhase θ)^(-(m:ℤ)) else 0)‖≤R*lam^(m+1) := by
  have hm0 : 0<m := by obtain ⟨j,hj⟩ := hm; omega
  have ho : x =O[nhds (0:ℝ)] (fun lam => lam) := by
    simpa only [hx0,sub_zero] using hxa.differentiableAt.isBigO_sub
  obtain ⟨A,hA,hAb⟩ := ho.exists_pos
  obtain ⟨ε,hε,hεb⟩ := Metric.eventually_nhds_iff.mp hAb.bound
  obtain ⟨R,δ,hR,hδ,hr⟩ := analytic_physical_residual_bound hz hα m hm hres x hx0 hxa hxe
  have hp : 0≤profileBoundConstant m := by unfold profileBoundConstant; positivity
  refine ⟨A,profileBoundConstant m*A+1,R,min ε δ,hA,by positivity,hR,lt_min hε hδ,?_⟩
  intro lam hlam hl
  have hεlam : dist lam 0<ε := by
    simpa only [Real.dist_eq,sub_zero,abs_of_nonneg hlam] using
      hl.trans_le (min_le_left ε δ)
  have hx : ‖x lam‖≤A*lam := by
    simpa only [Real.norm_eq_abs,abs_of_nonneg hlam] using hεb hεlam
  refine ⟨?_,?_,?_⟩
  · calc
      _ = |(x lam (zeroMode m hm0)).re| := by simp [amplitude]
      _ ≤ ‖x lam (zeroMode m hm0)‖ := Complex.abs_re_le_norm _
      _ ≤ ‖x lam‖ := norm_le_pi_norm _ _
      _ ≤ A*lam := hx
  · intro θ
    have hb (s:Fin 2) := (physicalProfile_near_e1 m hm0 (x lam) θ s).trans
      (mul_le_mul_of_nonneg_left hx hp)
    have hh : profileBoundConstant m*(A*lam)≤(profileBoundConstant m*A+1)*lam := by
      nlinarith
    constructor
    · simpa only [ite_true] using (hb 0).trans hh
    · simpa only [show (1:Fin 2)≠0 by decide,ite_false,sub_zero] using (hb 1).trans hh
  · intro θ s
    simpa only [abs_of_nonneg hlam] using hr lam θ s
      (by rw [abs_of_nonneg hlam]; exact hl.trans_le (min_le_right ε δ))

theorem boundary_profile_data {z : ℂ} (hz : z≠0) {α : ℝ}
    (hα : Irrational α) (m : ℕ) (hm : Odd m) (hres : z^2=(weylPhase α)^m) :
    ∃x:ℝ→Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      (∀ᶠ lam in nhds 0,
        finiteSystem m (by obtain ⟨j,hj⟩ := hm; omega) z (weylPhase α) lam (x lam)=0) ∧
      ((fun lam => x lam (zeroMode m (by obtain ⟨j,hj⟩ := hm; omega)))
        =O[nhds (0:ℝ)] (fun lam => lam^2)) ∧
      survivingCoefficient m z (weylPhase α)≠0 ∧
      ∃ A P R δ : ℝ, 0<A ∧ 0<P ∧ 0<R ∧ 0<δ ∧
        ∀lam:ℝ, 0≤lam → lam<δ →
          |amplitude m (by obtain ⟨j,hj⟩ := hm; omega) (x lam)-1|≤A*lam ∧
          (∀θ:ℝ, ‖physicalProfile m (x lam) θ 0-1‖≤P*lam ∧
            ‖physicalProfile m (x lam) θ 1‖≤P*lam) ∧
          ∀(θ:ℝ)(s:Fin 2),
            ‖(boundaryNumerator lam (phaseCenter m (by obtain ⟨j,hj⟩ := hm; omega) z (x lam)) θ*ᵥ
                physicalProfile m (x lam) θ-
              (z*(amplitude m (by obtain ⟨j,hj⟩ := hm; omega) (x lam):ℂ)) •
                physicalProfile m (x lam) (θ+α)) s-
              (if s=1 then survivingCoefficient m z (weylPhase α)*(lam:ℂ)^m*
                (weylPhase θ)^(-(m:ℤ)) else 0)‖≤R*lam^(m+1) := by
  have hm0 : 0<m := by obtain ⟨j,hj⟩ := hm; omega
  obtain ⟨x,hx0,hxa,hxe,hc,_⟩ := analytic_branch_residual_estimates hz
    (Complex.exp_ne_zero _) (weylPhase_noIntegerResonance hα) m hm hres
  exact ⟨x,hx0,hxa,hxe,branch_zero_mode_order hz m hm0 x hx0 hxa hxe,hc,
    analytic_branch_uniform_bounds hz hα m hm hres x hx0 hxa hxe⟩

end PaperUAMO.BoundaryProfileData

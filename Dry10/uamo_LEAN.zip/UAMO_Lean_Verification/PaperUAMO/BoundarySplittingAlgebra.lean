import PaperUAMO.InteriorRealNormalForm
import UAMODraft.BoundaryRealIdentification

noncomputable section
namespace PaperUAMO.BoundarySplitting
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open PaperUAMO.FreeElliptic PaperUAMO.InteriorNormalForm

def freeAngle (α:ℝ) (m:ℕ) (ell:ℤ) : ℝ := Real.pi*((m:ℝ)*α+(ell:ℝ))

theorem phaseCenter_exp (m:ℕ) (hm : 0 < m) (α:ℝ) (ell:ℤ) (x:Variables m) :
    phaseCenter m hm (resonantPhase α m ell) x=
      Complex.exp (((freeAngle α m ell+(x (zeroMode m hm)).im:ℝ):ℂ)*Complex.I) := by
  change Complex.exp ((freeAngle α m ell:ℂ)*Complex.I)*
    Complex.exp (Complex.I*((x (zeroMode m hm)).im:ℂ))=_
  rw [←Complex.exp_add]
  congr 1
  push_cast
  ring

theorem boundary_complexify {lam:ℝ} (hlam:0≤lam) (hlam1:lam<1)
    {z:ℂ} (hz:‖z‖=1) (y:ℝ) :
    complexify (boundaryRealTransfer lam z y)=boundarySzego lam z y := by
  rw [complexify,boundaryRealTransfer_map hlam hlam1 hz,
    ←cayley_eq_seed,←cayleyInverse_eq_seed]
  simp only [Matrix.mul_assoc]
  rw [←Matrix.mul_assoc cayleyMatrix,cayley_mul_inverse,one_mul]
  simp only [cayley_mul_inverse,Matrix.mul_one]

theorem boundary_normalized_intertwining (m:ℕ) (hm : 0 < m) (α:ℝ) (ell:ℤ)
    {lam:ℝ} (hlam:0≤lam) (hlam1:lam<1) (x:Variables m) (y:ℝ) :
    complexify (realTransfer 1 lam (freeAngle α m ell+(x (zeroMode m hm)).im)
      (2*Real.pi*y))*complexify (1:RMat)=complexify (1:RMat)*
      ((realTransferDenominator lam (2*Real.pi*y):ℂ)⁻¹ •
        boundaryNumerator lam (phaseCenter m hm (resonantPhase α m ell) x) y) := by
  rw [complexify_one,mul_one,one_mul,←UAMODraft.SeedLabel.boundaryRealTransfer_exp,
    ←phaseCenter_exp]
  exact boundary_complexify hlam hlam1 (by rw [phaseCenter_norm,resonantPhase_norm]) y

theorem exists_resonance_index (α t₀:ℝ) (m:ℕ)
    (hres:Complex.exp (((2*t₀:ℝ):ℂ)*Complex.I)=
      Complex.exp (((2*Real.pi*(m:ℝ)*α:ℝ):ℂ)*Complex.I)) :
    ∃ell:ℤ,t₀=freeAngle α m ell := by
  obtain ⟨ell,h⟩:=Complex.exp_eq_exp_iff_exists_int.mp hres
  have hi:=congrArg Complex.im h
  simp only [Complex.add_im,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,
    Complex.I_im,Complex.I_re,Complex.intCast_re,Complex.intCast_im,mul_one,mul_zero,zero_mul,add_zero,zero_add] at hi
  norm_num [Complex.mul_re] at hi
  refine ⟨ell,?_⟩
  unfold freeAngle
  linear_combination hi/2

theorem resonance_sign (α:ℝ) (m:ℕ) (ell:ℤ) :
    Real.cos (freeAngle α m ell-Real.pi*(m:ℝ)*α)=liftSign ell := by
  have he : freeAngle α m ell-Real.pi*(m:ℝ)*α=(ell:ℝ)*Real.pi := by
    unfold freeAngle
    ring
  rw [he]
  simpa [liftSign] using Real.cos_int_mul_pi_sub 0 ell

theorem resonance_sign_exp (α:ℝ) (m:ℕ) (ell:ℤ) :
    (liftSign ell:ℂ)=Complex.exp
      (((freeAngle α m ell-Real.pi*(m:ℝ)*α:ℝ):ℂ)*Complex.I) := by
  have he : (((freeAngle α m ell-Real.pi*(m:ℝ)*α:ℝ):ℂ)*Complex.I)=
      (ell:ℂ)*(Real.pi*Complex.I) := by unfold freeAngle;push_cast;ring
  rw [he,Complex.exp_int_mul,Complex.exp_pi_mul_I]
  simp [liftSign]

end PaperUAMO.BoundarySplitting

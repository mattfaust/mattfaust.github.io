import PaperUAMO.BoundaryProfileData
import PaperUAMO.BoundaryProfileAnalytic
import PaperUAMO.BoundarySplittingAlgebra
import PaperUAMO.InteriorSplittingApplication
import PaperUAMO.InteriorFrameProximity

set_option maxHeartbeats 800000
noncomputable section
namespace PaperUAMO.BoundarySplitting
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed Filter Asymptotics
open PaperUAMO.FreeElliptic PaperUAMO.InteriorNormalForm PaperUAMO.InteriorFrame
open PaperUAMO.SymmetricSplitting
open scoped Topology Matrix.L2OpNorm

theorem boundary_resonant_splitting_indexed {α:ℝ} (hα:Irrational α)
    (m:ℕ) (hm:Odd m) (ell:ℤ) :
    ∃t:ℝ→ℝ,∃B:ℝ → ℝ → RMat,∃H:RMat,∃C ε:ℝ,
      AnalyticAt ℝ t 0 ∧ t 0=freeAngle α m ell ∧
      ((fun lam=>t lam-freeAngle α m ell) =O[𝓝 (0:ℝ)] (fun lam=>lam^2)) ∧
      H.transpose=H ∧ Matrix.trace H=0 ∧ 0<‖H‖ ∧ 0<C ∧ 0<ε ∧
      ∀lam,0≤lam → lam<ε → lam<1 ∧
        (∀y i j,AnalyticAt ℝ (fun z=>B lam z i j) y) ∧
        (∀y i j,AnalyticAt ℝ (fun u=>B u y i j) lam) ∧
        (∀y,(B lam y).det=1) ∧
        (∀y,B lam (y+1)=((-1:ℝ)^(m:ℤ)) • B lam y) ∧
        HasProjectiveDegree (B lam) (m:ℤ) ∧
        (∀y,‖B lam y-rotation (Real.pi*(m:ℝ)*y)‖≤C*lam) ∧
        (∀y,‖liftSign ell • ((B lam (y+α))⁻¹*
          realTransfer 1 lam (t lam) (2*Real.pi*y)*B lam y)-1-lam^m • H‖≤
            C*lam^(m+1)) := by
  have hm0 : 0 < m := by obtain ⟨j,hj⟩:=hm;omega
  let z:=resonantPhase α m ell
  let c:=survivingCoefficient m z (weylPhase α)
  obtain ⟨x,hx0,hxa,_hxe,hcenter,hc,A₀,P,R,δ,hA₀,hP,hR,hδ,hdata⟩:=
    BoundaryProfileData.boundary_profile_data (resonantPhase_ne_zero α m ell) hα m hm
      (resonantPhase_square α m ell)
  let t:=fun lam=>freeAngle α m ell+(x lam (zeroMode m hm0)).im
  let v:=fun lam=>physicalProfile m (x lam)
  let B:=fun lam=>pairedRealFrame m (v lam)
  let M:ℝ → ℝ → Mat:=fun lam y=>boundaryNumerator lam (phaseCenter m hm0 z (x lam)) y
  let A:ℝ → ℝ → RMat:=fun lam y=>realTransfer 1 lam (t lam) (2*Real.pi*y)
  let η:=c*halfPhase m α
  let H:=signedLeading (liftSign ell) η
  have hη:η≠0:=mul_ne_zero hc (Complex.exp_ne_zero _)
  have hxphase:AnalyticAt ℝ (fun lam=>(x lam (zeroMode m hm0)).im) 0 :=
    (Complex.imCLM.analyticAt _).comp
      ((ContinuousLinearMap.proj (zeroMode m hm0):Variables m→L[ℝ]ℂ).analyticAt (x 0) |>.comp hxa)
  have ht:AnalyticAt ℝ t 0:=analyticAt_const.add hxphase
  have ht0:t 0=freeAngle α m ell := by simp [t,hx0]
  have horder:((fun lam=>t lam-freeAngle α m ell) =O[𝓝 (0:ℝ)] (fun lam=>lam^2)) := by
    have hi:((fun lam=>(x lam (zeroMode m hm0)).im) =O[𝓝 (0:ℝ)] (fun lam=>lam^2)):=
      (isBigO_of_le _ fun lam=>Complex.abs_im_le_norm _).trans hcenter
    simpa only [t,add_sub_cancel_left] using hi
  have hzunit (lam:ℝ):‖phaseCenter m hm0 z (x lam)‖=1 := by
    rw [phaseCenter_norm,resonantPhase_norm]
  let δ₀:=min δ 1
  have hδ₀:0<δ₀:=lt_min hδ zero_lt_one
  have hd (lam:ℝ) (hl:0≤lam) (hs:lam<δ₀):=
    hdata lam hl (hs.trans_le (min_le_left _ _))
  have hM:∀lam,0≤lam → lam<δ₀ → ∀y,
      M lam y 1 1=star (M lam y 0 0) ∧ M lam y 0 1=star (M lam y 1 0) := by
    intro lam _hl _hs y
    dsimp only [M]
    rw [boundaryNumerator_conjugateMatrix lam (hzunit lam)]
    simp [conjugateMatrix]
  have hSU:∀lam,0≤lam → lam<δ₀ → ∀y,
      SU11Form ((realTransferDenominator lam (2*Real.pi*y):ℂ)⁻¹ • M lam y) := by
    intro lam hl hs y
    exact boundarySzego_SU11 hl (hs.trans_le (min_le_right _ _)) (hzunit lam) y
  obtain ⟨K,εn,hK,hεn,hεnδ,hn⟩:=paired_profile_normal_form m hm0 α (liftSign ell) z c
    (liftSign_abs ell) (resonantPhase_eq_halfPhase α m ell) M v
    (fun lam=>amplitude m hm0 (x lam)) A₀ P R δ₀ hA₀.le hP.le hR hδ₀
    hM hSU (fun lam hl hs=>(hd lam hl hs).2.1)
    (fun lam hl hs=>(hd lam hl hs).1) (fun lam hl hs=>(hd lam hl hs).2.2)
  obtain ⟨δa,hδa,hδab⟩:=Metric.eventually_nhds_iff.mp
    (BoundaryProfileAnalytic.pairedRealFrame_analytic_eventually hm0 x hx0 hxa)
  let ε:=min εn (min δa (1/(8*(P+1))))
  let C:=max (64*P) (8*K)
  have hε:0<ε:=by dsimp [ε];positivity
  have hH:=signedLeading_data (liftSign_abs ell) η
  refine ⟨t,B,H,C,ε,ht,ht0,horder,hH.1,hH.2.1,?_,?_,hε,?_⟩
  · rw [show ‖H‖=‖η‖ from hH.2.2]
    exact norm_pos_iff.mpr hη
  · exact lt_of_lt_of_le (by positivity : 0<64*P) (le_max_left _ _)
  · intro lam hlam hsmall
    have hln:lam<εn:=hsmall.trans_le (min_le_left _ _)
    have hla:lam<δa:=hsmall.trans_le ((min_le_right _ _).trans (min_le_left _ _))
    have hlp:lam<1/(8*(P+1)):=hsmall.trans_le ((min_le_right _ _).trans (min_le_right _ _))
    have hpe:P*lam<1/4 := by
      have hh:=(lt_div_iff₀ (show 0<8*(P+1) by positivity)).mp hlp
      nlinarith
    obtain ⟨hlam1,hpos,_hsu,herror⟩:=hn lam hlam hln
    have hv:= (hd lam hlam (hln.trans_le hεnδ)).2.1
    have hdist:dist lam 0<δa:=by simpa only [Real.dist_eq,sub_zero,abs_of_nonneg hlam] using hla
    have hanalytic:=hδab hdist
    obtain ⟨_hcont,hdet,hanti,hdeg⟩:=pairedRealFrame_degree_data m (v lam)
      (continuous_physicalProfile m hm0 (x lam)) (physicalProfile_periodic m (x lam))
      (mul_nonneg hP.le hlam) hpe (fun y=>(hv y).1) (fun y=>(hv y).2)
    refine ⟨hlam1,(fun y=>(hanalytic y).2.1),(fun y=>(hanalytic y).2.2),hdet,hanti,hdeg,?_,?_⟩
    · intro y
      have hh:=pairedRealFrame_proximity m (v lam) (mul_nonneg hP.le hlam) hpe.le hv y
      apply hh.trans
      have hmul:=mul_le_mul_of_nonneg_right (show 64*P≤C from le_max_left _ _) hlam
      simpa only [mul_assoc] using hmul
    · intro y
      have hinter:∀y,complexify (A lam y)*complexify (1:RMat)=complexify (1:RMat)*
        ((realTransferDenominator lam (2*Real.pi*y):ℂ)⁻¹ • M lam y):=
          boundary_normalized_intertwining m hm0 α ell hlam hlam1 (x lam)
      have hh:=real_normal_error_bound (1:RMat) m α (liftSign ell) lam (A lam) (M lam)
        (v lam) η (liftSign_abs ell) (by simp) hpos hinter
        (mul_nonneg hK.le (pow_nonneg hlam _)) herror y
      change ‖liftSign ell • ((B lam (y+α))⁻¹*A lam y*B lam y)-1-lam^m • H‖≤_
      have hh':‖liftSign ell • ((B lam (y+α))⁻¹*A lam y*B lam y)-1-lam^m • H‖≤8*(K*lam^(m+1)) := by
        simpa only [realNormalError,physicalFrame,one_mul] using hh
      apply hh'.trans
      have hmul:=mul_le_mul_of_nonneg_right (show 8*K≤C from le_max_right _ _)
        (pow_nonneg hlam (m+1))
      simpa only [mul_assoc] using hmul

theorem boundary_resonant_splitting {α:ℝ} (hα:Irrational α)
    (m:ℕ) (hm:Odd m) (t₀:ℝ)
    (hres:Complex.exp (((2*t₀:ℝ):ℂ)*Complex.I)=
      Complex.exp (((2*Real.pi*(m:ℝ)*α:ℝ):ℂ)*Complex.I)) :
    let σ:=Real.cos (t₀-Real.pi*(m:ℝ)*α)
    (σ:ℂ)=Complex.exp (((t₀-Real.pi*(m:ℝ)*α:ℝ):ℂ)*Complex.I) ∧ |σ|=1 ∧
    ∃t:ℝ→ℝ,∃B:ℝ → ℝ → RMat,∃H:RMat,∃C ε:ℝ,
      AnalyticAt ℝ t 0 ∧ t 0=t₀ ∧
      ((fun lam=>t lam-t₀) =O[𝓝 (0:ℝ)] (fun lam=>lam^2)) ∧
      H.transpose=H ∧ Matrix.trace H=0 ∧ 0<‖H‖ ∧ 0<C ∧ 0<ε ∧
      ∀lam,0≤lam → lam<ε → lam<1 ∧
        (∀y i j,AnalyticAt ℝ (fun z=>B lam z i j) y) ∧
        (∀y i j,AnalyticAt ℝ (fun u=>B u y i j) lam) ∧
        (∀y,(B lam y).det=1) ∧
        (∀y,B lam (y+1)=((-1:ℝ)^(m:ℤ)) • B lam y) ∧
        HasProjectiveDegree (B lam) (m:ℤ) ∧
        (∀y,‖B lam y-rotation (Real.pi*(m:ℝ)*y)‖≤C*lam) ∧
        (∀y,‖σ • ((B lam (y+α))⁻¹*
          realTransfer 1 lam (t lam) (2*Real.pi*y)*B lam y)-1-lam^m • H‖≤
            C*lam^(m+1)) := by
  obtain ⟨ell,rfl⟩:=exists_resonance_index α t₀ m hres
  dsimp only
  rw [resonance_sign]
  exact ⟨resonance_sign_exp α m ell,liftSign_abs ell,
    boundary_resonant_splitting_indexed hα m hm ell⟩

end PaperUAMO.BoundarySplitting

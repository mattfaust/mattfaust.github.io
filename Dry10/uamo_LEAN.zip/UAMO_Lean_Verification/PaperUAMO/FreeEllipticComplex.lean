import PaperUAMO.FreeEllipticFrame
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

noncomputable section
namespace PaperUAMO.FreeElliptic
open Matrix UAMO Filter
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

abbrev CMat := Matrix (Fin 2) (Fin 2) ℂ
abbrev RMat := Matrix (Fin 2) (Fin 2) ℝ

def cayleyMatrix : CMat := !![1,Complex.I;1,-Complex.I]
def cayleyInverse : CMat := (1/2:ℂ) • !![1,1;-Complex.I,Complex.I]

theorem cayley_inverse_mul : cayleyInverse*cayleyMatrix=1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [cayleyInverse,cayleyMatrix,Matrix.mul_apply,Fin.sum_univ_two]
  all_goals ring_nf
  all_goals norm_num [Complex.I_sq]

theorem cayley_mul_inverse : cayleyMatrix*cayleyInverse=1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [cayleyInverse,cayleyMatrix,Matrix.mul_apply,Fin.sum_univ_two]
  all_goals ring_nf
  all_goals norm_num [Complex.I_sq]

def complexify (M : RMat) : CMat := cayleyMatrix*M.map Complex.ofReal*cayleyInverse

theorem complexify_mul (M N : RMat) : complexify (M*N)=complexify M*complexify N := by
  have hm : (M*N).map Complex.ofReal=M.map Complex.ofReal*N.map Complex.ofReal :=
    Matrix.map_mul (f:=Complex.ofRealHom)
  rw [complexify,hm]
  simp only [complexify,Matrix.mul_assoc]
  rw [←Matrix.mul_assoc cayleyInverse,cayley_inverse_mul,one_mul]

theorem complexify_add (M N : RMat) : complexify (M+N)=complexify M+complexify N := by
  simp [complexify,Matrix.map_add,Matrix.mul_add,Matrix.add_mul]

theorem complexify_smul (c : ℝ) (M : RMat) :
    complexify (c • M)=(c:ℂ) • complexify M := by
  have hm : (c • M).map Complex.ofReal=(c:ℂ) • M.map Complex.ofReal := by
    ext i j
    simp
  simp only [complexify,hm,mul_smul_comm,smul_mul_assoc]

theorem complexify_det (M : RMat) : (complexify M).det=(M.det:ℂ) := by
  have hc := congrArg Matrix.det cayley_mul_inverse
  rw [Matrix.det_mul,Matrix.det_one] at hc
  have hm : (M.map Complex.ofReal).det=(M.det:ℂ) :=
    (RingHom.map_det Complex.ofRealHom M).symm
  rw [complexify,Matrix.det_mul,Matrix.det_mul,hm]
  change cayleyMatrix.det*(M.det:ℂ)*cayleyInverse.det=(M.det:ℂ)
  calc
    _ = (cayleyMatrix.det*cayleyInverse.det)*(M.det:ℂ) := by ring
    _ = _ := by rw [hc,one_mul]

def phase (t : ℝ) : ℂ := Complex.exp ((t:ℂ)*Complex.I)
def phaseDiagonal (t : ℝ) : CMat := !![phase t,0;0,(phase t)⁻¹]

theorem phase_eq (t : ℝ) : phase t=(Real.cos t:ℂ)+Complex.I*(Real.sin t:ℂ) := by
  simpa [phase,mul_comm] using Complex.exp_mul_I (t:ℂ)

theorem phase_inv_eq (t : ℝ) : (phase t)⁻¹=(Real.cos t:ℂ)-Complex.I*(Real.sin t:ℂ) := by
  rw [phase,←Complex.exp_neg]
  have he : -((t:ℂ)*Complex.I)=((-t:ℝ):ℂ)*Complex.I := by push_cast;ring
  rw [he,←phase,phase_eq]
  simp only [Real.cos_neg,Real.sin_neg,Complex.ofReal_neg]
  ring

theorem phase_ne_zero (t : ℝ) : phase t≠0 := Complex.exp_ne_zero _

theorem complexify_rotation (t : ℝ) : complexify (rotation t)=phaseDiagonal t := by
  rw [phaseDiagonal,phase_inv_eq,phase_eq]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [complexify,cayleyMatrix,cayleyInverse,rotation,Matrix.mul_apply,Matrix.vecMul,
      dotProduct,Matrix.map_apply,Fin.sum_univ_two]
  all_goals ring_nf
  all_goals norm_num [Complex.I_sq]
  all_goals ring

def velocity (a θ : ℝ) : ℝ := complementaryCoupling a/(coupling a*Real.sin θ)
def offDiagonal (a θ : ℝ) : ℂ := -(coupling a:ℂ)⁻¹-Complex.I*(velocity a θ:ℂ)*Real.cos θ
def rawPerturbation (a θ : ℝ) : CMat := complexify (perturbation a θ)

theorem coupling_reciprocal {a : ℝ} (ha : 0<a) :
    (a+a⁻¹)/2=(coupling a)⁻¹ ∧ (a⁻¹-a)/2=complementaryCoupling a/coupling a := by
  have ha0 := ha.ne'
  unfold coupling complementaryCoupling
  constructor <;> field_simp <;> ring

theorem rawPerturbation_entries (a θ : ℝ) :
    rawPerturbation a θ=
      !![((a⁻¹-a)/2:ℝ)-Complex.I*(velocity a θ:ℂ)*Real.cos θ,
          -((a+a⁻¹)/2:ℝ)+Complex.I*(velocity a θ:ℂ)*Real.cos θ;
        -((a+a⁻¹)/2:ℝ)-Complex.I*(velocity a θ:ℂ)*Real.cos θ,
          ((a⁻¹-a)/2:ℝ)+Complex.I*(velocity a θ:ℂ)*Real.cos θ] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [rawPerturbation,complexify,cayleyMatrix,cayleyInverse,perturbation,
      velocity,Matrix.mul_apply,Matrix.vecMul,dotProduct,Matrix.map_apply,
      Fin.sum_univ_two,div_eq_mul_inv,_root_.mul_inv_rev]
  all_goals ring_nf
  all_goals norm_num [Complex.I_sq]

theorem rawPerturbation_eq {a θ : ℝ} (ha : 0<a) (hs : Real.sin θ≠0) :
    rawPerturbation a θ=
      !![-Complex.I*(velocity a θ:ℂ)*phase θ,star (offDiagonal a θ);
        offDiagonal a θ,Complex.I*(velocity a θ:ℂ)*(phase θ)⁻¹] := by
  have he := (coupling_pos ha).ne'
  have hm : velocity a θ*Real.sin θ=complementaryCoupling a/coupling a := by
    unfold velocity
    field_simp
    ring
  rw [rawPerturbation_entries,(coupling_reciprocal ha).1,(coupling_reciprocal ha).2,
    ←hm,phase_inv_eq,phase_eq]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [offDiagonal,Complex.ofReal_mul,Complex.star_def]
  all_goals ring_nf
  all_goals try norm_num [Complex.I_sq]
  all_goals simp only [←Complex.ofReal_cos,Complex.conj_ofReal,true_or]

def amplitude (a θ : ℝ) : ℝ := Real.sqrt (1+velocity a θ^2)

theorem amplitude_pos (a θ : ℝ) : 0<amplitude a θ := by
  unfold amplitude
  positivity

theorem velocity_ne_zero {a θ : ℝ} (ha : 0<a) (ha1 : a<1)
    (hs : Real.sin θ≠0) : velocity a θ≠0 := by
  unfold velocity complementaryCoupling
  apply div_ne_zero
  · apply div_ne_zero
    · nlinarith [sq_nonneg a]
    · positivity
  · exact mul_ne_zero (coupling_pos ha).ne' hs

theorem offDiagonal_norm {a θ : ℝ} (ha : 0<a) (hs : Real.sin θ≠0) :
    ‖offDiagonal a θ‖=amplitude a θ := by
  have he := (coupling_pos ha).ne'
  have hm : velocity a θ*Real.sin θ=complementaryCoupling a/coupling a := by
    unfold velocity
    field_simp
    ring
  have hrec : (complementaryCoupling a/coupling a)^2+1=(coupling a)⁻¹^2 := by
    have hu := coupling_square_identity a
    field_simp
    nlinarith [hu]
  have htrig : velocity a θ^2*(Real.sin θ^2+Real.cos θ^2)=velocity a θ^2 := by
    rw [Real.sin_sq_add_cos_sq,mul_one]
  have hsq : ‖offDiagonal a θ‖^2=1+velocity a θ^2 := by
    rw [Complex.sq_norm]
    simp only [offDiagonal,Complex.normSq_apply,Complex.sub_re,Complex.neg_re,
      Complex.inv_re,Complex.ofReal_re,Complex.mul_re,Complex.I_re,Complex.I_im,
      Complex.ofReal_im,Complex.mul_im,Complex.sub_im,Complex.neg_im,Complex.inv_im]
    simp [Complex.normSq_ofReal]
    have hh := congrArg (fun r:ℝ=>r^2) hm
    simp only [mul_pow] at hh
    nlinarith [hh,hrec,htrig]
  have hγ : amplitude a θ^2=1+velocity a θ^2 := by
    unfold amplitude
    exact Real.sq_sqrt (by positivity)
  exact (sq_eq_sq₀ (norm_nonneg _) (amplitude_pos a θ).le).mp (hsq.trans hγ.symm)

def normalizingAngle (a θ : ℝ) : ℝ := -(offDiagonal a θ).arg/2

theorem phase_neg (t : ℝ) : phase (-t)=(phase t)⁻¹ := by
  simp only [phase,Complex.ofReal_neg,neg_mul,Complex.exp_neg]

theorem phase_mul (s t : ℝ) : phase s*phase t=phase (s+t) := by
  simp only [phase,Complex.ofReal_add,add_mul,Complex.exp_add]

theorem phase_star (t : ℝ) : star (phase t)=(phase t)⁻¹ := by
  rw [phase_inv_eq,phase_eq]
  simp only [Complex.star_def,map_add,map_mul,Complex.conj_I,Complex.conj_ofReal]
  ring

theorem phaseDiagonal_det (t : ℝ) : (phaseDiagonal t).det=1 := by
  simp [phaseDiagonal,Matrix.det_fin_two_of,phase_ne_zero]

theorem phaseDiagonal_inverse_mul (t : ℝ) : phaseDiagonal (-t)*phaseDiagonal t=1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [phaseDiagonal,phase_neg,Matrix.mul_apply,Fin.sum_univ_two,phase_ne_zero]

theorem phaseDiagonal_commute (s t : ℝ) : phaseDiagonal s*phaseDiagonal t=
    phaseDiagonal t*phaseDiagonal s := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [phaseDiagonal,Matrix.mul_apply,Fin.sum_univ_two,mul_comm]

theorem offDiagonal_normalized {a θ : ℝ} (ha : 0<a) (hs : Real.sin θ≠0) :
    phase (normalizingAngle a θ)^2*offDiagonal a θ=(amplitude a θ:ℂ) := by
  rw [pow_two,phase_mul]
  have ht : normalizingAngle a θ+normalizingAngle a θ= -(offDiagonal a θ).arg := by
    unfold normalizingAngle
    ring
  rw [ht,phase_neg]
  have hpolar : (‖offDiagonal a θ‖:ℂ)*phase (offDiagonal a θ).arg=offDiagonal a θ :=
    Complex.norm_mul_exp_arg_mul_I _
  calc
    _ = (phase (offDiagonal a θ).arg)⁻¹*((‖offDiagonal a θ‖:ℂ)*phase (offDiagonal a θ).arg) := by rw [hpolar]
    _ = (‖offDiagonal a θ‖:ℂ) := by field_simp [phase_ne_zero]
    _ = _ := by rw [offDiagonal_norm ha hs]

def normalizedPerturbation (a θ h : ℝ) : CMat :=
  phaseDiagonal (-normalizingAngle a θ)*rawPerturbation a (θ+h)*phaseDiagonal (normalizingAngle a θ)

theorem normalizedPerturbation_zero {a θ : ℝ} (ha : 0<a) (hs : Real.sin θ≠0) :
    normalizedPerturbation a θ 0=
      !![-Complex.I*(velocity a θ:ℂ)*phase θ,(amplitude a θ:ℂ);
        (amplitude a θ:ℂ),Complex.I*(velocity a θ:ℂ)*(phase θ)⁻¹] := by
  have hlo := offDiagonal_normalized ha hs
  have hup := congrArg star hlo
  simp only [StarMul.star_mul,star_pow,phase_star] at hup
  have hreal : star (amplitude a θ:ℂ)=(amplitude a θ:ℂ) := by simp
  rw [hreal] at hup
  unfold normalizedPerturbation
  rw [add_zero,rawPerturbation_eq ha hs]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [phaseDiagonal,phase_neg,Matrix.mul_apply,Fin.sum_univ_two]
  · field_simp [phase_ne_zero]
  · calc
      _ = star (offDiagonal a θ)*(phase (normalizingAngle a θ))⁻¹^2 := by
        simp only [Complex.star_def]
        ring
      _ = _ := hup
  · calc
      _ = phase (normalizingAngle a θ)^2*offDiagonal a θ := by ring
      _ = _ := hlo
  · field_simp [phase_ne_zero]
    ring

end PaperUAMO.FreeElliptic

import PaperUAMO.FreeEllipticComplex

noncomputable section
namespace PaperUAMO.FreeElliptic
open Matrix UAMO Filter
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

theorem analyticAt_CMat_mul {F G : ℝ → CMat} {t : ℝ}
    (hF : AnalyticAt ℝ F t) (hG : AnalyticAt ℝ G t) :
    AnalyticAt ℝ (fun h=>F h*G h) t := by
  apply AnalyticAt.pi
  intro i
  apply AnalyticAt.pi
  intro j
  have hf (i j : Fin 2) : AnalyticAt ℝ (fun h=>F h i j) t :=
    (analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hF i)) j
  have hg (i j : Fin 2) : AnalyticAt ℝ (fun h=>G h i j) t :=
    (analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hG i)) j
  simpa only [Matrix.mul_apply,Fin.sum_univ_two] using
    ((hf i 0).mul (hg 0 j)).add ((hf i 1).mul (hg 1 j))

theorem analyticAt_complexify {F : ℝ → RMat} {t : ℝ}
    (hF : AnalyticAt ℝ F t) : AnalyticAt ℝ (fun h=>complexify (F h)) t := by
  have hm : AnalyticAt ℝ (fun h=>(F h).map Complex.ofReal) t := by
    apply AnalyticAt.pi
    intro i
    apply AnalyticAt.pi
    intro j
    exact (Complex.ofRealCLM.analyticAt _).comp
      ((analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hF i)) j)
  exact analyticAt_CMat_mul (analyticAt_CMat_mul analyticAt_const hm) analyticAt_const

theorem perturbation_analytic {a θ : ℝ} (ha : 0<a) (hs : Real.sin θ≠0) :
    AnalyticAt ℝ (fun h=>perturbation a (θ+h)) 0 := by
  have hn : ContDiffAt ℝ ⊤ (fun h:ℝ=>Real.sin (θ+h)) 0 :=
    (contDiffAt_const.add contDiffAt_id).sin
  have hc : ContDiffAt ℝ ⊤ (fun h:ℝ=>Real.cos (θ+h)) 0 :=
    (contDiffAt_const.add contDiffAt_id).cos
  have he := (coupling_pos ha).ne'
  apply ContDiffAt.analyticAt
  apply contDiffAt_pi.mpr
  intro i
  apply contDiffAt_pi.mpr
  intro j
  fin_cases i <;> fin_cases j
  · exact contDiffAt_const
  · exact (contDiffAt_const.mul hc).div (contDiffAt_const.mul hn)
      (by simpa using mul_ne_zero he hs)
  · exact contDiffAt_const
  · exact contDiffAt_const

theorem normalizedPerturbation_analytic {a θ : ℝ} (ha : 0<a) (hs : Real.sin θ≠0) :
    AnalyticAt ℝ (normalizedPerturbation a θ) 0 :=
  analyticAt_CMat_mul
    (analyticAt_CMat_mul analyticAt_const (analyticAt_complexify (perturbation_analytic ha hs)))
    analyticAt_const

def complexFrame (a θ h : ℝ) : CMat :=
  complexify (freeFrame a (θ+h) (spectralAngle (coupling a) θ h))*
    phaseDiagonal (normalizingAngle a θ)

theorem complexFrame_det_eventually {a θ : ℝ} (ha : 0<a) (he1 : coupling a<1)
    (hs : Real.sin θ≠0) : ∀ᶠ h in 𝓝 (0:ℝ),(complexFrame a θ h).det=1 := by
  filter_upwards [freeFrame_valid_eventually ha he1 hs] with h hh
  simp only [complexFrame,Matrix.det_mul,complexify_det,phaseDiagonal_det,hh.1,
    Complex.ofReal_one,mul_one]

theorem complexFrame_intertwining_eventually {a θ : ℝ} (ha : 0<a)
    (he1 : coupling a<1) (hs : Real.sin θ≠0) :
    ∀ᶠ h in 𝓝 (0:ℝ),∀lam x,
      complexify (realTransferNumerator a lam (spectralAngle (coupling a) θ h) x)*
          complexFrame a θ h =
        complexFrame a θ h*(phaseDiagonal (θ+h)+
          ((lam*Real.sin x:ℝ):ℂ) • normalizedPerturbation a θ h) := by
  filter_upwards [freeFrame_valid_eventually ha he1 hs] with h hh lam x
  have heq := congrArg complexify (hh.2 lam x)
  rw [complexify_mul,complexify_mul,complexify_add,complexify_smul,
    complexify_rotation] at heq
  have hP := phaseDiagonal_inverse_mul (-(normalizingAngle a θ))
  simp only [neg_neg] at hP
  dsimp only [complexFrame,normalizedPerturbation,rawPerturbation]
  calc
    _ = (complexify (realTransferNumerator a lam (spectralAngle (coupling a) θ h) x)*
          complexify (freeFrame a (θ+h) (spectralAngle (coupling a) θ h)))*
            phaseDiagonal (normalizingAngle a θ) := by rw [Matrix.mul_assoc]
    _ = (complexify (freeFrame a (θ+h) (spectralAngle (coupling a) θ h))*
          (phaseDiagonal (θ+h)+((lam*Real.sin x:ℝ):ℂ) • complexify (perturbation a (θ+h))))*
            phaseDiagonal (normalizingAngle a θ) := by rw [heq]
    _ = _ := by
      simp only [Matrix.mul_add,Matrix.add_mul,mul_smul_comm,smul_mul_assoc]
      apply congrArg₂ (fun X Y : CMat=>X+Y)
      · rw [Matrix.mul_assoc,phaseDiagonal_commute (θ+h),←Matrix.mul_assoc]
      · apply congrArg (fun X : CMat=>((lam*Real.sin x:ℝ):ℂ) • X)
        simp only [←Matrix.mul_assoc]
        rw [Matrix.mul_assoc _ (phaseDiagonal (normalizingAngle a θ)),hP,mul_one]

theorem complexFrame_eq_real_rotation (a θ h : ℝ) :
    complexFrame a θ h=complexify
      (freeFrame a (θ+h) (spectralAngle (coupling a) θ h)*rotation (normalizingAngle a θ)) := by
  rw [complexify_mul,complexify_rotation]
  rfl

theorem complexFrame_conjugates_eventually {a θ : ℝ} (ha : 0<a)
    (he1 : coupling a<1) (hs : Real.sin θ≠0) :
    ∀ᶠ h in 𝓝 (0:ℝ),(complexFrame a θ h).det=1 ∧ ∀lam x,
      (complexFrame a θ h)⁻¹*
          complexify (realTransferNumerator a lam (spectralAngle (coupling a) θ h) x)*
            complexFrame a θ h =
        phaseDiagonal (θ+h)+((lam*Real.sin x:ℝ):ℂ) • normalizedPerturbation a θ h := by
  filter_upwards [complexFrame_det_eventually ha he1 hs,
    complexFrame_intertwining_eventually ha he1 hs] with h hd heq
  refine ⟨hd,?_⟩
  intro lam x
  rw [Matrix.mul_assoc,heq,←Matrix.mul_assoc,
    Matrix.nonsing_inv_mul _ (by rw [hd];exact isUnit_one),one_mul]

end PaperUAMO.FreeElliptic

import PaperUAMO.FreeEllipticPhase
import UAMO.Basic
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.Analysis.Matrix

noncomputable section
namespace PaperUAMO.FreeElliptic
open Matrix Filter
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

def frameScale (a θ t : ℝ) : ℝ := Real.sqrt (a*Real.sin θ/Real.sin t)

def freeFrame (a θ t : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![frameScale a θ t, -frameScale a θ t*UAMO.complementaryCoupling a*Real.cos θ/Real.sin θ;
     0, (frameScale a θ t)⁻¹]

def rotation (θ : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![Real.cos θ,-Real.sin θ;Real.sin θ,Real.cos θ]

def perturbation (a θ : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![-a,2*UAMO.complementaryCoupling a*Real.cos θ/(UAMO.coupling a*Real.sin θ);
     0,a⁻¹]

theorem frameScale_pos {a θ t : ℝ} (ha : 0<a) (hs : 0<Real.sin θ/Real.sin t) :
    0<frameScale a θ t := by
  unfold frameScale
  apply Real.sqrt_pos.mpr
  simpa [mul_div_assoc] using mul_pos ha hs

theorem frameScale_sq {a θ t : ℝ} (ha : 0<a) (hs : 0<Real.sin θ/Real.sin t) :
    frameScale a θ t ^ 2 = a*Real.sin θ/Real.sin t := by
  apply Real.sq_sqrt
  simpa [mul_div_assoc] using (mul_pos ha hs).le

theorem freeFrame_det {a θ t : ℝ} (ha : 0<a) (hs : 0<Real.sin θ/Real.sin t) :
    (freeFrame a θ t).det=1 := by
  simp [freeFrame,Matrix.det_fin_two_of,(frameScale_pos ha hs).ne']

theorem freeFrame_intertwines {a θ t : ℝ} (ha : 0<a)
    (hs : 0<Real.sin θ/Real.sin t)
    (hc : Real.cos t=UAMO.coupling a*Real.cos θ) (x : ℝ) :
    UAMO.realTransferNumerator a 0 t x * freeFrame a θ t =
      freeFrame a θ t * rotation θ := by
  have ha0 := ha.ne'
  have hsθ : Real.sin θ≠0 := by intro h; simp [h] at hs
  have hst : Real.sin t≠0 := by intro h; simp [h] at hs
  have hr := (frameScale_pos ha hs).ne'
  have hr2 := frameScale_sq ha hs
  have hr2' : frameScale a θ t ^ 2 * Real.sin t = a*Real.sin θ :=
    (eq_div_iff hst).mp hr2
  have hc1 : a*Real.cos t=(1-UAMO.complementaryCoupling a)*Real.cos θ := by
    rw [hc];unfold UAMO.coupling UAMO.complementaryCoupling;field_simp;ring
  have hc2 : a⁻¹*Real.cos t=(1+UAMO.complementaryCoupling a)*Real.cos θ := by
    rw [hc];unfold UAMO.coupling UAMO.complementaryCoupling;field_simp;ring
  have hst2 : Real.sin t^2=Real.sin θ^2+
      UAMO.complementaryCoupling a^2*Real.cos θ^2 := by
    have hunit := UAMO.coupling_square_identity a
    have ht := Real.sin_sq_add_cos_sq t
    have hθ := Real.sin_sq_add_cos_sq θ
    rw [hc] at ht
    nlinarith [sq_nonneg (Real.cos θ)]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp only [freeFrame,rotation,UAMO.realTransferNumerator,Matrix.mul_apply,
      Fin.sum_univ_two,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.head_cons,
      Matrix.head_fin_const,zero_mul,mul_zero,add_zero,zero_add,sub_zero,add_zero]
  · rw [hc1]
    field_simp
    ring
  · rw [hc1]
    field_simp
    linear_combination Real.sin θ*Real.sin t*hr2' - frameScale a θ t^2*Real.sin θ*hst2
  · field_simp
    nlinarith [hr2']
  · rw [hc2]
    field_simp
    linear_combination -frameScale a θ t*UAMO.complementaryCoupling a*Real.cos θ*hr2'

theorem freeFrame_perturbation {a θ t : ℝ} (ha : 0<a)
    (hs : 0<Real.sin θ/Real.sin t) :
    !![-a,0;0,a⁻¹] * freeFrame a θ t =
      freeFrame a θ t * perturbation a θ := by
  have ha0 := ha.ne'
  have hsθ : Real.sin θ≠0 := by intro h; simp [h] at hs
  have hr := (frameScale_pos ha hs).ne'
  have hc : UAMO.coupling a≠0 := (UAMO.coupling_pos ha).ne'
  have hden : 1+a^2≠0 := by positivity
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [freeFrame,perturbation,Matrix.mul_apply,Fin.sum_univ_two]
  all_goals try ring
  unfold UAMO.coupling UAMO.complementaryCoupling
  field_simp
  ring

theorem freeFrame_full_intertwining {a θ t : ℝ} (ha : 0<a)
    (hs : 0<Real.sin θ/Real.sin t)
    (hc : Real.cos t=UAMO.coupling a*Real.cos θ) (lam x : ℝ) :
    UAMO.realTransferNumerator a lam t x * freeFrame a θ t =
      freeFrame a θ t * (rotation θ + (lam*Real.sin x) • perturbation a θ) := by
  have hdecomp : UAMO.realTransferNumerator a lam t x =
      UAMO.realTransferNumerator a 0 t x + (lam*Real.sin x) • !![-a,0;0,a⁻¹] := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [UAMO.realTransferNumerator] <;> ring
  rw [hdecomp,add_mul,smul_mul_assoc,freeFrame_intertwines ha hs hc,
    freeFrame_perturbation ha hs,mul_add,mul_smul_comm]

theorem freeFrame_analytic {a θ : ℝ} (ha : 0<a)
    (he1 : UAMO.coupling a<1) (hs : Real.sin θ≠0) :
    AnalyticAt ℝ (fun h => freeFrame a (θ+h) (spectralAngle (UAMO.coupling a) θ h)) 0 := by
  have he0 := UAMO.coupling_pos ha
  have ht := (spectralAngle_analytic (θ := θ) he0 he1 (0:ℝ)).contDiffAt (n := (⊤ : WithTop ℕ∞))
  have hn : ContDiffAt ℝ ⊤ (fun h : ℝ => Real.sin (θ+h)) 0 :=
    (contDiffAt_const.add contDiffAt_id).sin
  have hden := sin_spectralAngle_ne_zero he0 he1 θ 0
  have hrat := ((contDiffAt_const (c := a)).mul hn).div ht.sin hden
  have hratpos : 0<a*Real.sin (θ+0)/Real.sin (spectralAngle (UAMO.coupling a) θ 0) := by
    simpa [mul_div_assoc] using mul_pos ha (sin_ratio_pos he0 he1 hs)
  have hr : ContDiffAt ℝ ⊤
      (fun h => frameScale a (θ+h) (spectralAngle (UAMO.coupling a) θ h)) 0 :=
    hrat.sqrt hratpos.ne'
  have hr0 : frameScale a (θ+0) (spectralAngle (UAMO.coupling a) θ 0) ≠ 0 :=
    (frameScale_pos ha (by simpa using sin_ratio_pos he0 he1 hs)).ne'
  apply ContDiffAt.analyticAt
  apply contDiffAt_pi.mpr
  intro i
  apply contDiffAt_pi.mpr
  intro j
  fin_cases i <;> fin_cases j
  · exact hr
  · exact ((hr.neg.mul contDiffAt_const).mul
      (contDiffAt_const.add contDiffAt_id).cos).div hn (by simpa using hs)
  · exact contDiffAt_const
  · exact hr.inv hr0

theorem freeFrame_valid_eventually {a θ : ℝ} (ha : 0<a)
    (he1 : UAMO.coupling a<1) (hs : Real.sin θ≠0) :
    ∀ᶠ h : ℝ in 𝓝 0,
      (freeFrame a (θ+h) (spectralAngle (UAMO.coupling a) θ h)).det=1 ∧
      ∀ lam x : ℝ,
      UAMO.realTransferNumerator a lam (spectralAngle (UAMO.coupling a) θ h) x *
        freeFrame a (θ+h) (spectralAngle (UAMO.coupling a) θ h) =
      freeFrame a (θ+h) (spectralAngle (UAMO.coupling a) θ h) *
        (rotation (θ+h) + (lam*Real.sin x) • perturbation a (θ+h)) := by
  have he0 := UAMO.coupling_pos ha
  have ht := (spectralAngle_analytic (θ := θ) he0 he1 (0:ℝ)).continuousAt
  have hn : ContinuousAt (fun h : ℝ => Real.sin (θ+h)) 0 :=
    Real.continuous_sin.continuousAt.comp (continuousAt_const.add continuousAt_id)
  have hratio := hn.div (Real.continuous_sin.continuousAt.comp ht)
    (sin_spectralAngle_ne_zero he0 he1 θ 0)
  have hpos : 0 < Real.sin (θ+0)/Real.sin (spectralAngle (UAMO.coupling a) θ 0) :=
    by simpa using sin_ratio_pos he0 he1 hs
  filter_upwards [hratio.eventually (isOpen_Ioi.mem_nhds hpos)] with h hh
  refine ⟨freeFrame_det ha hh,?_⟩
  intro lam x
  exact freeFrame_full_intertwining ha hh (cos_spectralAngle he0 he1 θ h) lam x

end PaperUAMO.FreeElliptic

import Mathlib.Analysis.SpecialFunctions.Trigonometric.InverseDeriv
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Analytic.Basic
import Mathlib.Tactic

noncomputable section
namespace PaperUAMO.FreeElliptic
open scoped Topology

def orientation (θ : ℝ) : ℝ := if 0 < Real.sin θ then 1 else -1

def spectralAngle (ell θ h : ℝ) : ℝ :=
  orientation θ * Real.arccos (ell * Real.cos (θ+h))

theorem abs_coupled_cos_lt_one {ell : ℝ} (h0 : 0 < ell) (h1 : ell < 1) (φ : ℝ) :
    |ell * Real.cos φ| < 1 := by
  rw [abs_mul, abs_of_pos h0]
  exact (mul_le_of_le_one_right h0.le (Real.abs_cos_le_one φ)).trans_lt h1

theorem spectralAngle_analytic {ell θ : ℝ} (h0 : 0 < ell) (h1 : ell < 1) (h : ℝ) :
    AnalyticAt ℝ (spectralAngle ell θ) h := by
  have hc := abs_lt.mp (abs_coupled_cos_lt_one h0 h1 (θ+h))
  have hcos : ContDiffAt ℝ ⊤ (fun x : ℝ => ell * Real.cos (θ+x)) h :=
    contDiffAt_const.mul ((contDiffAt_const.add contDiffAt_id).cos)
  exact (contDiffAt_const.mul ((Real.contDiffAt_arccos
    (by linarith : ell * Real.cos (θ+h) ≠ -1)
    (by linarith : ell * Real.cos (θ+h) ≠ 1)).comp h hcos)).analyticAt

theorem cos_spectralAngle {ell : ℝ} (h0 : 0 < ell) (h1 : ell < 1) (θ h : ℝ) :
    Real.cos (spectralAngle ell θ h) = ell * Real.cos (θ+h) := by
  have hc := abs_lt.mp (abs_coupled_cos_lt_one h0 h1 (θ+h))
  simp only [spectralAngle, orientation]
  split_ifs <;> simp [Real.cos_arccos hc.1.le hc.2.le]

theorem sin_spectralAngle {ell : ℝ} (h0 : 0 < ell) (h1 : ell < 1) (θ h : ℝ) :
    Real.sin (spectralAngle ell θ h) =
      orientation θ * Real.sqrt (1-(ell*Real.cos (θ+h))^2) := by
  have hc := abs_lt.mp (abs_coupled_cos_lt_one h0 h1 (θ+h))
  simp only [spectralAngle,orientation]
  split_ifs <;> simp [Real.sin_arccos]

theorem sin_spectralAngle_ne_zero {ell : ℝ} (h0 : 0 < ell) (h1 : ell < 1) (θ h : ℝ) :
    Real.sin (spectralAngle ell θ h) ≠ 0 := by
  rw [sin_spectralAngle h0 h1]
  apply mul_ne_zero
  · unfold orientation; split_ifs <;> norm_num
  · apply Real.sqrt_ne_zero'.mpr
    have hc := abs_lt.mp (abs_coupled_cos_lt_one h0 h1 (θ+h))
    nlinarith

theorem sin_ratio_pos {ell θ : ℝ} (h0 : 0 < ell) (h1 : ell < 1)
    (hs : Real.sin θ ≠ 0) :
    0 < Real.sin θ / Real.sin (spectralAngle ell θ 0) := by
  rw [sin_spectralAngle h0 h1]
  have hp : 0 < Real.sqrt (1-(ell*Real.cos (θ+0))^2) := by
    apply Real.sqrt_pos.mpr
    have hc := abs_lt.mp (abs_coupled_cos_lt_one h0 h1 (θ+0))
    nlinarith
  unfold orientation
  split_ifs with h
  · exact div_pos h (by simpa using hp)
  · exact div_pos_of_neg_of_neg (lt_of_le_of_ne (le_of_not_gt h) hs)
      (by simpa using neg_neg_of_pos hp)

end PaperUAMO.FreeElliptic

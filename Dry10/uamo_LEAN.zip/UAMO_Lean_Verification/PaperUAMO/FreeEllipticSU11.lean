import PaperUAMO.FreeEllipticConjugacy
import PaperUAMO.InteriorFourierEvaluation
import UAMO.BoundarySeedNormalForm

noncomputable section
namespace PaperUAMO.FreeElliptic
open Matrix UAMO UAMO.BoundarySeed Filter
open scoped Topology

theorem complexify_one : complexify (1:RMat)=1 := by
  simp [complexify,cayley_mul_inverse]

theorem complexify_inv {M : RMat} (hd : M.det=1) :
    complexify M⁻¹=(complexify M)⁻¹ := by
  symm
  apply Matrix.inv_eq_left_inv
  rw [←complexify_mul,Matrix.nonsing_inv_mul _ (by rw [hd];exact isUnit_one),complexify_one]

theorem complexify_conjugate_entries (M : RMat) :
    (complexify M) 1 1=star ((complexify M) 0 0) ∧
    (complexify M) 0 1=star ((complexify M) 1 0) := by
  constructor <;>
    simp [complexify,cayleyMatrix,cayleyInverse,Matrix.mul_apply,Matrix.vecMul,dotProduct,
      Matrix.map_apply,Matrix.of_apply,Fin.sum_univ_two,Complex.star_def]

theorem complexify_SU11 {M : RMat} (hd : M.det=1) : SU11Form (complexify M) := by
  exact ⟨(complexify_conjugate_entries M).1,(complexify_conjugate_entries M).2,
    by rw [complexify_det,hd,Complex.ofReal_one]⟩

theorem physicalNumerator_eq_form (a θ lam h x : ℝ) :
    InteriorSeed.physicalNumerator (phase θ) (normalizedPerturbation a θ) lam h x =
      phaseDiagonal (θ+h)+((lam*Real.sin (2*Real.pi*x):ℝ):ℂ) • normalizedPerturbation a θ h := by
  have hp : phase (θ+h)=phase θ*Complex.exp (Complex.I*h) := by
    simp only [phase,←Complex.exp_add]
    congr 1
    push_cast
    ring
  have hn : (phase (θ+h))⁻¹=(phase θ)⁻¹*Complex.exp (-Complex.I*h) := by
    simp only [phase,←Complex.exp_neg,←Complex.exp_add]
    congr 1
    push_cast
    ring
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [InteriorSeed.physicalNumerator,InteriorSeed.phaseDiagonal,phaseDiagonal,hp,hn]
  rw [Complex.exp_neg]
  ring

def realGauge (a θ h : ℝ) : RMat :=
  freeFrame a (θ+h) (spectralAngle (coupling a) θ h)*rotation (normalizingAngle a θ)

theorem realGauge_det_eventually {a θ : ℝ} (ha : 0<a) (he1 : coupling a<1)
    (hs : Real.sin θ≠0) : ∀ᶠ h in 𝓝 (0:ℝ),(realGauge a θ h).det=1 := by
  filter_upwards [complexFrame_det_eventually ha he1 hs] with h hh
  rw [complexFrame_eq_real_rotation,complexify_det] at hh
  exact_mod_cast hh

theorem physicalNumerator_real_conjugate_eventually {a θ : ℝ} (ha : 0<a)
    (he1 : coupling a<1) (hs : Real.sin θ≠0) :
    ∀ᶠ h in 𝓝 (0:ℝ),(realGauge a θ h).det=1 ∧ ∀lam x,
      InteriorSeed.physicalNumerator (phase θ) (normalizedPerturbation a θ) lam h x =
      complexify ((realGauge a θ h)⁻¹*
        realTransferNumerator a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x)*
          realGauge a θ h) := by
  filter_upwards [realGauge_det_eventually ha he1 hs,
    complexFrame_conjugates_eventually ha he1 hs] with h hd hh
  refine ⟨hd,?_⟩
  intro lam x
  rw [physicalNumerator_eq_form,←hh.2 lam (2*Real.pi*x),
    complexFrame_eq_real_rotation]
  change (complexify (realGauge a θ h))⁻¹*
      complexify (realTransferNumerator a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x))*
      complexify (realGauge a θ h) = _
  rw [complexify_mul,complexify_mul,complexify_inv hd]

theorem physicalNumerator_SU11_eventually {a θ : ℝ} (ha : 0<a)
    (he1 : coupling a<1) (hs : Real.sin θ≠0) :
    ∀ᶠ h in 𝓝 (0:ℝ),∀lam,0≤lam → lam<1 → ∀x,
      let M := InteriorSeed.physicalNumerator (phase θ) (normalizedPerturbation a θ) lam h x
      M 1 1=star (M 0 0) ∧ M 0 1=star (M 1 0) ∧
      SU11Form (((realTransferDenominator lam (2*Real.pi*x):ℝ):ℂ)⁻¹ • M) := by
  filter_upwards [physicalNumerator_real_conjugate_eventually ha he1 hs]
    with h hh lam hlam hlam1 x
  dsimp only
  rw [hh.2]
  let G := realGauge a θ h
  let A := realTransferNumerator a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x)
  refine ⟨(complexify_conjugate_entries _).1,(complexify_conjugate_entries _).2,?_⟩
  have he : ((realTransferDenominator lam (2*Real.pi*x):ℝ):ℂ)⁻¹ •
      complexify (G⁻¹*A*G) =
      complexify (G⁻¹*realTransfer a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x)*G) := by
    rw [realTransfer,mul_smul_comm,smul_mul_assoc,complexify_smul,Complex.ofReal_inv]
  rw [he]
  apply complexify_SU11
  rw [Matrix.det_mul,Matrix.det_mul,Matrix.det_nonsing_inv,
    realTransfer_det ha.ne' hlam hlam1]
  change Ring.inverse ((realGauge a θ h).det)*1*(realGauge a θ h).det=1
  rw [hh.1]
  simp

end PaperUAMO.FreeElliptic

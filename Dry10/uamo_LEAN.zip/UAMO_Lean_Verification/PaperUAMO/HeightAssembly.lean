import PaperUAMO.InteriorSeedSymmetries
import UAMODraft.PublicBoundary
import UAMODraft.DraftGapContinuation
import UAMO.PhysicalAxisOpenGaps
import UAMO.PhysicalOpenGapDuality
import UAMO.PhysicalCouplingGapLabels

noncomputable section
namespace PaperUAMO.HeightAssembly
open UAMO UAMOSimple Set MeasureTheory
open PaperUAMO.InteriorSeedSymmetries

variable (seeds : ∀ a (ha : 0<a) (ha1 : a<1), PositiveInteriorSeeds a ha ha1)
include seeds

theorem interior_small_seed_to_height {a r α : ℝ}
    (ha : 0 < a) (ha1 : a < 1) (hr : 0 < r) (hra : r ≤ a)
    (hα : Irrational α) (m ell : ℤ) (hm : m ≠ 0) :
    OpenDOSGapLabel a r α ha.le ha1.le hr.le (hra.trans ha1.le)
      (uamoGapLabel α m ell) := by
  obtain ⟨ε, hε, hεa, hseed⟩ := seeds_all_signed_windings ha ha1 (seeds a ha ha1) α hα m
  let r₀ : ℝ := min (r / 2) (ε / 2)
  have hr₀ : 0 < r₀ := lt_min (half_pos hr) (half_pos hε)
  have hr₀r : r₀ < r := (min_le_left (r / 2) (ε / 2)).trans_lt (by linarith)
  have hr₀ε : r₀ < ε := (min_le_right (r / 2) (ε / 2)).trans_lt (by linarith)
  obtain ⟨hr₀1, hgap⟩ := hseed r₀ hr₀ hr₀ε
  exact UAMODraft.BoundaryAssembly.physical_gap_persists_by_height ha ha1.le hα
    hr₀ (hr₀ε.trans hεa) hr₀r.le hra m ell hm (hgap ell)

theorem interior_gap_by_finite_seeds_and_height {a r α : ℝ}
    (ha : 0 < a) (ha1 : a < 1) (hr : 0 < r) (hr1 : r < 1)
    (hα : Irrational α) (m ell : ℤ) :
    OpenDOSGapLabel a r α ha.le ha1.le hr.le hr1.le (uamoGapLabel α m ell) := by
  by_cases hm : m = 0
  · subst m
    exact (physical_axis_open_zero_winding_label ha ha1 hr.le hr1 hα ell).1
  by_cases hra : r ≤ a
  · exact interior_small_seed_to_height seeds ha ha1 hr hra hα m ell hm
  · have hmneg : -m ≠ 0 := neg_ne_zero.mpr hm
    have hd := interior_small_seed_to_height seeds hr hr1 ha (le_of_not_ge hra)
      hα.neg (-m) ell hmneg
    rw [uamoGapLabel_reverse_frequency, neg_neg] at hd
    exact (openDOSGapLabel_exchange_iff ha.le ha1.le hr.le hr1.le hα _).mpr hd

theorem physical_interior_by_finite_seeds_and_height {lam₁ lam₂ α : ℝ}
    (h₁ : 0 < lam₁) (h₁1 : lam₁ < 1) (h₂ : 0 < lam₂) (h₂1 : lam₂ < 1)
    (hα : Irrational α) (m ell : ℤ) :
    OpenPhysicalCouplingGapLabel lam₁ lam₂ α h₁.le h₁1.le h₂.le h₂1.le
      (uamoGapLabel α m ell) := by
  have ha : 0 < PhysicalWalk.stereographicParameter lam₁ := by
    unfold PhysicalWalk.stereographicParameter
    positivity
  have hr : 0 < PhysicalWalk.stereographicParameter lam₂ := by
    unfold PhysicalWalk.stereographicParameter
    positivity
  have ha1 : PhysicalWalk.stereographicParameter lam₁ < 1 := by
    unfold PhysicalWalk.stereographicParameter
    exact (div_le_self h₁.le (by linarith [Real.sqrt_nonneg (1-lam₁^2)])).trans_lt h₁1
  have hr1 : PhysicalWalk.stereographicParameter lam₂ < 1 := by
    unfold PhysicalWalk.stereographicParameter
    exact (div_le_self h₂.le (by linarith [Real.sqrt_nonneg (1-lam₂^2)])).trans_lt h₂1
  rw [openPhysicalCouplingGapLabel_iff]
  exact interior_gap_by_finite_seeds_and_height seeds ha ha1 hr hr1 hα m ell

theorem classification_from_seeds {lam₁ lam₂ α : ℝ}
    (h₁ : lam₁ ∈ Ioc (0 : ℝ) 1) (h₂ : lam₂ ∈ Ioc (0 : ℝ) 1)
    (hα : Irrational α) (m : ℤ) :
    ∀ label : AddCircle (1 : ℝ),
      (2 : ℕ) • label = (((m : ℝ) * α : ℝ) : AddCircle (1 : ℝ)) →
      ((∃ t δ : ℝ, 0 < δ ∧ ∀ s : ℝ, |s-t| < δ →
        (∀ θ : ℝ, Complex.exp ((s : ℂ) * Complex.I) ∉
          spectrum ℂ (walk lam₁ lam₂ α θ)) ∧
        ((dos lam₁ lam₂ α).real (arc s) : AddCircle (1 : ℝ)) = label) ↔
        (lam₁ < 1 ∧ lam₂ < 1) ∨ Odd m) := by
  intro label hlabel
  by_cases hi : lam₁ < 1 ∧ lam₂ < 1
  · constructor
    · intro _
      exact Or.inl hi
    · intro _
      obtain ⟨ell, rfl⟩ := UAMODraft.PublicAssembly.doubled_label_eq_gapLabel α m label hlabel
      change HasGap lam₁ lam₂ α (dos lam₁ lam₂ α) _
      apply (UAMODraft.PublicAssembly.public_gap_iff_physical lam₁ lam₂ α h₁ h₂ _).mpr
      exact physical_interior_by_finite_seeds_and_height seeds h₁.1 hi.1 h₂.1 hi.2 hα m ell
  · have hb : max lam₁ lam₂ = 1 := by
      apply le_antisymm (max_le h₁.2 h₂.2)
      by_cases hleft : lam₁ < 1
      · have hright : 1 ≤ lam₂ := le_of_not_gt (fun h => hi ⟨hleft, h⟩)
        exact hright.trans (le_max_right _ _)
      · exact (le_of_not_gt hleft).trans (le_max_left _ _)
    exact (UAMODraft.PublicAssembly.boundary_unitary_classification h₁ h₂ hb hα m label hlabel).trans
      ⟨Or.inr, fun h => h.resolve_left hi⟩

theorem noncritical_from_seeds {lam₁ lam₂ α : ℝ}
    (h₁ : lam₁ ∈ Ioo (0 : ℝ) 1) (h₂ : lam₂ ∈ Ioo (0 : ℝ) 1)
    (_hne : lam₁ ≠ lam₂) (hα : Irrational α) (m : ℤ) :
    ∀ label : AddCircle (1 : ℝ),
      (2 : ℕ) • label = (((m : ℝ) * α : ℝ) : AddCircle (1 : ℝ)) →
      HasGap lam₁ lam₂ α (dos lam₁ lam₂ α) label := by
  intro label hlabel
  obtain ⟨ell, rfl⟩ := UAMODraft.PublicAssembly.doubled_label_eq_gapLabel α m label hlabel
  apply (UAMODraft.PublicAssembly.public_gap_iff_physical lam₁ lam₂ α
    ⟨h₁.1, h₁.2.le⟩ ⟨h₂.1, h₂.2.le⟩ _).mpr
  exact physical_interior_by_finite_seeds_and_height seeds h₁.1 h₁.2 h₂.1 h₂.2 hα m ell

end PaperUAMO.HeightAssembly

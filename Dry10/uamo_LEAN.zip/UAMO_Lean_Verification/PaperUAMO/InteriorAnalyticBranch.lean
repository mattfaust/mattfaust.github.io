import PaperUAMO.InteriorFiniteSystem
import UAMODraft.AnalyticBranch

noncomputable section
set_option maxHeartbeats 1000000
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed
open scoped Topology BigOperators

def forcing (m : ℕ) (V₀ : SpinMatrix) (p : Mode m) : ℂ :=
  (2*Complex.I)⁻¹*∑ j : Fin 2, V₀ p.val.2 j *
    (baseCoefficient (p.val.1-1) j - baseCoefficient (p.val.1+1) j)

def coefficientDifferential (m : ℕ) (k : ℤ) (j : Fin 2) : Variables m →L[ℝ] ℂ :=
  if k=0 ∧ j=0 then 0 else
    if hp : k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ) ∧ ¬(k=-(m:ℤ) ∧ j=1) then
      ContinuousLinearMap.proj ⟨(k,j),hp⟩ else 0

theorem coefficient_hasFDerivAt (m : ℕ) (k : ℤ) (j : Fin 2) (x : Variables m) :
    HasFDerivAt (fun x : Variables m => coefficient m x k j)
      (coefficientDifferential m k j) x := by
  unfold coefficient coefficientDifferential
  split_ifs
  · exact hasFDerivAt_const _ _
  · exact (ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).hasFDerivAt
  · exact hasFDerivAt_const _ _

def parameterEvaluation (m : ℕ) (p : Mode m) : ParameterSpace m →L[ℝ] ℂ :=
  (ContinuousLinearMap.proj p).comp (ContinuousLinearMap.snd ℝ ℝ (Variables m))

def parameterComplex (m : ℕ) : ParameterSpace m →L[ℝ] ℂ :=
  Complex.ofRealCLM.comp (ContinuousLinearMap.fst ℝ ℝ (Variables m))

def fullDerivative (m : ℕ) (w q : ℂ) (V₀ : SpinMatrix) :
    ParameterSpace m →L[ℝ] Variables m :=
  ContinuousLinearMap.pi (fun p =>
    diagonal m w q p • parameterEvaluation m p + forcing m V₀ p • parameterComplex m)

theorem finiteSystem_hasFDerivAt (m : ℕ) (w q : ℂ) (V : ℝ → SpinMatrix)
    (hV : AnalyticAt ℝ V 0) :
    HasFDerivAt (fun p : ParameterSpace m => finiteSystem m w q V p.1 p.2)
      (fullDerivative m w q (V 0)) (0,0) := by
  let ev := parameterEvaluation m (zeroMode m)
  let im₀ := Complex.imCLM.comp ev
  let im := Complex.ofRealCLM.comp im₀
  let re := Complex.ofRealCLM.comp (Complex.reCLM.comp ev)
  have hi := im.hasFDerivAt (x := (0:ParameterSpace m))
  have hr := re.hasFDerivAt (x := (0:ParameterSpace m))
  have heplus : HasFDerivAt (fun p : ParameterSpace m =>
      w*Complex.exp (Complex.I*(p.2 (zeroMode m)).im))
      (w • (Complex.I • im)) (0,0) := by
    simpa [im,im₀,ev,parameterEvaluation,ContinuousLinearMap.comp_apply] using
      (hi.const_mul Complex.I).cexp.const_mul w
  have heminus : HasFDerivAt (fun p : ParameterSpace m =>
      w⁻¹*Complex.exp (-Complex.I*(p.2 (zeroMode m)).im))
      (w⁻¹ • ((-Complex.I) • im)) (0,0) := by
    simpa [im,im₀,ev,parameterEvaluation,ContinuousLinearMap.comp_apply] using
      (hi.const_mul (-Complex.I)).cexp.const_mul w⁻¹
  have hc (k : ℤ) (j : Fin 2) := (coefficient_hasFDerivAt m k j (0:Variables m)).comp (0,0)
    (ContinuousLinearMap.snd ℝ ℝ (Variables m)).hasFDerivAt
  apply hasFDerivAt_pi.mpr
  intro p
  let Dp := if p.val.2=0 then w • (Complex.I • im) else w⁻¹ • ((-Complex.I) • im)
  have hp : HasFDerivAt (fun y : ParameterSpace m =>
      if p.val.2=0 then w*Complex.exp (Complex.I*(y.2 (zeroMode m)).im)
      else w⁻¹*Complex.exp (-Complex.I*(y.2 (zeroMode m)).im)) Dp (0,0) := by
    dsimp only [Dp]
    split_ifs <;> assumption
  have hW : DifferentiableAt ℝ (fun y : ParameterSpace m =>
      ∑ j : Fin 2, V (y.2 (zeroMode m)).im p.val.2 j *
        (coefficient m y.2 (p.val.1-1) j-coefficient m y.2 (p.val.1+1) j)) (0,0) := by
    apply DifferentiableAt.sum
    intro j _
    have hv : DifferentiableAt ℝ (fun y : ParameterSpace m =>
        V (y.2 (zeroMode m)).im p.val.2 j) (0,0) := by
      have hv₀ := differentiableAt_pi.mp (differentiableAt_pi.mp hV.differentiableAt p.val.2) j
      exact hv₀.comp (0,0) im₀.differentiableAt
    exact hv.mul ((hc _ j).differentiableAt.sub (hc _ j).differentiableAt)
  have hA := hp.sub (((hasFDerivAt_const (1:ℂ) (0:ParameterSpace m)).sub hr).const_mul w |>.mul_const (q^p.val.1))
  have hB := ((parameterComplex m).hasFDerivAt (x := (0:ParameterSpace m))).const_mul ((2*Complex.I)⁻¹)
  have h := (hA.mul (hc p.val.1 p.val.2)).add (hB.mul hW.hasFDerivAt)
  convert h using 1
  apply ContinuousLinearMap.ext
  intro y
  by_cases hp₀ : p.val.1=0 ∧ p.val.2=0
  · have hpz : p=zeroMode m := Subtype.ext (Prod.ext hp₀.1 hp₀.2)
    subst p
    simp [fullDerivative,diagonal,parameterEvaluation,parameterComplex,forcing,baseCoefficient,
      coefficientDifferential,coefficient,zeroMode,Dp,im,im₀,re,ev,
      ContinuousLinearMap.comp_apply,smul_eq_mul]
    all_goals
      have hx := Complex.re_add_im (y.2 (zeroMode m))
      dsimp [zeroMode] at hx
      linear_combination -w*hx
  · simp [fullDerivative,diagonal,hp₀,parameterEvaluation,parameterComplex,forcing,
      coefficientDifferential,coefficient_base,baseCoefficient,p.property,Dp,im,im₀,re,ev,
      ContinuousLinearMap.comp_apply,smul_eq_mul,divisor,diagonalValue]
    split_ifs <;> ring_nf <;> simp

def graphEquiv (m : ℕ) (J : Variables m ≃L[ℝ] Variables m) (b : Variables m) :
    ParameterSpace m ≃L[ℝ] ParameterSpace m :=
  ({
    toFun := fun p => (p.1,J p.2+p.1 • b)
    invFun := fun p => (p.1,J.symm (p.2-p.1 • b))
    left_inv := by intro p; simp
    right_inv := by intro p; simp
    map_add' := by
      intro p q
      apply Prod.ext
      · rfl
      · simp only [Prod.fst_add,Prod.snd_add,map_add,add_smul]
        module
    map_smul' := by intro c p; apply Prod.ext <;> simp [smul_add,smul_smul]
  } : ParameterSpace m ≃ₗ[ℝ] ParameterSpace m).toContinuousLinearEquiv

theorem exact_finite_analytic_branch {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : AnalyticAt ℝ V 0) :
    ∃ x : ℝ → Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      (∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0) ∧
      (∀ᶠ p in nhds (0,(0:Variables m)), finiteSystem m w q V p.1 p.2=0 → p.2=x p.1) := by
  let J := finiteJacobianEquiv hw hq0 hq m hres
  let G := graphEquiv m J (forcing m (V 0))
  apply UAMODraft.OddSeed.analytic_implicit_graph
    (fun p : ParameterSpace m => finiteSystem m w q V p.1 p.2) 0
    (finiteSystem_base m w q V) (finiteSystem_analytic m w q V hV) G
  have hd := (ContinuousLinearMap.fst ℝ ℝ (Variables m)).hasFDerivAt.prodMk
    (finiteSystem_hasFDerivAt m w q V hV)
  apply Eq.trans hd.fderiv
  apply ContinuousLinearMap.ext
  intro p
  apply Prod.ext
  · rfl
  · funext k
    change diagonal m w q k*p.2 k+forcing m (V 0) k*(p.1:ℂ)=
      diagonal m w q k*p.2 k+p.1 • forcing m (V 0) k
    simp [Complex.real_smul,mul_comm]

end PaperUAMO.InteriorSeed

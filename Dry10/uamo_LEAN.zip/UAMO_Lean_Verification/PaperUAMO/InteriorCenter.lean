import PaperUAMO.InteriorOrders

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology BigOperators

theorem branch_zero_mode_order {w q : ℂ} (hw : w≠0) (m : ℕ)
    (V : ℝ → SpinMatrix) (hV : ContinuousAt V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0) :
    (fun lam => x lam (zeroMode m)) =O[nhds (0:ℝ)] (fun lam => lam^2) := by
  have hsum : (fun lam => ∑ j : Fin 2, V (x lam (zeroMode m)).im 0 j *
      (coefficient m (x lam) (-1) j-coefficient m (x lam) 1 j))
      =O[nhds (0:ℝ)] (fun lam => lam) := by
    apply IsBigO.sum
    intro j _
    have hminus := branch_coefficient_isBigO x hx0 hxa (-1) j (by simp)
    have hplus := branch_coefficient_isBigO x hx0 hxa 1 j (by simp)
    have hv := (branch_matrix_continuousAt x hx0 hxa.continuousAt V hV 0 j).isBigO_one ℝ
    simpa only [one_mul] using hv.mul (hminus.sub hplus)
  have hlam : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
    isBigO_of_le _ (fun lam => by simp)
  have hbound := (hlam.mul hsum).const_mul_left (-(2*Complex.I)⁻¹/w)
  have heq : ∀ᶠ (lam : ℝ) in nhds 0,
      (-(2*Complex.I)⁻¹/w)*((lam:ℂ)*
        ∑ j : Fin 2, V (x lam (zeroMode m)).im 0 j *
          (coefficient m (x lam) (-1) j-coefficient m (x lam) 1 j))=
        UAMODraft.OddSeed.zeroAdjustment (x lam (zeroMode m)) := by
    filter_upwards [hxe] with lam he
    have h := congrFun he (zeroMode m)
    have hc0 : coefficient m (x lam) 0 0=1 := by simp [coefficient]
    change (w*Complex.exp (Complex.I*(x lam (zeroMode m)).im)-
        w*(1-(x lam (zeroMode m)).re)*q^(0:ℤ))*coefficient m (x lam) 0 0+
        (2*Complex.I)⁻¹*(lam:ℂ)*∑ j : Fin 2,
          V (x lam (zeroMode m)).im 0 j *
            (coefficient m (x lam) (-1) j-coefficient m (x lam) 1 j)=0 at h
    simp only [hc0,zpow_zero,mul_one] at h
    rw [div_mul_eq_mul_div]
    apply (div_eq_iff hw).mpr
    unfold UAMODraft.OddSeed.zeroAdjustment
    linear_combination -h
  have hg : (fun lam => UAMODraft.OddSeed.zeroAdjustment (x lam (zeroMode m)))
      =O[nhds (0:ℝ)] (fun lam => lam^2) := by
    have hb := hbound.congr' heq EventuallyEq.rfl
    simpa only [pow_two] using hb
  have hxlim : Tendsto (fun lam => x lam (zeroMode m)) (nhds 0) (nhds 0) := by
    simpa only [Function.comp_def,hx0,Pi.zero_apply] using
      ((continuous_apply (zeroMode m)).continuousAt.comp hxa.continuousAt).tendsto
  exact (UAMODraft.OddSeed.zeroAdjustment_reverse_bound.comp_tendsto hxlim).trans hg

end PaperUAMO.InteriorSeed

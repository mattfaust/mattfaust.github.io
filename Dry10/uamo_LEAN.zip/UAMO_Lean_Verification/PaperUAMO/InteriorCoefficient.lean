import PaperUAMO.InteriorCoefficientRecurrence

noncomputable section
namespace PaperUAMO.InteriorCoefficient
open Complex

def coefficientVector (ξ : ℂ) (μ γ : ℝ) (m : ℕ) : ℕ → ℂ × ℂ
  | 0 => (1, 0)
  | n + 1 =>
      ((-I * μ * (coefficientVector ξ μ γ m n).1 +
          γ * (coefficientVector ξ μ γ m n).2) / (1 - ξ ^ (n + 1)),
       (γ * (coefficientVector ξ μ γ m n).1 +
          I * μ * (coefficientVector ξ μ γ m n).2) /
            (1 - ξ ^ (n + 1) / ξ ^ m))

def resonantCoefficient (ξ : ℂ) (μ γ : ℝ) (m : ℕ) : ℂ :=
    γ * (coefficientVector ξ μ γ m (m - 1)).1 +
      I * μ * (coefficientVector ξ μ γ m (m - 1)).2

theorem powers_injective (ξ : ℂ) (hξ : ξ ≠ 0)
    (hroot : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1) :
    Function.Injective (fun n : ℕ => ξ ^ n) := by
  have hlt : ∀ a b : ℕ, a < b → ξ ^ a ≠ ξ ^ b := by
    intro a b hab he
    have hd : ξ ^ (b - a) = 1 := by
      apply mul_right_cancel₀ (pow_ne_zero a hξ)
      rw [one_mul, ← pow_add, Nat.sub_add_cancel hab.le]
      exact he.symm
    exact hroot _ (Nat.sub_pos_of_lt hab) hd
  intro a b he
  apply le_antisymm
  · exact le_of_not_gt (fun h => hlt b a h he.symm)
  · exact le_of_not_gt (fun h => hlt a b h he)

theorem second_divisor_ne_zero (ξ : ℂ) (hξ : ξ ≠ 0)
    (hroot : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1) (m n : ℕ) (hn : n ≠ m) :
    1 - ξ ^ n / ξ ^ m ≠ 0 := by
  apply sub_ne_zero.mpr
  intro he
  have h := (div_eq_iff (pow_ne_zero m hξ)).mp he.symm
  rw [one_mul] at h
  exact hn (powers_injective ξ hξ hroot h)

theorem coefficientVector_first (ξ : ℂ) (μ γ : ℝ) (m n : ℕ)
    (hroot : ∀ k : ℕ, 0 < k → ξ ^ k ≠ 1) :
    (1 - ξ ^ (n + 1)) * (coefficientVector ξ μ γ m (n + 1)).1 =
      -I * μ * (coefficientVector ξ μ γ m n).1 +
        γ * (coefficientVector ξ μ γ m n).2 := by
  simp only [coefficientVector]
  exact mul_div_cancel₀ _ (sub_ne_zero.mpr (Ne.symm (hroot _ (by omega))))

theorem coefficientVector_second (ξ : ℂ) (μ γ : ℝ) (m n : ℕ)
    (hξ : ξ ≠ 0) (hroot : ∀ k : ℕ, 0 < k → ξ ^ k ≠ 1)
    (hn : n + 1 ≠ m) :
    (1 - ξ ^ (n + 1) / ξ ^ m) * (coefficientVector ξ μ γ m (n + 1)).2 =
      γ * (coefficientVector ξ μ γ m n).1 +
        I * μ * (coefficientVector ξ μ γ m n).2 := by
  simp only [coefficientVector]
  exact mul_div_cancel₀ _ (second_divisor_ne_zero ξ hξ hroot m (n + 1) hn)

theorem resonantCoefficient_ne_zero (ξ : ℂ) (μ γ : ℝ) (m : ℕ)
    (hξ : ‖ξ‖ = 1) (hroot : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1)
    (hm : 0 < m) (hμ : μ ≠ 0) (hγ : γ ^ 2 = 1 + μ ^ 2) :
    resonantCoefficient ξ μ γ m ≠ 0 := by
  intro hzero
  have hξ0 : ξ ≠ 0 := by intro h; simp [h] at hξ
  apply no_infinite_coupled_solution ξ μ γ m hξ hroot hm hμ hγ
    (fun n => (coefficientVector ξ μ γ m n).1)
    (fun n => (coefficientVector ξ μ γ m n).2) rfl rfl
  · exact fun n => coefficientVector_first ξ μ γ m n hroot
  · intro n
    by_cases hn : n + 1 = m
    · have hnm : n = m - 1 := by omega
      have hnum : γ * (coefficientVector ξ μ γ m n).1 +
          I * μ * (coefficientVector ξ μ γ m n).2 = 0 := by
        rw [hnm]
        exact hzero
      simp only [coefficientVector]
      rw [hnum, zero_div, mul_zero]
    · exact coefficientVector_second ξ μ γ m n hξ0 hroot hn

end PaperUAMO.InteriorCoefficient

import Mathlib.RingTheory.PowerSeries.Inverse
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic

noncomputable section
namespace PaperUAMO.InteriorCoefficient
open PowerSeries

abbrev Series := PowerSeries ℂ

def eulerCoeff (ξ : ℂ) : ℕ → ℂ
  | 0 => 1
  | n + 1 => eulerCoeff ξ n / (1 - ξ ^ (n + 1))

def eulerSeries (ξ : ℂ) : Series := PowerSeries.mk (eulerCoeff ξ)

@[simp] theorem eulerSeries_constant (ξ : ℂ) :
    constantCoeff ℂ (eulerSeries ξ) = 1 := by
  rw [← coeff_zero_eq_constantCoeff_apply]
  simp [eulerSeries, eulerCoeff]

theorem eulerSeries_rescale (ξ : ℂ)
    (hξ : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1) :
    rescale ξ (eulerSeries ξ) = (1 - X) * eulerSeries ξ := by
  ext n
  cases n with
  | zero => simp
  | succ n =>
      have hn : 1 - ξ ^ (n + 1) ≠ 0 := sub_ne_zero.mpr (Ne.symm (hξ _ (by omega)))
      rw [sub_mul, one_mul]
      simp only [map_sub, coeff_rescale, coeff_succ_X_mul, eulerSeries, coeff_mk,
        eulerCoeff]
      field_simp
      ring

def transformedEquation (ξ : ℂ) (μ : ℝ) (m : ℕ) (g : Series) : Series :=
    rescale ξ (rescale ξ g) -
      C ℂ ξ * (X * rescale ξ (rescale ξ g)) -
      C ℂ (1 + ξ ^ (m + 1)) * rescale ξ g -
      C ℂ (Complex.I * μ * ξ * (1 - ξ ^ m)) * (X * rescale ξ g) +
      C ℂ (ξ ^ (m + 1)) * g + C ℂ (ξ ^ (m + 1)) * (X * g)

def secondOrderEquation (ξ : ℂ) (μ : ℝ) (m : ℕ) (f : Series) : Series :=
    rescale ξ (rescale ξ f) -
      (C ℂ (1 + ξ ^ (m + 1)) +
        C ℂ (Complex.I * μ * ξ * (1 - ξ ^ m)) * X) * rescale ξ f +
      C ℂ (ξ ^ (m + 1)) * ((1 - X ^ 2) * f)

theorem rescale_C_complex (ξ c : ℂ) :
    rescale ξ (C ℂ c) = C ℂ c := by
  ext n
  cases n <;> simp [coeff_C]

theorem secondOrder_factorization (ξ : ℂ) (μ : ℝ) (m : ℕ)
    (hξ : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1) (g : Series) :
    secondOrderEquation ξ μ m (eulerSeries ξ * g) =
      eulerSeries ξ * (1 - X) * transformedEquation ξ μ m g := by
  have he := eulerSeries_rescale ξ hξ
  have hee : rescale ξ (rescale ξ (eulerSeries ξ)) =
      (1 - C ℂ ξ * X) * ((1 - X) * eulerSeries ξ) := by
    rw [he, map_mul, map_sub, map_one, rescale_X, he]
  simp only [secondOrderEquation, transformedEquation, map_mul, he, hee,
    map_sub, map_one, rescale_X]
  ring

def leadingCoeff (ξ : ℂ) (m n : ℕ) : ℂ :=
    (1 - ξ ^ (n + 1)) * (ξ ^ (m + 1) - ξ ^ (n + 1))

def couplingCoeff (ξ : ℂ) (μ : ℝ) (m n : ℕ) : ℂ :=
    ξ ^ (m + 1) - ξ ^ (2 * n + 1) -
      Complex.I * μ * ξ ^ (n + 1) * (1 - ξ ^ m)

theorem transformedEquation_coeff (ξ : ℂ) (μ : ℝ) (m n : ℕ) (g : Series) :
    coeff ℂ (n + 1) (transformedEquation ξ μ m g) =
      leadingCoeff ξ m n * coeff ℂ (n + 1) g +
      couplingCoeff ξ μ m n * coeff ℂ n g := by
  simp only [transformedEquation, map_add, map_sub, add_mul, sub_mul, coeff_C_mul,
    coeff_succ_X_mul, coeff_rescale, leadingCoeff, couplingCoeff, pow_add, pow_mul]
  ring

theorem divide_euler (ξ : ℂ) (f : Series)
    (hf : constantCoeff ℂ f = 1) :
    ∃ g : Series, constantCoeff ℂ g = 1 ∧ eulerSeries ξ * g = f := by
  let g := invOfUnit (eulerSeries ξ) (1 : ℂˣ) * f
  refine ⟨g, ?_, ?_⟩
  · simp [g, hf]
  · rw [← mul_assoc, mul_invOfUnit _ _ (by simp), one_mul]

theorem firstOrder_of_secondOrder (ξ : ℂ) (μ : ℝ) (m : ℕ)
    (hξ : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1) (f : Series)
    (hf : constantCoeff ℂ f = 1)
    (heq : secondOrderEquation ξ μ m f = 0) :
    ∃ g : ℕ → ℂ, g 0 = 1 ∧ ∀ n : ℕ,
      leadingCoeff ξ m n * g (n + 1) + couplingCoeff ξ μ m n * g n = 0 := by
  obtain ⟨g, hg, hfg⟩ := divide_euler ξ f hf
  have hE : eulerSeries ξ ≠ 0 := by
    intro h
    have := congrArg (constantCoeff ℂ) h
    simp at this
  have hX : (1 - X : Series) ≠ 0 := by
    intro h
    have := congrArg (constantCoeff ℂ) h
    simp at this
  have ht : transformedEquation ξ μ m g = 0 := by
    rw [← hfg, secondOrder_factorization ξ μ m hξ g] at heq
    exact (mul_eq_zero.mp heq).resolve_left (mul_ne_zero hE hX)
  refine ⟨fun n => coeff ℂ n g, ?_, ?_⟩
  · simpa only [coeff_zero_eq_constantCoeff_apply] using hg
  · intro n
    have h := congrArg (coeff ℂ (n + 1)) ht
    simpa only [transformedEquation_coeff, map_zero] using h

end PaperUAMO.InteriorCoefficient

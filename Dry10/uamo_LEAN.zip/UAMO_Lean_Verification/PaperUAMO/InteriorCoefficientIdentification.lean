import PaperUAMO.InteriorCoefficient
import PaperUAMO.InteriorLeading

noncomputable section
namespace PaperUAMO.InteriorCoefficient
open Complex Matrix UAMO UAMO.BoundarySeed
open scoped BigOperators

private theorem first_step_identity (k p M g w e u v : ℂ) (hw : w ≠ 0)
    (he : e ≠ 0) :
    k * ((-M * w / (w * e)) * (p * u) + (g / (w * e)) * (p * w * v)) =
      p * k * ((-M * u + g * v) / e) := by
  field_simp
  ring

private theorem second_step_identity (k p M g w e u v : ℂ) (hw : w ≠ 0)
    (he : e ≠ 0) :
    k * ((g / (w⁻¹ * e)) * (p * u) + (M * w⁻¹ / (w⁻¹ * e)) * (p * w * v)) =
      p * k * w * ((g * u + M * v) / e) := by
  field_simp
  ring

private theorem resonant_step_identity (k p M g w u v : ℂ) (hw : w ≠ 0) :
    -k * (g * (p * u) + (M * w⁻¹) * (p * w * v)) =
      -(k * p) * (g * u + M * v) := by
  field_simp
  ring

theorem inverse_natural_no_root (q : ℂ) (hq : NoIntegerResonance q) :
    ∀ n : ℕ, 0 < n → (q⁻¹) ^ n ≠ 1 := by
  intro n hn he
  have h : q ^ n = 1 := by simpa only [inv_pow, inv_eq_one] using he
  exact hq (n : ℤ) (by omega) (by simpa only [zpow_natCast] using h)

theorem divisor_negative_zero (w q : ℂ) (j : ℕ) :
    divisor w q 0 (-(j : ℤ)) = w * (1 - (q⁻¹) ^ j) := by
  simp only [divisor, diagonalValue, ite_true, zpow_neg, zpow_natCast, inv_pow]
  ring

theorem divisor_negative_one (w q : ℂ) (m j : ℕ) (hw : w ≠ 0)
    (hres : w ^ 2 = q ^ m) :
    divisor w q 1 (-(j : ℤ)) =
      w⁻¹ * (1 - (q⁻¹) ^ j / (q⁻¹) ^ m) := by
  simp only [divisor, diagonalValue, show (1 : Fin 2) ≠ 0 by decide, if_false, zpow_neg,
    zpow_natCast, inv_pow, div_inv_eq_mul, ← hres]
  field_simp [hw]
  ring

theorem leadingCoefficient_eq (w q : ℂ) (μ γ : ℝ) (m : ℕ)
    (hw : w ≠ 0) (hq0 : q ≠ 0) (hq : NoIntegerResonance q)
    (hres : w ^ 2 = q ^ m) (V : InteriorSeed.SpinMatrix)
    (hV : V = !![-I * μ * w, (γ : ℂ); (γ : ℂ), I * μ * w⁻¹])
    (d : ℕ) (hd : d < m) :
    InteriorSeed.leadingCoefficient w q V d 0 =
      ((2 * I)⁻¹) ^ d * (coefficientVector q⁻¹ μ γ m d).1 ∧
    InteriorSeed.leadingCoefficient w q V d 1 =
      ((2 * I)⁻¹) ^ d * w * (coefficientVector q⁻¹ μ γ m d).2 := by
  have hroot := inverse_natural_no_root q hq
  induction d with
  | zero => simp [InteriorSeed.leadingCoefficient, coefficientVector]
  | succ d ih =>
      obtain ⟨ih0, ih1⟩ := ih (by omega)
      have hD0 := divisor_negative_zero w q (d + 1)
      have hD1 := divisor_negative_one w q m (d + 1) hw hres
      have he0 : 1 - (q⁻¹) ^ (d + 1) ≠ 0 :=
        sub_ne_zero.mpr (Ne.symm (hroot _ (by omega)))
      have he1 : 1 - (q⁻¹) ^ (d + 1) / (q⁻¹) ^ m ≠ 0 :=
        second_divisor_ne_zero q⁻¹ (inv_ne_zero hq0) hroot m (d + 1) (by omega)
      constructor
      · rw [InteriorSeed.leadingCoefficient, Fin.sum_univ_two, ih0, ih1]
        simp only [hD0, hV, Matrix.of_apply, Matrix.cons_val_zero,
          Matrix.cons_val_one, Matrix.head_cons, Matrix.head_fin_const,
          coefficientVector, pow_succ]
        convert first_step_identity (2 * I)⁻¹ ((2 * I)⁻¹ ^ d) (I * μ) γ w
          (1 - q⁻¹ ^ (d + 1)) (coefficientVector q⁻¹ μ γ m d).1
          (coefficientVector q⁻¹ μ γ m d).2 hw he0 using 1 <;> ring
      · rw [InteriorSeed.leadingCoefficient, Fin.sum_univ_two, ih0, ih1]
        simp only [hD1, hV, Matrix.of_apply, Matrix.cons_val_zero,
          Matrix.cons_val_one, Matrix.head_cons, Matrix.head_fin_const,
          coefficientVector, pow_succ]
        exact second_step_identity (2 * I)⁻¹ ((2 * I)⁻¹ ^ d) (I * μ) γ w
          (1 - q⁻¹ ^ (d + 1) / q⁻¹ ^ m) (coefficientVector q⁻¹ μ γ m d).1
          (coefficientVector q⁻¹ μ γ m d).2 hw he1

theorem actual_resonant_coefficient_eq (w q : ℂ) (μ γ : ℝ) (m : ℕ)
    (hw : w ≠ 0) (hq0 : q ≠ 0) (hq : NoIntegerResonance q)
    (hm : 0 < m) (hres : w ^ 2 = q ^ m) (V : InteriorSeed.SpinMatrix)
    (hV : V = !![-I * μ * w, (γ : ℂ); (γ : ℂ), I * μ * w⁻¹]) :
    -(2 * I)⁻¹ * (∑ j : Fin 2,
      V 1 j * InteriorSeed.leadingCoefficient w q V (m - 1) j) =
      -((2 * I)⁻¹) ^ m * resonantCoefficient q⁻¹ μ γ m := by
  obtain ⟨h0, h1⟩ := leadingCoefficient_eq w q μ γ m hw hq0 hq hres V hV
    (m - 1) (by omega)
  have hk : (2 * I)⁻¹ * ((2 * I)⁻¹) ^ (m - 1) = ((2 * I)⁻¹) ^ m := by
    rw [← pow_succ', Nat.sub_add_cancel hm]
  rw [Fin.sum_univ_two, h0, h1]
  simp only [hV, Matrix.of_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons, Matrix.head_fin_const,
    resonantCoefficient]
  calc
    _ = -((2 * I)⁻¹ * ((2 * I)⁻¹) ^ (m - 1)) *
        (γ * (coefficientVector q⁻¹ μ γ m (m - 1)).1 +
          I * μ * (coefficientVector q⁻¹ μ γ m (m - 1)).2) := by
      exact resonant_step_identity _ _ _ _ _ _ _ hw
    _ = _ := by rw [hk]

theorem actual_resonant_coefficient_ne_zero (w q : ℂ) (μ γ : ℝ) (m : ℕ)
    (hw : w ≠ 0) (hq : NoIntegerResonance q) (hqn : ‖q‖ = 1)
    (hm : 0 < m) (hμ : μ ≠ 0) (hγ : γ ^ 2 = 1 + μ ^ 2)
    (hres : w ^ 2 = q ^ m) (V : InteriorSeed.SpinMatrix)
    (hV : V = !![-I * μ * w, (γ : ℂ); (γ : ℂ), I * μ * w⁻¹]) :
    -(2 * I)⁻¹ * (∑ j : Fin 2,
      V 1 j * InteriorSeed.leadingCoefficient w q V (m - 1) j) ≠ 0 := by
  have hq0 : q ≠ 0 := by intro h; simp [h] at hqn
  rw [actual_resonant_coefficient_eq w q μ γ m hw hq0 hq hm hres V hV]
  apply mul_ne_zero
  · exact neg_ne_zero.mpr (pow_ne_zero _ (inv_ne_zero
      (mul_ne_zero (by norm_num) I_ne_zero)))
  · exact resonantCoefficient_ne_zero q⁻¹ μ γ m (by simp [norm_inv, hqn])
      (inverse_natural_no_root q hq) hm hμ hγ

end PaperUAMO.InteriorCoefficient

import PaperUAMO.InteriorCoefficientFormal

noncomputable section
namespace PaperUAMO.InteriorCoefficient
open Complex PowerSeries

theorem conj_eq_inv_of_norm_one (z : ℂ) (hz : ‖z‖ = 1) :
    star z = z⁻¹ := by
  have h0 : z ≠ 0 := by intro h; simp [h] at hz
  have hmul : star z * z = 1 := by
    rw [Complex.star_def, ← Complex.normSq_eq_conj_mul_self, Complex.normSq_eq_norm_sq, hz]
    norm_num
  calc
    star z = star z * (z * z⁻¹) := by rw [mul_inv_cancel₀ h0, mul_one]
    _ = (star z * z) * z⁻¹ := by ring
    _ = z⁻¹ := by rw [hmul, one_mul]

theorem circle_quotient_real (A B : ℂ) (hA : ‖A‖ = 1) (hB : ‖B‖ = 1)
    (_hAB : 1 - A * B ≠ 0) :
    ((A - B) / (1 - A * B)).im = 0 := by
  have hA0 : A ≠ 0 := by intro h; simp [h] at hA
  have hB0 : B ≠ 0 := by intro h; simp [h] at hB
  have hden : 1 - A⁻¹ * B⁻¹ = (A * B - 1) / (A * B) := by
    field_simp [hA0, hB0]
  have hs : star ((A - B) / (1 - A * B)) = (A - B) / (1 - A * B) := by
    simp only [star_div₀, star_sub, star_one, star_mul,
      conj_eq_inv_of_norm_one A hA, conj_eq_inv_of_norm_one B hB]
    rw [inv_sub_inv hA0 hB0, mul_comm B⁻¹ A⁻¹, hden,
      div_div_div_cancel_right₀ (mul_ne_zero hA0 hB0)]
    rw [show B - A = -(A - B) by ring,
      show A * B - 1 = -(1 - A * B) by ring]
    exact neg_div_neg_eq _ _
  have hi := congrArg Complex.im hs
  simp only [Complex.star_def, Complex.conj_im] at hi
  linarith

theorem circle_numerator_ne_zero (A B : ℂ) (μ : ℝ)
    (hA : ‖A‖ = 1) (hB : ‖B‖ = 1) (hAB : 1 - A * B ≠ 0) (hμ : μ ≠ 0) :
    A - B - I * μ * (1 - A * B) ≠ 0 := by
  intro h
  have he : (A - B) / (1 - A * B) = I * μ := by
    apply (div_eq_iff hAB).mpr
    linear_combination h
  have hi := circle_quotient_real A B hA hB hAB
  rw [he] at hi
  apply hμ
  simpa using hi

theorem couplingCoeff_ne_zero (ξ : ℂ) (μ : ℝ) (m n : ℕ)
    (hξ : ‖ξ‖ = 1) (hm : ξ ^ m ≠ 1) (hn : n ≤ m) (hμ : μ ≠ 0) :
    couplingCoeff ξ μ m n ≠ 0 := by
  have hξ0 : ξ ≠ 0 := by intro h; simp [h] at hξ
  have hab : ξ ^ (m - n) * ξ ^ n = ξ ^ m := by
    rw [← pow_add, Nat.sub_add_cancel hn]
  have hprod : ξ ^ (n + 1) * ξ ^ (m - n) = ξ ^ (m + 1) := by
    rw [← pow_add]
    congr 1
    omega
  have hprod' : ξ ^ (n + 1) * ξ ^ n = ξ ^ (2 * n + 1) := by
    rw [← pow_add]
    congr 1
    omega
  have hnon := circle_numerator_ne_zero (ξ ^ (m - n)) (ξ ^ n) μ
    (by simp [norm_pow, hξ]) (by simp [norm_pow, hξ])
    (by rw [hab]; exact sub_ne_zero.mpr (Ne.symm hm)) hμ
  have he : couplingCoeff ξ μ m n =
      ξ ^ (n + 1) * (ξ ^ (m - n) - ξ ^ n - I * μ *
        (1 - ξ ^ (m - n) * ξ ^ n)) := by
    rw [hab]
    dsimp [couplingCoeff]
    simp only [mul_sub, hprod, hprod']
    ring
  rw [he]
  exact mul_ne_zero (pow_ne_zero _ hξ0) hnon

theorem no_firstOrder_solution (ξ : ℂ) (μ : ℝ) (m : ℕ)
    (hξ : ‖ξ‖ = 1) (hm : ξ ^ m ≠ 1) (hμ : μ ≠ 0)
    (g : ℕ → ℂ) (hg : g 0 = 1)
    (heq : ∀ n : ℕ, leadingCoeff ξ m n * g (n + 1) +
      couplingCoeff ξ μ m n * g n = 0) : False := by
  have hne : ∀ n : ℕ, n ≤ m → g n ≠ 0 := by
    intro n hn
    induction n with
    | zero => simp [hg]
    | succ n ih =>
        have hprev := ih (by omega)
        have hcoupling := couplingCoeff_ne_zero ξ μ m n hξ hm (by omega) hμ
        intro hzero
        have h := heq n
        rw [hzero, mul_zero, zero_add] at h
        exact (mul_ne_zero hcoupling hprev) h
  have h := heq m
  have hlead : leadingCoeff ξ m m = 0 := by simp [leadingCoeff]
  rw [hlead, zero_mul, zero_add] at h
  exact (mul_ne_zero (couplingCoeff_ne_zero ξ μ m m hξ hm le_rfl hμ)
    (hne m le_rfl)) h

theorem no_secondOrder_solution (ξ : ℂ) (μ : ℝ) (m : ℕ)
    (hξ : ‖ξ‖ = 1) (hroot : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1)
    (hm : 0 < m) (hμ : μ ≠ 0) (f : Series)
    (hf : constantCoeff ℂ f = 1)
    (heq : secondOrderEquation ξ μ m f = 0) : False := by
  obtain ⟨g, hg, hrec⟩ := firstOrder_of_secondOrder ξ μ m hroot f hf heq
  exact no_firstOrder_solution ξ μ m hξ (hroot m hm) hμ g hg hrec

end PaperUAMO.InteriorCoefficient

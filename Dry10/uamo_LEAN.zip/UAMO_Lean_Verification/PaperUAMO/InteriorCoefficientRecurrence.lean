import PaperUAMO.InteriorCoefficientNonzero

noncomputable section
namespace PaperUAMO.InteriorCoefficient
open Complex PowerSeries

private theorem eliminate_coupled {R : Type*} [CommRing R]
    (a t ti G M X f rf rrf v rv : R)
    (hti : t * ti = 1) (hGM : G ^ 2 + M ^ 2 = 1)
    (hf : f - rf = X * (-M * f + G * v))
    (hr : rf - rrf = a * X * (-M * rf + G * rv))
    (hv : v - ti * rv = X * (G * f + M * v)) :
    rrf - (1 + a * t + M * a * (1 - t) * X) * rf +
      a * t * ((1 - X ^ 2) * f) = 0 := by
  linear_combination -hr + a*t*(1-M*X)*hf + a*t*G*X*hv +
    a*t*X^2*f*hGM + a*G*X*rv*hti

theorem twoComponent_secondOrder (ξ : ℂ) (μ γ : ℝ) (m : ℕ)
    (hξ : ξ ≠ 0) (hγ : γ ^ 2 = 1 + μ ^ 2) (f v : Series)
    (hf : f - rescale ξ f =
      X * (-C ℂ (I * μ) * f + C ℂ (γ : ℂ) * v))
    (hv : v - C ℂ ((ξ ^ m)⁻¹) * rescale ξ v =
      X * (C ℂ (γ : ℂ) * f + C ℂ (I * μ) * v)) :
    secondOrderEquation ξ μ m f = 0 := by
  have hr := congrArg (rescale ξ) hf
  simp only [map_sub, map_mul, map_add, map_neg, rescale_X,
    rescale_C_complex] at hr
  have hn : (γ : ℂ) ^ 2 + (I * μ) ^ 2 = 1 := by
    have hγ' : (γ : ℂ) ^ 2 = 1 + (μ : ℂ) ^ 2 := by exact_mod_cast hγ
    rw [mul_pow, I_sq, hγ']
    ring
  have hn' : (C ℂ (γ : ℂ)) ^ 2 + (C ℂ (I * μ)) ^ 2 = 1 := by
    rw [← map_pow, ← map_pow, ← map_add, hn, map_one]
  have hti : C ℂ (ξ ^ m) * C ℂ ((ξ ^ m)⁻¹) = 1 := by
    rw [← map_mul, mul_inv_cancel₀ (pow_ne_zero _ hξ), map_one]
  have h := eliminate_coupled (C ℂ ξ) (C ℂ (ξ ^ m)) (C ℂ ((ξ ^ m)⁻¹))
    (C ℂ (γ : ℂ)) (C ℂ (I * μ)) X f (rescale ξ f)
    (rescale ξ (rescale ξ f)) v (rescale ξ v) hti hn' hf
      (by simpa only [map_mul] using hr) hv
  simp only [secondOrderEquation, map_add, map_sub, map_mul, map_one, map_pow,
    pow_succ] at h ⊢
  convert h using 1
  ring

theorem coefficient_equations_to_series (ξ : ℂ) (μ γ : ℝ) (m : ℕ)
    (u v : ℕ → ℂ) (hu : u 0 = 1) (hv0 : v 0 = 0)
    (hfirst : ∀ n : ℕ, (1 - ξ ^ (n + 1)) * u (n + 1) =
      -I * μ * u n + γ * v n)
    (hsecond : ∀ n : ℕ, (1 - ξ ^ (n + 1) / ξ ^ m) * v (n + 1) =
      γ * u n + I * μ * v n) :
    let f : Series := PowerSeries.mk u
    let h : Series := PowerSeries.mk v
    constantCoeff ℂ f = 1 ∧
    f - rescale ξ f = X * (-C ℂ (I * μ) * f + C ℂ (γ : ℂ) * h) ∧
    h - C ℂ ((ξ ^ m)⁻¹) * rescale ξ h =
      X * (C ℂ (γ : ℂ) * f + C ℂ (I * μ) * h) := by
  dsimp
  refine ⟨?_, ?_, ?_⟩
  · exact hu
  · ext n
    cases n with
    | zero =>
        simp only [map_sub, coeff_rescale, pow_zero, one_mul, sub_self, coeff_zero_X_mul]
    | succ n =>
        simp only [map_sub, coeff_rescale, coeff_succ_X_mul, map_add,
          neg_mul, map_neg, coeff_C_mul, coeff_mk]
        linear_combination hfirst n
  · ext n
    cases n with
    | zero =>
        simp only [map_sub, coeff_C_mul, coeff_rescale, pow_zero, one_mul,
          coeff_mk, hv0, mul_zero, sub_zero, coeff_zero_X_mul]
    | succ n =>
        simp only [map_sub, coeff_rescale, coeff_succ_X_mul, map_add,
          coeff_C_mul, coeff_mk]
        simp only [div_eq_mul_inv] at hsecond
        linear_combination hsecond n

theorem no_infinite_coupled_solution (ξ : ℂ) (μ γ : ℝ) (m : ℕ)
    (hξ : ‖ξ‖ = 1) (hroot : ∀ n : ℕ, 0 < n → ξ ^ n ≠ 1)
    (hm : 0 < m) (hμ : μ ≠ 0) (hγ : γ ^ 2 = 1 + μ ^ 2)
    (u v : ℕ → ℂ) (hu : u 0 = 1) (hv0 : v 0 = 0)
    (hfirst : ∀ n : ℕ, (1 - ξ ^ (n + 1)) * u (n + 1) =
      -I * μ * u n + γ * v n)
    (hsecond : ∀ n : ℕ, (1 - ξ ^ (n + 1) / ξ ^ m) * v (n + 1) =
      γ * u n + I * μ * v n) : False := by
  obtain ⟨hf0, hf, hv⟩ := coefficient_equations_to_series ξ μ γ m u v hu hv0
    hfirst hsecond
  have hξ0 : ξ ≠ 0 := by intro h; simp [h] at hξ
  exact no_secondOrder_solution ξ μ m hξ hroot hm hμ (PowerSeries.mk u) hf0
    (twoComponent_secondOrder ξ μ γ m hξ0 hγ _ _ hf hv)

end PaperUAMO.InteriorCoefficient

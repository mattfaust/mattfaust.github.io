import UAMODraft.FiniteSystem

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed
open scoped BigOperators Topology

abbrev Mode (m : ℕ) :=
  {p : ℤ × Fin 2 // p.1 ∈ Finset.Icc (-(m:ℤ)) (m:ℤ) ∧ ¬(p.1=-(m:ℤ) ∧ p.2=1)}
instance (m : ℕ) : Fintype (Mode m) :=
  Fintype.ofInjective
    (fun p : Mode m => (⟨p.val.1,p.property.1⟩,p.val.2) :
      Mode m → {k : ℤ // k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ)} × Fin 2)
    (by
      intro p q h
      apply Subtype.ext
      have h1 := congrArg (fun r : {k : ℤ // k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ)} × Fin 2 => r.1.val) h
      have h2 := congrArg (fun r : {k : ℤ // k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ)} × Fin 2 => r.2) h
      exact Prod.ext h1 h2)

abbrev Variables (m : ℕ) := Mode m → ℂ
abbrev SpinMatrix := Fin 2 → Fin 2 → ℂ
abbrev ParameterSpace (m : ℕ) := ℝ × Variables m

def zeroMode (m : ℕ) : Mode m :=
  ⟨(0,0), Finset.mem_Icc.mpr ⟨by omega,by omega⟩, by simp⟩

def coefficient (m : ℕ) (x : Variables m) (k : ℤ) (j : Fin 2) : ℂ :=
  if k=0 ∧ j=0 then 1 else
    if hp : k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ) ∧ ¬(k=-(m:ℤ) ∧ j=1) then
      x ⟨(k,j),hp⟩ else 0

def baseCoefficient (k : ℤ) (j : Fin 2) : ℂ := if k=0 ∧ j=0 then 1 else 0

def finiteSystem (m : ℕ) (w q : ℂ) (V : ℝ → SpinMatrix)
    (lam : ℝ) (x : Variables m) : Variables m := fun p =>
  ((if p.val.2=0 then w*Complex.exp (Complex.I*(x (zeroMode m)).im)
     else w⁻¹*Complex.exp (-Complex.I*(x (zeroMode m)).im)) -
      w*(1-(x (zeroMode m)).re)*q^p.val.1) * coefficient m x p.val.1 p.val.2 +
  (2*Complex.I)⁻¹*(lam:ℂ)* ∑ j : Fin 2,
    V (x (zeroMode m)).im p.val.2 j *
      (coefficient m x (p.val.1-1) j - coefficient m x (p.val.1+1) j)

def diagonal (m : ℕ) (w q : ℂ) (p : Mode m) : ℂ :=
  if p.val.1=0 ∧ p.val.2=0 then w else divisor w q p.val.2 p.val.1

theorem diagonal_ne_zero {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m) (p : Mode m) :
    diagonal m w q p ≠ 0 := by
  unfold diagonal
  split_ifs with hp
  · exact hw
  apply divisor_ne_zero hw hq0 hq m hres
  exact ⟨fun h => hp ⟨h.2,h.1⟩,fun h => p.property.2 ⟨h.2,h.1⟩⟩

def finiteJacobianLinear (m : ℕ) (w q : ℂ) : Variables m →ₗ[ℂ] Variables m where
  toFun x p := diagonal m w q p*x p
  map_add' x y := by funext p; exact mul_add _ _ _
  map_smul' c x := by funext p; simp only [Pi.smul_apply,smul_eq_mul,RingHom.id_apply]; ring

theorem finiteJacobian_bijective {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m) :
    Function.Bijective (finiteJacobianLinear m w q) := by
  constructor
  · intro x y h
    funext p
    exact mul_left_cancel₀ (diagonal_ne_zero hw hq0 hq m hres p) (congrFun h p)
  · intro y
    refine ⟨fun p => y p / diagonal m w q p,?_⟩
    funext p
    exact mul_div_cancel₀ _ (diagonal_ne_zero hw hq0 hq m hres p)

def finiteJacobianEquiv {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m) :
    Variables m ≃L[ℝ] Variables m :=
  ((LinearEquiv.ofBijective (finiteJacobianLinear m w q)
    (finiteJacobian_bijective hw hq0 hq m hres)).restrictScalars ℝ).toContinuousLinearEquiv

theorem coefficient_base (m : ℕ) (k : ℤ) (j : Fin 2) :
    coefficient m 0 k j=baseCoefficient k j := by
  simp [coefficient,baseCoefficient]

theorem finiteSystem_base (m : ℕ) (w q : ℂ) (V : ℝ → SpinMatrix) :
    finiteSystem m w q V 0 0=0 := by
  funext p
  by_cases hp : p.val.1=0 ∧ p.val.2=0
  · simp [finiteSystem,coefficient,hp.1,hp.2]
  · simp [finiteSystem,coefficient,hp]

theorem finiteSystem_analytic (m : ℕ) (w q : ℂ) (V : ℝ → SpinMatrix)
    (hV : AnalyticAt ℝ V 0) :
    AnalyticAt ℝ (fun p : ParameterSpace m => finiteSystem m w q V p.1 p.2) (0,0) := by
  have he (k : Mode m) : AnalyticAt ℝ (fun p : ParameterSpace m => p.2 k) (0,0) :=
    ((ContinuousLinearMap.proj k : Variables m →L[ℝ] ℂ).comp
      (ContinuousLinearMap.snd ℝ ℝ (Variables m))).analyticAt (0,0)
  have hc (k : ℤ) (j : Fin 2) :
      AnalyticAt ℝ (fun p : ParameterSpace m => coefficient m p.2 k j) (0,0) := by
    unfold coefficient
    split_ifs
    · exact analyticAt_const
    · exact he _
    · exact analyticAt_const
  have hi₀ : AnalyticAt ℝ (fun p : ParameterSpace m => (p.2 (zeroMode m)).im) (0,0) :=
    (Complex.imCLM.analyticAt _).comp (he _)
  have hi : AnalyticAt ℝ (fun p : ParameterSpace m => ((p.2 (zeroMode m)).im:ℂ)) (0,0) :=
    (Complex.ofRealCLM.analyticAt _).comp hi₀
  have hr : AnalyticAt ℝ (fun p : ParameterSpace m => ((p.2 (zeroMode m)).re:ℂ)) (0,0) :=
    (Complex.ofRealCLM.analyticAt _).comp ((Complex.reCLM.analyticAt _).comp (he _))
  have hv (i j : Fin 2) : AnalyticAt ℝ
      (fun p : ParameterSpace m => V (p.2 (zeroMode m)).im i j) (0,0) := by
    have hv' : AnalyticAt ℝ (fun t => V t i j) 0 :=
      (ContinuousLinearMap.proj j : (Fin 2 → ℂ) →L[ℝ] ℂ).analyticAt _ |>.comp
        ((ContinuousLinearMap.proj i : SpinMatrix →L[ℝ] (Fin 2 → ℂ)).analyticAt _ |>.comp hV)
    exact hv'.comp_of_eq hi₀ (by simp)
  apply AnalyticAt.pi
  intro p
  have hp : AnalyticAt ℝ (fun y : ParameterSpace m =>
      if p.val.2=0 then w*Complex.exp (Complex.I*(y.2 (zeroMode m)).im)
      else w⁻¹*Complex.exp (-Complex.I*(y.2 (zeroMode m)).im)) (0,0) := by
    split_ifs
    · exact analyticAt_const.mul (analyticAt_cexp.restrictScalars.comp (analyticAt_const.mul hi))
    · exact analyticAt_const.mul (analyticAt_cexp.restrictScalars.comp (analyticAt_const.mul hi))
  have hs : AnalyticAt ℝ (fun y : ParameterSpace m => ∑ j : Fin 2,
      V (y.2 (zeroMode m)).im p.val.2 j *
        (coefficient m y.2 (p.val.1-1) j - coefficient m y.2 (p.val.1+1) j)) (0,0) := by
    simpa only [Fin.sum_univ_two] using
      ((hv _ 0).mul ((hc _ 0).sub (hc _ 0))).add
        ((hv _ 1).mul ((hc _ 1).sub (hc _ 1)))
  exact ((hp.sub ((analyticAt_const.mul (analyticAt_const.sub hr)).mul analyticAt_const)).mul (hc _ _)).add
    ((analyticAt_const.mul ((Complex.ofRealCLM.analyticAt _).comp analyticAt_fst)).mul
      hs)

end PaperUAMO.InteriorSeed

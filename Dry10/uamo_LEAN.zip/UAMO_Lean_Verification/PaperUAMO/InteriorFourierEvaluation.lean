import PaperUAMO.InteriorResidual
import UAMO.BoundaryFourierEvaluation

noncomputable section
set_option maxHeartbeats 700000
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Matrix Function
open scoped BigOperators Topology

private theorem finite_support_sub {f g : ℤ→ℂ}
    (hf : (support f).Finite) (hg : (support g).Finite) :
    (support (fun k => f k-g k)).Finite := by
  apply (hf.union hg).subset
  intro k hk
  by_contra h
  simp only [Set.mem_union,mem_support,not_or,not_not] at h
  simp [mem_support,h.1,h.2] at hk

private theorem finite_support_add {f g : ℤ→ℂ}
    (hf : (support f).Finite) (hg : (support g).Finite) :
    (support (fun k => f k+g k)).Finite := by
  apply (hf.union hg).subset
  intro k hk
  by_contra h
  simp only [Set.mem_union,mem_support,not_or,not_not] at h
  simp [mem_support,h.1,h.2] at hk

private theorem finite_support_const_mul {f : ℤ→ℂ}
    (hf : (support f).Finite) (c : ℂ) : (support (fun k => c*f k)).Finite := by
  simpa only [mul_comm] using finite_support_mul_left hf (fun _ => c)

theorem fourierEval_sine_difference (f : ℤ→ℂ) (hf : (support f).Finite) (θ : ℝ) :
    fourierEval (fun k => (2*Complex.I)⁻¹*(f (k-1)-f (k+1))) θ =
      (Real.sin (2*Real.pi*θ):ℂ)*fourierEval f θ := by
  have hm : (support (fun k => f (k-1))).Finite := by
    simpa only [sub_eq_add_neg] using finite_support_translate hf (-1)
  have hp := finite_support_translate hf 1
  rw [fourierEval_const_mul (finite_support_sub hm hp),fourierEval_sub hm hp]
  rw [show (fun k => f (k-1))=(fun k => f (k+(-1))) by rfl,
    fourierEval_translate hf (-1),fourierEval_translate hf 1,sine_fourier]
  simp only [neg_neg,zpow_one,zpow_neg]
  ring

theorem fourierEvaluation_matrixResidual (D : Fin 2→ℂ) (V : SpinMatrix)
    (lam α θ : ℝ) (μ : ℂ) (v : FourierVector) (hv : ∀ i,(support (v i)).Finite) :
    fourierEvaluation (fun i k => (D i-μ*(weylPhase α)^k)*v i k+
      (2*Complex.I)⁻¹*(lam:ℂ)*∑ j : Fin 2, V i j*(v j (k-1)-v j (k+1))) θ =
      (Matrix.diagonal D+((lam*Real.sin (2*Real.pi*θ):ℝ):ℂ) • (Matrix.of V))*ᵥfourierEvaluation v θ-
        μ • fourierEvaluation v (θ+α) := by
  have hg (j : Fin 2) : (support (fun k => (2*Complex.I)⁻¹*(v j (k-1)-v j (k+1)))).Finite := by
    apply finite_support_const_mul
    apply finite_support_sub
    · simpa only [sub_eq_add_neg] using finite_support_translate (hv j) (-1)
    · exact finite_support_translate (hv j) 1
  have hu (i j : Fin 2) : (support (fun k => V i j*((2*Complex.I)⁻¹*
      (v j (k-1)-v j (k+1))))).Finite := finite_support_const_mul (hg j) _
  have hdiag (i : Fin 2) : (support (fun k => (D i-μ*(weylPhase α)^k)*v i k)).Finite := by
    simpa only [mul_comm] using finite_support_mul_left (hv i) (fun k => D i-μ*(weylPhase α)^k)
  have hweight (i : Fin 2) : (support (fun k => (weylPhase α)^k*v i k)).Finite := by
    simpa only [mul_comm] using finite_support_mul_left (hv i) (fun k => (weylPhase α)^k)
  have hd (i : Fin 2) : fourierEval (fun k => (D i-μ*(weylPhase α)^k)*v i k) θ =
      D i*fourierEval (v i) θ-μ*fourierEval (v i) (θ+α) := by
    simp only [sub_mul,mul_assoc]
    rw [fourierEval_sub (finite_support_const_mul (hv i) _) (finite_support_const_mul (hweight i) _),
      fourierEval_const_mul (hv i),fourierEval_const_mul (hweight i),← fourierEval_phase_shift]
  ext i
  change fourierEval (fun k => (D i-μ*(weylPhase α)^k)*v i k+
    (2*Complex.I)⁻¹*(lam:ℂ)*∑ j : Fin 2, V i j*(v j (k-1)-v j (k+1))) θ=_
  have heq : (fun k => (D i-μ*(weylPhase α)^k)*v i k+
      (2*Complex.I)⁻¹*(lam:ℂ)*∑ j : Fin 2, V i j*(v j (k-1)-v j (k+1)))=
      (fun k => (D i-μ*(weylPhase α)^k)*v i k+(lam:ℂ)*
        (V i 0*((2*Complex.I)⁻¹*(v 0 (k-1)-v 0 (k+1)))+
         V i 1*((2*Complex.I)⁻¹*(v 1 (k-1)-v 1 (k+1))))) := by
    funext k
    rw [Fin.sum_univ_two]
    ring
  rw [heq,fourierEval_add (hdiag i) (finite_support_const_mul (finite_support_add (hu i 0) (hu i 1)) _),
    hd,fourierEval_const_mul (finite_support_add (hu i 0) (hu i 1)),
    fourierEval_add (hu i 0) (hu i 1),fourierEval_const_mul (hg 0),fourierEval_const_mul (hg 1),
    fourierEval_sine_difference _ (hv 0),fourierEval_sine_difference _ (hv 1)]
  fin_cases i <;> simp [mulVec,dotProduct,Fin.sum_univ_two,fourierEvaluation,Matrix.diagonal] <;> ring

def fourierProfile (m : ℕ) (x : Variables m) : FourierVector := fun j k => coefficient m x k j

def physicalProfile (m : ℕ) (x : Variables m) (θ : ℝ) : Fin 2→ℂ :=
  fourierEvaluation (fourierProfile m x) θ

def phaseDiagonal (w : ℂ) (h : ℝ) : Fin 2→ℂ :=
  fun j => if j=0 then w*Complex.exp (Complex.I*h) else w⁻¹*Complex.exp (-Complex.I*h)

def physicalNumerator (w : ℂ) (V : ℝ→SpinMatrix) (lam h θ : ℝ) : SpinMatrix :=
  Matrix.diagonal (phaseDiagonal w h)+((lam*Real.sin (2*Real.pi*θ):ℝ):ℂ) • (Matrix.of (V h))

def amplitude (m : ℕ) (x : Variables m) : ℝ := 1-(x (zeroMode m)).re

theorem fourierProfile_finite (m : ℕ) (x : Variables m) (j : Fin 2) :
    (support (fourierProfile m x j)).Finite := by
  apply (Finset.finite_toSet (Finset.Icc (-(m:ℤ)) (m:ℤ))).subset
  intro k hk
  by_contra hki
  simp [mem_support,fourierProfile,coefficient_outside m x k j hki] at hk

theorem physicalProfile_residual (m : ℕ) (w : ℂ) (V : ℝ→SpinMatrix)
    (α lam θ : ℝ) (x : Variables m) :
    physicalNumerator w V lam (x (zeroMode m)).im θ*ᵥphysicalProfile m x θ-
      (w*(amplitude m x:ℂ)) • physicalProfile m x (θ+α) =
      fourierEvaluation (fun j k => fullResidual m w (weylPhase α) V lam x k j) θ := by
  symm
  simpa only [physicalProfile,physicalNumerator,fourierProfile,fullResidual,denominator,
    phaseDiagonal,amplitude,Complex.ofReal_sub,Complex.ofReal_one] using
    fourierEvaluation_matrixResidual (phaseDiagonal w (x (zeroMode m)).im)
      (V (x (zeroMode m)).im) lam α θ (w*(amplitude m x:ℂ))
      (fourierProfile m x) (fourierProfile_finite m x)

end PaperUAMO.InteriorSeed

import PaperUAMO.FreeEllipticConjugacy
import UAMODraft.RealFrameAlgebra

noncomputable section
namespace PaperUAMO.InteriorFrameAnalytic
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

theorem profileSignature_analyticAt {v : E → Fin 2 → ℂ} {x : E}
    (hv : AnalyticAt ℝ v x) :
    AnalyticAt ℝ (fun y=>profileSignature (v y)) x := by
  have h (i : Fin 2) := analyticAt_pi_iff.mp hv i
  have hr (i : Fin 2) := (Complex.reCLM.analyticAt _).comp (h i)
  have hi (i : Fin 2) := (Complex.imCLM.analyticAt _).comp (h i)
  have heq : (fun y => profileSignature (v y)) =
      (fun y => ((v y 0).re*(v y 0).re+(v y 0).im*(v y 0).im) -
        ((v y 1).re*(v y 1).re+(v y 1).im*(v y 1).im)) := by
    funext y
    simp only [profileSignature,←Complex.normSq_eq_norm_sq,Complex.normSq_apply]
  rw [heq]
  simpa only [Function.comp_def,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,
    Complex.reCLM_apply,Complex.imCLM_apply] using
    (((hr 0).mul (hr 0)).add ((hi 0).mul (hi 0))).sub
      (((hr 1).mul (hr 1)).add ((hi 1).mul (hi 1)))

theorem frameRaw_analyticAt {v : E → Fin 2 → ℂ} {g : E → ℂ} {x : E}
    (hv : AnalyticAt ℝ v x) (hg : AnalyticAt ℝ g x) :
    AnalyticAt ℝ (fun y => frameRaw (v y) (g y)) x := by
  have h (i : Fin 2) := analyticAt_pi_iff.mp hv i
  have hs (i : Fin 2) : AnalyticAt ℝ (fun y=>star (v y i)) x := by
    exact ((Complex.conjCLE:ℂ→L[ℝ]ℂ).analyticAt _).comp (h i)
  have hgs : AnalyticAt ℝ (fun y=>star (g y)) x :=
    ((Complex.conjCLE:ℂ→L[ℝ]ℂ).analyticAt _).comp hg
  apply AnalyticAt.pi
  intro i
  apply AnalyticAt.pi
  intro j
  fin_cases i <;> fin_cases j
  · exact hg.mul (h 0)
  · exact hgs.mul (hs 1)
  · exact hg.mul (h 1)
  · exact hgs.mul (hs 0)

theorem normalizedFrame_analyticAt {v : E → Fin 2 → ℂ} {g : E → ℂ} {x : E}
    (hv : AnalyticAt ℝ v x) (hg : AnalyticAt ℝ g x)
    (hs : 0<profileSignature (v x)) :
    AnalyticAt ℝ (fun y => normalizedFrame (v y) (g y)) x := by
  have hn : AnalyticAt ℝ (fun y=>(Real.sqrt (profileSignature (v y)))⁻¹) x :=
    (((profileSignature_analyticAt hv).contDiffAt (n:=⊤)).sqrt hs.ne').inv
      (Real.sqrt_pos.mpr hs).ne' |>.analyticAt
  have hnc := (Complex.ofRealCLM.analyticAt _).comp hn
  have hf := frameRaw_analyticAt hv hg
  apply AnalyticAt.pi
  intro i
  apply AnalyticAt.pi
  intro j
  have hij := analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hf i) j
  simpa only [normalizedFrame,Matrix.smul_apply,smul_eq_mul,Complex.ofReal_inv,
    Complex.ofRealCLM_apply,Function.comp_def,Pi.mul_apply] using hnc.mul hij

theorem realFrameOf_analyticAt {v : E → Fin 2 → ℂ} {g : E → ℂ} {x : E}
    (hv : AnalyticAt ℝ v x) (hg : AnalyticAt ℝ g x)
    (hs : 0<profileSignature (v x)) (ξ : ℂ) :
    AnalyticAt ℝ (fun y => realFrameOf (v y) (g y) ξ) x := by
  have hn := normalizedFrame_analyticAt hv hg hs
  have he (i j : Fin 2) := analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hn i) j
  apply AnalyticAt.pi
  intro i
  apply AnalyticAt.pi
  intro j
  change AnalyticAt ℝ (fun y =>
    ((seedCayleyInverse 1*normalizedFrame (v y) (g y)*seedCayley ξ) i j).re) x
  have hc : AnalyticAt ℝ (fun y =>
      (seedCayleyInverse 1*normalizedFrame (v y) (g y)*seedCayley ξ) i j) x := by
    simp only [Matrix.mul_apply,Fin.sum_univ_two]
    exact (((analyticAt_const.mul (he 0 0)).add
        (analyticAt_const.mul (he 1 0))).mul analyticAt_const).add
      (((analyticAt_const.mul (he 0 1)).add
        (analyticAt_const.mul (he 1 1))).mul analyticAt_const)
  exact (Complex.reCLM.analyticAt _).comp hc

end PaperUAMO.InteriorFrameAnalytic

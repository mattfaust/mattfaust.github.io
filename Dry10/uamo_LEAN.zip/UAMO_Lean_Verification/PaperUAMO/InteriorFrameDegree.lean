import UAMODraft.FrameContinuity
import PaperUAMO.SymmetricSplittingFrame

noncomputable section
namespace PaperUAMO.InteriorFrame
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed Matrix
open PaperUAMO.SymmetricSplitting UAMODraft.PositiveAngle UAMO.ProjectiveAngle UAMO.StablePlane
open scoped Topology

abbrev RealMatrix := Matrix (Fin 2) (Fin 2) ℝ

def pairedRealFrame (m : ℕ) (v : ℝ → Fin 2 → ℂ) (x : ℝ) : RealMatrix :=
  realFrameOf (v x) (halfPhase m x) 1

def columnCorrection (m : ℕ) (v : ℝ → Fin 2 → ℂ) (x : ℝ) : ℂ :=
  v x 0+star (halfPhase m x)^2*star (v x 1)

def pairedAngle (m : ℕ) (v : ℝ → Fin 2 → ℂ) (x : ℝ) : ℝ :=
  Real.pi*(m:ℝ)*x+Complex.arg (columnCorrection m v x)

theorem signature_pos (v : ℝ → Fin 2 → ℂ) {e : ℝ} (he0 : 0≤e) (he : e<1/4)
    (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) (x : ℝ) :
    0<profileSignature (v x) := by
  have h := (profileSignature_bounds (v x) he0 he.le (hv0 x) (hv1 x)).1
  linarith

theorem columnCorrection_periodic (m : ℕ) (v : ℝ → Fin 2 → ℂ)
    (hp : Function.Periodic v 1) (x : ℝ) :
    columnCorrection m v (x+1)=columnCorrection m v x := by
  simp only [columnCorrection,hp x,halfPhase_add_one,Complex.star_def,map_mul,
    map_pow,map_neg,map_one,mul_pow]
  have he : ((-1:ℂ)^m)^2=1 := by rw [←pow_mul,mul_comm m 2,pow_mul]; norm_num
  rw [he,one_mul]

theorem continuous_columnCorrection (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hv : Continuous v) :
    Continuous (columnCorrection m v) := by
  exact ((continuous_apply 0).comp hv).add
    (((continuous_halfPhase m).star.pow 2).mul (((continuous_apply 1).comp hv).star))

theorem columnCorrection_near_one (m : ℕ) (v : ℝ → Fin 2 → ℂ) {e : ℝ}
    (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) (x : ℝ) :
    ‖columnCorrection m v x-1‖≤2*e := by
  have he : columnCorrection m v x-1=(v x 0-1)+star (halfPhase m x)^2*star (v x 1) := by
    unfold columnCorrection; ring
  rw [he]
  have h := norm_add_le (v x 0-1) (star (halfPhase m x)^2*star (v x 1))
  simp only [norm_mul,norm_pow,norm_star,halfPhase_norm,one_pow,one_mul] at h
  linarith [hv0 x,hv1 x]

theorem columnCorrection_re_pos (m : ℕ) (v : ℝ → Fin 2 → ℂ) {e : ℝ} (he : e<1/4)
    (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) (x : ℝ) :
    0<(columnCorrection m v x).re := by
  have h := (Complex.abs_re_le_norm (columnCorrection m v x-1)).trans
    (columnCorrection_near_one m v hv0 hv1 x)
  simp only [Complex.sub_re,Complex.one_re] at h
  have hlow := (abs_le.mp h).1
  linarith

theorem continuous_pairedAngle (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hv : Continuous v)
    {e : ℝ} (he : e<1/4) (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) :
    Continuous (pairedAngle m v) := by
  apply Continuous.add (by fun_prop)
  apply continuous_iff_continuousAt.mpr
  intro x
  exact (Complex.continuousAt_arg (Or.inl (columnCorrection_re_pos m v he hv0 hv1 x))).comp
    (continuous_columnCorrection m v hv).continuousAt

theorem pairedAngle_degree (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hp : Function.Periodic v 1) (x : ℝ) :
    pairedAngle m v (x+1)=pairedAngle m v x+(m:ℝ)*Real.pi := by
  simp only [pairedAngle,columnCorrection_periodic m v hp]
  ring

theorem firstColumn_polar (m : ℕ) (v : ℝ → Fin 2 → ℂ) (x : ℝ) :
    firstColumnComplex (v x) (halfPhase m x) 1=
      (‖columnCorrection m v x‖:ℂ)*Complex.exp ((pairedAngle m v x:ℂ)*Complex.I) := by
  rw [firstColumn_factorization _ (halfPhase_norm m x) (by norm_num : ‖(1:ℂ)‖=1)]
  simp only [star_one,mul_one,one_pow]
  change halfPhase m x*columnCorrection m v x=_
  conv_lhs => rw [←Complex.norm_mul_exp_arg_mul_I (columnCorrection m v x)]
  have he : halfPhase m x*Complex.exp ((Complex.arg (columnCorrection m v x):ℂ)*Complex.I)=
      Complex.exp ((pairedAngle m v x:ℂ)*Complex.I) := by
    simp only [halfPhase,←Complex.exp_add]
    congr 1
    unfold pairedAngle
    push_cast
    ring
  calc
    _ = (‖columnCorrection m v x‖:ℂ)*(halfPhase m x*
        Complex.exp ((Complex.arg (columnCorrection m v x):ℂ)*Complex.I)) := by ring
    _ = _ := by rw [he]

theorem pairedRealFrame_first_column (m : ℕ) (v : ℝ → Fin 2 → ℂ) {e : ℝ}
    (he0 : 0≤e) (he : e<1/4) (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) (x : ℝ) :
    ∃r:ℝ,0<r ∧ pairedRealFrame m v x 0 0=r*Real.cos (pairedAngle m v x) ∧
      pairedRealFrame m v x 1 0=r*Real.sin (pairedAngle m v x) := by
  have hc : columnCorrection m v x≠0 := by
    intro h
    have hh := columnCorrection_re_pos m v he hv0 hv1 x
    simp only [h,Complex.zero_re,lt_self_iff_false] at hh
  have hp := signature_pos v he0 he hv0 hv1 x
  let r := ‖columnCorrection m v x‖/Real.sqrt (profileSignature (v x))
  refine ⟨r,div_pos (norm_pos_iff.mpr hc) (Real.sqrt_pos.mpr hp),?_,?_⟩
  all_goals
    have hh := realFrameOf_first_column (v x) (halfPhase m x) 1
    rw [firstColumn_polar] at hh
    simp only [Complex.mul_re,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,
      zero_mul,sub_zero,add_zero,Complex.exp_mul_I,Complex.add_re,Complex.add_im,
      Complex.I_re,Complex.I_im,mul_zero,mul_one,zero_add,
      ←Complex.ofReal_cos,←Complex.ofReal_sin,Complex.ofReal_re,Complex.ofReal_im,
      sub_zero,add_zero,zero_add] at hh
  · change _=r*_
    rw [pairedRealFrame,hh.1]
    dsimp [r]
    ring
  · change _=r*_
    rw [pairedRealFrame,hh.2]
    dsimp [r]
    ring

theorem continuous_pairedRealFrame (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hv : Continuous v)
    {e : ℝ} (he0 : 0≤e) (he : e<1/4)
    (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) :
    Continuous (pairedRealFrame m v) := by
  have hv₀ := (continuous_apply 0).comp hv
  have hv₁ := (continuous_apply 1).comp hv
  have hg := continuous_halfPhase m
  have hs : Continuous (fun x=>Real.sqrt (profileSignature (v x))) := by
    unfold profileSignature
    fun_prop
  have hsi : Continuous (fun x=>(Real.sqrt (profileSignature (v x)):ℂ)⁻¹) :=
    (Complex.continuous_ofReal.comp hs).inv₀ (fun x=>Complex.ofReal_ne_zero.mpr
      (Real.sqrt_pos.mpr (signature_pos v he0 he hv0 hv1 x)).ne')
  have hr : Continuous (fun x=>frameRaw (v x) (halfPhase m x)) := by
    apply continuous_pi
    intro i
    apply continuous_pi
    intro j
    fin_cases i <;> fin_cases j <;>
      simp only [frameRaw,Matrix.of_apply,Fin.zero_eta,Fin.mk_one,Matrix.cons_val_zero,
        Matrix.cons_val_one,Matrix.cons_val_fin_one]
    all_goals fun_prop
  have hf : Continuous (fun x=>normalizedFrame (v x) (halfPhase m x)) := hsi.smul hr
  have hb : Continuous (fun x=>seedCayleyInverse 1*normalizedFrame (v x) (halfPhase m x)*seedCayley 1) :=
    (continuous_const.mul hf).mul continuous_const
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  exact Complex.continuous_re.comp ((continuous_apply j).comp ((continuous_apply i).comp hb))

theorem pairedRealFrame_add_one (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hp : Function.Periodic v 1) (x : ℝ) :
    pairedRealFrame m v (x+1)=(-1:ℝ)^m • pairedRealFrame m v x := by
  have hc : normalizedFrame (v (x+1)) (halfPhase m (x+1))=
      (((-1:ℝ)^m:ℝ):ℂ) • normalizedFrame (v x) (halfPhase m x) := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [normalizedFrame,frameRaw,hp x,halfPhase_add_one,Complex.star_def,map_mul,map_pow] <;> ring
  change (seedCayleyInverse 1*normalizedFrame (v (x+1)) (halfPhase m (x+1))*seedCayley 1).map Complex.re=_
  rw [hc,Matrix.mul_smul,Matrix.smul_mul]
  ext i j
  simp only [pairedRealFrame,realFrameOf,Matrix.map_apply,Matrix.smul_apply,smul_eq_mul,
    Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]

theorem pairedRealFrame_degree_data (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hv : Continuous v)
    (hp : Function.Periodic v 1) {e : ℝ} (he0 : 0≤e) (he : e<1/4)
    (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) :
    Continuous (pairedRealFrame m v) ∧ (∀x,(pairedRealFrame m v x).det=1) ∧
      (∀x,pairedRealFrame m v (x+1)=((-1:ℝ)^(m:ℤ)) • pairedRealFrame m v x) ∧
      HasProjectiveDegree (pairedRealFrame m v) (m:ℤ) := by
  refine ⟨continuous_pairedRealFrame m v hv he0 he hv0 hv1,?_,?_,?_⟩
  · intro x
    exact realFrameOf_det (v x) (halfPhase_norm m x) (by norm_num)
      (signature_pos v he0 he hv0 hv1 x)
  · simpa only [zpow_natCast] using pairedRealFrame_add_one m v hp
  · exact ⟨pairedAngle m v,continuous_pairedAngle m v hv he hv0 hv1,
      pairedRealFrame_first_column m v he0 he hv0 hv1,
      by simpa only [Int.cast_natCast] using pairedAngle_degree m v hp⟩

theorem projectiveDegree_left_constant (S : RealMatrix) (hS : S.det=1)
    (B : ℝ→RealMatrix) (m : ℤ) (hB : HasProjectiveDegree B m) :
    HasProjectiveDegree (fun x=>S*B x) m := by
  let z : ℂ := (S 0 0:ℂ)+Complex.I*(S 1 0:ℂ)
  have hzre : z.re=S 0 0 := by simp [z]
  have hzim : z.im=S 1 0 := by simp [z]
  have hz : z≠0 := by
    intro hzero
    have h0 : S 0 0=0 := by simpa only [hzero,Complex.zero_re] using hzre.symm
    have h1 : S 1 0=0 := by simpa only [hzero,Complex.zero_im] using hzim.symm
    simp [Matrix.det_fin_two,h0,h1] at hS
  have hpolar : S 0 0=‖z‖*Real.cos z.arg ∧ S 1 0=‖z‖*Real.sin z.arg := by
    constructor
    · rw [Complex.norm_mul_cos_arg,hzre]
    · rw [Complex.norm_mul_sin_arg,hzim]
  obtain ⟨b,hb,hcol,hwind⟩ := hB
  refine ⟨fun x=>frameLift S z.arg (b x),(continuous_frameLift S z.arg).comp hb,?_,?_⟩
  · intro x
    obtain ⟨r,hr,h0,h1⟩ := hcol x
    obtain ⟨c,hc,hd⟩ := frameLift_direction hS (norm_pos_iff.mpr hz) hpolar (b x)
    have hd0 := congrFun hd 0
    have hd1 := congrFun hd 1
    simp only [angleVector,Matrix.mulVec,dotProduct,Fin.sum_univ_two,
      Pi.smul_apply,smul_eq_mul,Matrix.cons_val_zero,Matrix.cons_val_one,
      Matrix.cons_val_fin_one] at hd0 hd1
    refine ⟨r/c,div_pos hr hc,?_,?_⟩
    · simp only [Matrix.mul_apply,Fin.sum_univ_two,h0,h1]
      field_simp
      linear_combination -r*hd0
    · simp only [Matrix.mul_apply,Fin.sum_univ_two,h0,h1]
      field_simp
      linear_combination -r*hd1
  · intro x
    dsimp only
    rw [hwind]
    exact angleMap_add_int_pi (fun _=>frameLift S z.arg)
      (fun _=>frameLift_add_pi S z.arg) 0 (b x) m

theorem left_pairedRealFrame_degree_data (S : RealMatrix) (hS : S.det=1)
    (m : ℕ) (v : ℝ → Fin 2 → ℂ) (hv : Continuous v) (hp : Function.Periodic v 1)
    {e : ℝ} (he0 : 0≤e) (he : e<1/4)
    (hv0 : ∀x,‖v x 0-1‖≤e) (hv1 : ∀x,‖v x 1‖≤e) :
    Continuous (fun x=>S*pairedRealFrame m v x) ∧
      (∀x,(S*pairedRealFrame m v x).det=1) ∧
      (∀x,S*pairedRealFrame m v (x+1)=((-1:ℝ)^(m:ℤ)) • (S*pairedRealFrame m v x)) ∧
      HasProjectiveDegree (fun x=>S*pairedRealFrame m v x) (m:ℤ) := by
  obtain ⟨hc,hd,ha,hdeg⟩ := pairedRealFrame_degree_data m v hv hp he0 he hv0 hv1
  refine ⟨continuous_const.mul hc,?_,?_,projectiveDegree_left_constant S hS _ _ hdeg⟩
  · intro x
    rw [Matrix.det_mul,hS,hd,mul_one]
  · intro x
    rw [ha,Matrix.mul_smul]

end PaperUAMO.InteriorFrame

import PaperUAMO.InteriorRealNormalForm

noncomputable section
namespace PaperUAMO.InteriorNormalForm
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open PaperUAMO.FreeElliptic PaperUAMO.InteriorFrame
open PaperUAMO.SymmetricSplitting UAMODraft.QuantitativeOpening
open scoped Matrix.L2OpNorm

def freeSpin : Spin := ![1,0]

theorem normalized_component_bounds (v:Spin) {e:ℝ} (he0:0≤e) (he:e≤1/4)
    (h0:‖v 0-1‖≤e) (h1:‖v 1‖≤e) :
    ‖v 0/(Real.sqrt (profileSignature v):ℂ)-1‖≤8*e ∧
    ‖v 1/(Real.sqrt (profileSignature v):ℂ)‖≤2*e := by
  obtain ⟨hu,_,huclose⟩:=sqrt_signature_bounds v he0 he h0 h1
  have hupos : 0<Real.sqrt (profileSignature v) := by linarith
  constructor
  · rw [div_sub_one (Complex.ofReal_ne_zero.mpr hupos.ne'),norm_div,
      Complex.norm_real,Real.norm_eq_abs,abs_of_pos hupos]
    apply (div_le_iff₀ hupos).mpr
    have hnear : ‖v 0-(Real.sqrt (profileSignature v):ℂ)‖≤4*e := by
      have hh:=norm_sub_le (v 0-1) ((Real.sqrt (profileSignature v)-1:ℝ):ℂ)
      have heq : v 0-(Real.sqrt (profileSignature v):ℂ)=
        (v 0-1)-((Real.sqrt (profileSignature v)-1:ℝ):ℂ) := by push_cast;ring
      rw [heq]
      simp only [Complex.norm_real,Real.norm_eq_abs] at hh
      linarith
    nlinarith [mul_le_mul_of_nonneg_left hu (show 0≤8*e by positivity)]
  · rw [norm_div,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hupos]
    apply (div_le_iff₀ hupos).mpr
    nlinarith [mul_le_mul_of_nonneg_left hu (show 0≤2*e by positivity)]

theorem normalizedFrame_as_raw (v:Spin) (g:ℂ) :
    normalizedFrame v g=frameRaw (fun i=>v i/(Real.sqrt (profileSignature v):ℂ)) g := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [normalizedFrame,frameRaw,div_eq_mul_inv,Complex.star_def] <;> ring

theorem normalizedFrame_near_free (v:Spin) (g:ℂ) (hg:‖g‖=1)
    {e:ℝ} (he0:0≤e) (he:e≤1/4) (h0:‖v 0-1‖≤e) (h1:‖v 1‖≤e) (i j:Fin 2) :
    ‖normalizedFrame v g i j-normalizedFrame freeSpin g i j‖≤8*e := by
  obtain ⟨hn0,hn1⟩:=normalized_component_bounds v he0 he h0 h1
  have hn0star : ‖star (v 0/(Real.sqrt (profileSignature v):ℂ))-1‖≤8*e := by
    simpa only [star_sub,star_one] using (show ‖star (v 0/(Real.sqrt (profileSignature v):ℂ)-1)‖≤8*e by rwa [norm_star])
  rw [normalizedFrame_as_raw v g]
  have hf : normalizedFrame freeSpin g=!![g,0;0,star g] := by
    simp [normalizedFrame,profileSignature,freeSpin,frameRaw]
  rw [hf]
  fin_cases i <;> fin_cases j
  · simpa only [frameRaw,Matrix.of_apply,Fin.zero_eta,Fin.mk_one,Matrix.cons_val_zero,Matrix.cons_val_one,
      Matrix.cons_val_fin_one,←mul_sub_one,norm_mul,hg,one_mul] using hn0
  · simp only [frameRaw,Matrix.of_apply,Fin.zero_eta,Fin.mk_one,Matrix.cons_val_zero,Matrix.cons_val_one,
      Matrix.cons_val_fin_one,sub_zero,norm_mul,norm_star,hg,one_mul]
    linarith
  · simp only [frameRaw,Matrix.of_apply,Fin.zero_eta,Fin.mk_one,Matrix.cons_val_zero,Matrix.cons_val_one,
      Matrix.cons_val_fin_one,sub_zero,norm_mul,hg,one_mul]
    linarith
  · simpa only [frameRaw,Matrix.of_apply,Fin.zero_eta,Fin.mk_one,Matrix.cons_val_zero,Matrix.cons_val_one,
      Matrix.cons_val_fin_one,←mul_sub_one,←star_sub,star_one,norm_mul,norm_star,hg,one_mul]
      using hn0star

theorem pairedRealFrame_free (m:ℕ) (x:ℝ) :
    pairedRealFrame m (fun _=>freeSpin) x=rotation (Real.pi*(m:ℝ)*x) := by
  apply complexify_injective
  rw [complexify_pairedRealFrame,complexify_rotation]
  have hg : halfPhase m x=phase (Real.pi*(m:ℝ)*x) := rfl
  simp [normalizedFrame,profileSignature,freeSpin,frameRaw,phaseDiagonal,hg,phase_star]

theorem real_norm_error_between (T U:RMat) {ε:ℝ} (hε:0≤ε)
    (h:∀i j,‖complexify T i j-complexify U i j‖≤ε) : ‖T-U‖≤8*ε := by
  have hc : complexify (T-U)=complexify T-complexify U := by
    have hs:=complexify_add (T-U) U
    rw [sub_add_cancel] at hs
    exact eq_sub_iff_add_eq.mpr hs.symm
  have he : ∀i j,|(T-U) i j|≤2*ε := by
    intro i j
    have hh:=real_entry_error (T-U) 0 0 0 hε (by
      simpa only [hc,Complex.ofReal_zero,zero_smul,add_zero,Matrix.zero_apply,sub_zero,Matrix.sub_apply] using h) i j
    simpa only [zero_smul,add_zero,sub_zero] using hh
  have hb:=operator_norm_le_four_entries (T-U) (by positivity : 0≤2*ε) he
  linarith

theorem pairedRealFrame_proximity (m:ℕ) (v:ℝ→Spin) {e:ℝ} (he0:0≤e) (he:e≤1/4)
    (hv:∀x,‖v x 0-1‖≤e ∧ ‖v x 1‖≤e) (x:ℝ) :
    ‖pairedRealFrame m v x-rotation (Real.pi*(m:ℝ)*x)‖≤64*e := by
  rw [←pairedRealFrame_free]
  have hh:=real_norm_error_between (pairedRealFrame m v x)
    (pairedRealFrame m (fun _=>freeSpin) x) (by positivity : 0≤8*e)
    (by
      rw [complexify_pairedRealFrame,complexify_pairedRealFrame]
      exact normalizedFrame_near_free (v x) (halfPhase m x) (halfPhase_norm m x)
        he0 he (hv x).1 (hv x).2)
  linarith

theorem physicalFrame_proximity (S S₀:RMat) (m:ℕ) (v:ℝ→Spin) {e:ℝ}
    (he0:0≤e) (he:e≤1/4) (hv:∀x,‖v x 0-1‖≤e ∧ ‖v x 1‖≤e) (x:ℝ) :
    ‖physicalFrame S m v x-S₀*rotation (Real.pi*(m:ℝ)*x)‖≤
      64*‖S‖*e+‖S-S₀‖ := by
  let R:=rotation (Real.pi*(m:ℝ)*x)
  have hR : R∈unitary RMat := rotation_unitary _
  have heq : physicalFrame S m v x-S₀*R=
      S*(pairedRealFrame m v x-R)+(S-S₀)*R := by unfold physicalFrame;noncomm_ring
  rw [heq]
  calc
    _ ≤ ‖S*(pairedRealFrame m v x-R)‖+‖(S-S₀)*R‖ := norm_add_le _ _
    _ ≤ ‖S‖*(64*e)+‖S-S₀‖ := by
      rw [CStarRing.norm_mul_mem_unitary _ hR]
      exact add_le_add_right ((norm_mul_le _ _).trans
        (mul_le_mul_of_nonneg_left (pairedRealFrame_proximity m v he0 he hv x) (norm_nonneg S))) _
    _ = _ := by ring

end PaperUAMO.InteriorNormalForm

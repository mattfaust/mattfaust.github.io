import PaperUAMO.InteriorLeadingStep

noncomputable section
set_option maxHeartbeats 1000000
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology BigOperators

def leadingCoefficient (w q : ℂ) (V₀ : SpinMatrix) : ℕ → Fin 2 → ℂ
  | 0,j => if j=0 then 1 else 0
  | d+1,i => (2*Complex.I)⁻¹ * ∑ j : Fin 2,
      (V₀ i j / divisor w q i (-((d+1:ℕ):ℤ))) * leadingCoefficient w q V₀ d j

theorem branch_transition_analytic {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (p : Mode m) (hp : ¬(p.val.1=0 ∧ p.val.2=0)) (j : Fin 2) :
    AnalyticAt ℝ (fun lam => V (x lam (zeroMode m)).im p.val.2 j /
      denominator m w q (x lam) p.val.1 p.val.2) 0 := by
  have he : AnalyticAt ℝ (fun lam => x lam (zeroMode m)) 0 :=
    (ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).analyticAt _ |>.comp hxa
  have hi₀ : AnalyticAt ℝ (fun lam => (x lam (zeroMode m)).im) 0 :=
    (Complex.imCLM.analyticAt _).comp he
  have hi : AnalyticAt ℝ (fun lam => ((x lam (zeroMode m)).im:ℂ)) 0 :=
    (Complex.ofRealCLM.analyticAt _).comp hi₀
  have hr : AnalyticAt ℝ (fun lam => ((x lam (zeroMode m)).re:ℂ)) 0 :=
    (Complex.ofRealCLM.analyticAt _).comp ((Complex.reCLM.analyticAt _).comp he)
  have hv : AnalyticAt ℝ (fun lam => V (x lam (zeroMode m)).im p.val.2 j) 0 := by
    have hv₀ : AnalyticAt ℝ (fun t => V t p.val.2 j) 0 :=
      (ContinuousLinearMap.proj j : (Fin 2 → ℂ) →L[ℝ] ℂ).analyticAt _ |>.comp
        ((ContinuousLinearMap.proj p.val.2 : SpinMatrix →L[ℝ] (Fin 2 → ℂ)).analyticAt _ |>.comp hV)
    exact hv₀.comp_of_eq hi₀ (by simp [hx0])
  have hd : AnalyticAt ℝ (fun lam => denominator m w q (x lam) p.val.1 p.val.2) 0 := by
    unfold denominator
    split_ifs
    all_goals
      exact (analyticAt_const.mul
        (analyticAt_cexp.restrictScalars.comp (analyticAt_const.mul hi))).sub
          ((analyticAt_const.mul (analyticAt_const.sub hr)).mul analyticAt_const)
  have hd0 : denominator m w q (x 0) p.val.1 p.val.2≠0 := by
    rw [hx0,denominator_base]
    simpa only [diagonal,hp,if_false] using diagonal_ne_zero hw hq0 hq m hres p
  exact hv.div hd hd0

theorem branch_transition_order {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (p : Mode m) (hp : ¬(p.val.1=0 ∧ p.val.2=0)) (j : Fin 2) :
    (fun lam => V (x lam (zeroMode m)).im p.val.2 j /
        denominator m w q (x lam) p.val.1 p.val.2-
        V 0 p.val.2 j/divisor w q p.val.2 p.val.1)
      =O[nhds (0:ℝ)] (fun lam => lam) := by
  simpa only [hx0,Pi.zero_apply,Complex.zero_im,denominator_base,sub_zero] using
    (branch_transition_analytic hw hq0 hq m hres V hV x hx0 hxa p hp j).differentiableAt.isBigO_sub

theorem branch_negative_leading {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0)
    (d : ℕ) (hd : d<m) (i : Fin 2) :
    (fun lam => coefficient m (x lam) (-(d:ℤ)) i-
      leadingCoefficient w q (V 0) d i*(lam:ℂ)^d)
      =O[nhds (0:ℝ)] (fun lam => lam^(d+1)) := by
  induction d generalizing i with
  | zero =>
    fin_cases i
    · simpa [coefficient,leadingCoefficient] using
        (isBigO_zero (fun lam : ℝ => lam^(0+1)) (nhds (0:ℝ)) :
          (fun _ : ℝ => (0:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam^(0+1)))
    · simpa [leadingCoefficient] using branch_coefficient_isBigO x hx0 hxa 0 1 (by simp)
  | succ d ih =>
    let p : Mode m := ⟨(-((d+1:ℕ):ℤ),i),
      Finset.mem_Icc.mpr ⟨by omega,by omega⟩,by intro h; omega⟩
    have hp : ¬(p.val.1=0 ∧ p.val.2=0) := by intro h; dsimp [p] at h; omega
    have hkp : p.val.1+1=-(d:ℤ) := by dsimp [p]; omega
    have hkm : p.val.1-1=-((d+2:ℕ):ℤ) := by dsimp [p]; omega
    have hrec : ∀ᶠ (lam : ℝ) in nhds 0,
        coefficient m (x lam) p.val.1 i=(2*Complex.I)⁻¹*(lam:ℂ)*
          ∑ j : Fin 2, (V (x lam (zeroMode m)).im i j /
            denominator m w q (x lam) p.val.1 i) *
          (coefficient m (x lam) (-(d:ℤ)) j-coefficient m (x lam) (-((d+2:ℕ):ℤ)) j) := by
      filter_upwards [branch_recurrence hw hq0 hq m hres V x hx0 hxa.continuousAt hxe p hp] with lam h
      change coefficient m (x lam) p.val.1 i = _ at h
      rw [h,hkp,hkm,Fin.sum_univ_two,Fin.sum_univ_two]
      ring
    have hstep := leading_vector_step
      (fun lam => coefficient m (x lam) p.val.1 i)
      (fun j lam => coefficient m (x lam) (-(d:ℤ)) j)
      (fun j lam => coefficient m (x lam) (-((d+2:ℕ):ℤ)) j)
      (fun j lam => V (x lam (zeroMode m)).im i j / denominator m w q (x lam) p.val.1 i)
      ((2*Complex.I)⁻¹)
      (fun j => V 0 i j/divisor w q i p.val.1)
      (leadingCoefficient w q (V 0) d) d hrec (fun j => ih (by omega) j)
      (fun j => branch_coefficient_order hw hq0 hq m hres V hV.continuousAt x hx0 hxa hxe
        (d+1) (-((d+2:ℕ):ℤ)) j (by rw [abs_neg,abs_of_nonneg (by positivity)]; omega))
      (fun j => (branch_transition_analytic hw hq0 hq m hres V hV x hx0 hxa p hp j).continuousAt.isBigO_one ℝ)
      (fun j => branch_transition_order hw hq0 hq m hres V hV x hx0 hxa p hp j)
    simpa only [p,leadingCoefficient,Nat.succ_eq_add_one,Nat.add_assoc] using hstep

end PaperUAMO.InteriorSeed

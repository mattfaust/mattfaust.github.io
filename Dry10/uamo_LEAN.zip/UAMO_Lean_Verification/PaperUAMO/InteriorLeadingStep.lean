import PaperUAMO.InteriorOrders

noncomputable section
namespace PaperUAMO.InteriorSeed
open Asymptotics Filter
open scoped Topology BigOperators

theorem leading_vector_step
    (a : ℝ → ℂ) (b c : Fin 2 → ℝ → ℂ) (B : Fin 2 → ℝ → ℂ)
    (κ : ℂ) (B₀ v : Fin 2 → ℂ) (d : ℕ)
    (hrec : ∀ᶠ lam in nhds 0, a lam=κ*(lam:ℂ)*∑ j : Fin 2,
      B j lam*(b j lam-c j lam))
    (hb : ∀ j, (fun lam => b j lam-v j*(lam:ℂ)^d)
      =O[nhds (0:ℝ)] (fun lam => lam^(d+1)))
    (hc : ∀ j, c j =O[nhds (0:ℝ)] (fun lam => lam^(d+1)))
    (hB : ∀ j, B j =O[nhds (0:ℝ)] (fun _ => (1:ℝ)))
    (hB₀ : ∀ j, (fun lam => B j lam-B₀ j) =O[nhds (0:ℝ)] (fun lam => lam)) :
    (fun lam => a lam-(κ*∑ j : Fin 2, B₀ j*v j)*(lam:ℂ)^(d+1))
      =O[nhds (0:ℝ)] (fun lam => lam^(d+2)) := by
  have hp : (fun lam : ℝ => (lam:ℂ)^d) =O[nhds (0:ℝ)] (fun lam => lam^d) :=
    isBigO_of_le _ (fun lam => by simp [norm_pow])
  have he (j : Fin 2) : (fun lam =>
      B j lam*(b j lam-v j*(lam:ℂ)^d) +
      (B j lam-B₀ j)*v j*(lam:ℂ)^d-B j lam*c j lam)
      =O[nhds (0:ℝ)] (fun lam => lam^(d+1)) := by
    have h1 := (hB j).mul (hb j)
    have h2 := ((hB₀ j).const_mul_left (v j)).mul hp
    have h3 := (hB j).mul (hc j)
    simp only [one_mul] at h1 h3
    have h2' : (fun lam => (B j lam-B₀ j)*v j*(lam:ℂ)^d)
        =O[nhds (0:ℝ)] (fun lam => lam^(d+1)) := by
      simpa only [pow_succ,mul_comm] using h2
    exact (h1.add h2').sub h3
  have hs := IsBigO.sum (s:=Finset.univ) (fun j _ => he j)
  have hl : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
    isBigO_of_le _ (fun lam => by simp)
  have h := (hl.mul hs).const_mul_left κ
  have heq : ∀ᶠ (lam : ℝ) in nhds 0,
      κ*((lam:ℂ)*∑ j : Fin 2,
        (B j lam*(b j lam-v j*(lam:ℂ)^d) +
        (B j lam-B₀ j)*v j*(lam:ℂ)^d-B j lam*c j lam))=
      a lam-(κ*∑ j : Fin 2, B₀ j*v j)*(lam:ℂ)^(d+1) := by
    filter_upwards [hrec] with lam hrec
    rw [hrec,Fin.sum_univ_two,Fin.sum_univ_two,Fin.sum_univ_two,pow_succ]
    ring
  have ht := h.congr' heq EventuallyEq.rfl
  simpa only [show d+2=(d+1)+1 by omega,pow_succ,mul_comm] using ht

end PaperUAMO.InteriorSeed

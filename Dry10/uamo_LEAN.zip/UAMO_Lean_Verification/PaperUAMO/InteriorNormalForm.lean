import UAMODraft.ProfileEstimates
import UAMODraft.DiagonalEstimate
import UAMO.BoundarySeedPowerControl

noncomputable section
namespace PaperUAMO.InteriorNormalForm
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed

abbrev Spin := Fin 2 → ℂ
abbrev Mat := CMV.TransferMatrix

def transformed (m : ℕ) (α lam : ℝ) (M : ℝ → Mat) (v : ℝ → Spin) (x : ℝ) : Mat :=
  normalizedFrameInverse (v (x+α)) (halfPhase m (x+α))*
    ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M x)*
      normalizedFrame (v x) (halfPhase m x)

def scalarDiagonal (α lam σ s : ℝ) (v : ℝ → Spin) (x : ℝ) : ℝ :=
  σ*s*Real.sqrt (profileSignature (v (x+α)))/
    (realTransferDenominator lam (2*Real.pi*x)*Real.sqrt (profileSignature (v x)))

def productDenominator (α lam : ℝ) (v : ℝ → Spin) (x : ℝ) : ℝ :=
  realTransferDenominator lam (2*Real.pi*x)*Real.sqrt (profileSignature (v x))*
    Real.sqrt (profileSignature (v (x+α)))

def residual (α s : ℝ) (w : ℂ) (M : ℝ → Mat) (v : ℝ → Spin) (x : ℝ) : Spin :=
  M x*ᵥv x-(w*(s:ℂ)) • v (x+α)

theorem matrix_eq_conjugateMatrix (M : Mat)
    (hM : M 1 1=star (M 0 0) ∧ M 0 1=star (M 1 0)) :
    M=conjugateMatrix (M 0 0) (M 1 0) := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [conjugateMatrix,hM.1,hM.2]

theorem transformed_residual (m : ℕ) (α lam σ s : ℝ) (w : ℂ)
    (M : ℝ → Mat) (v : ℝ → Spin) (x : ℝ)
    (hw : w=(σ:ℂ)*halfPhase m α)
    (hM : M x 1 1=star (M x 0 0) ∧ M x 0 1=star (M x 1 0))
    (hp : 0<profileSignature (v (x+α))) :
    transformed m α lam M v x=(scalarDiagonal α lam σ s v x:ℂ) • 1+
      ((realTransferDenominator lam (2*Real.pi*x)*
        Real.sqrt (profileSignature (v x)):ℝ):ℂ)⁻¹ •
      (normalizedFrameInverse (v (x+α)) (halfPhase m (x+α))*
        frameRaw (residual α s w M v x) (halfPhase m x)) := by
  have hrepr := matrix_eq_conjugateMatrix (M x) hM
  have he : conjugateMatrix (M x 0 0) (M x 1 0)*ᵥv x=
      (w*(s:ℂ)) • v (x+α)+residual α s w M v x := by
    rw [←hrepr]
    unfold residual
    abel
  have hc : halfPhase m x*(w*(s:ℂ))=((σ*s:ℝ):ℂ)*halfPhase m (x+α) := by
    rw [hw,halfPhase_add,Complex.ofReal_mul]
    ring
  have h := normalizedFrame_residual_conjugacy (M x 0 0) (M x 1 0)
    (v x) (v (x+α)) (residual α s w M v x) (halfPhase m x) (halfPhase m (x+α))
    (w*(s:ℂ)) (σ*s) (realTransferDenominator lam (2*Real.pi*x))
    (halfPhase_norm m (x+α)) hp he hc
  simpa only [transformed,scalarDiagonal,←hrepr] using h

theorem productDenominator_bounds (α : ℝ) {lam : ℝ}
    (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1/2) (v : ℝ → Spin) (x : ℝ)
    {e : ℝ} (he0 : 0 ≤ e) (he : e ≤ 1/4)
    (hv : ∀y,‖v y 0-1‖ ≤ e ∧ ‖v y 1‖ ≤ e) :
    1/8 ≤ productDenominator α lam v x ∧
      |productDenominator α lam v x-1| ≤ 4*lam+9*e := by
  have hsig (y:ℝ) := sqrt_signature_bounds (v y) he0 he (hv y).1 (hv y).2
  have hp := transferDenominator_bounds hlam hlam1 (2*Real.pi*x)
  have h := product_near_one (δ:=1) (e:=0) (g:=3*e)
    (by norm_num) hp.1 hp.2.1 (hsig x).1 (hsig x).2.1
    (hsig (x+α)).1 (hsig (x+α)).2.1 (by norm_num) hp.2.2
    (hsig x).2.2 (hsig (x+α)).2.2
  simpa only [productDenominator,one_mul,mul_zero,zero_add,mul_assoc,
    show (3:ℝ)*3=9 by norm_num,←mul_assoc] using h

theorem profile_div_denominator_bound (α : ℝ) {lam : ℝ}
    (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1/2) (v : ℝ → Spin) (x : ℝ)
    {e : ℝ} (he0 : 0 ≤ e) (he : e ≤ 1/4)
    (hv : ∀y,‖v y 0-1‖ ≤ e ∧ ‖v y 1‖ ≤ e) :
    ‖v (x+α) 0/(productDenominator α lam v x:ℂ)-1‖ ≤ 32*lam+80*e := by
  obtain ⟨hK,hKd⟩ := productDenominator_bounds α hlam hlam1 v x he0 he hv
  have hK0 : 0<productDenominator α lam v x := by linarith
  have hw := (hv (x+α)).1
  rw [div_sub_one (Complex.ofReal_ne_zero.mpr hK0.ne'),norm_div,
    Complex.norm_real,Real.norm_eq_abs,abs_of_pos hK0]
  apply (div_le_iff₀ hK0).mpr
  have hn : ‖v (x+α) 0-(productDenominator α lam v x:ℂ)‖ ≤ 4*lam+10*e := by
    have heq : v (x+α) 0-(productDenominator α lam v x:ℂ)=
        (v (x+α) 0-1)-((productDenominator α lam v x-1:ℝ):ℂ) := by
      push_cast
      ring
    rw [heq]
    have hh := (norm_sub_le _ _).trans (add_le_add hw (show
      ‖((productDenominator α lam v x-1:ℝ):ℂ)‖ ≤ 4*lam+9*e by
      simpa only [Complex.norm_real,Real.norm_eq_abs] using hKd))
    linarith
  nlinarith [mul_le_mul_of_nonneg_left hK (show 0 ≤ 32*lam+80*e by positivity)]

theorem normalizedFrameInverse_SU11 (v : Spin) (g : ℂ) (hg : ‖g‖=1)
    (hv : 0<profileSignature v) : SU11Form (normalizedFrameInverse v g) := by
  refine ⟨?_,?_,?_⟩
  · simp [normalizedFrameInverse,frameAdjugate,Complex.star_def]
  · simp [normalizedFrameInverse,frameAdjugate,Complex.star_def]
  · have h := congrArg Matrix.det (normalizedFrame_mul_inverse v g hg hv)
    rw [Matrix.det_mul,normalizedFrame_det v g hg hv,one_mul,Matrix.det_one] at h
    exact h

theorem transformed_SU11 (m : ℕ) (α lam : ℝ) (M : ℝ → Mat) (v : ℝ → Spin)
    (x : ℝ) (hv : 0<profileSignature (v x)) (hv' : 0<profileSignature (v (x+α)))
    (hM : SU11Form ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M x)) :
    SU11Form (transformed m α lam M v x) :=
  SU11Form_mul (SU11Form_mul (normalizedFrameInverse_SU11 _ _ (halfPhase_norm _ _) hv') hM)
    (normalizedFrame_SU11 _ _ (halfPhase_norm _ _) hv)

end PaperUAMO.InteriorNormalForm

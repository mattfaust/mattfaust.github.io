import PaperUAMO.InteriorNormalForm

noncomputable section
namespace PaperUAMO.InteriorNormalForm
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed

theorem transformed_first_column (m : ℕ) (α σ s : ℝ) (z c : ℂ)
    {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1/2)
    (M : ℝ → Mat) (v : ℝ → Spin) (x : ℝ)
    (hz : z=(σ:ℂ)*halfPhase m α)
    (hM : M x 1 1=star (M x 0 0) ∧ M x 0 1=star (M x 1 0))
    {P R : ℝ} (hP : 0 ≤ P) (hsmall : P*lam ≤ 1/4)
    (hv : ∀y,‖v y 0-1‖ ≤ P*lam ∧ ‖v y 1‖ ≤ P*lam)
    (hr : ∀i:Fin 2,‖residual α s z M v x i-
      (if i=1 then c*(lam:ℂ)^m*(weylPhase x)^(-(m:ℤ)) else 0)‖ ≤ R*lam^(m+1)) :
    let η:=c*halfPhase m α
    let C:=24*R+(32+88*P)*‖η‖
    ‖transformed m α lam M v x 0 0-(scalarDiagonal α lam σ s v x:ℂ)‖ ≤ C*lam^(m+1) ∧
    ‖transformed m α lam M v x 1 0-(lam:ℂ)^m*η‖ ≤ C*lam^(m+1) := by
  let w:=v (x+α)
  let r:=residual α s z M v x
  let η:=c*halfPhase m α
  let L:=c*(lam:ℂ)^m*(weylPhase x)^(-(m:ℤ))
  let p:=realTransferDenominator lam (2*Real.pi*x)
  let u:=Real.sqrt (profileSignature (v x))
  let K:=productDenominator α lam v x
  have hsig (y:ℝ) := profileSignature_bounds (v y) (mul_nonneg hP hlam)
    hsmall (hv y).1 (hv y).2
  have hw0d : ‖w 0-1‖ ≤ P*lam := (hv (x+α)).1
  have hw1 : ‖w 1‖ ≤ P*lam := (hv (x+α)).2
  have hw0 : ‖w 0‖ ≤ 2 := by
    have hh:=norm_add_le (w 0-1) (1:ℂ)
    rw [sub_add_cancel,norm_one] at hh
    linarith
  have hw1b : ‖w 1‖ ≤ 1 := by linarith
  have hK := (productDenominator_bounds α hlam hlam1 v x (mul_nonneg hP hlam) hsmall hv).1
  have hdiv := profile_div_denominator_bound α hlam hlam1 v x (mul_nonneg hP hlam) hsmall hv
  have hL : ‖L‖ ≤ ‖η‖*lam^m := by
    simp only [L,η,norm_mul,norm_pow,norm_zpow,halfPhase_norm,weylPhase_norm,
      one_zpow,mul_one,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hlam]
    exact le_refl _
  have hphase : halfPhase m x*halfPhase m (x+α)*L/(K:ℂ)=((lam^m:ℝ):ℂ)*η/(K:ℂ) := by
    have hh:=halfPhase_fourier_cancel α x m
    dsimp [L,η]
    push_cast
    congr 1
    linear_combination (c*(lam:ℂ)^m)*hh
  have hb:=residual_entry_bounds w r (halfPhase m x) (halfPhase m (x+α)) L η
    (p:=p) (u:=u) (K:=K) (Q:=K) (E:=R*lam^(m+1)) (e:=P*lam) (t:=lam^m)
    (b:=32*lam+80*(P*lam)) rfl hK (halfPhase_norm m x) (halfPhase_norm m (x+α))
    hw0 hw1b hw1
    (by simpa only [r,show (0:Fin 2)≠1 by decide,if_false,sub_zero] using hr 0)
    (by simpa only [r,L,if_true] using hr 1)
    hL (pow_nonneg hlam _) hphase hdiv
  have hrepr:=transformed_residual m α lam σ s z M v x hz hM
    (by have hh:=(hsig (x+α)).1;linarith)
  have h00 : transformed m α lam M v x 0 0-(scalarDiagonal α lam σ s v x:ℂ)=
      transportResidual p u w r (halfPhase m x) (halfPhase m (x+α)) 0 0 := by
    rw [hrepr]
    simp [transportResidual,p,u,w,r,Matrix.one_apply]
  have h10 : transformed m α lam M v x 1 0=
      transportResidual p u w r (halfPhase m x) (halfPhase m (x+α)) 1 0 := by
    rw [hrepr]
    simp [transportResidual,p,u,w,r,Matrix.one_apply]
  dsimp only
  rw [h00,h10]
  constructor
  · have hh:=hb.1
    dsimp only [η] at hh
    rw [pow_succ] at hh ⊢
    nlinarith [mul_nonneg (norm_nonneg (c*halfPhase m α))
      (mul_nonneg (pow_nonneg hlam m) hlam),
      mul_nonneg (norm_nonneg (c*halfPhase m α))
      (mul_nonneg (mul_nonneg hP (pow_nonneg hlam m)) hlam)]
  · have hh:=hb.2
    simp only [Complex.ofReal_pow] at hh
    dsimp only [η] at hh
    rw [pow_succ] at hh ⊢
    nlinarith [mul_nonneg (norm_nonneg (c*halfPhase m α))
      (mul_nonneg (mul_nonneg hP (pow_nonneg hlam m)) hlam)]

theorem transformed_entry_bound (m : ℕ) (α σ s : ℝ) (z c : ℂ)
    {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1/2)
    (M : ℝ → Mat) (v : ℝ → Spin) (x : ℝ)
    (hz : z=(σ:ℂ)*halfPhase m α)
    (hM : M x 1 1=star (M x 0 0) ∧ M x 0 1=star (M x 1 0))
    (hSU : SU11Form ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M x))
    {P R : ℝ} (hP : 0 ≤ P) (hsmall : P*lam ≤ 1/4)
    (hv : ∀y,‖v y 0-1‖ ≤ P*lam ∧ ‖v y 1‖ ≤ P*lam)
    (hr : ∀i:Fin 2,‖residual α s z M v x i-
      (if i=1 then c*(lam:ℂ)^m*(weylPhase x)^(-(m:ℤ)) else 0)‖ ≤ R*lam^(m+1))
    (i j : Fin 2) :
    ‖transformed m α lam M v x i j-
      ((scalarDiagonal α lam σ s v x:ℂ) • (1:Mat)+
        ((lam^m:ℝ):ℂ) • hermitianSeed (c*halfPhase m α)) i j‖ ≤
      (24*R+(32+88*P)*‖c*halfPhase m α‖)*lam^(m+1) := by
  obtain ⟨h00,h10⟩:=transformed_first_column m α σ s z c hlam hlam1 M v x hz hM hP hsmall hv hr
  have hpos (y:ℝ) : 0<profileSignature (v y) := by
    have hh:=(profileSignature_bounds (v y) (mul_nonneg hP hlam)
      hsmall (hv y).1 (hv y).2).1
    linarith
  have hA:=transformed_SU11 m α lam M v x (hpos x) (hpos (x+α)) hSU
  fin_cases i <;> fin_cases j <;>
    simp [-norm_mul,Matrix.add_apply,Matrix.smul_apply,smul_eq_mul,hermitianSeed,Matrix.one_apply,
      Complex.ofReal_pow]
  · simpa only [norm_mul] using h00
  · calc
      _ = ‖star (transformed m α lam M v x 1 0-(lam:ℂ)^m*(c*halfPhase m α))‖ := by
        rw [hA.2.1]
        simp only [Complex.star_def,map_sub,map_mul,map_pow,Complex.conj_ofReal]
      _ = _ := norm_star _
      _ ≤ _ := by simpa only [norm_mul] using h10
  · simpa only [norm_mul] using h10
  · calc
      _ = ‖star (transformed m α lam M v x 0 0-(scalarDiagonal α lam σ s v x:ℂ))‖ := by
        rw [hA.1]
        simp only [Complex.star_def,map_sub,Complex.conj_ofReal]
      _ = _ := norm_star _
      _ ≤ _ := by simpa only [norm_mul] using h00

theorem scalarDiagonal_near_sign (α σ s : ℝ) {lam : ℝ}
    (hσ : |σ|=1) (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1/2)
    (v : ℝ → Spin) (x : ℝ) {A P : ℝ} (hA : 0 ≤ A) (hP : 0 ≤ P)
    (hsmall : P*lam ≤ 1/4)
    (hv : ∀y,‖v y 0-1‖ ≤ P*lam ∧ ‖v y 1‖ ≤ P*lam)
    (hs : |s-1| ≤ A*lam) :
    |scalarDiagonal α lam σ s v x-σ| ≤ (8*A+24*P+8)*lam := by
  have hsig (y:ℝ):=sqrt_signature_bounds (v y) (mul_nonneg hP hlam)
    hsmall (hv y).1 (hv y).2
  have hp:=transferDenominator_bounds hlam hlam1 (2*Real.pi*x)
  exact scalar_diagonal_near_sign hσ hlam hA hP hp.1
    (hsig x).1 (hsig x).2.1 (hsig (x+α)).1 (hsig (x+α)).2.1 hp.2.2
    (hsig x).2.2 (hsig (x+α)).2.2 hs

end PaperUAMO.InteriorNormalForm

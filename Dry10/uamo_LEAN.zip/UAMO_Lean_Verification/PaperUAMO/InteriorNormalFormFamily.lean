import PaperUAMO.InteriorNormalFormBounds

noncomputable section
namespace PaperUAMO.InteriorNormalForm
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed

theorem paired_profile_normal_form (m : ℕ) (hm : 0<m) (α σ : ℝ) (z c : ℂ)
    (hσ : |σ|=1) (hz : z=(σ:ℂ)*halfPhase m α)
    (M : ℝ → ℝ → Mat) (v : ℝ → ℝ → Spin) (s : ℝ → ℝ)
    (A P R δ : ℝ) (hA : 0 ≤ A) (hP : 0 ≤ P) (hR : 0<R) (hδ : 0<δ)
    (hM : ∀lam,0 ≤ lam → lam<δ → ∀x,
      M lam x 1 1=star (M lam x 0 0) ∧ M lam x 0 1=star (M lam x 1 0))
    (hSU : ∀lam,0 ≤ lam → lam<δ → ∀x,
      SU11Form ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M lam x))
    (hv : ∀lam,0 ≤ lam → lam<δ → ∀x,
      ‖v lam x 0-1‖ ≤ P*lam ∧ ‖v lam x 1‖ ≤ P*lam)
    (hs : ∀lam,0 ≤ lam → lam<δ → |s lam-1| ≤ A*lam)
    (hr : ∀lam,0 ≤ lam → lam<δ → ∀x i,
      ‖residual α (s lam) z (M lam) (v lam) x i-
        (if i=1 then c*(lam:ℂ)^m*(weylPhase x)^(-(m:ℤ)) else 0)‖ ≤ R*lam^(m+1)) :
    ∃K ε:ℝ,0<K ∧ 0<ε ∧ ε ≤ δ ∧ ∀lam,0 ≤ lam → lam<ε →
      lam<1 ∧ (∀x,0<profileSignature (v lam x)) ∧
      (∀x,SU11Form (transformed m α lam (M lam) (v lam) x)) ∧
      ∀x i j,‖transformed m α lam (M lam) (v lam) x i j-
        ((σ:ℂ) • (1:Mat)+((lam^m:ℝ):ℂ) • hermitianSeed (c*halfPhase m α)) i j‖ ≤
          K*lam^(m+1) := by
  let η:=c*halfPhase m α
  let D:=8*A+24*P+8
  let C:=24*R+(32+88*P)*‖η‖
  let K:=‖η‖^2+(7+2*‖η‖)*C
  have hD : 0 ≤ D := by dsimp [D];positivity
  have hC : 0<C := by dsimp [C];positivity
  have hK : 0<K := by dsimp [K];positivity
  let ε:=min δ (min (1/2) (min (1/(4*(P+1))) (min (1/(2*(D+1))) (1/(C+1)))))
  have hε : 0<ε := by dsimp [ε];positivity
  refine ⟨K,ε,hK,hε,min_le_left _ _,?_⟩
  intro lam hlam hsmall
  have hh:=lt_min_iff.mp hsmall
  have hh':=lt_min_iff.mp hh.2
  have hp:=lt_min_iff.mp hh'.2
  have hdc:=lt_min_iff.mp hp.2
  have hpl : P*lam ≤ 1/4 := by
    have h:=(lt_div_iff₀ (show 0<4*(P+1) by positivity)).mp hp.1
    nlinarith only [h,hlam]
  have hdl : D*lam ≤ 1/2 := by
    have h:=(lt_div_iff₀ (show 0<2*(D+1) by positivity)).mp hdc.1
    dsimp only [D] at h ⊢
    nlinarith only [h,hlam]
  have hcl : C*lam ≤ 1 := by
    have h:=(lt_div_iff₀ (show 0<C+1 by positivity)).mp hdc.2
    nlinarith only [h,hlam]
  have hpos (x:ℝ) : 0<profileSignature (v lam x) := by
    have h:=(profileSignature_bounds (v lam x) (mul_nonneg hP hlam) hpl
      (hv lam hlam hh.1 x).1 (hv lam hlam hh.1 x).2).1
    linarith
  have hSU' (x:ℝ) := transformed_SU11 m α lam (M lam) (v lam) x
    (hpos x) (hpos (x+α)) (hSU lam hlam hh.1 x)
  have hlam1 : lam<1 := by linarith [hh'.1]
  refine ⟨hlam1,hpos,hSU',?_⟩
  intro x i j
  have hentry:=transformed_entry_bound m α σ (s lam) z c hlam hh'.1.le
    (M lam) (v lam) x hz (hM lam hlam hh.1 x) (hSU lam hlam hh.1 x)
    hP hpl (hv lam hlam hh.1) (hr lam hlam hh.1 x)
  have hnear:=(scalarDiagonal_near_sign α σ (s lam) hσ hlam hh'.1.le
    (v lam) x hA hP hpl (hv lam hlam hh.1) (hs lam hlam hh.1)).trans hdl
  exact scalar_seed_power_entry_control (transformed m α lam (M lam) (v lam) x)
    (scalarDiagonal α lam σ (s lam) (v lam) x) σ lam C η m hm hlam hlam1.le
    hC.le hcl hσ hnear (hSU' x).2.2 hentry i j

end PaperUAMO.InteriorNormalForm

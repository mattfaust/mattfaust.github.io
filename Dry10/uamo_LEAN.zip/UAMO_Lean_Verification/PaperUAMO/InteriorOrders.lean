import PaperUAMO.InteriorAnalyticBranch
import UAMODraft.Center

noncomputable section
set_option maxHeartbeats 800000
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology BigOperators

def denominator (m : ℕ) (w q : ℂ) (x : Variables m) (k : ℤ) (j : Fin 2) : ℂ :=
  (if j=0 then w*Complex.exp (Complex.I*(x (zeroMode m)).im)
    else w⁻¹*Complex.exp (-Complex.I*(x (zeroMode m)).im)) -
      w*(1-(x (zeroMode m)).re)*q^k

theorem denominator_base (m : ℕ) (w q : ℂ) (k : ℤ) (j : Fin 2) :
    denominator m w q 0 k j=divisor w q j k := by
  simp [denominator,divisor,diagonalValue]

theorem denominator_continuousAt {m : ℕ} (w q : ℂ)
    (x : ℝ → Variables m) (hx : ContinuousAt x 0) (k : ℤ) (j : Fin 2) :
    ContinuousAt (fun lam => denominator m w q (x lam) k j) 0 := by
  have he : ContinuousAt (fun lam => x lam (zeroMode m)) 0 :=
    (continuous_apply _).continuousAt.comp hx
  unfold denominator
  split_ifs <;> fun_prop

theorem coefficient_outside (m : ℕ) (x : Variables m) (k : ℤ) (j : Fin 2)
    (hk : k∉Finset.Icc (-(m:ℤ)) (m:ℤ)) : coefficient m x k j=0 := by
  have hk0 : k≠0 := by
    intro h
    apply hk
    subst k
    exact Finset.mem_Icc.mpr ⟨by omega,by omega⟩
  simp [coefficient,hk0,hk]

@[simp] theorem coefficient_omitted (m : ℕ) (x : Variables m) :
    coefficient m x (-(m:ℤ)) 1=0 := by simp [coefficient]

theorem branch_coefficient_continuousAt {m : ℕ} (x : ℝ → Variables m)
    (hx : ContinuousAt x 0) (k : ℤ) (j : Fin 2) :
    ContinuousAt (fun lam => coefficient m (x lam) k j) 0 :=
  (coefficient_hasFDerivAt m k j (x 0)).continuousAt.comp hx

theorem branch_coefficient_isBigO {m : ℕ} (x : ℝ → Variables m)
    (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0) (k : ℤ) (j : Fin 2)
    (hk : ¬(k=0 ∧ j=0)) :
    (fun lam => coefficient m (x lam) k j) =O[nhds (0:ℝ)] (fun lam => lam) := by
  have ha : AnalyticAt ℝ (fun lam => coefficient m (x lam) k j) 0 := by
    unfold coefficient
    simp only [hk,if_false]
    split_ifs
    · exact ((ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).analyticAt _).comp hxa
    · exact analyticAt_const
  have hzero : coefficient m (x 0) k j=0 := by simp [hx0,coefficient,hk]
  simpa only [hzero,sub_zero] using ha.differentiableAt.isBigO_sub

theorem branch_matrix_continuousAt {m : ℕ} (x : ℝ → Variables m)
    (hx0 : x 0=0) (hx : ContinuousAt x 0) (V : ℝ → SpinMatrix)
    (hV : ContinuousAt V 0) (i j : Fin 2) :
    ContinuousAt (fun lam => V (x lam (zeroMode m)).im i j) 0 := by
  have hi : ContinuousAt (fun lam => (x lam (zeroMode m)).im) 0 :=
    Complex.continuous_im.continuousAt.comp ((continuous_apply _).continuousAt.comp hx)
  have he : (x 0 (zeroMode m)).im=0 := by simp [hx0]
  exact (continuous_apply j).continuousAt.comp
    ((continuous_apply i).continuousAt.comp (hV.comp_of_eq hi he))

theorem branch_inverse_isBigO {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hx : ContinuousAt x 0)
    (p : Mode m) (hp : ¬(p.val.1=0 ∧ p.val.2=0)) :
    (fun lam => (denominator m w q (x lam) p.val.1 p.val.2)⁻¹)
      =O[nhds (0:ℝ)] (fun _ => (1:ℝ)) := by
  have hd : denominator m w q (x 0) p.val.1 p.val.2≠0 := by
    rw [hx0,denominator_base]
    simpa only [diagonal,hp,if_false] using diagonal_ne_zero hw hq0 hq m hres p
  exact ((denominator_continuousAt w q x hx _ _).inv₀ hd).isBigO_one ℝ

theorem branch_recurrence {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (x : ℝ → Variables m) (hx0 : x 0=0) (hx : ContinuousAt x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0)
    (p : Mode m) (hp : ¬(p.val.1=0 ∧ p.val.2=0)) :
    ∀ᶠ lam in nhds 0, coefficient m (x lam) p.val.1 p.val.2=
      -(2*Complex.I)⁻¹*(lam:ℂ)*
        (∑ j : Fin 2, V (x lam (zeroMode m)).im p.val.2 j *
          (coefficient m (x lam) (p.val.1-1) j-coefficient m (x lam) (p.val.1+1) j)) /
        denominator m w q (x lam) p.val.1 p.val.2 := by
  have hd : denominator m w q (x 0) p.val.1 p.val.2≠0 := by
    rw [hx0,denominator_base]
    simpa only [diagonal,hp,if_false] using diagonal_ne_zero hw hq0 hq m hres p
  filter_upwards [hxe,(denominator_continuousAt w q x hx _ _).eventually_ne hd] with lam he hd'
  have h := congrFun he p
  change denominator m w q (x lam) p.val.1 p.val.2*coefficient m (x lam) p.val.1 p.val.2+
    (2*Complex.I)⁻¹*(lam:ℂ)*(∑ j : Fin 2, V (x lam (zeroMode m)).im p.val.2 j *
      (coefficient m (x lam) (p.val.1-1) j-coefficient m (x lam) (p.val.1+1) j))=0 at h
  apply (eq_div_iff hd').mpr
  linear_combination h

theorem branch_coefficient_order {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : ContinuousAt V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0)
    (d : ℕ) (k : ℤ) (s : Fin 2) (hd : (d:ℤ)≤|k|) :
    (fun lam => coefficient m (x lam) k s) =O[nhds (0:ℝ)] (fun lam => lam^d) := by
  induction d generalizing k s with
  | zero =>
    simpa only [pow_zero] using (branch_coefficient_continuousAt x hxa.continuousAt k s).isBigO_one ℝ
  | succ d ih =>
    by_cases hki : k∈Finset.Icc (-(m:ℤ)) (m:ℤ)
    · by_cases hom : k=-(m:ℤ) ∧ s=1
      · obtain ⟨rfl,rfl⟩ := hom
        simp only [coefficient_omitted]
        exact isBigO_zero _ _
      have hk : k≠0 := by rintro rfl; simp only [abs_zero] at hd; omega
      have hsum : (fun lam => ∑ j : Fin 2, V (x lam (zeroMode m)).im s j *
          (coefficient m (x lam) (k-1) j-coefficient m (x lam) (k+1) j))
          =O[nhds (0:ℝ)] (fun lam => lam^d) := by
        apply IsBigO.sum
        intro j _
        have hminus := ih (k-1) j (by
          have h := abs_add (k-1) 1
          norm_num at h
          omega)
        have hplus := ih (k+1) j (by
          have h := abs_sub (k+1) 1
          norm_num at h
          omega)
        have hv := (branch_matrix_continuousAt x hx0 hxa.continuousAt V hV s j).isBigO_one ℝ
        simpa only [one_mul] using hv.mul (hminus.sub hplus)
      have hlam : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
        isBigO_of_le _ (fun lam => by simp)
      let p : Mode m := ⟨(k,s),hki,hom⟩
      have hp : ¬(p.val.1=0 ∧ p.val.2=0) := fun h => hk h.1
      have hInv := branch_inverse_isBigO hw hq0 hq m hres x hx0 hxa.continuousAt p hp
      have hbound := ((hlam.mul hsum).const_mul_left (-(2*Complex.I)⁻¹)).mul hInv
      have hbound' : (fun lam => -(2*Complex.I)⁻¹*(lam:ℂ)*
          (∑ j : Fin 2, V (x lam (zeroMode m)).im s j *
            (coefficient m (x lam) (k-1) j-coefficient m (x lam) (k+1) j)) /
          denominator m w q (x lam) k s) =O[nhds (0:ℝ)] (fun lam => lam^(d+1)) := by
        simpa only [p,div_eq_mul_inv,mul_one,pow_succ,mul_assoc,mul_left_comm,mul_comm] using hbound
      have hrec := branch_recurrence hw hq0 hq m hres V x hx0 hxa.continuousAt hxe p hp
      exact hbound'.congr' (hrec.mono fun _ he => he.symm) EventuallyEq.rfl
    · have heq : (fun lam => coefficient m (x lam) k s)=(fun _ : ℝ => (0:ℂ)) := by
        funext lam
        exact coefficient_outside m (x lam) k s hki
      rw [heq]
      exact isBigO_zero _ _

end PaperUAMO.InteriorSeed

import PaperUAMO.FreeEllipticSU11

noncomputable section
namespace PaperUAMO.FreeElliptic
open Matrix UAMO UAMO.BoundarySeed Filter
open scoped Topology

theorem physicalNormalized_intertwining_eventually {a θ : ℝ} (ha : 0<a)
    (he1 : coupling a<1) (hs : Real.sin θ≠0) :
    ∀ᶠ h in 𝓝 (0:ℝ),(realGauge a θ h).det=1 ∧ ∀lam x,
      let M : CMat := InteriorSeed.physicalNumerator (phase θ) (normalizedPerturbation a θ) lam h x
      complexify (realTransfer a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x))*
        complexify (realGauge a θ h) =
      complexify (realGauge a θ h)*
        ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M) := by
  filter_upwards [physicalNumerator_real_conjugate_eventually ha he1 hs] with h hh
  refine ⟨hh.1,?_⟩
  intro lam x
  dsimp only
  rw [hh.2]
  have hunit : IsUnit (realGauge a θ h).det := by rw [hh.1];exact isUnit_one
  have hnorm : (realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ •
      complexify ((realGauge a θ h)⁻¹*
        realTransferNumerator a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x)*
          realGauge a θ h) =
      complexify ((realGauge a θ h)⁻¹*
        realTransfer a lam (spectralAngle (coupling a) θ h) (2*Real.pi*x)*
          realGauge a θ h) := by
    rw [realTransfer,mul_smul_comm,smul_mul_assoc,complexify_smul,Complex.ofReal_inv]
  rw [hnorm,←complexify_mul,←complexify_mul]
  simp only [←Matrix.mul_assoc,Matrix.mul_nonsing_inv _ hunit,one_mul]

end PaperUAMO.FreeElliptic

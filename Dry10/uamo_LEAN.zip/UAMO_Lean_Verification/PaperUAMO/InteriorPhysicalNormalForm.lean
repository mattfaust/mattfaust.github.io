import PaperUAMO.InteriorResonance
import PaperUAMO.InteriorNormalFormFamily
import PaperUAMO.FreeEllipticSU11

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed Asymptotics Filter Matrix
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

theorem actual_profile_normal_form {a α : ℝ} (ha : 0<a) (ha1 : a<1)
    (hα : Irrational α) (m : ℕ) (hm : 0<m) (ell : ℤ)
    (x : ℝ→Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0,
      finiteSystem m (FreeElliptic.phase (resonanceAngle α m ell)) (weylPhase α)
        (FreeElliptic.normalizedPerturbation a (resonanceAngle α m ell)) lam (x lam)=0) :
    let θ:=resonanceAngle α m ell
    let V:=FreeElliptic.normalizedPerturbation a θ
    let M:=fun lam y=>physicalNumerator (FreeElliptic.phase θ) V lam (x lam (zeroMode m)).im y
    let v:=fun lam=>physicalProfile m (x lam)
    let c:=resonantCoefficient m (FreeElliptic.phase θ) (weylPhase α) (V 0)
    ∃P K ε:ℝ,0<P ∧ 0<K ∧ 0<ε ∧ ∀lam,0≤lam → lam<ε →
      lam<1 ∧ (∀y,‖v lam y 0-1‖≤P*lam ∧ ‖v lam y 1‖≤P*lam) ∧
      (∀y,0<profileSignature (v lam y)) ∧
      (∀y,SU11Form (InteriorNormalForm.transformed m α lam (M lam) (v lam) y)) ∧
      ∀y i j,‖InteriorNormalForm.transformed m α lam (M lam) (v lam) y i j-
        ((liftSign ell:ℂ) • (1:CMV.TransferMatrix)+((lam^m:ℝ):ℂ) •
          hermitianSeed (c*halfPhase m α)) i j‖≤K*lam^(m+1) := by
  dsimp only
  let θ:=resonanceAngle α m ell
  let V:=FreeElliptic.normalizedPerturbation a θ
  let M:=fun lam y=>physicalNumerator (FreeElliptic.phase θ) V lam (x lam (zeroMode m)).im y
  let v:=fun lam=>physicalProfile m (x lam)
  let c:=resonantCoefficient m (FreeElliptic.phase θ) (weylPhase α) (V 0)
  have hs:=resonance_sin_ne_zero hα hm ell
  have hV : AnalyticAt ℝ V 0 := FreeElliptic.normalizedPerturbation_analytic ha hs
  have hres : (FreeElliptic.phase θ)^2=(weylPhase α)^m := by
    rw [show FreeElliptic.phase θ=resonantPhase α m ell from resonance_phase_eq α m ell]
    exact resonantPhase_square α m ell
  obtain ⟨A,P,R,δ,hA,hP,hR,hδ,hbounds⟩ := analytic_resonant_profile_bounds
    (FreeElliptic.phase_ne_zero θ) hα m hm hres V hV x hx0 hxa hxe
  have he1 : coupling a<1 := by
    rw [coupling,div_lt_one (by positivity : (0:ℝ)<1+a^2)]
    nlinarith [sq_pos_of_ne_zero (sub_ne_zero.mpr ha1.ne)]
  have hlim : Tendsto (fun lam=>(x lam (zeroMode m)).im) (nhds 0) (nhds 0) := by
    simpa only [Function.comp_def,hx0,Pi.zero_apply,Complex.zero_im] using
      (Complex.continuous_im.continuousAt.comp
        ((continuous_apply (zeroMode m)).continuousAt.comp hxa.continuousAt)).tendsto
  have hstruct := hlim.eventually (FreeElliptic.physicalNumerator_SU11_eventually ha he1 hs)
  obtain ⟨δs,hδs,hδsb⟩ := Metric.eventually_nhds_iff.mp hstruct
  let δ₀:=min δ (min δs 1)
  have hδ₀:0<δ₀ := lt_min hδ (lt_min hδs zero_lt_one)
  have hb (lam:ℝ) (hl:0≤lam) (hd:lam<δ₀) := hbounds lam hl (hd.trans_le (min_le_left _ _))
  have hst (lam:ℝ) (hl:0≤lam) (hd:lam<δ₀) (y:ℝ) :
      M lam y 1 1=star (M lam y 0 0) ∧ M lam y 0 1=star (M lam y 1 0) ∧
      SU11Form ((realTransferDenominator lam (2*Real.pi*y):ℂ)⁻¹ • M lam y) := by
    have hd' : dist lam 0<δs := by
      rw [Real.dist_eq,sub_zero,abs_of_nonneg hl]
      exact hd.trans_le ((min_le_right _ _).trans (min_le_left _ _))
    exact hδsb hd' lam hl
      (hd.trans_le ((min_le_right _ _).trans (min_le_right _ _))) y
  have hw : FreeElliptic.phase θ=(liftSign ell:ℂ)*halfPhase m α := by
    rw [show FreeElliptic.phase θ=resonantPhase α m ell from resonance_phase_eq α m ell]
    exact resonantPhase_eq_halfPhase α m ell
  obtain ⟨K,ε,hK,hε,hεδ,hout⟩ := InteriorNormalForm.paired_profile_normal_form m hm α
    (liftSign ell) (FreeElliptic.phase θ) c (liftSign_abs ell) hw M v
    (fun lam=>amplitude m (x lam)) A P R δ₀ hA.le hP.le hR hδ₀
    (fun lam hl hd y=>⟨(hst lam hl hd y).1,(hst lam hl hd y).2.1⟩)
    (fun lam hl hd y=>(hst lam hl hd y).2.2)
    (fun lam hl hd=>(hb lam hl hd).2.1)
    (fun lam hl hd=>(hb lam hl hd).1)
    (fun lam hl hd=>(hb lam hl hd).2.2)
  refine ⟨P,K,ε,hP,hK,hε,?_⟩
  intro lam hl hd
  obtain ⟨hl1,hpos,hsu,herror⟩ := hout lam hl hd
  exact ⟨hl1,(hb lam hl (hd.trans_le hεδ)).2.1,hpos,hsu,herror⟩

end PaperUAMO.InteriorSeed

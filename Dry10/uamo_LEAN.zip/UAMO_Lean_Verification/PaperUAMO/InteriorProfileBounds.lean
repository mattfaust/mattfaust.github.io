import PaperUAMO.InteriorFourierEvaluation
import UAMO.BoundarySeedFrame

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Function Filter
open scoped BigOperators Topology

def profileBoundConstant (m : ℕ) : ℝ := (Finset.Icc (-(m:ℤ)) (m:ℤ)).card

theorem physicalProfile_sum (m : ℕ) (x : Variables m) (θ : ℝ) (s : Fin 2) :
    physicalProfile m x θ s=∑ k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ),coefficient m x k s*(weylPhase θ)^k := by
  unfold physicalProfile fourierEvaluation fourierEval fourierProfile
  apply finsum_eq_sum_of_support_subset
  intro k hk
  by_contra hki
  simp [mem_support,coefficient_outside m x k s hki] at hk

theorem profile_base_sum (m : ℕ) (θ : ℝ) (s : Fin 2) :
    (∑ k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ),
      baseCoefficient k s*(weylPhase θ)^k) = if s=0 then 1 else 0 := by
  by_cases hs : s=0
  · simp only [baseCoefficient,hs,and_true,if_true]
    rw [Finset.sum_eq_single 0]
    · simp
    · intro k _ hk; simp [hk]
    · intro h
      exact False.elim (h (Finset.mem_Icc.mpr ⟨by omega,by omega⟩))
  · simp [baseCoefficient,hs]

theorem profile_coefficient_bound (m : ℕ) (x : Variables m) (s : Fin 2) (k : ℤ) :
    ‖coefficient m x k s-baseCoefficient k s‖≤‖x‖ := by
  by_cases hz : k=0 ∧ s=0
  · simp [coefficient,baseCoefficient,hz]
  · simp only [coefficient,baseCoefficient,hz,if_false,sub_zero]
    split_ifs with hret
    · exact norm_le_pi_norm x ⟨(k,s),hret⟩
    · simp

theorem physicalProfile_near_e1 (m : ℕ) (x : Variables m) (θ : ℝ) (s : Fin 2) :
    ‖physicalProfile m x θ s-(if s=0 then 1 else 0)‖≤profileBoundConstant m*‖x‖ := by
  have he : physicalProfile m x θ s-(if s=0 then 1 else 0)=
      ∑ k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ),
        (coefficient m x k s-baseCoefficient k s)*(weylPhase θ)^k := by
    simp only [sub_mul,Finset.sum_sub_distrib]
    rw [physicalProfile_sum,profile_base_sum]
  rw [he]
  calc
    _ ≤ ∑ k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ),
        ‖(coefficient m x k s-baseCoefficient k s)*(weylPhase θ)^k‖ := norm_sum_le _ _
    _ = ∑ k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ),
        ‖coefficient m x k s-baseCoefficient k s‖ := by
      simp only [norm_mul,norm_zpow,weylPhase_norm,one_zpow,mul_one]
    _ ≤ ∑ k ∈ Finset.Icc (-(m:ℤ)) (m:ℤ),‖x‖ :=
      Finset.sum_le_sum (fun k _ => profile_coefficient_bound m x s k)
    _ = _ := by simp [profileBoundConstant]

theorem analytic_profile_uniform_bound {m : ℕ} (x : ℝ → Variables m)
    (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0) :
    ∃ P ε : ℝ, 0<P ∧ 0<ε ∧ ∀ (lam θ : ℝ) (s : Fin 2), |lam|<ε →
      ‖physicalProfile m (x lam) θ s-(if s=0 then 1 else 0)‖≤P*|lam| := by
  have ho : x =O[nhds (0:ℝ)] (fun lam => lam) := by
    simpa only [hx0,sub_zero] using hxa.differentiableAt.isBigO_sub
  obtain ⟨C,hC,hbound⟩ := ho.exists_pos
  obtain ⟨ε,hε,hεb⟩ := Metric.eventually_nhds_iff.mp hbound.bound
  refine ⟨(profileBoundConstant m+1)*C,ε,?_,hε,?_⟩
  · have hp : 0≤profileBoundConstant m := by unfold profileBoundConstant; positivity
    positivity
  · intro lam θ s hlam
    have hb : ‖x lam‖≤C*|lam| := by
      simpa using hεb (by simpa only [Real.dist_eq,sub_zero] using hlam)
    have hp : 0≤profileBoundConstant m := by unfold profileBoundConstant; positivity
    calc
      _ ≤ profileBoundConstant m*‖x lam‖ := physicalProfile_near_e1 _ _ _ _
      _ ≤ profileBoundConstant m*(C*|lam|) := mul_le_mul_of_nonneg_left hb hp
      _ ≤ ((profileBoundConstant m+1)*C)*|lam| := by nlinarith [abs_nonneg lam]

end PaperUAMO.InteriorSeed

import PaperUAMO.InteriorProfileTheorem

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter Matrix
open scoped Topology

 theorem analytic_amplitude_uniform_bound {m : ℕ} (x : ℝ → Variables m)
    (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0) :
    ∃ A ε : ℝ, 0<A ∧ 0<ε ∧ ∀lam:ℝ, |lam|<ε →
      |amplitude m (x lam)-1|≤A*|lam| := by
  have ho : x =O[nhds (0:ℝ)] (fun lam => lam) := by
    simpa only [hx0,sub_zero] using hxa.differentiableAt.isBigO_sub
  obtain ⟨A,hA,hbound⟩ := ho.exists_pos
  obtain ⟨ε,hε,hεb⟩ := Metric.eventually_nhds_iff.mp hbound.bound
  refine ⟨A,ε,hA,hε,?_⟩
  intro lam hlam
  have hb : ‖x lam‖≤A*|lam| := by
    simpa using hεb (by simpa only [Real.dist_eq,sub_zero] using hlam)
  calc
    _ = |(x lam (zeroMode m)).re| := by simp [amplitude]
    _ ≤ ‖x lam (zeroMode m)‖ := Complex.abs_re_le_norm _
    _ ≤ ‖x lam‖ := norm_le_pi_norm _ _
    _ ≤ A*|lam| := hb

theorem analytic_resonant_profile_bounds {w : ℂ} (hw : w≠0) {α : ℝ}
    (hα : Irrational α) (m : ℕ) (hm : 0<m) (hres : w^2=(weylPhase α)^m)
    (V : ℝ→SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ→Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w (weylPhase α) V lam (x lam)=0) :
    ∃ A P R δ : ℝ, 0<A ∧ 0<P ∧ 0<R ∧ 0<δ ∧
      ∀lam:ℝ, 0≤lam → lam<δ →
        |amplitude m (x lam)-1|≤A*lam ∧
        (∀θ:ℝ,‖physicalProfile m (x lam) θ 0-1‖≤P*lam ∧
          ‖physicalProfile m (x lam) θ 1‖≤P*lam) ∧
        ∀(θ:ℝ)(i:Fin 2),
          ‖(physicalNumerator w V lam (x lam (zeroMode m)).im θ*ᵥphysicalProfile m (x lam) θ-
            (w*(amplitude m (x lam):ℂ)) • physicalProfile m (x lam) (θ+α)) i-
            (if i=1 then resonantCoefficient m w (weylPhase α) (V 0)*(lam:ℂ)^m*
              (weylPhase θ)^(-(m:ℤ)) else 0)‖≤R*lam^(m+1) := by
  obtain ⟨A,εa,hA,hεa,ha⟩ := analytic_amplitude_uniform_bound x hx0 hxa
  obtain ⟨P,εp,hP,hεp,hp⟩ := analytic_profile_uniform_bound x hx0 hxa
  obtain ⟨R,εr,hR,hεr,hr⟩ := analytic_physical_residual_bound hw hα m hm hres V hV x hx0 hxa hxe
  refine ⟨A,P,R,min εa (min εp εr),hA,hP,hR,lt_min hεa (lt_min hεp hεr),?_⟩
  intro lam hlam hl
  have ha' := ha lam (by rw [abs_of_nonneg hlam]; exact hl.trans_le (min_le_left _ _))
  have hp' := hp lam
  have hr' := hr lam
  refine ⟨by simpa only [abs_of_nonneg hlam] using ha',?_,?_⟩
  · intro θ
    constructor
    · simpa only [ite_true,abs_of_nonneg hlam] using
        hp' θ 0 (by rw [abs_of_nonneg hlam]; exact hl.trans_le ((min_le_right _ _).trans (min_le_left _ _)))
    · simpa only [show (1:Fin 2)≠0 by decide,ite_false,sub_zero,abs_of_nonneg hlam] using
        hp' θ 1 (by rw [abs_of_nonneg hlam]; exact hl.trans_le ((min_le_right _ _).trans (min_le_left _ _)))
  · intro θ i
    simpa only [abs_of_nonneg hlam] using hr' θ i
      (by rw [abs_of_nonneg hlam]; exact hl.trans_le ((min_le_right _ _).trans (min_le_right _ _)))

end PaperUAMO.InteriorSeed

import PaperUAMO.InteriorProfileBounds
import UAMO.BoundarySeedEntries

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed
open scoped BigOperators Topology

theorem coefficient_analyticAt (m : ℕ) (k : ℤ) (j : Fin 2) (x : Variables m) :
    AnalyticAt ℝ (fun y : Variables m => coefficient m y k j) x := by
  unfold coefficient
  split_ifs
  · exact analyticAt_const
  · exact (ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).analyticAt x
  · exact analyticAt_const

theorem continuous_physicalProfile (m : ℕ) (x : Variables m) :
    Continuous (physicalProfile m x) := by
  apply continuous_pi
  intro s
  simp_rw [physicalProfile_sum]
  apply continuous_finset_sum
  intro k _
  simp_rw [weylPhase_zpow]
  fun_prop

theorem weylPhase_period_one (θ : ℝ) : weylPhase (θ+1)=weylPhase θ := by
  rw [weylPhase_add]
  have h : weylPhase 1=1 := by simp [weylPhase,Complex.exp_two_pi_mul_I]
  rw [h,mul_one]

theorem physicalProfile_periodic (m : ℕ) (x : Variables m) (θ : ℝ) :
    physicalProfile m x (θ+1)=physicalProfile m x θ := by
  unfold physicalProfile fourierEvaluation fourierEval
  simp only [weylPhase_period_one]

theorem physicalProfile_analytic_phase (m : ℕ) (x : Variables m) (θ : ℝ) :
    AnalyticAt ℝ (physicalProfile m x) θ := by
  apply AnalyticAt.pi
  intro i
  simp_rw [physicalProfile_sum]
  apply Finset.analyticAt_sum
  intro k _
  simp_rw [weylPhase_zpow]
  apply analyticAt_const.mul
  apply analyticAt_cexp.restrictScalars.comp
  exact ((Complex.ofRealCLM.analyticAt _).comp
    ((analyticAt_const.mul analyticAt_id).mul analyticAt_const)).mul analyticAt_const

end PaperUAMO.InteriorSeed

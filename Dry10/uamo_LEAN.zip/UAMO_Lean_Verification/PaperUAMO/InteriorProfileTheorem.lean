import PaperUAMO.InteriorUniformResidual
import PaperUAMO.InteriorProfileRegularity
import PaperUAMO.InteriorCoefficientIdentification
import PaperUAMO.FreeEllipticConjugacy

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.CMV UAMO.BoundarySeed Asymptotics Filter Matrix
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace
open scoped BigOperators Topology

theorem analytic_resonant_profile {w : ℂ} (hw : w≠0) {α : ℝ}
    (hα : Irrational α) (m : ℕ) (hm : 0<m) (hres : w^2=(weylPhase α)^m)
    (V : ℝ→SpinMatrix) (hV : AnalyticAt ℝ V 0) (μ γ : ℝ) (hμ : μ≠0)
    (hγ : γ^2=1+μ^2)
    (hV₀ : V 0=!![-Complex.I*μ*w,(γ:ℂ);(γ:ℂ),Complex.I*μ*w⁻¹]) :
    ∃ x : ℝ→Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      (∀ᶠ lam in nhds 0, finiteSystem m w (weylPhase α) V lam (x lam)=0) ∧
      resonantCoefficient m w (weylPhase α) (V 0)≠0 ∧
      ((fun lam => x lam (zeroMode m)) =O[nhds (0:ℝ)] (fun lam => lam^2)) ∧
      ∃ P C ε : ℝ, 0<P ∧ 0<C ∧ 0<ε ∧ ∀ (lam θ : ℝ) (i : Fin 2), |lam|<ε →
        ‖physicalProfile m (x lam) θ i-(if i=0 then 1 else 0)‖≤P*|lam| ∧
        ‖(physicalNumerator w V lam (x lam (zeroMode m)).im θ*ᵥphysicalProfile m (x lam) θ-
            (w*(amplitude m (x lam):ℂ)) • physicalProfile m (x lam) (θ+α)) i-
          (if i=1 then resonantCoefficient m w (weylPhase α) (V 0)*(lam:ℂ)^m*
            (weylPhase θ)^(-(m:ℤ)) else 0)‖≤C*|lam|^(m+1) := by
  obtain ⟨x,hx0,hxa,hxe,_⟩ := exact_finite_analytic_branch hw
    (Complex.exp_ne_zero _) (weylPhase_noIntegerResonance hα) m hres V hV
  have hc : resonantCoefficient m w (weylPhase α) (V 0)≠0 :=
    InteriorCoefficient.actual_resonant_coefficient_ne_zero w (weylPhase α) μ γ m hw
      (weylPhase_noIntegerResonance hα) (weylPhase_norm α) hm hμ hγ hres (V 0) hV₀
  obtain ⟨P,εp,hP,hεp,hp⟩ := analytic_profile_uniform_bound x hx0 hxa
  obtain ⟨C,εr,hC,hεr,hr⟩ := analytic_physical_residual_bound hw hα m hm hres V hV x hx0 hxa hxe
  refine ⟨x,hx0,hxa,hxe,hc,branch_zero_mode_order hw m V hV.continuousAt x hx0 hxa hxe,
    P,C,min εp εr,hP,hC,lt_min hεp hεr,?_⟩
  intro lam θ i hlam
  exact ⟨hp lam θ i (hlam.trans_le (min_le_left _ _)),
    hr lam θ i (hlam.trans_le (min_le_right _ _))⟩

theorem actual_elliptic_profile_data {a θ : ℝ} (ha : 0<a) (ha1 : a<1)
    (hs : Real.sin θ≠0) :
    AnalyticAt ℝ (fun h => (FreeElliptic.normalizedPerturbation a θ h : SpinMatrix)) 0 ∧
      FreeElliptic.velocity a θ≠0 ∧
      (FreeElliptic.amplitude a θ)^2=1+(FreeElliptic.velocity a θ)^2 ∧
      (FreeElliptic.normalizedPerturbation a θ 0 : SpinMatrix)=
        !![-Complex.I*(FreeElliptic.velocity a θ)*FreeElliptic.phase θ,
          (FreeElliptic.amplitude a θ:ℂ);(FreeElliptic.amplitude a θ:ℂ),
          Complex.I*(FreeElliptic.velocity a θ)*(FreeElliptic.phase θ)⁻¹] := by
  refine ⟨FreeElliptic.normalizedPerturbation_analytic ha hs,
    FreeElliptic.velocity_ne_zero ha ha1 hs,?_,?_⟩
  · unfold FreeElliptic.amplitude
    exact Real.sq_sqrt (by positivity)
  · simpa only [div_eq_mul_inv] using FreeElliptic.normalizedPerturbation_zero ha hs

theorem elliptic_spectral_center_order {a θ : ℝ} (ha : 0<a) (ha1 : a<1)
    {m : ℕ} (x : ℝ→Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hcenter : (fun lam => x lam (zeroMode m)) =O[nhds (0:ℝ)] (fun lam => lam^2)) :
    (fun lam => FreeElliptic.spectralAngle (coupling a) θ (x lam (zeroMode m)).im-
      FreeElliptic.spectralAngle (coupling a) θ 0)
      =O[nhds (0:ℝ)] (fun lam => lam^2) := by
  have hi : (fun lam => (x lam (zeroMode m)).im) =O[nhds (0:ℝ)] (fun lam => lam^2) :=
    (isBigO_of_le _ fun lam => Complex.abs_im_le_norm _).trans hcenter
  have ht : Tendsto (fun lam => (x lam (zeroMode m)).im) (nhds 0) (nhds 0) := by
    simpa only [Function.comp_def,hx0,Pi.zero_apply,Complex.zero_im] using
      (Complex.continuous_im.continuousAt.comp ((continuous_apply (zeroMode m)).continuousAt.comp hxa.continuousAt)).tendsto
  have he1 : coupling a<1 := by
    rw [coupling,div_lt_one (by positivity : (0:ℝ)<1+a^2)]
    nlinarith [sq_pos_of_ne_zero (sub_ne_zero.mpr ha1.ne)]
  have hf := (FreeElliptic.spectralAngle_analytic (coupling_pos ha)
    he1 (θ:=θ) 0).differentiableAt.isBigO_sub.comp_tendsto ht
  have hf' := hf
  simp only [Function.comp_def,sub_zero] at hf'
  exact hf'.trans hi

end PaperUAMO.InteriorSeed

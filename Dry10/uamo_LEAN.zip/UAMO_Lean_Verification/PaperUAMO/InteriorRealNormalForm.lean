import PaperUAMO.InteriorNormalFormFamily
import PaperUAMO.InteriorFrameDegree
import PaperUAMO.FreeEllipticComplex

set_option maxHeartbeats 800000
noncomputable section
namespace PaperUAMO.InteriorNormalForm
open Matrix UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open PaperUAMO.FreeElliptic PaperUAMO.InteriorFrame
open PaperUAMO.SymmetricSplitting UAMODraft.QuantitativeOpening
open scoped Matrix.L2OpNorm

theorem cayley_eq_seed : cayleyMatrix=seedCayley 1 := by simp [cayleyMatrix,seedCayley]
theorem cayleyInverse_eq_seed : cayleyInverse=seedCayleyInverse 1 := by
  simp [cayleyInverse,seedCayleyInverse]

theorem complexify_one : complexify (1:RMat)=1 := by
  simp [complexify,Matrix.map_one,cayley_mul_inverse]

theorem complexify_injective : Function.Injective complexify := by
  intro A B h
  have h' := congrArg (fun X:CMat=>cayleyInverse*X*cayleyMatrix) h
  simp only [complexify,Matrix.mul_assoc] at h'
  rw [←Matrix.mul_assoc cayleyInverse,cayley_inverse_mul,one_mul,
    ←Matrix.mul_assoc cayleyInverse,cayley_inverse_mul,one_mul] at h'
  simp only [←Matrix.mul_assoc,cayley_inverse_mul,Matrix.mul_one] at h'
  ext i j
  exact Complex.ofReal_injective (congrFun (congrFun h' i) j)

theorem complexify_pairedRealFrame (m:ℕ) (v:ℝ→Spin) (x:ℝ) :
    complexify (pairedRealFrame m v x)=normalizedFrame (v x) (halfPhase m x) := by
  rw [complexify,pairedRealFrame,realFrameOf_map,←cayley_eq_seed,←cayleyInverse_eq_seed]
  simp only [Matrix.mul_assoc]
  rw [←Matrix.mul_assoc cayleyMatrix,cayley_mul_inverse,one_mul]
  simp only [Matrix.mul_one]

def realLeading (η:ℂ) : RMat := symmetricBlock η.re (-η.im)

theorem realLeading_symmetric (η:ℂ) : (realLeading η).transpose=realLeading η := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [realLeading,symmetricBlock]

theorem realLeading_trace (η:ℂ) : Matrix.trace (realLeading η)=0 := by
  simp [realLeading,symmetricBlock,Matrix.trace,Matrix.diag,Fin.sum_univ_two]

theorem realLeading_norm (η:ℂ) : ‖realLeading η‖=‖η‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [realLeading,symmetricBlock_norm_sq,Complex.sq_norm]
  simp [Complex.normSq_apply,pow_two]

theorem complexify_realLeading (η:ℂ) : complexify (realLeading η)=hermitianSeed η := by
  ext i j
  fin_cases i <;> fin_cases j <;> apply Complex.ext <;>
    simp [complexify,realLeading,symmetricBlock,cayleyMatrix,cayleyInverse,
      hermitianSeed,Matrix.mul_apply,Matrix.vecMul,dotProduct,Matrix.map_apply,Fin.sum_univ_two,
      Complex.mul_re,Complex.mul_im,Complex.star_def] <;> ring

def physicalFrame (S:RMat) (m:ℕ) (v:ℝ→Spin) (x:ℝ) : RMat :=
  S*pairedRealFrame m v x

theorem physicalFrame_conjugacy (S:RMat) (m:ℕ) (α lam:ℝ)
    (A:ℝ→RMat) (M:ℝ→Mat) (v:ℝ→Spin) (hS:S.det=1)
    (hv:∀x,0<profileSignature (v x))
    (hinter:∀x,complexify (A x)*complexify S=complexify S*
      ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M x)) (x:ℝ) :
    complexify ((physicalFrame S m v (x+α))⁻¹*A x*physicalFrame S m v x)=
      transformed m α lam M v x := by
  have hdet (y:ℝ) : (physicalFrame S m v y).det=1 := by
    rw [physicalFrame,Matrix.det_mul,hS,one_mul]
    exact realFrameOf_det (v y) (halfPhase_norm m y) (by norm_num) (hv y)
  have hi : complexify ((physicalFrame S m v (x+α))⁻¹)*
      complexify (physicalFrame S m v (x+α))=1 := by
    rw [←complexify_mul,Matrix.nonsing_inv_mul _ (by rw [hdet];exact isUnit_one),complexify_one]
  have he : complexify (physicalFrame S m v (x+α))*transformed m α lam M v x=
      complexify (A x)*complexify (physicalFrame S m v x) := by
    simp only [physicalFrame,complexify_mul,complexify_pairedRealFrame,transformed,
      Matrix.mul_assoc]
    rw [←Matrix.mul_assoc (normalizedFrame _ _) (normalizedFrameInverse _ _),
      normalizedFrame_mul_inverse _ _ (halfPhase_norm m (x+α)) (hv (x+α)),one_mul]
    rw [←Matrix.mul_assoc (complexify (A x)),hinter,Matrix.mul_assoc]
  rw [complexify_mul,complexify_mul,Matrix.mul_assoc,←he,←Matrix.mul_assoc,hi,one_mul]

theorem real_entry_error (T:RMat) (σ d:ℝ) (η:ℂ) {ε:ℝ} (hε:0≤ε)
    (h:∀i j,‖complexify T i j-
      ((σ:ℂ) • (1:Mat)+(d:ℂ) • hermitianSeed η) i j‖≤ε) (i j:Fin 2) :
    |(T-(σ • (1:RMat)+d • realLeading η)) i j|≤2*ε := by
  have hphase : seedEigenphase 1=1 := by simp [seedEigenphase]
  have hh:=seedCayley_error_bound 1 (complexify T)
    ((σ:ℂ) • (1:Mat)+(d:ℂ) • hermitianSeed η) hε h i j
  rw [hphase,←cayley_eq_seed,←cayleyInverse_eq_seed,
    ←complexify_realLeading,←complexify_one,←complexify_smul,←complexify_smul,
    ←complexify_add] at hh
  have hc (N:RMat) : cayleyInverse*complexify N*cayleyMatrix=N.map Complex.ofReal := by
    simp only [complexify,Matrix.mul_assoc]
    rw [←Matrix.mul_assoc cayleyInverse,cayley_inverse_mul,one_mul,Matrix.mul_one]
  rw [hc,hc] at hh
  simpa only [Matrix.sub_apply,Matrix.map_apply,←Complex.ofReal_sub,
    Complex.norm_real,Real.norm_eq_abs] using hh

theorem operator_norm_le_four_entries (T:RMat) {ε:ℝ} (hε:0≤ε)
    (h:∀i j,|T i j|≤ε) : ‖T‖≤4*ε := by
  change ‖Matrix.toEuclideanCLM (𝕜:=ℝ) T‖≤4*ε
  apply (Matrix.toEuclideanCLM (𝕜:=ℝ) T).opNorm_le_bound (by positivity)
  intro v
  let w:=Matrix.toEuclideanCLM (𝕜:=ℝ) T v
  have hw (i:Fin 2) : ‖w i‖≤2*ε*‖v‖ := by
    change ‖(T *ᵥ (fun j=>v j)) i‖≤_
    simp only [Matrix.mulVec,dotProduct,Fin.sum_univ_two]
    calc
      _ ≤ ‖T i 0*v 0‖+‖T i 1*v 1‖ := norm_add_le _ _
      _ ≤ ε*‖v‖+ε*‖v‖ := by
        simp only [norm_mul,Real.norm_eq_abs]
        exact add_le_add (mul_le_mul (h i 0) (PiLp.norm_apply_le v 0) (abs_nonneg _) hε)
          (mul_le_mul (h i 1) (PiLp.norm_apply_le v 1) (abs_nonneg _) hε)
      _ = _ := by ring
  have hs:=PiLp.norm_sq_eq_of_L2 (fun _:Fin 2=>ℝ) w
  simp only [Fin.sum_univ_two] at hs
  have h0:=sq_le_sq₀ (norm_nonneg (w 0)) (by positivity : 0≤2*ε*‖v‖)
  have h1:=sq_le_sq₀ (norm_nonneg (w 1)) (by positivity : 0≤2*ε*‖v‖)
  have hb0:=h0.mpr (hw 0)
  have hb1:=h1.mpr (hw 1)
  change ‖w‖≤4*ε*‖v‖
  nlinarith [norm_nonneg w,mul_nonneg hε (norm_nonneg v)]

end PaperUAMO.InteriorNormalForm

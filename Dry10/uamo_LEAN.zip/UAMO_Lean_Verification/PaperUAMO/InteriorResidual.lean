import PaperUAMO.InteriorLeading

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology BigOperators

def fullResidual (m : ℕ) (w q : ℂ) (V : ℝ → SpinMatrix)
    (lam : ℝ) (x : Variables m) (k : ℤ) (i : Fin 2) : ℂ :=
  denominator m w q x k i*coefficient m x k i+
    (2*Complex.I)⁻¹*(lam:ℂ)*∑ j : Fin 2, V (x (zeroMode m)).im i j *
      (coefficient m x (k-1) j-coefficient m x (k+1) j)

def resonantResidual (m : ℕ) (V : ℝ → SpinMatrix) (lam : ℝ) (x : Variables m) : ℂ :=
  -(2*Complex.I)⁻¹*(lam:ℂ)*∑ j : Fin 2,
    V (x (zeroMode m)).im 1 j*coefficient m x (-(m:ℤ)+1) j

def exteriorResidual (m : ℕ) (V : ℝ → SpinMatrix) (lam : ℝ) (x : Variables m)
    (i : Fin 2) (side : Bool) : ℂ :=
  (if side then (2*Complex.I)⁻¹ else -(2*Complex.I)⁻¹)*(lam:ℂ)*∑ j : Fin 2,
    V (x (zeroMode m)).im i j*coefficient m x (if side then (m:ℤ) else -(m:ℤ)) j

def resonantCoefficient (m : ℕ) (w q : ℂ) (V₀ : SpinMatrix) : ℂ :=
  -(2*Complex.I)⁻¹*∑ j : Fin 2, V₀ 1 j*leadingCoefficient w q V₀ (m-1) j

theorem fullResidual_exact (m : ℕ) (w q : ℂ) (V : ℝ → SpinMatrix)
    (lam : ℝ) (x : Variables m) (hx : finiteSystem m w q V lam x=0) (k : ℤ) (i : Fin 2) :
    fullResidual m w q V lam x k i=
      if k=-(m:ℤ) ∧ i=1 then resonantResidual m V lam x
      else if k=-(m:ℤ)-1 then exteriorResidual m V lam x i false
      else if k=(m:ℤ)+1 then exteriorResidual m V lam x i true else 0 := by
  by_cases hom : k=-(m:ℤ) ∧ i=1
  · obtain ⟨rfl,rfl⟩ := hom
    have hfar (j : Fin 2) : coefficient m x (-(m:ℤ)-1) j=0 :=
      coefficient_outside m x _ j (by simp only [Finset.mem_Icc]; omega)
    simp [fullResidual,coefficient_omitted,hfar,resonantResidual]
    ring
  by_cases hn : k=-(m:ℤ)-1
  · subst k
    have hfar (j : Fin 2) : coefficient m x (-(m:ℤ)-1-1) j=0 :=
      coefficient_outside m x _ j (by simp only [Finset.mem_Icc]; omega)
    have hhere : coefficient m x (-(m:ℤ)-1) i=0 :=
      coefficient_outside m x _ i (by simp only [Finset.mem_Icc]; omega)
    simp only [fullResidual,hhere,mul_zero,zero_add,hfar,zero_sub,mul_neg,
      Finset.sum_neg_distrib,hom,if_false,if_true,exteriorResidual,Bool.false_eq_true]
    rw [sub_add_cancel]
    ring
  by_cases hp : k=(m:ℤ)+1
  · subst k
    have hfar (j : Fin 2) : coefficient m x ((m:ℤ)+1+1) j=0 :=
      coefficient_outside m x _ j (by simp only [Finset.mem_Icc]; omega)
    have hhere : coefficient m x ((m:ℤ)+1) i=0 :=
      coefficient_outside m x _ i (by simp only [Finset.mem_Icc]; omega)
    simp [fullResidual,hhere,hfar,hom,hn,exteriorResidual]
  simp only [hom,if_false,hn,hp]
  by_cases hki : k∈Finset.Icc (-(m:ℤ)) (m:ℤ)
  · exact congrFun hx ⟨(k,i),hki,hom⟩
  · have h₁ (j : Fin 2) : coefficient m x (k-1) j=0 :=
      coefficient_outside m x _ j (by simp only [Finset.mem_Icc] at hki ⊢; omega)
    have h₂ (j : Fin 2) : coefficient m x (k+1) j=0 :=
      coefficient_outside m x _ j (by simp only [Finset.mem_Icc] at hki ⊢; omega)
    simp [fullResidual,coefficient_outside m x k i hki,h₁,h₂]

theorem branch_matrix_order {m : ℕ} (x : ℝ → Variables m)
    (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0) (V : ℝ → SpinMatrix)
    (hV : AnalyticAt ℝ V 0) (i j : Fin 2) :
    (fun lam => V (x lam (zeroMode m)).im i j-V 0 i j)
      =O[nhds (0:ℝ)] (fun lam => lam) := by
  have he : AnalyticAt ℝ (fun lam => x lam (zeroMode m)) 0 :=
    (ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).analyticAt _ |>.comp hxa
  have hi : AnalyticAt ℝ (fun lam => (x lam (zeroMode m)).im) 0 :=
    (Complex.imCLM.analyticAt _).comp he
  have hv₀ : AnalyticAt ℝ (fun t => V t i j) 0 :=
    (ContinuousLinearMap.proj j : (Fin 2 → ℂ) →L[ℝ] ℂ).analyticAt _ |>.comp
      ((ContinuousLinearMap.proj i : SpinMatrix →L[ℝ] (Fin 2 → ℂ)).analyticAt _ |>.comp hV)
  have hv := hv₀.comp_of_eq hi (by simp [hx0])
  simpa only [Function.comp_def,hx0,Pi.zero_apply,Complex.zero_im,sub_zero] using hv.differentiableAt.isBigO_sub

theorem resonantResidual_asymptotic {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0) :
    (fun lam => resonantResidual m V lam (x lam)-resonantCoefficient m w q (V 0)*(lam:ℂ)^m)
      =O[nhds (0:ℝ)] (fun lam => lam^(m+1)) := by
  have he : -(m:ℤ)+1=-((m-1:ℕ):ℤ) := by omega
  have hstep := leading_vector_step
    (fun lam => resonantResidual m V lam (x lam))
    (fun j lam => coefficient m (x lam) (-(m:ℤ)+1) j)
    (fun _ _ => (0:ℂ))
    (fun j lam => V (x lam (zeroMode m)).im 1 j)
    (-(2*Complex.I)⁻¹) (fun j => V 0 1 j) (leadingCoefficient w q (V 0) (m-1)) (m-1)
    (Filter.Eventually.of_forall (by intro lam; simp [resonantResidual]))
    (fun j => by simpa only [he] using
      branch_negative_leading hw hq0 hq m hres V hV x hx0 hxa hxe (m-1) (by omega) j)
    (fun _ => isBigO_zero _ _)
    (fun j => (branch_matrix_continuousAt x hx0 hxa.continuousAt V hV.continuousAt 1 j).isBigO_one ℝ)
    (fun j => branch_matrix_order x hx0 hxa V hV 1 j)
  simpa only [resonantCoefficient,show m-1+1=m by omega,show m-1+2=m+1 by omega] using hstep

theorem exteriorResidual_order {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : ContinuousAt V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0) (i : Fin 2) (side : Bool) :
    (fun lam => exteriorResidual m V lam (x lam) i side)
      =O[nhds (0:ℝ)] (fun lam => lam^(m+1)) := by
  have hs : (fun lam => ∑ j : Fin 2, V (x lam (zeroMode m)).im i j *
      coefficient m (x lam) (if side then (m:ℤ) else -(m:ℤ)) j)
      =O[nhds (0:ℝ)] (fun lam => lam^m) := by
    apply IsBigO.sum
    intro j _
    have hc := branch_coefficient_order hw hq0 hq m hres V hV x hx0 hxa hxe m
      (if side then (m:ℤ) else -(m:ℤ)) j (by split_ifs <;> simp)
    have hv := (branch_matrix_continuousAt x hx0 hxa.continuousAt V hV i j).isBigO_one ℝ
    simpa only [one_mul] using hv.mul hc
  have hlam : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
    isBigO_of_le _ (fun lam => by simp)
  simpa only [exteriorResidual,pow_succ,mul_assoc,mul_left_comm,mul_comm] using
    (hlam.mul hs).const_mul_left (if side then (2*Complex.I)⁻¹ else -(2*Complex.I)⁻¹)

end PaperUAMO.InteriorSeed

import PaperUAMO.InteriorProfileData

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Filter Matrix
open scoped Topology
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

def resonanceAngle (α : ℝ) (m : ℕ) (ell : ℤ) : ℝ :=
  Real.pi*((m:ℝ)*α+(ell:ℝ))

theorem resonance_phase_eq (α : ℝ) (m : ℕ) (ell : ℤ) :
    FreeElliptic.phase (resonanceAngle α m ell)=resonantPhase α m ell := rfl

theorem resonance_sin_ne_zero {α : ℝ} (hα : Irrational α) {m : ℕ}
    (hm : 0<m) (ell : ℤ) : Real.sin (resonanceAngle α m ell)≠0 := by
  intro hs
  obtain ⟨n,hn⟩ := Real.sin_eq_zero_iff.mp hs
  have he : (m:ℝ)*α+(ell:ℝ)=(n:ℝ) := by
    unfold resonanceAngle at hn
    nlinarith [Real.pi_pos]
  exact ((hα.natCast_mul hm.ne').add_intCast ell).ne_int n he

theorem physical_analytic_profile {a α : ℝ} (ha : 0<a) (ha1 : a<1)
    (hα : Irrational α) (m : ℕ) (hm : 0<m) (ell : ℤ) :
    ∃ x : ℝ→Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      (∀ᶠ lam in nhds 0,
        finiteSystem m (FreeElliptic.phase (resonanceAngle α m ell)) (weylPhase α)
          (FreeElliptic.normalizedPerturbation a (resonanceAngle α m ell)) lam (x lam)=0) ∧
      resonantCoefficient m (FreeElliptic.phase (resonanceAngle α m ell)) (weylPhase α)
        (FreeElliptic.normalizedPerturbation a (resonanceAngle α m ell) 0)≠0 := by
  let θ:=resonanceAngle α m ell
  have hs:=resonance_sin_ne_zero hα hm ell
  obtain ⟨hV,hμ,hγ,hV0⟩ := actual_elliptic_profile_data ha ha1 hs
  have hres : (FreeElliptic.phase θ)^2=(weylPhase α)^m := by
    rw [show FreeElliptic.phase θ=resonantPhase α m ell from resonance_phase_eq α m ell]
    exact resonantPhase_square α m ell
  obtain ⟨x,hx0,hxa,hxe,hc,_⟩ := analytic_resonant_profile (FreeElliptic.phase_ne_zero θ)
    hα m hm hres (FreeElliptic.normalizedPerturbation a θ) hV
      (FreeElliptic.velocity a θ) (FreeElliptic.amplitude a θ) hμ hγ hV0
  exact ⟨x,hx0,hxa,hxe,hc⟩

end PaperUAMO.InteriorSeed

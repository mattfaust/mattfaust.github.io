import PaperUAMO.InteriorPhysicalNormalForm
import PaperUAMO.InteriorPhysicalIntertwining
import PaperUAMO.InteriorSplittingApplication
import PaperUAMO.InteriorSeedGapBridge

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Filter Matrix
open PaperUAMO.FreeElliptic PaperUAMO.InteriorNormalForm
open PaperUAMO.SymmetricSplitting UAMODraft.SpectralBridge
open UAMODraft.CircleCover UAMODraft.CoverHyperbolicity
open scoped Topology Matrix.L2OpNorm

theorem positive_interior_seed_hyperbolicity {a α : ℝ} (ha : 0<a) (ha1 : a<1)
    (hα : Irrational α) (m : ℕ) (hm : 0 < m) (ell : ℤ) :
    ∃t:ℝ→ℝ, AnalyticAt ℝ t 0 ∧ ∃ε>0,∀lam,0<lam → lam<ε →
      lam<1 ∧
      IsUniformlyHyperbolicOnLines (translation 1 α) (physicalRealCircle a lam (t lam)) ∧
      HasRotationNumber (physicalRealPhase a lam (t lam)) α
        ((m:ℝ)*α/2+(1-liftSign ell)/4) := by
  obtain ⟨x,hx0,hxa,hxe,hc⟩ := physical_analytic_profile ha ha1 hα m hm ell
  let θ:=resonanceAngle α m ell
  let V:=normalizedPerturbation a θ
  let t:=fun lam=>spectralAngle (coupling a) θ (x lam (zeroMode m)).im
  let A:ℝ→ℝ→FreeElliptic.RMat:=fun lam=>physicalRealPhase a lam (t lam)
  let S:=fun lam=>realGauge a θ (x lam (zeroMode m)).im
  let M:ℝ→ℝ→CMat:=fun lam y=>physicalNumerator (phase θ) V lam (x lam (zeroMode m)).im y
  let v:=fun lam=>physicalProfile m (x lam)
  let c:=resonantCoefficient m (phase θ) (weylPhase α) (V 0)
  let η:=c*halfPhase m α
  have hη:η≠0 := mul_ne_zero hc (Complex.exp_ne_zero _)
  have hs:=resonance_sin_ne_zero hα hm ell
  have he1 : coupling a<1 := by
    rw [coupling,div_lt_one (by positivity : (0:ℝ)<1+a^2)]
    nlinarith [sq_pos_of_ne_zero (sub_ne_zero.mpr ha1.ne)]
  have hxev : AnalyticAt ℝ (fun lam=>x lam (zeroMode m)) 0 :=
    (ContinuousLinearMap.proj (zeroMode m) : Variables m →L[ℝ] ℂ).analyticAt (x 0) |>.comp hxa
  have hxphase : AnalyticAt ℝ (fun lam=>(x lam (zeroMode m)).im) 0 :=
    (Complex.imCLM.analyticAt _).comp hxev
  have ht : AnalyticAt ℝ t 0 :=
    (spectralAngle_analytic (coupling_pos ha) he1 _).comp hxphase
  have hlim : Tendsto (fun lam=>(x lam (zeroMode m)).im) (nhds 0) (nhds 0) := by
    simpa only [hx0,Pi.zero_apply,Complex.zero_im] using hxphase.continuousAt.tendsto
  have hinter := hlim.eventually (physicalNormalized_intertwining_eventually ha he1 hs)
  obtain ⟨P,K,εn,hP,hK,hεn,hn⟩ := actual_profile_normal_form ha ha1 hα m hm ell x hx0 hxa hxe
  have hdata : ∀ᶠ lam in 𝓝[>] (0:ℝ),
      Continuous (A lam) ∧ Function.Periodic (A lam) 1 ∧
      (∀y,(A lam y).det=1) ∧ (S lam).det=1 ∧
      Continuous (v lam) ∧ Function.Periodic (v lam) 1 ∧
      (∀y,‖v lam y 0-1‖≤P*lam ∧ ‖v lam y 1‖≤P*lam) ∧
      (∀y,FreeElliptic.complexify (A lam y)*FreeElliptic.complexify (S lam)=FreeElliptic.complexify (S lam)*
        ((realTransferDenominator lam (2*Real.pi*y):ℂ)⁻¹ • M lam y)) ∧
      (∀y i j,‖transformed m α lam (M lam) (v lam) y i j-
        ((liftSign ell:ℂ) • (1:CMat)+((lam^m:ℝ):ℂ) • hermitianSeed η) i j‖≤K*lam^(m+1)) := by
    filter_upwards [self_mem_nhdsWithin,(eventually_lt_nhds hεn).filter_mono inf_le_left,
      hinter.filter_mono inf_le_left] with lam hlam hsmall hg
    have hlam0:0<lam:=hlam
    obtain ⟨hlam1,hv,_hpos,_hsu,herror⟩:=hn lam hlam0.le hsmall
    refine ⟨continuous_physicalRealPhase a hlam0.le hlam1 (t lam),
      physicalRealPhase_periodic a lam (t lam),?_,hg.1,
      continuous_physicalProfile m (x lam),physicalProfile_periodic m (x lam),hv,?_,herror⟩
    · intro y
      exact realTransfer_det ha.ne' hlam0.le hlam1 (t lam) (2*Real.pi*y)
    · intro y
      exact hg.2 lam y
  obtain ⟨ε,hε,hout⟩:=paired_normal_form_splits m hm α (liftSign ell) η
    (liftSign_abs ell) hη P K hP.le hK.le A S M v hdata
  refine ⟨t,ht,min ε 1,lt_min hε zero_lt_one,?_⟩
  intro lam hlam hsmall
  obtain ⟨hper,hUH,hrot⟩:=hout lam hlam (hsmall.trans_le (min_le_left _ _))
  refine ⟨hsmall.trans_le (min_le_right _ _),?_,hrot⟩
  exact hUH

end PaperUAMO.InteriorSeed

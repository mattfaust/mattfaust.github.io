import PaperUAMO.SymmetricSplitting
import UAMODraft.PhysicalHyperbolicResolvent
import UAMODraft.PhysicalLiftLabel
import UAMO.PhysicalOpenGapAllCuts

noncomputable section
namespace PaperUAMO.InteriorSeedGapBridge
open UAMO UAMO.CMV UAMODraft.SpectralBridge UAMODraft.CircleCover UAMODraft.CoverHyperbolicity
open PaperUAMO.SymmetricSplitting

theorem physicalRotationLabel_of_rotation {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (α t ρ : ℝ)
    (hrot : HasRotationNumber (physicalRealPhase a (coupling r) t) α ρ) :
    HasPhysicalRotationLabel a (coupling r) t α (ρ:AddCircle (1:ℝ)) := by
  obtain ⟨F,hFc,_hFp,hFd,_hFm,_hFa,hFl⟩ := hrot
  exact UAMODraft.SeedLabel.physicalRotationLabel_of_genuine_lift ha
    (by unfold coupling; positivity) (coupling_lt_one_of_lt_one hr1) t α ρ F hFc hFd hFl

theorem openDOSGapLabel_of_hyperbolic_rotation {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (hα : Irrational α)
    (t ρ : ℝ)
    (hUH : IsUniformlyHyperbolicOnLines (translation 1 α)
      (physicalRealCircle a (coupling r) t))
    (hrot : HasRotationNumber (physicalRealPhase a (coupling r) t) α ρ) :
    OpenDOSGapLabel a r α ha.le ha1 hr hr1.le (ρ:AddCircle (1:ℝ)) ∧
      OpenPhysicalRotationGapLabel a r α (ρ:AddCircle (1:ℝ)) := by
  have hlabel := physicalRotationLabel_of_rotation ha hr hr1 α t ρ hrot
  have hDOS := ((physicalRotationLabel_iff_DOS ha ha1 hr hr1 α hα t
    (ρ:AddCircle (1:ℝ))).mp hlabel).symm
  have hopen := openDOSGapLabel_of_witness_all_cuts ha ha1 hr hr1.le hα 0
    (Complex.exp ((t:ℂ)*Complex.I)) (Complex.norm_exp_ofReal_mul_I t)
    (physical_resolvent_of_uniformHyperbolic ha ha1 hr hr1 α t hUH 0)
    (ρ:AddCircle (1:ℝ)) hDOS
  exact ⟨hopen,(openPhysicalRotationGapLabel_iff_DOS ha ha1 hr hr1 hα _).mpr hopen⟩

end PaperUAMO.InteriorSeedGapBridge

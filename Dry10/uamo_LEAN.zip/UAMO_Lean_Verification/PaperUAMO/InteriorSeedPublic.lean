import PaperUAMO.InteriorSeeds
import UAMODraft.PublicBoundary

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.PhysicalWalk UAMOSimple MeasureTheory Set

theorem physical_interior_seed_gaps {lam₀ α : ℝ}
    (h₀ : 0<lam₀) (h₀1 : lam₀<1) (hα : Irrational α) (m : ℤ) :
    ∃ ε : ℝ, 0<ε ∧ ε<lam₀ ∧ ∀(lam:ℝ) (hlam:0<lam), lam<ε →
      ∃hlam1:lam<1, ∀ell:ℤ,
        OpenPhysicalCouplingGapLabel lam₀ lam α h₀.le h₀1.le hlam.le hlam1.le
          (uamoGapLabel α m ell) ∧
        OpenPhysicalCouplingGapLabel lam lam₀ α hlam.le hlam1.le h₀.le h₀1.le
          (uamoGapLabel α m ell) := by
  let a := stereographicParameter lam₀
  have ha : 0<a := by dsimp [a,stereographicParameter]; positivity
  have hale : a≤lam₀ := by
    dsimp [a,stereographicParameter]
    exact div_le_self h₀.le (by linarith [Real.sqrt_nonneg (1-lam₀^2)])
  have ha1 : a<1 := hale.trans_lt h₀1
  obtain ⟨ε,hε,hεa,hseed⟩ := appendix_interior_seed_gaps ha ha1 α hα m
  refine ⟨ε,hε,hεa.trans_le hale,?_⟩
  intro lam hlam hsmall
  have hlam1 : lam<1 := ((hsmall.trans hεa).trans_le hale).trans h₀1
  have hr : 0<stereographicParameter lam := by unfold stereographicParameter; positivity
  have hrle : stereographicParameter lam≤lam := by
    unfold stereographicParameter
    exact div_le_self hlam.le (by linarith [Real.sqrt_nonneg (1-lam^2)])
  obtain ⟨_,hg⟩ := hseed (stereographicParameter lam) hr (hrle.trans_lt hsmall)
  refine ⟨hlam1,?_⟩
  intro ell
  constructor
  · rw [openPhysicalCouplingGapLabel_iff]
    exact (hg ell).1
  · rw [openPhysicalCouplingGapLabel_iff]
    exact (hg ell).2

theorem appendix_interior_seed_gaps_single_winding {lam₀ α : ℝ}
    (h₀ : 0 < lam₀) (h₀1 : lam₀ < 1) (hα : Irrational α) (m : ℤ) :
    ∃ ε : ℝ, 0 < ε ∧ ε < lam₀ ∧ ∀ lam : ℝ, 0 < lam → lam < ε →
      ∀ label : AddCircle (1 : ℝ),
        (2 : ℕ) • label = (((m : ℝ) * α : ℝ) : AddCircle (1 : ℝ)) →
        HasGap lam₀ lam α (dos lam₀ lam α) label ∧
        HasGap lam lam₀ α (dos lam lam₀ α) label := by
  obtain ⟨ε, hε, hε₀, hseed⟩ := physical_interior_seed_gaps h₀ h₀1 hα m
  refine ⟨ε, hε, hε₀, ?_⟩
  intro lam hlam hsmall label hlabel
  obtain ⟨hlam1, hgaps⟩ := hseed lam hlam hsmall
  obtain ⟨ell, rfl⟩ := UAMODraft.PublicAssembly.doubled_label_eq_gapLabel α m label hlabel
  exact ⟨(UAMODraft.PublicAssembly.public_gap_iff_physical lam₀ lam α
      ⟨h₀, h₀1.le⟩ ⟨hlam, hlam1.le⟩ _).mpr (hgaps ell).1,
    (UAMODraft.PublicAssembly.public_gap_iff_physical lam lam₀ α
      ⟨hlam, hlam1.le⟩ ⟨h₀, h₀1.le⟩ _).mpr (hgaps ell).2⟩

end PaperUAMO.InteriorSeed

import UAMO.PhysicalAxisOpenGaps
import UAMO.PhysicalCircleReflection
import UAMO.PhysicalOpenGapDuality

noncomputable section
namespace PaperUAMO.InteriorSeedSymmetries
open UAMO UAMO.CircleDOS UAMO.PhysicalDOS Set

theorem physical_arcLabel_conjugate_quotient {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (α : ℝ) (z : ℂ) (hz : ‖z‖=1) :
    ((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1) (star z):ℝ):AddCircle (1:ℝ)) =
      -((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1) z:ℝ):AddCircle (1:ℝ)) := by
  by_cases him : z.im=0
  · have hre : z.re^2=1 := by
      have h := Complex.sq_norm z
      rw [hz] at h
      simp only [one_pow,Complex.normSq_apply,him,zero_pow (by decide : 2≠0),add_zero] at h
      nlinarith [h]
    have hcases : z.re=1 ∨ z.re= -1 := (sq_eq_one_iff).mp hre
    have haxes : z=1 ∨ z= -1 := by
      rcases hcases with h|h
      · left; apply Complex.ext <;> simp [h,him]
      · right; apply Complex.ext <;> simp [h,him]
    obtain ⟨hone,hneg⟩ := physical_axis_arcLabels ha ha1 hr hr1 α
    rcases haxes with rfl|rfl
    · simp only [star_one,hone,AddCircle.coe_period,neg_zero]
    · simp only [star_neg,star_one,hneg]
      apply add_eq_zero_iff_eq_neg.mp
      rw [←AddCircle.coe_add]
      norm_num
  · rw [physical_arcLabel_conj ha ha1 hr hr1 α him,AddCircle.coe_sub,
      AddCircle.coe_period,zero_sub]

theorem openDOSGapLabel_neg {a r α : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (hα : Irrational α)
    (label : AddCircle (1:ℝ))
    (hgap : OpenDOSGapLabel a r α ha.le ha1 hr hr1 label) :
    OpenDOSGapLabel a r α ha.le ha1 hr hr1 (-label) := by
  obtain ⟨t,δ,hδ,hgap⟩ := hgap
  refine ⟨-t,δ,hδ,?_⟩
  intro s hs
  have hs' : |(-s)-t|<δ := by
    simpa only [show -s-t= -(s- -t) by ring,abs_neg] using hs
  obtain ⟨hres,hlabel⟩ := hgap (-s) hs'
  let z : ℂ := Complex.exp (((-s:ℝ):ℂ)*Complex.I)
  have hz : ‖z‖=1 := Complex.norm_exp_ofReal_mul_I (-s)
  have hstar : star z=Complex.exp ((s:ℂ)*Complex.I) := by
    simp [z,Complex.star_def,←Complex.exp_conj]
  constructor
  · intro θ
    rw [←hstar]
    exact (physical_circle_resolvent_star ha ha1 hr hr1 hα θ z hz).mpr (hres θ)
  · rw [←hstar,physical_arcLabel_conjugate_quotient ha ha1 hr hr1 α z hz]
    exact congrArg Neg.neg hlabel

def PositiveInteriorSeeds (a : ℝ) (ha : 0<a) (ha1 : a<1) : Prop :=
  ∀ α : ℝ, Irrational α → ∀ m : ℕ, 0 < m → ∀ ell : ℤ,
    ∃ ε : ℝ, 0<ε ∧ ε<a ∧ ∀ r : ℝ, ∀ hr : 0<r, r<ε →
      ∃ hr1 : r<1, OpenDOSGapLabel a r α ha.le ha1.le hr.le hr1.le
        (uamoGapLabel α m ell)

theorem positive_seeds_uniform_lifts {a : ℝ} (ha : 0<a) (ha1 : a<1)
    (hseed : PositiveInteriorSeeds a ha ha1) (α : ℝ) (hα : Irrational α)
    (m : ℕ) (hm : 0 < m) :
    ∃ ε : ℝ, 0<ε ∧ ε<a ∧ ∀ r : ℝ, ∀ hr : 0<r, r<ε →
      ∃ hr1 : r<1, ∀ell:ℤ, OpenDOSGapLabel a r α ha.le ha1.le hr.le hr1.le
        (uamoGapLabel α m ell) := by
  obtain ⟨ε₀,hε₀,hε₀a,h₀⟩ := hseed α hα m hm 0
  obtain ⟨ε₁,hε₁,_hε₁a,h₁⟩ := hseed α hα m hm 1
  refine ⟨min ε₀ ε₁,lt_min hε₀ hε₁,(min_le_left _ _).trans_lt hε₀a,?_⟩
  intro r hr hsmall
  obtain ⟨hr1,hg₀⟩ := h₀ r hr (hsmall.trans_le (min_le_left _ _))
  obtain ⟨_,hg₁⟩ := h₁ r hr (hsmall.trans_le (min_le_right _ _))
  refine ⟨hr1,?_⟩
  intro ell
  rcases Int.even_or_odd ell with h|h
  · have heq : uamoGapLabel α m ell=uamoGapLabel α m 0 :=
      (uamoGapLabel_eq_iff hα _ _ _ _).mpr ⟨rfl,by simpa only [sub_zero] using h⟩
    simpa only [heq] using hg₀
  · obtain ⟨k,hk⟩ := h
    have heq : uamoGapLabel α m ell=uamoGapLabel α m 1 :=
      (uamoGapLabel_eq_iff hα _ _ _ _).mpr ⟨rfl,k,by omega⟩
    simpa only [heq] using hg₁

theorem seeds_all_signed_windings {a : ℝ} (ha : 0<a) (ha1 : a<1)
    (hseed : PositiveInteriorSeeds a ha ha1) (α : ℝ) (hα : Irrational α)
    (m : ℤ) :
    ∃ ε : ℝ, 0<ε ∧ ε<a ∧ ∀ r : ℝ, ∀ hr : 0<r, r<ε →
      ∃ hr1 : r<1, ∀ell:ℤ, OpenDOSGapLabel a r α ha.le ha1.le hr.le hr1.le
        (uamoGapLabel α m ell) := by
  by_cases hm : m=0
  · subst m
    refine ⟨a/2,half_pos ha,by linarith,?_⟩
    intro r hr hsmall
    have hr1 : r<1 := by linarith
    exact ⟨hr1,fun ell=>(physical_axis_open_zero_winding_label ha ha1 hr.le hr1 hα ell).1⟩
  · obtain ⟨ε,hε,hεa,hg⟩ := positive_seeds_uniform_lifts ha ha1 hseed α hα m.natAbs
      (Int.natAbs_pos.mpr hm)
    refine ⟨ε,hε,hεa,?_⟩
    intro r hr hsmall
    obtain ⟨hr1,hg⟩ := hg r hr hsmall
    refine ⟨hr1,?_⟩
    intro ell
    by_cases hm0 : 0 ≤ m
    · have he : (m.natAbs:ℤ)=m := by rw [Int.natCast_natAbs,abs_of_nonneg hm0]
      simpa only [he] using hg ell
    · have he : -(m.natAbs:ℤ)=m := by
        rw [Int.natCast_natAbs,abs_of_neg (lt_of_not_ge hm0),neg_neg]
      have href := openDOSGapLabel_neg ha ha1.le hr.le hr1.le hα _ (hg ell)
      rw [←uamoGapLabel_neg_winding,he] at href
      exact href

theorem interior_seeds_all_signed_both_orders {a : ℝ} (ha : 0<a) (ha1 : a<1)
    (hseed : PositiveInteriorSeeds a ha ha1) (α : ℝ) (hα : Irrational α)
    (m : ℤ) :
    ∃ ε : ℝ, 0<ε ∧ ε<a ∧ ∀ r : ℝ, ∀ hr : 0<r, r<ε →
      ∃ hr1 : r<1, ∀ell:ℤ,
        OpenDOSGapLabel a r α ha.le ha1.le hr.le hr1.le (uamoGapLabel α m ell) ∧
        OpenDOSGapLabel r a α hr.le hr1.le ha.le ha1.le (uamoGapLabel α m ell) := by
  obtain ⟨ε,hε,hεa,hg⟩ := seeds_all_signed_windings ha ha1 hseed α hα m
  obtain ⟨η,hη,_hηa,hd⟩ := seeds_all_signed_windings ha ha1 hseed (-α) hα.neg (-m)
  refine ⟨min ε η,lt_min hε hη,(min_le_left _ _).trans_lt hεa,?_⟩
  intro r hr hsmall
  obtain ⟨hr1,hg⟩ := hg r hr (hsmall.trans_le (min_le_left _ _))
  obtain ⟨_,hd⟩ := hd r hr (hsmall.trans_le (min_le_right _ _))
  refine ⟨hr1,fun ell=>⟨hg ell,?_⟩⟩
  have hx := openDOSGapLabel_exchange ha.le ha1.le hr.le hr1.le hα.neg
    (uamoGapLabel (-α) (-m) ell) (hd ell)
  simpa only [neg_neg,uamoGapLabel_reverse_frequency] using hx

end PaperUAMO.InteriorSeedSymmetries

import PaperUAMO.InteriorSeedCore
import PaperUAMO.InteriorSeedSymmetries
import UAMODraft.SeedLabelParity

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed InteriorSeedSymmetries

theorem positive_interior_seeds (a : ℝ) (ha : 0<a) (ha1 : a<1) :
    PositiveInteriorSeeds a ha ha1 := by
  intro α hα m hm ell
  obtain ⟨t,_ht,ε,hε,hseed⟩ := positive_interior_seed_hyperbolicity ha ha1 hα m hm ell
  refine ⟨min (a/2) (ε/2),lt_min (by positivity) (by positivity),
    (min_le_left _ _).trans_lt (by linarith),?_⟩
  intro r hr hsmall
  have hra:r<a := (hsmall.trans_le (min_le_left _ _)).trans (by linarith)
  have hr1:r<1 := hra.trans ha1
  have hcouple:coupling r<ε := by
    have hbound:coupling r≤2*r := by
      rw [coupling,div_le_iff₀ (by positivity : (0:ℝ)<1+r^2)]
      nlinarith [sq_nonneg r]
    have hsmall':r<ε/2 := hsmall.trans_le (min_le_right _ _)
    linarith
  obtain ⟨_hc1,hUH,hrot⟩ := hseed (coupling r) (coupling_pos hr) hcouple
  refine ⟨hr1,?_⟩
  have hg := (InteriorSeedGapBridge.openDOSGapLabel_of_hyperbolic_rotation
    ha ha1.le hr.le hr1 hα (t (coupling r)) _ hUH hrot).1
  simpa only [UAMODraft.SeedLabel.seed_sign_rotation_label] using hg

theorem appendix_interior_seed_gaps {a : ℝ} (ha : 0<a) (ha1 : a<1)
    (α : ℝ) (hα : Irrational α) (m : ℤ) :
    ∃ ε : ℝ, 0<ε ∧ ε<a ∧ ∀ r : ℝ, ∀ hr : 0<r, r<ε →
      ∃ hr1 : r<1, ∀ell:ℤ,
        OpenDOSGapLabel a r α ha.le ha1.le hr.le hr1.le (uamoGapLabel α m ell) ∧
        OpenDOSGapLabel r a α hr.le hr1.le ha.le ha1.le (uamoGapLabel α m ell) :=
  interior_seeds_all_signed_both_orders ha ha1 (positive_interior_seeds a ha ha1) α hα m

end PaperUAMO.InteriorSeed

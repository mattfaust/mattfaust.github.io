import PaperUAMO.InteriorSeedCore
import PaperUAMO.InteriorFrameProximity
import PaperUAMO.InteriorFrameAnalytic

noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed Filter Matrix
open PaperUAMO.FreeElliptic PaperUAMO.InteriorNormalForm PaperUAMO.InteriorFrame
open scoped Topology Matrix.L2OpNorm

def physicalSeedFrame (a θ : ℝ) (m : ℕ) (x : ℝ→Variables m) (lam y : ℝ) : FreeElliptic.RMat :=
  physicalFrame (realGauge a θ (x lam (zeroMode m)).im) m (physicalProfile m (x lam)) y

theorem realGauge_entry_analytic {a θ : ℝ} (ha : 0<a) (he1 : coupling a<1)
    (hs : Real.sin θ≠0) (i j : Fin 2) :
    AnalyticAt ℝ (fun h=>realGauge a θ h i j) 0 := by
  have hf:=freeFrame_analytic ha he1 hs
  have hij (p q:Fin 2) := analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hf p) q
  simp only [realGauge,Matrix.mul_apply,Fin.sum_univ_two]
  exact ((hij i 0).mul analyticAt_const).add ((hij i 1).mul analyticAt_const)

theorem profile_parameter_analyticAt {m : ℕ} (x : ℝ→Variables m) {t:ℝ}
    (hxa : AnalyticAt ℝ x t) (y:ℝ) :
    AnalyticAt ℝ (fun lam=>physicalProfile m (x lam) y) t := by
  apply AnalyticAt.pi
  intro i
  simp_rw [physicalProfile_sum]
  apply Finset.analyticAt_sum
  intro k _
  exact ((coefficient_analyticAt m k i (x t)).comp hxa).mul analyticAt_const

theorem halfPhase_analyticAt (m:ℕ) (y:ℝ) : AnalyticAt ℝ (halfPhase m) y := by
  unfold halfPhase
  apply analyticAt_cexp.restrictScalars.comp
  exact ((Complex.ofRealCLM.analyticAt _).comp
    (analyticAt_const.mul analyticAt_id)).mul analyticAt_const

theorem physicalSeedFrame_analytic_phase (a θ:ℝ) (m:ℕ) (x:ℝ→Variables m)
    (lam y:ℝ) (hsig:0<profileSignature (physicalProfile m (x lam) y)) (i j:Fin 2) :
    AnalyticAt ℝ (fun z=>physicalSeedFrame a θ m x lam z i j) y := by
  have hb:=InteriorFrameAnalytic.realFrameOf_analyticAt
    (physicalProfile_analytic_phase m (x lam) y) (halfPhase_analyticAt m y) hsig 1
  have hij (p q:Fin 2) := analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hb p) q
  simp only [physicalSeedFrame,physicalFrame,pairedRealFrame,Matrix.mul_apply,Fin.sum_univ_two]
  exact (analyticAt_const.mul (hij 0 j)).add (analyticAt_const.mul (hij 1 j))

theorem physicalSeedFrame_analytic_parameter_eventually {a θ:ℝ}
    (ha:0<a) (he1:coupling a<1) (hs:Real.sin θ≠0)
    {m:ℕ} (x:ℝ→Variables m) (hx0:x 0=0) (hxa:AnalyticAt ℝ x 0) :
    ∀ᶠ lam in 𝓝 (0:ℝ),∀y,0<profileSignature (physicalProfile m (x lam) y) →
      ∀i j,AnalyticAt ℝ (fun u=>physicalSeedFrame a θ m x u y i j) lam := by
  have hlim:Tendsto (fun lam=>(x lam (zeroMode m)).im) (𝓝 0) (𝓝 0) := by
    simpa only [Function.comp_def,hx0,Pi.zero_apply,Complex.zero_im] using
      (Complex.continuous_im.continuousAt.comp
        ((continuous_apply (zeroMode m)).continuousAt.comp hxa.continuousAt)).tendsto
  have he : ∀ᶠ h in 𝓝 (0:ℝ),∀i j,AnalyticAt ℝ (fun u=>realGauge a θ u i j) h := by
    rw [eventually_all]
    intro i
    rw [eventually_all]
    intro j
    exact (realGauge_entry_analytic ha he1 hs i j).eventually_analyticAt
  filter_upwards [hxa.eventually_analyticAt,hlim.eventually he] with lam hxl hgl y hsig i j
  have hp : AnalyticAt ℝ (fun u=>(x u (zeroMode m)).im) lam :=
    (Complex.imCLM.analyticAt _).comp
      ((ContinuousLinearMap.proj (zeroMode m) : Variables m→L[ℝ]ℂ).analyticAt (x lam) |>.comp hxl)
  have hg (p q:Fin 2) : AnalyticAt ℝ
      (fun u=>realGauge a θ (x u (zeroMode m)).im p q) lam := AnalyticAt.comp (f:=fun u:ℝ=>(x u (zeroMode m)).im) (x:=lam) (hgl p q) hp
  have hb:=InteriorFrameAnalytic.realFrameOf_analyticAt
    (profile_parameter_analyticAt x hxl y) (show AnalyticAt ℝ (fun _:ℝ=>halfPhase m y) lam from analyticAt_const) hsig 1
  have hij (p q:Fin 2) := analyticAt_pi_iff.mp (analyticAt_pi_iff.mp hb p) q
  simp only [physicalSeedFrame,physicalFrame,pairedRealFrame,Matrix.mul_apply,Fin.sum_univ_two]
  exact ((hg i 0).mul (hij 0 j)).add ((hg i 1).mul (hij 1 j))

theorem realGauge_branch_bound {a θ:ℝ} (ha:0<a) (he1:coupling a<1)
    (hs:Real.sin θ≠0) {m:ℕ} (x:ℝ→Variables m) (hx0:x 0=0) (hxa:AnalyticAt ℝ x 0) :
    ∃D ε:ℝ,0<D ∧ 0<ε ∧ ∀lam,|lam|<ε →
      ‖realGauge a θ (x lam (zeroMode m)).im-realGauge a θ 0‖≤D*|lam| := by
  have hp : AnalyticAt ℝ (fun lam=>(x lam (zeroMode m)).im) 0 :=
    (Complex.imCLM.analyticAt _).comp
      ((ContinuousLinearMap.proj (zeroMode m) : Variables m→L[ℝ]ℂ).analyticAt (x 0) |>.comp hxa)
  have hg (i j:Fin 2) : AnalyticAt ℝ (fun lam=>realGauge a θ (x lam (zeroMode m)).im i j) 0 := by
    have hhg : AnalyticAt ℝ (fun h=>realGauge a θ h i j) (x 0 (zeroMode m)).im := by
      simpa only [hx0,Pi.zero_apply,Complex.zero_im] using realGauge_entry_analytic ha he1 hs i j
    exact AnalyticAt.comp (f:=fun u:ℝ=>(x u (zeroMode m)).im) (x:=(0:ℝ)) hhg hp
  let E:ℝ→(Fin 2×Fin 2)→ℝ:=fun lam p=>
    realGauge a θ (x lam (zeroMode m)).im p.1 p.2-realGauge a θ 0 p.1 p.2
  have ho : E =O[𝓝 (0:ℝ)] (fun lam=>lam) := by
    apply Asymptotics.isBigO_pi.mpr
    intro p
    simpa only [E,hx0,Pi.zero_apply,Complex.zero_im,sub_zero] using
      (hg p.1 p.2).differentiableAt.isBigO_sub
  obtain ⟨D,hD,hbound⟩:=ho.exists_pos
  obtain ⟨ε,hε,hεb⟩:=Metric.eventually_nhds_iff.mp hbound.bound
  refine ⟨4*D,ε,by positivity,hε,?_⟩
  intro lam hlam
  have hb:‖E lam‖≤D*|lam| := by
    simpa using hεb (by simpa only [Real.dist_eq,sub_zero] using hlam)
  have hn:=operator_norm_le_four_entries
    (realGauge a θ (x lam (zeroMode m)).im-realGauge a θ 0)
    (by positivity : 0≤D*|lam|) (fun i j=>by
      exact (norm_le_pi_norm (E lam) (i,j)).trans hb)
  simpa only [mul_assoc] using hn

theorem physicalSeedFrame_uniform_proximity {a θ:ℝ} (ha:0<a) (he1:coupling a<1)
    (hs:Real.sin θ≠0) {m:ℕ} (x:ℝ→Variables m) (hx0:x 0=0) (hxa:AnalyticAt ℝ x 0) :
    ∃C ε:ℝ,0<C ∧ 0<ε ∧ ∀lam,0≤lam → lam<ε → ∀y,
      ‖physicalSeedFrame a θ m x lam y-realGauge a θ 0*rotation (Real.pi*(m:ℝ)*y)‖≤C*lam := by
  obtain ⟨D,εd,hD,hεd,hd⟩:=realGauge_branch_bound ha he1 hs x hx0 hxa
  obtain ⟨P,εp,hP,hεp,hp⟩:=analytic_profile_uniform_bound x hx0 hxa
  let L:=‖realGauge a θ 0‖+D
  let C:=64*L*P+D
  have hL:0<L:=by dsimp[L];positivity
  let ε:=min εd (min εp (min 1 (1/(4*(P+1)))))
  have hε:0<ε:=by dsimp[ε];positivity
  refine ⟨C,ε,by dsimp[C];positivity,hε,?_⟩
  intro lam hlam hl y
  have hld:lam<εd:=hl.trans_le (min_le_left _ _)
  have hlp:lam<εp:=hl.trans_le ((min_le_right _ _).trans (min_le_left _ _))
  have hl1:lam<1:=hl.trans_le ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
  have hls:lam<1/(4*(P+1)):=hl.trans_le ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
  have hpl:P*lam≤1/4:=by
    have hh:=(lt_div_iff₀ (show 0<4*(P+1) by positivity)).mp hls
    nlinarith
  have hb:=hd lam (by rwa [abs_of_nonneg hlam])
  rw [abs_of_nonneg hlam] at hb
  have hS:‖realGauge a θ (x lam (zeroMode m)).im‖≤L := by
    have hh:=norm_add_le (realGauge a θ (x lam (zeroMode m)).im-realGauge a θ 0) (realGauge a θ 0)
    rw [sub_add_cancel] at hh
    dsimp[L]
    nlinarith
  have hv:∀z,‖physicalProfile m (x lam) z 0-1‖≤P*lam ∧
      ‖physicalProfile m (x lam) z 1‖≤P*lam := by
    intro z
    constructor
    · simpa only [ite_true,abs_of_nonneg hlam] using hp lam z 0 (by rwa [abs_of_nonneg hlam])
    · simpa only [show (1:Fin 2)≠0 by decide,ite_false,sub_zero,abs_of_nonneg hlam] using
        hp lam z 1 (by rwa [abs_of_nonneg hlam])
  have hh:=physicalFrame_proximity (realGauge a θ (x lam (zeroMode m)).im)
    (realGauge a θ 0) m (physicalProfile m (x lam)) (mul_nonneg hP.le hlam) hpl hv y
  change ‖physicalSeedFrame a θ m x lam y-_‖≤_ at hh
  apply hh.trans
  dsimp[C]
  have hmul:=mul_le_mul_of_nonneg_right hS (mul_nonneg (by norm_num : (0:ℝ)≤64) (mul_nonneg hP.le hlam))
  nlinarith

end PaperUAMO.InteriorSeed

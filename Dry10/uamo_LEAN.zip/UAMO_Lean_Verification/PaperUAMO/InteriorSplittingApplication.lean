import PaperUAMO.InteriorRealNormalForm
import PaperUAMO.SymmetricSplittingCircle

noncomputable section
namespace PaperUAMO.InteriorNormalForm
open Matrix Filter Set UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open PaperUAMO.FreeElliptic PaperUAMO.InteriorFrame
open PaperUAMO.SymmetricSplitting UAMODraft.QuantitativeOpening
open UAMODraft.CircleCover UAMODraft.CoverHyperbolicity
open scoped Matrix.L2OpNorm Topology

def signedLeading (σ:ℝ) (η:ℂ) : RMat := σ • realLeading η

def realNormalError (S:RMat) (m:ℕ) (α σ lam:ℝ) (A:ℝ → RMat)
    (v:ℝ → Spin) (η:ℂ) (x:ℝ) : RMat :=
  σ • ((physicalFrame S m v (x+α))⁻¹*A x*physicalFrame S m v x)-
    1-lam^m • signedLeading σ η

theorem signedLeading_data {σ:ℝ} (hσ:|σ|=1) (η:ℂ) :
    (signedLeading σ η).transpose=signedLeading σ η ∧
    Matrix.trace (signedLeading σ η)=0 ∧ ‖signedLeading σ η‖=‖η‖ := by
  refine ⟨?_,?_,?_⟩
  · rw [signedLeading,Matrix.transpose_smul,realLeading_symmetric]
  · rw [signedLeading,Matrix.trace_smul,realLeading_trace,smul_zero]
  · rw [signedLeading,norm_smul,Real.norm_eq_abs,hσ,one_mul,realLeading_norm]

theorem real_normal_error_bound (S:RMat) (m:ℕ) (α σ lam:ℝ)
    (A:ℝ → RMat) (M:ℝ → Mat) (v:ℝ → Spin) (η:ℂ) (hσ:|σ|=1)
    (hS:S.det=1) (hv:∀x,0<profileSignature (v x))
    (hinter:∀x,complexify (A x)*complexify S=complexify S*
      ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M x))
    {ε:ℝ} (hε:0≤ε)
    (herr:∀x i j,‖transformed m α lam M v x i j-
      ((σ:ℂ) • (1:Mat)+((lam^m:ℝ):ℂ) • hermitianSeed η) i j‖≤ε) (x:ℝ) :
    ‖realNormalError S m α σ lam A v η x‖≤8*ε := by
  let T:=(physicalFrame S m v (x+α))⁻¹*A x*physicalFrame S m v x
  have ht : ∀i j,|((T-(σ • (1:RMat)+lam^m • realLeading η)) i j)|≤2*ε := by
    apply real_entry_error T σ (lam^m) η hε
    rw [show complexify T=transformed m α lam M v x from
      physicalFrame_conjugacy S m α lam A M v hS hv hinter x]
    exact herr x
  have hσ2 : σ*σ=1 := by nlinarith [sq_abs σ]
  have he : realNormalError S m α σ lam A v η x=
      σ • (T-(σ • (1:RMat)+lam^m • realLeading η)) := by
    ext i j
    simp only [realNormalError,signedLeading,Matrix.sub_apply,Matrix.add_apply,
      Matrix.smul_apply,smul_eq_mul,T]
    linear_combination (1:RMat) i j*hσ2
  rw [he,norm_smul,Real.norm_eq_abs,hσ,one_mul]
  have hb:=operator_norm_le_four_entries (T-(σ • (1:RMat)+lam^m • realLeading η))
    (by positivity : 0≤2*ε) ht
  linarith

theorem real_normal_equation (S:RMat) (m:ℕ) (α σ lam:ℝ)
    (A:ℝ → RMat) (v:ℝ → Spin) (η:ℂ) (x:ℝ) :
    σ • ((physicalFrame S m v (x+α))⁻¹*A x*physicalFrame S m v x)=
      1+lam^m • signedLeading σ η+realNormalError S m α σ lam A v η x := by
  unfold realNormalError
  abel

theorem real_normal_form_data (S:RMat) (m:ℕ) (α σ lam:ℝ)
    (A:ℝ → RMat) (M:ℝ → Mat) (v:ℝ → Spin) (η:ℂ) (hσ:|σ|=1)
    (hS:S.det=1) (hvcont:Continuous v) (hvper:Function.Periodic v 1)
    {e ε:ℝ} (he0:0≤e) (he:e<1/4) (hε:0≤ε)
    (hv:∀x,‖v x 0-1‖≤e ∧ ‖v x 1‖≤e)
    (hinter:∀x,complexify (A x)*complexify S=complexify S*
      ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M x))
    (herr:∀x i j,‖transformed m α lam M v x i j-
      ((σ:ℂ) • (1:Mat)+((lam^m:ℝ):ℂ) • hermitianSeed η) i j‖≤ε) :
    Continuous (physicalFrame S m v) ∧
    (∀x,(physicalFrame S m v x).det=1) ∧
    (∀x,physicalFrame S m v (x+1)=((-1:ℝ)^(m:ℤ)) • physicalFrame S m v x) ∧
    HasProjectiveDegree (physicalFrame S m v) (m:ℤ) ∧
    (∀x,‖realNormalError S m α σ lam A v η x‖≤8*ε) := by
  obtain ⟨hc,hd,hp,hdeg⟩:=left_pairedRealFrame_degree_data S hS m v hvcont hvper
    he0 he (fun x=>(hv x).1) (fun x=>(hv x).2)
  exact ⟨hc,hd,hp,hdeg,real_normal_error_bound S m α σ lam A M v η hσ hS
    (signature_pos v he0 he (fun x=>(hv x).1) (fun x=>(hv x).2)) hinter hε herr⟩

theorem paired_normal_form_splits (m:ℕ) (hm : 0 < m) (α σ:ℝ) (η:ℂ)
    (hσ:|σ|=1) (hη:η≠0) (P K:ℝ) (hP:0≤P) (hK:0≤K)
    (A:ℝ → ℝ → RMat) (S:ℝ → RMat) (M:ℝ → ℝ → Mat) (v:ℝ → ℝ → Spin)
    (hdata:∀ᶠ lam in 𝓝[>] (0:ℝ),
      Continuous (A lam) ∧ Function.Periodic (A lam) 1 ∧
      (∀x,(A lam x).det=1) ∧ (S lam).det=1 ∧
      Continuous (v lam) ∧ Function.Periodic (v lam) 1 ∧
      (∀x,‖v lam x 0-1‖≤P*lam ∧ ‖v lam x 1‖≤P*lam) ∧
      (∀x,complexify (A lam x)*complexify (S lam)=complexify (S lam)*
        ((realTransferDenominator lam (2*Real.pi*x):ℂ)⁻¹ • M lam x)) ∧
      (∀x i j,‖transformed m α lam (M lam) (v lam) x i j-
        ((σ:ℂ) • (1:Mat)+((lam^m:ℝ):ℂ) • hermitianSeed η) i j‖≤K*lam^(m+1))) :
    ∃ε>0,∀lam,0<lam → lam<ε →
      ∃hp:Function.Periodic (A lam) 1,
        IsUniformlyHyperbolicOnLines (translation 1 α) (periodicLift (A lam) hp) ∧
        HasRotationNumber (A lam) α ((m:ℝ)*α/2+(1-σ)/4) := by
  have hηpos : 0<‖η‖:=norm_pos_iff.mpr hη
  have hid : Tendsto (fun lam:ℝ=>lam) (𝓝[>] 0) (𝓝 0):=tendsto_id'.mpr inf_le_left
  have hp0 : Tendsto (fun lam:ℝ=>P*lam) (𝓝[>] 0) (𝓝 0) := by
    simpa only [mul_zero] using tendsto_const_nhds.mul hid
  have hk0 : Tendsto (fun lam:ℝ=>32*K*lam) (𝓝[>] 0) (𝓝 0) := by
    simpa only [mul_zero] using tendsto_const_nhds.mul hid
  have hd0 : Tendsto (fun lam:ℝ=>lam^m*‖η‖) (𝓝[>] 0) (𝓝 0) := by
    simpa only [zero_pow hm.ne',zero_mul] using (hid.pow m).mul tendsto_const_nhds
  have hpos : ∀ᶠ lam in 𝓝[>] (0:ℝ),0<lam:=self_mem_nhdsWithin
  have hevent : ∀ᶠ lam in 𝓝[>] (0:ℝ),
      ∃hp:Function.Periodic (A lam) 1,
        IsUniformlyHyperbolicOnLines (translation 1 α) (periodicLift (A lam) hp) ∧
        HasRotationNumber (A lam) α ((m:ℝ)*α/2+(1-σ)/4) := by
    filter_upwards [hdata,hpos,(tendsto_order.mp hp0).2 (1/4) (by norm_num),
      (tendsto_order.mp hk0).2 ‖η‖ hηpos,(tendsto_order.mp hd0).2 1 (by norm_num)]
      with lam hh hlam hp hk hd
    obtain ⟨hAc,hAp,hAd,hSd,hvc,hvp,hv,hinter,herr⟩:=hh
    obtain ⟨hBc,hBd,hBp,hdeg,herror⟩:=real_normal_form_data (S lam) m α σ lam
      (A lam) (M lam) (v lam) η hσ hSd hvc hvp (mul_nonneg hP hlam.le) hp
      (mul_nonneg hK (pow_nonneg hlam.le _)) hv hinter herr
    have hlead:=signedLeading_data hσ η
    have hdn : ‖lam^m • signedLeading σ η‖=lam^m*‖η‖ := by
      rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (pow_nonneg hlam.le _),hlead.2.2]
    refine ⟨hAp,?_⟩
    have hresult:=symmetric_splitting_at α σ (m:ℤ) hσ (A lam)
      (physicalFrame (S lam) m (v lam))
      (realNormalError (S lam) m α σ lam (A lam) (v lam) η)
      (lam^m • signedLeading σ η) hAc hAp hAd hBc hBd hBp hdeg
      (by rw [Matrix.transpose_smul,hlead.1])
      (by rw [Matrix.trace_smul,hlead.2.1,smul_zero])
      (by rw [hdn];positivity) (by rw [hdn];exact hd.le) ?_
      (real_normal_equation (S lam) m α σ lam (A lam) (v lam) η)
    · simpa only [Int.cast_natCast] using hresult
    · intro x
      apply (herror x).trans
      rw [hdn,pow_succ]
      have ht:=mul_le_mul_of_nonneg_right hk.le (pow_nonneg hlam.le m)
      nlinarith
  obtain ⟨ε,hε,hsub⟩:=mem_nhdsGT_iff_exists_Ioo_subset.mp hevent
  exact ⟨ε,hε,fun lam hlam hsmall=>hsub ⟨hlam,hsmall⟩⟩

end PaperUAMO.InteriorNormalForm

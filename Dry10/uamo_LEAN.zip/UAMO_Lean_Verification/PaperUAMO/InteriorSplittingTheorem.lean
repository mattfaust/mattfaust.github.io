import PaperUAMO.InteriorSplitRegularity
import PaperUAMO.InteriorSplittingApplication

set_option maxHeartbeats 800000
noncomputable section
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed Filter Matrix Asymptotics
open PaperUAMO.FreeElliptic PaperUAMO.InteriorNormalForm PaperUAMO.InteriorFrame
open PaperUAMO.SymmetricSplitting
open scoped Topology

section GaugeContinuity
attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace
private theorem perturbation_continuous {a θ:ℝ} (ha:0<a) (hs:Real.sin θ≠0) :
    ContinuousAt (normalizedPerturbation a θ) 0 :=
  (normalizedPerturbation_analytic ha hs).continuousAt
end GaugeContinuity

open scoped Matrix.L2OpNorm

theorem interior_resonant_splitting {a α:ℝ} (ha:0<a) (ha1:a<1)
    (hα:Irrational α) (m:ℕ) (hm : 0 < m) (ell:ℤ) :
    let θ:=resonanceAngle α m ell
    let t₀:=spectralAngle (coupling a) θ 0
    let S₀:=realGauge a θ 0
    ∃t:ℝ→ℝ,∃B:ℝ → ℝ → RMat,∃H:RMat,∃C ε:ℝ,
      AnalyticAt ℝ t 0 ∧ t 0=t₀ ∧
      ((fun lam=>t lam-t₀) =O[𝓝 (0:ℝ)] (fun lam=>lam^2)) ∧
      H.transpose=H ∧ Matrix.trace H=0 ∧ 0<‖H‖ ∧ 0<C ∧ 0<ε ∧
      ∀lam,0≤lam → lam<ε → lam<1 ∧
        (∀y i j,AnalyticAt ℝ (fun z=>B lam z i j) y) ∧
        (∀y i j,AnalyticAt ℝ (fun u=>B u y i j) lam) ∧
        (∀y,(B lam y).det=1) ∧
        (∀y,B lam (y+1)=((-1:ℝ)^(m:ℤ)) • B lam y) ∧
        HasProjectiveDegree (B lam) (m:ℤ) ∧
        (∀y,‖B lam y-S₀*rotation (Real.pi*(m:ℝ)*y)‖≤C*lam) ∧
        (∀y,‖liftSign ell • ((B lam (y+α))⁻¹*
          realTransfer a lam (t lam) (2*Real.pi*y)*B lam y)-1-lam^m • H‖≤
            C*lam^(m+1)) := by
  dsimp only
  obtain ⟨x,hx0,hxa,hxe,hc⟩:=physical_analytic_profile ha ha1 hα m hm ell
  let θ:=resonanceAngle α m ell
  let V:=normalizedPerturbation a θ
  let t:=fun lam=>spectralAngle (coupling a) θ (x lam (zeroMode m)).im
  let B:=physicalSeedFrame a θ m x
  let S:=fun lam=>realGauge a θ (x lam (zeroMode m)).im
  let A:ℝ → ℝ → RMat:=fun lam y=>realTransfer a lam (t lam) (2*Real.pi*y)
  let M:ℝ → ℝ → Mat:=fun lam y=>physicalNumerator (phase θ) V lam (x lam (zeroMode m)).im y
  let v:=fun lam=>physicalProfile m (x lam)
  let c:=resonantCoefficient m (phase θ) (weylPhase α) (V 0)
  let η:=c*halfPhase m α
  let H:=signedLeading (liftSign ell) η
  have hη:η≠0:=mul_ne_zero hc (Complex.exp_ne_zero _)
  have hs:=resonance_sin_ne_zero hα hm ell
  have he1:coupling a<1 := by
    rw [coupling,div_lt_one (by positivity : (0:ℝ)<1+a^2)]
    nlinarith [sq_pos_of_ne_zero (sub_ne_zero.mpr ha1.ne)]
  have hxev:AnalyticAt ℝ (fun lam=>x lam (zeroMode m)) 0 :=
    (ContinuousLinearMap.proj (zeroMode m):Variables m→L[ℝ]ℂ).analyticAt (x 0) |>.comp hxa
  have hxphase:AnalyticAt ℝ (fun lam=>(x lam (zeroMode m)).im) 0 :=
    (Complex.imCLM.analyticAt _).comp hxev
  have ht:AnalyticAt ℝ t 0 :=
    (spectralAngle_analytic (coupling_pos ha) he1 _).comp hxphase
  have ht0:t 0=spectralAngle (coupling a) θ 0 := by simp [t,hx0]
  have hVcont : ContinuousAt V 0 := perturbation_continuous ha hs
  have horder:((fun lam=>t lam-spectralAngle (coupling a) θ 0)
      =O[𝓝 (0:ℝ)] (fun lam=>lam^2)) :=
    elliptic_spectral_center_order ha ha1 x hx0 hxa
      (branch_zero_mode_order (phase_ne_zero θ) m V
        hVcont x hx0 hxa hxe)
  have hlim:Tendsto (fun lam=>(x lam (zeroMode m)).im) (𝓝 0) (𝓝 0) := by
    simpa only [hx0,Pi.zero_apply,Complex.zero_im] using hxphase.continuousAt.tendsto
  have hgood := hlim.eventually (physicalNormalized_intertwining_eventually ha he1 hs)
  have hpar:=physicalSeedFrame_analytic_parameter_eventually ha he1 hs x hx0 hxa
  obtain ⟨δ,hδ,hδb⟩:=Metric.eventually_nhds_iff.mp (hgood.and hpar)
  obtain ⟨P,K,εn,hP,hK,hεn,hn⟩:=actual_profile_normal_form ha ha1 hα m hm ell x hx0 hxa hxe
  obtain ⟨C₀,εb,hC₀,hεb,hb⟩:=physicalSeedFrame_uniform_proximity ha he1 hs x hx0 hxa
  let C:=max C₀ (8*K)
  let ε:=min εn (min εb (min δ (1/(8*(P+1)))))
  have hε:0<ε:=by dsimp [ε];positivity
  have hH:=signedLeading_data (liftSign_abs ell) η
  refine ⟨t,B,H,C,ε,ht,ht0,horder,hH.1,hH.2.1,?_,lt_of_lt_of_le hC₀ (le_max_left _ _),hε,?_⟩
  · rw [show ‖H‖=‖η‖ from hH.2.2]
    exact norm_pos_iff.mpr hη
  · intro lam hlam hsmall
    have hln:lam<εn:=hsmall.trans_le (min_le_left _ _)
    have hlb:lam<εb:=hsmall.trans_le ((min_le_right _ _).trans (min_le_left _ _))
    have hld:lam<δ:=hsmall.trans_le ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
    have hlp:lam<1/(8*(P+1)):=hsmall.trans_le ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
    have hpe:P*lam<1/4 := by
      have hh:=(lt_div_iff₀ (show 0<8*(P+1) by positivity)).mp hlp
      nlinarith
    obtain ⟨hlam1,hv,hpos,_hsu,herror⟩:=hn lam hlam hln
    have hdist : dist lam 0<δ := by simpa only [Real.dist_eq,sub_zero,abs_of_nonneg hlam] using hld
    obtain ⟨hg,hanalytic⟩:=hδb hdist
    have hinter:∀y,complexify (A lam y)*complexify (S lam)=complexify (S lam)*
        ((realTransferDenominator lam (2*Real.pi*y):ℂ)⁻¹ • M lam y) := hg.2 lam
    obtain ⟨_hcont,hdet,hanti,hdegree,herr⟩:=real_normal_form_data (S lam) m α (liftSign ell) lam
      (A lam) (M lam) (v lam) η (liftSign_abs ell) hg.1
      (continuous_physicalProfile m (x lam)) (physicalProfile_periodic m (x lam))
      (mul_nonneg hP.le hlam) hpe (mul_nonneg hK.le (pow_nonneg hlam _)) hv hinter herror
    refine ⟨hlam1,?_,?_,hdet,hanti,hdegree,?_,?_⟩
    · intro y i j
      exact physicalSeedFrame_analytic_phase a θ m x lam y (hpos y) i j
    · intro y i j
      exact hanalytic y (hpos y) i j
    · intro y
      exact (hb lam hlam hlb y).trans (mul_le_mul_of_nonneg_right (le_max_left _ _) hlam)
    · intro y
      change ‖realNormalError (S lam) m α (liftSign ell) lam (A lam) (v lam) η y‖≤_
      apply (herr y).trans
      have hh:=mul_le_mul_of_nonneg_right (show 8*K≤C from le_max_right _ _)
        (pow_nonneg hlam (m+1))
      simpa only [mul_assoc] using hh

end PaperUAMO.InteriorSeed

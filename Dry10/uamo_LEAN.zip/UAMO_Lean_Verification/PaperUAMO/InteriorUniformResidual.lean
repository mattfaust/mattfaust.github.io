import PaperUAMO.InteriorProfileBounds
import PaperUAMO.InteriorCenter

noncomputable section
set_option maxHeartbeats 800000
namespace PaperUAMO.InteriorSeed
open UAMO UAMO.BoundarySeed Asymptotics Function Filter Matrix
open scoped BigOperators Topology

def residualError (m : ℕ) (w q : ℂ) (V : ℝ→SpinMatrix)
    (lam : ℝ) (x : Variables m) (k : ℤ) (i : Fin 2) : ℂ :=
  fullResidual m w q V lam x k i-
    if k=-(m:ℤ) ∧ i=1 then resonantCoefficient m w q (V 0)*(lam:ℂ)^m else 0

theorem residualError_order {w q : ℂ} (hw : w≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : w^2=q^m)
    (V : ℝ → SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w q V lam (x lam)=0) (k : ℤ) (i : Fin 2) :
    (fun lam => residualError m w q V lam (x lam) k i)
      =O[nhds (0:ℝ)] (fun lam => lam^(m+1)) := by
  by_cases ho : k=-(m:ℤ) ∧ i=1
  · have heq : ∀ᶠ lam in nhds 0, residualError m w q V lam (x lam) k i=
        resonantResidual m V lam (x lam)-resonantCoefficient m w q (V 0)*(lam:ℂ)^m := by
      filter_upwards [hxe] with lam h
      unfold residualError
      rw [fullResidual_exact m w q V lam (x lam) h k i]
      simp only [if_pos ho]
    exact (resonantResidual_asymptotic hw hq0 hq m hm hres V hV x hx0 hxa hxe).congr'
      (heq.mono fun _ h => h.symm) EventuallyEq.rfl
  by_cases hn : k=-(m:ℤ)-1
  · have heq : ∀ᶠ lam in nhds 0, residualError m w q V lam (x lam) k i=
        exteriorResidual m V lam (x lam) i false := by
      filter_upwards [hxe] with lam h
      unfold residualError
      rw [fullResidual_exact m w q V lam (x lam) h k i]
      simp only [if_neg ho,if_pos hn,sub_zero]
    exact (exteriorResidual_order hw hq0 hq m hres V hV.continuousAt x hx0 hxa hxe i false).congr'
      (heq.mono fun _ h => h.symm) EventuallyEq.rfl
  by_cases hp : k=(m:ℤ)+1
  · have heq : ∀ᶠ lam in nhds 0, residualError m w q V lam (x lam) k i=
        exteriorResidual m V lam (x lam) i true := by
      filter_upwards [hxe] with lam h
      unfold residualError
      rw [fullResidual_exact m w q V lam (x lam) h k i]
      simp only [if_neg ho,if_neg hn,if_pos hp,sub_zero]
    exact (exteriorResidual_order hw hq0 hq m hres V hV.continuousAt x hx0 hxa hxe i true).congr'
      (heq.mono fun _ h => h.symm) EventuallyEq.rfl
  · have heq : ∀ᶠ lam in nhds 0, residualError m w q V lam (x lam) k i=0 := by
      filter_upwards [hxe] with lam h
      unfold residualError
      rw [fullResidual_exact m w q V lam (x lam) h k i]
      simp only [if_neg ho,if_neg hn,if_neg hp,sub_zero]
    exact (isBigO_zero _ _).congr' (heq.mono fun _ h => h.symm) EventuallyEq.rfl

theorem fullResidual_outside (m : ℕ) (w q : ℂ) (V : ℝ→SpinMatrix)
    (lam : ℝ) (x : Variables m) (hx : finiteSystem m w q V lam x=0)
    (k : ℤ) (i : Fin 2) (hk : k∉Finset.Icc (-((m+1:ℕ):ℤ)) ((m+1:ℕ):ℤ)) :
    fullResidual m w q V lam x k i=0 := by
  rw [fullResidual_exact m w q V lam x hx]
  have h1 : k≠-(m:ℤ) := by simp only [Finset.mem_Icc] at hk; omega
  have h2 : k≠-(m:ℤ)-1 := by simp only [Finset.mem_Icc] at hk; omega
  have h3 : k≠(m:ℤ)+1 := by simp only [Finset.mem_Icc] at hk; omega
  simp [h1,h2,h3]

theorem physicalResidual_error_sum (m : ℕ) (w : ℂ) (V : ℝ→SpinMatrix)
    (α lam θ : ℝ) (x : Variables m)
    (hx : finiteSystem m w (weylPhase α) V lam x=0) (i : Fin 2) :
    (physicalNumerator w V lam (x (zeroMode m)).im θ*ᵥphysicalProfile m x θ-
      (w*(amplitude m x:ℂ)) • physicalProfile m x (θ+α)) i-
      (if i=1 then resonantCoefficient m w (weylPhase α) (V 0)*(lam:ℂ)^m*
        (weylPhase θ)^(-(m:ℤ)) else 0)=
      ∑ k ∈ Finset.Icc (-((m+1:ℕ):ℤ)) ((m+1:ℕ):ℤ),
        residualError m w (weylPhase α) V lam x k i*(weylPhase θ)^k := by
  rw [physicalProfile_residual]
  have hr : fourierEvaluation (fun j k => fullResidual m w (weylPhase α) V lam x k j) θ i=
      ∑ k ∈ Finset.Icc (-((m+1:ℕ):ℤ)) ((m+1:ℕ):ℤ),
        fullResidual m w (weylPhase α) V lam x k i*(weylPhase θ)^k := by
    unfold fourierEvaluation fourierEval
    apply finsum_eq_sum_of_support_subset
    intro k hk
    by_contra hki
    simp [mem_support,fullResidual_outside m w (weylPhase α) V lam x hx k i hki] at hk
  rw [hr]
  simp only [residualError,sub_mul,Finset.sum_sub_distrib]
  congr 1
  by_cases hi : i=1
  · simp only [hi,and_true,if_true]
    rw [Finset.sum_eq_single (-(m:ℤ))]
    · simp
    · intro k _ hk; simp [hk]
    · intro h
      exact False.elim (h (Finset.mem_Icc.mpr ⟨by omega,by omega⟩))
  · simp [hi]

theorem analytic_physical_residual_bound {w : ℂ} (hw : w≠0) {α : ℝ}
    (hα : Irrational α) (m : ℕ) (hm : 0<m) (hres : w^2=(weylPhase α)^m)
    (V : ℝ→SpinMatrix) (hV : AnalyticAt ℝ V 0)
    (x : ℝ→Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m w (weylPhase α) V lam (x lam)=0) :
    ∃ C ε : ℝ, 0<C ∧ 0<ε ∧ ∀ (lam θ : ℝ) (i : Fin 2), |lam|<ε →
      ‖(physicalNumerator w V lam (x lam (zeroMode m)).im θ*ᵥphysicalProfile m (x lam) θ-
          (w*(amplitude m (x lam):ℂ)) • physicalProfile m (x lam) (θ+α)) i-
        (if i=1 then resonantCoefficient m w (weylPhase α) (V 0)*(lam:ℂ)^m*
          (weylPhase θ)^(-(m:ℤ)) else 0)‖≤C*|lam|^(m+1) := by
  let I : Finset ℤ := Finset.Icc (-((m+1:ℕ):ℤ)) ((m+1:ℕ):ℤ)
  let J := {k : ℤ // k∈I} × Fin 2
  let E : ℝ→J→ℂ := fun lam p => residualError m w (weylPhase α) V lam (x lam) p.1.val p.2
  have ho : E =O[nhds (0:ℝ)] (fun lam => lam^(m+1)) := by
    apply isBigO_pi.mpr
    intro p
    exact residualError_order hw (Complex.exp_ne_zero _) (weylPhase_noIntegerResonance hα)
      m hm hres V hV x hx0 hxa hxe p.1.val p.2
  obtain ⟨C,hC,hbound⟩ := ho.exists_pos
  have hb : ∀ᶠ lam in nhds 0, ∀ (θ : ℝ) (i : Fin 2),
      ‖(physicalNumerator w V lam (x lam (zeroMode m)).im θ*ᵥphysicalProfile m (x lam) θ-
          (w*(amplitude m (x lam):ℂ)) • physicalProfile m (x lam) (θ+α)) i-
        (if i=1 then resonantCoefficient m w (weylPhase α) (V 0)*(lam:ℂ)^m*
          (weylPhase θ)^(-(m:ℤ)) else 0)‖≤((I.card:ℝ)+1)*C*|lam|^(m+1) := by
    filter_upwards [hxe,hbound.bound] with lam hfinite he
    intro θ i
    rw [physicalResidual_error_sum m w V α lam θ (x lam) hfinite i]
    change ‖∑ k ∈ I, _‖≤_
    calc
      _ ≤ ∑ k ∈ I, ‖residualError m w (weylPhase α) V lam (x lam) k i*(weylPhase θ)^k‖ := norm_sum_le _ _
      _ ≤ ∑ _k ∈ I, C*|lam|^(m+1) := by
        apply Finset.sum_le_sum
        intro k hk
        simp only [norm_mul,norm_zpow,weylPhase_norm,one_zpow,mul_one]
        have h := (norm_le_pi_norm (E lam) (⟨k,hk⟩,i)).trans he
        simpa only [E,Real.norm_eq_abs,abs_pow] using h
      _ ≤ ((I.card:ℝ)+1)*C*|lam|^(m+1) := by
        simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
        nlinarith [pow_nonneg (abs_nonneg lam) (m+1)]
  obtain ⟨ε,hε,hεb⟩ := Metric.eventually_nhds_iff.mp hb
  refine ⟨((I.card:ℝ)+1)*C,ε,by positivity,hε,?_⟩
  intro lam θ i hlam
  exact hεb (by simpa only [Real.dist_eq,sub_zero] using hlam) θ i

end PaperUAMO.InteriorSeed

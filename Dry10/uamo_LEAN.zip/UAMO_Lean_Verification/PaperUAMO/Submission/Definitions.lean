import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.CStarAlgebra.ContinuousLinearMap
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Analysis.SpecialFunctions.Complex.Circle
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
import Mathlib.Topology.Instances.AddCircle
import Mathlib.Data.Real.Irrational

noncomputable section
namespace PaperUAMO.Submission
open MeasureTheory

abbrev SequenceSpace := ℓ²(ℤ, ℂ)
abbrev WalkOperator := Matrix (Fin 2) (Fin 2) (SequenceSpace →L[ℂ] SequenceSpace)

def complement (lam : ℝ) : ℝ := Real.sqrt (1-lam^2)

def coin (α lam x : ℝ) (ψ : Fin 2 → SequenceSpace) (n : ℤ) : Fin 2 → ℂ :=
  let angle := 2*Real.pi*(x+(n:ℝ)*α)
  ![((lam*Real.cos angle:ℝ):ℂ)*ψ 0 n + Complex.I*(complement lam:ℂ)*ψ 0 n -
      ((lam*Real.sin angle:ℝ):ℂ)*ψ 1 n,
    ((lam*Real.sin angle:ℝ):ℂ)*ψ 0 n + ((lam*Real.cos angle:ℝ):ℂ)*ψ 1 n -
      Complex.I*(complement lam:ℂ)*ψ 1 n]

def IsUAMO (α : ℝ) (W : ℝ → ℝ → ℝ → WalkOperator) : Prop :=
  ∀ lam₁ lam₂ x (ψ : Fin 2 → SequenceSpace) (n : ℤ),
    (∑ j : Fin 2, W lam₁ lam₂ x 0 j (ψ j) n) =
      (lam₁:ℂ)*coin α lam₂ x ψ (n-1) 0 -
        (complement lam₁:ℂ)*coin α lam₂ x ψ n 1 ∧
    (∑ j : Fin 2, W lam₁ lam₂ x 1 j (ψ j) n) =
      (lam₁:ℂ)*coin α lam₂ x ψ (n+1) 1 +
        (complement lam₁:ℂ)*coin α lam₂ x ψ n 0

def IsDOS (W : ℝ → WalkOperator) (ν : Measure ℂ) : Prop :=
  IsProbabilityMeasure ν ∧ (∀ᵐ z ∂ν, ‖z‖=1) ∧
  ∀ k : ℕ, (∫ z, z^k ∂ν) =
    ∫ x in (0:ℝ)..1,
      ((((W x)^k) 0 0 (lp.single 2 0 (1:ℂ))) 0 +
       (((W x)^k) 1 1 (lp.single 2 0 (1:ℂ))) 0)/2

def arc (t : ℝ) : Set ℂ :=
  let z := Complex.exp ((t:ℂ)*Complex.I)
  if 0<z.im then {w | 0<w.im ∧ z.re≤w.re}
  else {w | 0<w.im ∨ (w.im<0 ∧ w.re<z.re)}

def OpenGap (W : ℝ → WalkOperator) (ν : Measure ℂ)
    (ρ : AddCircle (1:ℝ)) : Prop :=
  ∃ t δ : ℝ, 0<δ ∧ ∀ s : ℝ, |s-t|<δ →
    (∀ x : ℝ, Complex.exp ((s:ℂ)*Complex.I) ∉ spectrum ℂ (W x)) ∧
    (ν.real (arc s) : AddCircle (1:ℝ))=ρ

def HasWinding (α : ℝ) (m : ℤ) (ρ : AddCircle (1:ℝ)) : Prop :=
  (2:ℕ) • ρ = (((m:ℝ)*α:ℝ) : AddCircle (1:ℝ))

end PaperUAMO.Submission

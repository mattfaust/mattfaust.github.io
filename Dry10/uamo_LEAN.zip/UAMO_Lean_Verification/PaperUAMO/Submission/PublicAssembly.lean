import PaperUAMO.Submission.WalkBridge
import PaperUAMO.HeightAssembly

noncomputable section
namespace PaperUAMO.Submission
open MeasureTheory Set

theorem uamo_from_seeds
    (seeds : ∀ a (ha : 0<a) (ha1 : a<1),
      InteriorSeedSymmetries.PositiveInteriorSeeds a ha ha1) :
    ∀ α : ℝ, Irrational α →
    ∃ W : ℝ → ℝ → ℝ → WalkOperator, IsUAMO α W ∧
      ∀ lam₁ ∈ Ioc (0:ℝ) 1, ∀ lam₂ ∈ Ioc (0:ℝ) 1,
      ∃! ν : Measure ℂ, IsDOS (W lam₁ lam₂) ν ∧
        ∀ (m : ℤ) (ρ : AddCircle (1:ℝ)), HasWinding α m ρ →
          (OpenGap (W lam₁ lam₂) ν ρ ↔ (lam₁<1 ∧ lam₂<1) ∨ Odd m) := by
  intro α hα
  refine ⟨fun lam₁ lam₂ x => UAMOSimple.walk lam₁ lam₂ α x,physical_walk_isUAMO α,?_⟩
  intro lam₁ h₁ lam₂ h₂
  refine ⟨UAMOSimple.dos lam₁ lam₂ α,⟨?_,?_⟩,?_⟩
  · exact UAMOSimple.dos_isDOS lam₁ lam₂ α h₁ h₂
  · intro m ρ hρ
    exact HeightAssembly.classification_from_seeds seeds h₁ h₂ hα m ρ hρ
  · intro ν hν
    exact UAMOSimple.isDOS_unique hν.1 (UAMOSimple.dos_isDOS lam₁ lam₂ α h₁ h₂)

end PaperUAMO.Submission

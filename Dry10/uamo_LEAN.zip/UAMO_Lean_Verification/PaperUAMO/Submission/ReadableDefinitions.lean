import PaperUAMO.Submission.Definitions

noncomputable section
namespace PaperUAMO.Submission
open MeasureTheory

def GapClassification (α lam₁ lam₂ : ℝ)
    (W : ℝ → WalkOperator) (ν : Measure ℂ) : Prop :=
  ∀ (m : ℤ) (ρ : AddCircle (1:ℝ)), HasWinding α m ρ →
    (OpenGap W ν ρ ↔ (lam₁ < 1 ∧ lam₂ < 1) ∨ Odd m)

end PaperUAMO.Submission

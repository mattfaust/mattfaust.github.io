import PaperUAMO.Submission.ReadableTheorem

noncomputable section
namespace PaperUAMO.Submission.ReadableSignature
open MeasureTheory Set

theorem expanded_statement_guard :
    ∀ α : ℝ, Irrational α →
    ∃ W : ℝ → ℝ → ℝ → WalkOperator, IsUAMO α W ∧
      ∀ lam₁ ∈ Ioc (0:ℝ) 1, ∀ lam₂ ∈ Ioc (0:ℝ) 1,
      ∃! ν : Measure ℂ, IsDOS (W lam₁ lam₂) ν ∧
        ∀ (m : ℤ) (ρ : AddCircle (1:ℝ)), HasWinding α m ρ →
          (OpenGap (W lam₁ lam₂) ν ρ ↔ (lam₁<1 ∧ lam₂<1) ∨ Odd m) :=
  PaperUAMO.Submission.readable_uamo

end PaperUAMO.Submission.ReadableSignature

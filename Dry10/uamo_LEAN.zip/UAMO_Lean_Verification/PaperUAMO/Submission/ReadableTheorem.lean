import PaperUAMO.Submission.ReadableDefinitions
import PaperUAMO.Submission.Theorem

noncomputable section
namespace PaperUAMO.Submission
open MeasureTheory Set

theorem readable_uamo :
    ∀ α : ℝ, Irrational α →
    ∃ W : ℝ → ℝ → ℝ → WalkOperator, IsUAMO α W ∧
      ∀ lam₁ ∈ Ioc (0:ℝ) 1, ∀ lam₂ ∈ Ioc (0:ℝ) 1,
      ∃! ν : Measure ℂ,
        IsDOS (W lam₁ lam₂) ν ∧
        GapClassification α lam₁ lam₂ (W lam₁ lam₂) ν :=
  PaperUAMO.Submission.uamo

end PaperUAMO.Submission

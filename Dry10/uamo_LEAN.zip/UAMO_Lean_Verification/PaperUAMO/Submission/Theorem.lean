import PaperUAMO.Submission.PublicAssembly
import PaperUAMO.InteriorSeeds

noncomputable section
namespace PaperUAMO.Submission
open MeasureTheory Set

theorem uamo :
    ∀ α : ℝ, Irrational α →
    ∃ W : ℝ → ℝ → ℝ → WalkOperator, IsUAMO α W ∧
      ∀ lam₁ ∈ Ioc (0:ℝ) 1, ∀ lam₂ ∈ Ioc (0:ℝ) 1,
      ∃! ν : Measure ℂ, IsDOS (W lam₁ lam₂) ν ∧
        ∀ (m : ℤ) (ρ : AddCircle (1:ℝ)), HasWinding α m ρ →
          (OpenGap (W lam₁ lam₂) ν ρ ↔ (lam₁<1 ∧ lam₂<1) ∨ Odd m) :=
  uamo_from_seeds InteriorSeed.positive_interior_seeds

theorem noncritical {lam₁ lam₂ α : ℝ}
    (h₁ : lam₁ ∈ Ioo (0:ℝ) 1) (h₂ : lam₂ ∈ Ioo (0:ℝ) 1)
    (hne : lam₁≠lam₂) (hα : Irrational α) (m : ℤ) :
    ∀ ρ : AddCircle (1:ℝ), HasWinding α m ρ →
      OpenGap (UAMOSimple.walk lam₁ lam₂ α) (UAMOSimple.dos lam₁ lam₂ α) ρ :=
  HeightAssembly.noncritical_from_seeds InteriorSeed.positive_interior_seeds h₁ h₂ hne hα m

end PaperUAMO.Submission

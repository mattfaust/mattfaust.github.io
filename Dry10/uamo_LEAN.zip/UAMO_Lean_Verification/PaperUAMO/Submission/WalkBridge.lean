import PaperUAMO.Submission.Definitions
import UAMOSimple.Spec
import Mathlib.Tactic

noncomputable section
namespace PaperUAMO.Submission
open Matrix UAMOSimple

private theorem phase_star_at (α x : ℝ) (ψ : UAMOSimple.Hilbert) (n : ℤ) :
    star (UAMOSimple.phase α x) ψ n =
      ((Real.cos (UAMOSimple.phaseAngle α x n):ℂ)-
        (Real.sin (UAMOSimple.phaseAngle α x n):ℂ)*Complex.I)*ψ n := by
  rw [UAMOSimple.phase,LinearIsometryEquiv.star_eq_symm]
  change Complex.exp (((-UAMOSimple.phaseAngle α x n:ℝ):ℂ)*Complex.I)*ψ n = _
  rw [Complex.exp_mul_I]
  simp [sub_eq_add_neg]

private theorem coin_action (α lam x : ℝ) (ψ : Fin 2 → SequenceSpace) (n : ℤ) (i : Fin 2) :
    (∑ j : Fin 2,
      UAMOSimple.coinFactor lam (complement lam) (UAMOSimple.phase α x) i j (ψ j) n) =
      coin α lam x ψ n i := by
  fin_cases i <;>
    simp [UAMOSimple.coinFactor,Fin.sum_univ_two,coin,ContinuousLinearMap.add_apply,
      ContinuousLinearMap.sub_apply,ContinuousLinearMap.smul_apply,UAMOSimple.phase_apply,
      phase_star_at,UAMOSimple.phaseValue,UAMOSimple.phaseAngle,Complex.exp_mul_I,
      Complex.ofReal_cos,Complex.ofReal_sin]
  all_goals ring_nf
  all_goals try simp only [Complex.I_sq]
  all_goals ring

theorem physical_walk_isUAMO (α : ℝ) :
    IsUAMO α (fun lam₁ lam₂ x => UAMOSimple.walk lam₁ lam₂ α x) := by
  intro lam₁ lam₂ x ψ n
  have hp (k : ℤ) (i : Fin 2) := coin_action α lam₂ x ψ k i
  constructor
  all_goals
    simp only [UAMOSimple.walk,UAMOSimple.shiftFactor,Matrix.mul_apply,Fin.sum_univ_two,
      Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.head_cons,Matrix.head_fin_const,
      ContinuousLinearMap.add_apply,ContinuousLinearMap.mul_apply,
      ContinuousLinearMap.smul_apply,ContinuousLinearMap.neg_apply,UAMOSimple.shift_apply,
      UAMOSimple.shift_star_apply,ContinuousLinearMap.one_apply,lp.coeFn_smul,Pi.smul_apply,
      smul_eq_mul,Matrix.of_apply,lp.coeFn_add,Pi.add_apply]
  all_goals
    simp only [Fin.sum_univ_two] at hp
    simp_rw [←hp]
  all_goals unfold complement at *
  all_goals ring

end PaperUAMO.Submission

import PaperUAMO.SymmetricSplittingFrame
import UAMODraft.CircleOpening

noncomputable section
namespace PaperUAMO.SymmetricSplitting
open Matrix Filter Set UAMODraft.QuantitativeOpening UAMODraft.PositiveAngle
open UAMODraft.OpeningAssembly UAMODraft.OpeningRotationAssembly
open UAMODraft.CircleCover UAMODraft.CoverHyperbolicity
open UAMO.ProjectiveAngle UAMO.StablePlane
open scoped Matrix.L2OpNorm Topology

def HasRotationNumber (A : ℝ→Mat2) (α ρ : ℝ) : Prop :=
  ∃F:ℝ→ℝ→ℝ,
    Continuous (fun p:ℝ×ℝ=>F p.1 p.2) ∧
    (∀s,Function.Periodic (fun x=>F x s) 1) ∧
    (∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c • (A x*ᵥangleVector s)) ∧
    (∀x,StrictMono (F x)) ∧
    (∀x s,F x (s+Real.pi)=F x s+Real.pi) ∧
    ∀x s,Tendsto (fun n:ℕ=>(angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 ρ)

theorem positive_seed_bounds (d : ℝ) (hd : 0<d) (hd1 : d≤1)
    (E : Mat2) (hE : ‖E‖≤d/4) :
    (∀i j,0<(1+symmetricBlock 0 d+E) i j) ∧
    (∀i,1+d/2≤∑j,(1+symmetricBlock 0 d+E) i j) ∧
    (∀j,1+d/2≤∑i,(1+symmetricBlock 0 d+E) i j) := by
  have hb (i j : Fin 2) := abs_le.mp ((entry_le_norm E i j).trans hE)
  constructor
  · intro i j
    fin_cases i <;> fin_cases j <;>
      simp only [Matrix.add_apply,Matrix.one_apply,symmetricBlock,Matrix.of_apply,
        Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one] <;>
      norm_num <;> linarith [hb 0 0,hb 0 1,hb 1 0,hb 1 1]
  constructor
  · intro i
    fin_cases i <;>
      simp [Fin.sum_univ_two,symmetricBlock] <;>
      linarith [hb 0 0,hb 0 1,hb 1 0,hb 1 1]
  · intro j
    fin_cases j <;>
      simp [Fin.sum_univ_two,symmetricBlock] <;>
      linarith [hb 0 0,hb 0 1,hb 1 0,hb 1 1]

private theorem signMatrix_one : signMatrix 1=(1:Mat2) := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [signMatrix]

private theorem quadrantReflection_one : quadrantReflection 1=(1:Mat2) := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [quadrantReflection]

theorem symmetric_splitting_at (α σ : ℝ) (m : ℤ) (hσ : |σ|=1)
    (A B E : ℝ→Mat2) (D : Mat2)
    (hAcont : Continuous A) (hAper : Function.Periodic A 1)
    (hAdet : ∀x,(A x).det=1) (hBcont : Continuous B)
    (hBdet : ∀x,(B x).det=1)
    (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hdegree : HasProjectiveDegree B m)
    (hsym : D.transpose=D) (htrace : Matrix.trace D=0)
    (hd : 0<‖D‖) (hd1 : ‖D‖≤1) (hE : ∀x,‖E x‖≤‖D‖/4)
    (hnormal : ∀x,σ • ((B (x+α))⁻¹*A x*B x)=1+D+E x) :
    IsUniformlyHyperbolicOnLines (translation 1 α) (periodicLift A hAper) ∧
      HasRotationNumber A α ((m:ℝ)*α/2+(1-σ)/4) := by
  obtain ⟨t,ht⟩ := exists_rotation_symmetric D hsym htrace hd
  let H : ℝ→Mat2 := fun x=>B x*rotationFactor t
  have hHcont : Continuous H := hBcont.mul continuous_const
  have hHdet (x:ℝ) : (H x).det=1 := by
    simp only [H,Matrix.det_mul,hBdet,rotationFactor_det,mul_one]
  have hHanti (x:ℝ) : H (x+1)=((-1:ℝ)^m) • H x := by
    simp only [H,hanti,smul_mul_assoc]
  obtain ⟨b,hb,hcol,hwind⟩ :=
    projectiveDegree_right_rotation B m hBcont hBdet hanti hdegree t
  let C : ℝ→Mat2 := fun x=>σ • ((H (x+α))⁻¹*A x*H x)
  have hCopened : C=openedCocycle (fun x:ℝ=>x+α) A H σ 1 := by
    funext x
    simp only [C,openedCocycle,signMatrix_one,one_mul,mul_one]
  have hCform (x:ℝ) : C x=1+symmetricBlock 0 ‖D‖+
      star (rotationFactor t)*E x*rotationFactor t := by
    change σ • ((B (x+α)*rotationFactor t)⁻¹*A x*(B x*rotationFactor t))=_
    rw [rotated_signed_conjugacy,hnormal]
    simp only [Matrix.mul_add,Matrix.add_mul,Matrix.mul_one]
    rw [(unitary.mem_iff.mp (rotation_unitary t)).1,ht]
  have hpos (x:ℝ) (i j:Fin 2) : 0<C x i j := by
    rw [hCform]
    exact (positive_seed_bounds ‖D‖ hd hd1 _
      (by rw [rotation_error_norm];exact hE x)).1 i j
  have hσsq : σ^2=1 := sign_sq_one hσ
  have hUH := ordinaryCircle_uniformHyperbolic_of_opened_positive α A H m
    hAcont hAper hHcont hHanti hAdet hHdet σ 1 hσsq (by norm_num)
    (by rw [←hCopened];exact hpos)
  refine ⟨hUH,?_⟩
  have hCcont : Continuous C := by
    rw [hCopened]
    exact openedCocycle_continuous _ (continuous_id.add continuous_const)
      A H hAcont hHcont hHdet σ 1
  have hCper : Function.Periodic C 1 := by
    rw [hCopened]
    exact openedCocycle_periodic A H α σ 1 m hAper hHdet hHanti
  have hCdet (x:ℝ) : (C x).det=1 := by
    rw [hCopened]
    exact openedCocycle_det _ A H hAdet hHdet σ 1 hσsq (by norm_num) x
  exact opening_rotation_full A H C b α (by norm_num : |(1:ℝ)|=1) hσ
    hHcont hb hCcont hCper hCdet hpos hHdet hcol m hwind hHanti
    (fun _=>by simp only [quadrantReflection_one,one_mul,mul_one];rfl)

end PaperUAMO.SymmetricSplitting

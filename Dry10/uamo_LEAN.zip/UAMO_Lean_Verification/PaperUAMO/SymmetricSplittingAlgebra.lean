import UAMODraft.OpeningForms
import UAMODraft.FrameAngle
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

noncomputable section
namespace PaperUAMO.SymmetricSplitting
open Matrix UAMODraft.QuantitativeOpening UAMODraft.PositiveAngle
open UAMO.ProjectiveAngle UAMO.StablePlane
open scoped Matrix.L2OpNorm

def symmetricBlock (u v : ℝ) : Mat2 := !![u,v;v,-u]

theorem symmetric_traceless_eq (D : Mat2) (hs : D.transpose=D)
    (ht : Matrix.trace D=0) : D=symmetricBlock (D 0 0) (D 0 1) := by
  have h10 : D 1 0=D 0 1 := congrFun (congrFun hs 0) 1
  have h11 : D 1 1= -D 0 0 := by
    simp only [Matrix.trace,Matrix.diag,Fin.sum_univ_two] at ht
    linarith
  ext i j
  fin_cases i <;> fin_cases j <;> simp [symmetricBlock,h10,h11]

theorem symmetricBlock_norm_sq (u v : ℝ) :
    ‖symmetricBlock u v‖^2=u^2+v^2 := by
  have h : star (symmetricBlock u v)*symmetricBlock u v=(u^2+v^2) • (1:Mat2) := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [symmetricBlock,Matrix.star_apply,Matrix.mul_apply,Fin.sum_univ_two] <;> ring
  have hn := congrArg norm h
  rw [CStarRing.norm_star_mul_self,norm_smul,Real.norm_eq_abs,
    abs_of_nonneg (add_nonneg (sq_nonneg u) (sq_nonneg v)),norm_one,mul_one] at hn
  simpa [pow_two] using hn

theorem rotation_unitary (t : ℝ) : rotationFactor t∈unitary Mat2 := by
  apply unitary.mem_iff.mpr
  constructor <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [rotationFactor,Matrix.star_apply,Matrix.mul_apply,Fin.sum_univ_two] <;>
    nlinarith [Real.sin_sq_add_cos_sq t]

theorem rotation_conjugate_symmetricBlock (u v t : ℝ) :
    star (rotationFactor t)*symmetricBlock u v*rotationFactor t=
      symmetricBlock (u*Real.cos (2*t)+v*Real.sin (2*t))
        (v*Real.cos (2*t)-u*Real.sin (2*t)) := by
  have hu : u*(Real.sin t^2+Real.cos t^2)=u := by rw [Real.sin_sq_add_cos_sq,mul_one]
  have hv : v*(Real.sin t^2+Real.cos t^2)=v := by rw [Real.sin_sq_add_cos_sq,mul_one]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [rotationFactor,symmetricBlock,Matrix.star_apply,Matrix.mul_apply,
      Fin.sum_univ_two,Real.cos_two_mul,Real.sin_two_mul] <;>
    nlinarith [hu,hv]

theorem exists_rotation_symmetric (D : Mat2) (hs : D.transpose=D)
    (ht : Matrix.trace D=0) (hd : 0<‖D‖) :
    ∃t:ℝ,star (rotationFactor t)*D*rotationFactor t=symmetricBlock 0 ‖D‖ := by
  let u:=D 0 0
  let v:=D 0 1
  let z:ℂ:=⟨v,-u⟩
  have hD : D=symmetricBlock u v := symmetric_traceless_eq D hs ht
  have hn : ‖z‖=‖D‖ := by
    have hsq : ‖z‖^2=‖D‖^2 := by
      rw [hD,symmetricBlock_norm_sq,Complex.sq_norm]
      simp [z,Complex.normSq]
      ring
    exact (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp hsq
  have hz : z≠0 := norm_pos_iff.mp (hn.symm ▸ hd)
  refine ⟨z.arg/2,?_⟩
  rw [hD,rotation_conjugate_symmetricBlock,show 2*(z.arg/2)=z.arg by ring,
    Complex.cos_arg hz,Complex.sin_arg,hn]
  have hsquare : ‖D‖^2=u^2+v^2 := by rw [hD,symmetricBlock_norm_sq]
  have h0 : u*(v/‖D‖)+v*(-u/‖D‖)=0 := by ring
  have h1 : v*(v/‖D‖)-u*(-u/‖D‖)=‖D‖ := by
    field_simp [hd.ne']
    nlinarith [hsquare]
  simp only [z, ←hD,h0,h1]

theorem rotation_error_norm (t : ℝ) (E : Mat2) :
    ‖star (rotationFactor t)*E*rotationFactor t‖=‖E‖ := by
  rw [CStarRing.norm_mul_mem_unitary _ (rotation_unitary t),
    CStarRing.norm_mem_unitary_mul _ (unitary.star_mem_iff.mpr (rotation_unitary t))]

end PaperUAMO.SymmetricSplitting

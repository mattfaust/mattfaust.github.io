import PaperUAMO.SymmetricSplittingFamily

noncomputable section
namespace PaperUAMO.SymmetricSplitting
open Matrix Filter Set UAMODraft.QuantitativeOpening
open UAMODraft.CircleCover UAMODraft.CoverHyperbolicity
open scoped Matrix.L2OpNorm Topology

theorem uniformErrorLittleO_iff (E : ℝ → C(AddCircle (1:ℝ),Mat2)) (D : ℝ → Mat2) :
    UniformErrorLittleO (fun lam x=>E lam (x:AddCircle (1:ℝ))) D ↔
      Asymptotics.IsLittleO (𝓝[>] (0:ℝ)) E D := by
  rw [Asymptotics.isLittleO_iff]
  constructor
  · intro h c hc
    filter_upwards [h c hc] with lam hlam
    apply (ContinuousMap.norm_le (E lam) (mul_nonneg hc.le (norm_nonneg _))).mpr
    intro x
    obtain ⟨x,rfl⟩ := QuotientAddGroup.mk_surjective x
    exact hlam x
  · intro h c hc
    filter_upwards [h hc] with lam hlam x
    exact ((E lam).norm_coe_le_norm _).trans hlam

theorem circle_representative_periodic {X : Type*} (A : AddCircle (1:ℝ) → X) :
    Function.Periodic (fun x:ℝ=>A (x:AddCircle (1:ℝ))) 1 := by
  intro x
  change A ((x+1:ℝ):AddCircle (1:ℝ))=A (x:AddCircle (1:ℝ))
  rw [AddCircle.coe_add_period]

theorem symmetric_seed_splitting_circle
    (α σ : ℝ) (m : ℤ) (hσ : |σ|=1)
    (A E : ℝ → C(AddCircle (1:ℝ),Mat2)) (B : ℝ → ℝ → Mat2) (D : ℝ → Mat2)
    (hAdet : ∀ᶠ lam in 𝓝[>] (0:ℝ),∀x,(A lam x).det=1)
    (hBcont : ∀ᶠ lam in 𝓝[>] (0:ℝ),Continuous (B lam))
    (hBdet : ∀ᶠ lam in 𝓝[>] (0:ℝ),∀x,(B lam x).det=1)
    (hanti : ∀ᶠ lam in 𝓝[>] (0:ℝ),∀x,B lam (x+1)=((-1:ℝ)^m) • B lam x)
    (hdegree : ∀ᶠ lam in 𝓝[>] (0:ℝ),HasProjectiveDegree (B lam) m)
    (hsym : ∀ᶠ lam in 𝓝[>] (0:ℝ),(D lam).transpose=D lam)
    (htrace : ∀ᶠ lam in 𝓝[>] (0:ℝ),Matrix.trace (D lam)=0)
    (hd : ∀ᶠ lam in 𝓝[>] (0:ℝ),0<‖D lam‖)
    (hdlim : Tendsto (fun lam=>‖D lam‖) (𝓝[>] (0:ℝ)) (𝓝 0))
    (herror : Asymptotics.IsLittleO (𝓝[>] (0:ℝ)) E D)
    (hnormal : ∀ᶠ lam in 𝓝[>] (0:ℝ),∀x,
      σ • ((B lam (x+α))⁻¹*A lam (x:AddCircle (1:ℝ))*B lam x)=
        1+D lam+E lam (x:AddCircle (1:ℝ))) :
    ∃ε>0,∀lam,0<lam → lam<ε →
      IsUniformlyHyperbolicOnLines (translation 1 α) (A lam) ∧
      HasRotationNumber (fun x:ℝ=>A lam (x:AddCircle (1:ℝ))) α
        ((m:ℝ)*α/2+(1-σ)/4) := by
  have hsmall : ∀ᶠ lam in 𝓝[>] (0:ℝ),‖D lam‖<1 :=
    (tendsto_order.mp hdlim).2 1 (by norm_num)
  have herr := (uniformErrorLittleO_iff E D).mpr herror (1/4) (by norm_num)
  have hresult : ∀ᶠ lam in 𝓝[>] (0:ℝ),
      IsUniformlyHyperbolicOnLines (translation 1 α) (A lam) ∧
      HasRotationNumber (fun x:ℝ=>A lam (x:AddCircle (1:ℝ))) α
        ((m:ℝ)*α/2+(1-σ)/4) := by
    filter_upwards [hAdet,hBcont,hBdet,hanti,hdegree,hsym,htrace,hd,hnormal,hsmall,herr]
      with lam hAdet hBcont hBdet hanti hdegree hsym htrace hd hnormal hsmall herr
    have h := symmetric_splitting_at α σ m hσ
      (fun x:ℝ=>A lam (x:AddCircle (1:ℝ))) (B lam)
      (fun x:ℝ=>E lam (x:AddCircle (1:ℝ))) (D lam)
      ((A lam).continuous.comp (AddCircle.continuous_mk' _))
      (circle_representative_periodic (A lam)) (fun x=>hAdet _) hBcont hBdet hanti
      hdegree hsym htrace hd hsmall.le
      (fun x=>by simpa only [one_div_mul_eq_div] using herr x) hnormal
    have hlift : periodicLift (fun x:ℝ=>A lam (x:AddCircle (1:ℝ)))
        (circle_representative_periodic (A lam))=(A lam: AddCircle (1:ℝ) → Mat2) := by
      funext x
      obtain ⟨x,rfl⟩ := QuotientAddGroup.mk_surjective x
      rfl
    rw [hlift] at h
    exact h
  obtain ⟨ε,hε,hsub⟩ := mem_nhdsGT_iff_exists_Ioo_subset.mp hresult
  exact ⟨ε,hε,fun lam hlam hlamε=>hsub ⟨hlam,hlamε⟩⟩

end PaperUAMO.SymmetricSplitting

import PaperUAMO.SymmetricSplitting

noncomputable section
namespace PaperUAMO.SymmetricSplitting
open Matrix Filter Set UAMODraft.QuantitativeOpening
open UAMODraft.CircleCover UAMODraft.CoverHyperbolicity
open scoped Matrix.L2OpNorm Topology

def UniformErrorLittleO (E : ℝ → ℝ → Mat2) (D : ℝ → Mat2) : Prop :=
  ∀c:ℝ,0<c → ∀ᶠ lam in 𝓝[>] (0:ℝ),∀x,‖E lam x‖≤c*‖D lam‖

end PaperUAMO.SymmetricSplitting

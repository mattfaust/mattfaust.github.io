import PaperUAMO.SymmetricSplittingAlgebra
import UAMODraft.OpeningPhasePeriodicity

noncomputable section
namespace PaperUAMO.SymmetricSplitting
open Matrix UAMODraft.QuantitativeOpening UAMODraft.PositiveAngle
open UAMO.ProjectiveAngle UAMO.StablePlane
open scoped Matrix.L2OpNorm

def HasProjectiveDegree (B : ℝ→Mat2) (m : ℤ) : Prop :=
  ∃b:ℝ→ℝ,Continuous b ∧
    (∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x)) ∧
    ∀x,b (x+1)=b x+(m:ℝ)*Real.pi

theorem projectiveDegree_right_rotation (B : ℝ→Mat2) (m : ℤ)
    (hB : Continuous B) (hd : ∀x,(B x).det=1)
    (hp : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hw : HasProjectiveDegree B m) (t : ℝ) :
    HasProjectiveDegree (fun x=>B x*rotationFactor t) m := by
  obtain ⟨b,hb,hcol,hwind⟩ := hw
  refine ⟨fun x=>frameLift (B x) (b x) t,
    continuous_frameLift_family B b (fun _=>t) hB hb continuous_const hd hcol,?_,?_⟩
  · intro x
    obtain ⟨r,hr,hcol⟩ := hcol x
    obtain ⟨c,hc,hdir⟩ := frameLift_direction (hd x) hr hcol t
    have h0 := congrFun hdir 0
    have h1 := congrFun hdir 1
    refine ⟨c⁻¹,inv_pos.mpr hc,?_,?_⟩
    · simp only [angleVector,Matrix.mulVec,dotProduct,Fin.sum_univ_two,
        Pi.smul_apply,smul_eq_mul,Matrix.cons_val_zero] at h0
      simp only [Matrix.mul_apply,Fin.sum_univ_two,rotationFactor,Matrix.of_apply,
        Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one]
      rw [h0]
      field_simp
    · simp only [angleVector,Matrix.mulVec,dotProduct,Fin.sum_univ_two,
        Pi.smul_apply,smul_eq_mul,Matrix.cons_val_one,Matrix.cons_val_fin_one] at h1
      simp only [Matrix.mul_apply,Fin.sum_univ_two,rotationFactor,Matrix.of_apply,
        Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one]
      rw [h1]
      field_simp
  · intro x
    change frameLift (B (x+1)) (b (x+1)) t=frameLift (B x) (b x) t+(m:ℝ)*Real.pi
    rw [hp,hwind,frameLift_degree_shift]

theorem rotation_inverse (t : ℝ) : (rotationFactor t)⁻¹=star (rotationFactor t) := by
  have hu := (unitary.mem_iff.mp (rotation_unitary t)).2
  have hi : (rotationFactor t)⁻¹*rotationFactor t=1 :=
    Matrix.nonsing_inv_mul _ (by rw [rotationFactor_det];exact isUnit_one)
  calc
    _ = (rotationFactor t)⁻¹*(rotationFactor t*star (rotationFactor t)) := by rw [hu,mul_one]
    _ = _ := by rw [←mul_assoc,hi,one_mul]

theorem rotated_signed_conjugacy (A B : ℝ→Mat2) (α σ t : ℝ) (x : ℝ) :
    σ • ((B (x+α)*rotationFactor t)⁻¹*A x*(B x*rotationFactor t))=
      star (rotationFactor t)*(σ • ((B (x+α))⁻¹*A x*B x))*rotationFactor t := by
  rw [Matrix.mul_inv_rev,rotation_inverse]
  simp only [Matrix.mul_assoc,mul_smul_comm,smul_mul_assoc]

end PaperUAMO.SymmetricSplitting

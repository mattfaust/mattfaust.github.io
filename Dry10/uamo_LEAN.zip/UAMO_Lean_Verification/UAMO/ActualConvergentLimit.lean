import UAMO.ScalarGaugeDenominators
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Algebra.ContinuedFractions.Computation.ApproximationCorollaries

noncomputable section
namespace UAMO.ScalarGauge
open Filter
open scoped Topology

theorem convergent_den_tendsto_atTop {α : ℝ} (hα : Irrational α) :
    Tendsto (fun n:ℕ => (α.convergent n).den) atTop atTop := by
  apply tendsto_atTop_mono' atTop ?_ tendsto_id
  filter_upwards [eventually_ge_atTop (4:ℕ)] with n hn
  exact (Nat.le_succ n).trans
    ((Nat.le_fib_self (by omega : 5≤n+1)).trans (convergent_den_fibonacci hα n))

theorem actual_convergents_tendsto {α : ℝ} (_hα : Irrational α) :
    Tendsto (fun n:ℕ => (α.convergent n:ℝ)) atTop (𝓝 α) := by
  simpa only [← Real.convs_eq_convergent] using GenContFract.of_convergence α

end UAMO.ScalarGauge

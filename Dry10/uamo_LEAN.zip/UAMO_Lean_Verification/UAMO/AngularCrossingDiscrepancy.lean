import UAMO.FiniteAngularCrossings
import Mathlib.Algebra.Order.Floor.Ring

noncomputable section
namespace UAMO.ProjectiveAngle
open Set

def unitGridCount (N : ℕ) (d x : ℝ) : ℕ :=
  (Finset.univ.filter (fun j : Fin N => d+(j.val:ℝ)≤x)).card

theorem unitGridCount_discrepancy (N : ℕ) (d x : ℝ) (hd : 0≤d) (hd1 : d<1)
    (hx : 0≤x) (hxN : x≤(N:ℝ)) : |(unitGridCount N d x:ℝ)-x|≤1 := by
  classical
  let S := Finset.univ.filter (fun j : Fin N => d+(j.val:ℝ)≤x)
  have hu : S.card≤Nat.floor x+1 := by
    have h := Finset.card_le_card_of_injOn (s:=S) (t:=Finset.range (Nat.floor x+1))
      (fun j : Fin N => j.val) (by
        intro j hj
        have hh := (Finset.mem_filter.mp hj).2
        have hle : (j.val:ℝ)≤x := by linarith
        have hjfloor := Nat.le_floor hle
        simp only [Finset.mem_range]
        omega) (by intro i _ j _ hij; exact Fin.ext hij)
    simpa using h
  have hfloorN : Nat.floor x≤N := Nat.floor_le_of_le hxN
  let embed : Fin (Nat.floor x) → Fin N := fun j => ⟨j.val,j.isLt.trans_le hfloorN⟩
  have hl : Nat.floor x≤S.card := by
    have h := Finset.card_le_card_of_injOn (s:=Finset.univ) (t:=S) embed (by
      intro j _
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_univ _,?_⟩
      have hj : (j.val:ℝ)+1≤(Nat.floor x:ℝ) := by
        exact_mod_cast Nat.succ_le_of_lt j.isLt
      change d+(j.val:ℝ)≤x
      linarith [Nat.floor_le hx]) (by
        intro i _ j _ hij
        apply Fin.ext
        exact congrArg (fun k : Fin N => k.val) hij)
    simpa using h
  have hu' : (S.card:ℝ)≤(Nat.floor x:ℝ)+1 := by exact_mod_cast hu
  have hl' : (Nat.floor x:ℝ)≤(S.card:ℝ) := by exact_mod_cast hl
  change |(S.card:ℝ)-x|≤1
  apply abs_le.mpr
  constructor
  · linarith [Nat.lt_floor_add_one x]
  · linarith [Nat.floor_le hx]

def angularCrossingCount (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (t : ℝ) : ℕ :=
  (Finset.univ.filter (fun j : Fin N =>
    angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn j≤t)).card

theorem angularCrossingRoot_le_iff (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (t : ℝ) (j : Fin N) :
    angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn j≤t ↔
      δ/Real.pi+(j.val:ℝ)≤(f t-f t₀)/Real.pi := by
  rw [← hmono.le_iff_le,(angularCrossingRoot_spec f hf hmono t₀ L δ hL hδ hδπ N hturn j).2]
  have he : δ/Real.pi+(j.val:ℝ)=(δ+(j.val:ℝ)*Real.pi)/Real.pi := by
    field_simp [Real.pi_ne_zero]
  rw [he,div_le_div_iff_of_pos_right Real.pi_pos]
  constructor <;> intro h <;> linarith

theorem angularCrossingCount_eq_unitGridCount (f : ℝ → ℝ) (hf : Continuous f)
    (hmono : StrictMono f) (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (t : ℝ) :
    angularCrossingCount f hf hmono t₀ L δ hL hδ hδπ N hturn t=
      unitGridCount N (δ/Real.pi) ((f t-f t₀)/Real.pi) := by
  unfold angularCrossingCount unitGridCount
  congr 1
  ext j
  simp only [Finset.mem_filter,Finset.mem_univ,true_and]
  exact angularCrossingRoot_le_iff f hf hmono t₀ L δ hL hδ hδπ N hturn t j

theorem angularCrossingCount_discrepancy (f : ℝ → ℝ) (hf : Continuous f)
    (hmono : StrictMono f) (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) {t : ℝ} (ht : t∈Icc t₀ (t₀+L)) :
    |(angularCrossingCount f hf hmono t₀ L δ hL hδ hδπ N hturn t:ℝ)-
      (f t-f t₀)/Real.pi|≤1 := by
  rw [angularCrossingCount_eq_unitGridCount]
  apply unitGridCount_discrepancy
  · exact div_nonneg hδ Real.pi_pos.le
  · exact (div_lt_one Real.pi_pos).mpr hδπ
  · exact div_nonneg (sub_nonneg.mpr (hmono.monotone ht.1)) Real.pi_pos.le
  · apply (div_le_iff₀ Real.pi_pos).mpr
    have hu := hmono.monotone ht.2
    rw [hturn] at hu
    linarith

end UAMO.ProjectiveAngle

import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic

noncomputable section
namespace UAMO.ProjectiveAngle
open Set Filter
open scoped Topology

def angleIterate (F : ℝ → ℝ → ℝ) (α x s : ℝ) : ℕ → ℝ
  | 0 => s
  | n+1 => F (x+(n:ℝ)*α) (angleIterate F α x s n)

@[simp] theorem angleIterate_zero (F : ℝ → ℝ → ℝ) (α x s : ℝ) :
    angleIterate F α x s 0=s := rfl

@[simp] theorem angleIterate_succ (F : ℝ → ℝ → ℝ) (α x s : ℝ) (n : ℕ) :
    angleIterate F α x s (n+1)=F (x+(n:ℝ)*α) (angleIterate F α x s n) := rfl

theorem angleMap_add_int_pi (F : ℝ → ℝ → ℝ)
    (hpi : ∀ x s, F x (s+Real.pi)=F x s+Real.pi) (x s : ℝ) (l : ℤ) :
    F x (s+(l:ℝ)*Real.pi)=F x s+(l:ℝ)*Real.pi := by
  have hp : Function.Periodic (fun u => F x u-u) Real.pi := by
    intro u
    change F x (u+Real.pi)-(u+Real.pi)=F x u-u
    rw [hpi]
    ring
  have h := hp.int_mul l s
  simp only [zsmul_eq_mul] at h
  linarith

theorem angleIterate_monotone (F : ℝ → ℝ → ℝ) (hmono : ∀ x, Monotone (F x))
    (α x : ℝ) (n : ℕ) : Monotone (fun s => angleIterate F α x s n) := by
  induction n with
  | zero => exact monotone_id
  | succ n ih => exact (hmono (x+(n:ℝ)*α)).comp ih

theorem angleIterate_add_int_pi (F : ℝ → ℝ → ℝ)
    (hpi : ∀ x s, F x (s+Real.pi)=F x s+Real.pi)
    (α x s : ℝ) (l : ℤ) (n : ℕ) :
    angleIterate F α x (s+(l:ℝ)*Real.pi) n=angleIterate F α x s n+(l:ℝ)*Real.pi := by
  induction n with
  | zero => rfl
  | succ n ih => rw [angleIterate_succ,ih,angleIterate_succ,angleMap_add_int_pi F hpi]

theorem angleIterate_invariant_line (F : ℝ → ℝ → ℝ) (α : ℝ) (θ : ℝ → ℝ) (k : ℤ)
    (hstep : ∀ x, F x (θ x)=θ (x+α)+(k:ℝ)*Real.pi)
    (hpi : ∀ x s, F x (s+Real.pi)=F x s+Real.pi) (x : ℝ) (n : ℕ) :
    angleIterate F α x (θ x) n=θ (x+(n:ℝ)*α)+(n:ℝ)*(k:ℝ)*Real.pi := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [angleIterate_succ,ih]
    have he : F (x+(n:ℝ)*α) (θ (x+(n:ℝ)*α)+(n:ℝ)*(k:ℝ)*Real.pi)=
        F (x+(n:ℝ)*α) (θ (x+(n:ℝ)*α))+(n:ℝ)*(k:ℝ)*Real.pi := by
      simpa only [Int.cast_mul,Int.cast_natCast] using
        angleMap_add_int_pi F hpi (x+(n:ℝ)*α) (θ (x+(n:ℝ)*α)) ((n:ℤ)*k)
    rw [he,hstep]
    push_cast
    rw [show x+(n:ℝ)*α+α=x+((n:ℝ)+1)*α by ring]
    ring

theorem winding_remainder_bounded (θ : ℝ → ℝ) (m : ℤ) (hθ : Continuous θ)
    (hwind : ∀ x, θ (x+1)=θ x+(m:ℝ)*Real.pi) :
    ∃ C : ℝ, 0<C ∧ ∀ x, |θ x-(m:ℝ)*Real.pi*x|≤C := by
  have hp : Function.Periodic (fun x => θ x-(m:ℝ)*Real.pi*x) 1 := by
    intro x
    change θ (x+1)-(m:ℝ)*Real.pi*(x+1)=θ x-(m:ℝ)*Real.pi*x
    rw [hwind]
    ring
  have hc : Continuous (fun x => θ x-(m:ℝ)*Real.pi*x) := by fun_prop
  obtain ⟨C,hC,hb⟩ := (hp.isBounded_of_continuous (by norm_num) hc).exists_pos_norm_le
  exact ⟨C,hC,fun x => hb _ ⟨x,rfl⟩⟩

theorem angleIterate_bounded_deviation (F : ℝ → ℝ → ℝ) (α : ℝ) (θ : ℝ → ℝ)
    (m k : ℤ) (hθ : Continuous θ) (hwind : ∀ x, θ (x+1)=θ x+(m:ℝ)*Real.pi)
    (hstep : ∀ x, F x (θ x)=θ (x+α)+(k:ℝ)*Real.pi)
    (hmono : ∀ x, Monotone (F x))
    (hpi : ∀ x s, F x (s+Real.pi)=F x s+Real.pi) (x s : ℝ) :
    ∃ B : ℝ, 0<B ∧ ∀ n : ℕ,
      |angleIterate F α x s n-s-Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ)|≤B := by
  obtain ⟨C,hC,hrem⟩ := winding_remainder_bounded θ m hθ hwind
  obtain ⟨l,hl,_⟩ := existsUnique_sub_zsmul_mem_Ico Real.pi_pos (s-θ x) 0
  simp only [zero_add,zsmul_eq_mul,Set.mem_Ico] at hl
  have hlo : θ x+(l:ℝ)*Real.pi≤s := by linarith [hl.1]
  have hhi : s≤θ x+((l:ℝ)+1)*Real.pi := by linarith [hl.2]
  let b := (m:ℝ)*Real.pi*x+(l:ℝ)*Real.pi-s
  refine ⟨C+|b|+Real.pi,by positivity,?_⟩
  intro n
  have hlower := angleIterate_monotone F hmono α x n hlo
  have hupper := angleIterate_monotone F hmono α x n hhi
  dsimp only at hlower hupper
  rw [angleIterate_add_int_pi F hpi,angleIterate_invariant_line F α θ k hstep hpi] at hlower
  have he : θ x+((l:ℝ)+1)*Real.pi=θ x+((l+1:ℤ):ℝ)*Real.pi := by push_cast; rfl
  rw [he,angleIterate_add_int_pi F hpi,angleIterate_invariant_line F α θ k hstep hpi] at hupper
  push_cast at hupper
  have hlo' : θ (x+(n:ℝ)*α)-(m:ℝ)*Real.pi*(x+(n:ℝ)*α)+b ≤
      angleIterate F α x s n-s-Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ) := by
    dsimp [b]
    linear_combination hlower
  have hhi' : angleIterate F α x s n-s-Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ) ≤
      θ (x+(n:ℝ)*α)-(m:ℝ)*Real.pi*(x+(n:ℝ)*α)+b+Real.pi := by
    dsimp [b]
    linear_combination hupper
  obtain ⟨hrlo,hrhi⟩ := abs_le.mp (hrem (x+(n:ℝ)*α))
  apply abs_le.mpr
  constructor
  · linarith [neg_abs_le b,Real.pi_pos]
  · linarith [le_abs_self b]

theorem angleIterate_mean_tendsto (F : ℝ → ℝ → ℝ) (α : ℝ) (θ : ℝ → ℝ)
    (m k : ℤ) (hθ : Continuous θ) (hwind : ∀ x, θ (x+1)=θ x+(m:ℝ)*Real.pi)
    (hstep : ∀ x, F x (θ x)=θ (x+α)+(k:ℝ)*Real.pi)
    (hmono : ∀ x, Monotone (F x))
    (hpi : ∀ x s, F x (s+Real.pi)=F x s+Real.pi) (x s : ℝ) :
    Tendsto (fun n : ℕ => (angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 (((m:ℝ)*α+(k:ℝ))/2)) := by
  obtain ⟨B,hB,hbound⟩ := angleIterate_bounded_deviation F α θ m k hθ hwind hstep hmono hpi x s
  let e := fun n : ℕ => angleIterate F α x s n-s-Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ)
  have he : Tendsto (fun n : ℕ => e n/(n:ℝ)) atTop (𝓝 0) := by
    apply squeeze_zero_norm (a:=fun n : ℕ => B/(n:ℝ))
    · intro n
      simp only [norm_div,Real.norm_eq_abs,abs_of_nonneg (Nat.cast_nonneg n : (0:ℝ)≤n)]
      exact div_le_div_of_nonneg_right (hbound n) (Nat.cast_nonneg n)
    · exact tendsto_const_div_atTop_nhds_zero_nat B
  have ht := (he.div_const (2*Real.pi)).add_const (((m:ℝ)*α+(k:ℝ))/2)
  simp only [zero_div,zero_add] at ht
  apply ht.congr'
  filter_upwards [eventually_ge_atTop (1:ℕ)] with n hn
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  dsimp [e]
  field_simp [Real.pi_ne_zero,hn0]
  ring

end UAMO.ProjectiveAngle

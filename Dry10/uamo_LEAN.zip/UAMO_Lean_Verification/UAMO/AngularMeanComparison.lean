import UAMO.PhysicalGapRotation

noncomputable section
namespace UAMO.ProjectiveAngle
open Set Filter
open scoped Topology

theorem angleIterate_displacement_difference_le_pi (F : ℝ → ℝ → ℝ)
    (hmono : ∀x,Monotone (F x))
    (hpi : ∀x s,F x (s+Real.pi)=F x s+Real.pi)
    (α x s v : ℝ) (n : ℕ) :
    |(angleIterate F α x s n-angleIterate F α x v n)-(s-v)|≤Real.pi := by
  obtain ⟨l,hl,_⟩ := existsUnique_sub_zsmul_mem_Ico Real.pi_pos (s-v) 0
  simp only [zero_add,zsmul_eq_mul,Set.mem_Ico] at hl
  have hlo : v+(l:ℝ)*Real.pi≤s := by linarith [hl.1]
  have hhi : s≤v+((l:ℝ)+1)*Real.pi := by linarith [hl.2]
  have hlower := angleIterate_monotone F hmono α x n hlo
  have hupper := angleIterate_monotone F hmono α x n hhi
  dsimp only at hlower hupper
  rw [angleIterate_add_int_pi F hpi] at hlower
  have he : v+((l:ℝ)+1)*Real.pi=v+((l+1:ℤ):ℝ)*Real.pi := by push_cast; rfl
  rw [he,angleIterate_add_int_pi F hpi] at hupper
  push_cast at hupper
  apply abs_le.mpr
  constructor <;> linarith [hl.1,hl.2]

theorem tendsto_div_nat_of_bounded_error_div_succ (u v : ℕ → ℝ)
    (c ρ C : ℝ) (hc : c≠0) (herror : ∀n,|u n-v n|≤C)
    (hv : Tendsto (fun n : ℕ => v n/(c*((n:ℝ)+1))) atTop (𝓝 ρ)) :
    Tendsto (fun n : ℕ => u n/(c*(n:ℝ))) atTop (𝓝 ρ) := by
  have he : Tendsto (fun n : ℕ => (u n-v n)/(n:ℝ)) atTop (𝓝 0) := by
    apply squeeze_zero_norm (a:=fun n : ℕ => C/(n:ℝ))
    · intro n
      simp only [norm_div,Real.norm_eq_abs,abs_of_nonneg (Nat.cast_nonneg n : (0:ℝ)≤n)]
      exact div_le_div_of_nonneg_right (herror n) (Nat.cast_nonneg n)
    · exact tendsto_const_div_atTop_nhds_zero_nat C
  have hv' : Tendsto (fun n : ℕ => v n/(c*(n:ℝ))) atTop (𝓝 ρ) := by
    have h := hv.div (tendsto_natCast_div_add_atTop (1:ℝ)) (by norm_num)
    simp only [div_one] at h
    apply h.congr'
    filter_upwards [eventually_ge_atTop (1:ℕ)] with n hn
    have hn0 : (n:ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
    have hn1 : (n:ℝ)+1≠0 := by positivity
    field_simp [hc,hn0,hn1]
    ring
  have h := hv'.add (he.div_const c)
  simp only [zero_div,add_zero] at h
  apply h.congr'
  filter_upwards [eventually_ge_atTop (1:ℕ)] with n hn
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  field_simp [hc,hn0]
  ring

theorem angleIterate_mean_tendsto_of_endpoint (F : ℝ → ℝ → ℝ)
    (hmono : ∀x,Monotone (F x))
    (hpi : ∀x s,F x (s+Real.pi)=F x s+Real.pi)
    (α x v c ρ : ℝ)
    (hendpoint : Tendsto (fun n : ℕ =>
      (angleIterate F α x v n+c)/(2*Real.pi*((n:ℝ)+1))) atTop (𝓝 ρ)) (s : ℝ) :
    Tendsto (fun n : ℕ => (angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 ρ) := by
  apply tendsto_div_nat_of_bounded_error_div_succ
    (fun n => angleIterate F α x s n-s)
    (fun n => angleIterate F α x v n+c) (2*Real.pi) ρ
    (Real.pi+|v+c|) (by positivity) _ hendpoint
  intro n
  calc
    |(angleIterate F α x s n-s)-(angleIterate F α x v n+c)| =
        |((angleIterate F α x s n-angleIterate F α x v n)-(s-v))-(v+c)| := by
          congr 1
          ring
    _ ≤ |(angleIterate F α x s n-angleIterate F α x v n)-(s-v)|+|v+c| := abs_sub _ _
    _ ≤ Real.pi+|v+c| := add_le_add_right
      (angleIterate_displacement_difference_le_pi F hmono hpi α x s v n) _

theorem angleIterate_base_rescaling (F : ℝ → ℝ → ℝ) (b α x s : ℝ) (n : ℕ) :
    angleIterate F (b*α) (b*x) s n=
      angleIterate (fun y => F (b*y)) α x s n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [angleIterate_succ,angleIterate_succ,ih]
    congr 1
    ring

end UAMO.ProjectiveAngle

namespace UAMO
open ProjectiveAngle Filter
open scoped Topology

theorem physicalAngularMean_tendsto_of_radian_endpoint {a lam : ℝ}
    (ha : 0<a) (hlam : 0≤lam) (hlam1 : lam<1) (t α x v c ρ : ℝ)
    (hendpoint : Tendsto (fun n : ℕ =>
      (angleIterate (fun y => realTransferAngleLift a lam t y)
        (2*Real.pi*α) (2*Real.pi*x) v n+c)/(2*Real.pi*((n:ℝ)+1))) atTop (𝓝 ρ))
    (s : ℝ) : Tendsto (physicalAngularMean a lam t α x s) atTop (𝓝 ρ) := by
  simp_rw [angleIterate_base_rescaling] at hendpoint
  exact angleIterate_mean_tendsto_of_endpoint _
    (fun y => (realTransferAngleLift_strictMono ha hlam hlam1 t (2*Real.pi*y)).monotone)
    (fun y u => realTransferAngleLift_add_pi a lam t (2*Real.pi*y) u)
    α x v c ρ hendpoint s

end UAMO

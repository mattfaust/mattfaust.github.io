import UAMO.RealCocycleConjugacy
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

noncomputable section
namespace UAMO
open Matrix MeasureTheory

def axisDiagonalEntry (a lam x : ℝ) : ℝ :=
  a * (1 - lam * Real.sin x) / realTransferDenominator lam x

theorem axis_sine_abs_lt_one {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    |lam * Real.sin x| < 1 := by
  rw [abs_mul, abs_of_nonneg hlam]
  exact (mul_le_of_le_one_right hlam (Real.abs_sin_le_one x)).trans_lt hlam1

theorem axisDiagonalEntry_pos {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    0 < axisDiagonalEntry a lam x := by
  have hs := (abs_lt.mp (axis_sine_abs_lt_one hlam hlam1 x)).2
  exact div_pos (mul_pos ha (sub_pos.mpr hs)) (realTransferDenominator_pos hlam hlam1 x)

theorem axisDiagonalEntry_inverse {a lam : ℝ} (ha : a ≠ 0)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    (axisDiagonalEntry a lam x)⁻¹ =
      a⁻¹ * (1 + lam * Real.sin x) / realTransferDenominator lam x := by
  have hden := (realTransferDenominator_pos hlam hlam1 x).ne'
  have hs := (abs_lt.mp (axis_sine_abs_lt_one hlam hlam1 x)).2
  have hm : 1 - lam * Real.sin x ≠ 0 := (sub_pos.mpr hs).ne'
  have hsq := realTransferDenominator_sq hlam hlam1 x
  dsimp only [axisDiagonalEntry]
  field_simp
  linear_combination a * hsq

theorem realTransfer_zero_axis {a lam : ℝ} (ha : a ≠ 0)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    realTransfer a lam 0 x =
      !![axisDiagonalEntry a lam x, 0; 0, (axisDiagonalEntry a lam x)⁻¹] := by
  rw [axisDiagonalEntry_inverse ha hlam hlam1]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [realTransfer, realTransferNumerator, axisDiagonalEntry, div_eq_mul_inv, mul_comm]

theorem realTransferDenominator_add_pi (lam x : ℝ) :
    realTransferDenominator lam (x + Real.pi) = realTransferDenominator lam x := by
  simp [realTransferDenominator, Real.sin_add_pi]

theorem realTransfer_pi_axis (a lam x : ℝ) :
    realTransfer a lam Real.pi x = -realTransfer a lam 0 (x + Real.pi) := by
  rw [realTransfer, realTransfer, realTransferDenominator_add_pi]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [realTransferNumerator, Real.sin_add_pi] <;> ring

theorem axisDiagonalEntry_half_period_product {a lam : ℝ}
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    axisDiagonalEntry a lam x * axisDiagonalEntry a lam (x + Real.pi) = a^2 := by
  have hd := (realTransferDenominator_pos hlam hlam1 x).ne'
  have hsq := realTransferDenominator_sq hlam hlam1 x
  simp only [axisDiagonalEntry, realTransferDenominator_add_pi, Real.sin_add_pi, mul_neg,
    sub_neg_eq_add]
  rw [← mul_div_mul_comm, ← pow_two, div_eq_iff (pow_ne_zero 2 hd)]
  linear_combination -a^2 * hsq

theorem continuous_axisDiagonalEntry (a : ℝ) {lam : ℝ}
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) : Continuous (axisDiagonalEntry a lam) := by
  unfold axisDiagonalEntry realTransferDenominator
  apply Continuous.div (by fun_prop) (by fun_prop)
  intro x
  exact (realTransferDenominator_pos hlam hlam1 x).ne'

theorem axisDiagonalEntry_periodic (a lam : ℝ) :
    Function.Periodic (axisDiagonalEntry a lam) (2 * Real.pi) := by
  intro x
  simp only [axisDiagonalEntry, realTransferDenominator, Real.sin_add_two_pi]

theorem continuous_log_axisDiagonalEntry {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    Continuous (fun x => Real.log (axisDiagonalEntry a lam x)) :=
  (continuous_axisDiagonalEntry a hlam hlam1).log
    (fun x => (axisDiagonalEntry_pos ha hlam hlam1 x).ne')

theorem log_axisDiagonalEntry_half_period {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    Real.log (axisDiagonalEntry a lam x) +
      Real.log (axisDiagonalEntry a lam (x + Real.pi)) = 2 * Real.log a := by
  rw [← Real.log_mul (axisDiagonalEntry_pos ha hlam hlam1 x).ne'
    (axisDiagonalEntry_pos ha hlam hlam1 (x + Real.pi)).ne',
    axisDiagonalEntry_half_period_product hlam hlam1, Real.log_pow]
  norm_num

theorem integral_log_axisDiagonalEntry {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    (∫ x in (0 : ℝ)..(2 * Real.pi), Real.log (axisDiagonalEntry a lam x)) =
      (2 * Real.pi) * Real.log a := by
  let f := fun x => Real.log (axisDiagonalEntry a lam x)
  have hc : Continuous f := continuous_log_axisDiagonalEntry ha hlam hlam1
  have hp : Function.Periodic f (2 * Real.pi) :=
    (axisDiagonalEntry_periodic a lam).comp Real.log
  have hs : (∫ x in (0 : ℝ)..(2 * Real.pi), f (x + Real.pi)) =
      ∫ x in (0 : ℝ)..(2 * Real.pi), f x := by
    rw [intervalIntegral.integral_comp_add_right]
    simpa only [zero_add, add_comm (2 * Real.pi) Real.pi] using
      hp.intervalIntegral_add_eq Real.pi 0
  have hsum : (∫ x in (0 : ℝ)..(2 * Real.pi), f x + f (x + Real.pi)) =
      (2 * Real.pi) * (2 * Real.log a) := by
    simp_rw [show ∀ x, f x + f (x + Real.pi) = 2 * Real.log a from
      log_axisDiagonalEntry_half_period ha hlam hlam1]
    simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul]
  have his : IntervalIntegrable (fun x => f (x + Real.pi)) volume 0 (2 * Real.pi) :=
    (hc.comp (continuous_id.add continuous_const)).intervalIntegrable _ _
  rw [intervalIntegral.integral_add (hc.intervalIntegrable _ _) his, hs] at hsum
  dsimp only [f] at hsum
  linarith

end UAMO

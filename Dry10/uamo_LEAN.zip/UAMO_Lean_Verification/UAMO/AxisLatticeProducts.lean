import UAMO.AxisUniformGrowth

noncomputable section
namespace UAMO

theorem axisDiagonalEntry_bounded_with_inverse {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    ∃ C : ℝ, 0 < C ∧ ∀ x : ℝ,
      ‖(axisDiagonalEntry a lam x : ℂ)‖ ≤ C ∧
      ‖(axisDiagonalEntry a lam x : ℂ)⁻¹‖ ≤ C := by
  have hp := axisDiagonalEntry_periodic a lam
  have hc := continuous_axisDiagonalEntry a hlam hlam1
  have hperiod : 2 * Real.pi ≠ 0 := by positivity
  obtain ⟨C, hC⟩ := (hp.isBounded_of_continuous hperiod hc).exists_norm_le
  have hci : Continuous (fun x => (axisDiagonalEntry a lam x)⁻¹) :=
    hc.inv₀ (fun x => (axisDiagonalEntry_pos ha hlam hlam1 x).ne')
  obtain ⟨D, hD⟩ := ((hp.comp (fun y : ℝ => y⁻¹)).isBounded_of_continuous
    hperiod hci).exists_norm_le
  refine ⟨max (max C D) 1, lt_of_lt_of_le zero_lt_one (le_max_right _ _), fun x => ⟨?_, ?_⟩⟩
  · simpa only [Complex.norm_real] using
      (hC _ ⟨x, rfl⟩).trans ((le_max_left C D).trans (le_max_left _ _))
  · rw [← Complex.ofReal_inv, Complex.norm_real]
    exact (hD _ ⟨x, rfl⟩).trans ((le_max_right C D).trans (le_max_left _ _))

theorem axis_products_both_directions {α a lam : ℝ} (hα : Irrational α)
    (ha : 0 < a) (ha1 : a < 1) (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    ∃ N : ℕ, 1 ≤ N ∧ ∃ q : ℝ, 0 < q ∧ q < 1 ∧ ∀ x : ℝ,
      ‖∏ j ∈ Finset.range N, (axisDiagonalEntry a lam
        (x + (j : ℝ) * (2 * Real.pi * α)) : ℂ)‖ ≤ q ∧
      ‖∏ j ∈ Finset.range N, (axisDiagonalEntry a lam
        (x - (j : ℝ) * (2 * Real.pi * α)) : ℂ)‖ ≤ q := by
  obtain ⟨N, hN, hforward⟩ := axis_product_uniform_contraction hα ha ha1 hlam hlam1
  obtain ⟨M, hM, hbackward⟩ := axis_product_uniform_contraction hα.neg ha ha1 hlam hlam1
  let K := max N M
  let q := Real.exp ((K : ℝ) * (Real.log a / 2))
  have hK : 1 ≤ K := hN.trans (le_max_left _ _)
  have hq : q < 1 := (hforward K (le_max_left _ _) 0).2
  refine ⟨K, hK, q, Real.exp_pos _, hq, fun x => ⟨?_, ?_⟩⟩
  · have hp : 0 ≤ ∏ j ∈ Finset.range K,
        axisDiagonalEntry a lam (x + (j : ℝ) * (2 * Real.pi * α)) :=
      Finset.prod_nonneg (fun j _ => (axisDiagonalEntry_pos ha hlam hlam1 _).le)
    rw [← Complex.ofReal_prod, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hp]
    exact (hforward K (le_max_left _ _) x).1
  · have hp : 0 ≤ ∏ j ∈ Finset.range K,
        axisDiagonalEntry a lam (x - (j : ℝ) * (2 * Real.pi * α)) :=
      Finset.prod_nonneg (fun j _ => (axisDiagonalEntry_pos ha hlam hlam1 _).le)
    rw [← Complex.ofReal_prod, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hp]
    have h := (hbackward K (le_max_right _ _) x).1
    simpa only [mul_neg, neg_mul, ← sub_eq_add_neg] using h

end UAMO

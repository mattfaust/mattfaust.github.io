import UAMO.AxisLatticeProducts
import UAMO.WeightedShiftResolvent
import UAMO.RealCocycleResolvent

noncomputable section
namespace UAMO
open Matrix CMV PhysicalRepresentation

private theorem diagonal_two_isUnit {A : Type*} [Ring A] (x y : A)
    (hx : IsUnit x) (hy : IsUnit y) : IsUnit (!![x,0;0,y] : Matrix (Fin 2) (Fin 2) A) := by
  obtain ⟨u,rfl⟩ := hx
  obtain ⟨v,rfl⟩ := hy
  refine ⟨⟨!![↑u,0;0,↑v],!![↑u⁻¹,0;0,↑v⁻¹],?_,?_⟩,rfl⟩
  all_goals ext i j; fin_cases i <;> fin_cases j <;>
    simp [Matrix.mul_apply,Fin.sum_univ_two]

theorem real_axis_recurrence_isUnit {α a lam : ℝ} (hα : Irrational α)
    (ha : 0<a) (ha1 : a<1) (hlam : 0≤lam) (hlam1 : lam<1) (θ s : ℝ) :
    ∃C:ℝ,∃hC:0<C,∃hB:∀n i j,
      ‖complexRealTransfer a lam 0 (phaseAngle α θ n+s) i j‖≤C,
      IsUnit (latticeDifference
        (fun n => complexRealTransfer a lam 0 (phaseAngle α θ n+s)) C hC.le hB) := by
  obtain ⟨C,hC,hbound⟩ := axisDiagonalEntry_bounded_with_inverse ha hlam hlam1
  obtain ⟨N,_,q,_,hq,hprod⟩ := axis_products_both_directions hα ha ha1 hlam hlam1
  let d := fun n : ℤ => (axisDiagonalEntry a lam (phaseAngle α θ n+s) : ℂ)
  have hd : ∀n,‖d n‖≤C := fun n => (hbound _).1
  have hi : ∀n,‖(d n)⁻¹‖≤C := fun n => (hbound _).2
  have hne : ∀n,d n≠0 := fun n => Complex.ofReal_ne_zero.mpr
    (axisDiagonalEntry_pos ha hlam hlam1 _).ne'
  have hp : ∀n:ℤ,‖∏k∈Finset.range N,d (n+(k:ℤ))‖≤q := by
    intro n
    convert (hprod (phaseAngle α θ n+s)).1 using 1
    congr 1
    apply Finset.prod_congr rfl
    intro k _
    dsimp only [d]
    congr 2
    unfold phaseAngle
    push_cast
    ring
  have hu0 := lattice_recurrence_isUnit_of_forward_product_contraction d C hC.le hd N q hq hp
  have hu1 := lattice_recurrence_isUnit_of_inverse_product_contraction
    (fun n => (d n)⁻¹) C C hC.le hC.le hi (by simpa using hd)
    (fun n => inv_ne_zero (hne n)) N q hq (by simpa using hp)
  have hdiag (n : ℤ) : complexRealTransfer a lam 0 (phaseAngle α θ n+s)=
      !![d n,0;0,(d n)⁻¹] := by
    unfold complexRealTransfer
    rw [realTransfer_zero_axis ha.ne' hlam hlam1]
    ext i j
    fin_cases i <;> fin_cases j <;> simp [d]
  have hB : ∀n i j,‖complexRealTransfer a lam 0 (phaseAngle α θ n+s) i j‖≤C := by
    intro n i j
    rw [hdiag]
    fin_cases i <;> fin_cases j <;> simp only [Matrix.of_apply,Matrix.cons_val_zero,
      Matrix.cons_val_one,Matrix.cons_val_fin_one]
    · exact hd n
    · simpa using hC.le
    · simpa using hC.le
    · exact hi n
  refine ⟨C,hC,hB,?_⟩
  have he : latticeDifference
      (fun n => complexRealTransfer a lam 0 (phaseAngle α θ n+s)) C hC.le hB=
      !![star shift-latticeMultiplier d C hC.le hd,0;
        0,star shift-latticeMultiplier (fun n => (d n)⁻¹) C hC.le hi] := by
    ext i j ψ n
    fin_cases i <;> fin_cases j <;>
      simp [latticeDifference,latticeForwardShift,latticeMatrixMultiplier,hdiag]
  rw [he]
  exact diagonal_two_isUnit _ _ hu0 hu1

theorem physical_one_resolvent {a r α : ℝ} (ha : 0<a) (ha1 : a<1)
    (hr : 0≤r) (hr1 : r<1) (hα : Irrational α) (θ : ℝ) :
    (1:ℂ)∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) α θ) := by
  have hlam : 0≤coupling r := by unfold coupling; positivity
  obtain ⟨C,hC,hB,hu⟩ := real_axis_recurrence_isUnit hα ha ha1 hlam
    (coupling_lt_one_of_lt_one hr1) θ 0
  have hB' : ∀n i j,‖complexRealTransfer a (coupling r) 0 (phaseAngle α θ n) i j‖≤C := by
    simpa only [add_zero] using hB
  have hu' : IsUnit (latticeDifference
      (fun n => complexRealTransfer a (coupling r) 0 (phaseAngle α θ n)) C hC.le hB') := by
    have he : latticeDifference
        (fun n => complexRealTransfer a (coupling r) 0 (phaseAngle α θ n+0)) C hC.le hB =
        latticeDifference
          (fun n => complexRealTransfer a (coupling r) 0 (phaseAngle α θ n)) C hC.le hB' := by
      ext i j ψ n
      simp [latticeDifference,latticeMatrixMultiplier]
    rwa [he] at hu
  have h := (physicalWalk_resolvent_iff_real_latticeDifference ha ha1.le hr hr1 α θ 0 C hC.le hB').mpr hu'
  simpa using h

theorem physical_neg_one_resolvent {a r α : ℝ} (ha : 0<a) (ha1 : a<1)
    (hr : 0≤r) (hr1 : r<1) (hα : Irrational α) (θ : ℝ) :
    (-1:ℂ)∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) α θ) := by
  have hlam : 0≤coupling r := by unfold coupling; positivity
  obtain ⟨C,hC,hB,hu⟩ := real_axis_recurrence_isUnit hα ha ha1 hlam
    (coupling_lt_one_of_lt_one hr1) θ Real.pi
  let A := fun n => complexRealTransfer a (coupling r) Real.pi (phaseAngle α θ n)
  let B := fun n => complexRealTransfer a (coupling r) 0 (phaseAngle α θ n+Real.pi)
  have he : ∀n,A n= -B n := by
    intro n
    dsimp only [A,B,complexRealTransfer]
    rw [realTransfer_pi_axis]
    ext i j
    simp
  have hA : ∀n i j,‖A n i j‖≤C := by
    intro n i j
    simpa only [he,Matrix.neg_apply,norm_neg] using hB n i j
  have hconj : ∀n,((-1:ℂ) • A n)*(1:TransferMatrix)=1*B n := by
    intro n
    simp [he]
  have huA := (latticeDifference_isUnit_iff_scalar_conjugacy A B (fun _ => (-1:ℂ))
    1 1 C C hC.le hC.le hA hB (by intro n; norm_num) (by simp) hconj).mpr hu
  have h := (physicalWalk_resolvent_iff_real_latticeDifference ha ha1.le hr hr1
    α θ Real.pi C hC.le hA).mpr huA
  simpa using h

end UAMO

import UAMO.PhysicalGapRotation
import UAMO.RealTransferAngleNormalization
import UAMO.PhysicalAxisLabels

noncomputable section
namespace UAMO
open ProjectiveAngle Filter CircleDOS PhysicalDOS
open scoped Topology

theorem physicalAngularRotation_zero_axis {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (α : ℝ) :
    HasPhysicalAngularRotation a lam 0 α 0 := by
  intro x s
  have h := angleIterate_mean_tendsto
    (fun y => realTransferAngleLift a lam 0 (2*Real.pi*y)) α
    (fun _ => 0) 0 0 continuous_const (by simp)
    (by intro y; simp [realTransferAngleLift_zero_axis])
    (fun y => (realTransferAngleLift_strictMono ha hlam hlam1 0 (2*Real.pi*y)).monotone)
    (fun y v => realTransferAngleLift_add_pi a lam 0 (2*Real.pi*y) v) x s
  simpa only [Int.cast_zero,zero_mul,zero_add,zero_div] using h

theorem physicalAngularRotation_pi_axis {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (α : ℝ) :
    HasPhysicalAngularRotation a lam Real.pi α (1/2) := by
  intro x s
  have h := angleIterate_mean_tendsto
    (fun y => realTransferAngleLift a lam Real.pi (2*Real.pi*y)) α
    (fun _ => 0) 0 1 continuous_const (by simp)
    (by intro y; simp [realTransferAngleLift_pi_axis])
    (fun y => (realTransferAngleLift_strictMono ha hlam hlam1 Real.pi (2*Real.pi*y)).monotone)
    (fun y v => realTransferAngleLift_add_pi a lam Real.pi (2*Real.pi*y) v) x s
  simpa only [Int.cast_zero,Int.cast_one,zero_mul,zero_add] using h

theorem physical_axis_rotation_labels {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (α : ℝ) :
    HasPhysicalRotationLabel a lam 0 α (uamoGapLabel α 0 0) ∧
      HasPhysicalRotationLabel a lam Real.pi α (uamoGapLabel α 0 1) := by
  refine ⟨⟨0,physicalAngularRotation_zero_axis ha hlam hlam1 α,?_⟩,
    ⟨1/2,physicalAngularRotation_pi_axis ha hlam hlam1 α,?_⟩⟩ <;>
    simp [uamoGapLabel]

theorem physical_axis_rotation_DOS_labels {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r<1) (α : ℝ) :
    HasPhysicalRotationLabel a (coupling r) 0 α
      ((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le) 1:ℝ):AddCircle (1:ℝ)) ∧
    HasPhysicalRotationLabel a (coupling r) Real.pi α
      ((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le) (-1):ℝ):AddCircle (1:ℝ)) := by
  obtain ⟨hp,hm⟩ := physical_axis_arcLabels ha ha1 hr hr1.le α
  obtain ⟨h0,hpi⟩ := physical_axis_rotation_labels ha
    (by unfold coupling; positivity) (CMV.coupling_lt_one_of_lt_one hr1) α
  rw [hp,hm,AddCircle.coe_period]
  simpa only [uamoGapLabel,Int.cast_zero,Int.cast_one,zero_mul,zero_add,zero_div,
    AddCircle.coe_zero] using And.intro h0 hpi

end UAMO

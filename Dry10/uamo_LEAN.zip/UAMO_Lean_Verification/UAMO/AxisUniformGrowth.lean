import UAMO.AxisCocycle
import UAMO.CircleRotationAverage

noncomputable section
namespace UAMO
open MeasureTheory Filter Set CircleDOS
open scoped Topology

def axisLogEntryComplex (a lam : ℝ) (z : ℂ) : ℂ :=
  (Real.log (a * (1 - lam * z.im) / Real.sqrt (1 - lam^2 * z.im^2)) : ℝ)

theorem axisLogEntryComplex_measurable (a lam : ℝ) : Measurable (axisLogEntryComplex a lam) := by
  unfold axisLogEntryComplex
  fun_prop

theorem axisCircle_sine_bound {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam < 1)
    (z : Circle) : |lam * (z : ℂ).im| < 1 := by
  have hi : |(z : ℂ).im| ≤ 1 := (Complex.abs_im_le_norm _).trans_eq z.norm_coe
  rw [abs_mul, abs_of_nonneg hlam]
  exact (mul_le_of_le_one_right hlam hi).trans_lt hlam1

theorem axisLogEntryComplex_continuous_circle {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    Continuous (fun z : Circle => axisLogEntryComplex a lam z) := by
  have hb (z : Circle) := abs_lt.mp (axisCircle_sine_bound hlam hlam1 z)
  have hd (z : Circle) : 0 < 1 - lam^2 * (z : ℂ).im^2 := by
    have hh := mul_pos (sub_pos.mpr (hb z).2) (show 0 < 1 + lam * (z : ℂ).im by linarith [(hb z).1])
    nlinarith only [hh]
  have hden (z : Circle) : 0 < Real.sqrt (1 - lam^2 * (z : ℂ).im^2) := Real.sqrt_pos.mpr (hd z)
  have hpos (z : Circle) : 0 < a * (1 - lam * (z : ℂ).im) /
      Real.sqrt (1 - lam^2 * (z : ℂ).im^2) :=
    div_pos (mul_pos ha (sub_pos.mpr (hb z).2)) (hden z)
  unfold axisLogEntryComplex
  apply Complex.continuous_ofReal.comp
  apply Continuous.log _ (fun z => (hpos z).ne')
  exact (by fun_prop : Continuous (fun z : Circle => a * (1 - lam * (z : ℂ).im))).div
    (by fun_prop) (fun z => (hden z).ne')

def axisCircleLog {a lam : ℝ} (ha : 0 < a) (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    C(Circle, ℂ) :=
  ⟨fun z => axisLogEntryComplex a lam z, axisLogEntryComplex_continuous_circle ha hlam hlam1⟩

theorem axisLogEntryComplex_exp (a lam x : ℝ) :
    axisLogEntryComplex a lam (Complex.exp ((x : ℂ) * Complex.I)) =
      (Real.log (axisDiagonalEntry a lam x) : ℂ) := by
  simp [axisLogEntryComplex, axisDiagonalEntry, realTransferDenominator,
    Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]

theorem axisCircleLog_exp {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (x : ℝ) :
    axisCircleLog ha hlam hlam1 (Circle.exp x) =
      (Real.log (axisDiagonalEntry a lam x) : ℂ) :=
  axisLogEntryComplex_exp a lam x

theorem integral_log_axisDiagonalEntry_turns {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    (∫ x in (0 : ℝ)..1, Real.log (axisDiagonalEntry a lam (2 * Real.pi * x))) =
      Real.log a := by
  rw [intervalIntegral.integral_comp_mul_left
    (fun x => Real.log (axisDiagonalEntry a lam x)) (by positivity : 2 * Real.pi ≠ 0)]
  simp only [mul_zero, mul_one, integral_log_axisDiagonalEntry ha hlam hlam1, smul_eq_mul]
  field_simp

theorem circleRotationMean_axisCircleLog {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    circleRotationMean (axisCircleLog ha hlam hlam1) = (Real.log a : ℂ) := by
  change (∫ z : Circle, axisLogEntryComplex a lam z ∂circleComap uniformCircleMeasure) = _
  rw [circleComap_integral _ uniformCircleMeasure_ae_circle (axisLogEntryComplex a lam)]
  rw [uniformCircleMeasure, integral_map
    (logFourierChar_continuous 1).measurable.aemeasurable
    (axisLogEntryComplex_measurable a lam).aestronglyMeasurable]
  have he (x : ℝ) : logFourierChar 1 x = Complex.exp (((2 * Real.pi * x : ℝ) : ℂ) * Complex.I) := by
    unfold logFourierChar
    congr 1
    push_cast
    ring
  simp_rw [he, axisLogEntryComplex_exp]
  change (∫ x in Ioc (0 : ℝ) 1, (Real.log (axisDiagonalEntry a lam (2 * Real.pi * x)) : ℂ)) = _
  rw [← intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1),
    intervalIntegral.integral_ofReal, integral_log_axisDiagonalEntry_turns ha hlam hlam1]

theorem circle_exp_pow (x : ℝ) (n : ℕ) :
    Circle.exp x ^ n = Circle.exp ((n : ℝ) * x) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ, ih, ← Circle.exp_add]
    congr 1
    push_cast
    ring

theorem circleRotationAverage_axisCircleLog {a lam : ℝ} (ha : 0 < a)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (ω x : ℝ) (n : ℕ) :
    circleRotationAverage (Circle.exp ω) n (Circle.exp x) (axisCircleLog ha hlam hlam1) =
      (((n : ℝ)⁻¹ * ∑ j ∈ Finset.range n,
        Real.log (axisDiagonalEntry a lam (x + (j : ℝ) * ω))) : ℂ) := by
  rw [circleRotationAverage_apply]
  simp_rw [circle_exp_pow, ← Circle.exp_add, axisCircleLog_exp]
  push_cast
  congr 1
  apply Finset.sum_congr rfl
  intro j _
  rw [add_comm]

theorem axis_log_sum_uniform_negative {α a lam : ℝ} (hα : Irrational α)
    (ha : 0 < a) (ha1 : a < 1) (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    ∃ N : ℕ, 1 ≤ N ∧ ∀ n : ℕ, N ≤ n → ∀ x : ℝ,
      (∑ j ∈ Finset.range n, Real.log (axisDiagonalEntry a lam
        (x + (j : ℝ) * (2 * Real.pi * α)))) < (n : ℝ) * (Real.log a / 2) := by
  have ht := circleRotationAverage_irrational_tendsto hα (axisCircleLog ha hlam hlam1)
  rw [circleRotationMean_axisCircleLog ha hlam hlam1] at ht
  have hre := (Complex.continuous_re.tendsto (Real.log a : ℂ)).comp ht
  have hloga : Real.log a < 0 := Real.log_neg ha ha1
  have hev : ∀ᶠ p : ℕ × Circle in atTop ×ˢ (⊤ : Filter Circle),
      (circleRotationAverage (Circle.exp (2 * Real.pi * α)) p.1 p.2
        (axisCircleLog ha hlam hlam1)).re < Real.log a / 2 :=
    hre.eventually (gt_mem_nhds (by simpa only [Complex.ofReal_re] using
      (show Real.log a < Real.log a / 2 by linarith)))
  have hunif : ∀ᶠ n : ℕ in atTop, ∀ z : Circle,
      (circleRotationAverage (Circle.exp (2 * Real.pi * α)) n z
        (axisCircleLog ha hlam hlam1)).re < Real.log a / 2 :=
    Filter.mem_prod_top.mp hev
  obtain ⟨N, hN⟩ := eventually_atTop.mp hunif
  refine ⟨max N 1, le_max_right _ _, fun n hn x => ?_⟩
  have h := hN n ((le_max_left N 1).trans hn) (Circle.exp x)
  rw [circleRotationAverage_axisCircleLog] at h
  simp only [← Complex.ofReal_mul, Complex.ofReal_re, ← div_eq_inv_mul] at h
  have hn0 : 0 < (n : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one ((le_max_right N 1).trans hn))
  have hh := (div_lt_iff₀ hn0).mp h
  simpa only [mul_comm (Real.log a / 2) (n : ℝ)] using hh

theorem axis_product_uniform_contraction {α a lam : ℝ} (hα : Irrational α)
    (ha : 0 < a) (ha1 : a < 1) (hlam : 0 ≤ lam) (hlam1 : lam < 1) :
    ∃ N : ℕ, 1 ≤ N ∧ ∀ n : ℕ, N ≤ n → ∀ x : ℝ,
      (∏ j ∈ Finset.range n, axisDiagonalEntry a lam
        (x + (j : ℝ) * (2 * Real.pi * α))) ≤ Real.exp ((n : ℝ) * (Real.log a / 2)) ∧
      Real.exp ((n : ℝ) * (Real.log a / 2)) < 1 := by
  obtain ⟨N, hN, hsum⟩ := axis_log_sum_uniform_negative hα ha ha1 hlam hlam1
  refine ⟨N, hN, fun n hn x => ⟨?_, ?_⟩⟩
  · have hp : 0 < ∏ j ∈ Finset.range n,
        axisDiagonalEntry a lam (x + (j : ℝ) * (2 * Real.pi * α)) :=
      Finset.prod_pos (fun j _ => axisDiagonalEntry_pos ha hlam hlam1 _)
    calc
      _ = Real.exp (∑ j ∈ Finset.range n, Real.log (axisDiagonalEntry a lam
          (x + (j : ℝ) * (2 * Real.pi * α)))) := by
        rw [← Real.log_prod _ _ (fun j _ => (axisDiagonalEntry_pos ha hlam hlam1 _).ne'),
          Real.exp_log hp]
      _ ≤ _ := Real.exp_le_exp.mpr (hsum n hn x).le
  · apply Real.exp_lt_one_iff.mpr
    have hn0 : 0 < (n : ℝ) := by
      exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one (hN.trans hn))
    exact mul_neg_of_pos_of_neg hn0 (div_neg_of_neg_of_pos (Real.log_neg ha ha1) (by norm_num))

end UAMO

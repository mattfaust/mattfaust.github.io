import UAMO.BJAvalancheFinite

noncomputable section

open Matrix
open scoped Matrix Matrix.L2OpNorm BigOperators

namespace UAMO.BourgainJitomirskaya
open UAMO.CMV

def avalancheProduct (A : ℕ → TransferMatrix) : ℕ → TransferMatrix
  | 0 => 1
  | n + 1 => A n * avalancheProduct A n

@[simp] theorem avalancheProduct_det (A : ℕ → TransferMatrix)
    (hA : ∀ j, (A j).det = 1) (n : ℕ) : (avalancheProduct A n).det = 1 := by
  induction n with
  | zero => simp [avalancheProduct]
  | succ n ih => simp [avalancheProduct, Matrix.det_mul, hA, ih]

theorem avalancheProduct_norm_pos (A : ℕ → TransferMatrix)
    (hA : ∀ j, (A j).det = 1) (n : ℕ) : 0 < transferNorm (avalancheProduct A n) :=
  zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ (by rw [avalancheProduct_det A hA n, norm_one]))

def avalancheTransition (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ) (j : ℕ) :
    TransferMatrix := star (V (j + 1) : TransferMatrix) * (U j : TransferMatrix)

theorem avalancheTransition_unitary (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ) (j : ℕ) :
    avalancheTransition U V j ∈ Matrix.unitaryGroup (Fin 2) ℂ :=
  (star (V (j + 1)) * U j).property

theorem avalanche_unitary_norm (U V : Matrix.unitaryGroup (Fin 2) ℂ)
    (M : TransferMatrix) :
    transferNorm ((U : TransferMatrix) * M * star (V : TransferMatrix)) =
      transferNorm M := by
  change ‖(U : TransferMatrix) * M * star (V : TransferMatrix)‖ = ‖M‖
  rw [CStarRing.norm_mul_mem_unitary _ (unitary.star_mem V.property),
    CStarRing.norm_coe_unitary_mul]

theorem avalanche_norm_smul (s : ℝ) (hs : 0 ≤ s) (M : TransferMatrix) :
    transferNorm ((s : ℂ) • M) = s * transferNorm M := by
  change ‖(s : ℂ) • M‖ = s * ‖M‖
  simp only [norm_smul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hs]

theorem avalanche_product_decomposition (A : ℕ → TransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : TransferMatrix) * avalancheDiagonal (δ j) * star (V j : TransferMatrix)))
    (n : ℕ) :
    avalancheProduct A (n + 1) = ((∏ j ∈ Finset.range (n + 1), σ j : ℝ) : ℂ) •
      ((U n : TransferMatrix) * avalancheFrameProduct δ (avalancheTransition U V) n *
        star (V 0 : TransferMatrix)) := by
  induction n with
  | zero => simpa [avalancheProduct, avalancheFrameProduct] using hA 0
  | succ n ih =>
      rw [avalancheProduct, hA (n + 1), ih, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
      simp only [Finset.prod_range_succ, Complex.ofReal_mul, avalancheFrameProduct,
        avalancheTransition]
      congr 1
      · ring
      · simp only [mul_assoc]

theorem avalanche_product_norm_decomposition (A : ℕ → TransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hσ : ∀ j, 0 ≤ σ j)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : TransferMatrix) * avalancheDiagonal (δ j) * star (V j : TransferMatrix)))
    (n : ℕ) :
    transferNorm (avalancheProduct A (n + 1)) = (∏ j ∈ Finset.range (n + 1), σ j) *
      transferNorm (avalancheFrameProduct δ (avalancheTransition U V) n) := by
  rw [avalanche_product_decomposition A σ δ U V hA n,
    avalanche_norm_smul _ (Finset.prod_nonneg (fun j _ => hσ j)), avalanche_unitary_norm]

theorem avalanche_pair_decomposition (A : ℕ → TransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : TransferMatrix) * avalancheDiagonal (δ j) * star (V j : TransferMatrix)))
    (j : ℕ) :
    A (j + 1) * A j = ((σ (j + 1) * σ j : ℝ) : ℂ) •
      ((U (j + 1) : TransferMatrix) *
        (avalancheDiagonal (δ (j + 1)) * avalancheTransition U V j * avalancheDiagonal (δ j)) *
          star (V j : TransferMatrix)) := by
  rw [hA (j + 1), hA j, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  simp only [Complex.ofReal_mul, avalancheTransition, mul_assoc]

theorem avalanche_pair_norm_decomposition (A : ℕ → TransferMatrix) (σ δ : ℕ → ℝ)
    (U V : ℕ → Matrix.unitaryGroup (Fin 2) ℂ)
    (hσ : ∀ j, 0 ≤ σ j)
    (hA : ∀ j, A j = (σ j : ℂ) •
      ((U j : TransferMatrix) * avalancheDiagonal (δ j) * star (V j : TransferMatrix)))
    (j : ℕ) :
    transferNorm (A (j + 1) * A j) = (σ (j + 1) * σ j) *
      transferNorm (avalancheDiagonal (δ (j + 1)) * avalancheTransition U V j *
        avalancheDiagonal (δ j)) := by
  rw [avalanche_pair_decomposition A σ δ U V hA j,
    avalanche_norm_smul _ (mul_nonneg (hσ (j + 1)) (hσ j)), avalanche_unitary_norm]

theorem avalanche_log_multiplicity (l : ℕ → ℝ) (n : ℕ) :
    (∑ j ∈ Finset.range (n + 2), l j) + (∑ j ∈ Finset.range n, l (j + 1)) =
      ∑ j ∈ Finset.range (n + 1), (l (j + 1) + l j) := by
  induction n with
  | zero => simp [Finset.sum_range_succ, add_comm]
  | succ n ih =>
      simp only [Nat.succ_eq_add_one, Finset.sum_range_succ] at ih ⊢
      linarith

end UAMO.BourgainJitomirskaya

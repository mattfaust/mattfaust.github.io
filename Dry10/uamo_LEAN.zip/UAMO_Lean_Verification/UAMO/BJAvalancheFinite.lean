import UAMO.BJAvalancheMatrices

noncomputable section

open Matrix
open scoped Matrix Matrix.L2OpNorm BigOperators

namespace UAMO.BourgainJitomirskaya
open UAMO.CMV

@[simp] theorem avalancheMatrixRow_one_norm (i : Fin 2) :
    ‖avalancheMatrixRow (1 : TransferMatrix) i‖ = 1 := by
  apply le_antisymm
  · simpa using avalanche_row_norm_le (1 : TransferMatrix) i
  · have h := (avalancheMatrixRow (1 : TransferMatrix) i).le_opNorm
      (EuclideanSpace.single i 1)
    simpa [avalancheMatrixRow_apply, Matrix.one_apply, EuclideanSpace.single_apply] using h

@[simp] theorem avalancheMatrixRow_diagonal_zero (δ : ℝ) :
    avalancheMatrixRow (avalancheDiagonal δ) 0 = avalancheMatrixRow 1 0 := by
  ext x
  simp [avalancheMatrixRow_apply, avalancheDiagonal, Fin.sum_univ_two]

@[simp] theorem avalancheMatrixRow_diagonal_one (δ : ℝ) :
    avalancheMatrixRow (avalancheDiagonal δ) 1 = (δ : ℂ) • avalancheMatrixRow 1 1 := by
  ext x
  simp [avalancheMatrixRow_apply, avalancheDiagonal, Fin.sum_univ_two]

theorem avalanche_diagonal_row_control {t δ : ℝ}
    (ht : 0 < t) (ht' : t ≤ 1 / 100) (hδ : 0 ≤ δ) (hδ' : δ ≤ t ^ 4) :
    avalancheMatrixRow (avalancheDiagonal δ) 0 ≠ 0 ∧
      ‖avalancheMatrixRow (avalancheDiagonal δ) 1‖ ≤
        8 * t ^ 3 * ‖avalancheMatrixRow (avalancheDiagonal δ) 0‖ := by
  constructor
  · apply norm_ne_zero_iff.mp
    simp
  · have hn : ‖(δ : ℂ) • avalancheMatrixRow 1 1‖ = δ := by
      calc
        ‖(δ : ℂ) • avalancheMatrixRow 1 1‖ = ‖(δ : ℂ)‖ * ‖avalancheMatrixRow 1 1‖ :=
          norm_smul (δ : ℂ) (avalancheMatrixRow (1 : TransferMatrix) 1)
        _ = δ := by rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hδ,
          avalancheMatrixRow_one_norm, mul_one]
    rw [avalancheMatrixRow_diagonal_zero, avalancheMatrixRow_diagonal_one, hn,
      avalancheMatrixRow_one_norm, mul_one]
    have ht8 : t ≤ 8 := by linarith
    have hpow := mul_le_mul_of_nonneg_right ht8 (show 0 ≤ t ^ 3 by positivity)
    nlinarith

theorem avalanche_overlap_lower {t δ ε : ℝ} {R : TransferMatrix}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ t ^ 4) (hε : 0 ≤ ε) (hε' : ε ≤ t ^ 4)
    (hR : R ∈ Matrix.unitaryGroup (Fin 2) ℂ)
    (hpair : t ≤ transferNorm (avalancheDiagonal ε * R * avalancheDiagonal δ)) :
    t / 2 ≤ ‖R 0 0‖ := by
  have ht1 : t ≤ 1 := by linarith
  have ht4 : t ^ 4 ≤ 1 := by simpa using pow_le_pow_left₀ ht.le ht1 4
  have hδ1 : δ ≤ 1 := hδ'.trans ht4
  have hb := entry_norm_bound_of_unitary hR 0 1
  have hc := entry_norm_bound_of_unitary hR 1 0
  have hd := entry_norm_bound_of_unitary hR 1 1
  have hb' := mul_le_mul_of_nonneg_right hb hδ
  have hc' := mul_le_mul_of_nonneg_left hc hε
  have hd' := mul_le_mul_of_nonneg_left hd hε
  have hdd := mul_le_mul_of_nonneg_right hd' hδ
  have hεδ := mul_le_mul_of_nonneg_left hδ1 hε
  have hu : transferNorm (avalancheDiagonal ε * R * avalancheDiagonal δ) ≤
      ‖R 0 0‖ + ‖R 0 1‖ * δ + ε * ‖R 1 0‖ + ε * ‖R 1 1‖ * δ := by
    simpa [avalancheDiagonal, Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two, norm_mul,
      Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hδ, abs_of_nonneg hε, mul_assoc, add_assoc]
      using transferNorm_le_sum_entries (avalancheDiagonal ε * R * avalancheDiagonal δ)
  have hrt := (avalanche_small_parameter ht ht').2.1
  have hrt' := mul_le_mul_of_nonneg_left hrt ht.le
  have hsq := mul_le_mul_of_nonneg_left ht1 ht.le
  have hthree : 3 * t ^ 4 ≤ t / 2 := by nlinarith
  nlinarith

def avalancheFrameProduct (δ : ℕ → ℝ) (R : ℕ → TransferMatrix) : ℕ → TransferMatrix
  | 0 => avalancheDiagonal (δ 0)
  | n + 1 => avalancheDiagonal (δ (n + 1)) * R n * avalancheFrameProduct δ R n

theorem avalanche_frame_rows_and_log (δ : ℕ → ℝ) (R : ℕ → TransferMatrix)
    {t : ℝ} (ht : 0 < t) (ht' : t ≤ 1 / 100) (n : ℕ)
    (hδ : ∀ j ≤ n, 0 ≤ δ j ∧ δ j ≤ t ^ 4)
    (hR : ∀ j < n, R j ∈ Matrix.unitaryGroup (Fin 2) ℂ)
    (ha : ∀ j < n, t / 2 ≤ ‖R j 0 0‖) :
    avalancheMatrixRow (avalancheFrameProduct δ R n) 0 ≠ 0 ∧
      ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 1‖ ≤
        8 * t ^ 3 * ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ ∧
      |Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ -
        ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖| ≤ 32 * (n : ℝ) * t ^ 2 := by
  induction n with
  | zero =>
      obtain ⟨hf, hg⟩ := avalanche_diagonal_row_control ht ht' (hδ 0 le_rfl).1 (hδ 0 le_rfl).2
      refine ⟨hf, hg, ?_⟩
      simp [avalancheFrameProduct]
  | succ n ih =>
      obtain ⟨hf, hg, hlog⟩ := ih
        (fun j hj => hδ j (hj.trans (Nat.le_succ n)))
        (fun j hj => hR j (Nat.lt_succ_of_lt hj))
        (fun j hj => ha j (Nat.lt_succ_of_lt hj))
      obtain ⟨hf', hg'⟩ := avalanche_matrix_step ht ht' (hδ (n + 1) le_rfl).1
        (hδ (n + 1) le_rfl).2 (hR n (Nat.lt_succ_self n))
        (ha n (Nat.lt_succ_self n)) hf hg
      refine ⟨hf', hg', ?_⟩
      have hstep := avalanche_large_row_log_error ht ht'
        (ha n (Nat.lt_succ_self n)) (entry_norm_bound_of_unitary (hR n (Nat.lt_succ_self n)) 0 1)
        hf hg
      rw [← avalancheMatrixRow_step_zero (δ (n + 1)) (R n) (avalancheFrameProduct δ R n)] at hstep
      rw [Finset.sum_range_succ]
      calc
        |Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R (n + 1)) 0‖ -
            ((∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖) + Real.log ‖R n 0 0‖)| =
            |(Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R (n + 1)) 0‖ -
              Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ - Real.log ‖R n 0 0‖) +
              (Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ -
                ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖)| := by congr 1; ring
        _ ≤ |Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R (n + 1)) 0‖ -
              Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ - Real.log ‖R n 0 0‖| +
              |Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ -
                ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖| := abs_add _ _
        _ ≤ 32 * t ^ 2 + 32 * (n : ℝ) * t ^ 2 := add_le_add hstep hlog
        _ = 32 * ((n + 1 : ℕ) : ℝ) * t ^ 2 := by push_cast; ring

theorem avalanche_frame_log_error (δ : ℕ → ℝ) (R : ℕ → TransferMatrix)
    {t : ℝ} (ht : 0 < t) (ht' : t ≤ 1 / 100) (n : ℕ)
    (hδ : ∀ j ≤ n, 0 ≤ δ j ∧ δ j ≤ t ^ 4)
    (hR : ∀ j < n, R j ∈ Matrix.unitaryGroup (Fin 2) ℂ)
    (ha : ∀ j < n, t / 2 ≤ ‖R j 0 0‖) :
    |Real.log (transferNorm (avalancheFrameProduct δ R n)) -
      ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖| ≤ (32 * (n : ℝ) + 16) * t ^ 2 := by
  obtain ⟨hf, hg, hlog⟩ := avalanche_frame_rows_and_log δ R ht ht' n hδ hR ha
  have hnorm := avalanche_norm_log_row_error ht ht' hf hg
  calc
    |Real.log (transferNorm (avalancheFrameProduct δ R n)) -
        ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖| =
        |(Real.log (transferNorm (avalancheFrameProduct δ R n)) -
          Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖) +
          (Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ -
            ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖)| := by congr 1; ring
    _ ≤ |Real.log (transferNorm (avalancheFrameProduct δ R n)) -
          Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖| +
          |Real.log ‖avalancheMatrixRow (avalancheFrameProduct δ R n) 0‖ -
            ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖| := abs_add _ _
    _ ≤ 16 * t ^ 2 + 32 * (n : ℝ) * t ^ 2 := add_le_add hnorm hlog
    _ = _ := by ring

theorem avalanche_pair_log_error {t δ ε : ℝ} {R : TransferMatrix}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ t ^ 4) (hε : 0 ≤ ε) (hε' : ε ≤ t ^ 4)
    (hR : R ∈ Matrix.unitaryGroup (Fin 2) ℂ) (ha : t / 2 ≤ ‖R 0 0‖) :
    |Real.log (transferNorm (avalancheDiagonal ε * R * avalancheDiagonal δ)) -
      Real.log ‖R 0 0‖| ≤ 48 * t ^ 2 := by
  let ds : ℕ → ℝ := fun j => if j = 0 then δ else ε
  have hds : ∀ j ≤ 1, 0 ≤ ds j ∧ ds j ≤ t ^ 4 := by
    intro j _
    by_cases hj : j = 0
    · simpa [ds, hj] using And.intro hδ hδ'
    · simpa [ds, hj] using And.intro hε hε'
  have h := avalanche_frame_log_error ds (fun _ => R) ht ht' 1 hds
    (fun _ _ => hR) (fun _ _ => ha)
  simpa [avalancheFrameProduct, ds, show (32 : ℝ) + 16 = 48 by norm_num] using h

theorem avalanche_principle_in_frames (δ : ℕ → ℝ) (R : ℕ → TransferMatrix)
    {t : ℝ} (ht : 0 < t) (ht' : t ≤ 1 / 100) (n : ℕ)
    (hδ : ∀ j ≤ n, 0 ≤ δ j ∧ δ j ≤ t ^ 4)
    (hR : ∀ j < n, R j ∈ Matrix.unitaryGroup (Fin 2) ℂ)
    (hpair : ∀ j < n,
      t ≤ transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j))) :
    |Real.log (transferNorm (avalancheFrameProduct δ R n)) -
      ∑ j ∈ Finset.range n,
        Real.log (transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)))| ≤
      (80 * (n : ℝ) + 16) * t ^ 2 := by
  have ha (j : ℕ) (hj : j < n) : t / 2 ≤ ‖R j 0 0‖ :=
    avalanche_overlap_lower ht ht' (hδ j (Nat.le_of_lt hj)).1 (hδ j (Nat.le_of_lt hj)).2
      (hδ (j + 1) hj).1 (hδ (j + 1) hj).2 (hR j hj) (hpair j hj)
  have hmain := avalanche_frame_log_error δ R ht ht' n hδ hR ha
  have hsum : |(∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖) -
      ∑ j ∈ Finset.range n,
        Real.log (transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)))| ≤
      48 * (n : ℝ) * t ^ 2 := by
    rw [← Finset.sum_sub_distrib]
    calc
      |∑ j ∈ Finset.range n, (Real.log ‖R j 0 0‖ -
          Real.log (transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j))))| ≤
          ∑ j ∈ Finset.range n, |Real.log ‖R j 0 0‖ -
            Real.log (transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)))| :=
        Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _j ∈ Finset.range n, 48 * t ^ 2 := by
        apply Finset.sum_le_sum
        intro j hj
        have hj' := Finset.mem_range.mp hj
        rw [abs_sub_comm]
        exact avalanche_pair_log_error ht ht'
          (hδ j (Nat.le_of_lt hj')).1 (hδ j (Nat.le_of_lt hj')).2
          (hδ (j + 1) hj').1 (hδ (j + 1) hj').2 (hR j hj') (ha j hj')
      _ = _ := by simp; ring
  calc
    |Real.log (transferNorm (avalancheFrameProduct δ R n)) -
        ∑ j ∈ Finset.range n,
          Real.log (transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)))| ≤
        |Real.log (transferNorm (avalancheFrameProduct δ R n)) -
          ∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖| +
        |(∑ j ∈ Finset.range n, Real.log ‖R j 0 0‖) -
          ∑ j ∈ Finset.range n,
            Real.log (transferNorm (avalancheDiagonal (δ (j + 1)) * R j * avalancheDiagonal (δ j)))| :=
      abs_sub_le _ _ _
    _ ≤ (32 * (n : ℝ) + 16) * t ^ 2 + 48 * (n : ℝ) * t ^ 2 := add_le_add hmain hsum
    _ = _ := by ring

end UAMO.BourgainJitomirskaya

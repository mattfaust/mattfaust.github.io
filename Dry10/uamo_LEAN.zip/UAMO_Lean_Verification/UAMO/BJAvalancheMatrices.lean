import UAMO.BJAvalancheRows

noncomputable section

open Matrix
open scoped Matrix Matrix.L2OpNorm

namespace UAMO.BourgainJitomirskaya
open UAMO.CMV

def avalancheDiagonal (δ : ℝ) : TransferMatrix :=
  !![(1 : ℂ), 0; 0, (δ : ℂ)]

def avalancheMatrixRow (M : TransferMatrix) (i : Fin 2) :
    EuclideanSpace ℂ (Fin 2) →L[ℂ] ℂ :=
  (PiLp.proj (𝕜 := ℂ) 2 (fun _ : Fin 2 => ℂ) i).comp (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M)

@[simp] theorem avalancheMatrixRow_apply (M : TransferMatrix) (i : Fin 2)
    (x : EuclideanSpace ℂ (Fin 2)) :
    avalancheMatrixRow M i x = ∑ j : Fin 2, M i j * x j := rfl

theorem avalanche_vector_norm_le_add (x : EuclideanSpace ℂ (Fin 2)) :
    ‖x‖ ≤ ‖x 0‖ + ‖x 1‖ := by
  have hx : x = EuclideanSpace.single 0 (x 0) + EuclideanSpace.single 1 (x 1) := by
    ext i
    fin_cases i <;> simp [EuclideanSpace.single_apply]
  calc
    ‖x‖ = ‖EuclideanSpace.single 0 (x 0) + EuclideanSpace.single 1 (x 1)‖ := congrArg norm hx
    _ ≤ ‖EuclideanSpace.single 0 (x 0)‖ + ‖EuclideanSpace.single 1 (x 1)‖ := norm_add_le _ _
    _ = _ := by simp

theorem avalanche_row_norm_le (M : TransferMatrix) (i : Fin 2) :
    ‖avalancheMatrixRow M i‖ ≤ transferNorm M := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro x
  calc
    ‖avalancheMatrixRow M i x‖ ≤ ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x‖ := by
      change ‖(Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x) i‖ ≤ _
      exact PiLp.norm_apply_le (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x) i
    _ ≤ transferNorm M * ‖x‖ := (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M).le_opNorm x

theorem avalanche_norm_le_rows (M : TransferMatrix) :
    transferNorm M ≤ ‖avalancheMatrixRow M 0‖ + ‖avalancheMatrixRow M 1‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (by positivity)
  intro x
  calc
    ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x‖ ≤
        ‖avalancheMatrixRow M 0 x‖ + ‖avalancheMatrixRow M 1 x‖ :=
      avalanche_vector_norm_le_add _
    _ ≤ ‖avalancheMatrixRow M 0‖ * ‖x‖ + ‖avalancheMatrixRow M 1‖ * ‖x‖ :=
      add_le_add ((avalancheMatrixRow M 0).le_opNorm x)
        ((avalancheMatrixRow M 1).le_opNorm x)
    _ = _ := by ring

theorem avalancheMatrixRow_mul (M N : TransferMatrix) (i : Fin 2) :
    avalancheMatrixRow (M * N) i =
      M i 0 • avalancheMatrixRow N 0 + M i 1 • avalancheMatrixRow N 1 := by
  ext x
  simp [avalancheMatrixRow_apply, Matrix.mul_apply, Fin.sum_univ_two]
  ring

@[simp] theorem avalancheMatrixRow_step_zero (δ : ℝ) (R M : TransferMatrix) :
    avalancheMatrixRow (avalancheDiagonal δ * R * M) 0 =
      R 0 0 • avalancheMatrixRow M 0 + R 0 1 • avalancheMatrixRow M 1 := by
  rw [avalancheMatrixRow_mul]
  simp [avalancheDiagonal, Matrix.mul_apply, Fin.sum_univ_two]

@[simp] theorem avalancheMatrixRow_step_one (δ : ℝ) (R M : TransferMatrix) :
    avalancheMatrixRow (avalancheDiagonal δ * R * M) 1 =
      (δ : ℂ) • (R 1 0 • avalancheMatrixRow M 0 + R 1 1 • avalancheMatrixRow M 1) := by
  rw [avalancheMatrixRow_mul]
  have h10 : (avalancheDiagonal δ * R) 1 0 = (δ : ℂ) * R 1 0 := by
    simp [avalancheDiagonal, Matrix.mul_apply, Fin.sum_univ_two]
  have h11 : (avalancheDiagonal δ * R) 1 1 = (δ : ℂ) * R 1 1 := by
    simp [avalancheDiagonal, Matrix.mul_apply, Fin.sum_univ_two]
  rw [h10, h11, smul_add, MulAction.mul_smul, MulAction.mul_smul]

theorem avalanche_norm_log_row_error {t : ℝ} {M : TransferMatrix}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (hf : avalancheMatrixRow M 0 ≠ 0)
    (hg : ‖avalancheMatrixRow M 1‖ ≤ 8 * t ^ 3 * ‖avalancheMatrixRow M 0‖) :
    |Real.log (transferNorm M) - Real.log ‖avalancheMatrixRow M 0‖| ≤ 16 * t ^ 2 := by
  have hf0 : 0 < ‖avalancheMatrixRow M 0‖ := norm_pos_iff.mpr hf
  have ht1 : t ≤ 1 := by linarith
  have hc := mul_le_mul_of_nonneg_left ht1 (show 0 ≤ 8 * t ^ 2 by positivity)
  have hr : 8 * t ^ 3 ≤ 8 * t ^ 2 := by nlinarith
  have hε : 8 * t ^ 2 ≤ 1 / 2 := by
    have := (avalanche_small_parameter ht ht').2.2.2
    nlinarith [sq_nonneg t]
  have hlo := avalanche_row_norm_le M 0
  have hhi := avalanche_norm_le_rows M
  have hr' := mul_le_mul_of_nonneg_right hr (norm_nonneg (avalancheMatrixRow M 0))
  have hlog := avalanche_abs_log_sub_log_le hf0 (show 0 ≤ 8 * t ^ 2 by positivity) hε
    (show (1 - 8 * t ^ 2) * ‖avalancheMatrixRow M 0‖ ≤ transferNorm M by nlinarith)
    (show transferNorm M ≤ (1 + 8 * t ^ 2) * ‖avalancheMatrixRow M 0‖ by nlinarith)
  convert hlog using 1
  ring

theorem avalanche_matrix_step {t δ : ℝ} {R M : TransferMatrix}
    (ht : 0 < t) (ht' : t ≤ 1 / 100)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ t ^ 4)
    (hR : R ∈ Matrix.unitaryGroup (Fin 2) ℂ)
    (ha : t / 2 ≤ ‖R 0 0‖)
    (hf : avalancheMatrixRow M 0 ≠ 0)
    (hg : ‖avalancheMatrixRow M 1‖ ≤ 8 * t ^ 3 * ‖avalancheMatrixRow M 0‖) :
    avalancheMatrixRow (avalancheDiagonal δ * R * M) 0 ≠ 0 ∧
      ‖avalancheMatrixRow (avalancheDiagonal δ * R * M) 1‖ ≤
        8 * t ^ 3 * ‖avalancheMatrixRow (avalancheDiagonal δ * R * M) 0‖ := by
  have hb := entry_norm_bound_of_unitary hR 0 1
  rw [avalancheMatrixRow_step_zero, avalancheMatrixRow_step_one]
  constructor
  · have hlo := (avalanche_large_row_bounds (a := R 0 0) hb hg).1
    have hr := (avalanche_small_parameter ht ht').2.1
    have hp : 0 < (‖R 0 0‖ - 8 * t ^ 3) * ‖avalancheMatrixRow M 0‖ :=
      mul_pos (by linarith) (norm_pos_iff.mpr hf)
    exact norm_pos_iff.mp (hp.trans_le hlo)
  · exact avalanche_row_contraction ht ht' hδ hδ' ha hb
      (entry_norm_bound_of_unitary hR 1 0) (entry_norm_bound_of_unitary hR 1 1) hg

end UAMO.BourgainJitomirskaya

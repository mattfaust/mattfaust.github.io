import UAMO.CMVTransferDetGrowthComparison
import Mathlib.LinearAlgebra.Matrix.PosDef

noncomputable section

namespace UAMO.BourgainJitomirskaya
open UAMO.CMV

open Matrix
open scoped Matrix Matrix.L2OpNorm

theorem transferNorm_diagonal (a b : ℂ) :
    transferNorm (Matrix.diagonal ![a, b]) = max ‖a‖ ‖b‖ := by
  apply le_antisymm
  · unfold transferNorm
    have hmax : 0 ≤ max ‖a‖ ‖b‖ := (norm_nonneg a).trans (le_max_left _ _)
    apply ContinuousLinearMap.opNorm_le_bound _ hmax
    intro x
    apply (sq_le_sq₀ (norm_nonneg _) (mul_nonneg hmax (norm_nonneg x))).mp
    rw [PiLp.norm_sq_eq_of_L2, mul_pow, PiLp.norm_sq_eq_of_L2, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i _
    have hi : ‖![a, b] i‖ ≤ max ‖a‖ ‖b‖ := by
      fin_cases i
      · exact le_max_left _ _
      · exact le_max_right _ _
    have hx : (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ)
        (Matrix.diagonal ![a, b]) x) i = ![a, b] i * x i := by
      change (Matrix.diagonal ![a, b] *ᵥ (fun j => x j)) i = _
      exact Matrix.mulVec_diagonal ![a, b] (fun j => x j) i
    rw [hx, norm_mul, mul_pow]
    exact mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (norm_nonneg _) hi 2) (sq_nonneg _)
  · apply max_le
    · simpa using transferNorm_entry_le (Matrix.diagonal ![a, b]) 0 0
    · simpa using transferNorm_entry_le (Matrix.diagonal ![a, b]) 1 1

def avalancheSVDSwap : Matrix.unitaryGroup (Fin 2) ℂ :=
  ⟨!![0, 1; 1, 0], by
    apply Matrix.mem_unitaryGroup_iff'.mpr
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [Matrix.mul_apply, Matrix.star_apply, Fin.sum_univ_two]⟩

theorem avalancheSVDSwap_diagonal (a b : ℂ) :
    star (avalancheSVDSwap : TransferMatrix) * Matrix.diagonal ![a, b] *
      (avalancheSVDSwap : TransferMatrix) = Matrix.diagonal ![b, a] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [avalancheSVDSwap, Matrix.mul_apply, Matrix.star_apply, Fin.sum_univ_two,
      Matrix.diagonal_apply]

theorem transferMatrix_gram_diagonalization (A : TransferMatrix) :
    ∃ (V : Matrix.unitaryGroup (Fin 2) ℂ) (a b : ℝ),
      0 ≤ b ∧ b ≤ a ∧
      star (V : TransferMatrix) * (star A * A) * (V : TransferMatrix) =
        Matrix.diagonal ![(a : ℂ), (b : ℂ)] := by
  let hG := Matrix.isHermitian_transpose_mul_self A
  let V := hG.eigenvectorUnitary
  let a := hG.eigenvalues 0
  let b := hG.eigenvalues 1
  have ha : 0 ≤ a := Matrix.eigenvalues_conjTranspose_mul_self_nonneg A 0
  have hb : 0 ≤ b := Matrix.eigenvalues_conjTranspose_mul_self_nonneg A 1
  have hdiag : star (V : TransferMatrix) * (star A * A) * (V : TransferMatrix) =
      Matrix.diagonal ![(a : ℂ), (b : ℂ)] := by
    convert hG.star_mul_self_mul_eq_diagonal using 1
    ext i
    fin_cases i <;> rfl
  by_cases hba : b ≤ a
  · exact ⟨V, a, b, hb, hba, hdiag⟩
  · refine ⟨V * avalancheSVDSwap, b, a, ha, (le_of_not_ge hba), ?_⟩
    change star ((V : TransferMatrix) * (avalancheSVDSwap : TransferMatrix)) *
      (star A * A) * ((V : TransferMatrix) * (avalancheSVDSwap : TransferMatrix)) = _
    rw [Matrix.star_mul]
    calc
      _ = star (avalancheSVDSwap : TransferMatrix) *
          (star (V : TransferMatrix) * (star A * A) * (V : TransferMatrix)) *
            (avalancheSVDSwap : TransferMatrix) := by simp only [mul_assoc]
      _ = _ := by rw [hdiag, avalancheSVDSwap_diagonal]

theorem transferMatrix_gram_singularValues (A : TransferMatrix) (hA : A.det = 1) :
    ∃ V : Matrix.unitaryGroup (Fin 2) ℂ,
      star (V : TransferMatrix) * (star A * A) * (V : TransferMatrix) =
        Matrix.diagonal ![((transferNorm A : ℂ) ^ 2), ((transferNorm A : ℂ)⁻¹ ^ 2)] := by
  obtain ⟨V, a, b, hb, hba, hdiag⟩ := transferMatrix_gram_diagonalization A
  have hG : star A * A = (V : TransferMatrix) *
      Matrix.diagonal ![(a : ℂ), (b : ℂ)] * star (V : TransferMatrix) := by
    calc
      _ = ((V : TransferMatrix) * star (V : TransferMatrix)) *
          (star A * A) * ((V : TransferMatrix) * star (V : TransferMatrix)) := by
        rw [(unitary.mul_star_self_of_mem V.prop), one_mul, mul_one]
      _ = (V : TransferMatrix) *
          (star (V : TransferMatrix) * (star A * A) * (V : TransferMatrix)) *
            star (V : TransferMatrix) := by simp only [mul_assoc]
      _ = _ := by rw [hdiag]
  have hnorm : ‖star A * A‖ = a := by
    rw [hG, ← unitary.coe_star, CStarRing.norm_mul_coe_unitary,
      CStarRing.norm_coe_unitary_mul]
    change transferNorm (Matrix.diagonal ![(a : ℂ), (b : ℂ)]) = a
    rw [transferNorm_diagonal]
    simp only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hb.trans hba),
      abs_of_nonneg hb, max_eq_left hba]
  have ha : a = (transferNorm A) ^ 2 := by
    rw [← hnorm, CStarRing.norm_star_mul_self]
    exact (pow_two _).symm
  have hprod : a * b = 1 := by
    have hd := congrArg Matrix.det hdiag
    rw [Matrix.det_mul_right_comm, (unitary.star_mul_self_of_mem V.prop), one_mul] at hd
    have hd' : (a : ℂ) * (b : ℂ) = 1 := by
      simpa [Matrix.det_mul, Matrix.star_eq_conjTranspose, Matrix.det_conjTranspose,
        hA, Matrix.det_diagonal, Fin.prod_univ_two] using hd.symm
    exact_mod_cast hd'
  have hpos : 0 < transferNorm A := zero_lt_one.trans_le
    (one_le_transferNorm_of_det_norm A (by rw [hA, norm_one]))
  have hsmall : b = ((transferNorm A)⁻¹) ^ 2 := by
    rw [ha] at hprod
    apply mul_left_cancel₀ (pow_ne_zero 2 hpos.ne')
    rw [hprod, ← mul_pow, mul_inv_cancel₀ hpos.ne', one_pow]
  refine ⟨V, ?_⟩
  simpa only [ha, hsmall, Complex.ofReal_pow, Complex.ofReal_inv] using hdiag

theorem transferMatrix_svd_diagonal (A : TransferMatrix) (hA : A.det = 1) :
    ∃ U V : Matrix.unitaryGroup (Fin 2) ℂ,
      A = (U : TransferMatrix) *
        Matrix.diagonal ![(transferNorm A : ℂ), ((transferNorm A : ℂ)⁻¹)] *
          star (V : TransferMatrix) := by
  obtain ⟨V, hgram⟩ := transferMatrix_gram_singularValues A hA
  let s : ℂ := (transferNorm A : ℂ)
  have hs : s ≠ 0 := Complex.ofReal_ne_zero.mpr
    (ne_of_gt (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm A (by rw [hA, norm_one]))))
  let D : TransferMatrix := Matrix.diagonal ![s, s⁻¹]
  let Q : TransferMatrix := Matrix.diagonal ![s⁻¹, s]
  have hQ : star Q = Q := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [Q, s, Matrix.star_apply, Matrix.diagonal_apply]
  have hQD : Q * D = 1 := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [Q, D, Matrix.diagonal_mul_diagonal, Matrix.diagonal_apply, hs]
  let U₀ : TransferMatrix := A * (V : TransferMatrix) * Q
  have hU : U₀ ∈ Matrix.unitaryGroup (Fin 2) ℂ := by
    apply Matrix.mem_unitaryGroup_iff'.mpr
    calc
      star U₀ * U₀ = Q *
          (star (V : TransferMatrix) * (star A * A) * (V : TransferMatrix)) * Q := by
        simp only [U₀, Matrix.star_mul, hQ, mul_assoc]
      _ = Q * Matrix.diagonal ![s ^ 2, s⁻¹ ^ 2] * Q := by rw [hgram]
      _ = 1 := by
        ext i j
        fin_cases i <;> fin_cases j <;>
          simp [Q, Matrix.diagonal_mul_diagonal, Matrix.diagonal_apply] <;> field_simp <;> ring
  refine ⟨⟨U₀, hU⟩, V, ?_⟩
  change A = (A * (V : TransferMatrix) * Q) * D * star (V : TransferMatrix)
  calc
    A = A * ((V : TransferMatrix) * star (V : TransferMatrix)) := by
      rw [(unitary.mul_star_self_of_mem V.prop), mul_one]
    _ = (A * (V : TransferMatrix)) * (Q * D) * star (V : TransferMatrix) := by
      rw [hQD, mul_one, mul_assoc]
    _ = _ := by simp only [mul_assoc]

theorem transferMatrix_svd (A : TransferMatrix) (hA : A.det = 1) :
    ∃ U V : Matrix.unitaryGroup (Fin 2) ℂ,
      A = (transferNorm A : ℂ) • ((U : TransferMatrix) *
        Matrix.diagonal ![(1 : ℂ), ((((transferNorm A)⁻¹) ^ 2 : ℝ) : ℂ)] *
          star (V : TransferMatrix)) := by
  obtain ⟨U, V, hUV⟩ := transferMatrix_svd_diagonal A hA
  have hs : (transferNorm A : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr
    (ne_of_gt (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm A (by rw [hA, norm_one]))))
  have hD : Matrix.diagonal ![(transferNorm A : ℂ), ((transferNorm A : ℂ)⁻¹)] =
      (transferNorm A : ℂ) •
        Matrix.diagonal ![(1 : ℂ), ((((transferNorm A)⁻¹) ^ 2 : ℝ) : ℂ)] := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [Matrix.diagonal_apply, Matrix.smul_apply, smul_eq_mul,
        Complex.ofReal_pow, Complex.ofReal_inv]
    field_simp
    ring
  refine ⟨U, V, ?_⟩
  calc
    A = (U : TransferMatrix) *
        Matrix.diagonal ![(transferNorm A : ℂ), ((transferNorm A : ℂ)⁻¹)] *
          star (V : TransferMatrix) := hUV
    _ = _ := by rw [hD, mul_smul_comm, smul_mul_assoc]

end UAMO.BourgainJitomirskaya

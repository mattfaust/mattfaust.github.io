import UAMO.BJFourierSmoothing
import Mathlib.Analysis.PSeries

noncomputable section

namespace UAMO.BourgainJitomirskaya

open MeasureTheory AddCircle
open scoped ENNReal

def fourierLpCut (f : Lp ℂ 2 (@haarAddCircle 1 inferInstance)) (s : Finset ℤ) :
    Lp ℂ 2 (@haarAddCircle 1 inferInstance) :=
  ∑ k ∈ s, fourierCoeff f k • fourierLp 2 k

theorem fourierLp_norm_sq_eq_tsum (f : Lp ℂ 2 (@haarAddCircle 1 inferInstance)) :
    ‖f‖ ^ 2 = ∑' k : ℤ, ‖fourierCoeff f k‖ ^ 2 := by
  simp_rw [← fourierBasis_repr]
  have h := lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num)
    (fourierBasis.repr f)
  simpa using h

theorem summable_sq_fourierCoeff (f : Lp ℂ 2 (@haarAddCircle 1 inferInstance)) :
    Summable (fun k : ℤ => ‖fourierCoeff f k‖ ^ 2) := by
  have h := (lp.memℓp (fourierBasis.repr f)).summable
    (show 0 < (2 : ENNReal).toReal by norm_num)
  simpa only [ENNReal.toReal_ofNat, Real.rpow_two, fourierBasis_repr] using h

theorem fourierCoeff_fourierLpCut (f : Lp ℂ 2 (@haarAddCircle 1 inferInstance))
    (s : Finset ℤ) (k : ℤ) :
    fourierCoeff (fourierLpCut f s) k = if k ∈ s then fourierCoeff f k else 0 := by
  have hb (i : ℤ) : fourierBasis.repr (fourierLp (T := (1 : ℝ)) 2 i) =
      lp.single 2 i (1 : ℂ) := by
    simpa only [coe_fourierBasis] using
      HilbertBasis.repr_self (@fourierBasis (1 : ℝ) inferInstance) i
  rw [← fourierBasis_repr]
  simp only [fourierLpCut, map_sum, map_smul, hb,
    lp.coeFn_sum, Finset.sum_apply, lp.coeFn_smul, Pi.smul_apply,
    lp.single_apply, Pi.single_apply, smul_eq_mul]
  simp [Finset.sum_ite_eq', eq_comm]

theorem fourierCoeff_sub_fourierLpCut (f : Lp ℂ 2 (@haarAddCircle 1 inferInstance))
    (s : Finset ℤ) (k : ℤ) :
    fourierCoeff (f - fourierLpCut f s) k = if k ∈ s then 0 else fourierCoeff f k := by
  rw [← fourierBasis_repr, map_sub]
  simp only [lp.coeFn_sub, Pi.sub_apply, fourierBasis_repr, fourierCoeff_fourierLpCut]
  split_ifs <;> simp

private theorem nat_inverse_square_tail (K : ℕ) :
    Summable (fun n : ℕ => if K < n then ((n : ℝ) ^ 2)⁻¹ else 0) ∧
      (∑' n : ℕ, if K < n then ((n : ℝ) ^ 2)⁻¹ else 0) ≤ 2 / ((K : ℝ) + 1) := by
  have hnonneg (n : ℕ) : 0 ≤ if K < n then ((n : ℝ) ^ 2)⁻¹ else 0 := by
    split_ifs <;> positivity
  have hsum (N : ℕ) :
      (∑ n ∈ Finset.range N, if K < n then ((n : ℝ) ^ 2)⁻¹ else 0) ≤
        2 / ((K : ℝ) + 1) := by
    have hs : (Finset.range N).filter (fun n => K < n) = Finset.Ioo K N := by
      ext n
      simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_Ioo]
      tauto
    rw [← Finset.sum_filter, hs]
    exact sum_Ioo_inv_sq_le K N
  exact ⟨summable_of_sum_range_le hnonneg hsum, Real.tsum_le_of_sum_range_le hnonneg hsum⟩

private theorem int_inverse_square_tail (K : ℕ) :
    Summable (fun k : ℤ => if k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) then 0
      else ((k : ℝ) ^ 2)⁻¹) ∧
      (∑' k : ℤ, if k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) then 0
        else ((k : ℝ) ^ 2)⁻¹) ≤ 4 / ((K : ℝ) + 1) := by
  let g : ℤ → ℝ := fun k => if k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) then 0
    else ((k : ℝ) ^ 2)⁻¹
  have hp (n : ℕ) : g (n : ℤ) = if K < n then ((n : ℝ) ^ 2)⁻¹ else 0 := by
    by_cases hn : K < n
    · have hm : (n : ℤ) ∉ Finset.Icc (-(K : ℤ)) (K : ℤ) := by
        simp only [Finset.mem_Icc]; omega
      simp [g, hn, hm]
    · have hm : (n : ℤ) ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) := by
        simp only [Finset.mem_Icc]; omega
      simp [g, hn, hm]
  have hn (n : ℕ) : g (-(n : ℤ)) = if K < n then ((n : ℝ) ^ 2)⁻¹ else 0 := by
    have hm : (-(n : ℤ) ∈ Finset.Icc (-(K : ℤ)) (K : ℤ)) ↔
        ((n : ℤ) ∈ Finset.Icc (-(K : ℤ)) (K : ℤ)) := by
      simp only [Finset.mem_Icc]
      omega
    simpa only [g, hm, Int.cast_neg, neg_sq] using hp n
  obtain ⟨hNat, hbound⟩ := nat_inverse_square_tail K
  have hpSum : Summable (fun n : ℕ => g (n : ℤ)) := hNat.congr fun n => (hp n).symm
  have hnSum : Summable (fun n : ℕ => g (-(n : ℤ))) := hNat.congr fun n => (hn n).symm
  refine ⟨hpSum.of_nat_of_neg hnSum, ?_⟩
  change (∑' k, g k) ≤ _
  rw [hpSum.tsum_of_nat_of_neg hnSum]
  simp_rw [hp, hn]
  have hz : g 0 = 0 := by simp [g]
  rw [hz, sub_zero]
  calc
    _ ≤ 2 / ((K : ℝ) + 1) + 2 / ((K : ℝ) + 1) := add_le_add hbound hbound
    _ = _ := by ring

theorem norm_sub_fourierLpCut_sq_le (f : Lp ℂ 2 (@haarAddCircle 1 inferInstance))
    (C : ℝ) (K : ℕ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ C / |(k : ℝ)|) :
    ‖f - fourierLpCut f (Finset.Icc (-(K : ℤ)) (K : ℤ))‖ ^ 2 ≤
      4 * C ^ 2 / ((K : ℝ) + 1) := by
  obtain ⟨hseries, hbound⟩ := int_inverse_square_tail K
  have hpoint (k : ℤ) :
      ‖fourierCoeff (f - fourierLpCut f (Finset.Icc (-(K : ℤ)) (K : ℤ))) k‖ ^ 2 ≤
        C ^ 2 * (if k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) then 0 else ((k : ℝ) ^ 2)⁻¹) := by
    rw [fourierCoeff_sub_fourierLpCut]
    by_cases hk : k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ)
    · simp [hk]
    · simp only [hk, if_false]
      have hk0 : k ≠ 0 := by intro h; subst k; simp at hk
      have h := pow_le_pow_left₀ (norm_nonneg _) (hcoeff k hk0) 2
      simpa only [div_pow, sq_abs, div_eq_mul_inv, mul_pow, inv_pow] using h
  rw [fourierLp_norm_sq_eq_tsum]
  calc
    _ ≤ ∑' k : ℤ, C ^ 2 *
        (if k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) then 0 else ((k : ℝ) ^ 2)⁻¹) :=
      Summable.tsum_le_tsum hpoint (summable_sq_fourierCoeff _) (hseries.mul_left _)
    _ = C ^ 2 * ∑' k : ℤ,
        (if k ∈ Finset.Icc (-(K : ℤ)) (K : ℤ) then 0 else ((k : ℝ) ^ 2)⁻¹) := tsum_mul_left
    _ ≤ C ^ 2 * (4 / ((K : ℝ) + 1)) := mul_le_mul_of_nonneg_left hbound (sq_nonneg C)
    _ = _ := by ring

def fourierContinuousCut (f : C(AddCircle (1 : ℝ), ℂ)) (s : Finset ℤ) :
    C(AddCircle (1 : ℝ), ℂ) := ∑ k ∈ s, fourierCoeff f k • fourier k

theorem toLp_fourierContinuousCut (f : C(AddCircle (1 : ℝ), ℂ)) (s : Finset ℤ) :
    ContinuousMap.toLp 2 haarAddCircle ℂ (fourierContinuousCut f s) =
      fourierLpCut (ContinuousMap.toLp 2 haarAddCircle ℂ f) s := by
  simp only [fourierContinuousCut, map_sum, map_smul, fourierLpCut, fourierCoeff_toLp,
    fourierLp]

theorem norm_toLp_sub_fourierContinuousCut_sq_le (f : C(AddCircle (1 : ℝ), ℂ))
    (C : ℝ) (K : ℕ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ C / |(k : ℝ)|) :
    ‖ContinuousMap.toLp 2 haarAddCircle ℂ
      (f - fourierContinuousCut f (Finset.Icc (-(K : ℤ)) (K : ℤ)))‖ ^ 2 ≤
      4 * C ^ 2 / ((K : ℝ) + 1) := by
  rw [map_sub, toLp_fourierContinuousCut]
  exact norm_sub_fourierLpCut_sq_le _ C K (by simpa only [fourierCoeff_toLp] using hcoeff)

theorem integral_norm_sub_fourierContinuousCut_sq_le (f : C(AddCircle (1 : ℝ), ℂ))
    (C : ℝ) (K : ℕ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ C / |(k : ℝ)|) :
    (∫ x : AddCircle (1 : ℝ),
      ‖f x - fourierContinuousCut f (Finset.Icc (-(K : ℤ)) (K : ℤ)) x‖ ^ 2 ∂haarAddCircle) ≤
      4 * C ^ 2 / ((K : ℝ) + 1) := by
  have h := norm_toLp_sub_fourierContinuousCut_sq_le f C K hcoeff
  have heq : ‖ContinuousMap.toLp 2 haarAddCircle ℂ
      (f - fourierContinuousCut f (Finset.Icc (-(K : ℤ)) (K : ℤ)))‖ ^ 2 =
      ∫ x : AddCircle (1 : ℝ),
        ‖f x - fourierContinuousCut f (Finset.Icc (-(K : ℤ)) (K : ℤ)) x‖ ^ 2 ∂haarAddCircle := by
    rw [fourierLp_norm_sq_eq_tsum, tsum_sq_fourierCoeff]
    apply integral_congr_ae
    filter_upwards [(f - fourierContinuousCut f (Finset.Icc (-(K : ℤ)) (K : ℤ))).coeFn_toLp
      (p := 2) (𝕜 := ℂ) haarAddCircle] with x hx
    rw [hx]
    rfl
  rwa [heq] at h

theorem integral_norm_fourierOrbitAverage_sub_cut_sq_le
    (f : C(AddCircle (1 : ℝ), ℂ)) (R : ℕ) (hR : 0 < R) (α : AddCircle (1 : ℝ))
    (C : ℝ) (K : ℕ)
    (hcoeff : ∀ k : ℤ, k ≠ 0 → ‖fourierCoeff f k‖ ≤ C / |(k : ℝ)|) :
    (∫ x : AddCircle (1 : ℝ),
      ‖fourierOrbitAverage f R α x -
        fourierContinuousCut (fourierOrbitAverage f R α)
          (Finset.Icc (-(K : ℤ)) (K : ℤ)) x‖ ^ 2 ∂haarAddCircle) ≤
      4 * C ^ 2 / ((K : ℝ) + 1) := by
  apply integral_norm_sub_fourierContinuousCut_sq_le
  intro k hk
  exact (norm_fourierCoeff_fourierOrbitAverage_le f R hR α k).trans (hcoeff k hk)

end UAMO.BourgainJitomirskaya

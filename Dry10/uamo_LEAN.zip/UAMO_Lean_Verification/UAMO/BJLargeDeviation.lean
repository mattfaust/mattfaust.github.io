import UAMO.BJDeviationParameters
import UAMO.BJFourierDeviation
import UAMO.BJRotationKernelBounds

noncomputable section
namespace UAMO.BourgainJitomirskaya
open MeasureTheory

local instance largeDeviationCirclePeriod : Fact (0<(1:ℝ)) := ⟨by norm_num⟩

theorem fourier_largeDeviation {B κ : ℝ}
    (hB : 0<B) (hκ : 0<κ) (hκ1 : κ≤1) :
    ∃C c:ℝ,0<C ∧ 0<c ∧ ∃Q:ℕ,8≤Q ∧
      ∀(f:C(AddCircle (1:ℝ),ℂ))(α:ℝ)(p:ℤ)(q n:ℕ),Q≤q →
        IsCoprime p (q:ℤ) → |α-(p:ℝ)/(q:ℝ)|<1/(q:ℝ)^2 →
        (∀k:ℤ,k≠0 → ‖fourierCoeff f k‖≤1/|(k:ℝ)|) →
        (∀x,‖f (x+(α:AddCircle (1:ℝ)))-f x‖≤B/(n:ℝ)) →
        C*(q:ℝ)≤n →
        AddCircle.haarAddCircle.real {x:AddCircle (1:ℝ)|κ<‖f x-fourierCoeff f 0‖}≤
          Real.exp (-c*q) := by
  obtain ⟨C,c,hC,hc,Q,hQ,hcut⟩ := exists_deviation_cutoff_parameters hB hκ hκ1
  refine ⟨C,c,hC,hc,Q,hQ,?_⟩
  intro f α p q n hq hcop happrox hcoeff hshift hn
  have hq8 := hQ.trans hq
  obtain ⟨R,K,hRq,hK,hlow,hsmall,htail⟩ := hcut q hq
  have hR : 0<R := (show 0<q by omega).trans_le hRq
  have hsmooth : (R:ℝ)*(B/(n:ℝ))≤κ/4 := by
    simpa only [mul_div_assoc] using hsmall n hn
  have hlow' : (∑k∈(Finset.Icc (-(K:ℤ)) (K:ℤ)).erase 0,
      (1/|(k:ℝ)|)*fourierOrbitMultiplier R (α:AddCircle (1:ℝ)) k)≤κ/4 :=
    (rationalApprox_sum_weighted_multiplier hq8 hcop happrox R hRq K hK).trans hlow
  exact (fourier_deviation_measure_le f R hR (α:AddCircle (1:ℝ)) K (B/(n:ℝ)) κ hκ
    hcoeff hshift hsmooth hlow').trans htail

theorem fourier_largeDeviation_two {B κ : ℝ}
    (hB : 0<B) (hκ : 0<κ) (hκ1 : κ≤1) :
    ∃C c:ℝ,0<C ∧ 0<c ∧ ∃Q:ℕ,8≤Q ∧
      ∀(f:C(AddCircle (1:ℝ),ℂ))(α:ℝ)(p:ℤ)(q n:ℕ),Q≤q →
        IsCoprime p (q:ℤ) → |α-(p:ℝ)/(q:ℝ)|<1/(q:ℝ)^2 →
        (∀k:ℤ,k≠0 → ‖fourierCoeff f k‖≤2/|(k:ℝ)|) →
        (∀x,‖f (x+(α:AddCircle (1:ℝ)))-f x‖≤B/(n:ℝ)) →
        C*(q:ℝ)≤n →
        AddCircle.haarAddCircle.real {x:AddCircle (1:ℝ)|κ<‖f x-fourierCoeff f 0‖}≤
          Real.exp (-c*q) := by
  obtain ⟨C,c,hC,hc,Q,hQ,hldt⟩ := fourier_largeDeviation (half_pos hB) (half_pos hκ)
    (by linarith : κ/2≤1)
  refine ⟨C,c,hC,hc,Q,hQ,?_⟩
  intro f α p q n hq hcop happrox hcoeff hshift hn
  let g : C(AddCircle (1:ℝ),ℂ) := (1/2:ℂ) • f
  have hgc (k:ℤ) : fourierCoeff g k=(1/2:ℂ)*fourierCoeff f k := by
    exact fourierCoeff.const_smul f (1/2:ℂ) k
  have hgn (x y:AddCircle (1:ℝ)) : ‖g x-g y‖=‖f x-f y‖/2 := by
    change ‖(1/2:ℂ)*f x-(1/2:ℂ)*f y‖=_
    rw [← mul_sub,norm_mul]
    norm_num
    ring
  have hcoeff' (k:ℤ) (hk:k≠0) : ‖fourierCoeff g k‖≤1/|(k:ℝ)| := by
    rw [hgc,norm_mul]
    norm_num
    have h := mul_le_mul_of_nonneg_left (hcoeff k hk) (by norm_num : (0:ℝ)≤2⁻¹)
    convert h using 1 <;> ring
  have hshift' (x:AddCircle (1:ℝ)) : ‖g (x+(α:AddCircle (1:ℝ)))-g x‖≤(B/2)/(n:ℝ) := by
    rw [hgn]
    convert div_le_div_of_nonneg_right (hshift x) (by norm_num : (0:ℝ)≤2) using 1
    ring
  have h := hldt g α p q n hq hcop happrox hcoeff' hshift' hn
  have heq : {x:AddCircle (1:ℝ)|κ/2<‖g x-fourierCoeff g 0‖}=
      {x:AddCircle (1:ℝ)|κ<‖f x-fourierCoeff f 0‖} := by
    ext x
    rw [Set.mem_setOf_eq,Set.mem_setOf_eq,hgc]
    change κ/2<‖(1/2:ℂ)*f x-(1/2:ℂ)*fourierCoeff f 0‖ ↔ _
    rw [← mul_sub,norm_mul]
    norm_num
    constructor <;> intro hh <;> linarith
  rwa [heq] at h

end UAMO.BourgainJitomirskaya

import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

noncomputable section

namespace UAMO.BourgainJitomirskaya

open MeasureTheory AddCircle Set Polynomial
open scoped ENNReal

def phaseBadSet (f : AddCircle (1 : ℝ) → ℝ) (c κ : ℝ) : Set (AddCircle (1 : ℝ)) :=
  {x | κ < |f x - c|}

def phaseBadHull (s : Set (AddCircle (1 : ℝ))) (δ : ℝ) : Set (AddCircle (1 : ℝ)) :=
  {x | ∃ t : ℝ, |t| ≤ δ ∧ x + (t : AddCircle (1 : ℝ)) ∈ s}

theorem isOpen_phaseBadSet {f : AddCircle (1 : ℝ) → ℝ} (hf : Continuous f)
    (c κ : ℝ) : IsOpen (phaseBadSet f c κ) :=
  isOpen_lt continuous_const (hf.sub continuous_const).abs

theorem isOpen_phaseBadHull {s : Set (AddCircle (1 : ℝ))} (hs : IsOpen s) (δ : ℝ) :
    IsOpen (phaseBadHull s δ) := by
  have heq : phaseBadHull s δ =
      ⋃ t : ℝ, ⋃ (_ : |t| ≤ δ), (fun x : AddCircle (1 : ℝ) => x + (t : AddCircle (1 : ℝ))) ⁻¹' s := by
    ext x
    simp [phaseBadHull]
  rw [heq]
  exact isOpen_iUnion fun t => isOpen_iUnion fun _ =>
    hs.preimage (continuous_id.add continuous_const)

theorem phaseBadHull_subset_bad_union_threshold_balls
    {f : AddCircle (1 : ℝ) → ℝ} (hf : Continuous f) (c κ δ : ℝ)
    (S : Finset (AddCircle (1 : ℝ)))
    (hS : ∀ y, |f y - c| = κ → y ∈ S) :
    phaseBadHull (phaseBadSet f c κ) δ ⊆
      phaseBadSet f c κ ∪ ⋃ y ∈ S, Metric.closedBall y δ := by
  intro x hx
  by_cases hxb : x ∈ phaseBadSet f c κ
  · exact Or.inl hxb
  right
  obtain ⟨s, hs, hxs⟩ := hx
  have hxle : |f x - c| ≤ κ := le_of_not_gt hxb
  have hxsle : κ ≤ |f (x + (s : AddCircle (1 : ℝ))) - c| := le_of_lt hxs
  let g : ℝ → ℝ := fun t => |f (x + (t : AddCircle (1 : ℝ))) - c|
  have hg : Continuous g :=
    ((hf.comp (continuous_const.add QuotientAddGroup.continuous_mk)).sub continuous_const).abs
  have h0 : g 0 ≤ κ := by simpa [g] using hxle
  obtain ⟨t, ht, hgt⟩ := intermediate_value_uIcc hg.continuousOn
    (Set.mem_uIcc.mpr (Or.inl ⟨h0, hxsle⟩))
  have htδ : |t| ≤ δ := by
    obtain ⟨hs₁, hs₂⟩ := abs_le.mp hs
    rcases Set.mem_uIcc.mp ht with ht | ht <;> apply abs_le.mpr <;> constructor <;> linarith
  refine Set.mem_iUnion.mpr ⟨x + (t : AddCircle (1 : ℝ)), Set.mem_iUnion.mpr ⟨hS _ hgt, ?_⟩⟩
  have hnorm : ‖(t : AddCircle (1 : ℝ))‖ ≤ |t| :=
    QuotientAddGroup.norm_mk_le_norm
  simpa only [Metric.mem_closedBall, dist_eq_norm, sub_add_cancel_left, norm_neg] using
    hnorm.trans htδ

theorem haarAddCircle_closedBall_le (y : AddCircle (1 : ℝ)) (δ : ℝ) :
    haarAddCircle (Metric.closedBall y δ) ≤ ENNReal.ofReal (2 * δ) := by
  have hv : (volume : Measure (AddCircle (1 : ℝ))) = haarAddCircle := by
    simpa using (volume_eq_smul_haarAddCircle (T := (1 : ℝ)))
  rw [← hv, AddCircle.volume_closedBall]
  exact ENNReal.ofReal_le_ofReal (min_le_right _ _)

theorem measure_phaseBadHull_le_of_threshold_finset
    {f : AddCircle (1 : ℝ) → ℝ} (hf : Continuous f) (c κ δ : ℝ)
    (S : Finset (AddCircle (1 : ℝ)))
    (hS : ∀ y, |f y - c| = κ → y ∈ S) :
    haarAddCircle (phaseBadHull (phaseBadSet f c κ) δ) ≤
      haarAddCircle (phaseBadSet f c κ) + ENNReal.ofReal (2 * (S.card : ℝ) * δ) := by
  calc
    _ ≤ haarAddCircle (phaseBadSet f c κ ∪ ⋃ y ∈ S, Metric.closedBall y δ) :=
      measure_mono (phaseBadHull_subset_bad_union_threshold_balls hf c κ δ S hS)
    _ ≤ haarAddCircle (phaseBadSet f c κ) +
        haarAddCircle (⋃ y ∈ S, Metric.closedBall y δ) := measure_union_le _ _
    _ ≤ haarAddCircle (phaseBadSet f c κ) + ∑ y ∈ S, haarAddCircle (Metric.closedBall y δ) :=
      add_le_add_left (measure_biUnion_finset_le S _) _
    _ ≤ haarAddCircle (phaseBadSet f c κ) + ∑ _y ∈ S, ENNReal.ofReal (2 * δ) :=
      add_le_add_left (Finset.sum_le_sum fun y _ => haarAddCircle_closedBall_le y δ) _
    _ = _ := by
      simp only [Finset.sum_const, nsmul_eq_mul]
      rw [← ENNReal.ofReal_natCast, ← ENNReal.ofReal_mul (Nat.cast_nonneg _)]
      congr 2
      ring

def phasePolynomialLog (P : Polynomial ℂ) (x : AddCircle (1 : ℝ)) : ℝ :=
  Real.log ‖P.eval (_root_.fourier 1 x)‖

theorem continuous_phasePolynomialLog (P : Polynomial ℂ)
    (hP : ∀ w : ℂ, ‖w‖ = 1 → P.eval w ≠ 0) : Continuous (phasePolynomialLog P) :=
  (P.continuous.comp (_root_.fourier 1).continuous).norm.log
    (fun x => norm_ne_zero_iff.mpr (hP (_root_.fourier 1 x) (Circle.norm_coe _)))

theorem phase_reflect_natDegree_le (P : Polynomial ℂ) (D : ℕ)
    (hP : P.natDegree ≤ D) : (Polynomial.reflect D P).natDegree ≤ D := by
  apply Polynomial.natDegree_le_iff_coeff_eq_zero.mpr
  intro j hj
  rw [Polynomial.coeff_reflect, Polynomial.revAt_eq_self_of_lt hj]
  exact Polynomial.coeff_eq_zero_of_natDegree_lt (hP.trans_lt hj)

theorem phase_reflect_eval (P : Polynomial ℂ) {D : ℕ} (hP : P.natDegree ≤ D)
    {w : ℂ} (hw : ‖w‖ = 1) :
    (Polynomial.reflect D (P.map (starRingEnd ℂ))).eval w = w ^ D * star (P.eval w) := by
  have hw0 : w ≠ 0 := by intro h; simp [h] at hw
  have hconj : star w = w⁻¹ := by
    rw [Complex.inv_def, Complex.normSq_eq_norm_sq, hw]
    simp
  have heval : (P.map (starRingEnd ℂ)).eval (w⁻¹) = star (P.eval w) := by
    rw [← hconj, Polynomial.eval_map]
    exact Polynomial.eval₂_hom (starRingEnd ℂ) w
  letI : Invertible (w⁻¹) := invertibleOfNonzero (inv_ne_zero hw0)
  have hreflect := Polynomial.eval₂_reflect_mul_pow (RingHom.id ℂ) (w⁻¹) D
    (P.map (starRingEnd ℂ)) (Polynomial.natDegree_map_le.trans hP)
  simp only [invOf_eq_inv, inv_inv] at hreflect
  change (Polynomial.reflect D (P.map (starRingEnd ℂ))).eval w * (w⁻¹) ^ D =
    (P.map (starRingEnd ℂ)).eval (w⁻¹) at hreflect
  rw [heval] at hreflect
  apply mul_right_cancel₀ (pow_ne_zero D (inv_ne_zero hw0))
  calc
    _ = star (P.eval w) := hreflect
    _ = star (P.eval w) * (w * w⁻¹) ^ D := by
      rw [mul_inv_cancel₀ hw0, one_pow, mul_one]
    _ = _ := by rw [mul_pow]; ring

theorem phase_fourier_one_injective :
    Function.Injective (fun x : AddCircle (1 : ℝ) => (_root_.fourier 1 x : ℂ)) := by
  intro x y h
  dsimp only at h
  rw [_root_.fourier_one, _root_.fourier_one, Subtype.coe_inj] at h
  exact AddCircle.injective_toCircle one_ne_zero h

@[simp] theorem phaseBadHull_empty (δ : ℝ) :
    phaseBadHull (∅ : Set (AddCircle (1 : ℝ))) δ = ∅ := by
  ext x
  simp [phaseBadHull]

end UAMO.BourgainJitomirskaya

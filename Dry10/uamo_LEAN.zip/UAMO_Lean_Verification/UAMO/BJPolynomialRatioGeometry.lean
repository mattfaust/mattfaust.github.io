import UAMO.BJPhaseBadSetGeometry

noncomputable section
namespace UAMO.BourgainJitomirskaya
open MeasureTheory AddCircle Set Polynomial
open scoped ENNReal

def phasePolynomialRatioLog (P Q : Polynomial ℂ) (x : AddCircle (1:ℝ)) : ℝ :=
  phasePolynomialLog P x-phasePolynomialLog Q x

theorem continuous_phasePolynomialRatioLog (P Q : Polynomial ℂ)
    (hP : ∀w:ℂ,‖w‖=1 → P.eval w≠0) (hQ : ∀w:ℂ,‖w‖=1 → Q.eval w≠0) :
    Continuous (phasePolynomialRatioLog P Q) :=
  (continuous_phasePolynomialLog P hP).sub (continuous_phasePolynomialLog Q hQ)

def phaseRatioLevelPolynomial (P Q : Polynomial ℂ) (a : ℝ) : Polynomial ℂ :=
  P*Polynomial.reflect (max P.natDegree Q.natDegree) (P.map (starRingEnd ℂ))-
  C (Real.exp (2*a):ℂ)*(Q*Polynomial.reflect (max P.natDegree Q.natDegree) (Q.map (starRingEnd ℂ)))

theorem phaseRatioLevelPolynomial_natDegree_le (P Q : Polynomial ℂ) (a:ℝ) :
    (phaseRatioLevelPolynomial P Q a).natDegree≤2*max P.natDegree Q.natDegree := by
  apply (Polynomial.natDegree_sub_le _ _).trans
  apply max_le
  · exact (Polynomial.natDegree_mul_le_of_le (le_max_left P.natDegree Q.natDegree)
      (phase_reflect_natDegree_le _ (max P.natDegree Q.natDegree)
        (Polynomial.natDegree_map_le.trans (le_max_left P.natDegree Q.natDegree)))).trans (by omega)
  · apply (Polynomial.natDegree_C_mul_le _ _).trans
    exact (Polynomial.natDegree_mul_le_of_le (le_max_right P.natDegree Q.natDegree)
      (phase_reflect_natDegree_le _ (max P.natDegree Q.natDegree)
        (Polynomial.natDegree_map_le.trans (le_max_right P.natDegree Q.natDegree)))).trans (by omega)

theorem phaseRatioLevelPolynomial_eval (P Q : Polynomial ℂ) (a:ℝ) {w:ℂ} (hw:‖w‖=1) :
    (phaseRatioLevelPolynomial P Q a).eval w=
      w^(max P.natDegree Q.natDegree)*
        (((‖P.eval w‖^2:ℝ):ℂ)-(Real.exp (2*a):ℂ)*((‖Q.eval w‖^2:ℝ):ℂ)) := by
  simp only [phaseRatioLevelPolynomial,Polynomial.eval_sub,Polynomial.eval_mul,Polynomial.eval_C,
    phase_reflect_eval P (le_max_left _ _) hw,phase_reflect_eval Q (le_max_right _ _) hw]
  have hp : P.eval w*star (P.eval w)=((‖P.eval w‖^2:ℝ):ℂ) := by
    rw [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq]
  have hq : Q.eval w*star (Q.eval w)=((‖Q.eval w‖^2:ℝ):ℂ) := by
    rw [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq]
  calc
    _=w^(max P.natDegree Q.natDegree)*(P.eval w*star (P.eval w)-
      (Real.exp (2*a):ℂ)*(Q.eval w*star (Q.eval w))) := by ring
    _=_ := by rw [hp,hq]

theorem phaseRatioLevelPolynomial_eval_eq_zero_iff (P Q : Polynomial ℂ) (a:ℝ)
    {w:ℂ} (hw:‖w‖=1) (hPw:P.eval w≠0) (hQw:Q.eval w≠0) :
    (phaseRatioLevelPolynomial P Q a).eval w=0 ↔
      Real.log ‖P.eval w‖-Real.log ‖Q.eval w‖=a := by
  have hw0 : w≠0 := by intro h; simp [h] at hw
  rw [phaseRatioLevelPolynomial_eval P Q a hw,mul_eq_zero,
    or_iff_right (pow_ne_zero _ hw0),sub_eq_zero]
  rw [← Complex.ofReal_mul,Complex.ofReal_inj]
  have hexp : Real.exp (2*a)*‖Q.eval w‖^2=(Real.exp a*‖Q.eval w‖)^2 := by
    rw [two_mul,Real.exp_add];ring
  rw [hexp,sq_eq_sq₀ (norm_nonneg _) (mul_nonneg (Real.exp_pos a).le (norm_nonneg _))]
  constructor
  · intro h
    rw [h,Real.log_mul (Real.exp_pos a).ne' (norm_ne_zero_iff.mpr hQw),Real.log_exp]
    ring
  · intro h
    have he := congrArg Real.exp h
    rw [Real.exp_sub,Real.exp_log (norm_pos_iff.mpr hPw),
      Real.exp_log (norm_pos_iff.mpr hQw)] at he
    exact (div_eq_iff (norm_ne_zero_iff.mpr hQw)).mp he

def phaseRatioLevelRoots (P Q : Polynomial ℂ) (a:ℝ) : Finset (AddCircle (1:ℝ)) :=
  (phaseRatioLevelPolynomial P Q a).roots.toFinset.preimage
    (fun x:AddCircle (1:ℝ) => (_root_.fourier 1 x:ℂ)) phase_fourier_one_injective.injOn

theorem phaseRatioLevelRoots_card_le (P Q : Polynomial ℂ) (a:ℝ) :
    (phaseRatioLevelRoots P Q a).card≤2*max P.natDegree Q.natDegree := by
  classical
  unfold phaseRatioLevelRoots
  rw [Finset.card_preimage]
  exact (Finset.card_filter_le _ _).trans ((Multiset.toFinset_card_le _).trans
    ((Polynomial.card_roots' _).trans (phaseRatioLevelPolynomial_natDegree_le P Q a)))

theorem mem_phaseRatioLevelRoots_iff (P Q : Polynomial ℂ) (a:ℝ)
    (hP:∀w:ℂ,‖w‖=1 → P.eval w≠0) (hQ:∀w:ℂ,‖w‖=1 → Q.eval w≠0)
    (hR:phaseRatioLevelPolynomial P Q a≠0) (x:AddCircle (1:ℝ)) :
    x∈phaseRatioLevelRoots P Q a ↔ phasePolynomialRatioLog P Q x=a := by
  simp only [phaseRatioLevelRoots,Finset.mem_preimage,Multiset.mem_toFinset,
    Polynomial.mem_roots hR,Polynomial.IsRoot.def]
  exact phaseRatioLevelPolynomial_eval_eq_zero_iff P Q a (Circle.norm_coe _)
    (hP _ (Circle.norm_coe _)) (hQ _ (Circle.norm_coe _))

theorem phasePolynomialRatioLog_constant_of_level_eq_zero (P Q : Polynomial ℂ) (a:ℝ)
    (hP:∀w:ℂ,‖w‖=1 → P.eval w≠0) (hQ:∀w:ℂ,‖w‖=1 → Q.eval w≠0)
    (hR:phaseRatioLevelPolynomial P Q a=0) (x:AddCircle (1:ℝ)) :
    phasePolynomialRatioLog P Q x=a := by
  apply (phaseRatioLevelPolynomial_eval_eq_zero_iff P Q a (Circle.norm_coe _)
    (hP _ (Circle.norm_coe _)) (hQ _ (Circle.norm_coe _))).mp
  rw [hR,Polynomial.eval_zero]

theorem phasePolynomialRatioLog_threshold_complexity (P Q : Polynomial ℂ)
    (hP:∀w:ℂ,‖w‖=1 → P.eval w≠0) (hQ:∀w:ℂ,‖w‖=1 → Q.eval w≠0)
    (c:ℝ) {κ:ℝ} (hκ:0≤κ) :
    phaseBadSet (phasePolynomialRatioLog P Q) c κ=∅ ∨
      ∃S:Finset (AddCircle (1:ℝ)),S.card≤4*max P.natDegree Q.natDegree ∧
        ∀x,|phasePolynomialRatioLog P Q x-c|=κ → x∈S := by
  classical
  have hdegenerate (a:ℝ) (ha:|a-c|=κ) (hR:phaseRatioLevelPolynomial P Q a=0) :
      phaseBadSet (phasePolynomialRatioLog P Q) c κ=∅ := by
    ext x
    simp only [phaseBadSet,Set.mem_setOf_eq,Set.mem_empty_iff_false,iff_false]
    rw [phasePolynomialRatioLog_constant_of_level_eq_zero P Q a hP hQ hR x,ha]
    exact lt_irrefl _
  have hmlevel : |(c-κ)-c|=κ := by
    rw [show (c-κ)-c= -κ by ring,abs_neg,abs_of_nonneg hκ]
  have hplevel : |(c+κ)-c|=κ := by rw [add_sub_cancel_left,abs_of_nonneg hκ]
  by_cases hm : phaseRatioLevelPolynomial P Q (c-κ)=0
  · exact Or.inl (hdegenerate _ hmlevel hm)
  by_cases hp : phaseRatioLevelPolynomial P Q (c+κ)=0
  · exact Or.inl (hdegenerate _ hplevel hp)
  right
  refine ⟨phaseRatioLevelRoots P Q (c-κ)∪phaseRatioLevelRoots P Q (c+κ),?_,?_⟩
  · exact (Finset.card_union_le _ _).trans
      ((Nat.add_le_add (phaseRatioLevelRoots_card_le P Q (c-κ))
        (phaseRatioLevelRoots_card_le P Q (c+κ))).trans (by omega))
  · intro x hx
    rcases le_total 0 (phasePolynomialRatioLog P Q x-c) with h|h
    · apply Finset.mem_union_right
      apply (mem_phaseRatioLevelRoots_iff P Q (c+κ) hP hQ hp x).mpr
      rw [abs_of_nonneg h] at hx
      linarith
    · apply Finset.mem_union_left
      apply (mem_phaseRatioLevelRoots_iff P Q (c-κ) hP hQ hm x).mpr
      rw [abs_of_nonpos h] at hx
      linarith

theorem measure_phaseBadHull_polynomial_ratio_le (P Q : Polynomial ℂ)
    (hP:∀w:ℂ,‖w‖=1 → P.eval w≠0) (hQ:∀w:ℂ,‖w‖=1 → Q.eval w≠0)
    (c:ℝ) {κ δ:ℝ} (hκ:0≤κ) (hδ:0≤δ) :
    haarAddCircle (phaseBadHull (phaseBadSet (phasePolynomialRatioLog P Q) c κ) δ)≤
      haarAddCircle (phaseBadSet (phasePolynomialRatioLog P Q) c κ)+
        ENNReal.ofReal (8*(max P.natDegree Q.natDegree:ℕ)*δ) := by
  obtain hbad|⟨S,hcard,hS⟩ := phasePolynomialRatioLog_threshold_complexity P Q hP hQ c hκ
  · simp [hbad]
  calc
    _≤haarAddCircle (phaseBadSet (phasePolynomialRatioLog P Q) c κ)+
        ENNReal.ofReal (2*(S.card:ℝ)*δ) :=
      measure_phaseBadHull_le_of_threshold_finset
        (continuous_phasePolynomialRatioLog P Q hP hQ) c κ δ S hS
    _≤_ := by
      apply add_le_add_left
      apply ENNReal.ofReal_le_ofReal
      have hcard' : (S.card:ℝ)≤4*(max P.natDegree Q.natDegree:ℕ) := by exact_mod_cast hcard
      nlinarith

end UAMO.BourgainJitomirskaya

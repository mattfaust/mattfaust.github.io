import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Order.Filter.AtTopBot.Tendsto
import Mathlib.Tactic

noncomputable section
open Filter
open scoped Topology BigOperators
namespace UAMO.BourgainJitomirskaya

def recordScaleGap (F : ℕ → ℝ) (N : ℕ) : ℝ := F N - F (2 * N)

def recordScaleGapEnvelope (κ A : ℝ) (q : ℕ) : ℝ :=
  κ / (50 * (q : ℝ) ^ 2) + A / (q : ℝ) ^ 4

def recordScaleLossEnvelope (κ A H γ : ℝ) (q : ℕ) : ℝ :=
  H * recordScaleGapEnvelope κ A q + Real.exp (-γ * (q : ℝ)) + A / (q : ℝ) ^ 5

def RecordScaleTransition (κ A H γ : ℝ) (F : ℕ → ℝ) (q : ℕ → ℕ) : Prop :=
  ∀ s N : ℕ, (q s) ^ 6 ≤ N → N ≤ 3 * (q s) ^ 6 → q s ∣ N →
    2000 * κ ≤ F N → recordScaleGap F N ≤ κ / 100 →
    ∃ M : ℕ, N ≤ M ∧ (q (s + 1)) ^ 6 ≤ M ∧ M ≤ 3 * (q (s + 1)) ^ 6 ∧
      q (s + 1) ∣ M ∧
      F N - H * recordScaleGap F N - Real.exp (-γ * (q s : ℝ)) -
        A / (q (s + 1) : ℝ) ^ 5 ≤ F M ∧
      (M : ℝ) * recordScaleGap F M ≤
        (N : ℝ) * recordScaleGap F N + A * (q (s + 1) : ℝ)

lemma recordScaleGapEnvelope_nonneg {κ A : ℝ} (hκ : 0 ≤ κ) (hA : 0 ≤ A) (q : ℕ) :
    0 ≤ recordScaleGapEnvelope κ A q := by
  unfold recordScaleGapEnvelope
  positivity

lemma recordScaleLossEnvelope_nonneg {κ A H γ : ℝ}
    (hκ : 0 ≤ κ) (hA : 0 ≤ A) (hH : 0 ≤ H) (q : ℕ) :
    0 ≤ recordScaleLossEnvelope κ A H γ q := by
  unfold recordScaleLossEnvelope
  exact add_nonneg (add_nonneg
    (mul_nonneg hH (recordScaleGapEnvelope_nonneg hκ hA q)) (Real.exp_pos _).le)
    (div_nonneg hA (pow_nonneg (Nat.cast_nonneg _) _))

lemma summable_recordScaleGapEnvelope (κ A : ℝ) :
    Summable (recordScaleGapEnvelope κ A) := by
  have h₂ := (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (2 : ℕ))).mul_left (κ / 50)
  have h₄ := (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (4 : ℕ))).mul_left A
  convert h₂.add h₄ using 1
  ext q
  unfold recordScaleGapEnvelope
  ring

lemma summable_recordScaleLossEnvelope (κ A H : ℝ) {γ : ℝ} (hγ : 0 < γ) :
    Summable (recordScaleLossEnvelope κ A H γ) := by
  have hgap := (summable_recordScaleGapEnvelope κ A).mul_left H
  have hexp : Summable (fun q : ℕ => Real.exp (-γ * (q : ℝ))) := by
    simpa only [mul_comm] using Real.summable_exp_nat_mul_iff.mpr (neg_neg_of_pos hγ)
  have h₅ := (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (5 : ℕ))).mul_left A
  convert (hgap.add hexp).add h₅ using 1
  ext q
  unfold recordScaleLossEnvelope
  ring

structure RecordScaleBudgetBounds (κ A H γ ε : ℝ) (Q : ℕ) : Prop where
  positive : 0 < Q
  gap : ∀ q : ℕ, Q ≤ q → recordScaleGapEnvelope κ A q ≤ κ / 100
  tail : (∑' n : ℕ, recordScaleLossEnvelope κ A H γ (n + Q)) ≤ ε
  summable : Summable (recordScaleLossEnvelope κ A H γ)

theorem exists_recordScaleBudgetBounds {κ A H γ ε : ℝ} (hκ : 0 < κ)
    (hγ : 0 < γ) (hε : 0 < ε) : ∃ Q : ℕ, RecordScaleBudgetBounds κ A H γ ε Q := by
  have hgap : ∀ᶠ q : ℕ in atTop, recordScaleGapEnvelope κ A q ≤ κ / 100 :=
    (summable_recordScaleGapEnvelope κ A).tendsto_atTop_zero.eventually
      (eventually_le_nhds (by positivity : (0 : ℝ) < κ / 100))
  have htail : ∀ᶠ Q : ℕ in atTop,
      (∑' n : ℕ, recordScaleLossEnvelope κ A H γ (n + Q)) ≤ ε :=
    (tendsto_sum_nat_add (recordScaleLossEnvelope κ A H γ)).eventually
      (eventually_le_nhds hε)
  obtain ⟨Q₁, hQ₁⟩ := eventually_atTop.mp hgap
  obtain ⟨Q₂, hQ₂⟩ := eventually_atTop.mp htail
  refine ⟨max 1 (max Q₁ Q₂), ?_⟩
  exact ⟨by omega, fun q hq => hQ₁ q (by omega), hQ₂ _ (by omega),
    summable_recordScaleLossEnvelope κ A H hγ⟩

theorem recordScale_prefix_loss_le {κ A H γ ε : ℝ}
    (hκ : 0 ≤ κ) (hA : 0 ≤ A) (hH : 0 ≤ H) (hγ : 0 < γ)
    {Q : ℕ} (hQ : RecordScaleBudgetBounds κ A H γ ε Q)
    {q : ℕ → ℕ} (hq : StrictMono q) (hQq : Q ≤ q 0) (s : ℕ) :
    (∑ j ∈ Finset.range s, recordScaleLossEnvelope κ A H γ (q j)) ≤ ε := by
  classical
  let e : ℕ → ℕ := fun j => q j - Q
  have hshift (j : ℕ) : e j + Q = q j :=
    Nat.sub_add_cancel (hQq.trans (hq.monotone (Nat.zero_le j)))
  have he : Function.Injective e := by
    intro i j hij
    apply hq.injective
    simpa only [hshift] using congrArg (fun n => n + Q) hij
  have hs : Summable (fun n : ℕ => recordScaleLossEnvelope κ A H γ (n + Q)) :=
    (summable_nat_add_iff Q).mpr (summable_recordScaleLossEnvelope κ A H hγ)
  calc
    _ = ∑ n ∈ (Finset.range s).image e, recordScaleLossEnvelope κ A H γ (n + Q) := by
      rw [Finset.sum_image (fun i _ j _ hij => he hij)]
      simp only [hshift]
    _ ≤ ∑' n : ℕ, recordScaleLossEnvelope κ A H γ (n + Q) :=
      hs.sum_le_tsum _ (fun n _ => recordScaleLossEnvelope_nonneg hκ hA hH (n + Q))
    _ ≤ ε := hQ.tail

lemma recordScale_square_step {q p : ℕ} (hqp : q < p) :
    (q : ℝ) ^ 2 + (p : ℝ) ≤ (p : ℝ) ^ 2 := by
  have hstep : (q : ℝ) + 1 ≤ p := by exact_mod_cast hqp
  have hq : (0 : ℝ) ≤ q := Nat.cast_nonneg q
  have hp : (0 : ℝ) ≤ p := Nat.cast_nonneg p
  nlinarith [mul_nonneg (show 0 ≤ (p : ℝ) - q - 1 by linarith)
    (show 0 ≤ (p : ℝ) + q by positivity)]

lemma recordScale_gap_le_envelope {κ A : ℝ} (hκ : 0 ≤ κ) (hA : 0 ≤ A)
    {q₀ q N : ℕ} (hq : 0 < q) (hq₀ : q₀ ≤ q) (hN : q ^ 6 ≤ N)
    {d : ℝ} (hw : (N : ℝ) * d ≤ κ * (q₀ : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2) :
    d ≤ recordScaleGapEnvelope κ A q := by
  have hqr : (0 : ℝ) < q := by exact_mod_cast hq
  have hNr : (0 : ℝ) < N := by exact_mod_cast (pow_pos hq 6).trans_le hN
  have hq₀r : (q₀ : ℝ) ^ 4 ≤ (q : ℝ) ^ 4 := by
    exact_mod_cast Nat.pow_le_pow_left hq₀ 4
  have hscale : (q : ℝ) ^ 6 ≤ N := by exact_mod_cast hN
  have hid : (q : ℝ) ^ 6 * recordScaleGapEnvelope κ A q =
      κ * (q : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2 := by
    unfold recordScaleGapEnvelope
    field_simp
    ring
  have hb : κ * (q₀ : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2 ≤
      κ * (q : ℝ) ^ 4 / 50 + A * (q : ℝ) ^ 2 := by gcongr
  have hm := mul_le_mul_of_nonneg_right hscale (recordScaleGapEnvelope_nonneg hκ hA q)
  rw [hid] at hm
  exact (mul_le_mul_left hNr).mp (hw.trans (hb.trans hm))

private def RecordScaleState (κ A H γ : ℝ) (F : ℕ → ℝ) (q : ℕ → ℕ)
    (s N : ℕ) : Prop :=
  (q s) ^ 6 ≤ N ∧ N ≤ 3 * (q s) ^ 6 ∧ q s ∣ N ∧
  F ((q 0) ^ 6) - (∑ j ∈ Finset.range s, recordScaleLossEnvelope κ A H γ (q j)) ≤ F N ∧
  (N : ℝ) * recordScaleGap F N ≤ κ * (q 0 : ℝ) ^ 4 / 50 + A * (q s : ℝ) ^ 2

structure RecordScaleSequence (κ ε : ℝ) (F : ℕ → ℝ) (q Ns : ℕ → ℕ) : Prop where
  initial : Ns 0 = (q 0) ^ 6
  monotone : Monotone Ns
  tendsto : Tendsto Ns atTop atTop
  lower : ∀ s : ℕ, (q s) ^ 6 ≤ Ns s
  upper : ∀ s : ℕ, Ns s ≤ 3 * (q s) ^ 6
  dvd : ∀ s : ℕ, q s ∣ Ns s
  height : ∀ s : ℕ, 2000 * κ ≤ F (Ns s)
  gap : ∀ s : ℕ, recordScaleGap F (Ns s) ≤ κ / 100
  loss : ∀ s : ℕ, F ((q 0)^6)-ε ≤ F (Ns s)

theorem recordScale_sequence_of_budget {κ A H γ ε : ℝ}
    (hκ : 0 < κ) (hA : 0 < A) (hH : 0 < H) (hγ : 0 < γ)
    (hεκ : ε≤κ) {Q : ℕ} (hQ : RecordScaleBudgetBounds κ A H γ ε Q)
    {F : ℕ → ℝ} {q : ℕ → ℕ} (hq : StrictMono q) (hQq : Q ≤ q 0)
    (hheight₀ : 4000 * κ ≤ F ((q 0) ^ 6))
    (hweight₀ : (((q 0) ^ 6 : ℕ) : ℝ) * recordScaleGap F ((q 0) ^ 6) ≤
      κ * (q 0 : ℝ) ^ 4 / 50)
    (hstep : RecordScaleTransition κ A H γ F q) :
    ∃ Ns : ℕ → ℕ, RecordScaleSequence κ ε F q Ns := by
  have hden (s : ℕ) : Q ≤ q s := hQq.trans (hq.monotone (Nat.zero_le s))
  have hpos (s : ℕ) : 0 < q s := hQ.positive.trans_le (hden s)
  have hprefix (s : ℕ) :
      (∑ j ∈ Finset.range s, recordScaleLossEnvelope κ A H γ (q j)) ≤ ε :=
    recordScale_prefix_loss_le hκ.le hA.le hH.le hγ hQ hq hQq s
  have height {s N : ℕ} (hN : RecordScaleState κ A H γ F q s N) :
      2000 * κ ≤ F N := by
    have hl := hN.2.2.2.1
    have hb := hprefix s
    linarith
  have gapEnvelope {s N : ℕ} (hN : RecordScaleState κ A H γ F q s N) :
      recordScaleGap F N ≤ recordScaleGapEnvelope κ A (q s) :=
    recordScale_gap_le_envelope hκ.le hA.le (hpos s)
      (hq.monotone (Nat.zero_le s)) hN.1 hN.2.2.2.2
  have gap {s N : ℕ} (hN : RecordScaleState κ A H γ F q s N) :
      recordScaleGap F N ≤ κ / 100 :=
    (gapEnvelope hN).trans (hQ.gap (q s) (hden s))
  have initial : RecordScaleState κ A H γ F q 0 ((q 0) ^ 6) := by
    refine ⟨le_rfl, by omega, dvd_pow_self _ (by norm_num), ?_, ?_⟩
    · simp only [Finset.range_zero, Finset.sum_empty, sub_zero, le_refl]
    · exact hweight₀.trans (le_add_of_nonneg_right
        (mul_nonneg hA.le (sq_nonneg (q 0 : ℝ))))
  have next (s N : ℕ) (hN : RecordScaleState κ A H γ F q s N) :
      ∃ M : ℕ, N ≤ M ∧ RecordScaleState κ A H γ F q (s + 1) M := by
    obtain ⟨M, hNM, hMlo, hMhi, hMdvd, hMF, hMw⟩ :=
      hstep s N hN.1 hN.2.1 hN.2.2.1 (height hN) (gap hN)
    refine ⟨M, hNM, hMlo, hMhi, hMdvd, ?_, ?_⟩
    · have hrat : A / (q (s + 1) : ℝ) ^ 5 ≤ A / (q s : ℝ) ^ 5 := by
        apply div_le_div_of_nonneg_left hA.le
        · exact pow_pos (by exact_mod_cast hpos s) 5
        · gcongr
          exact_mod_cast hq.monotone (Nat.le_succ s)
      have hg := mul_le_mul_of_nonneg_left (gapEnvelope hN) hH.le
      have hl := hN.2.2.2.1
      rw [Finset.sum_range_succ]
      unfold recordScaleLossEnvelope at hl ⊢
      linarith
    · have hw := hN.2.2.2.2
      have hsquare := mul_le_mul_of_nonneg_left
        (recordScale_square_step (hq (Nat.lt_succ_self s))) hA.le
      nlinarith
  let State (s : ℕ) := {N : ℕ // RecordScaleState κ A H γ F q s N}
  let advance (s : ℕ) (x : State s) : State (s + 1) :=
    ⟨Classical.choose (next s x.val x.property),
      (Classical.choose_spec (next s x.val x.property)).2⟩
  let states : (s : ℕ) → State s :=
    Nat.rec ⟨(q 0) ^ 6, initial⟩ (fun s x => advance s x)
  let Ns : ℕ → ℕ := fun s => (states s).val
  have hstates (s : ℕ) : RecordScaleState κ A H γ F q s (Ns s) :=
    (states s).property
  have hmono : Monotone Ns := by
    apply monotone_nat_of_le_succ
    intro s
    exact (Classical.choose_spec (next s (states s).val (states s).property)).1
  refine ⟨Ns, ?_⟩
  exact {
    initial := rfl
    monotone := hmono
    tendsto := tendsto_atTop_mono (fun s =>
      (Nat.le_pow (by norm_num : 0 < (6 : ℕ))).trans (hstates s).1) hq.tendsto_atTop
    lower := fun s => (hstates s).1
    upper := fun s => (hstates s).2.1
    dvd := fun s => (hstates s).2.2.1
    height := fun s => height (hstates s)
    gap := fun s => gap (hstates s)
    loss := fun s => (sub_le_sub_left (hprefix s) _).trans (hstates s).2.2.2.1 }

theorem exists_recordScale_budget {κ A H γ ε : ℝ}
    (hκ : 0 < κ) (hA : 0 < A) (hH : 0 < H) (hγ : 0 < γ)
    (hε : 0<ε) (hεκ : ε≤κ) :
    ∃ Q : ℕ, 0 < Q ∧ ∀ (F : ℕ → ℝ) (q : ℕ → ℕ),
      StrictMono q → Q ≤ q 0 →
      4000 * κ ≤ F ((q 0) ^ 6) →
      (((q 0) ^ 6 : ℕ) : ℝ) * recordScaleGap F ((q 0) ^ 6) ≤ κ * (q 0 : ℝ) ^ 4 / 50 →
      RecordScaleTransition κ A H γ F q →
      ∃ Ns : ℕ → ℕ, RecordScaleSequence κ ε F q Ns := by
  obtain ⟨Q, hQ⟩ := exists_recordScaleBudgetBounds (A := A) (H := H) hκ hγ hε
  exact ⟨Q, hQ.positive, fun F q hq hQq hheight hweight hstep =>
    recordScale_sequence_of_budget hκ hA hH hγ hεκ hQ hq hQq hheight hweight hstep⟩

theorem RecordScaleSequence.limit_lower {κ ε L : ℝ}
    {F : ℕ→ℝ} {q Ns : ℕ→ℕ} (hseq : RecordScaleSequence κ ε F q Ns)
    (hlim : Tendsto F atTop (𝓝 L)) : F ((q 0)^6)-ε≤L :=
  ge_of_tendsto' (hlim.comp hseq.tendsto) hseq.loss

end UAMO.BourgainJitomirskaya

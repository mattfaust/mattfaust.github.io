import Mathlib.RingTheory.Coprime.Basic
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Data.Real.Archimedean
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Lean.Elab.Tactic.Omega

noncomputable section

namespace UAMO.BourgainJitomirskaya

theorem coprime_small_linear_combination_ne_zero {a q k m : ℤ}
    (hcop : IsCoprime a q) (hk : k ≠ 0) (hsmall : |k| < q) :
    a * k - m * q ≠ 0 := by
  intro hz
  have hmul : q ∣ a * k := ⟨m, by nlinarith [sub_eq_zero.mp hz]⟩
  have hdiv : q ∣ k := hcop.symm.dvd_of_dvd_mul_left hmul
  have hle : q ≤ |k| := Int.le_of_dvd (abs_pos.mpr hk) ((dvd_abs q k).mpr hdiv)
  exact (not_le_of_gt hsmall) hle

theorem rationalApprox_separation {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    {k : ℤ} (hk : k ≠ 0) (hsmall : 2 * |k| ≤ (q : ℤ)) (m : ℤ) :
    1 / (2 * (q : ℝ)) < |(k : ℝ) * α - (m : ℝ)| := by
  have hqZ : (2 : ℤ) ≤ (q : ℤ) := by exact_mod_cast hq
  have hqR : (0 : ℝ) < (q : ℝ) := by exact_mod_cast (show 0 < q by omega)
  have hkq : |k| < (q : ℤ) := by omega
  have hnz := coprime_small_linear_combination_ne_zero hcop hk hkq (m := m)
  have hint : (1 : ℤ) ≤ |a * k - m * (q : ℤ)| := by
    have := abs_pos.mpr hnz
    omega
  have hone : (1 : ℝ) ≤ |(a : ℝ) * (k : ℝ) - (m : ℝ) * (q : ℝ)| := by
    exact_mod_cast hint
  have hkR : (0 : ℝ) < |(k : ℝ)| := by exact_mod_cast (abs_pos.mpr hk)
  have hsmallR : 2 * |(k : ℝ)| ≤ (q : ℝ) := by exact_mod_cast hsmall
  have hident : (k : ℝ) * (a : ℝ) / (q : ℝ) - (m : ℝ) =
      ((a : ℝ) * (k : ℝ) - (m : ℝ) * (q : ℝ)) / (q : ℝ) := by
    field_simp
    ring
  have hrat : 1 / (q : ℝ) ≤ |(k : ℝ) * (a : ℝ) / (q : ℝ) - (m : ℝ)| := by
    rw [hident, abs_div, abs_of_pos hqR]
    exact div_le_div_of_nonneg_right hone hqR.le
  have herr : |(k : ℝ)| * |α - (a : ℝ) / (q : ℝ)| < 1 / (2 * (q : ℝ)) := by
    calc
      _ < |(k : ℝ)| * (1 / (q : ℝ) ^ 2) := mul_lt_mul_of_pos_left happrox hkR
      _ ≤ ((q : ℝ) / 2) * (1 / (q : ℝ) ^ 2) :=
        mul_le_mul_of_nonneg_right (by linarith) (by positivity)
      _ = 1 / (2 * (q : ℝ)) := by field_simp; ring
  have htri : |(k : ℝ) * (a : ℝ) / (q : ℝ) - (m : ℝ)| ≤
      |(k : ℝ) * α - (m : ℝ)| + |(k : ℝ)| * |α - (a : ℝ) / (q : ℝ)| := by
    calc
      _ = |((k : ℝ) * α - (m : ℝ)) -
          (k : ℝ) * (α - (a : ℝ) / (q : ℝ))| := by congr 1; ring
      _ ≤ |(k : ℝ) * α - (m : ℝ)| +
          |(k : ℝ) * (α - (a : ℝ) / (q : ℝ))| := by
        simpa only [sub_zero, zero_sub, abs_neg] using
          abs_sub_le ((k : ℝ) * α - (m : ℝ)) 0
            ((k : ℝ) * (α - (a : ℝ) / (q : ℝ)))
      _ = _ := by rw [abs_mul]
  have hhalf : 1 / (q : ℝ) = 2 * (1 / (2 * (q : ℝ))) := by field_simp
  linarith

def centeredFraction (x : ℝ) : ℝ := x - (⌊x + 1 / 2⌋ : ℝ)

theorem centeredFraction_mem_Ico (x : ℝ) :
    centeredFraction x ∈ Set.Ico (-(1 / 2 : ℝ)) (1 / 2) := by
  have hlo := Int.floor_le (x + 1 / 2)
  have hhi := Int.lt_floor_add_one (x + 1 / 2)
  constructor <;> dsimp [centeredFraction] <;> linarith

theorem abs_centeredFraction_le_half (x : ℝ) : |centeredFraction x| ≤ (1 / 2 : ℝ) := by
  obtain ⟨hlo, hhi⟩ := centeredFraction_mem_Ico x
  exact abs_le.mpr ⟨hlo, hhi.le⟩

theorem rationalApprox_centered_separation {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    {k : ℤ} (hk : k ≠ 0) (hsmall : 2 * |k| ≤ (q : ℤ)) :
    1 / (2 * (q : ℝ)) < |centeredFraction ((k : ℝ) * α)| := by
  exact rationalApprox_separation hq hcop happrox hk hsmall ⌊(k : ℝ) * α + 1 / 2⌋

theorem rationalApprox_centered_pair_separation {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (x : ℝ) {k l : ℤ} (hkl : k ≠ l) (hsmall : 2 * |k - l| ≤ (q : ℤ)) :
    1 / (2 * (q : ℝ)) <
      |centeredFraction (x + (k : ℝ) * α) - centeredFraction (x + (l : ℝ) * α)| := by
  have h := rationalApprox_separation hq hcop happrox (sub_ne_zero.mpr hkl) hsmall
    (⌊x + (k : ℝ) * α + 1 / 2⌋ - ⌊x + (l : ℝ) * α + 1 / 2⌋)
  convert h using 1
  congr 1
  simp only [centeredFraction, Int.cast_sub]
  ring

end UAMO.BourgainJitomirskaya

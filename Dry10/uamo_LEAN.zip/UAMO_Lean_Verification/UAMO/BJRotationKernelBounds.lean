import UAMO.BJFourierSmoothing
import UAMO.BJRotationPacking
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.NumberTheory.Harmonic.Bounds

noncomputable section

namespace UAMO.BourgainJitomirskaya

open AddCircle Finset
open scoped ComplexConjugate

theorem coe_centeredFraction (x : ℝ) :
    (centeredFraction x : AddCircle (1 : ℝ)) = (x : AddCircle (1 : ℝ)) := by
  have hz : (((⌊x + 1 / 2⌋ : ℤ) : ℝ) : AddCircle (1 : ℝ)) = 0 := by
    apply (AddCircle.coe_eq_zero_iff 1).mpr
    exact ⟨⌊x + 1 / 2⌋, by simp⟩
  rw [centeredFraction, AddCircle.coe_sub, hz, sub_zero]

theorem norm_one_sub_exp_two_mul_I (t : ℝ) :
    ‖(1 : ℂ) - Complex.exp (((2 * t : ℝ) : ℂ) * Complex.I)‖ = 2 * |Real.sin t| := by
  apply (sq_eq_sq₀ (norm_nonneg _) (by positivity)).mp
  rw [← Complex.normSq_eq_norm_sq]
  simp only [Complex.normSq_apply, Complex.sub_re, Complex.sub_im,
    Complex.one_re, Complex.one_im, Complex.exp_ofReal_mul_I_re,
    Complex.exp_ofReal_mul_I_im, mul_pow, sq_abs]
  nlinarith [Real.sin_sq_add_cos_sq (2 * t), Real.sin_sq_add_cos_sq t, Real.cos_two_mul t]

theorem norm_one_sub_fourier_one_coe (x : ℝ) :
    ‖(1 : ℂ) - fourier 1 (x : AddCircle (1 : ℝ))‖ = 2 * |Real.sin (Real.pi * x)| := by
  have hf : fourier 1 (x : AddCircle (1 : ℝ)) =
      Complex.exp (((2 * (Real.pi * x) : ℝ) : ℂ) * Complex.I) := by
    rw [fourier_coe_apply]
    congr 1
    push_cast
    ring
  rw [hf, norm_one_sub_exp_two_mul_I]

theorem fourier_chord_ge_centered (α : ℝ) (k : ℤ) :
    4 * |centeredFraction ((k : ℝ) * α)| ≤
      ‖(1 : ℂ) - fourier k (α : AddCircle (1 : ℝ))‖ := by
  have hf : fourier k (α : AddCircle (1 : ℝ)) =
      fourier 1 (((k : ℝ) * α : ℝ) : AddCircle (1 : ℝ)) := by
    rw [fourier_coe_apply, fourier_coe_apply]
    congr 1
    push_cast
    ring
  rw [hf, ← coe_centeredFraction ((k : ℝ) * α), norm_one_sub_fourier_one_coe]
  have hx : |Real.pi * centeredFraction ((k : ℝ) * α)| ≤ Real.pi / 2 := by
    rw [abs_mul, abs_of_pos Real.pi_pos]
    nlinarith [abs_centeredFraction_le_half ((k : ℝ) * α), Real.pi_pos]
  have h := Real.mul_abs_le_abs_sin hx
  rw [abs_mul, abs_of_pos Real.pi_pos] at h
  have heq : 2 / Real.pi * (Real.pi * |centeredFraction ((k : ℝ) * α)|) =
      2 * |centeredFraction ((k : ℝ) * α)| := by field_simp; ring
  rw [heq] at h
  linarith

theorem fourier_ne_one_of_centered_ne_zero (α : ℝ) (k : ℤ)
    (hd : centeredFraction ((k : ℝ) * α) ≠ 0) :
    fourier k (α : AddCircle (1 : ℝ)) ≠ 1 := by
  intro h
  have hc := fourier_chord_ge_centered α k
  rw [h, sub_self, norm_zero] at hc
  have hp := abs_pos.mpr hd
  linarith

theorem norm_fourierOrbitAmplitude_le_centered
    (R : ℕ) (hR : 0 < R) (α : ℝ) (k : ℤ)
    (hd : centeredFraction ((k : ℝ) * α) ≠ 0) :
    ‖fourierOrbitAmplitude R (α : AddCircle (1 : ℝ)) k‖ ≤
      1 / (2 * (R : ℝ) * |centeredFraction ((k : ℝ) * α)|) := by
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hdpos := abs_pos.mpr hd
  calc
    _ ≤ 2 / ((R : ℝ) * ‖(1 : ℂ) - fourier k (α : AddCircle (1 : ℝ))‖) :=
      norm_fourierOrbitAmplitude_le R hR _ k (fourier_ne_one_of_centered_ne_zero α k hd)
    _ ≤ 2 / ((R : ℝ) * (4 * |centeredFraction ((k : ℝ) * α)|)) :=
      div_le_div_of_nonneg_left (by norm_num) (by positivity)
        (mul_le_mul_of_nonneg_left (fourier_chord_ge_centered α k) hRr.le)
    _ = _ := by field_simp; ring

theorem fourierOrbitMultiplier_le_centered_inv
    (R : ℕ) (hR : 0 < R) (α : ℝ) (k : ℤ)
    (hd : centeredFraction ((k : ℝ) * α) ≠ 0) :
    fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k ≤
      1 / (2 * (R : ℝ) * |centeredFraction ((k : ℝ) * α)|) := by
  have hamp := norm_fourierOrbitAmplitude_le_one R hR (α : AddCircle (1 : ℝ)) k
  calc
    _ ≤ ‖fourierOrbitAmplitude R (α : AddCircle (1 : ℝ)) k‖ := by
      unfold fourierOrbitMultiplier
      nlinarith [norm_nonneg (fourierOrbitAmplitude R (α : AddCircle (1 : ℝ)) k)]
    _ ≤ _ := norm_fourierOrbitAmplitude_le_centered R hR α k hd

theorem fourierOrbitMultiplier_mul_centered_sq_le
    (R : ℕ) (hR : 0 < R) (α : ℝ) (k : ℤ) :
    fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k *
      ((R : ℝ) * centeredFraction ((k : ℝ) * α)) ^ 2 ≤ 1 / 4 := by
  by_cases hd : centeredFraction ((k : ℝ) * α) = 0
  · simp [hd]
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hp : 0 < 2 * (R : ℝ) * |centeredFraction ((k : ℝ) * α)| := by positivity
  have h := (le_div_iff₀ hp).mp (norm_fourierOrbitAmplitude_le_centered R hR α k hd)
  have hs := mul_self_le_mul_self (mul_nonneg (norm_nonneg _) hp.le) h
  simp only [one_mul, ← pow_two, mul_pow, sq_abs] at hs
  unfold fourierOrbitMultiplier
  nlinarith [hs]

theorem fourierOrbitMultiplier_le_regularized_centered
    (R : ℕ) (hR : 0 < R) (α : ℝ) (k : ℤ) :
    fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k ≤
      2 * (1 + ((R : ℝ) * centeredFraction ((k : ℝ) * α)) ^ 2)⁻¹ := by
  have hden : 0 < 1 + ((R : ℝ) * centeredFraction ((k : ℝ) * α)) ^ 2 := by positivity
  rw [← div_eq_mul_inv]
  apply (le_div_iff₀ hden).mpr
  have h1 := fourierOrbitMultiplier_le_one R hR (α : AddCircle (1 : ℝ)) k
  have h2 := fourierOrbitMultiplier_mul_centered_sq_le R hR α k
  nlinarith

theorem fourierOrbitMultiplier_neg (R : ℕ) (α : AddCircle (1 : ℝ)) (k : ℤ) :
    fourierOrbitMultiplier R α (-k) = fourierOrbitMultiplier R α k := by
  have hc : fourierOrbitAmplitude R α (-k) = conj (fourierOrbitAmplitude R α k) := by
    simp only [fourierOrbitAmplitude, fourier_neg, map_mul, map_inv₀, map_natCast,
      map_sum, map_pow]
  simp only [fourierOrbitMultiplier, hc, Complex.norm_conj]

theorem rationalApprox_sum_weighted_multiplier_of_quarter
    {α : ℝ} {a : ℤ} {q : ℕ} (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (R : ℕ) (hR : 0 < R) (s : Finset ℤ) (hnonzero : ∀ k ∈ s, k ≠ 0)
    (hquarter : ∀ k ∈ s, 4 * |k| ≤ (q : ℤ)) :
    ∑ k ∈ s, |(k : ℝ)|⁻¹ * fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k ≤
      4 * (q : ℝ) / (R : ℝ) := by
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hd (k : ℤ) (hk : k ∈ s) : centeredFraction ((k : ℝ) * α) ≠ 0 := by
    have hp := rationalApprox_centered_separation hq hcop happrox (hnonzero k hk)
      (show 2 * |k| ≤ (q : ℤ) by have := hquarter k hk; have := abs_nonneg k; omega)
    have hqR : 0 < (q : ℝ) := by exact_mod_cast (show 0 < q by omega)
    exact abs_pos.mp ((by positivity : (0 : ℝ) < 1 / (2 * (q : ℝ))).trans hp)
  calc
    _ ≤ ∑ k ∈ s, |(k : ℝ)|⁻¹ *
        (1 / (2 * (R : ℝ) * |centeredFraction ((k : ℝ) * α)|)) :=
      sum_le_sum fun k hk => mul_le_mul_of_nonneg_left
        (fourierOrbitMultiplier_le_centered_inv R hR α k (hd k hk)) (by positivity)
    _ = (1 / (2 * (R : ℝ))) *
        ∑ k ∈ s, |(k : ℝ)|⁻¹ * |centeredFraction ((k : ℝ) * α)|⁻¹ := by
      rw [mul_sum]
      apply sum_congr rfl
      intro k _
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring
    _ ≤ (1 / (2 * (R : ℝ))) * (8 * (q : ℝ)) :=
      mul_le_mul_of_nonneg_left
        (rationalApprox_sum_weighted_centered_inv_of_quarter hq hcop happrox s hnonzero hquarter)
        (by positivity)
    _ = _ := by field_simp; ring

theorem rationalApprox_sum_multiplier_block
    {α : ℝ} {a : ℤ} {q : ℕ} (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (R : ℕ) (hRq : q ≤ R) (s : Finset ℤ)
    (hspan : ∀ k ∈ s, ∀ l ∈ s, 2 * |k - l| ≤ (q : ℤ)) :
    ∑ k ∈ s, fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k ≤ 36 := by
  have hR : 0 < R := (show 0 < q by omega).trans_le hRq
  have hRr : 0 < (R : ℝ) := by exact_mod_cast hR
  have hqR : (q : ℝ) ≤ (R : ℝ) := by exact_mod_cast hRq
  have hratio : 0 ≤ (q : ℝ) / (R : ℝ) := by positivity
  have hratio1 : (q : ℝ) / (R : ℝ) ≤ 1 := (div_le_one hRr).mpr hqR
  calc
    _ ≤ ∑ k ∈ s, 2 * (1 + ((R : ℝ) * centeredFraction ((k : ℝ) * α)) ^ 2)⁻¹ :=
      sum_le_sum fun k _ => fourierOrbitMultiplier_le_regularized_centered R hR α k
    _ = 2 * ∑ k ∈ s, (1 + ((R : ℝ) * centeredFraction ((k : ℝ) * α)) ^ 2)⁻¹ :=
      (mul_sum _ _ _).symm
    _ ≤ 2 * (2 + 16 * ((q : ℝ) / (R : ℝ)) ^ 2) := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      simpa only [zero_add] using
        rationalApprox_sum_regularized_centered hq hcop happrox s hspan 0 hRr
    _ ≤ 36 := by nlinarith

private theorem sum_range_mul_blocks (f : ℕ → ℝ) (m n : ℕ) :
    ∑ k ∈ range (n * m), f k = ∑ j ∈ range n, ∑ i ∈ range m, f (j * m + i) := by
  induction n with
  | zero => simp
  | succ n ih => rw [Nat.succ_mul, sum_range_add, ih, sum_range_succ]

private theorem rationalApprox_sum_weighted_multiplier_nonneg
    {α : ℝ} {a : ℤ} {q : ℕ} (hq : 8 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (R : ℕ) (hRq : q ≤ R) (K : ℕ) (hK : 1 ≤ K) :
    ∑ k ∈ range (K + 1), (k : ℝ)⁻¹ *
        fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) (k : ℤ) ≤
      4 * (q : ℝ) / R + (288 / (q : ℝ)) * (1 + Real.log ((K : ℝ) + 1)) := by
  let m : ℕ := q / 4
  let f : ℕ → ℝ := fun k => (k : ℝ)⁻¹ *
    fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) (k : ℤ)
  have hm : 0 < m := by dsimp [m]; omega
  have hqm : 4 * m ≤ q := by dsimp [m]; omega
  have hq8m : q ≤ 8 * m := by dsimp [m]; omega
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hqR : (0 : ℝ) < q := by exact_mod_cast (show 0 < q by omega)
  have hR : 0 < R := (show 0 < q by omega).trans_le hRq
  have hf (k : ℕ) : 0 ≤ f k := mul_nonneg (by positivity)
    (fourierOrbitMultiplier_nonneg R _ _)
  have hfirst : ∑ i ∈ range m, f i ≤ 4 * (q : ℝ) / R := by
    let s : Finset ℤ := ((range m).erase 0).image (fun i : ℕ => (i : ℤ))
    have hnonzero : ∀ k ∈ s, k ≠ 0 := by
      intro k hk
      obtain ⟨i, hi, rfl⟩ := mem_image.mp hk
      exact_mod_cast (mem_erase.mp hi).1
    have hquarter : ∀ k ∈ s, 4 * |k| ≤ (q : ℤ) := by
      intro k hk
      obtain ⟨i, hi, rfl⟩ := mem_image.mp hk
      have hi' := mem_range.mp (mem_of_mem_erase hi)
      rw [abs_of_nonneg (Nat.cast_nonneg i)]
      exact_mod_cast (show 4 * i ≤ q by omega)
    have hs := rationalApprox_sum_weighted_multiplier_of_quarter
      (show 2 ≤ q by omega) hcop happrox R hR s hnonzero hquarter
    have heq : ∑ k ∈ s, |(k : ℝ)|⁻¹ *
        fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k = ∑ i ∈ range m, f i := by
      dsimp only [s]
      rw [sum_image]
      · simp only [Int.cast_natCast, Nat.abs_cast]
        change ∑ i ∈ (range m).erase 0, f i = ∑ i ∈ range m, f i
        exact sum_erase (range m) (by simp [f])
      · intro i _ j _ hij
        exact_mod_cast hij
    rwa [heq] at hs
  have hblock (j : ℕ) :
      ∑ i ∈ range m, fourierOrbitMultiplier R (α : AddCircle (1 : ℝ))
        ((j * m + i : ℕ) : ℤ) ≤ 36 := by
    let s : Finset ℤ := (range m).image (fun i : ℕ => ((j * m + i : ℕ) : ℤ))
    have hspan : ∀ k ∈ s, ∀ l ∈ s, 2 * |k - l| ≤ (q : ℤ) := by
      intro k hk l hl
      obtain ⟨i, hi, rfl⟩ := mem_image.mp hk
      obtain ⟨i', hi', rfl⟩ := mem_image.mp hl
      have hiR : (i : ℤ) < m := by exact_mod_cast mem_range.mp hi
      have hiR' : (i' : ℤ) < m := by exact_mod_cast mem_range.mp hi'
      have hqmR : 4 * (m : ℤ) ≤ q := by exact_mod_cast hqm
      have hd : |((j * m + i : ℕ) : ℤ) - ((j * m + i' : ℕ) : ℤ)| ≤ (m : ℤ) := by
        apply abs_le.mpr
        constructor <;> push_cast <;> omega
      omega
    have hs := rationalApprox_sum_multiplier_block
      (show 2 ≤ q by omega) hcop happrox R hRq s hspan
    dsimp only [s] at hs
    rw [sum_image] at hs
    · exact hs
    · intro i _ i' _ heq
      have : j * m + i = j * m + i' := by exact_mod_cast heq
      omega
  have hweighted (j : ℕ) (hj : 0 < j) :
      ∑ i ∈ range m, f (j * m + i) ≤ (36 / (m : ℝ)) * (j : ℝ)⁻¹ := by
    have hjm : (0 : ℝ) < (j * m : ℕ) := by exact_mod_cast Nat.mul_pos hj hm
    calc
      _ ≤ ∑ i ∈ range m, ((j * m : ℕ) : ℝ)⁻¹ *
          fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) ((j * m + i : ℕ) : ℤ) := by
        apply sum_le_sum
        intro i _
        apply mul_le_mul_of_nonneg_right _ (fourierOrbitMultiplier_nonneg R _ _)
        simpa only [one_div] using one_div_le_one_div_of_le hjm
          (show ((j * m : ℕ) : ℝ) ≤ ((j * m + i : ℕ) : ℝ) by exact_mod_cast Nat.le_add_right (j * m) i)
      _ = ((j * m : ℕ) : ℝ)⁻¹ * ∑ i ∈ range m,
          fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) ((j * m + i : ℕ) : ℤ) :=
        (mul_sum _ _ _).symm
      _ ≤ ((j * m : ℕ) : ℝ)⁻¹ * 36 :=
        mul_le_mul_of_nonneg_left (hblock j) (by positivity)
      _ = _ := by simp only [Nat.cast_mul, mul_inv_rev, div_eq_mul_inv]; ring
  have hlog : (harmonic K : ℝ) ≤ 1 + Real.log ((K : ℝ) + 1) := by
    apply (harmonic_le_one_add_log K).trans
    apply add_le_add_left
    exact Real.log_le_log (by exact_mod_cast (show 0 < K by omega)) (by linarith)
  have hlognonneg : 0 ≤ 1 + Real.log ((K : ℝ) + 1) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ (K : ℝ) + 1 from le_add_of_nonneg_left (Nat.cast_nonneg K))
    linarith
  have hcoef : 36 / (m : ℝ) ≤ 288 / (q : ℝ) := by
    apply (div_le_div_iff₀ hmR hqR).mpr
    have : (q : ℝ) ≤ 8 * (m : ℝ) := by exact_mod_cast hq8m
    linarith
  calc
    _ ≤ ∑ k ∈ range ((K + 1) * m), f k := by
      apply sum_le_sum_of_subset_of_nonneg
      · exact range_mono (by nlinarith)
      · intro k _ _
        exact hf k
    _ = ∑ j ∈ range (K + 1), ∑ i ∈ range m, f (j * m + i) :=
      sum_range_mul_blocks f m (K + 1)
    _ = (∑ i ∈ range m, f i) +
        ∑ j ∈ range K, ∑ i ∈ range m, f ((j + 1) * m + i) := by
      rw [sum_range_succ']
      simp only [zero_mul, zero_add]
      rw [add_comm]
    _ ≤ 4 * (q : ℝ) / R + ∑ j ∈ range K, (36 / (m : ℝ)) * ((j + 1 : ℕ) : ℝ)⁻¹ :=
      add_le_add hfirst (sum_le_sum fun j _ => hweighted (j + 1) (by omega))
    _ = 4 * (q : ℝ) / R + (36 / (m : ℝ)) * (harmonic K : ℝ) := by
      rw [← mul_sum]
      simp only [harmonic, Rat.cast_sum, Rat.cast_inv, Rat.cast_natCast]
    _ ≤ 4 * (q : ℝ) / R + (36 / (m : ℝ)) * (1 + Real.log ((K : ℝ) + 1)) :=
      add_le_add_left (mul_le_mul_of_nonneg_left hlog (by positivity)) _
    _ ≤ _ := add_le_add_left (mul_le_mul_of_nonneg_right hcoef hlognonneg) _

theorem rationalApprox_sum_weighted_multiplier
    {α : ℝ} {a : ℤ} {q : ℕ} (hq : 8 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (R : ℕ) (hRq : q ≤ R) (K : ℕ) (hK : 1 ≤ K) :
    ∑ k ∈ (Icc (-(K : ℤ)) (K : ℤ)).erase 0,
        (1 / |(k : ℝ)|) * fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k ≤
      4096 * ((q : ℝ) / R + (1 + Real.log ((K : ℝ) + 1)) / q) := by
  let f : ℤ → ℝ := fun k => |(k : ℝ)|⁻¹ *
    fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) k
  let s : Finset ℤ := (range (K + 1)).image (fun k : ℕ => (k : ℤ))
  let t : Finset ℤ := (range (K + 1)).image (fun k : ℕ => -(k : ℤ))
  have hf (k : ℤ) : 0 ≤ f k := mul_nonneg (by positivity)
    (fourierOrbitMultiplier_nonneg R _ _)
  have hcover : (Icc (-(K : ℤ)) (K : ℤ)).erase 0 ⊆ s ∪ t := by
    intro k hk
    have hk' := mem_Icc.mp (mem_of_mem_erase hk)
    by_cases hk0 : 0 ≤ k
    · apply mem_union.mpr
      left
      apply mem_image.mpr
      refine ⟨k.toNat, mem_range.mpr ?_, Int.toNat_of_nonneg hk0⟩
      omega
    · apply mem_union.mpr
      right
      apply mem_image.mpr
      refine ⟨(-k).toNat, mem_range.mpr ?_, ?_⟩
      · omega
      · rw [Int.toNat_of_nonneg (by omega : 0 ≤ -k)]
        omega
  have hs : ∑ k ∈ s, f k = ∑ k ∈ range (K + 1), (k : ℝ)⁻¹ *
      fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) (k : ℤ) := by
    dsimp only [s]
    rw [sum_image]
    · simp only [f, Int.cast_natCast, Nat.abs_cast]
    · intro i _ j _ heq
      exact_mod_cast heq
  have ht : ∑ k ∈ t, f k = ∑ k ∈ range (K + 1), (k : ℝ)⁻¹ *
      fourierOrbitMultiplier R (α : AddCircle (1 : ℝ)) (k : ℤ) := by
    dsimp only [t]
    rw [sum_image]
    · simp only [f, Int.cast_neg, Int.cast_natCast, abs_neg,
        Nat.abs_cast, fourierOrbitMultiplier_neg]
    · intro i _ j _ heq
      exact_mod_cast neg_injective heq
  have hU : ∑ k ∈ s ∪ t, f k ≤ (∑ k ∈ s, f k) + ∑ k ∈ t, f k := by
    have heq := sum_union_inter (s₁ := s) (s₂ := t) (f := f)
    have hnn : 0 ≤ ∑ k ∈ s ∩ t, f k := sum_nonneg fun k _ => hf k
    linarith
  have hnat := rationalApprox_sum_weighted_multiplier_nonneg hq hcop happrox R hRq K hK
  have hlognonneg : 0 ≤ 1 + Real.log ((K : ℝ) + 1) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ (K : ℝ) + 1 from le_add_of_nonneg_left (Nat.cast_nonneg K))
    linarith
  simp only [one_div]
  calc
    _ ≤ ∑ k ∈ s ∪ t, f k := sum_le_sum_of_subset_of_nonneg hcover fun k _ _ => hf k
    _ ≤ (∑ k ∈ s, f k) + ∑ k ∈ t, f k := hU
    _ ≤ 2 * (4 * (q : ℝ) / R + (288 / (q : ℝ)) *
        (1 + Real.log ((K : ℝ) + 1))) := by rw [hs, ht]; linarith
    _ = 8 * ((q : ℝ) / R) + 576 * ((1 + Real.log ((K : ℝ) + 1)) / q) := by ring
    _ ≤ _ := by
      have hqr : 0 ≤ (q : ℝ) / R := by positivity
      have hLq : 0 ≤ (1 + Real.log ((K : ℝ) + 1)) / q := div_nonneg hlognonneg (by positivity)
      nlinarith

end UAMO.BourgainJitomirskaya

import UAMO.BJRotationArithmetic
import Mathlib.Analysis.PSeries
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Algebra.Order.BigOperators.Ring.Finset

noncomputable section

namespace UAMO.BourgainJitomirskaya

open Finset

theorem sum_nat_inv_sq_le_two (s : Finset ℕ) (hpos : ∀ n ∈ s, n ≠ 0) :
    ∑ n ∈ s, ((n : ℝ) ^ 2)⁻¹ ≤ 2 := by
  have hsub : s ⊆ Ioo 0 (s.sup id + 1) := by
    intro n hn
    exact mem_Ioo.mpr ⟨Nat.pos_of_ne_zero (hpos n hn),
      Nat.lt_succ_of_le (Finset.le_sup (f := id) hn)⟩
  calc
    _ ≤ ∑ n ∈ Ioo 0 (s.sup id + 1), ((n : ℝ) ^ 2)⁻¹ :=
      sum_le_sum_of_subset_of_nonneg hsub (by intro n _ _; positivity)
    _ ≤ 2 := by simpa using (sum_Ioo_inv_sq_le (α := ℝ) 0 (s.sup id + 1))

theorem floor_div_injective_of_separated {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    {δ : ℝ} (hδ : 0 < δ) (hzero : ∀ i ∈ s, 0 ≤ x i)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ |x i - x j|) :
    Set.InjOn (fun i => ⌊x i / δ⌋₊) (s : Set ι) := by
  intro i hi j hj heq
  by_contra hij
  have hloi := Nat.floor_le (div_nonneg (hzero i hi) hδ.le)
  have hloj := Nat.floor_le (div_nonneg (hzero j hj) hδ.le)
  have hhii := Nat.lt_floor_add_one (x i / δ)
  have hhij := Nat.lt_floor_add_one (x j / δ)
  dsimp only at heq
  rw [heq] at hloi hhii
  have hclose : |x i / δ - x j / δ| < 1 := abs_lt.mpr ⟨by linarith, by linarith⟩
  rw [← sub_div, abs_div, abs_of_pos hδ] at hclose
  have hlt : |x i - x j| < δ := by simpa using (div_lt_iff₀ hδ).mp hclose
  exact (not_lt_of_ge (hsep i hi j hj hij)) hlt

theorem sum_inv_sq_le_of_separated {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (x : ι → ℝ) {δ : ℝ} (hδ : 0 < δ)
    (hmin : ∀ i ∈ s, δ ≤ x i)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ |x i - x j|) :
    ∑ i ∈ s, (x i ^ 2)⁻¹ ≤ 2 / δ ^ 2 := by
  let f : ι → ℕ := fun i => ⌊x i / δ⌋₊
  have hzero : ∀ i ∈ s, 0 ≤ x i := fun i hi => hδ.le.trans (hmin i hi)
  have hinj : Set.InjOn f (s : Set ι) := floor_div_injective_of_separated s x hδ hzero hsep
  have hpositive : ∀ i ∈ s, 0 < f i := by
    intro i hi
    exact Nat.floor_pos.mpr ((le_div_iff₀ hδ).mpr (by simpa using hmin i hi))
  have hlabel : ∀ i ∈ s, δ * (f i : ℝ) ≤ x i := by
    intro i hi
    have h := Nat.floor_le (div_nonneg (hzero i hi) hδ.le)
    simpa only [mul_comm] using (le_div_iff₀ hδ).mp h
  have heach : ∀ i ∈ s, (x i ^ 2)⁻¹ ≤ (δ ^ 2)⁻¹ * ((f i : ℝ) ^ 2)⁻¹ := by
    intro i hi
    have hp : 0 < (f i : ℝ) := by exact_mod_cast hpositive i hi
    have hsq : (δ * (f i : ℝ)) ^ 2 ≤ x i ^ 2 := by
      simpa only [pow_two] using mul_self_le_mul_self (mul_nonneg hδ.le hp.le) (hlabel i hi)
    have h := one_div_le_one_div_of_le (sq_pos_of_pos (mul_pos hδ hp)) hsq
    simpa only [one_div, mul_pow, mul_inv_rev, mul_comm] using h
  have hsum : ∑ n ∈ s.image f, ((n : ℝ) ^ 2)⁻¹ ≤ 2 := by
    apply sum_nat_inv_sq_le_two
    intro n hn
    obtain ⟨i, hi, rfl⟩ := mem_image.mp hn
    exact ne_of_gt (hpositive i hi)
  calc
    _ ≤ ∑ i ∈ s, (δ ^ 2)⁻¹ * ((f i : ℝ) ^ 2)⁻¹ := sum_le_sum heach
    _ = (δ ^ 2)⁻¹ * ∑ n ∈ s.image f, ((n : ℝ) ^ 2)⁻¹ := by
      rw [mul_sum, sum_image hinj]
    _ ≤ (δ ^ 2)⁻¹ * 2 := mul_le_mul_of_nonneg_left hsum (by positivity)
    _ = 2 / δ ^ 2 := by ring

theorem sum_inv_sq_le_of_abs_separated {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (x : ι → ℝ) {δ : ℝ} (hδ : 0 < δ)
    (hmin : ∀ i ∈ s, δ ≤ |x i|)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ |x i - x j|) :
    ∑ i ∈ s, (x i ^ 2)⁻¹ ≤ 4 / δ ^ 2 := by
  classical
  have hp : ∑ i ∈ s.filter (fun i => 0 ≤ x i), (x i ^ 2)⁻¹ ≤ 2 / δ ^ 2 := by
    apply sum_inv_sq_le_of_separated _ x hδ
    · intro i hi
      obtain ⟨his, hix⟩ := mem_filter.mp hi
      simpa only [abs_of_nonneg hix] using hmin i his
    · intro i hi j hj hij
      exact hsep i (mem_filter.mp hi).1 j (mem_filter.mp hj).1 hij
  have hn : ∑ i ∈ s.filter (fun i => ¬0 ≤ x i), ((-x i) ^ 2)⁻¹ ≤ 2 / δ ^ 2 := by
    apply sum_inv_sq_le_of_separated _ (fun i => -x i) hδ
    · intro i hi
      obtain ⟨his, hix⟩ := mem_filter.mp hi
      simpa only [abs_of_neg (lt_of_not_ge hix)] using hmin i his
    · intro i hi j hj hij
      simpa only [neg_sub_neg, abs_sub_comm] using
        hsep i (mem_filter.mp hi).1 j (mem_filter.mp hj).1 hij
  simp only [neg_sq] at hn
  have heq := sum_filter_add_sum_filter_not s (fun i => 0 ≤ x i) (fun i => (x i ^ 2)⁻¹)
  rw [← heq]
  calc
    _ ≤ 2 / δ ^ 2 + 2 / δ ^ 2 := add_le_add hp hn
    _ = 4 / δ ^ 2 := by ring

theorem card_abs_lt_le_two_of_separated {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (x : ι → ℝ) {δ : ℝ} (hδ : 0 < δ)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ |x i - x j|) :
    (s.filter (fun i => |x i| < δ)).card ≤ 2 := by
  classical
  let t := s.filter (fun i => |x i| < δ)
  let f : ι → ℕ := fun i => ⌊(x i + δ) / δ⌋₊
  have hzero : ∀ i ∈ t, 0 ≤ x i + δ := by
    intro i hi
    have h := (abs_lt.mp (mem_filter.mp hi).2).1
    linarith
  have hshift : ∀ i ∈ t, ∀ j ∈ t, i ≠ j → δ ≤ |(x i + δ) - (x j + δ)| := by
    intro i hi j hj hij
    simpa only [add_sub_add_right_eq_sub] using
      hsep i (mem_filter.mp hi).1 j (mem_filter.mp hj).1 hij
  have hinj : Set.InjOn f (t : Set ι) :=
    floor_div_injective_of_separated t (fun i => x i + δ) hδ hzero hshift
  have hsub : t.image f ⊆ range 2 := by
    intro n hn
    obtain ⟨i, hi, rfl⟩ := mem_image.mp hn
    apply mem_range.mpr
    apply (Nat.floor_lt (div_nonneg (hzero i hi) hδ.le)).mpr
    have h := (abs_lt.mp (mem_filter.mp hi).2).2
    rw [div_lt_iff₀ hδ]
    norm_num
    linarith
  calc
    t.card = (t.image f).card := (card_image_of_injOn hinj).symm
    _ ≤ (range 2).card := card_le_card hsub
    _ = 2 := card_range 2

theorem sum_regularized_inv_sq_le_of_separated {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (x : ι → ℝ) {δ R : ℝ} (hδ : 0 < δ) (hR : 0 < R)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ |x i - x j|) :
    ∑ i ∈ s, (1 + (R * x i) ^ 2)⁻¹ ≤ 2 + 4 / (R * δ) ^ 2 := by
  classical
  have hnear : ∑ i ∈ s.filter (fun i => |x i| < δ),
      (1 + (R * x i) ^ 2)⁻¹ ≤ 2 := by
    calc
      _ ≤ ∑ _i ∈ s.filter (fun i => |x i| < δ), (1 : ℝ) := by
        apply sum_le_sum
        intro i _
        have h := one_div_le_one_div_of_le (show (0 : ℝ) < 1 by norm_num)
          (show (1 : ℝ) ≤ 1 + (R * x i) ^ 2 by nlinarith [sq_nonneg (R * x i)])
        simpa only [one_div, inv_one] using h
      _ = ((s.filter (fun i => |x i| < δ)).card : ℝ) := by simp
      _ ≤ 2 := by exact_mod_cast card_abs_lt_le_two_of_separated s x hδ hsep
  have hpack : ∑ i ∈ s.filter (fun i => ¬|x i| < δ), (x i ^ 2)⁻¹ ≤ 4 / δ ^ 2 := by
    apply sum_inv_sq_le_of_abs_separated _ x hδ
    · intro i hi
      exact le_of_not_gt (mem_filter.mp hi).2
    · intro i hi j hj hij
      exact hsep i (mem_filter.mp hi).1 j (mem_filter.mp hj).1 hij
  have hfar : ∑ i ∈ s.filter (fun i => ¬|x i| < δ),
      (1 + (R * x i) ^ 2)⁻¹ ≤ 4 / (R * δ) ^ 2 := by
    calc
      _ ≤ ∑ i ∈ s.filter (fun i => ¬|x i| < δ),
          (R ^ 2)⁻¹ * (x i ^ 2)⁻¹ := by
        apply sum_le_sum
        intro i hi
        have hx : x i ≠ 0 := by
          have hmin : δ ≤ |x i| := le_of_not_gt (mem_filter.mp hi).2
          exact abs_pos.mp (hδ.trans_le hmin)
        have hsq := sq_pos_of_ne_zero (mul_ne_zero hR.ne' hx)
        have h := one_div_le_one_div_of_le hsq
          (show (R * x i) ^ 2 ≤ 1 + (R * x i) ^ 2 by linarith)
        simpa only [one_div, mul_pow, mul_inv_rev, mul_comm] using h
      _ = (R ^ 2)⁻¹ * ∑ i ∈ s.filter (fun i => ¬|x i| < δ), (x i ^ 2)⁻¹ :=
        (mul_sum _ _ _).symm
      _ ≤ (R ^ 2)⁻¹ * (4 / δ ^ 2) := mul_le_mul_of_nonneg_left hpack (by positivity)
      _ = 4 / (R * δ) ^ 2 := by simp only [mul_pow, div_eq_mul_inv, mul_inv_rev]; ring
  have heq := sum_filter_add_sum_filter_not s (fun i => |x i| < δ)
    (fun i => (1 + (R * x i) ^ 2)⁻¹)
  rw [← heq]
  exact add_le_add hnear hfar

theorem rationalApprox_sum_centered_inv_sq {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (s : Finset ℤ) (hnonzero : ∀ k ∈ s, k ≠ 0)
    (hsmall : ∀ k ∈ s, 2 * |k| ≤ (q : ℤ))
    (hspan : ∀ k ∈ s, ∀ l ∈ s, 2 * |k - l| ≤ (q : ℤ)) :
    ∑ k ∈ s, (centeredFraction ((k : ℝ) * α) ^ 2)⁻¹ ≤ 16 * (q : ℝ) ^ 2 := by
  have hqR : (0 : ℝ) < (q : ℝ) := by exact_mod_cast (show 0 < q by omega)
  calc
    _ ≤ 4 / (1 / (2 * (q : ℝ))) ^ 2 := by
      apply sum_inv_sq_le_of_abs_separated _ _ (by positivity)
      · intro k hk
        exact (rationalApprox_centered_separation hq hcop happrox (hnonzero k hk) (hsmall k hk)).le
      · intro k hk l hl hkl
        simpa only [zero_add] using
          (rationalApprox_centered_pair_separation hq hcop happrox 0 hkl (hspan k hk l hl)).le
    _ = 16 * (q : ℝ) ^ 2 := by field_simp; ring

theorem rationalApprox_sum_regularized_centered {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (s : Finset ℤ) (hspan : ∀ k ∈ s, ∀ l ∈ s, 2 * |k - l| ≤ (q : ℤ))
    (x : ℝ) {R : ℝ} (hR : 0 < R) :
    ∑ k ∈ s, (1 + (R * centeredFraction (x + (k : ℝ) * α)) ^ 2)⁻¹ ≤
      2 + 16 * ((q : ℝ) / R) ^ 2 := by
  have hqR : (0 : ℝ) < (q : ℝ) := by exact_mod_cast (show 0 < q by omega)
  calc
    _ ≤ 2 + 4 / (R * (1 / (2 * (q : ℝ)))) ^ 2 := by
      apply sum_regularized_inv_sq_le_of_separated _ _ (by positivity) hR
      intro k hk l hl hkl
      exact (rationalApprox_centered_pair_separation hq hcop happrox x hkl (hspan k hk l hl)).le
    _ = 2 + 16 * ((q : ℝ) / R) ^ 2 := by field_simp; ring

theorem sum_int_inv_sq_le_four (s : Finset ℤ) (hnonzero : ∀ k ∈ s, k ≠ 0) :
    ∑ k ∈ s, ((k : ℝ) ^ 2)⁻¹ ≤ 4 := by
  have h : ∑ k ∈ s, ((k : ℝ) ^ 2)⁻¹ ≤ 4 / (1 : ℝ) ^ 2 := by
    apply sum_inv_sq_le_of_abs_separated s (fun k => (k : ℝ)) (by norm_num)
    · intro k hk
      have hpos : (0 : ℤ) < |k| := abs_pos.mpr (hnonzero k hk)
      have hle : (1 : ℤ) ≤ |k| := by omega
      exact_mod_cast hle
    · intro k _ l _ hkl
      have hpos : (0 : ℤ) < |k - l| := abs_pos.mpr (sub_ne_zero.mpr hkl)
      have hle : (1 : ℤ) ≤ |k - l| := by omega
      exact_mod_cast hle
  simpa using h

theorem rationalApprox_sum_weighted_centered_inv {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (s : Finset ℤ) (hnonzero : ∀ k ∈ s, k ≠ 0)
    (hsmall : ∀ k ∈ s, 2 * |k| ≤ (q : ℤ))
    (hspan : ∀ k ∈ s, ∀ l ∈ s, 2 * |k - l| ≤ (q : ℤ)) :
    ∑ k ∈ s, |(k : ℝ)|⁻¹ * |centeredFraction ((k : ℝ) * α)|⁻¹ ≤ 8 * (q : ℝ) := by
  have hkbound := sum_int_inv_sq_le_four s hnonzero
  have hpbound := rationalApprox_sum_centered_inv_sq hq hcop happrox s hnonzero hsmall hspan
  have hcs := sum_mul_sq_le_sq_mul_sq s (fun k => |(k : ℝ)|⁻¹)
    (fun k => |centeredFraction ((k : ℝ) * α)|⁻¹)
  simp only [inv_pow, sq_abs] at hcs
  have hbound := hcs.trans (mul_le_mul hkbound hpbound (by positivity) (by norm_num))
  have hsq : (∑ k ∈ s, |(k : ℝ)|⁻¹ * |centeredFraction ((k : ℝ) * α)|⁻¹) ^ 2 ≤
      (8 * (q : ℝ)) ^ 2 := by nlinarith [hbound]
  exact (sq_le_sq₀ (by positivity) (by positivity)).mp hsq

theorem rationalApprox_sum_weighted_centered_inv_of_quarter {α : ℝ} {a : ℤ} {q : ℕ}
    (hq : 2 ≤ q) (hcop : IsCoprime a (q : ℤ))
    (happrox : |α - (a : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2)
    (s : Finset ℤ) (hnonzero : ∀ k ∈ s, k ≠ 0)
    (hquarter : ∀ k ∈ s, 4 * |k| ≤ (q : ℤ)) :
    ∑ k ∈ s, |(k : ℝ)|⁻¹ * |centeredFraction ((k : ℝ) * α)|⁻¹ ≤ 8 * (q : ℝ) := by
  apply rationalApprox_sum_weighted_centered_inv hq hcop happrox s hnonzero
  · intro k hk
    have := hquarter k hk
    have := abs_nonneg k
    omega
  · intro k hk l hl
    have hkq := hquarter k hk
    have hlq := hquarter l hl
    have hab : |k - l| ≤ |k| + |l| := by
      simpa only [sub_zero, zero_sub, abs_neg] using abs_sub_le k 0 l
    omega

end UAMO.BourgainJitomirskaya

import UAMO.BJRotationArithmetic
import Mathlib.Analysis.Normed.Group.AddCircle
import Mathlib.NumberTheory.DiophantineApproximation.Basic
import Mathlib.RingTheory.Int.Basic
import Mathlib.Order.Filter.AtTopBot.Tendsto

noncomputable section

open Filter

namespace UAMO.BourgainJitomirskaya

def rotationError (α : ℝ) (q : ℕ) : ℝ :=
  ‖((q : ℝ) * α : AddCircle (1 : ℝ))‖

theorem rotationError_eq_abs_round (α : ℝ) (q : ℕ) :
    rotationError α q = |(q : ℝ) * α - (round ((q : ℝ) * α) : ℝ)| := by
  rw [rotationError, AddCircle.norm_eq]
  simp only [inv_one, one_mul, mul_one]

theorem continuous_rotationError (q : ℕ) : Continuous (fun α : ℝ => rotationError α q) :=
  ((AddCircle.continuous_mk' (1 : ℝ)).comp (continuous_const.mul continuous_id)).norm

theorem rotationError_le_abs_sub_int (α : ℝ) (q : ℕ) (a : ℤ) :
    rotationError α q ≤ |(q : ℝ) * α - (a : ℝ)| := by
  rw [rotationError_eq_abs_round]
  exact round_le _ _

theorem rotationError_pos {α : ℝ} (hα : Irrational α) {q : ℕ} (hq : 0 < q) :
    0 < rotationError α q := by
  rw [rotationError_eq_abs_round, abs_pos, sub_ne_zero]
  exact (hα.natCast_mul (Nat.ne_of_gt hq)).ne_int _

theorem exists_rotationError_le (α : ℝ) {M : ℕ} (hM : 0 < M) :
    ∃ q : ℕ, 0 < q ∧ q ≤ M ∧ rotationError α q ≤ 1 / ((M : ℝ) + 1) := by
  simpa only [rotationError_eq_abs_round] using
    Real.exists_nat_abs_mul_sub_round_le α hM

theorem exists_rotationError_lt (α : ℝ) {ε : ℝ} (hε : 0 < ε) :
    ∃ q : ℕ, 0 < q ∧ rotationError α q < ε := by
  obtain ⟨N, hN⟩ := exists_nat_one_div_lt hε
  obtain ⟨q, hq, _, herr⟩ := exists_rotationError_le α (Nat.succ_pos N)
  refine ⟨q, hq, herr.trans_lt (lt_of_le_of_lt ?_ hN)⟩
  apply one_div_le_one_div_of_le
  · positivity
  · exact add_le_add_right (Nat.cast_le.mpr (Nat.le_succ N)) 1

def rotationRecord (α : ℝ) (q : ℕ) : Prop :=
  0 < q ∧ ∀ k : ℕ, 0 < k → k < q → rotationError α q < rotationError α k

def firstSmall (α : ℝ) (ε : ℝ) (hε : 0 < ε) : ℕ :=
  Nat.find (exists_rotationError_lt α hε)

theorem firstSmall_pos (α : ℝ) (ε : ℝ) (hε : 0 < ε) : 0 < firstSmall α ε hε :=
  (Nat.find_spec (exists_rotationError_lt α hε)).1

theorem rotationError_firstSmall_lt (α : ℝ) (ε : ℝ) (hε : 0 < ε) :
    rotationError α (firstSmall α ε hε) < ε :=
  (Nat.find_spec (exists_rotationError_lt α hε)).2

theorem le_rotationError_of_lt_firstSmall (α : ℝ) (ε : ℝ) (hε : 0 < ε)
    {k : ℕ} (hk : 0 < k) (hkq : k < firstSmall α ε hε) : ε ≤ rotationError α k := by
  exact le_of_not_gt (fun h => Nat.find_min (exists_rotationError_lt α hε) hkq ⟨hk, h⟩)

theorem rotationRecord_firstSmall (α : ℝ) (ε : ℝ) (hε : 0 < ε) :
    rotationRecord α (firstSmall α ε hε) := by
  refine ⟨firstSmall_pos α ε hε, fun k hk hkq => ?_⟩
  exact (rotationError_firstSmall_lt α ε hε).trans_le
    (le_rotationError_of_lt_firstSmall α ε hε hk hkq)

theorem exists_pos_lt_rotationError_prefix {α : ℝ} (hα : Irrational α) (M : ℕ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℕ, 0 < k → k ≤ M → ε < rotationError α k := by
  induction M with
  | zero => exact ⟨1, zero_lt_one, fun k hk hk0 => by omega⟩
  | succ M ih =>
    obtain ⟨ε, hε, hprefix⟩ := ih
    refine ⟨min ε (rotationError α (M + 1) / 2),
      lt_min hε (div_pos (rotationError_pos hα (Nat.succ_pos M)) (by norm_num)), ?_⟩
    intro k hk hkM
    rcases Nat.eq_or_lt_of_le hkM with heq | hlt
    · subst k
      exact (min_le_right _ _).trans_lt (by
        have := rotationError_pos hα (Nat.succ_pos M)
        linarith)
    · exact (min_le_left _ _).trans_lt (hprefix k hk (by omega))

theorem exists_rotationRecord_gt {α : ℝ} (hα : Irrational α) (M : ℕ) :
    ∃ q : ℕ, M < q ∧ rotationRecord α q := by
  obtain ⟨ε, hε, hprefix⟩ := exists_pos_lt_rotationError_prefix hα M
  refine ⟨firstSmall α ε hε, ?_, rotationRecord_firstSmall α ε hε⟩
  by_contra h
  have := hprefix _ (firstSmall_pos α ε hε) (Nat.le_of_not_gt h)
  exact (not_lt_of_gt this) (rotationError_firstSmall_lt α ε hε)

def nextRotationRecord {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) : ℕ :=
  firstSmall α (rotationError α q) (rotationError_pos hα hq.1)

theorem rotationRecord_next {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) : rotationRecord α (nextRotationRecord hα hq) :=
  rotationRecord_firstSmall _ _ _

theorem rotationError_next_lt {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) : rotationError α (nextRotationRecord hα hq) < rotationError α q :=
  rotationError_firstSmall_lt _ _ _

theorem lt_nextRotationRecord {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) : q < nextRotationRecord hα hq := by
  have hn := rotationRecord_next hα hq
  have he := rotationError_next_lt hα hq
  by_contra h
  rcases Nat.eq_or_lt_of_le (Nat.le_of_not_gt h) with heq | hlt
  · exact (lt_irrefl _) (heq ▸ he)
  · exact (not_lt_of_gt (hq.2 _ hn.1 hlt)) he

theorem rotationError_le_inv_next {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) :
    rotationError α q ≤ 1 / (nextRotationRecord hα hq : ℝ) := by
  have hlt := lt_nextRotationRecord hα hq
  have hn : 0 < nextRotationRecord hα hq - 1 := by have := hq.1; omega
  obtain ⟨k, hk, hkN, herr⟩ := exists_rotationError_le α hn
  have hmin := le_rotationError_of_lt_firstSmall α (rotationError α q)
    (rotationError_pos hα hq.1) hk (show k < nextRotationRecord hα hq by omega)
  have hcast : ((nextRotationRecord hα hq - 1 : ℕ) : ℝ) + 1 =
      (nextRotationRecord hα hq : ℝ) := by
    exact_mod_cast (show nextRotationRecord hα hq - 1 + 1 = nextRotationRecord hα hq by omega)
  exact hmin.trans (by simpa only [hcast] using herr)

def rotationNumerator (α : ℝ) (q : ℕ) : ℤ := round ((q : ℝ) * α)

theorem rotationRecord_coprime {α : ℝ} {q : ℕ} (hq : rotationRecord α q) :
    (rotationNumerator α q).natAbs.Coprime q := by
  classical
  let a := rotationNumerator α q
  let d := Nat.gcd a.natAbs q
  change d = 1
  have hdq : d ∣ q := Nat.gcd_dvd_right _ _
  have hda : (d : ℤ) ∣ a := Int.natCast_dvd.mpr (Nat.gcd_dvd_left _ _)
  obtain ⟨k, hk⟩ := hdq
  obtain ⟨m, hm⟩ := hda
  have hd : 0 < d := by
    by_contra h
    have hd0 : d = 0 := by omega
    have hqpos := hq.1
    simp [hd0] at hk
    omega
  have hkpos : 0 < k := by
    by_contra h
    have hk0 : k = 0 := by omega
    have hqpos := hq.1
    simp [hk0] at hk
    omega
  by_contra hd1
  have hd2 : 2 ≤ d := by omega
  have hklt : k < q := by nlinarith
  have hdR : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast (show 1 ≤ d by omega)
  have hscale : rotationError α q = (d : ℝ) * |(k : ℝ) * α - (m : ℝ)| := by
    rw [rotationError_eq_abs_round]
    change |(q : ℝ) * α - (a : ℝ)| = _
    rw [hk, hm, Nat.cast_mul, Int.cast_mul, Int.cast_natCast]
    rw [show (d : ℝ) * (k : ℝ) * α - (d : ℝ) * (m : ℝ) =
      (d : ℝ) * ((k : ℝ) * α - (m : ℝ)) by ring, abs_mul, abs_of_nonneg (Nat.cast_nonneg d)]
  have hle : rotationError α k ≤ rotationError α q := by
    calc
      _ ≤ |(k : ℝ) * α - (m : ℝ)| := rotationError_le_abs_sub_int α k m
      _ ≤ (d : ℝ) * |(k : ℝ) * α - (m : ℝ)| := by
        nlinarith [abs_nonneg ((k : ℝ) * α - (m : ℝ))]
      _ = _ := hscale.symm
  exact (not_le_of_gt (hq.2 k hkpos hklt)) hle

theorem rotationRecord_isCoprime {α : ℝ} {q : ℕ} (hq : rotationRecord α q) :
    IsCoprime (rotationNumerator α q) (q : ℤ) := by
  apply Int.isCoprime_iff_nat_coprime.mpr
  simpa only [Int.natAbs_natCast] using rotationRecord_coprime hq

theorem rotationApprox_error_eq (α : ℝ) {q : ℕ} (hq : 0 < q) :
    |α - (rotationNumerator α q : ℝ) / (q : ℝ)| = rotationError α q / (q : ℝ) := by
  have hqR : (0 : ℝ) < (q : ℝ) := Nat.cast_pos.mpr hq
  rw [rotationError_eq_abs_round]
  calc
    _ = |((q : ℝ) * α - (rotationNumerator α q : ℝ)) / (q : ℝ)| := by
      congr 1
      field_simp
      ring
    _ = _ := by rw [abs_div, abs_of_pos hqR]; rfl

theorem rotationRecord_approx_le {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) :
    |α - (rotationNumerator α q : ℝ) / (q : ℝ)| ≤
      1 / ((q : ℝ) * (nextRotationRecord hα hq : ℝ)) := by
  rw [rotationApprox_error_eq α hq.1]
  calc
    _ ≤ (1 / (nextRotationRecord hα hq : ℝ)) / (q : ℝ) :=
      div_le_div_of_nonneg_right (rotationError_le_inv_next hα hq) (Nat.cast_nonneg q)
    _ = _ := by rw [div_div, mul_comm]

theorem rotationRecord_approx_lt {α : ℝ} (hα : Irrational α) {q : ℕ}
    (hq : rotationRecord α q) :
    |α - (rotationNumerator α q : ℝ) / (q : ℝ)| < 1 / (q : ℝ) ^ 2 := by
  apply (rotationRecord_approx_le hα hq).trans_lt
  have hqR : (0 : ℝ) < (q : ℝ) := Nat.cast_pos.mpr hq.1
  have hnR : (q : ℝ) < (nextRotationRecord hα hq : ℝ) :=
    Nat.cast_lt.mpr (lt_nextRotationRecord hα hq)
  apply one_div_lt_one_div_of_lt (by positivity)
  nlinarith

private def rotationRecordStep {α : ℝ} (hα : Irrational α)
    (q : {q : ℕ // rotationRecord α q}) : {q : ℕ // rotationRecord α q} :=
  ⟨nextRotationRecord hα q.property, rotationRecord_next hα q.property⟩

def rotationRecordSeq {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) (j : ℕ) : ℕ :=
  ((rotationRecordStep hα)^[j] ⟨q₀, hq₀⟩).val

@[simp]
theorem rotationRecordSeq_zero {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) : rotationRecordSeq hα hq₀ 0 = q₀ := rfl

theorem rotationRecordSeq_record {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) (j : ℕ) : rotationRecord α (rotationRecordSeq hα hq₀ j) :=
  ((rotationRecordStep hα)^[j] ⟨q₀, hq₀⟩).property

@[simp]
theorem rotationRecordSeq_succ {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) (j : ℕ) :
    rotationRecordSeq hα hq₀ (j + 1) =
      nextRotationRecord hα (rotationRecordSeq_record hα hq₀ j) := by
  simp only [rotationRecordSeq, Function.iterate_succ_apply', rotationRecordStep]

theorem rotationRecordSeq_strictMono {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) : StrictMono (rotationRecordSeq hα hq₀) := by
  apply strictMono_nat_of_lt_succ
  intro j
  rw [rotationRecordSeq_succ]
  exact lt_nextRotationRecord hα (rotationRecordSeq_record hα hq₀ j)

theorem rotationRecordSeq_isCoprime {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) (j : ℕ) :
    IsCoprime (rotationNumerator α (rotationRecordSeq hα hq₀ j))
      (rotationRecordSeq hα hq₀ j : ℤ) :=
  rotationRecord_isCoprime (rotationRecordSeq_record hα hq₀ j)

theorem rotationRecordSeq_approx_le {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) (j : ℕ) :
    |α - (rotationNumerator α (rotationRecordSeq hα hq₀ j) : ℝ) /
      (rotationRecordSeq hα hq₀ j : ℝ)| ≤
      1 / ((rotationRecordSeq hα hq₀ j : ℝ) * (rotationRecordSeq hα hq₀ (j + 1) : ℝ)) := by
  rw [rotationRecordSeq_succ]
  exact rotationRecord_approx_le hα (rotationRecordSeq_record hα hq₀ j)

theorem rotationRecordSeq_approx_lt {α : ℝ} (hα : Irrational α) {q₀ : ℕ}
    (hq₀ : rotationRecord α q₀) (j : ℕ) :
    |α - (rotationNumerator α (rotationRecordSeq hα hq₀ j) : ℝ) /
      (rotationRecordSeq hα hq₀ j : ℝ)| < 1 / (rotationRecordSeq hα hq₀ j : ℝ) ^ 2 :=
  rotationRecord_approx_lt hα (rotationRecordSeq_record hα hq₀ j)

theorem isOpen_rotationRecord (q : ℕ) : IsOpen {α : ℝ | rotationRecord α q} := by
  by_cases hq : 0 < q
  · have heq : {α : ℝ | rotationRecord α q} =
        ⋂ k ∈ Finset.Ico 1 q, {α : ℝ | rotationError α q < rotationError α k} := by
      ext α
      simp only [rotationRecord, hq, true_and, Set.mem_setOf_eq, Set.mem_iInter,
        Finset.mem_Ico]
      constructor
      · intro h k hk
        exact h k (by omega) hk.2
      · intro h k hk hkq
        exact h k ⟨by omega, hkq⟩
    rw [heq]
    exact isOpen_biInter_finset fun k _ =>
      isOpen_lt (continuous_rotationError q) (continuous_rotationError k)
  · have heq : {α : ℝ | rotationRecord α q} = ∅ := by
      ext α
      simp [rotationRecord, hq]
    rw [heq]
    exact isOpen_empty

end UAMO.BourgainJitomirskaya

import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Module

namespace UAMO

noncomputable section

def coupling (a : ℝ) : ℝ := 2 * a / (1 + a ^ 2)

def complementaryCoupling (a : ℝ) : ℝ := (1 - a ^ 2) / (1 + a ^ 2)

theorem coupling_square_identity (a : ℝ) :
    coupling a ^ 2 + complementaryCoupling a ^ 2 = 1 := by
  have h : (1 + a ^ 2 : ℝ) ≠ 0 := by positivity
  unfold coupling complementaryCoupling
  field_simp
  ring

theorem complementaryCoupling_nonneg {a : ℝ} (ha : 0 ≤ a) (ha1 : a ≤ 1) :
    0 ≤ complementaryCoupling a := by
  unfold complementaryCoupling
  apply div_nonneg
  · nlinarith
  · positivity

theorem complementaryCoupling_eq_sqrt {a : ℝ} (ha : 0 ≤ a) (ha1 : a ≤ 1) :
    Real.sqrt (1 - coupling a ^ 2) = complementaryCoupling a := by
  have hsq : 1 - coupling a ^ 2 = complementaryCoupling a ^ 2 := by
    nlinarith [coupling_square_identity a]
  rw [hsq, Real.sqrt_sq_eq_abs, abs_of_nonneg (complementaryCoupling_nonneg ha ha1)]

theorem coupling_pos {a : ℝ} (ha : 0 < a) : 0 < coupling a := by
  unfold coupling
  positivity

def realTransferNumerator (a lam t x : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![a * (Real.cos t - lam * Real.sin x), -a * Real.sin t;
    a⁻¹ * Real.sin t, a⁻¹ * (Real.cos t + lam * Real.sin x)]

theorem realTransferNumerator_det {a : ℝ} (ha : a ≠ 0) (lam t x : ℝ) :
    (realTransferNumerator a lam t x).det = 1 - lam ^ 2 * Real.sin x ^ 2 := by
  have hm : a * a⁻¹ = 1 := mul_inv_cancel₀ ha
  calc
    (realTransferNumerator a lam t x).det =
        (a * a⁻¹) * (Real.cos t ^ 2 + Real.sin t ^ 2 - lam ^ 2 * Real.sin x ^ 2) := by
      simp only [realTransferNumerator, Matrix.det_fin_two_of]
      ring
    _ = 1 - lam ^ 2 * Real.sin x ^ 2 := by
      rw [hm, one_mul]
      nlinarith [Real.sin_sq_add_cos_sq t]

theorem realTransferNumerator_det_pos {a lam : ℝ} (ha : a ≠ 0)
    (hlam : 0 ≤ lam) (hlam1 : lam < 1) (t x : ℝ) :
    0 < (realTransferNumerator a lam t x).det := by
  rw [realTransferNumerator_det ha]
  have hs : Real.sin x ^ 2 ≤ 1 := by
    nlinarith [Real.sin_sq_add_cos_sq x, sq_nonneg (Real.cos x)]
  have hp := mul_le_mul_of_nonneg_left hs (sq_nonneg lam)
  nlinarith

end

end UAMO

import UAMO.BoundarySeedResolvent
import UAMO.UnitCircleScalarCorrespondence
import UAMO.GapProjectionTrace
import UAMO.PhysicalDOSLabels
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Inverse
import UAMO.FreePhysicalDOS
import UAMO.ScalarIDSContinuity
import UAMO.ScalarGapInternality
import UAMO.ScalarInternalSeed
import UAMO.CircleArcLabel
import UAMO.PhysicalCircleReflection
import UAMO.UAMOGapLabels

noncomputable section
namespace UAMO
open Set MeasureTheory CircleDOS PhysicalDOS CMV

theorem circle_realPart_internal_cut (ν : Measure ℂ) [IsProbabilityMeasure ν]
    [NoAtoms ν] (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) {x : ℝ}
    (hx : (ν.map Complex.re).real (Iio x) ∈ Ioo (0:ℝ) 1) :
    x ∈ Ioo (-1:ℝ) 1 := by
  have hs := realPart_ae_Ioo ν hc
  letI : IsProbabilityMeasure (ν.map Complex.re) :=
    isProbabilityMeasure_map Complex.continuous_re.measurable.aemeasurable
  constructor
  · by_contra! hle
    have he : Iio x =ᵐ[ν.map Complex.re] (∅ : Set ℝ) := by
      filter_upwards [hs] with y hy
      apply propext
      change (y<x) ↔ False
      exact iff_false_intro (not_lt_of_ge (hle.trans hy.1.le))
    have hz := measureReal_congr he
    rw [measureReal_empty] at hz
    linarith [hx.1]
  · by_contra! hle
    have he : Iio x =ᵐ[ν.map Complex.re] (univ : Set ℝ) := by
      filter_upwards [hs] with y hy
      apply propext
      change (y<x) ↔ True
      exact iff_true_intro (hy.2.trans_le hle)
    have hz := measureReal_congr he
    rw [measureReal_univ_eq_one] at hz
    linarith [hx.2]

theorem scalar_internal_normalized_bound {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (Φ E : ℝ)
    (hIDS : scalarIDS a r (-Real.pi*Φ) E ∈ Ioo (0:ℝ) 1) :
    (a/((1+a^2)*(1+r^2)))*E ∈ Ioo (-1:ℝ) 1 := by
  letI := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 Φ
  apply circle_realPart_internal_cut (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1)
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1)
  rwa [physicalRealPartIDS_eq_scalarIDS ha ha1 hr hr1 Φ E]

theorem upperLift_norm_of_mem_Icc {x : ℝ} (hx : x ∈ Icc (-1:ℝ) 1) :
    ‖upperLift x‖=1 := by
  have hs : 0≤1-x^2 := by nlinarith [hx.1,hx.2]
  have hn : ‖upperLift x‖^2=1 := by
    rw [← Complex.normSq_eq_norm_sq]
    simp only [Complex.normSq_apply,upperLift]
    nlinarith [Real.sq_sqrt hs]
  nlinarith [norm_nonneg (upperLift x)]

theorem scalarEnergyOfCircle_upperLift {a : ℝ} (ha : a≠0) (r E : ℝ) :
    scalarEnergyOfCircle a r (upperLift ((a/((1+a^2)*(1+r^2)))*E))=E := by
  have hM : (1+a^2)*(1+r^2)≠0 := by positivity
  simp only [scalarEnergyOfCircle,upperLift_re]
  field_simp
  ring

theorem scalar_internal_circle_lift {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (Φ E u : ℝ) (hu : u∈Ioo (0:ℝ) 1)
    (huHalf : u≠1/2) (hIDS : scalarIDS a r (-Real.pi*Φ) E=|1-2*u|) :
    ∃z:ℂ, ‖z‖=1 ∧ z.im≠0 ∧ scalarEnergyOfCircle a r z=E ∧
      arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z=u := by
  have hlabel : scalarIDS a r (-Real.pi*Φ) E∈Ioo (0:ℝ) 1 := by
    rw [hIDS]
    exact ⟨abs_pos.mpr (by intro h; apply huHalf; linarith),
      abs_lt.mpr ⟨by linarith [hu.2],by linarith [hu.1]⟩⟩
  let x := (a/((1+a^2)*(1+r^2)))*E
  have hx : x∈Ioo (-1:ℝ) 1 := scalar_internal_normalized_bound ha ha1 hr hr1 Φ E hlabel
  have hnorm : ‖upperLift x‖=1 := upperLift_norm_of_mem_Icc ⟨hx.1.le,hx.2.le⟩
  have hpos : 0<(upperLift x).im := sqrt_circle_height_pos hx
  have hE : scalarEnergyOfCircle a r (upperLift x)=E :=
    scalarEnergyOfCircle_upperLift ha.ne' r E
  rcases lt_or_gt_of_ne huHalf with hlt | hgt
  · refine ⟨upperLift x,hnorm,ne_of_gt hpos,hE,?_⟩
    rw [physical_arcLabel_upper ha ha1 hr hr1 Φ hpos,hE,hIDS,
      abs_of_nonneg (by linarith : 0≤1-2*u)]
    ring
  · have hneg : (star (upperLift x)).im<0 := by change -(upperLift x).im<0; linarith
    refine ⟨star (upperLift x),by simpa only [norm_star] using hnorm,
      ne_of_lt hneg,by simpa only [scalarEnergyOfCircle_star] using hE,?_⟩
    rw [physical_arcLabel_lower ha ha1 hr hr1 Φ hneg,scalarEnergyOfCircle_star,hE,hIDS,
      abs_of_nonpos (by linarith : 1-2*u≤0)]
    ring

end UAMO

namespace UAMO.BoundarySeed
open Set CircleDOS PhysicalDOS

end UAMO.BoundarySeed

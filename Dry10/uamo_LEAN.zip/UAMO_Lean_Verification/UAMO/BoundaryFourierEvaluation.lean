import UAMO.BoundaryFourierFirstSeed
import Mathlib.Algebra.BigOperators.Finprod

noncomputable section
namespace UAMO.BoundarySeed
open Matrix Function Set
open scoped BigOperators

def fourierEval (f : ℤ→ℂ) (x : ℝ) : ℂ := ∑ᶠ k, f k*(weylPhase x)^k

def fourierEvaluation (v : FourierVector) (x : ℝ) : Fin 2→ℂ :=
  fun s => fourierEval (v s) x

theorem finite_support_mul_left {f : ℤ→ℂ} (hf : (support f).Finite) (g : ℤ→ℂ) :
    (support (fun k => f k*g k)).Finite := by
  apply hf.subset
  intro k hk
  contrapose! hk
  simp only [mem_support,not_not] at hk ⊢
  rw [hk,zero_mul]

theorem finite_support_translate {f : ℤ→ℂ} (hf : (support f).Finite) (j : ℤ) :
    (support (fun k => f (k+j))).Finite := by
  exact hf.preimage (Equiv.addRight j).injective.injOn

theorem fourierEval_add {f g : ℤ→ℂ} (hf : (support f).Finite) (hg : (support g).Finite)
    (x : ℝ) : fourierEval (fun k => f k+g k) x=fourierEval f x+fourierEval g x := by
  simp only [fourierEval,add_mul]
  exact finsum_add_distrib (finite_support_mul_left hf _) (finite_support_mul_left hg _)

theorem fourierEval_const_mul {f : ℤ→ℂ} (hf : (support f).Finite) (c : ℂ) (x : ℝ) :
    fourierEval (fun k => c*f k) x=c*fourierEval f x := by
  simp only [fourierEval,mul_assoc]
  exact (mul_finsum _ c (finite_support_mul_left hf _)).symm

theorem fourierEval_sub {f g : ℤ→ℂ} (hf : (support f).Finite) (hg : (support g).Finite)
    (x : ℝ) : fourierEval (fun k => f k-g k) x=fourierEval f x-fourierEval g x := by
  simp only [fourierEval,sub_mul]
  exact finsum_sub_distrib (finite_support_mul_left hf _) (finite_support_mul_left hg _)

theorem fourierEval_translate {f : ℤ→ℂ} (hf : (support f).Finite) (j : ℤ) (x : ℝ) :
    fourierEval (fun k => f (k+j)) x=(weylPhase x)^(-j)*fourierEval f x := by
  have hw : weylPhase x≠0 := Complex.exp_ne_zero _
  have hs := finite_support_mul_left (finite_support_translate hf j) (fun k => weylPhase x^k)
  have he : fourierEval (fun k => f (k+j)) x*(weylPhase x)^j = fourierEval f x := by
    rw [fourierEval,finsum_mul _ _ hs]
    apply finsum_eq_of_bijective (fun k : ℤ => k+j) (Equiv.addRight j).bijective
    intro k
    rw [zpow_add₀ hw]
    ring
  have hj : (weylPhase x)^j≠0 := zpow_ne_zero _ hw
  apply (mul_left_inj' hj).mp
  rw [he,zpow_neg]
  field_simp

theorem fourierEval_phase_shift (f : ℤ→ℂ) (α x : ℝ) :
    fourierEval f (x+α)=fourierEval (fun k => (weylPhase α)^k*f k) x := by
  unfold fourierEval
  apply finsum_congr
  intro k
  rw [weylPhase_add,mul_zpow]
  ring

theorem fourierEval_sineCoupling (v : FourierVector)
    (hv : ∀ s,(support (v s)).Finite) (x : ℝ) (s : Fin 2) :
    fourierEval (sineCoupling v s) x =
      -(Real.sin (2*Real.pi*x) : ℂ)*fourierEval (v (1-s)) x := by
  have hp := finite_support_translate (hv (1-s)) 1
  have hm := finite_support_translate (hv (1-s)) (-1)
  have hdiff : (support (fun k => v (1-s) (k+1)-v (1-s) (k-1))).Finite := by
    apply (hp.union hm).subset
    intro k hk
    by_contra h
    simp only [mem_union,mem_support,not_or,not_not] at h
    have h2 : v (1-s) (k-1)=0 := by simpa [sub_eq_add_neg] using h.2
    simp [mem_support,h.1,h2] at hk
  change fourierEval (fun k => (v (1-s) (k+1)-v (1-s) (k-1))/(2*Complex.I)) x = _
  simp only [div_eq_mul_inv,mul_comm _ (2*Complex.I)⁻¹]
  rw [fourierEval_const_mul hdiff]
  rw [fourierEval_sub hp (by simpa [sub_eq_add_neg] using hm)]
  rw [fourierEval_translate (hv (1-s)) 1,
    show (fun k => v (1-s) (k-1))=(fun k => v (1-s) (k+(-1))) by rfl,
    fourierEval_translate (hv (1-s)) (-1)]
  rw [sine_fourier]
  simp only [zpow_neg,zpow_one,neg_neg]
  ring

def centeredFourierResidual (lam : ℝ) (z μ q : ℂ) (v : FourierVector) : FourierVector :=
  fun s k => (diagonalValue z s-μ*q^k)*v s k+(lam : ℂ)*sineCoupling v s k

theorem sineCoupling_finite_support (v : FourierVector)
    (hv : ∀ s,(support (v s)).Finite) (s : Fin 2) :
    (support (sineCoupling v s)).Finite := by
  apply ((finite_support_translate (hv (1-s)) 1).union
    (finite_support_translate (hv (1-s)) (-1))).subset
  intro k hk
  by_contra h
  simp only [mem_union,mem_support,not_or,not_not] at h
  have h2 : v (1-s) (k-1)=0 := by simpa [sub_eq_add_neg] using h.2
  simp [mem_support,sineCoupling,h.1,h2] at hk

theorem fourierEvaluation_centeredResidual (lam α x : ℝ) (z μ : ℂ) (v : FourierVector)
    (hv : ∀ s,(support (v s)).Finite) :
    fourierEvaluation (centeredFourierResidual lam z μ (weylPhase α) v) x =
      boundaryNumerator lam z x*ᵥfourierEvaluation v x-
        μ • fourierEvaluation v (x+α) := by
  have hdiag (s : Fin 2) : (support (fun k =>
      (diagonalValue z s-μ*(weylPhase α)^k)*v s k)).Finite := by
    simpa only [mul_comm] using finite_support_mul_left (hv s)
      (fun k => diagonalValue z s-μ*(weylPhase α)^k)
  have hsine (s : Fin 2) : (support (fun k => (lam : ℂ)*sineCoupling v s k)).Finite := by
    simpa only [mul_comm] using finite_support_mul_left (sineCoupling_finite_support v hv s)
      (fun _ => (lam : ℂ))
  have hweight (s : Fin 2) : (support (fun k => (weylPhase α)^k*v s k)).Finite := by
    simpa only [mul_comm] using finite_support_mul_left (hv s) (fun k => (weylPhase α)^k)
  have hd (s : Fin 2) : fourierEval
      (fun k => (diagonalValue z s-μ*(weylPhase α)^k)*v s k) x =
      diagonalValue z s*fourierEval (v s) x-μ*fourierEval (v s) (x+α) := by
    have hf : (support (fun k => diagonalValue z s*v s k)).Finite := by
      simpa only [mul_comm] using finite_support_mul_left (hv s) (fun _ => diagonalValue z s)
    have hg : (support (fun k => μ*((weylPhase α)^k*v s k))).Finite := by
      simpa only [mul_comm] using finite_support_mul_left (hweight s) (fun _ => μ)
    simp only [sub_mul,mul_assoc]
    rw [fourierEval_sub hf hg,fourierEval_const_mul (hv s),
      fourierEval_const_mul (hweight s),← fourierEval_phase_shift]
  have he (s : Fin 2) : fourierEvaluation
      (centeredFourierResidual lam z μ (weylPhase α) v) x s =
      diagonalValue z s*fourierEval (v s) x-
        μ*fourierEval (v s) (x+α)-
        (lam : ℂ)*(Real.sin (2*Real.pi*x) : ℂ)*fourierEval (v (1-s)) x := by
    change fourierEval (fun k => (diagonalValue z s-μ*(weylPhase α)^k)*v s k+
      (lam : ℂ)*sineCoupling v s k) x = _
    rw [fourierEval_add (hdiag s) (hsine s),hd,
      fourierEval_const_mul (sineCoupling_finite_support v hv s),fourierEval_sineCoupling v hv]
    ring
  ext s
  rw [he]
  fin_cases s <;>
    simp [boundaryNumerator,fourierEvaluation,diagonalValue,mulVec,dotProduct,Fin.sum_univ_two]
  all_goals ring

end UAMO.BoundarySeed

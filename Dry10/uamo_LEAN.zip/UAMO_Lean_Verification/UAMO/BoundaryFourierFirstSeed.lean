import UAMO.BoundaryFourierSeed

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

theorem weylPhase_add (x y : ℝ) : weylPhase (x+y)=weylPhase x*weylPhase y := by
  unfold weylPhase
  rw [← Complex.exp_add]
  congr 1
  push_cast
  ring

theorem sine_fourier (x : ℝ) :
    (Real.sin (2*Real.pi*x) : ℂ) =
      (weylPhase x-(weylPhase x)⁻¹)/(2*Complex.I) := by
  rw [Complex.ofReal_sin]
  unfold Complex.sin weylPhase
  rw [neg_mul, Complex.exp_neg]
  field_simp
  ring_nf
  simp only [Complex.I_sq]
  ring

def firstCenter (α : ℝ) (ell : ℤ) : ℝ := Real.pi*(α+ell)

def firstCenterPhase (α : ℝ) (ell : ℤ) : ℂ :=
  Complex.exp ((firstCenter α ell : ℂ)*Complex.I)

theorem firstCenterPhase_square (α : ℝ) (ell : ℤ) :
    firstCenterPhase α ell ^ 2 = weylPhase α := by
  unfold firstCenterPhase firstCenter weylPhase
  rw [← Complex.exp_nat_mul]
  have he : (2 : ℂ)*((Real.pi*(α+(ell : ℝ)) : ℝ)*Complex.I)=
      ((2*Real.pi*α : ℝ) : ℂ)*Complex.I + (ell : ℂ)*(2*Real.pi*Complex.I) := by
    push_cast
    ring
  norm_num only [Nat.cast_ofNat]
  rw [he,Complex.exp_add]
  have hp : Complex.exp ((ell : ℂ)*(2*Real.pi*Complex.I))=1 := by
    apply Complex.exp_eq_one_iff.mpr
    exact ⟨ell,by ring⟩
  rw [hp,mul_one]

end UAMO.BoundarySeed

import UAMO.SeedEigenpolynomial
import UAMO.CMVTransfer

noncomputable section
namespace UAMO.BoundarySeed
open scoped BigOperators
open Matrix

abbrev FourierVector := Fin 2 → ℤ → ℂ

def diagonalValue (z : ℂ) (s : Fin 2) : ℂ := if s = 0 then z else z⁻¹

def divisor (z q : ℂ) (s : Fin 2) (k : ℤ) : ℂ :=
  diagonalValue z s - z * q ^ k

def sineCoupling (v : FourierVector) : FourierVector :=
  fun s k => (v (1-s) (k+1) - v (1-s) (k-1)) / (2*Complex.I)

theorem divisor_zero_eq {z q : ℂ} (hz : z ≠ 0) (hq : NoIntegerResonance q)
    (k : ℤ) : divisor z q 0 k = 0 ↔ k = 0 := by
  simp only [divisor, diagonalValue, if_pos rfl]
  constructor
  · intro h
    have hpow : q ^ k = 1 := by
      apply (mul_left_cancel₀ hz)
      simpa only [mul_one] using (sub_eq_zero.mp h).symm
    by_contra hk
    exact hq k hk hpow
  · rintro rfl
    simp

theorem divisor_one_eq {z q : ℂ} (hz : z ≠ 0) (hq0 : q ≠ 0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : z^2=q^m) (k : ℤ) :
    divisor z q 1 k = 0 ↔ k = -(m : ℤ) := by
  simp only [divisor, diagonalValue, show (1 : Fin 2) ≠ 0 by decide, if_false]
  have hmul : z * (z * q^k) = q^((m : ℤ)+k) := by
    rw [← mul_assoc, ← pow_two, hres, ← zpow_natCast, ← zpow_add₀ hq0]
  constructor
  · intro h
    have hh := congrArg (z * ·) (sub_eq_zero.mp h)
    dsimp only at hh
    rw [mul_inv_cancel₀ hz, hmul] at hh
    have hk : (m : ℤ)+k=0 := by
      by_contra hh0
      exact hq _ hh0 hh.symm
    omega
  · intro hk
    apply sub_eq_zero.mpr
    apply mul_left_cancel₀ hz
    rw [mul_inv_cancel₀ hz, hmul, hk, add_neg_cancel, zpow_zero]

theorem divisor_ne_zero {z q : ℂ} (hz : z ≠ 0) (hq0 : q ≠ 0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : z^2=q^m)
    (s : Fin 2) (k : ℤ) (hk : ¬ (s=0 ∧ k=0) ∧ ¬ (s=1 ∧ k=-(m : ℤ))) :
    divisor z q s k ≠ 0 := by
  fin_cases s
  · exact fun h => hk.1 ⟨rfl, (divisor_zero_eq hz hq k).mp h⟩
  · exact fun h => hk.2 ⟨rfl, (divisor_one_eq hz hq0 hq m hres k).mp h⟩

def correction (z q : ℂ) (m : ℕ) (F : FourierVector) : FourierVector :=
  fun s k => if (s=0 ∧ k=0) ∨ (s=1 ∧ k=-(m : ℤ)) then 0
    else -F s k / divisor z q s k

def boundaryNumerator (lam : ℝ) (z : ℂ) (x : ℝ) : CMV.TransferMatrix :=
  !![z, -(lam*Real.sin (2*Real.pi*x) : ℝ);
    -(lam*Real.sin (2*Real.pi*x) : ℝ), z⁻¹]

theorem boundaryNumerator_eq_szegoCell (r x : ℝ) {z : ℂ} (hz : z ≠ 0) :
    boundaryNumerator (coupling r) z x =
      z⁻¹ • CMV.szegoCell 1 0 (CMV.oddAlpha r (2*Real.pi*x)) 1 z := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [boundaryNumerator, CMV.szegoCell, CMV.szegoStep, CMV.szegoNumerator,
      CMV.oddAlpha, Matrix.mul_apply, Fin.sum_univ_two, hz] <;> try field_simp
  left
  simpa only [Complex.ofReal_sin,Complex.ofReal_mul,Complex.ofReal_ofNat] using
    (Complex.conj_ofReal (Real.sin (2*Real.pi*x))).symm

end UAMO.BoundarySeed

import UAMO.BoundaryFourierSeed
import Mathlib.Algebra.Polynomial.Inductions
import UAMO.BoundaryFourierFirstSeed
import UAMO.BoundaryFourierEvaluation
import Mathlib.Analysis.Analytic.Polynomial
import Mathlib.Analysis.SpecialFunctions.Complex.Analytic

noncomputable section
namespace UAMO.BoundarySeed
open Polynomial

def resonantPhase (α : ℝ) (m : ℕ) (ell : ℤ) : ℂ :=
  firstCenterPhase ((m : ℝ)*α) ell

theorem resonantPhase_ne_zero (α : ℝ) (m : ℕ) (ell : ℤ) :
    resonantPhase α m ell≠0 := Complex.exp_ne_zero _

theorem resonantPhase_norm (α : ℝ) (m : ℕ) (ell : ℤ) :
    ‖resonantPhase α m ell‖=1 := Complex.norm_exp_ofReal_mul_I _

theorem resonantPhase_square (α : ℝ) (m : ℕ) (ell : ℤ) :
    resonantPhase α m ell^2=weylPhase α^m := by
  rw [resonantPhase,firstCenterPhase_square,← zpow_natCast,weylPhase_zpow]
  unfold weylPhase
  congr 1
  push_cast
  ring

end UAMO.BoundarySeed

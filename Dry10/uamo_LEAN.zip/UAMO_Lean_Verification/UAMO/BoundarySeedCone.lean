import UAMO.BoundarySeedDiagonalization
import UAMO.StablePlane

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

theorem signed_real_entry_bound (A D : Matrix (Fin 2) (Fin 2) ℝ) {s δ : ℝ}
    (hs : |s|=1) (hE : ∀i j,|A i j-(s • D) i j|≤δ) (i j : Fin 2) :
    |s*A i j-D i j|≤δ := by
  have hs2 : s*s=1 := by nlinarith [sq_abs s]
  have he : s*A i j-D i j=s*(A i j-s*D i j) := by
    linear_combination D i j*hs2
  rw [he,abs_mul,hs,one_mul]
  exact hE i j

end UAMO.BoundarySeed

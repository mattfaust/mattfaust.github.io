import UAMO.SeedDeterminantControl
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

def seedEigenphase (η : ℂ) : ℂ := Complex.exp (((Complex.arg η/2 : ℝ):ℂ)*Complex.I)

theorem seedEigenphase_norm (η : ℂ) : ‖seedEigenphase η‖=1 :=
  Complex.norm_exp_ofReal_mul_I _

theorem seedEigenphase_square (η : ℂ) : (‖η‖:ℂ)*seedEigenphase η^2=η := by
  unfold seedEigenphase
  rw [sq,← Complex.exp_add]
  have he : (((Complex.arg η/2 : ℝ):ℂ)*Complex.I)+
      (((Complex.arg η/2 : ℝ):ℂ)*Complex.I)=(Complex.arg η:ℂ)*Complex.I := by push_cast; ring
  rw [he]
  exact Complex.norm_mul_exp_arg_mul_I η

def seedCayley (ξ : ℂ) : CMV.TransferMatrix := !![star ξ,Complex.I*star ξ;ξ,-Complex.I*ξ]
def seedCayleyInverse (ξ : ℂ) : CMV.TransferMatrix :=
  (1/2:ℂ) • !![ξ,star ξ;-Complex.I*ξ,Complex.I*star ξ]

private theorem phase_mul_star {ξ : ℂ} (hξ : ‖ξ‖=1) : ξ*star ξ=1 := by
  rw [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq,hξ]
  norm_num

theorem seedCayley_inverse_mul {ξ : ℂ} (hξ : ‖ξ‖=1) :
    seedCayleyInverse ξ*seedCayley ξ=1 := by
  have h := phase_mul_star hξ
  simp only [Complex.star_def] at h
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [seedCayleyInverse,seedCayley,Matrix.mul_apply,Fin.sum_univ_two,Complex.star_def]
  all_goals ring_nf
  all_goals try simp only [Complex.I_sq]
  all_goals ring_nf at h ⊢
  all_goals linear_combination h

theorem seedCayley_mul_inverse {ξ : ℂ} (hξ : ‖ξ‖=1) :
    seedCayley ξ*seedCayleyInverse ξ=1 := by
  have h := phase_mul_star hξ
  simp only [Complex.star_def] at h
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [seedCayleyInverse,seedCayley,Matrix.mul_apply,Fin.sum_univ_two,Complex.star_def]
  all_goals ring_nf
  all_goals try simp only [Complex.I_sq]
  all_goals ring_nf at h ⊢
  all_goals linear_combination h

def seedDiagonalMatrix (d : ℝ) : CMV.TransferMatrix := !![(d:ℂ),0;0,-(d:ℂ)]

theorem seedCayley_intertwining_of_square (η ξ : ℂ) (d : ℝ)
    (hunit : ‖ξ‖=1) (he : η=(d:ℂ)*ξ^2) :
    hermitianSeed η*seedCayley ξ=seedCayley ξ*seedDiagonalMatrix d := by
  have hξ := phase_mul_star hunit
  simp only [Complex.star_def] at hξ
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [hermitianSeed,seedCayley,seedDiagonalMatrix,Matrix.mul_apply,Fin.sum_univ_two,
      he,Complex.star_def]
  · linear_combination (d:ℂ)*(starRingEnd ℂ ξ)*hξ
  · linear_combination Complex.I*(d:ℂ)*(starRingEnd ℂ ξ)*hξ
  · linear_combination (d:ℂ)*ξ*hξ
  · linear_combination Complex.I*(d:ℂ)*ξ*hξ

theorem seedCayley_obstruction_intertwining (η : ℂ) :
    hermitianSeed η*seedCayley (seedEigenphase η) =
      seedCayley (seedEigenphase η)*seedDiagonalMatrix ‖η‖ :=
  seedCayley_intertwining_of_square η (seedEigenphase η) ‖η‖
    (seedEigenphase_norm η) (seedEigenphase_square η).symm

theorem seedCayley_diagonalizes (η : ℂ) :
    seedCayleyInverse (seedEigenphase η)*hermitianSeed η*seedCayley (seedEigenphase η)=
      seedDiagonalMatrix ‖η‖ := by
  rw [Matrix.mul_assoc,seedCayley_obstruction_intertwining,← Matrix.mul_assoc,
    seedCayley_inverse_mul (seedEigenphase_norm η),Matrix.one_mul]

theorem seedCayley_conjugate_entries_real (ξ : ℂ) (A : CMV.TransferMatrix)
    (h0 : A 1 1=star (A 0 0)) (h1 : A 0 1=star (A 1 0)) (i j : Fin 2) :
    star ((seedCayleyInverse ξ*A*seedCayley ξ) i j)=
      (seedCayleyInverse ξ*A*seedCayley ξ) i j := by
  fin_cases i <;> fin_cases j <;>
    simp [seedCayleyInverse,seedCayley,Matrix.mul_apply,Matrix.vecMul,dotProduct,Fin.sum_univ_two,h0,h1,
      Complex.star_def]
  all_goals ring

def seedRealConjugate (η : ℂ) (A : CMV.TransferMatrix) : Matrix (Fin 2) (Fin 2) ℝ :=
  (seedCayleyInverse (seedEigenphase η)*A*seedCayley (seedEigenphase η)).map Complex.re

theorem seedRealConjugate_map (η : ℂ) (A : CMV.TransferMatrix) (hA : SU11Form A) :
    (seedRealConjugate η A).map Complex.ofReal =
      seedCayleyInverse (seedEigenphase η)*A*seedCayley (seedEigenphase η) := by
  ext i j
  have h := seedCayley_conjugate_entries_real (seedEigenphase η) A hA.1 hA.2.1 i j
  have hi := congrArg Complex.im h
  simp only [Complex.star_def,Complex.conj_im] at hi
  have him : ((seedCayleyInverse (seedEigenphase η)*A*seedCayley (seedEigenphase η)) i j).im=0 := by linarith
  apply Complex.ext
  · rfl
  · simpa only [seedRealConjugate,Matrix.map_apply,Complex.ofReal_im] using him.symm

theorem seedRealConjugate_det (η : ℂ) (A : CMV.TransferMatrix) (hA : SU11Form A) :
    (seedRealConjugate η A).det=1 := by
  have he := congrArg Matrix.det (seedRealConjugate_map η A hA)
  rw [Matrix.det_mul,Matrix.det_mul,hA.2.2,mul_one,mul_comm,← Matrix.det_mul,
    seedCayley_mul_inverse (seedEigenphase_norm η),Matrix.det_one] at he
  have hc : ((seedRealConjugate η A).det:ℂ)=1 := by simpa only [Matrix.det_fin_two,Matrix.map_apply,
    Complex.ofReal_sub,Complex.ofReal_mul] using he
  exact Complex.ofReal_injective hc

theorem seedCayley_entry_norm {ξ : ℂ} (hξ : ‖ξ‖=1) (i j : Fin 2) :
    ‖seedCayley ξ i j‖≤1 := by
  fin_cases i <;> fin_cases j <;> simp [seedCayley,norm_mul,hξ]

theorem seedCayleyInverse_entry_norm {ξ : ℂ} (hξ : ‖ξ‖=1) (i j : Fin 2) :
    ‖seedCayleyInverse ξ i j‖≤(1/2:ℝ) := by
  fin_cases i <;> fin_cases j <;> simp [seedCayleyInverse,norm_mul,hξ]

private theorem matrix_mul_entry_bound (A B : CMV.TransferMatrix) {K L : ℝ}
    (hK : 0≤K) (hA : ∀i j,‖A i j‖≤K) (hB : ∀i j,‖B i j‖≤L) (i j : Fin 2) :
    ‖(A*B) i j‖≤2*K*L := by
  simp only [Matrix.mul_apply,Fin.sum_univ_two]
  calc
    _ ≤ ‖A i 0*B 0 j‖+‖A i 1*B 1 j‖ := norm_add_le _ _
    _ ≤ K*L+K*L := by
      simp only [norm_mul]
      exact add_le_add (mul_le_mul (hA i 0) (hB 0 j) (norm_nonneg _) hK)
        (mul_le_mul (hA i 1) (hB 1 j) (norm_nonneg _) hK)
    _ = _ := by ring

theorem seedCayley_error_bound (η : ℂ) (A B : CMV.TransferMatrix) {δ : ℝ}
    (hδ : 0≤δ) (hE : ∀i j,‖A i j-B i j‖≤δ) (i j : Fin 2) :
    ‖(seedCayleyInverse (seedEigenphase η)*A*seedCayley (seedEigenphase η)) i j-
      (seedCayleyInverse (seedEigenphase η)*B*seedCayley (seedEigenphase η)) i j‖≤2*δ := by
  have hleft : ∀i j,‖(seedCayleyInverse (seedEigenphase η)*(A-B)) i j‖≤δ := by
    intro i j
    have h := matrix_mul_entry_bound (seedCayleyInverse (seedEigenphase η)) (A-B)
      (by norm_num : (0:ℝ)≤1/2) (seedCayleyInverse_entry_norm (seedEigenphase_norm η)) hE i j
    norm_num at h
    exact h
  have h := matrix_mul_entry_bound (seedCayleyInverse (seedEigenphase η)*(A-B))
    (seedCayley (seedEigenphase η)) hδ hleft (seedCayley_entry_norm (seedEigenphase_norm η)) i j
  simpa only [Matrix.mul_sub,Matrix.sub_mul,Matrix.sub_apply,mul_one] using h

theorem seedRealConjugate_error_bound (η : ℂ) (A B : CMV.TransferMatrix) {δ : ℝ}
    (hδ : 0≤δ) (hE : ∀i j,‖A i j-B i j‖≤δ) (i j : Fin 2) :
    |seedRealConjugate η A i j-seedRealConjugate η B i j|≤2*δ := by
  simp only [seedRealConjugate,Matrix.map_apply,← Complex.sub_re]
  exact (Complex.abs_re_le_norm _).trans (seedCayley_error_bound η A B hδ hE i j)

theorem seedCayley_scalar_model (η : ℂ) (a ε : ℝ) :
    seedCayleyInverse (seedEigenphase η)*
      ((a:ℂ) • (1:CMV.TransferMatrix)+(ε:ℂ) • hermitianSeed η)*seedCayley (seedEigenphase η)=
      (a:ℂ) • (1:CMV.TransferMatrix)+(ε:ℂ) • seedDiagonalMatrix ‖η‖ := by
  rw [Matrix.mul_add,Matrix.add_mul,Matrix.mul_smul,Matrix.mul_smul,
    Matrix.smul_mul,Matrix.smul_mul,Matrix.mul_one,
    seedCayley_inverse_mul (seedEigenphase_norm η),seedCayley_diagonalizes]

theorem seedRealConjugate_scalar_model (η : ℂ) (a ε : ℝ) :
    seedRealConjugate η ((a:ℂ) • (1:CMV.TransferMatrix)+(ε:ℂ) • hermitianSeed η)=
      !![a+ε*‖η‖,0;0,a-ε*‖η‖] := by
  rw [seedRealConjugate,seedCayley_scalar_model]
  ext i j
  fin_cases i <;> fin_cases j <;> simp [seedDiagonalMatrix]
  all_goals ring

theorem hermitianSeed_real_smul (s : ℝ) (η : ℂ) :
    hermitianSeed ((s:ℂ)*η)=(s:ℂ) • hermitianSeed η := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [hermitianSeed,Complex.star_def]

theorem seedRealConjugate_signed_scalar_model {s : ℝ} (hs : |s|=1)
    (η : ℂ) (a ε : ℝ) :
    seedRealConjugate ((s:ℂ)*η) ((a:ℂ) • (1:CMV.TransferMatrix)+(ε:ℂ) • hermitianSeed η)=
      !![a+s*ε*‖η‖,0;0,a-s*ε*‖η‖] := by
  have hs2 : s^2=1 := by nlinarith [sq_abs s]
  have hsc : (s:ℂ)^2=1 := by exact_mod_cast hs2
  have hcoeff : ((s*ε:ℝ):ℂ)*(s:ℂ)=(ε:ℂ) := by
    push_cast
    linear_combination (ε:ℂ)*hsc
  have he : (a:ℂ) • (1:CMV.TransferMatrix)+(ε:ℂ) • hermitianSeed η =
      (a:ℂ) • (1:CMV.TransferMatrix)+((s*ε:ℝ):ℂ) • hermitianSeed ((s:ℂ)*η) := by
    rw [hermitianSeed_real_smul,smul_smul,hcoeff]
  rw [he,seedRealConjugate_scalar_model]
  simp only [norm_mul,Complex.norm_real,Real.norm_eq_abs,hs,one_mul]

theorem seedRealConjugate_signed_near_diagonal {s : ℝ} (hs : |s|=1)
    (η : ℂ) (A : CMV.TransferMatrix) (hA : SU11Form A) (ε : ℝ)
    {δ : ℝ} (hδ : 0≤δ)
    (hE : ∀i j,‖A i j-((s:ℂ) • (1:CMV.TransferMatrix)+(ε:ℂ) • hermitianSeed η) i j‖≤δ) :
    (seedRealConjugate ((s:ℂ)*η) A).det=1 ∧
      ∀i j,|seedRealConjugate ((s:ℂ)*η) A i j-
        (s • !![1+ε*‖η‖,0;0,1-ε*‖η‖]) i j|≤2*δ := by
  refine ⟨seedRealConjugate_det _ A hA,?_⟩
  intro i j
  have h := seedRealConjugate_error_bound ((s:ℂ)*η) A _ hδ hE i j
  rw [seedRealConjugate_signed_scalar_model hs] at h
  convert h using 2
  fin_cases i <;> fin_cases j <;> simp <;> ring

end UAMO.BoundarySeed

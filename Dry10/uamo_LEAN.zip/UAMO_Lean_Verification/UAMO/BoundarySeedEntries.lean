import UAMO.BoundarySeedEstimates
import UAMO.SeedDeterminantControl

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

theorem halfPhase_fourier_cancel (α x : ℝ) (m : ℕ) :
    halfPhase m x*halfPhase m (x+α)*(weylPhase x)^(-(m : ℤ))=halfPhase m α := by
  have hsq : halfPhase m x*halfPhase m x=(weylPhase x)^(m : ℤ) := by
    simp only [halfPhase,weylPhase,← Complex.exp_add,← Complex.exp_int_mul]
    congr 1
    push_cast
    ring
  rw [halfPhase_add]
  calc
    _ = (halfPhase m x*halfPhase m x)*(weylPhase x)^(-(m : ℤ))*halfPhase m α := by ring
    _ = _ := by
      have hw : weylPhase x≠0 := Complex.exp_ne_zero _
      rw [hsq,← zpow_add₀ hw,add_neg_cancel,zpow_zero,one_mul]

def transportResidual (p u : ℝ) (w r : Fin 2→ℂ) (g gp : ℂ) : CMV.TransferMatrix :=
  ((p*u : ℝ) : ℂ)⁻¹ • (normalizedFrameInverse w gp*frameRaw r g)

theorem transportResidual_zero (p u : ℝ) (w r : Fin 2→ℂ) (g gp : ℂ) :
    transportResidual p u w r g gp 0 0=
      (g*star gp)*(star (w 0)*r 0-star (w 1)*r 1)/
        ((p*u*Real.sqrt (profileSignature w) : ℝ) : ℂ) := by
  simp only [transportResidual,normalizedFrameInverse,frameAdjugate,frameRaw,
    Matrix.smul_apply,Matrix.mul_apply,Fin.sum_univ_two,smul_eq_mul,
    Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,
    Complex.ofReal_mul,_root_.mul_inv_rev,div_eq_mul_inv]
  ring

theorem transportResidual_one (p u : ℝ) (w r : Fin 2→ℂ) (g gp : ℂ) :
    transportResidual p u w r g gp 1 0=
      (g*gp)*(w 0*r 1-w 1*r 0)/
        ((p*u*Real.sqrt (profileSignature w) : ℝ) : ℂ) := by
  simp only [transportResidual,normalizedFrameInverse,frameAdjugate,frameRaw,
    Matrix.smul_apply,Matrix.mul_apply,Fin.sum_univ_two,smul_eq_mul,
    Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,
    Complex.ofReal_mul,_root_.mul_inv_rev,div_eq_mul_inv]
  ring

end UAMO.BoundarySeed

import UAMO.BoundarySeedNormalForm

noncomputable section
namespace UAMO.BoundarySeed
open Polynomial Matrix

theorem sqrt_signature_bounds (v : Fin 2→ℂ) {e : ℝ} (he0 : 0≤e) (he : e≤1/4)
    (h0 : ‖v 0-1‖≤e) (h1 : ‖v 1‖≤e) :
    1/2≤Real.sqrt (profileSignature v) ∧ Real.sqrt (profileSignature v)≤2 ∧
      |Real.sqrt (profileSignature v)-1|≤3*e := by
  obtain ⟨hl,hu,hd⟩ := profileSignature_bounds v he0 he h0 h1
  have hs := Real.sqrt_nonneg (profileSignature v)
  have hs2 := Real.sq_sqrt (by linarith : 0≤profileSignature v)
  constructor
  · nlinarith
  constructor
  · nlinarith
  · obtain ⟨hdl,hdu⟩ := abs_le.mp hd
    apply abs_le.mpr
    constructor <;> nlinarith [sq_nonneg (Real.sqrt (profileSignature v)-1)]

theorem transferDenominator_bounds {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam≤1/2) (x : ℝ) :
    1/2≤realTransferDenominator lam x ∧ realTransferDenominator lam x≤1 ∧
      |realTransferDenominator lam x-1|≤lam := by
  have hlt : lam<1 := by linarith
  have hp := realTransferDenominator_pos hlam hlt x
  have hp2 := realTransferDenominator_sq hlam hlt x
  have hs := Real.sin_sq_le_one x
  have hl2 : lam^2≤1/4 := by nlinarith
  have hprod : lam^2*Real.sin x^2≤lam^2 := mul_le_of_le_one_right (sq_nonneg _) hs
  have hprod0 := mul_nonneg (sq_nonneg lam) (sq_nonneg (Real.sin x))
  constructor
  · nlinarith
  constructor
  · nlinarith
  · apply abs_le.mpr
    constructor <;> nlinarith [sq_nonneg (realTransferDenominator lam x-1)]

theorem liftSign_abs (ell : ℤ) : |liftSign ell|=1 := by
  rw [← Real.norm_eq_abs,liftSign,norm_zpow]
  norm_num

end UAMO.BoundarySeed

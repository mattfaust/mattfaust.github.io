import UAMO.BoundaryFourierSeedTheorem

noncomputable section
namespace UAMO.BoundarySeed
open Polynomial Matrix
open scoped BigOperators

def profileSignature (v : Fin 2→ℂ) : ℝ := ‖v 0‖^2-‖v 1‖^2

theorem profileSignature_bounds (v : Fin 2→ℂ) {e : ℝ} (he0 : 0≤e) (he : e≤1/4)
    (h0 : ‖v 0-1‖≤e) (h1 : ‖v 1‖≤e) :
    1/2≤profileSignature v ∧ profileSignature v≤2 ∧
      |profileSignature v-1|≤3*e := by
  have hlo : 1-e≤‖v 0‖ := by
    have h := norm_sub_norm_le (1 : ℂ) (v 0)
    rw [norm_one,norm_sub_rev] at h
    linarith
  have hup : ‖v 0‖≤1+e := by
    calc
      ‖v 0‖ = ‖(v 0-1)+1‖ := by rw [sub_add_cancel]
      _ ≤ ‖v 0-1‖+‖(1 : ℂ)‖ := norm_add_le _ _
      _ ≤ 1+e := by rw [norm_one]; linarith
  have hs0 : 0≤‖v 0‖ := norm_nonneg _
  have hs1 : 0≤‖v 1‖ := norm_nonneg _
  have hsq0 : (1-e)^2≤‖v 0‖^2 := by nlinarith
  have hsq1 : ‖v 0‖^2≤(1+e)^2 := by nlinarith
  have hsq2 : ‖v 1‖^2≤e^2 := by nlinarith
  unfold profileSignature
  refine ⟨by nlinarith,by nlinarith,?_⟩
  rw [abs_le]
  constructor <;> nlinarith

def halfPhase (m : ℕ) (x : ℝ) : ℂ :=
  Complex.exp (((Real.pi*(m : ℝ)*x : ℝ) : ℂ)*Complex.I)

theorem halfPhase_norm (m : ℕ) (x : ℝ) : ‖halfPhase m x‖=1 :=
  Complex.norm_exp_ofReal_mul_I _

def frameRaw (v : Fin 2→ℂ) (g : ℂ) : CMV.TransferMatrix :=
  !![g*v 0,star g*star (v 1);g*v 1,star g*star (v 0)]

def frameAdjugate (v : Fin 2→ℂ) (g : ℂ) : CMV.TransferMatrix :=
  !![star g*star (v 0),-star g*star (v 1);-g*v 1,g*v 0]

def normalizedFrame (v : Fin 2→ℂ) (g : ℂ) : CMV.TransferMatrix :=
  ((Real.sqrt (profileSignature v) : ℂ)⁻¹) • frameRaw v g

def normalizedFrameInverse (v : Fin 2→ℂ) (g : ℂ) : CMV.TransferMatrix :=
  ((Real.sqrt (profileSignature v) : ℂ)⁻¹) • frameAdjugate v g

theorem frameRaw_det (v : Fin 2→ℂ) (g : ℂ) (hg : ‖g‖=1) :
    (frameRaw v g).det=(profileSignature v : ℂ) := by
  have hg' : g*star g=1 := by
    simp only [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq,hg,one_pow,Complex.ofReal_one]
  have h0 : v 0*star (v 0)=(‖v 0‖^2 : ℝ) := by
    simp only [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq]
  have h1 : v 1*star (v 1)=(‖v 1‖^2 : ℝ) := by
    simp only [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq]
  simp only [frameRaw,Matrix.det_fin_two_of,profileSignature,Complex.ofReal_sub]
  calc
    _ = (g*star g)*(v 0*star (v 0)-v 1*star (v 1)) := by ring
    _ = _ := by rw [hg',h0,h1,one_mul]

theorem frameRaw_mul_adjugate (v : Fin 2→ℂ) (g : ℂ) (hg : ‖g‖=1) :
    frameRaw v g*frameAdjugate v g=(profileSignature v : ℂ) • (1 : CMV.TransferMatrix) := by
  have hd := frameRaw_det v g hg
  simp only [frameRaw,Matrix.det_fin_two_of,Complex.star_def] at hd
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [frameRaw,frameAdjugate,Matrix.mul_apply,Fin.sum_univ_two]
  all_goals first | (solve | ring) | linear_combination hd

theorem normalizedFrame_mul_inverse (v : Fin 2→ℂ) (g : ℂ) (hg : ‖g‖=1)
    (hv : 0<profileSignature v) : normalizedFrame v g*normalizedFrameInverse v g=1 := by
  have hs : (Real.sqrt (profileSignature v) : ℂ)≠0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr hv).ne'
  have hsq : (Real.sqrt (profileSignature v) : ℂ)^2=(profileSignature v : ℂ) := by
    exact_mod_cast Real.sq_sqrt hv.le
  rw [normalizedFrame,normalizedFrameInverse,Matrix.smul_mul,Matrix.mul_smul,
    frameRaw_mul_adjugate v g hg,smul_smul,smul_smul,← hsq]
  have hc : (Real.sqrt (profileSignature v) : ℂ)⁻¹*
      (Real.sqrt (profileSignature v) : ℂ)⁻¹*(Real.sqrt (profileSignature v) : ℂ)^2=1 := by
    field_simp
    ring
  rw [hc,one_smul]

theorem normalizedFrame_det (v : Fin 2→ℂ) (g : ℂ) (hg : ‖g‖=1)
    (hv : 0<profileSignature v) : (normalizedFrame v g).det=1 := by
  have hs : (Real.sqrt (profileSignature v) : ℂ)≠0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr hv).ne'
  have hsq : (Real.sqrt (profileSignature v) : ℂ)^2=(profileSignature v : ℂ) := by
    exact_mod_cast Real.sq_sqrt hv.le
  rw [normalizedFrame,Matrix.det_smul,Fintype.card_fin,frameRaw_det v g hg,← hsq]
  field_simp

theorem normalizedFrame_inverse_mul (v : Fin 2→ℂ) (g : ℂ) (hg : ‖g‖=1)
    (hv : 0<profileSignature v) : normalizedFrameInverse v g*normalizedFrame v g=1 :=
  Matrix.mul_eq_one_comm.mp (normalizedFrame_mul_inverse v g hg hv)

def SU11Form (A : CMV.TransferMatrix) : Prop :=
  A 1 1=star (A 0 0) ∧ A 0 1=star (A 1 0) ∧ A.det=1

theorem normalizedFrame_SU11 (v : Fin 2→ℂ) (g : ℂ) (hg : ‖g‖=1)
    (hv : 0<profileSignature v) : SU11Form (normalizedFrame v g) := by
  refine ⟨?_,?_,normalizedFrame_det v g hg hv⟩
  all_goals simp [normalizedFrame,frameRaw,Complex.star_def]

end UAMO.BoundarySeed

import UAMO.BoundarySeedRegularity
import UAMO.BoundarySeedPowerControl
import UAMO.BoundarySeedCone
import UAMO.CMVTransferDetGrowthComparison
import UAMO.RealCocycleConjugacy

noncomputable section
namespace UAMO.BoundarySeed
open Matrix CMV Filter MeasureTheory Set
open scoped Topology

def boundarySzegoRadian (lam : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  boundarySzego lam z (x/(2*Real.pi))

theorem boundarySzegoRadian_physical {r : ℝ} (hr : 0≤r) (hr1 : r<1)
    {z : ℂ} (hz : z≠0) (x : ℝ) :
    boundarySzegoRadian (coupling r) z x=
      (star (physicalHopping r x)/(‖physicalHopping r x‖ : ℂ)) •
        (z⁻¹ • uamoSzegoCell 1 r z x) := by
  have hq : star (physicalHopping r x)≠0 := star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x)
  have h1 : coupling 1=1 := by norm_num [coupling]
  have h0 : complementaryCoupling 1=0 := by norm_num [complementaryCoupling]
  have hx : 2*Real.pi*(x/(2*Real.pi))=x := by field_simp
  have hN := boundaryNumerator_eq_szegoCell r (x/(2*Real.pi)) hz
  simp only [hx] at hN
  have hcell : uamoSzegoCell 1 r z x=
      (star (physicalHopping r x))⁻¹ • szegoCell 1 0 (oddAlpha r x) 1 z := by
    simp only [uamoSzegoCell,h1,h0,szegoCell,szegoStep,Complex.ofReal_one,
      inv_one,one_smul,Matrix.mul_smul]
  have hg : (star (physicalHopping r x)/(‖physicalHopping r x‖ : ℂ))*
      (z⁻¹*(star (physicalHopping r x))⁻¹)=(‖physicalHopping r x‖ : ℂ)⁻¹*z⁻¹ := by
    rw [div_eq_mul_inv]
    calc
      _ = (star (physicalHopping r x)*(star (physicalHopping r x))⁻¹)*
          ((‖physicalHopping r x‖ : ℂ)⁻¹*z⁻¹) := by ring
      _ = _ := by rw [mul_inv_cancel₀ hq,one_mul]
  unfold boundarySzegoRadian boundarySzego
  rw [hx,hN,hcell]
  simp only [smul_smul,mul_assoc]
  rw [hg,physicalHopping_norm_eq_realTransferDenominator]

end UAMO.BoundarySeed

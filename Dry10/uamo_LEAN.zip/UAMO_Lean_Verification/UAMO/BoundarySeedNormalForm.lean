import UAMO.BoundarySeedFrame
import UAMO.RealCocycleTwist

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

def conjugateMatrix (a b : ℂ) : CMV.TransferMatrix := !![a,star b;b,star a]

theorem conjugateMatrix_mul_frameRaw (a b : ℂ) (v : Fin 2→ℂ) (g : ℂ) :
    conjugateMatrix a b*frameRaw v g=frameRaw (conjugateMatrix a b*ᵥv) g := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [conjugateMatrix,frameRaw,Matrix.mul_apply,mulVec,dotProduct,Fin.sum_univ_two,
      Complex.star_def] <;> ring

theorem frameRaw_residual_decomposition (w r : Fin 2→ℂ) (g gp mu : ℂ) (c : ℝ)
    (hc : g*mu=(c : ℂ)*gp) :
    frameRaw (mu • w+r) g=(c : ℂ) • frameRaw w gp+frameRaw r g := by
  have hc' := congrArg (starRingEnd ℂ) hc
  simp only [map_mul,Complex.conj_ofReal] at hc'
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [frameRaw,Pi.smul_apply,Complex.star_def]
  · linear_combination w 0*hc
  · linear_combination (starRingEnd ℂ) (w 1)*hc'
  · linear_combination w 1*hc
  · linear_combination (starRingEnd ℂ) (w 0)*hc'

theorem frameRaw_eq_sqrt_smul (v : Fin 2→ℂ) (g : ℂ)
    (hv : 0<profileSignature v) :
    frameRaw v g=(Real.sqrt (profileSignature v) : ℂ) • normalizedFrame v g := by
  have hs : (Real.sqrt (profileSignature v) : ℂ)≠0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr hv).ne'
  rw [normalizedFrame,smul_smul,mul_inv_cancel₀ hs,one_smul]

theorem normalizedFrame_residual_conjugacy (a b : ℂ) (v w r : Fin 2→ℂ)
    (g gp mu : ℂ) (c p : ℝ) (hgp : ‖gp‖=1)
    (hw : 0<profileSignature w)
    (he : conjugateMatrix a b*ᵥv=mu • w+r) (hc : g*mu=(c : ℂ)*gp) :
    normalizedFrameInverse w gp*((p : ℂ)⁻¹ • conjugateMatrix a b)*normalizedFrame v g =
      ((c*Real.sqrt (profileSignature w)/(p*Real.sqrt (profileSignature v)) : ℝ) : ℂ) • 1 +
      ((p*Real.sqrt (profileSignature v) : ℝ) : ℂ)⁻¹ •
        (normalizedFrameInverse w gp*frameRaw r g) := by
  have hraw := conjugateMatrix_mul_frameRaw a b v g
  rw [he,frameRaw_residual_decomposition w r g gp mu c hc] at hraw
  conv_lhs => rw [normalizedFrame]
  rw [Matrix.mul_smul, Matrix.mul_smul, Matrix.smul_mul, smul_smul,
    mul_assoc, hraw, mul_add, Matrix.mul_smul,
    frameRaw_eq_sqrt_smul w gp hw, Matrix.mul_smul,
    normalizedFrame_inverse_mul w gp hgp hw]
  simp only [smul_add,smul_smul,Complex.ofReal_div,Complex.ofReal_mul,_root_.mul_inv_rev]
  congr 1
  congr 1
  ring

theorem halfPhase_add (m : ℕ) (x y : ℝ) : halfPhase m (x+y)=halfPhase m x*halfPhase m y := by
  unfold halfPhase
  rw [← Complex.exp_add]
  congr 1
  push_cast
  ring

def liftSign (ell : ℤ) : ℝ := (-1 : ℝ)^ell

theorem resonantPhase_eq_halfPhase (α : ℝ) (m : ℕ) (ell : ℤ) :
    resonantPhase α m ell=(liftSign ell : ℂ)*halfPhase m α := by
  unfold resonantPhase firstCenterPhase firstCenter halfPhase liftSign
  have he : ((Real.pi*((m : ℝ)*α+(ell : ℝ)) : ℝ) : ℂ)*Complex.I =
      (ell : ℂ)*(Real.pi*Complex.I)+((Real.pi*(m : ℝ)*α : ℝ) : ℂ)*Complex.I := by
    push_cast
    ring
  rw [he,Complex.exp_add,Complex.exp_int_mul,Complex.exp_pi_mul_I]
  simp only [← Complex.ofReal_neg, ← Complex.ofReal_one, ← Complex.ofReal_zpow]

theorem halfPhase_center_cancellation (α : ℝ) (m : ℕ) (ell : ℤ) (R x : ℝ) :
    halfPhase m x*(resonantPhase α m ell*(R : ℂ))=
      ((liftSign ell*R : ℝ) : ℂ)*halfPhase m (x+α) := by
  rw [resonantPhase_eq_halfPhase,halfPhase_add,Complex.ofReal_mul]
  ring

theorem inverse_eq_star_of_norm_one {z : ℂ} (hz : ‖z‖=1) : z⁻¹=star z := by
  have h : z*star z=1 := by
    simp only [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq,hz,one_pow,
      Complex.ofReal_one]
  have hz0 : z≠0 := norm_ne_zero_iff.mp (by rw [hz]; norm_num)
  calc
    z⁻¹ = z⁻¹*(z*star z) := by rw [h,mul_one]
    _ = star z := by rw [← mul_assoc,inv_mul_cancel₀ hz0,one_mul]

theorem boundaryNumerator_conjugateMatrix (lam : ℝ) {z : ℂ} (hz : ‖z‖=1) (x : ℝ) :
    boundaryNumerator lam z x=conjugateMatrix z (-(lam*Real.sin (2*Real.pi*x) : ℝ)) := by
  rw [boundaryNumerator,conjugateMatrix,inverse_eq_star_of_norm_one hz]
  ext i j
  fin_cases i <;> fin_cases j <;> simp only [Matrix.of_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one, Complex.star_def, Complex.conj_ofReal, map_neg]

def boundarySzego (lam : ℝ) (z : ℂ) (x : ℝ) : CMV.TransferMatrix :=
  (realTransferDenominator lam (2*Real.pi*x) : ℂ)⁻¹ • boundaryNumerator lam z x

theorem boundarySzego_det {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1)
    {z : ℂ} (hz : z≠0) (x : ℝ) : (boundarySzego lam z x).det=1 := by
  have hp := realTransferDenominator_pos hlam hlam1 (2*Real.pi*x)
  have hp2 : (realTransferDenominator lam (2*Real.pi*x) : ℂ)^2=
      1-(lam : ℂ)^2*(Real.sin (2*Real.pi*x) : ℂ)^2 := by
    exact_mod_cast realTransferDenominator_sq hlam hlam1 (2*Real.pi*x)
  rw [boundarySzego,Matrix.det_smul,Fintype.card_fin]
  have hm : (boundaryNumerator lam z x).det=
      (realTransferDenominator lam (2*Real.pi*x) : ℂ)^2 := by
    rw [boundaryNumerator,Matrix.det_fin_two_of,mul_inv_cancel₀ hz,hp2]
    push_cast
    ring
  rw [hm,inv_pow,inv_mul_cancel₀ (pow_ne_zero 2 (Complex.ofReal_ne_zero.mpr hp.ne'))]

theorem SU11Form_mul {A B : CMV.TransferMatrix} (hA : SU11Form A) (hB : SU11Form B) :
    SU11Form (A*B) := by
  refine ⟨?_,?_,by rw [Matrix.det_mul,hA.2.2,hB.2.2,mul_one]⟩
  · simp only [Matrix.mul_apply,Fin.sum_univ_two,hA.1,hA.2.1,hB.1,hB.2.1,
      Complex.star_def,map_add,map_mul,starRingEnd_self_apply]
    ring
  · simp only [Matrix.mul_apply,Fin.sum_univ_two,hA.1,hA.2.1,hB.1,hB.2.1,
      Complex.star_def,map_add,map_mul,starRingEnd_self_apply]
    ring

theorem boundarySzego_SU11 {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1)
    {z : ℂ} (hz : ‖z‖=1) (x : ℝ) : SU11Form (boundarySzego lam z x) := by
  have hz0 : z≠0 := norm_ne_zero_iff.mp (by rw [hz]; norm_num)
  refine ⟨?_,?_,boundarySzego_det hlam hlam1 hz0 x⟩
  · simp only [boundarySzego,boundaryNumerator,Matrix.smul_apply,smul_eq_mul,
      Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,
      inverse_eq_star_of_norm_one hz,Complex.star_def,map_mul,map_inv₀,Complex.conj_ofReal]
  · simp only [boundarySzego,boundaryNumerator,Matrix.smul_apply,smul_eq_mul,
      Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,
      Complex.star_def,map_mul,map_inv₀,map_neg,Complex.conj_ofReal]

end UAMO.BoundarySeed

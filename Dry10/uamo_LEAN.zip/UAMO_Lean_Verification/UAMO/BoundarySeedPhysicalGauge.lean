import UAMO.BoundarySeedLyapunov

noncomputable section
namespace UAMO.BoundarySeed
open Matrix CMV

def boundarySwap : TransferMatrix := !![0,1;1,0]

def boundaryHoppingGauge (r t : ℝ) : ℂ :=
  star (physicalHopping r t)/(‖physicalHopping r t‖ : ℂ)

theorem boundarySwap_square : boundarySwap*boundarySwap=1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [boundarySwap,Matrix.mul_apply,Fin.sum_univ_two]

theorem boundaryHoppingGauge_norm {r : ℝ} (hr : 0≤r) (hr1 : r<1) (t : ℝ) :
    ‖boundaryHoppingGauge r t‖=1 := by
  simp only [boundaryHoppingGauge,norm_div,norm_star,Complex.norm_real,
    Real.norm_eq_abs,abs_of_nonneg (norm_nonneg _),
    div_self (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 t))]

theorem boundarySzego_physical_conjugacy {r : ℝ} (hr : 0≤r) (hr1 : r<1)
    {z : ℂ} (hz : z≠0) (x : ℝ) :
    boundarySzego (coupling r) z x=boundaryHoppingGauge r (2*Real.pi*x) •
      (boundarySwap*uamoTransfer 1 r z (2*Real.pi*x)*boundarySwap) := by
  have h := boundarySzegoRadian_physical hr hr1 hz (2*Real.pi*x)
  have hx : (2*Real.pi*x)/(2*Real.pi)=x := by field_simp
  have h1 : coupling 1=1 := by norm_num [coupling]
  have h0 : complementaryCoupling 1=0 := by norm_num [complementaryCoupling]
  have hP : physicalConjugator 1 0=boundarySwap := by
    ext i j
    fin_cases i <;> fin_cases j <;> norm_num [physicalConjugator,boundarySwap]
  have hPi : physicalConjugatorInv 1 0=boundarySwap := by
    ext i j
    fin_cases i <;> fin_cases j <;> norm_num [physicalConjugatorInv,boundarySwap]
  rw [boundarySzegoRadian,hx,uamoTransfer_szego_conjugacy (by norm_num : (0:ℝ)<1) r hz,
    h1,h0,hP,hPi] at h
  exact h

end UAMO.BoundarySeed

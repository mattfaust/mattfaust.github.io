import UAMO.SeedDeterminantControl

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

theorem seed_power_square_le {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1)
    {m : ℕ} (hm : 1 ≤ m) : (lam^m)^2 ≤ lam^(m+1) := by
  rw [← pow_mul]
  exact pow_le_pow_of_le_one hlam hlam1 (by omega)

theorem seed_power_error_le_one {lam C : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1)
    (hC : 0 ≤ C) (hsmall : C*lam ≤ 1) (m : ℕ) : C*lam^(m+1) ≤ 1 := by
  have hp : lam^(m+1) ≤ lam := by
    simpa only [pow_one] using pow_le_pow_of_le_one hlam hlam1 (show 1 ≤ m+1 by omega)
  exact (mul_le_mul_of_nonneg_left hp hC).trans hsmall

theorem scalar_seed_power_diagonal_control (A : CMV.TransferMatrix)
    (a s lam C : ℝ) (η : ℂ) (m : ℕ) (hm : 1 ≤ m)
    (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1) (hC : 0 ≤ C) (hsmall : C*lam ≤ 1)
    (hs : |s|=1) (hnear : |a-s|≤1/2) (hdet : A.det=1)
    (hentry : ∀ i j, ‖A i j-((a : ℂ) • (1 : CMV.TransferMatrix)+
      ((lam^m : ℝ) : ℂ) • hermitianSeed η) i j‖ ≤ C*lam^(m+1)) :
    |a-s| ≤ (‖η‖^2+(6+2*‖η‖)*C)*lam^(m+1) := by
  have heps : |lam^m| ≤ 1 := by
    rw [abs_of_nonneg (pow_nonneg hlam m)]
    exact pow_le_one₀ hlam hlam1
  have hd := scalar_seed_diagonal_control A a s (lam^m) η hs hnear heps
    (mul_nonneg hC (pow_nonneg hlam _)) (seed_power_error_le_one hlam hlam1 hC hsmall m)
    hdet hentry
  have hp := mul_le_mul_of_nonneg_right (seed_power_square_le hlam hlam1 hm) (sq_nonneg ‖η‖)
  nlinarith

theorem scalar_seed_power_entry_control (A : CMV.TransferMatrix)
    (a s lam C : ℝ) (η : ℂ) (m : ℕ) (hm : 1 ≤ m)
    (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1) (hC : 0 ≤ C) (hsmall : C*lam ≤ 1)
    (hs : |s|=1) (hnear : |a-s|≤1/2) (hdet : A.det=1)
    (hentry : ∀ i j, ‖A i j-((a : ℂ) • (1 : CMV.TransferMatrix)+
      ((lam^m : ℝ) : ℂ) • hermitianSeed η) i j‖ ≤ C*lam^(m+1)) :
    ∀ i j, ‖A i j-((s : ℂ) • (1 : CMV.TransferMatrix)+
      ((lam^m : ℝ) : ℂ) • hermitianSeed η) i j‖ ≤
      (‖η‖^2+(7+2*‖η‖)*C)*lam^(m+1) := by
  have hd := scalar_seed_power_diagonal_control A a s lam C η m hm hlam hlam1 hC hsmall
    hs hnear hdet hentry
  intro i j
  let B : CMV.TransferMatrix := (a : ℂ) • 1+((lam^m : ℝ) : ℂ) • hermitianSeed η
  let D : CMV.TransferMatrix := (s : ℂ) • 1+((lam^m : ℝ) : ℂ) • hermitianSeed η
  have hBD : ‖B i j-D i j‖ ≤ |a-s| := by
    by_cases hij : i=j
    · subst j
      simp [B,D,Matrix.one_apply,← Complex.ofReal_sub,Complex.norm_real,Real.norm_eq_abs]
    · simp [B,D,Matrix.one_apply,hij,abs_nonneg]
  calc
    _ = ‖(A i j-B i j)+(B i j-D i j)‖ := by congr 1; dsimp [D]; ring
    _ ≤ ‖A i j-B i j‖+‖B i j-D i j‖ := norm_add_le _ _
    _ ≤ C*lam^(m+1)+|a-s| := add_le_add (hentry i j) hBD
    _ ≤ _ := by nlinarith

end UAMO.BoundarySeed

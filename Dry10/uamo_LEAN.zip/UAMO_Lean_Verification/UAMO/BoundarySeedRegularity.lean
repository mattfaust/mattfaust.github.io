import UAMO.BoundarySeedEntries

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

theorem boundarySzego_add_one (lam : ℝ) (z : ℂ) (x : ℝ) :
    boundarySzego lam z (x+1)=boundarySzego lam z x := by
  have hs : Real.sin (2*Real.pi*(x+1))=Real.sin (2*Real.pi*x) := by
    rw [show 2*Real.pi*(x+1)=2*Real.pi*x+2*Real.pi by ring,Real.sin_add_two_pi]
  simp only [boundarySzego,boundaryNumerator,realTransferDenominator,hs]

end UAMO.BoundarySeed

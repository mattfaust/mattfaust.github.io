import UAMO.BoundarySeedRegularity
import UAMO.BoundarySeedPowerControl
import UAMO.BoundarySeedCone
import UAMO.NearDiagonalLatticeRecurrence
import UAMO.CMVTransferDetGrowthComparison
import UAMO.LatticeMatrixMultiplier
import UAMO.BoundarySeedPhysicalGauge
import UAMO.LatticeScalarGauge

noncomputable section
namespace UAMO.BoundarySeed
open Matrix CMV PhysicalRepresentation

def seedOrbitScalar (r α θ : ℝ) (n : ℤ) : ℂ :=
  orbitGauge (fun k => (boundaryHoppingGauge r (2*Real.pi*(θ+(k:ℝ)*α)))⁻¹) n

theorem seedOrbitScalar_norm {r : ℝ} (hr : 0≤r) (hr1 : r<1) (α θ : ℝ) (n : ℤ) :
    ‖seedOrbitScalar r α θ n‖=1 := by
  exact orbitGauge_norm _ (fun k => by rw [norm_inv,boundaryHoppingGauge_norm hr hr1,inv_one]) n

theorem seedOrbitScalar_succ {r : ℝ} (hr : 0≤r) (hr1 : r<1) (α θ : ℝ) (n : ℤ) :
    seedOrbitScalar r α θ (n+1)=
      (boundaryHoppingGauge r (2*Real.pi*(θ+(n:ℝ)*α)))⁻¹*seedOrbitScalar r α θ n := by
  exact orbitGauge_succ _ (fun k => by rw [norm_inv,boundaryHoppingGauge_norm hr hr1,inv_one]) n

end UAMO.BoundarySeed

import UAMO.RealCocycleTwist
import UAMO.StablePlane
import Mathlib.Analysis.SpecificLimits.Basic

noncomputable section
namespace UAMO
open Matrix StablePlane
open scoped Matrix Topology

theorem realTransferDenominator_add_pi (lam x : ℝ) :
    realTransferDenominator lam (x+Real.pi)=realTransferDenominator lam x := by
  simp only [realTransferDenominator,Real.sin_add_pi,neg_sq]

theorem realTransfer_boundary_half_phase (lam t x : ℝ) :
    realTransfer 1 lam t (x+Real.pi)*quarterTurn=quarterTurn*realTransfer 1 lam t x := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [realTransfer,realTransferNumerator,quarterTurn,realTransferDenominator_add_pi,
      Real.sin_add_pi,Matrix.mul_apply,Fin.sum_univ_two]
  ring
  simp

theorem boundary_stable_angle_odd_winding_period_one {lam : ℝ}
    (hlam : 0≤lam) (hlam1 : lam<1) (t α : ℝ) (θ : ℝ→ℝ) (hθ : Continuous θ)
    (hstable : ∀ x,IsStable (fun y => realTransfer 1 lam t (2*Real.pi*y)) α x
      (angleVector (θ x))) :
    ∃ k : ℤ,∀ x,θ (x+1)-θ x=(2*(k : ℝ)+1)*Real.pi := by
  have hsym (x : ℝ) : realTransfer 1 lam t (2*Real.pi*(x+1/2))*quarterTurn=
      quarterTurn*realTransfer 1 lam t (2*Real.pi*x) := by
    rw [show 2*Real.pi*(x+1/2)=2*Real.pi*x+Real.pi by ring]
    exact realTransfer_boundary_half_phase lam t (2*Real.pi*x)
  simpa only [show (2 : ℝ)*(1/2)=1 by norm_num] using
    stable_angle_odd_winding (fun y => realTransfer 1 lam t (2*Real.pi*y))
      (fun x => realTransfer_det (by norm_num) hlam hlam1 t (2*Real.pi*x))
      (1/2) α hsym θ hθ hstable

def stableAngleDegree (θ : ℝ→ℝ) : ℝ := (θ 1-θ 0)/Real.pi

theorem boundary_stableAngleDegree_odd {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1)
    (t α : ℝ) (θ : ℝ→ℝ) (hθ : Continuous θ)
    (hstable : ∀ x,IsStable (fun y => realTransfer 1 lam t (2*Real.pi*y)) α x
      (angleVector (θ x))) :
    ∃ m : ℤ,Odd m ∧ stableAngleDegree θ=(m : ℝ) := by
  obtain ⟨k,hk⟩ := boundary_stable_angle_odd_winding_period_one hlam hlam1 t α θ hθ hstable
  refine ⟨2*k+1,⟨k,by ring⟩,?_⟩
  have hh := hk 0
  simp only [zero_add] at hh
  rw [stableAngleDegree,hh]
  simp only [mul_div_cancel_right₀ _ Real.pi_ne_zero,Int.cast_add,Int.cast_mul,Int.cast_ofNat,Int.cast_one]

end UAMO

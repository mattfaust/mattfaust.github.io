import UAMO.SpectralMomentCorrespondence
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Basic
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Isometric
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.Topology.Algebra.Polynomial
import Mathlib.Tactic.Linarith

noncomputable section

namespace UAMO

open Set Filter
open scoped Topology Polynomial ContinuousFunctionalCalculus

section CStarAlgebra

variable {A : Type*} [CStarAlgebra A]

theorem norm_cfc_sub_polynomial_lt (f : ℝ → ℝ) (K : Set ℝ)
    (hf : ContinuousOn f K) (p : ℝ[X]) (epsilon : ℝ) (hepsilon : 0 < epsilon)
    (hp : ∀ x ∈ K, ‖f x - p.eval x‖ < epsilon)
    (a : A) (ha : IsSelfAdjoint a) (hspectrum : spectrum ℝ a ⊆ K) :
    ‖cfc f a - Polynomial.aeval a p‖ < epsilon := by
  rw [← cfc_polynomial p a ha,
    ← cfc_sub f p.eval a (hf.mono hspectrum) p.continuous.continuousOn]
  exact norm_cfc_lt hepsilon (fun x hx => hp x (hspectrum hx))

theorem continuousOn_cfc_of_compact_window (f : ℝ → ℝ) (K : Set ℝ)
    (hK : IsCompact K) (hf : ContinuousOn f K) :
    ContinuousOn (fun a : A => cfc f a)
      {a | IsSelfAdjoint a ∧ spectrum ℝ a ⊆ K} := by
  intro a ha
  apply Metric.continuousWithinAt_iff.mpr
  intro epsilon hepsilon
  have hepsilon3 : 0 < epsilon / 3 := by linarith
  obtain ⟨p, hp⟩ := SpectralMoments.exists_polynomial_uniform_approximation K hK f hf
    (epsilon / 3) hepsilon3
  obtain ⟨delta, hdelta, hpcont⟩ := Metric.continuousAt_iff.mp
    (p.continuousAt_aeval (a := a)) (epsilon / 3) hepsilon3
  refine ⟨delta, hdelta, fun b hb hab => ?_⟩
  have herrora := norm_cfc_sub_polynomial_lt f K hf p (epsilon / 3) hepsilon3 hp a ha.1 ha.2
  have herrorb := norm_cfc_sub_polynomial_lt f K hf p (epsilon / 3) hepsilon3 hp b hb.1 hb.2
  have hmiddle := hpcont hab
  have hfirst : dist (cfc f b) (Polynomial.aeval b p) < epsilon / 3 := by
    simpa only [dist_eq_norm] using herrorb
  have hlast : dist (Polynomial.aeval a p) (cfc f a) < epsilon / 3 := by
    simpa only [dist_eq_norm, norm_sub_rev] using herrora
  calc
    dist (cfc f b) (cfc f a) ≤
        dist (cfc f b) (Polynomial.aeval b p) + dist (Polynomial.aeval b p) (cfc f a) :=
      dist_triangle _ _ _
    _ ≤ dist (cfc f b) (Polynomial.aeval b p) +
        (dist (Polynomial.aeval b p) (Polynomial.aeval a p) +
          dist (Polynomial.aeval a p) (cfc f a)) :=
      add_le_add_left (dist_triangle _ _ _) _
    _ < epsilon := by linarith

theorem continuousAt_cfc_of_local_spectral_window
    {X : Type*} [TopologicalSpace X] (H : X → A) (x : X)
    (hH : ContinuousAt H x) (f : ℝ → ℝ) (K : Set ℝ) (hK : IsCompact K)
    (hf : ContinuousOn f K)
    (hnear : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (H t) ∧ spectrum ℝ (H t) ⊆ K) :
    ContinuousAt (fun t => cfc f (H t)) x := by
  have htendsto : Tendsto H (𝓝 x)
      (𝓝[{a : A | IsSelfAdjoint a ∧ spectrum ℝ a ⊆ K}] H x) :=
    tendsto_nhdsWithin_iff.mpr ⟨hH, hnear⟩
  exact (continuousOn_cfc_of_compact_window f K hK hf (H x) hnear.self_of_nhds).tendsto.comp htendsto

variable [Nontrivial A]

theorem real_spectrum_subset_Icc_of_norm_le (a : A) {R : ℝ} (hbound : ‖a‖ ≤ R) :
    spectrum ℝ a ⊆ Icc (-R) R := by
  intro y hy
  have hnorm : ‖y‖ ≤ R := (spectrum.norm_le_norm_of_mem hy).trans hbound
  exact abs_le.mp hnorm

theorem continuousAt_cfc_of_local_norm_bound
    {X : Type*} [TopologicalSpace X] (H : X → A) (x : X)
    (hH : ContinuousAt H x) (f : ℝ → ℝ) (R : ℝ)
    (hf : ContinuousOn f (Icc (-R) R))
    (hnear : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (H t) ∧ ‖H t‖ ≤ R) :
    ContinuousAt (fun t => cfc f (H t)) x := by
  apply continuousAt_cfc_of_local_spectral_window H x hH f (Icc (-R) R) isCompact_Icc hf
  filter_upwards [hnear] with t ht
  exact ⟨ht.1, real_spectrum_subset_Icc_of_norm_le (H t) ht.2⟩

theorem continuousAt_cfc_of_continuous
    {X : Type*} [TopologicalSpace X] (H : X → A) (x : X)
    (hH : ContinuousAt H x) (f : ℝ → ℝ) (hf : Continuous f)
    (hself : ∀ᶠ t in 𝓝 x, IsSelfAdjoint (H t)) :
    ContinuousAt (fun t => cfc f (H t)) x := by
  have hbound : ∀ᶠ t in 𝓝 x, ‖H t‖ < ‖H x‖ + 1 :=
    hH.norm.eventually (gt_mem_nhds (by linarith : ‖H x‖ < ‖H x‖ + 1))
  apply continuousAt_cfc_of_local_norm_bound H x hH f (‖H x‖ + 1) hf.continuousOn
  filter_upwards [hself, hbound] with t ht hb
  exact ⟨ht, hb.le⟩

end CStarAlgebra

end UAMO

import UAMO.CMVLyapunov
import Mathlib.MeasureTheory.Constructions.BorelSpace.Complex

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

local instance aeTransferMatrixMeasurableSpace : MeasurableSpace TransferMatrix :=
  borel TransferMatrix
local instance aeTransferMatrixBorelSpace : BorelSpace TransferMatrix := ⟨rfl⟩

theorem transferProduct_det_norm_ae (A : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (ω : ℝ) (n : ℕ) :
    ∀ᵐ x ∂volume, ‖(transferProduct A ω x n).det‖ = 1 := by
  induction n with
  | zero => simp
  | succ n ih =>
    filter_upwards [(quasiMeasurePreserving_add_right volume (n*ω)).ae hd, ih] with x hx hi
    simp only [transferProduct_succ, Matrix.det_mul, norm_mul, hx, hi, one_mul]

theorem transferLogNorm_nonneg_ae (A : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (ω : ℝ) (n : ℕ) :
    ∀ᵐ x ∂volume, 0 ≤ transferLogNorm A ω x n := by
  filter_upwards [transferProduct_det_norm_ae A hd ω n] with x hx
  exact Real.log_nonneg (one_le_transferNorm_of_det_norm _ hx)

theorem measurable_transferProduct (A : ℝ → TransferMatrix) (hA : Measurable A)
    (ω : ℝ) (n : ℕ) : Measurable (fun x => transferProduct A ω x n) := by
  induction n with
  | zero => exact measurable_const
  | succ n ih => exact (hA.comp (measurable_id.add_const (n*ω))).mul ih

theorem measurable_transferLogNorm (A : ℝ → TransferMatrix) (hA : Measurable A)
    (ω : ℝ) (n : ℕ) : Measurable (fun x => transferLogNorm A ω x n) :=
  Real.measurable_log.comp (continuous_transferNorm.measurable.comp
    (measurable_transferProduct A hA ω n))

theorem transferLogNorm_add_le_ae (A : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (ω : ℝ) (m n : ℕ) :
    ∀ᵐ x ∂volume, transferLogNorm A ω x (m+n) ≤
      transferLogNorm A ω (x+n*ω) m + transferLogNorm A ω x n := by
  filter_upwards [transferProduct_det_norm_ae A hd ω (m+n),
    (quasiMeasurePreserving_add_right volume (n*ω)).ae (transferProduct_det_norm_ae A hd ω m),
    transferProduct_det_norm_ae A hd ω n] with x hmn hm hn
  have hmnpos := zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ hmn)
  have hmpos := zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ hm)
  have hnpos := zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ hn)
  unfold transferLogNorm
  rw [transferProduct_add]
  calc
    Real.log (transferNorm
        (transferProduct A ω (x+n*ω) m * transferProduct A ω x n)) ≤
        Real.log (transferNorm (transferProduct A ω (x+n*ω) m) *
          transferNorm (transferProduct A ω x n)) := by
      apply Real.log_le_log
      · simpa only [transferProduct_add] using hmnpos
      · exact transferNorm_mul_le _ _
    _ = _ := Real.log_mul hmpos.ne' hnpos.ne'

theorem transferLogNorm_intervalIntegrable_ae (A : ℝ → TransferMatrix)
    (hA : Measurable A) (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1)
    (hi : ∀ a b, IntervalIntegrable (fun x => Real.log (transferNorm (A x))) volume a b)
    (ω : ℝ) (n : ℕ) (a b : ℝ) :
    IntervalIntegrable (fun x => transferLogNorm A ω x n) volume a b := by
  induction n with
  | zero => simp [transferLogNorm]
  | succ n ih =>
    have hs : IntervalIntegrable (fun x => transferLogNorm A ω (x+n*ω) 1) volume a b := by
      simpa only [transferLogNorm, transferProduct_succ, transferProduct_zero, Nat.cast_zero,
        zero_mul, add_zero, mul_one, add_sub_cancel_right] using
        (hi (a+n*ω) (b+n*ω)).comp_add_right (n*ω)
    apply (hs.add ih).mono_fun'
    · exact (measurable_transferLogNorm A hA ω (n+1)).aestronglyMeasurable
    · filter_upwards [ae_restrict_of_ae (transferLogNorm_add_le_ae A hd ω 1 n),
        ae_restrict_of_ae (transferLogNorm_nonneg_ae A hd ω (n+1))] with x hx hn
      rw [Real.norm_eq_abs, abs_of_nonneg hn]
      simpa only [Nat.add_comm 1 n] using hx

theorem transferLogAverage_subadditive_ae (A : ℝ → TransferMatrix)
    (hA : Measurable A) (hp : Function.Periodic A (2*Real.pi))
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1)
    (hi : ∀ a b, IntervalIntegrable (fun x => Real.log (transferNorm (A x))) volume a b)
    (ω : ℝ) : Subadditive (transferLogAverage A ω) := by
  intro m n
  unfold transferLogAverage
  rw [← add_div]
  apply div_le_div_of_nonneg_right _ (by positivity)
  have hm : IntervalIntegrable (fun x => transferLogNorm A ω (x+n*ω) m)
      volume 0 (2*Real.pi) := by
    simpa only [add_sub_cancel_right, zero_add, sub_self] using
      (transferLogNorm_intervalIntegrable_ae A hA hd hi ω m
        (0+n*ω) (2*Real.pi+n*ω)).comp_add_right (n*ω)
  have hn := transferLogNorm_intervalIntegrable_ae A hA hd hi ω n 0 (2*Real.pi)
  calc
    (∫ x in (0 : ℝ)..2*Real.pi, transferLogNorm A ω x (m+n)) ≤
        ∫ x in (0 : ℝ)..2*Real.pi,
          transferLogNorm A ω (x+n*ω) m + transferLogNorm A ω x n :=
      intervalIntegral.integral_mono_ae (by positivity)
        (transferLogNorm_intervalIntegrable_ae A hA hd hi ω (m+n) 0 (2*Real.pi))
        (hm.add hn) (transferLogNorm_add_le_ae A hd ω m n)
    _ = _ := by
      rw [intervalIntegral.integral_add hm hn, transferLogNorm_integral_shift A hp]

theorem finiteLyapunov_nonneg_ae (A : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (ω : ℝ) (n : ℕ) :
    0 ≤ finiteLyapunov A ω n := by
  apply div_nonneg _ (Nat.cast_nonneg n)
  apply div_nonneg _ (by positivity)
  exact intervalIntegral.integral_nonneg_of_ae (by positivity)
    (transferLogNorm_nonneg_ae A hd ω n)

theorem finiteLyapunov_bddBelow_ae (A : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (ω : ℝ) :
    BddBelow (range (finiteLyapunov A ω)) := by
  refine ⟨0, ?_⟩
  rintro _ ⟨n, rfl⟩
  exact finiteLyapunov_nonneg_ae A hd ω n

theorem lyapunov_nonneg_ae (A : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (ω : ℝ) : 0 ≤ lyapunov A ω := by
  apply le_csInf (show ((fun n => finiteLyapunov A ω n) '' Ici 1).Nonempty from
    ⟨finiteLyapunov A ω 1, 1, by simp, rfl⟩)
  rintro _ ⟨n, _, rfl⟩
  exact finiteLyapunov_nonneg_ae A hd ω n

theorem tendsto_finiteLyapunov_ae (A : ℝ → TransferMatrix)
    (hA : Measurable A) (hp : Function.Periodic A (2*Real.pi))
    (hd : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1)
    (hi : ∀ a b, IntervalIntegrable (fun x => Real.log (transferNorm (A x))) volume a b)
    (ω : ℝ) : Tendsto (finiteLyapunov A ω) atTop (𝓝 (lyapunov A ω)) := by
  have h := (transferLogAverage_subadditive_ae A hA hp hd hi ω).tendsto_lim
    (finiteLyapunov_bddBelow_ae A hd ω)
  simpa only [Subadditive.lim, lyapunov, finiteLyapunov] using h

end UAMO.CMV

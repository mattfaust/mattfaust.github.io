import UAMO.CMVSeparatedAngularRoots
import UAMO.CMVRootEnumeration
import UAMO.AngularCrossingDiscrepancy
import UAMO.CircleArcParameterization
import UAMO.CircleArcCounting
import UAMO.CMVPointwiseDOSConvergence

noncomputable section
namespace UAMO.CMV
open Matrix ProjectiveAngle CircleDOS PhysicalDOS MeasureTheory Set Filter
open scoped Topology BigOperators

local instance angularDOSDecidable (p : Prop) : Decidable p := Classical.propDecidable p

theorem separatedEigenangle_pos (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) (j : Fin (2*(n+1))) :
    0<separatedEigenangle n ha hr hr1 ω x j := by
  obtain ⟨hj,hval⟩ := separatedEigenangle_spec n ha hr hr1 ω x j
  have hne : separatedEigenangle n ha hr hr1 ω x j≠0 := by
    intro he
    rw [he,separatedAngularEndpoint_zero] at hval
    have hnonneg := mul_nonneg (Nat.cast_nonneg j.val : (0:ℝ)≤j.val) Real.pi_pos.le
    linarith [Real.pi_pos]
  exact lt_of_le_of_ne hj.1 hne.symm

theorem separatedEigenangle_exp_injective (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) :
    Function.Injective (fun j => anglePoint (separatedEigenangle n ha hr hr1 ω x j)) := by
  intro i j he
  apply separatedEigenangle_injective n ha hr hr1 ω x
  exact anglePoint_injOn_turn (separatedEigenangle_spec n ha hr hr1 ω x i).1
    (separatedEigenangle_spec n ha hr hr1 ω x j).1 he

theorem separatedSpectralMeasure_real_eq_eigenangle_count (n : ℕ) {a r : ℝ}
    (ha : 0<a) (hr : 0≤r) (hr1 : r<1) (ω x : ℝ)
    (S : Set ℂ) (hS : MeasurableSet S) :
    (separatedSpectralMeasure n a r ω x).real S=
      ((Finset.univ.filter (fun j : Fin (2*(n+1)) =>
        anglePoint (separatedEigenangle n ha hr hr1 ω x j)∈S)).card:ℝ)/
        ((2*(n+1):ℕ):ℝ) := by
  apply separatedSpectralMeasure_real_eq_count_of_distinct_det_zeros n a r ω x
    (fun j => anglePoint (separatedEigenangle n ha hr hr1 ω x j))
    (separatedEigenangle_exp_injective n ha hr hr1 ω x) _ S hS
  exact separatedEigenangle_det_zero n ha hr hr1 ω x

def separatedEigenangleCount (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x t : ℝ) : ℕ :=
  (Finset.univ.filter (fun j : Fin (2*(n+1)) =>
    separatedEigenangle n ha hr hr1 ω x j≤t)).card

theorem separatedEigenangleCount_discrepancy (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) {t : ℝ} (ht : t∈Icc 0 (2*Real.pi)) :
    |(separatedEigenangleCount n ha hr hr1 ω x t:ℝ)-
      (separatedAngularEndpoint n a r t ω x+Real.pi/2)/Real.pi|≤1 := by
  have h := angularCrossingCount_discrepancy
    (fun u => separatedAngularEndpoint n a r u ω x)
    (continuous_separatedAngularEndpoint n ha hr hr1 ω x)
    (separatedAngularEndpoint_strictMono n ha hr hr1 ω x)
    0 (2*Real.pi) (Real.pi/2) (by positivity) (by positivity)
    (by linarith [Real.pi_pos]) (2*(n+1))
    (by simpa only [zero_add] using separatedAngularEndpoint_turn n a r 0 ω x)
    (by simpa only [zero_add] using ht)
  change |(separatedEigenangleCount n ha hr hr1 ω x t:ℝ)-
    (separatedAngularEndpoint n a r t ω x-
      separatedAngularEndpoint n a r 0 ω x)/Real.pi|≤1 at h
  simpa only [separatedAngularEndpoint_zero,sub_neg_eq_add,neg_div] using h

theorem separatedSpectralMeasure_arcLabel_endpoint_error (n : ℕ) {a r : ℝ}
    (ha : 0<a) (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) {t : ℝ}
    (ht0 : 0<t) (ht2π : t<2*Real.pi) :
    |arcLabel (separatedSpectralMeasure n a r ω x) (anglePoint t)-
      separatedAngularEndpoint n a r t ω x/(2*Real.pi*((n:ℝ)+1))|≤
      2/((n:ℝ)+1) := by
  let p := separatedEigenangle n ha hr hr1 ω x
  let A := (Finset.univ.filter (fun j => anglePoint (p j)∈directedArc (anglePoint t))).card
  let B := separatedEigenangleCount n ha hr hr1 ω x t
  let H := separatedAngularEndpoint n a r t ω x
  have hA : |(A:ℝ)-(B:ℝ)|≤2 :=
    directedArc_count_discrepancy p (separatedEigenangle_injective n ha hr hr1 ω x)
      (fun j => (separatedEigenangle_spec n ha hr hr1 ω x j).1)
      (fun j => (separatedEigenangle_pos n ha hr hr1 ω x j).ne') ht0 ht2π
  have hB : |(B:ℝ)-(H+Real.pi/2)/Real.pi|≤1 :=
    separatedEigenangleCount_discrepancy n ha hr hr1 ω x ⟨ht0.le,ht2π.le⟩
  have hshift : (H+Real.pi/2)/Real.pi=H/Real.pi+1/2 := by
    field_simp [Real.pi_ne_zero]
    ring_nf
    exact Or.inl True.intro
  rw [hshift] at hB
  have hnum : |(A:ℝ)-H/Real.pi|≤4 := by
    obtain ⟨hAl,hAu⟩ := abs_le.mp hA
    obtain ⟨hBl,hBu⟩ := abs_le.mp hB
    apply abs_le.mpr
    constructor <;> linarith
  rw [arcLabel,separatedSpectralMeasure_real_eq_eigenangle_count n ha hr hr1 ω x
    _ (measurableSet_directedArc _)]
  change |(A:ℝ)/((2*(n+1):ℕ):ℝ)-H/(2*Real.pi*((n:ℝ)+1))|≤2/((n:ℝ)+1)
  have hN : (0:ℝ)<((2*(n+1):ℕ):ℝ) := by positivity
  have hn : (n:ℝ)+1≠0 := by positivity
  have hden : H/(2*Real.pi*((n:ℝ)+1))=(H/Real.pi)/((2*(n+1):ℕ):ℝ) := by
    push_cast
    field_simp [Real.pi_ne_zero,hn]
    ring_nf
    exact Or.inl True.intro
  rw [hden,← sub_div,abs_div,abs_of_pos hN]
  calc
    _ ≤ 4/((2*(n+1):ℕ):ℝ) := div_le_div_of_nonneg_right hnum hN.le
    _ = 2/((n:ℝ)+1) := by push_cast; field_simp [hn]; ring

theorem separatedAngularEndpoint_normalized_tendsto {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (α x : ℝ)
    (hα : Irrational α) {t : ℝ} (ht0 : 0<t) (ht2π : t<2*Real.pi) :
    Tendsto (fun n : ℕ => separatedAngularEndpoint n a r t
      (2*Real.pi*α) (2*Real.pi*x)/(2*Real.pi*((n:ℝ)+1))) atTop
      (𝓝 (arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le) (anglePoint t))) := by
  have hμ := separatedSpectralMeasure_pointwise_arcLabel_tendsto ha ha1 hr hr1.le α x hα
    (anglePoint t)
  have herr : Tendsto (fun n : ℕ =>
      separatedAngularEndpoint n a r t (2*Real.pi*α) (2*Real.pi*x)/
        (2*Real.pi*((n:ℝ)+1))-
      arcLabel (separatedSpectralMeasure n a r (2*Real.pi*α) (2*Real.pi*x))
        (anglePoint t)) atTop (𝓝 0) := by
    apply squeeze_zero_norm (a:=fun n : ℕ => 2/((n:ℝ)+1))
    · intro n
      rw [Real.norm_eq_abs,abs_sub_comm]
      exact separatedSpectralMeasure_arcLabel_endpoint_error n ha hr hr1
        (2*Real.pi*α) (2*Real.pi*x) ht0 ht2π
    · simpa only [mul_one_div,mul_zero] using
        tendsto_one_div_add_atTop_nhds_zero_nat.const_mul (2:ℝ)
  have h := hμ.add herr
  simp only [add_zero] at h
  convert h using 1
  ext n
  dsimp
  ring

end UAMO.CMV

namespace UAMO
open ProjectiveAngle CMV CircleDOS PhysicalDOS Filter
open scoped Topology

theorem physicalAngularRotation_eq_DOS_arcLabel {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (α : ℝ)
    (hα : Irrational α) {t : ℝ} (ht0 : 0<t) (ht2π : t<2*Real.pi) :
    HasPhysicalAngularRotation a (coupling r) t α
      (arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le) (anglePoint t)) := by
  intro x s
  apply physicalAngularMean_tendsto_of_radian_endpoint ha
    (by unfold coupling; positivity) (coupling_lt_one_of_lt_one hr1)
    t α x (separatedLeftAngle a t) (t/2) _ _ s
  exact separatedAngularEndpoint_normalized_tendsto ha ha1 hr hr1 α x hα ht0 ht2π

end UAMO

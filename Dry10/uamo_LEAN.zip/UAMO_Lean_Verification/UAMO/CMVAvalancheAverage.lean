import UAMO.CMVAvalancheBlocks
import UAMO.CMVUniformGrowth

noncomputable section

open MeasureTheory Set
open scoped BigOperators

namespace UAMO.CMV
open BourgainJitomirskaya

private theorem radianTransferProduct_avalanche_blocks (A : ℝ→TransferMatrix)
    (α θ : ℝ) (m N : ℕ) :
    avalancheProduct (fun j => transferProduct A (2*Real.pi*α)
      (θ+2*Real.pi*α*(j*m:ℕ)) m) N=transferProduct A (2*Real.pi*α) θ (N*m) := by
  simpa only [mul_comm (2*Real.pi*α)] using
    transferProduct_avalanche_blocks A (2*Real.pi*α) θ m N

private theorem radianTransferProduct_avalanche_pair (A : ℝ→TransferMatrix)
    (α θ : ℝ) (m j : ℕ) :
    transferProduct A (2*Real.pi*α) (θ+2*Real.pi*α*((j+1)*m:ℕ)) m*
      transferProduct A (2*Real.pi*α) (θ+2*Real.pi*α*(j*m:ℕ)) m=
      transferProduct A (2*Real.pi*α) (θ+2*Real.pi*α*(j*m:ℕ)) (2*m) := by
  simpa only [mul_comm (2*Real.pi*α)] using
    transferProduct_avalanche_pair A (2*Real.pi*α) θ m j

def avalancheDefect (A : ℝ→TransferMatrix) (α : ℝ) (N n : ℕ) (x : ℝ) : ℝ :=
  (transferLogNorm A (2*Real.pi*α) (2 * Real.pi * x) ((n + 2) * N) +
    (∑ j ∈ Finset.range n, transferLogNorm A (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N) -
    ∑ j ∈ Finset.range (n + 1), transferLogNorm A (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N)) /
      (((n + 2) * N : ℕ) : ℝ)

theorem avalanche_shift_integrable (A : ℝ→TransferMatrix) (hc : Continuous A) (hd : ∀x,(A x).det=1) (α : ℝ) (k : ℕ) (r : ℝ) :
    IntervalIntegrable (fun x => transferLogNorm A (2*Real.pi*α) (2 * Real.pi * x + r) k)
      volume 0 1 :=
  ((continuous_transferLogNorm A hc (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) k).comp
    ((continuous_const.mul continuous_id).add continuous_const)).intervalIntegrable 0 1

theorem avalanche_shift_integral (A : ℝ→TransferMatrix) (hp : Function.Periodic A (2*Real.pi)) (α : ℝ) (k : ℕ) (r : ℝ) :
    (∫ x in (0 : ℝ)..1, transferLogNorm A (2*Real.pi*α) (2 * Real.pi * x + r) k) =
      transferLogAverage A (2*Real.pi*α) k := by
  have h := intervalIntegral.integral_comp_mul_left (a := 0) (b := 1)
    (c := 2 * Real.pi) (fun θ => transferLogNorm A (2*Real.pi*α) (θ + r) k) (by positivity)
  simp only [mul_zero, mul_one, transferLogNorm_integral_shift A hp] at h
  simpa only [transferLogAverage, smul_eq_mul, div_eq_mul_inv, mul_comm] using h

theorem avalanche_average_eq_mul_finite (A : ℝ→TransferMatrix) (α : ℝ) (k : ℕ) :
    transferLogAverage A (2*Real.pi*α) k = (k : ℝ) * finiteLyapunov A (2*Real.pi*α) k := by
  cases k with
  | zero => simp [transferLogAverage, transferLogNorm]
  | succ k =>
      unfold finiteLyapunov
      field_simp

theorem avalancheDefect_integral (A : ℝ→TransferMatrix) (hc : Continuous A) (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,(A x).det=1) (α : ℝ) (N n : ℕ) (hN : 0 < N) :
    (∫ x in (0 : ℝ)..1, avalancheDefect A α N n x) =
      finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) +
        (n : ℝ) / (n + 2 : ℕ) * finiteLyapunov A (2*Real.pi*α) N -
        (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) (2 * N) := by
  have h0 := avalanche_shift_integrable A hc hd α ((n + 2) * N) 0
  simp only [add_zero] at h0
  have h1 : IntervalIntegrable (fun x => ∑ j ∈ Finset.range n,
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N) volume 0 1 := by
    convert IntervalIntegrable.sum (Finset.range n)
      (fun j _ => avalanche_shift_integrable A hc hd α N
        (2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ))) using 1
    ext x
    simp only [Finset.sum_apply]
  have h2 : IntervalIntegrable (fun x => ∑ j ∈ Finset.range (n + 1),
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N)) volume 0 1 := by
    convert IntervalIntegrable.sum (Finset.range (n + 1))
      (fun j _ => avalanche_shift_integrable A hc hd α (2 * N)
        (2 * Real.pi * α * ((j * N : ℕ) : ℝ))) using 1
    ext x
    simp only [Finset.sum_apply]
  unfold avalancheDefect
  rw [intervalIntegral.integral_div, intervalIntegral.integral_sub (h0.add h1) h2,
    intervalIntegral.integral_add h0 h1,
    intervalIntegral.integral_finset_sum (fun j _ => avalanche_shift_integrable A hc hd α N
      (2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ))),
    intervalIntegral.integral_finset_sum (fun j _ => avalanche_shift_integrable A hc hd α (2 * N)
      (2 * Real.pi * α * ((j * N : ℕ) : ℝ)))]
  have hfirst := avalanche_shift_integral A hp α ((n + 2) * N) 0
  simp only [add_zero] at hfirst
  rw [hfirst]
  simp_rw [avalanche_shift_integral A hp, avalanche_average_eq_mul_finite]
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  have hmr : ((n + 2 : ℕ) : ℝ) ≠ 0 := by positivity
  push_cast
  field_simp
  ring

theorem avalancheDefect_abs_le (A : ℝ→TransferMatrix) (hd : ∀x,(A x).det=1) (B : ℝ) (hB : 0≤B) (hlinear : ∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B) (α : ℝ) (N n : ℕ) (hN : 0 < N) (x : ℝ) :
    |avalancheDefect A α N n x| ≤ 2 * B := by
  have h0 := transferLogNorm_nonneg A (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) (2 * Real.pi * x) ((n + 2) * N)
  have hu0 := hlinear (2*Real.pi*α) (2 * Real.pi * x) ((n + 2) * N)
  have h1 := Finset.sum_nonneg (s := Finset.range n) (fun j _ =>
    transferLogNorm_nonneg A (fun x => by rw [hd x,norm_one]) (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N)
  have h2 := Finset.sum_nonneg (s := Finset.range (n + 1)) (fun j _ =>
    transferLogNorm_nonneg A (fun x => by rw [hd x,norm_one]) (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N))
  have hu1 := Finset.sum_le_sum (s := Finset.range n) (fun j _ =>
    hlinear (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N)
  have hu2 := Finset.sum_le_sum (s := Finset.range (n + 1)) (fun j _ =>
    hlinear (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N))
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at hu1 hu2
  have hden : (0 : ℝ) < (((n + 2) * N : ℕ) : ℝ) := by positivity
  unfold avalancheDefect
  rw [abs_div, abs_of_pos hden]
  apply (div_le_iff₀ hden).mpr
  apply abs_le.mpr
  push_cast at h0 h1 h2 hu0 hu1 hu2 ⊢
  have hNB : 0 ≤ (N : ℝ) * B := mul_nonneg (Nat.cast_nonneg N) hB
  constructor <;> nlinarith

theorem avalancheDefect_good (A : ℝ→TransferMatrix) (hd : ∀x,(A x).det=1) (α : ℝ) (N n : ℕ) (hN : 0 < N)
    (x : ℝ) {μ : ℝ} (hμ : 10000 ≤ μ)
    (hlarge : ∀ j < n + 2, μ ≤ transferNorm (transferProduct A (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N))
    (hpair : ∀ j < n + 1,
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N +
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N -
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) ≤ Real.log μ / 2) :
    |avalancheDefect A α N n x| ≤ 1000 / ((N : ℝ) * μ) := by
  have hp (j : ℕ) (hj : j < n + 1) := hpair j hj
  simp only [transferLogNorm, ← radianTransferProduct_avalanche_pair] at hp
  have h := avalanche_principle_log (fun j => transferProduct A (2*Real.pi*α)
    (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N) n
    (fun _ => transferProduct_det_one A hd (2*Real.pi*α) _ N) hμ hlarge hp
  simp only [radianTransferProduct_avalanche_blocks, radianTransferProduct_avalanche_pair] at h
  have hden : (0 : ℝ) < (((n + 2) * N : ℕ) : ℝ) := by positivity
  unfold avalancheDefect
  rw [abs_div, abs_of_pos hden]
  refine (div_le_div_of_nonneg_right h hden.le).trans_eq ?_
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  have hmr : ((n + 2 : ℕ) : ℝ) ≠ 0 := by positivity
  have hμr : μ ≠ 0 := by linarith
  push_cast
  field_simp
  ring

theorem avalanche_integral_badset_bound {Ω : Type*} [MeasurableSpace Ω]
    (ν : Measure Ω) [IsProbabilityMeasure ν] (f : Ω → ℝ) {s : Set Ω}
    (hs : MeasurableSet s) {a b δ : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hδ : ν.real s ≤ δ) (hgood : ∀ x ∉ s, |f x| ≤ a) (hall : ∀ x, |f x| ≤ b) :
    |∫ x, f x ∂ν| ≤ a + b * δ := by
  classical
  have hi : Integrable (fun x => a + s.indicator (fun _ => b) x) ν :=
    (integrable_const a).add ((integrable_const b).indicator hs)
  have h := norm_integral_le_of_norm_le hi (Filter.Eventually.of_forall (fun x => by
    rw [Real.norm_eq_abs]
    by_cases hx : x ∈ s
    · simpa [hx] using (hall x).trans (show b ≤ a + b by linarith)
    · simpa [hx] using hgood x hx))
  rw [integral_add (integrable_const a) ((integrable_const b).indicator hs),
    integral_const, integral_indicator_const b hs] at h
  simp only [measureReal_univ_eq_one, one_smul, smul_eq_mul, Real.norm_eq_abs] at h
  nlinarith [mul_le_mul_of_nonneg_left hδ hb]

theorem finiteLyapunov_avalanche_average (A : ℝ→TransferMatrix) (hc : Continuous A) (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,(A x).det=1) (B : ℝ) (hB : 0≤B) (hlinear : ∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B) (α : ℝ) (N n : ℕ) (hN : 0 < N)
    {μ δ : ℝ} (hμ : 10000 ≤ μ) {s : Set ℝ} (hs : MeasurableSet s)
    (hδ : (volume.restrict (Ioc (0 : ℝ) 1)).real s ≤ δ)
    (hlarge : ∀ x ∉ s, ∀ j < n + 2, μ ≤ transferNorm (transferProduct A (2*Real.pi*α)
      (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N))
    (hpair : ∀ x ∉ s, ∀ j < n + 1,
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N +
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N -
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) ≤ Real.log μ / 2) :
    |finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) +
      (n : ℝ) / (n + 2 : ℕ) * finiteLyapunov A (2*Real.pi*α) N -
      (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤
        1000 / ((N : ℝ) * μ) + 2 * B * δ := by
  let ν : Measure ℝ := volume.restrict (Ioc (0 : ℝ) 1)
  haveI phaseProbability : IsProbabilityMeasure ν := ⟨by simp [ν]⟩
  have hμ0 : 0 < μ := by linarith
  have h := avalanche_integral_badset_bound ν (avalancheDefect A α N n) hs
    (show 0 ≤ 1000 / ((N : ℝ) * μ) by positivity)
    (show 0 ≤ 2 * B from mul_nonneg (by norm_num)
      hB) hδ
    (fun x hx => avalancheDefect_good A hd α N n hN x hμ (hlarge x hx) (hpair x hx))
    (avalancheDefect_abs_le A hd B hB hlinear α N n hN)
  rw [← avalancheDefect_integral A hc hp hd α N n hN,
    intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)]
  exact h

end UAMO.CMV

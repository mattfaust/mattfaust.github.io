import UAMO.CMVAvalancheAverage

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace UAMO.CMV

def avalanchePhaseLog (A : ℝ → TransferMatrix) (α : ℝ) (N : ℕ) (x : ℝ) : ℝ :=
  transferLogNorm A (2*Real.pi*α) (2 * Real.pi * x) N / (N : ℝ)

theorem continuous_avalanchePhaseLog (A : ℝ → TransferMatrix) (hc : Continuous A) (hd : ∀x,(A x).det=1) (α : ℝ) (N : ℕ) :
    Continuous (avalanchePhaseLog A α N) :=
  ((continuous_transferLogNorm A hc (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) N).comp
    (continuous_const.mul continuous_id)).div_const (N : ℝ)

theorem avalanchePhaseLog_periodic (A : ℝ → TransferMatrix) (hp : Function.Periodic A (2*Real.pi)) (α : ℝ) (N : ℕ) :
    Function.Periodic (avalanchePhaseLog A α N) 1 := by
  intro x
  unfold avalanchePhaseLog
  rw [show 2 * Real.pi * (x + 1) = 2 * Real.pi * x + 2 * Real.pi by ring]
  exact congrArg (fun u : ℝ => u / (N : ℝ))
    (congrArg Real.log (congrArg transferNorm (transferProduct_periodic A hp (2*Real.pi*α) N (2*Real.pi*x))))

def avalancheBaseBadSet (A : ℝ → TransferMatrix) (α : ℝ) (N : ℕ) (κ : ℝ) : Set ℝ :=
  {x | κ < |avalanchePhaseLog A α N x - finiteLyapunov A (2*Real.pi*α) N|}

theorem measurableSet_avalancheBaseBadSet (A : ℝ → TransferMatrix) (hc : Continuous A) (hd : ∀x,(A x).det=1) (α : ℝ) (N : ℕ) (κ : ℝ) :
    MeasurableSet (avalancheBaseBadSet A α N κ) :=
  (isOpen_lt continuous_const
    ((continuous_avalanchePhaseLog A hc hd α N).sub continuous_const).abs).measurableSet

theorem avalancheBaseBadSet_add_one (A : ℝ → TransferMatrix) (hp : Function.Periodic A (2*Real.pi)) (α : ℝ) (N : ℕ) (κ x : ℝ) :
    x + 1 ∈ avalancheBaseBadSet A α N κ ↔ x ∈ avalancheBaseBadSet A α N κ := by
  change κ < |avalanchePhaseLog A α N (x + 1) - _| ↔ _
  rw [avalanchePhaseLog_periodic A hp]
  rfl

theorem avalanche_periodic_set_shift_mass {s : Set ℝ} (hs : MeasurableSet s)
    (hp : ∀ x : ℝ, x + 1 ∈ s ↔ x ∈ s) (r : ℝ) :
    (volume.restrict (Ioc (0 : ℝ) 1)).real ((fun x => x + r) ⁻¹' s) =
      (volume.restrict (Ioc (0 : ℝ) 1)).real s := by
  classical
  have ht : MeasurableSet ((fun x => x + r) ⁻¹' s) :=
    hs.preimage (continuous_id.add continuous_const).measurable
  have hI (u : Set ℝ) (hu : MeasurableSet u) :
      (∫ x in (0 : ℝ)..1, u.indicator (fun _ => (1 : ℝ)) x) =
        (volume.restrict (Ioc (0 : ℝ) 1)).real u := by
    rw [intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)]
    simpa only [smul_eq_mul, mul_one] using
      (integral_indicator_const (μ := volume.restrict (Ioc (0 : ℝ) 1)) (1 : ℝ) hu)
  have hper : Function.Periodic (s.indicator (fun _ => (1 : ℝ))) 1 := by
    intro x
    by_cases hx : x ∈ s
    · have hx' := (hp x).mpr hx
      simp [hx, hx']
    · have hx' : x + 1 ∉ s := fun hh => hx ((hp x).mp hh)
      simp [hx, hx']
  calc
    (volume.restrict (Ioc (0 : ℝ) 1)).real ((fun x => x + r) ⁻¹' s) =
        ∫ x in (0 : ℝ)..1, ((fun x => x + r) ⁻¹' s).indicator (fun _ => (1 : ℝ)) x := (hI _ ht).symm
    _ = ∫ x in (0 : ℝ)..1, s.indicator (fun _ => (1 : ℝ)) (x + r) := by
      congr 1
    _ = ∫ x in (0 : ℝ)..1, s.indicator (fun _ => (1 : ℝ)) x := by
      rw [intervalIntegral.integral_comp_add_right]
      simpa only [zero_add, add_comm 1 r] using hper.intervalIntegral_add_eq r 0
    _ = _ := hI s hs

def avalancheBadSet (A : ℝ → TransferMatrix) (α : ℝ) (N n : ℕ) (κ : ℝ) : Set ℝ :=
  (⋃ j ∈ Finset.range (n + 2), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
    avalancheBaseBadSet A α N κ) ∪
  (⋃ j ∈ Finset.range (n + 1), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
    avalancheBaseBadSet A α (2 * N) κ)

theorem measurableSet_avalancheBadSet (A : ℝ → TransferMatrix) (hc : Continuous A) (hd : ∀x,(A x).det=1) (α : ℝ) (N n : ℕ) (κ : ℝ) :
    MeasurableSet (avalancheBadSet A α N n κ) := by
  apply MeasurableSet.union
  · exact MeasurableSet.iUnion fun _ => MeasurableSet.iUnion fun _ =>
      (measurableSet_avalancheBaseBadSet A hc hd α N κ).preimage
        (continuous_id.add continuous_const).measurable
  · exact MeasurableSet.iUnion fun _ => MeasurableSet.iUnion fun _ =>
      (measurableSet_avalancheBaseBadSet A hc hd α (2 * N) κ).preimage
        (continuous_id.add continuous_const).measurable

theorem avalancheBadSet_mass_le (A : ℝ → TransferMatrix) (hc : Continuous A) (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,(A x).det=1) (α : ℝ) (N n : ℕ) (κ : ℝ) {δ : ℝ}
    (hN : (volume.restrict (Ioc (0 : ℝ) 1)).real (avalancheBaseBadSet A α N κ) ≤ δ)
    (h2N : (volume.restrict (Ioc (0 : ℝ) 1)).real (avalancheBaseBadSet A α (2 * N) κ) ≤ δ) :
    (volume.restrict (Ioc (0 : ℝ) 1)).real (avalancheBadSet A α N n κ) ≤
      2 * (n + 2 : ℕ) * δ := by
  let ν : Measure ℝ := volume.restrict (Ioc (0 : ℝ) 1)
  have hs (k m : ℕ) (hk : ν.real (avalancheBaseBadSet A α k κ) ≤ δ) :
      ν.real (⋃ j ∈ Finset.range m, (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
        avalancheBaseBadSet A α k κ) ≤ (m : ℝ) * δ := by
    refine (measureReal_biUnion_finset_le (μ := ν) (Finset.range m) _).trans ?_
    calc
      (∑ j ∈ Finset.range m, ν.real ((fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
          avalancheBaseBadSet A α k κ)) ≤ ∑ _j ∈ Finset.range m, δ := by
        apply Finset.sum_le_sum
        intro j _
        rw [show ν.real ((fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
          avalancheBaseBadSet A α k κ) = ν.real (avalancheBaseBadSet A α k κ) from
          avalanche_periodic_set_shift_mass (measurableSet_avalancheBaseBadSet A hc hd α k κ)
            (avalancheBaseBadSet_add_one A hp α k κ) _]
        exact hk
      _ = _ := by simp
  have hδ : 0 ≤ δ := measureReal_nonneg.trans hN
  have hu := measureReal_union_le (μ := ν)
    (⋃ j ∈ Finset.range (n + 2), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
      avalancheBaseBadSet A α N κ)
    (⋃ j ∈ Finset.range (n + 1), (fun x : ℝ => x + α * ((j * N : ℕ) : ℝ)) ⁻¹'
      avalancheBaseBadSet A α (2 * N) κ)
  have h1 := hs N (n + 2) hN
  have h2 := hs (2 * N) (n + 1) h2N
  change ν.real _ ≤ _
  unfold avalancheBadSet
  push_cast at hu h1 h2 ⊢
  linarith

theorem avalancheBadSet_good (A : ℝ → TransferMatrix) (α : ℝ) (N n : ℕ) (κ x : ℝ)
    (hx : x ∉ avalancheBadSet A α N n κ) :
    (∀ j < n + 2, |avalanchePhaseLog A α N (x + α * ((j * N : ℕ) : ℝ)) -
      finiteLyapunov A (2*Real.pi*α) N| ≤ κ) ∧
    (∀ j < n + 1, |avalanchePhaseLog A α (2 * N) (x + α * ((j * N : ℕ) : ℝ)) -
      finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤ κ) := by
  simp only [avalancheBadSet, mem_union, mem_iUnion, Finset.mem_range, mem_preimage,
    avalancheBaseBadSet, mem_setOf_eq] at hx
  constructor
  · intro j hj
    exact le_of_not_gt (fun hh => hx (Or.inl ⟨j, hj, hh⟩))
  · intro j hj
    exact le_of_not_gt (fun hh => hx (Or.inr ⟨j, hj, hh⟩))

end UAMO.CMV

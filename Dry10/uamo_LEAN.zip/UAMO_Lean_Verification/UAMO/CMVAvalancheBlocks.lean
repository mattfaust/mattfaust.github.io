import UAMO.BJAvalancheScale

noncomputable section
namespace UAMO.CMV
open BourgainJitomirskaya
open scoped BigOperators

theorem transferProduct_avalanche_blocks (A : ℝ→TransferMatrix) (ω x : ℝ) (m N : ℕ) :
    avalancheProduct (fun j => transferProduct A ω (x+(j*m:ℕ)*ω) m) N=
      transferProduct A ω x (N*m) := by
  induction N with
  | zero => simp [avalancheProduct]
  | succ N ih =>
    rw [avalancheProduct,ih,show (N+1)*m=m+N*m by ring,transferProduct_add]

theorem transferProduct_avalanche_pair (A : ℝ→TransferMatrix) (ω x : ℝ) (m j : ℕ) :
    transferProduct A ω (x+((j+1)*m:ℕ)*ω) m*
      transferProduct A ω (x+(j*m:ℕ)*ω) m=
        transferProduct A ω (x+(j*m:ℕ)*ω) (2*m) := by
  rw [show 2*m=m+m by ring,transferProduct_add]
  have he : x+((j+1)*m:ℕ)*ω=(x+(j*m:ℕ)*ω)+(m:ℝ)*ω := by push_cast; ring
  rw [he]

theorem transferProduct_det_one (A : ℝ→TransferMatrix) (hd : ∀x,(A x).det=1)
    (ω x : ℝ) (n : ℕ) : (transferProduct A ω x n).det=1 := by
  induction n with
  | zero => simp
  | succ n ih => rw [transferProduct_succ,Matrix.det_mul,hd,ih,mul_one]

end UAMO.CMV

import UAMO.CMVAvalancheAverage
import UAMO.CMVAvalancheBadSet

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace UAMO.CMV

theorem finiteLyapunov_le_linear_bound (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hd : ∀x,(A x).det=1) (B : ℝ) (hB : 0≤B)
    (hlinear : ∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B)
    (ω : ℝ) (n : ℕ) : finiteLyapunov A ω n≤B := by
  by_cases hn : n=0
  · simp [hn,finiteLyapunov,hB]
  have hnr : (0:ℝ)<n := by exact_mod_cast Nat.pos_of_ne_zero hn
  apply (div_le_iff₀ hnr).mpr
  unfold transferLogAverage
  apply (div_le_iff₀ (by positivity : (0:ℝ)<2*Real.pi)).mpr
  have hi := intervalIntegral.integral_mono_on (by positivity : (0:ℝ)≤2*Real.pi)
    ((continuous_transferLogNorm A hc (fun x => by rw [hd x,norm_one]) ω n).intervalIntegrable _ _)
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => (n:ℝ)*B) volume 0 (2*Real.pi))
    (fun x _ => hlinear ω x n)
  simp only [intervalIntegral.integral_const,sub_zero,smul_eq_mul] at hi
  nlinarith

theorem avalanche_good_of_deviations (A : ℝ → TransferMatrix) (hd : ∀x,(A x).det=1) (α : ℝ) (N n : ℕ) (hN : 0 < N)
    (x : ℝ) {κ : ℝ} (hκ : 0 < κ)
    (hL : 400 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hL2 : (9 / 10 : ℝ) * finiteLyapunov A (2*Real.pi*α) N ≤ finiteLyapunov A (2*Real.pi*α) (2 * N))
    (hdN : ∀ j < n + 2,
      |transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N / (N : ℝ) -
          finiteLyapunov A (2*Real.pi*α) N| ≤ κ)
    (hd2N : ∀ j < n + 1,
      |transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) / ((2 * N : ℕ) : ℝ) -
          finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤ κ) :
    (∀ j < n + 2, Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2) ≤
      transferNorm (transferProduct A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N)) ∧
    (∀ j < n + 1,
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N +
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N -
      transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) ≤
          Real.log (Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) / 2) := by
  have hNr : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN
  have h2Nr : (0 : ℝ) < ((2 * N : ℕ) : ℝ) := by positivity
  have hLN := mul_le_mul_of_nonneg_left hL hNr.le
  have hL2N := mul_le_mul_of_nonneg_left hL2 hNr.le
  have hNκ : 0 ≤ (N : ℝ) * κ := mul_nonneg hNr.le hκ.le
  constructor
  · intro j hj
    have hlo : (finiteLyapunov A (2*Real.pi*α) N - κ) * (N : ℝ) ≤
        transferLogNorm A (2*Real.pi*α)
          (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N := by
      apply (le_div_iff₀ hNr).mp
      linarith [(abs_le.mp (hdN j hj)).1]
    apply (Real.log_le_log_iff (Real.exp_pos _)
      (transferProduct_norm_pos A (fun y => by rw [hd y,norm_one]) (2*Real.pi*α) _ N)).mp
    rw [Real.log_exp]
    change (N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2 ≤
      transferLogNorm A (2*Real.pi*α) _ N
    nlinarith
  · intro j hj
    have hhi0 : transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N ≤
        (finiteLyapunov A (2*Real.pi*α) N + κ) * (N : ℝ) := by
      apply (div_le_iff₀ hNr).mp
      linarith [(abs_le.mp (hdN j (by omega))).2]
    have hhi1 : transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * (((j + 1) * N : ℕ) : ℝ)) N ≤
        (finiteLyapunov A (2*Real.pi*α) N + κ) * (N : ℝ) := by
      apply (div_le_iff₀ hNr).mp
      linarith [(abs_le.mp (hdN (j + 1) (by omega))).2]
    have hlo2 : (finiteLyapunov A (2*Real.pi*α) (2 * N) - κ) * ((2 * N : ℕ) : ℝ) ≤
        transferLogNorm A (2*Real.pi*α)
          (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) := by
      apply (le_div_iff₀ h2Nr).mp
      linarith [(abs_le.mp (hd2N j hj)).1]
    rw [Real.log_exp]
    simp only [Nat.cast_mul, Nat.cast_ofNat] at hhi0 hhi1 hlo2 ⊢
    nlinarith

theorem finiteLyapunov_avalanche_of_deviation_masses
    (A : ℝ → TransferMatrix) (hc : Continuous A) (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,(A x).det=1) (B : ℝ) (hB : 0≤B) (hlinear : ∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B) (α : ℝ) (N n : ℕ) (hN : 0 < N) {κ δ : ℝ} (hκ : 0 < κ)
    (hL : 400 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hL2 : (9 / 10 : ℝ) * finiteLyapunov A (2*Real.pi*α) N ≤ finiteLyapunov A (2*Real.pi*α) (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)
    (hbadN : (volume.restrict (Ioc (0 : ℝ) 1)).real (avalancheBaseBadSet A α N κ) ≤ δ)
    (hbad2N : (volume.restrict (Ioc (0 : ℝ) 1)).real (avalancheBaseBadSet A α (2 * N) κ) ≤ δ) :
    (|finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) +
      (n : ℝ) / (n + 2 : ℕ) * finiteLyapunov A (2*Real.pi*α) N -
      (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
          4 * B * (n + 2 : ℕ) * δ) ∧
    (|finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) + finiteLyapunov A (2*Real.pi*α) N -
        2 * finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
          4 * B * (n + 2 : ℕ) * δ +
          2 * B / (n + 2 : ℕ)) := by
  have hμ : 10000 ≤ Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2) := by
    have h := Real.exp_le_exp.mpr hscale
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 10000)] using h
  have hgood (x : ℝ) (hx : x ∉ avalancheBadSet A α N n κ) :=
    avalancheBadSet_good A α N n κ x hx
  have hphase (k j : ℕ) (x : ℝ) :
      avalanchePhaseLog A α k (x + α * ((j * N : ℕ) : ℝ)) =
        transferLogNorm A (2*Real.pi*α)
          (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) k / (k : ℝ) := by
    unfold avalanchePhaseLog
    congr 2
    ring
  have hconditions (x : ℝ) (hx : x ∉ avalancheBadSet A α N n κ) :=
    avalanche_good_of_deviations A hd α N n hN x hκ hL hL2
      (fun j hj => by simpa only [hphase] using (hgood x hx).1 j hj)
      (fun j hj => by simpa only [hphase] using (hgood x hx).2 j hj)
  have havg := finiteLyapunov_avalanche_average A hc hp hd B hB hlinear α N n hN hμ
    (measurableSet_avalancheBadSet A hc hd α N n κ)
    (avalancheBadSet_mass_le A hc hp hd α N n κ hbadN hbad2N)
    (fun x hx => (hconditions x hx).1) (fun x hx => (hconditions x hx).2)
  have hweighted : |finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) +
      (n : ℝ) / (n + 2 : ℕ) * finiteLyapunov A (2*Real.pi*α) N -
      (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
          4 * B * (n + 2 : ℕ) * δ := by
    convert havg using 1
    ring
  refine ⟨hweighted, ?_⟩
  have hdiff : |finiteLyapunov A (2*Real.pi*α) N - finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤
      B := by
    apply abs_le.mpr
    have h1 := finiteLyapunov_nonneg A (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) N
    have h2 := finiteLyapunov_nonneg A (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) (2 * N)
    have h3 := finiteLyapunov_le_linear_bound A hc hd B hB hlinear (2*Real.pi*α) N
    have h4 := finiteLyapunov_le_linear_bound A hc hd B hB hlinear (2*Real.pi*α) (2 * N)
    constructor <;> linarith
  have hm : (0 : ℝ) < ((n + 2 : ℕ) : ℝ) := by positivity
  have hcor : |(2 / (n + 2 : ℕ)) *
      (finiteLyapunov A (2*Real.pi*α) N - finiteLyapunov A (2*Real.pi*α) (2 * N))| ≤
      2 * B / (n + 2 : ℕ) := by
    rw [abs_mul, abs_of_nonneg (show (0 : ℝ) ≤ 2 / (n + 2 : ℕ) by positivity)]
    calc
      _ ≤ (2 / (n + 2 : ℕ)) * B :=
        mul_le_mul_of_nonneg_left hdiff (by positivity)
      _ = _ := by ring
  have heq : finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) + finiteLyapunov A (2*Real.pi*α) N -
      2 * finiteLyapunov A (2*Real.pi*α) (2 * N) =
      (finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) +
        (n : ℝ) / (n + 2 : ℕ) * finiteLyapunov A (2*Real.pi*α) N -
        (2 * (n + 1 : ℕ) / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) (2 * N)) +
      (2 / (n + 2 : ℕ)) * (finiteLyapunov A (2*Real.pi*α) N - finiteLyapunov A (2*Real.pi*α) (2 * N)) := by
    push_cast
    field_simp
    ring
  rw [heq]
  exact (abs_add _ _).trans (add_le_add hweighted hcor)

end UAMO.CMV

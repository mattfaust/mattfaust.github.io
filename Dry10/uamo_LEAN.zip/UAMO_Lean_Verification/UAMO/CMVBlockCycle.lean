import UAMO.CMVMonodromy
import Mathlib.LinearAlgebra.Matrix.SchurComplement

noncomputable section
namespace UAMO.CMV
open Matrix

abbrev ChainSite (n : ℕ) := Fin (n + 1) × Fin 2
abbrev ChainMatrix (n : ℕ) := Matrix (ChainSite n) (ChainSite n) ℂ

def chainLower (n : ℕ) (A : ℕ → TransferMatrix) : ChainMatrix n := fun i j =>
  if i.1.val = j.1.val + 1 then A j.1.val i.2 j.2 else 0

def chainOpen (n : ℕ) (A : ℕ → TransferMatrix) : ChainMatrix n := 1 - chainLower n A

def chainSource (n : ℕ) : Matrix (ChainSite n) (Fin 2) ℂ := fun i j =>
  if i.1 = 0 then (1 : TransferMatrix) i.2 j else 0

def chainPropagator (n : ℕ) (A : ℕ → TransferMatrix) : Matrix (ChainSite n) (Fin 2) ℂ :=
  fun i j => indexedProduct A i.1.val i.2 j

def chainFeedback (n : ℕ) (A : ℕ → TransferMatrix) : Matrix (Fin 2) (ChainSite n) ℂ := fun i j =>
  if j.1 = Fin.last n then A n i j.2 else 0

def chainCycle (n : ℕ) (A : ℕ → TransferMatrix) : ChainMatrix n :=
  chainOpen n A - chainSource n * chainFeedback n A

theorem chainOpen_det (n : ℕ) (A : ℕ → TransferMatrix) : (chainOpen n A).det = 1 := by
  have ht : (chainOpen n A).BlockTriangular (fun i => OrderDual.toDual i.1) := by
    intro i j hij
    have hlt : i.1.val < j.1.val := hij
    have hne : i ≠ j := by intro h; subst j; omega
    have hstep : ¬i.1.val = j.1.val + 1 := by omega
    simp [chainOpen, chainLower, Matrix.one_apply, hne, hstep]
  rw [ht.det]
  apply Finset.prod_eq_one
  intro k _
  have hb : (chainOpen n A).toSquareBlock (fun i => OrderDual.toDual i.1) k = 1 := by
    ext i j
    have hcell : i.val.1 = j.val.1 := by
      have hi := i.property
      have hj := j.property
      exact hi.trans hj.symm
    have hstep : ¬i.val.1.val = j.val.1.val + 1 := by rw [hcell]; omega
    simp only [Matrix.toSquareBlock_def, Matrix.toBlock_apply, chainOpen, Matrix.sub_apply,
      chainLower, Matrix.of_apply, if_neg hstep, sub_zero]
    simp only [Matrix.one_apply, Subtype.ext_iff]
  rw [hb, Matrix.det_one]

theorem chainLower_propagator_zero (n : ℕ) (A : ℕ → TransferMatrix) (s t : Fin 2) :
    (chainLower n A * chainPropagator n A) (0, s) t = 0 := by
  simp [Matrix.mul_apply, chainLower]

theorem chainLower_propagator_succ (n : ℕ) (A : ℕ → TransferMatrix)
    (i : Fin n) (s t : Fin 2) :
    (chainLower n A * chainPropagator n A) (i.succ, s) t =
      (A i.val * indexedProduct A i.val) s t := by
  rw [Matrix.mul_apply, Fintype.sum_prod_type]
  rw [Finset.sum_eq_single i.castSucc]
  · simp [chainLower, chainPropagator, Matrix.mul_apply]
  · intro j _ hji
    have hne : ¬i.succ.val = j.val + 1 := by
      intro h
      apply hji
      apply Fin.ext
      simpa using (Nat.add_right_cancel h).symm
    have hval : i.val ≠ j.val := by
      intro h
      apply hji
      exact Fin.ext h.symm
    simp [chainLower, hval]
  · intro h
    exact False.elim (h (Finset.mem_univ _))

theorem chainOpen_mul_propagator (n : ℕ) (A : ℕ → TransferMatrix) :
    chainOpen n A * chainPropagator n A = chainSource n := by
  rw [chainOpen, Matrix.sub_mul, Matrix.one_mul]
  ext i t
  rcases i with ⟨i, s⟩
  refine Fin.cases ?_ (fun j => ?_) i
  · simp [chainPropagator, chainLower_propagator_zero, chainSource, indexedProduct]
  · rw [Matrix.sub_apply, chainLower_propagator_succ]
    simp [chainPropagator, chainSource, indexedProduct]

theorem chainFeedback_mul_propagator (n : ℕ) (A : ℕ → TransferMatrix) :
    chainFeedback n A * chainPropagator n A = indexedProduct A (n + 1) := by
  ext s t
  simp [Matrix.mul_apply, Fintype.sum_prod_type, chainFeedback, chainPropagator, indexedProduct]

theorem chainCycle_factor (n : ℕ) (A : ℕ → TransferMatrix) :
    chainCycle n A = chainOpen n A * (1 - chainPropagator n A * chainFeedback n A) := by
  rw [Matrix.mul_sub, Matrix.mul_one, ← Matrix.mul_assoc, chainOpen_mul_propagator]
  rfl

theorem chainCycle_det (n : ℕ) (A : ℕ → TransferMatrix) :
    (chainCycle n A).det = (1 - indexedProduct A (n + 1)).det := by
  rw [chainCycle_factor, Matrix.det_mul, chainOpen_det, one_mul,
    Matrix.det_one_sub_mul_comm, chainFeedback_mul_propagator]

end UAMO.CMV

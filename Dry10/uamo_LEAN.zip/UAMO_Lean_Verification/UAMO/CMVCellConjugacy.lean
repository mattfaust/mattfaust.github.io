import UAMO.CMVConjugacyGrowth
import UAMO.CMVFiniteTransfer

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

theorem realSzegoStep_det (lam t : ℝ) (hlam : lam ≠ 0)
    (hlt : lam^2+t^2 = 1) (z : ℂ) :
    (szegoStep (t : ℂ) (lam : ℂ) z).det = z := by
  have hlc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hc : (lam : ℂ)^2+(t : ℂ)^2 = 1 := by exact_mod_cast hlt
  rw [szegoStep_det]
  simp only [Complex.star_def, Complex.conj_ofReal]
  rw [show 1-(t : ℂ)*(t : ℂ) = (lam : ℂ)^2 by linear_combination -hc]
  field_simp

theorem gzCell_szego_conjugacy (lam t b : ℝ) (ρ : ℂ)
    (hlam : lam ≠ 0) (hlt : lam^2+t^2 = 1) {z : ℂ} (hz : z ≠ 0) :
    gzCell lam t b ρ z =
      (szegoStep (t : ℂ) (lam : ℂ) z)⁻¹ * (z⁻¹ • szegoCell lam t b ρ z) *
        szegoStep (t : ℂ) (lam : ℂ) z := by
  have hi : IsUnit (szegoStep (t : ℂ) (lam : ℂ) z).det := by
    rw [realSzegoStep_det lam t hlam hlt]
    exact isUnit_iff_ne_zero.mpr hz
  rw [gzCell_eq_szego lam t b ρ hz]
  simp only [szegoCell, mul_smul_comm, smul_mul_assoc, ← mul_assoc,
    Matrix.nonsing_inv_mul _ hi, one_mul]

theorem lyapunov_constant_conjugacy (B : ℝ → TransferMatrix)
    (hc : Continuous B) (hp : Function.Periodic B (2*Real.pi))
    (hd : ∀ x, ‖(B x).det‖ = 1) (C D : TransferMatrix)
    (hCD : C*D = 1) (hDC : D*C = 1) (ω : ℝ) :
    lyapunov (fun x => C*B x*D) ω = lyapunov B ω := by
  have hcA : Continuous (fun x => C*B x*D) :=
    (continuous_const.mul hc).mul continuous_const
  have hpA : Function.Periodic (fun x => C*B x*D) (2*Real.pi) := by
    intro x
    dsimp only
    rw [hp]
  have hdA (x : ℝ) : ‖(C*B x*D).det‖ = 1 := by
    have hh := congrArg Matrix.det hCD
    rw [Matrix.det_mul, Matrix.det_one] at hh
    rw [Matrix.det_mul, Matrix.det_mul, show C.det*(B x).det*D.det =
      (C.det*D.det)*(B x).det by ring, hh, one_mul]
    exact hd x
  exact lyapunov_conjugacy _ B hcA hc hpA hp hdA hd C D hCD hDC (fun _ => rfl) ω

def uamoGZCell (a r : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  gzCell (coupling a) (complementaryCoupling a) (oddAlpha r x)
    (star (physicalHopping r x)) z

theorem gzLyapunov_eq_uamo {a r : ℝ} (ha : 0 < a) (hr0 : 0 ≤ r) (hr1 : r < 1)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    lyapunov (uamoGZCell a r z) ω = uamoLyapunov a r ω z := by
  let X := szegoStep (complementaryCoupling a : ℂ) (coupling a : ℂ) z
  let C := physicalConjugator (coupling a) (complementaryCoupling a)
  let D := physicalConjugatorInv (coupling a) (complementaryCoupling a)
  have hCD : C*D = 1 := physicalConjugator_mul_inv _ _ (coupling_pos ha).ne'
  have hDC : D*C = 1 := physicalConjugator_inv_mul _ _ (coupling_pos ha).ne'
  have hi : IsUnit X.det := by
    rw [show X.det = z from realSzegoStep_det _ _ (coupling_pos ha).ne' (coupling_square_identity a) z]
    exact isUnit_iff_ne_zero.mpr hz
  have hXX : X*X⁻¹ = 1 := Matrix.mul_nonsing_inv X hi
  have hXX' : X⁻¹*X = 1 := Matrix.nonsing_inv_mul X hi
  have hpair : (X⁻¹*C)*(D*X) = 1 := by
    calc
      _ = X⁻¹*(C*D)*X := by simp only [mul_assoc]
      _ = 1 := by rw [hCD, mul_one, hXX']
  have hpair' : (D*X)*(X⁻¹*C) = 1 := by
    calc
      _ = D*(X*X⁻¹)*C := by simp only [mul_assoc]
      _ = 1 := by rw [hXX, mul_one, hDC]
  have heq : uamoGZCell a r z = fun x => (X⁻¹*C)*uamoTransfer a r z x*(D*X) := by
    funext x
    rw [uamoGZCell, gzCell_szego_conjugacy _ _ _ _ (coupling_pos ha).ne'
      (coupling_square_identity a) hz]
    change X⁻¹*(z⁻¹ • uamoSzegoCell a r z x)*X = _
    rw [uamoTransfer_szego_conjugacy ha r hz]
    simp only [C, D, mul_assoc]
  rw [heq]
  exact lyapunov_constant_conjugacy _ (continuous_uamoTransfer a hr0 hr1 z)
    (uamoTransfer_periodic a r z) (uamoTransfer_det_norm ha hr0 hr1 hz)
    _ _ hpair hpair' ω

end UAMO.CMV

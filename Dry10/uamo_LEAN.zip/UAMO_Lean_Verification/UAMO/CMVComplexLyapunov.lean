import UAMO.CMVLyapunov

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

theorem one_le_transferNorm_of_det_norm_ge_one (M : TransferMatrix)
    (hM : 1 ≤ ‖M.det‖) : 1 ≤ transferNorm M := by
  by_contra h
  have hnorm : ‖M‖ < 1 := lt_of_not_ge h
  have ht := ((continuous_id.matrix_det :
    Continuous (fun N : TransferMatrix => N.det)).norm).tendsto 0
  have hz : Tendsto (fun n : ℕ => ‖M.det‖^n) atTop (𝓝 0) := by
    simpa only [Function.comp_def, id_eq, Matrix.det_pow, norm_pow,
      Matrix.det_zero, norm_zero] using
      ht.comp (tendsto_pow_atTop_nhds_zero_of_norm_lt_one hnorm)
  have hge : ∀ᶠ n : ℕ in atTop, (1 : ℝ) ≤ ‖M.det‖^n := Eventually.of_forall (fun n => one_le_pow₀ hM)
  have hl : (1 : ℝ) ≤ 0 := ge_of_tendsto hz hge
  norm_num at hl

theorem transferProduct_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω x : ℝ) (n : ℕ) :
    1 ≤ ‖(transferProduct A ω x n).det‖ := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ, Matrix.det_mul, norm_mul]
    exact one_le_mul_of_one_le_of_one_le (hd _) ih

theorem one_le_transferProduct_norm_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω x : ℝ) (n : ℕ) :
    1 ≤ transferNorm (transferProduct A ω x n) :=
  one_le_transferNorm_of_det_norm_ge_one _ (transferProduct_det_norm_ge_one A hd ω x n)

theorem transferProduct_norm_pos_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω x : ℝ) (n : ℕ) :
    0 < transferNorm (transferProduct A ω x n) :=
  zero_lt_one.trans_le (one_le_transferProduct_norm_of_det_norm_ge_one A hd ω x n)

theorem transferLogNorm_nonneg_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω x : ℝ) (n : ℕ) :
    0 ≤ transferLogNorm A ω x n :=
  Real.log_nonneg (one_le_transferProduct_norm_of_det_norm_ge_one A hd ω x n)

theorem continuous_transferLogNorm_of_det_norm_ge_one (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω : ℝ) (n : ℕ) :
    Continuous (fun x => transferLogNorm A ω x n) :=
  (continuous_transferNorm.comp (continuous_transferProduct A hc ω n)).log
    (fun x => ne_of_gt (transferProduct_norm_pos_of_det_norm_ge_one A hd ω x n))

theorem transferLogNorm_add_le_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω x : ℝ) (m n : ℕ) :
    transferLogNorm A ω x (m + n) ≤
      transferLogNorm A ω (x + n * ω) m + transferLogNorm A ω x n := by
  unfold transferLogNorm
  rw [transferProduct_add]
  calc
    Real.log (transferNorm
        (transferProduct A ω (x + n * ω) m * transferProduct A ω x n)) ≤
        Real.log (transferNorm (transferProduct A ω (x + n * ω) m) *
          transferNorm (transferProduct A ω x n)) := by
      apply Real.log_le_log
      · rw [← transferProduct_add]
        exact transferProduct_norm_pos_of_det_norm_ge_one A hd ω x (m + n)
      · exact transferNorm_mul_le _ _
    _ = _ := Real.log_mul
      (ne_of_gt (transferProduct_norm_pos_of_det_norm_ge_one A hd ω _ m))
      (ne_of_gt (transferProduct_norm_pos_of_det_norm_ge_one A hd ω x n))

theorem transferLogAverage_subadditive_of_det_norm_ge_one (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2 * Real.pi)) (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω : ℝ) :
    Subadditive (transferLogAverage A ω) := by
  intro m n
  unfold transferLogAverage
  rw [← add_div]
  apply div_le_div_of_nonneg_right _ (by positivity)
  have hm : IntervalIntegrable (fun x => transferLogNorm A ω (x + n * ω) m)
      volume 0 (2 * Real.pi) := ((continuous_transferLogNorm_of_det_norm_ge_one A hc hd ω m).comp
    (show Continuous (fun x : ℝ => x + n * ω) from
      continuous_id.add continuous_const)).intervalIntegrable 0 (2 * Real.pi)
  have hn : IntervalIntegrable (fun x => transferLogNorm A ω x n)
      volume 0 (2 * Real.pi) :=
    (continuous_transferLogNorm_of_det_norm_ge_one A hc hd ω n).intervalIntegrable 0 (2 * Real.pi)
  calc
    (∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω x (m + n)) ≤
        ∫ x in (0 : ℝ)..(2 * Real.pi),
          (transferLogNorm A ω (x + n * ω) m + transferLogNorm A ω x n) :=
      intervalIntegral.integral_mono (by positivity)
        ((continuous_transferLogNorm_of_det_norm_ge_one A hc hd ω (m + n)).intervalIntegrable _ _)
        (hm.add hn) (fun x => transferLogNorm_add_le_of_det_norm_ge_one A hd ω x m n)
    _ = (∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω (x + n * ω) m) +
        ∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω x n :=
      intervalIntegral.integral_add hm hn
    _ = _ := by rw [transferLogNorm_integral_shift A hp]

theorem finiteLyapunov_nonneg_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω : ℝ) (n : ℕ) :
    0 ≤ finiteLyapunov A ω n := by
  apply div_nonneg _ (Nat.cast_nonneg n)
  apply div_nonneg _ (by positivity)
  exact intervalIntegral.integral_nonneg (by positivity)
    (fun x _ => transferLogNorm_nonneg_of_det_norm_ge_one A hd ω x n)

theorem finiteLyapunov_bddBelow_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω : ℝ) : BddBelow (range (finiteLyapunov A ω)) := by
  refine ⟨0, ?_⟩
  rintro _ ⟨n, rfl⟩
  exact finiteLyapunov_nonneg_of_det_norm_ge_one A hd ω n

theorem lyapunov_le_finite_of_det_norm_ge_one (A : ℝ → TransferMatrix)
    (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω : ℝ) {n : ℕ} (hn : 1 ≤ n) :
    lyapunov A ω ≤ finiteLyapunov A ω n :=
  csInf_le ((finiteLyapunov_bddBelow_of_det_norm_ge_one A hd ω).mono (image_subset_range _ _)) ⟨n, hn, rfl⟩

theorem tendsto_finiteLyapunov_of_det_norm_ge_one (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2 * Real.pi)) (hd : ∀ x, 1 ≤ ‖(A x).det‖) (ω : ℝ) :
    Tendsto (finiteLyapunov A ω) atTop (𝓝 (lyapunov A ω)) := by
  have h := (transferLogAverage_subadditive_of_det_norm_ge_one A hc hp hd ω).tendsto_lim
    (finiteLyapunov_bddBelow_of_det_norm_ge_one A hd ω)
  simpa only [Subadditive.lim, lyapunov, finiteLyapunov] using h

end UAMO.CMV

import UAMO.CMVLyapunov

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter Set Matrix
open scoped Topology Matrix.L2OpNorm

theorem transferNorm_smul (c : ℂ) (M : TransferMatrix) :
    transferNorm (c • M) = ‖c‖ * transferNorm M := by
  change ‖c • M‖ = ‖c‖ * ‖M‖
  exact norm_smul c M

theorem transferProduct_scalar_gauge (A : ℝ → TransferMatrix) (g : ℝ → ℂ)
    (ω x : ℝ) (n : ℕ) :
    transferProduct (fun y => g y • A y) ω x n =
      (∏ j ∈ Finset.range n, g (x+j*ω)) • transferProduct A ω x n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ, ih, transferProduct_succ, Finset.prod_range_succ]
    rw [smul_mul_smul_comm, mul_comm (g (x+n*ω))]

theorem transferProduct_norm_unit_gauge (A : ℝ → TransferMatrix) (g : ℝ → ℂ)
    (hg : ∀ x, ‖g x‖ = 1) (ω x : ℝ) (n : ℕ) :
    transferNorm (transferProduct (fun y => g y • A y) ω x n) =
      transferNorm (transferProduct A ω x n) := by
  rw [transferProduct_scalar_gauge, transferNorm_smul]
  simp only [norm_prod, hg, Finset.prod_const_one, one_mul]

theorem lyapunov_unit_gauge (A : ℝ → TransferMatrix) (g : ℝ → ℂ)
    (hg : ∀ x, ‖g x‖ = 1) (ω : ℝ) :
    lyapunov (fun y => g y • A y) ω = lyapunov A ω := by
  unfold lyapunov finiteLyapunov transferLogAverage transferLogNorm
  simp_rw [transferProduct_norm_unit_gauge A g hg]

theorem transferNorm_conjugator_pos (C D : TransferMatrix) (hCD : C*D = 1) :
    0 < transferNorm C * transferNorm D := by
  have h := transferNorm_mul_le C D
  rw [hCD, transferNorm_one] at h
  exact zero_lt_one.trans_le h

theorem transferLogNorm_conjugacy_le (A B : ℝ → TransferMatrix)
    (hA : ∀ x, ‖(A x).det‖ = 1) (hB : ∀ x, ‖(B x).det‖ = 1)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1)
    (hconj : ∀ x, A x = C*B x*D) (ω x : ℝ) (n : ℕ) :
    transferLogNorm A ω x n ≤ transferLogNorm B ω x n +
      Real.log (transferNorm C * transferNorm D) := by
  have hc := transferNorm_conjugator_pos C D hCD
  have hb := transferProduct_norm_pos B hB ω x n
  have hn : transferNorm (transferProduct A ω x n) ≤
      (transferNorm C*transferNorm D)*transferNorm (transferProduct B ω x n) := by
    rw [transferProduct_conjugacy A B C D hCD hDC hconj]
    calc
      _ ≤ (transferNorm C * transferNorm (transferProduct B ω x n))*transferNorm D :=
        (transferNorm_mul_le _ D).trans
          (mul_le_mul_of_nonneg_right (transferNorm_mul_le C _) (norm_nonneg _))
      _ = _ := by ring
  have hl := Real.log_le_log (transferProduct_norm_pos A hA ω x n) hn
  rw [Real.log_mul hc.ne' hb.ne'] at hl
  simpa only [transferLogNorm, add_comm] using hl

theorem finiteLyapunov_conjugacy_le (A B : ℝ → TransferMatrix)
    (hcA : Continuous A) (hcB : Continuous B)
    (hA : ∀ x, ‖(A x).det‖ = 1) (hB : ∀ x, ‖(B x).det‖ = 1)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1)
    (hconj : ∀ x, A x = C*B x*D) (ω : ℝ) (n : ℕ) :
    finiteLyapunov A ω n ≤ finiteLyapunov B ω n +
      Real.log (transferNorm C * transferNorm D)/(n : ℝ) := by
  have hi := intervalIntegral.integral_mono (by positivity : (0 : ℝ) ≤ 2*Real.pi)
    ((continuous_transferLogNorm A hcA hA ω n).intervalIntegrable (μ := volume) _ _)
    (((continuous_transferLogNorm B hcB hB ω n).add continuous_const).intervalIntegrable
      (μ := volume) _ _)
    (fun x => transferLogNorm_conjugacy_le A B hA hB C D hCD hDC hconj ω x n)
  rw [intervalIntegral.integral_add
    ((continuous_transferLogNorm B hcB hB ω n).intervalIntegrable _ _)
    intervalIntegrable_const] at hi
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hi
  have hdiv := div_le_div_of_nonneg_right hi (by positivity : (0 : ℝ) ≤ 2*Real.pi)
  rw [add_div, mul_div_cancel_left₀ _ (by positivity : (2*Real.pi : ℝ) ≠ 0)] at hdiv
  have hfin := div_le_div_of_nonneg_right hdiv (Nat.cast_nonneg n)
  simpa only [add_div, finiteLyapunov, transferLogAverage] using hfin

theorem lyapunov_conjugacy (A B : ℝ → TransferMatrix)
    (hcA : Continuous A) (hcB : Continuous B)
    (hpA : Function.Periodic A (2*Real.pi)) (hpB : Function.Periodic B (2*Real.pi))
    (hA : ∀ x, ‖(A x).det‖ = 1) (hB : ∀ x, ‖(B x).det‖ = 1)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1)
    (hconj : ∀ x, A x = C*B x*D) (ω : ℝ) :
    lyapunov A ω = lyapunov B ω := by
  have hsA := tendsto_finiteLyapunov A hcA hpA hA ω
  have hsB := tendsto_finiteLyapunov B hcB hpB hB ω
  have hAB := le_of_tendsto_of_tendsto' hsA
    (hsB.add (tendsto_const_div_atTop_nhds_zero_nat (Real.log (transferNorm C*transferNorm D))))
    (fun n => finiteLyapunov_conjugacy_le A B hcA hcB hA hB C D hCD hDC hconj ω n)
  have hrev (x : ℝ) : B x = D*A x*C := by
    rw [hconj]
    simp only [mul_assoc, ← mul_assoc D C, hDC, one_mul, mul_one]
  have hBA := le_of_tendsto_of_tendsto' hsB
    (hsA.add (tendsto_const_div_atTop_nhds_zero_nat (Real.log (transferNorm D*transferNorm C))))
    (fun n => finiteLyapunov_conjugacy_le B A hcB hcA hB hA D C hDC hCD hrev ω n)
  exact le_antisymm (by simpa using hAB) (by simpa using hBA)

end UAMO.CMV

import UAMO.CMVFrequencyDOSMoments

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set PhysicalDOS
open scoped Topology

theorem continuous_finiteOdd_coupling_phase (n : ℕ) (ω : ℝ) :
    Continuous (fun p : ℝ × ℝ => finiteOdd n p.1 ω p.2) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  change Continuous (fun p : ℝ × ℝ =>
    Matrix.blockDiagonal (fun l : ZMod (n+1) =>
      thetaBlock (oddAlpha p.1 (p.2+l.val*ω)) (star (physicalHopping p.1 (p.2+l.val*ω))))
        ((oddPairEquiv n).symm i) ((oddPairEquiv n).symm j))
  simp only [Matrix.blockDiagonal_apply]
  split_ifs
  · generalize ((oddPairEquiv n).symm i).1 = s
    generalize ((oddPairEquiv n).symm j).1 = t
    fin_cases s <;> fin_cases t <;>
      simp only [Fin.zero_eta, Fin.mk_one, thetaBlock, Matrix.of_apply, Matrix.cons_val_zero,
        Matrix.cons_val_one, Matrix.cons_val_fin_one, oddAlpha, physicalHopping, star_star,
        coupling, complementaryCoupling] <;> fun_prop (disch := intros; positivity)
  · exact continuous_const

theorem continuous_finiteCMV_coupling_phase (n : ℕ) (a ω : ℝ) :
    Continuous (fun p : ℝ × ℝ => finiteCMV n a p.1 ω p.2) :=
  continuous_const.mul (continuous_finiteOdd_coupling_phase n ω)

theorem continuous_finiteSpectralMeasure_moment_coupling_phase
    (n : ℕ) (a ω : ℝ) (k : ℕ) :
    Continuous (fun p : ℝ × ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a p.1 ω p.2) := by
  simp only [finiteSpectralMeasure_moment, Matrix.trace, Matrix.diag]
  apply Continuous.div_const
  apply continuous_finset_sum
  intro i _
  exact (continuous_apply i).comp ((continuous_apply i).comp
    ((continuous_finiteCMV_coupling_phase n a ω).pow k))

theorem continuous_finiteSpectralMeasure_phase_moment_coupling
    (n : ℕ) (a α : ℝ) (k : ℕ) :
    Continuous (fun r : ℝ => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*α) (2*Real.pi*θ)) := by
  have harg : Continuous (fun p : ℝ × ℝ => (p.1, 2*Real.pi*p.2)) := by fun_prop
  have hcomp := (continuous_finiteSpectralMeasure_moment_coupling_phase n a (2*Real.pi*α) k).comp harg
  have hfun : Continuous (fun p : ℝ × ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a
      p.1 (2*Real.pi*α) (2*Real.pi*p.2)) := hcomp
  have hc := continuous_parametric_integral_of_continuous (μ := volume)
    (f := fun r : ℝ => fun θ : ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r
      (2*Real.pi*α) (2*Real.pi*θ)) hfun (isCompact_Icc (a := (0:ℝ)) (b := 1))
  have heq : (fun r : ℝ => ∫ θ in Icc (0:ℝ) 1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*α) (2*Real.pi*θ)) =
      (fun r : ℝ => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*α) (2*Real.pi*θ)) := by
    funext r
    rw [intervalIntegral.integral_of_le (by norm_num : (0:ℝ) ≤ 1), integral_Icc_eq_integral_Ioc]
  rwa [heq] at hc

theorem continuous_physicalUnitaryDOS_moment_coupling (a α : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (k : ℕ) :
    Continuous (fun r : Icc (0:ℝ) 1 =>
      ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r α ha0 ha1 r.property.1 r.property.2) := by
  have hu : TendstoUniformly
      (fun n : ℕ => fun r : Icc (0:ℝ) 1 => ∫ θ in (0:ℝ)..1,
        ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*α) (2*Real.pi*θ))
      (fun r : Icc (0:ℝ) 1 =>
        ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r α ha0 ha1 r.property.1 r.property.2) atTop := by
    apply Metric.tendstoUniformly_iff.mpr
    intro ε hε
    have hlim := (tendsto_add_atTop_iff_nat 1).2
      (tendsto_const_div_atTop_nhds_zero_nat (4*(k:ℝ)))
    filter_upwards [hlim.eventually (Iio_mem_nhds hε)] with n hn r
    rw [dist_eq_norm, norm_sub_rev]
    exact (finiteSpectralMeasure_phase_moment_error n a r α ha0 ha1
      r.property.1 r.property.2 k).trans_lt hn
  apply hu.continuous
  apply Eventually.of_forall
  intro n
  have hcomp := (continuous_finiteSpectralMeasure_phase_moment_coupling n a α k).comp
    (continuous_subtype_val : Continuous (fun r : Icc (0:ℝ) 1 => (r:ℝ)))
  exact hcomp

end UAMO.CMV

import UAMO.CMVRowReduction

noncomputable section
namespace UAMO.CMV
open Matrix

def chainSiteEquiv (n : ℕ) : ChainSite n ≃ FiniteSite n where
  toFun p := (p.2, (p.1.val : ZMod (n + 1)))
  invFun p := (⟨p.2.val, ZMod.val_lt p.2⟩, p.1)
  left_inv p := by
    rcases p with ⟨i, s⟩
    simp only [Prod.mk.injEq, and_true]
    apply Fin.ext
    simp only [ZMod.val_natCast, Nat.mod_eq_of_lt i.isLt]
  right_inv p := by
    rcases p with ⟨s, j⟩
    simp only [ZMod.natCast_zmod_val]

private theorem chainSource_feedback_apply (n : ℕ) (A : ℕ → TransferMatrix)
    (i j : ChainSite n) :
    (chainSource n * chainFeedback n A) i j =
      if i.1 = 0 ∧ j.1 = Fin.last n then A n i.2 j.2 else 0 := by
  by_cases hi : i.1 = 0 <;> by_cases hj : j.1 = Fin.last n <;>
    simp [Matrix.mul_apply, chainSource, chainFeedback, hi, hj]
  have h := congrFun (congrFun (Matrix.one_mul (A n)) i.2) j.2
  simpa only [Matrix.mul_apply, Fin.sum_univ_two] using h

private theorem zmod_cast_pred_eq_iff (n : ℕ) (i j : Fin (n + 1)) :
    (i.val : ZMod (n + 1)) - 1 = (j.val : ZMod (n + 1)) ↔
      i.val = j.val + 1 ∨ (i = 0 ∧ j = Fin.last n) := by
  rw [sub_eq_iff_eq_add]
  have heq : (i.val : ZMod (n + 1)) = (j.val : ZMod (n + 1)) + 1 ↔
      i.val = (j.val + 1) % (n + 1) := by
    constructor
    · intro h
      have hjc : (j.val : ZMod (n + 1)) + 1 = ((j.val + 1 : ℕ) : ZMod (n + 1)) := by simp
      rw [hjc] at h
      have hval := congrArg (fun q : ZMod (n + 1) => q.val) h
      simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt i.isLt] using hval
    · intro h
      apply (ZMod.val_injective (n + 1))
      have hjc : (j.val : ZMod (n + 1)) + 1 = ((j.val + 1 : ℕ) : ZMod (n + 1)) := by simp
      rw [hjc]
      simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt i.isLt] using h
  rw [heq]
  by_cases hj : j = Fin.last n
  · subst j
    simp only [Fin.val_last, Nat.mod_self, true_and]
    constructor
    · intro h
      exact Or.inr ⟨Fin.ext h, trivial⟩
    · rintro (h | ⟨h, _⟩)
      · have := i.isLt; omega
      · subst i; rfl
  · have hjlt : j.val + 1 < n + 1 := by
      have hne : j.val ≠ n := by intro h; apply hj; exact Fin.ext h
      have := j.isLt
      omega
    rw [Nat.mod_eq_of_lt hjlt]
    simp only [hj, and_false, or_false]

theorem finiteTransferSystem_reindex (n : ℕ) (a r ω x : ℝ) (z : ℂ) :
    Matrix.reindexAlgEquiv ℂ ℂ (chainSiteEquiv n).symm
      (finiteTransferSystem n a r ω x z) =
        chainCycle n (fun k => finiteCellTransfer n a r ω x z k) := by
  ext i j
  rcases i with ⟨i, s⟩
  rcases j with ⟨j, t⟩
  change finiteTransferSystem n a r ω x z (chainSiteEquiv n (i, s)) (chainSiteEquiv n (j, t)) = _
  simp only [chainSiteEquiv, Equiv.coe_fn_mk, finiteTransferSystem, Matrix.sub_apply,
    PEquiv.toMatrix_toPEquiv_mul, Matrix.submatrix_apply, cellBackward, Equiv.coe_fn_mk,
    id_eq, Matrix.blockDiagonal_apply, chainCycle, chainOpen, Matrix.sub_apply,
    chainLower, chainSource_feedback_apply]
  have hone : (1 : FiniteMatrix n) (s, (i.val : ZMod (n + 1))) (t, (j.val : ZMod (n + 1))) =
      (1 : ChainMatrix n) (i, s) (j, t) := by
    have hc : ((i.val : ZMod (n + 1)) = (j.val : ZMod (n + 1))) ↔ i = j := by
      constructor
      · intro h
        apply Fin.ext
        have hval := congrArg (fun q : ZMod (n + 1) => q.val) h
        simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt i.isLt, Nat.mod_eq_of_lt j.isLt] using hval
      · rintro rfl; rfl
    simp only [Matrix.one_apply, Prod.mk.injEq, hc, and_comm]
  rw [hone]
  by_cases hp : (i.val : ZMod (n + 1)) - 1 = (j.val : ZMod (n + 1))
  · rw [if_pos hp, hp]
    rcases (zmod_cast_pred_eq_iff n i j).mp hp with hsucc | ⟨hi, hj⟩
    · have hnot : ¬(i = 0 ∧ j = Fin.last n) := by
        rintro ⟨hi, _⟩
        subst i
        simp only [Fin.val_zero] at hsucc
        omega
      rw [if_pos hsucc, if_neg hnot, sub_zero]
    · subst i
      subst j
      simp
  · have hsucc : ¬i.val = j.val + 1 := fun h => hp ((zmod_cast_pred_eq_iff n i j).mpr (Or.inl h))
    have hwrap : ¬(i = 0 ∧ j = Fin.last n) := fun h => hp ((zmod_cast_pred_eq_iff n i j).mpr (Or.inr h))
    rw [if_neg hp, if_neg hsucc, if_neg hwrap, sub_zero, sub_zero]

theorem finiteTransferSystem_det (n : ℕ) (a r ω x : ℝ) (z : ℂ) :
    (finiteTransferSystem n a r ω x z).det = (1 - finiteMonodromy n a r ω x z).det := by
  rw [← Matrix.det_reindexAlgEquiv (R := ℂ) ℂ (chainSiteEquiv n).symm,
    finiteTransferSystem_reindex, chainCycle_det]
  rfl

end UAMO.CMV

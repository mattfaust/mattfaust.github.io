import UAMO.CMVMovingFrequencyDOSConvergence
import UAMO.PhysicalDOSSpectralSupport

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set PhysicalDOS PhysicalRepresentation CircleDOS
open scoped Topology

theorem finiteEigenvalueList_mem_spectrum (n : ℕ) (a r ω x : ℝ)
    (i : Fin (finiteEigenvalueList n a r ω x).length) :
    (finiteEigenvalueList n a r ω x).get i ∈ spectrum ℂ (finiteCMV n a r ω x) := by
  have hz := finiteEigenvalueList_mem_root n a r ω x i
  rw [Polynomial.IsRoot, finiteCharpoly_eval] at hz
  simpa only [spectrum.mem_iff, Algebra.algebraMap_eq_smul_one,
    Matrix.isUnit_iff_isUnit_det, isUnit_iff_ne_zero, not_not] using hz

theorem physicalUnitaryDOS_spectral_bump_pos (a r α θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    {z : ℂ} (hz : z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ))
    {ε : ℝ} (hε : 0 < ε) :
    0 < ∫ w : ℂ, max 0 (ε - ‖w-z‖) ∂physicalUnitaryDOS a r α ha0 ha1 hr0 hr1 := by
  have hc : Continuous (fun w : ℂ => max 0 (ε - ‖w-z‖)) := by fun_prop
  have hi := integrable_continuous_of_ae_circle _
    (physicalUnitaryDOS_ae_circle a r α ha0 ha1 hr0 hr1) _ hc
  apply (integral_pos_iff_support_of_nonneg
    (fun w : ℂ => le_max_left (0:ℝ) (ε - ‖w-z‖)) hi).mpr
  change 0 < (physicalUnitaryDOS a r α ha0 ha1 hr0 hr1)
    (Function.support (fun w : ℂ => max 0 (ε - ‖w-z‖)))
  have heq : Function.support (fun w : ℂ => max 0 (ε - ‖w-z‖)) = Metric.ball z ε := by
    ext w
    simp only [Function.mem_support, ne_eq, max_eq_left_iff, not_le, sub_pos,
      Metric.mem_ball, dist_eq_norm]
  rw [heq]
  exact physicalUnitaryDOS_ball_pos_of_mem_spectrum a r α θ ha0 ha1 hr0 hr1 hz hε

theorem eventually_exists_finite_spectrum_near (a r : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (N : ℕ → ℕ) (Φ : ℕ → ℝ) {α : ℝ}
    (hN : Tendsto N atTop atTop) (hΦ : Tendsto Φ atTop (𝓝 α)) (θ : ℝ)
    {z : ℂ} (hz : z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ))
    {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ j in atTop, ∃ x : ℝ, ∃ w : ℂ,
      w ∈ spectrum ℂ (finiteCMV (N j) a r (2*Real.pi*Φ j) x) ∧ dist w z < ε := by
  let f : ℂ → ℝ := fun w => max 0 (ε - ‖w-z‖)
  have hf : Continuous f := by dsimp only [f]; fun_prop
  have hpos := physicalUnitaryDOS_spectral_bump_pos a r α θ ha0 ha1 hr0 hr1 hz hε
  have hlim := finiteSpectralMeasure_moving_frequency_real_tests_tendsto
    a r ha0 ha1 hr0 hr1 N Φ hN hΦ f (hf.comp continuous_subtype_val)
  filter_upwards [hlim.eventually (Ioi_mem_nhds hpos)] with j hj
  by_contra hn
  push_neg at hn
  have hfzero (x : ℝ) : ∫ w : ℂ, f w ∂finiteSpectralMeasure (N j) a r (2*Real.pi*Φ j) x = 0 := by
    rw [finiteSpectralMeasure_integral]
    have hzsum : (∑ i : Fin (finiteEigenvalueList (N j) a r (2*Real.pi*Φ j) x).length,
        f ((finiteEigenvalueList (N j) a r (2*Real.pi*Φ j) x).get i)) = 0 := by
      apply Finset.sum_eq_zero
      intro i _
      have hd := hn x _ (finiteEigenvalueList_mem_spectrum (N j) a r (2*Real.pi*Φ j) x i)
      rw [dist_eq_norm] at hd
      exact max_eq_left (sub_nonpos.mpr hd)
    rw [hzsum, mul_zero]
  have hzero : (∫ x in (0:ℝ)..1,
      ∫ w : ℂ, f w ∂finiteSpectralMeasure (N j) a r (2*Real.pi*Φ j) (2*Real.pi*x)) = 0 := by
    simp only [hfzero, intervalIntegral.integral_zero]
  exact (ne_of_gt hj) hzero

end UAMO.CMV

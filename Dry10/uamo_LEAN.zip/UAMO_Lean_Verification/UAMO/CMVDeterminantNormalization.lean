import UAMO.CMVCyclicDeterminant
import UAMO.CMVStateDeterminant
import UAMO.CMVFiniteSpectral

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory

theorem finiteCMV_det_norm_normalization (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) :
    ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
      (coupling a * ‖z‖) ^ (n + 1) *
        (∏ j : ZMod (n + 1), ‖physicalHopping r (x + j.val * ω)‖) *
          ‖(1 - finiteMonodromy n a r ω x z).det‖ := by
  have h := congrArg (fun M : FiniteMatrix n => ‖M.det‖)
    (finiteTransferSystem_mul_stateMatrix n ha hr hr1 ω x hz)
  simp only [Matrix.det_mul, norm_mul, finiteTransferSystem_det,
    finiteStateMatrix_det_norm, finiteResidualMatrix_det_norm n a hr hr1 ω x z,
    abs_of_pos (coupling_pos ha)] at h
  have hp := congrArg norm (finiteCMV_det_pencil n a r ω x z)
  rw [norm_mul, finiteEven_det, norm_pow, norm_neg, norm_one, one_pow, one_mul] at hp
  rw [← hp] at h
  have hb : coupling a * ‖z‖ ≠ 0 := mul_ne_zero (ne_of_gt (coupling_pos ha))
    (norm_ne_zero_iff.mpr hz)
  calc
    ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
        (coupling a * ‖z‖) ^ (n + 1) *
          ((coupling a * ‖z‖)⁻¹ ^ (n + 1) *
            ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖) := by
      rw [← mul_assoc, ← mul_pow, mul_inv_cancel₀ hb, one_pow, one_mul]
    _ = _ := by rw [← h]; ring

theorem finiteMonodromy_det_ne_zero (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    (1 - finiteMonodromy n a r ω x z).det ≠ 0 := by
  intro h
  have hn := finiteCMV_det_norm_normalization n ha hr hr1 ω x hz
  rw [h, norm_zero, mul_zero] at hn
  exact finiteCMV_det_ne_zero n a r ω x hcircle (norm_eq_zero.mp hn)

theorem finiteCMV_log_det_normalization (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Real.log ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
      (n + 1 : ℕ) * (Real.log (coupling a) + Real.log ‖z‖) +
        (∑ j : ZMod (n + 1), Real.log ‖physicalHopping r (x + j.val * ω)‖) +
          Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖ := by
  have hbase : coupling a * ‖z‖ ≠ 0 :=
    mul_ne_zero (ne_of_gt (coupling_pos ha)) (norm_ne_zero_iff.mpr hz)
  have hhop (j : ZMod (n + 1)) : ‖physicalHopping r (x + j.val * ω)‖ ≠ 0 :=
    norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 _)
  have hprod : (∏ j : ZMod (n + 1), ‖physicalHopping r (x + j.val * ω)‖) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun j _ => hhop j)
  have hmono := norm_ne_zero_iff.mpr (finiteMonodromy_det_ne_zero n ha hr hr1 ω x hz hcircle)
  rw [finiteCMV_det_norm_normalization n ha hr hr1 ω x hz,
    Real.log_mul (mul_ne_zero (pow_ne_zero _ hbase) hprod) hmono,
    Real.log_mul (pow_ne_zero _ hbase) hprod, Real.log_pow,
    Real.log_mul (ne_of_gt (coupling_pos ha)) (norm_ne_zero_iff.mpr hz),
    Real.log_prod _ _ (fun j _ => hhop j)]

theorem finite_monodromy_log_potential_identity (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖ / ((n + 1 : ℕ) : ℝ) =
      2 * (∫ w, Real.log ‖z - w‖ ∂finiteSpectralMeasure n a r ω x) -
        Real.log (coupling a) - Real.log ‖z‖ -
          (∑ j : ZMod (n + 1), Real.log ‖physicalHopping r (x + j.val * ω)‖) /
            ((n + 1 : ℕ) : ℝ) := by
  rw [finiteSpectralMeasure_log_integral n a r ω x hcircle,
    finiteCMV_log_det_normalization n ha hr hr1 ω x hz hcircle]
  push_cast
  have hn : (n : ℝ) + 1 ≠ 0 := by positivity
  field_simp
  ring

end UAMO.CMV

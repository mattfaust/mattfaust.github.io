import UAMO.CMVEmpiricalDOSLimit
import UAMO.CMVFiniteTestFunctional
import UAMO.CMVFiniteLogLimit

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter CircleDOS PhysicalDOS
open scoped Topology

local instance : MeasurableSpace Circle := borel Circle
local instance : BorelSpace Circle := ⟨rfl⟩

theorem finiteSpectralMeasure_phase_tests_tendsto (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (f : ℂ → ℂ) (hf : Continuous (fun z : Circle => f z)) :
    Tendsto (fun n => ∫ θ in (0 : ℝ)..1,
      ∫ z : ℂ, f z ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) atTop
        (𝓝 (∫ z : ℂ, f z ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)) := by
  let ν := physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1
  have hcircle := physicalUnitaryDOS_ae_circle a r Φ ha0 ha1 hr0 hr1
  letI := circleComap_probability ν hcircle
  let L₀ := circleIntegralCLM (circleComap ν)
  have hstar (g : C(Circle, ℂ)) : L₀ (star g) = star (L₀ g) := by
    change (∫ z : Circle, star (g z) ∂circleComap ν) = _
    simp only [Complex.star_def, integral_conj]
    rfl
  have hmoment (k : ℕ) : L₀ (circleCharacter k) = ∫ z : ℂ, z^k ∂ν := by
    change (∫ z : Circle, (z : ℂ)^(k : ℤ) ∂circleComap ν) = _
    simp only [zpow_natCast]
    exact circleComap_integral ν hcircle (fun z : ℂ => z^k)
  have hm (k : ℕ) : Tendsto (fun n => finitePhaseCircleTest n a r Φ (circleCharacter k))
      atTop (𝓝 (L₀ (circleCharacter k))) := by
    rw [hmoment]
    simp only [finitePhaseCircleTest_character]
    simpa only [finiteSpectralMeasure_moment] using
      finiteSpectralMeasure_phase_moments_tendsto a r Φ ha0 ha1 hr0 hr1 k
  have h := circleFunctional_tendsto_of_nat_characters
    (fun n => finitePhaseCircleTest n a r Φ) L₀
    (fun n => finitePhaseCircleTest_bound n a r Φ) (circleIntegralCLM_bound _)
    (fun n => finitePhaseCircleTest_star n a r Φ) hstar hm
    ⟨fun z : Circle => f z, hf⟩
  rw [show L₀ ⟨fun z : Circle => f z, hf⟩ = ∫ z : ℂ, f z ∂ν from
    circleComap_integral ν hcircle f] at h
  simpa only [finitePhaseCircleTest_restrict] using h

theorem finiteSpectralMeasure_phase_log_tendsto (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (z : ℂ) (hz : ‖z‖ ≠ 1) :
    Tendsto (fun n => ∫ θ in (0 : ℝ)..1,
      ∫ w : ℂ, Real.log ‖z-w‖ ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) atTop
        (𝓝 (∫ w : ℂ, Real.log ‖z-w‖ ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)) := by
  have h := finiteSpectralMeasure_phase_tests_tendsto a r Φ ha0 ha1 hr0 hr1
    (fun w => (Real.log ‖z-w‖ : ℂ)) (circleLogTest z hz).continuous
  have hre := Complex.continuous_re.continuousAt.tendsto.comp h
  simpa only [integral_complex_ofReal, intervalIntegral, integral_complex_ofReal,
    ← Complex.ofReal_sub, Complex.ofReal_re, Function.comp_def] using hre

theorem finiteSpectralLogAverage_eq_turns (a r Φ : ℝ) (z : ℂ) (n : ℕ) :
    finiteSpectralLogAverage a r (2*Real.pi*Φ) z n =
      ∫ θ in (0 : ℝ)..1,
        ∫ w : ℂ, Real.log ‖z-w‖ ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ) := by
  have h := intervalIntegral.integral_comp_mul_left (a := (0 : ℝ)) (b := 1)
    (c := 2*Real.pi)
    (fun x => ∫ w : ℂ, Real.log ‖z-w‖ ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) x)
    (by positivity)
  simpa only [finiteSpectralLogAverage, phaseMean, mul_zero, zero_mul, mul_one, one_mul,
    smul_eq_mul, div_eq_mul_inv, mul_comm] using h.symm

theorem finiteSpectralLogAverage_tendsto_physical_DOS (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (z : ℂ) (hz : ‖z‖ ≠ 1) :
    Tendsto (finiteSpectralLogAverage a r (2*Real.pi*Φ) z) atTop
      (𝓝 (∫ w : ℂ, Real.log ‖z-w‖ ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)) := by
  simpa only [← finiteSpectralLogAverage_eq_turns] using
    finiteSpectralMeasure_phase_log_tendsto a r Φ ha0 ha1 hr0 hr1 z hz

theorem uamoLyapunov_thouless_off_circle {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r < 1) (Φ : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    uamoLyapunov a r (2*Real.pi*Φ) z =
      2 * (∫ w : ℂ, Real.log ‖z-w‖ ∂physicalUnitaryDOS a r Φ ha.le ha1 hr hr1.le) -
        Real.log (coupling a) - Real.log ‖z‖ + Real.log (1+r^2) := by
  have h := tendsto_nhds_unique
    (finiteSpectralLogAverage_tendsto_physical_DOS a r Φ ha.le ha1 hr hr1.le z hcircle)
    (tendsto_finiteSpectralLogAverage ha hr hr1 (2*Real.pi*Φ) hz hcircle)
  linarith

end UAMO.CMV

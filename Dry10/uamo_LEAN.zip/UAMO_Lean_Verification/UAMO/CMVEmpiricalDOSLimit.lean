import UAMO.CMVFiniteBoundaryMoments
import UAMO.CMVFinitePhaseContinuity
import UAMO.PhysicalCMVDOSMoments
import Mathlib.Analysis.SpecificLimits.Basic

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalCMV PhysicalRealPart PhysicalRepresentation PhysicalDOS MeasureTheory Filter
open scoped Topology

def cmvSiteMoment (a r Φ θ : ℝ) (k : ℕ) (j : ℤ) : ℂ :=
  (((infiniteCMV a r Φ θ ^ k) 0 0 (delta j)) j +
   ((infiniteCMV a r Φ θ ^ k) 1 1 (delta j)) j) / 2

theorem continuous_cmvSiteMoment (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (k : ℕ) (j : ℤ) :
    Continuous (fun θ => cmvSiteMoment a r Φ θ k j) := by
  simp only [cmvSiteMoment, infiniteCMV_power_zero_entry a r Φ _ ha0 ha1 hr0 hr1,
    infiniteCMV_power_one_entry a r Φ _ ha0 ha1 hr0 hr1, walk_power_diagonal_at_site]
  exact (((continuous_walk_source_entry a r Φ k 1 1).comp
    ((continuous_id.sub continuous_const).add continuous_const)).add
    ((continuous_walk_source_entry a r Φ k 0 0).comp
      (continuous_id.add continuous_const))).div_const 2

theorem cmv_bulk_normalization (n : ℕ) (a r Φ θ : ℝ) (k : ℕ) :
    (∑ j : Fin (n+1), ∑ s : Fin 2,
      ((infiniteCMV a r Φ θ^k) s s (delta (j.val : ℤ))) (j.val : ℤ)) /
        ((2*(n+1) : ℕ) : ℂ) =
      (∑ j : Fin (n+1), cmvSiteMoment a r Φ θ k (j.val : ℤ)) / ((n+1 : ℕ) : ℂ) := by
  simp only [cmvSiteMoment, Fin.sum_univ_two, ← Finset.sum_div]
  push_cast
  field_simp

theorem cmv_bulk_integral (n : ℕ) (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (k : ℕ) :
    (∫ θ in (0 : ℝ)..1,
      (∑ j : Fin (n+1), cmvSiteMoment a r Φ θ k (j.val : ℤ)) / ((n+1 : ℕ) : ℂ)) =
      ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 := by
  rw [intervalIntegral.integral_div, intervalIntegral.integral_finset_sum]
  · simp only [cmvSiteMoment,
      infiniteCMV_site_phase_averaged_moments a r Φ ha0 ha1 hr0 hr1,
      Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    have hn : ((n+1 : ℕ) : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.succ_ne_zero n)
    exact mul_div_cancel_left₀ _ hn
  · intro j _
    exact (continuous_cmvSiteMoment a r Φ ha0 ha1 hr0 hr1 k (j.val : ℤ)).intervalIntegrable _ _

theorem finiteSpectralMeasure_phase_moment_error (n : ℕ) (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (k : ℕ) :
    ‖(∫ θ in (0 : ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) -
      ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1‖ ≤
      4*(k : ℝ)/(n+1 : ℕ) := by
  have hfin : IntervalIntegrable (fun θ =>
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ))
      volume (0 : ℝ) 1 :=
    ((continuous_finiteSpectralMeasure_moment n a r (2*Real.pi*Φ) k).comp
      (continuous_const.mul continuous_id)).intervalIntegrable _ _
  have hbulk : IntervalIntegrable (fun θ =>
      (∑ j : Fin (n+1), cmvSiteMoment a r Φ θ k (j.val : ℤ)) / ((n+1 : ℕ) : ℂ))
      volume (0 : ℝ) 1 := by
    apply Continuous.intervalIntegrable
    apply Continuous.div_const
    exact continuous_finset_sum _ (fun j _ => continuous_cmvSiteMoment a r Φ ha0 ha1 hr0 hr1 k _)
  rw [← cmv_bulk_integral n a r Φ ha0 ha1 hr0 hr1 k,
    ← intervalIntegral.integral_sub hfin hbulk]
  have hb (θ : ℝ) : ‖(∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r
      (2*Real.pi*Φ) (2*Real.pi*θ)) -
      (∑ j : Fin (n+1), cmvSiteMoment a r Φ θ k (j.val : ℤ)) / ((n+1 : ℕ) : ℂ)‖ ≤
      4*(k : ℝ)/(n+1 : ℕ) := by
    rw [finiteSpectralMeasure_moment, ← cmv_bulk_normalization]
    exact finiteCMV_trace_power_bulk_error n a r Φ θ ha0 ha1 hr0 hr1 k
  simpa using intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0 : ℝ)) (b := 1) (fun θ _ => hb θ)

theorem finiteSpectralMeasure_phase_moments_tendsto (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (k : ℕ) :
    Tendsto (fun n => ∫ θ in (0 : ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) atTop
        (𝓝 (∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)) := by
  apply tendsto_iff_norm_sub_tendsto_zero.mpr
  exact squeeze_zero (fun n => norm_nonneg _)
    (fun n => finiteSpectralMeasure_phase_moment_error n a r Φ ha0 ha1 hr0 hr1 k)
    ((tendsto_add_atTop_iff_nat 1).2 (tendsto_const_div_atTop_nhds_zero_nat (4*(k : ℝ))))

end UAMO.CMV

import UAMO.CMVFiniteNormalSpectrum
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory

theorem finiteSpectralMeasure_integral_complex (n : ℕ) (a r ω x : ℝ) (f : ℂ → ℂ) :
    ∫ w, f w ∂finiteSpectralMeasure n a r ω x =
      (((2 * (n + 1) : ℕ) : ℂ)⁻¹) *
        ∑ i : Fin (finiteEigenvalueList n a r ω x).length,
          f ((finiteEigenvalueList n a r ω x).get i) := by
  rw [finiteSpectralMeasure, integral_smul_measure,
    integral_finset_sum_measure (fun _ _ => integrable_dirac)]
  simp only [integral_dirac, ENNReal.toReal_inv, ENNReal.toReal_natCast,
    Complex.real_smul, Complex.ofReal_inv, Complex.ofReal_natCast]

theorem finiteCMV_trace_power (n : ℕ) (a r ω x : ℝ) (k : ℕ) :
    (finiteCMV n a r ω x ^ k).trace =
      ∑ i : Fin (finiteEigenvalueList n a r ω x).length,
        ((finiteEigenvalueList n a r ω x).get i) ^ k := by
  have hU := finiteCMV_unitary n a r ω x
  have hc : Commute (finiteCMV n a r ω x) (star (finiteCMV n a r ω x)) := by
    show _ * _ = _ * _
    rw [unitary.mul_star_self_of_mem hU, unitary.star_mul_self_of_mem hU]
  rw [normal_matrix_trace_power_roots _ hc k]
  have hl : (↑(finiteEigenvalueList n a r ω x) : Multiset ℂ) =
      (finiteCMV n a r ω x).charpoly.roots := Multiset.coe_toList _
  rw [← hl, Multiset.map_coe, Multiset.sum_coe]
  conv_lhs => rw [← List.ofFn_get (finiteEigenvalueList n a r ω x)]
  rw [List.map_ofFn, List.sum_ofFn]
  rfl

theorem finiteSpectralMeasure_moment (n : ℕ) (a r ω x : ℝ) (k : ℕ) :
    (∫ w : ℂ, w ^ k ∂finiteSpectralMeasure n a r ω x) =
      (finiteCMV n a r ω x ^ k).trace / ((2 * (n + 1) : ℕ) : ℂ) := by
  rw [finiteSpectralMeasure_integral_complex, ← finiteCMV_trace_power]
  rw [div_eq_mul_inv, mul_comm]

theorem finiteCMV_power_entry_norm_le_one (n : ℕ) (a r ω x : ℝ) (k : ℕ)
    (i j : FiniteSite n) : ‖(finiteCMV n a r ω x ^ k) i j‖ ≤ 1 :=
  entry_norm_bound_of_unitary ((unitary _).pow_mem (finiteCMV_unitary n a r ω x) k) i j

end UAMO.CMV

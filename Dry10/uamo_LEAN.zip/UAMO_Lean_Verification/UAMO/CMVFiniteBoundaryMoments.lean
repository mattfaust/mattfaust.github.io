import UAMO.CMVFinitePropagation
import UAMO.CMVEmpiricalDOSMoments

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalCMV PhysicalRealPart PhysicalRepresentation

theorem cmv_boundary_card_le (n k : ℕ) :
    (Finset.univ.filter (fun j : Fin n => ¬ (k ≤ j.val ∧ j.val + k < n))).card ≤ 2 * k := by
  let L := Finset.univ.filter (fun j : Fin n => j.val < k)
  let R := Finset.univ.filter (fun j : Fin n => n ≤ j.val + k)
  have hL : L.card ≤ k := by
    have h := Finset.card_le_card_of_injOn (s := L) (t := Finset.range k)
      (fun j : Fin n => j.val) (by intro j hj; simpa [L] using hj)
      (by intro i _ j _ hij; exact Fin.ext hij)
    simpa using h
  have hR : R.card ≤ k := by
    have h := Finset.card_le_card_of_injOn (s := R) (t := Finset.range k)
      (fun j : Fin n => n - 1 - j.val) (by
        intro j hj
        have hj' : n ≤ j.val + k := (Finset.mem_filter.mp hj).2
        simp only [Finset.mem_range]
        have := j.isLt
        omega) (by
        intro i _ j _ hij
        dsimp only at hij
        apply Fin.ext
        have := i.isLt
        have := j.isLt
        omega)
    simpa using h
  have heq : Finset.univ.filter (fun j : Fin n => ¬ (k ≤ j.val ∧ j.val + k < n)) = L ∪ R := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_union, L, R]
    omega
  rw [heq]
  exact (Finset.card_union_le L R).trans (by omega)

theorem finiteMatrix_trace_cells (n : ℕ) (B : FiniteMatrix n) :
    B.trace = ∑ j : Fin (n+1), ∑ s : Fin 2,
      B (s, (j.val : ZMod (n+1))) (s, (j.val : ZMod (n+1))) := by
  rw [Matrix.trace, Fintype.sum_prod_type, Finset.sum_comm]
  have hc (j : Fin (n+1)) : (ZMod.finEquiv (n+1)).toEquiv j = (j.val : ZMod (n+1)) :=
    (ZMod.natCast_zmod_val ((ZMod.finEquiv (n+1)).toEquiv j)).symm
  simpa only [Matrix.diag, hc] using ((ZMod.finEquiv (n+1)).toEquiv.sum_comp
    (fun j : ZMod (n+1) => ∑ s : Fin 2, B (s,j) (s,j))).symm

theorem finiteCMV_trace_power_bulk_error (n : ℕ) (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (k : ℕ) :
    ‖(finiteCMV n a r (2*Real.pi*Φ) (2*Real.pi*θ)^k).trace /
        ((2*(n+1) : ℕ) : ℂ) -
      (∑ j : Fin (n+1), ∑ s : Fin 2,
        ((infiniteCMV a r Φ θ^k) s s (delta (j.val : ℤ))) (j.val : ℤ)) /
          ((2*(n+1) : ℕ) : ℂ)‖ ≤ 4 * (k : ℝ) / (n+1 : ℕ) := by
  let S := Finset.univ.filter (fun j : Fin (n+1) => ¬ (k ≤ j.val ∧ j.val+k < n+1))
  let d : Fin (n+1) → ℂ := fun j => ∑ s : Fin 2,
    ((finiteCMV n a r (2*Real.pi*Φ) (2*Real.pi*θ)^k)
      (s, (j.val : ZMod (n+1))) (s, (j.val : ZMod (n+1))) -
    ((infiniteCMV a r Φ θ^k) s s (delta (j.val : ℤ))) (j.val : ℤ))
  have hnorm (j : Fin (n+1)) : ‖d j‖ ≤ 4 := by
    have he (s : Fin 2) : ‖(finiteCMV n a r (2*Real.pi*Φ) (2*Real.pi*θ)^k)
        (s, (j.val : ZMod (n+1))) (s, (j.val : ZMod (n+1))) -
        ((infiniteCMV a r Φ θ^k) s s (delta (j.val : ℤ))) (j.val : ℤ)‖ ≤ 2 := by
      have hf := finiteCMV_power_entry_norm_le_one n a r (2*Real.pi*Φ) (2*Real.pi*θ) k
        (s, (j.val : ZMod (n+1))) (s, (j.val : ZMod (n+1)))
      have hi := spin_coordinate_entry_norm_le_one (infiniteCMV a r Φ θ^k)
        ((unitary _).pow_mem (infiniteCMV_unitary a r Φ θ ha0 ha1 hr0 hr1) k) s (j.val : ℤ)
      exact (norm_sub_le _ _).trans (by linarith)
    apply (norm_sum_le _ _).trans
    have hh := Finset.sum_le_sum (s := Finset.univ) (fun s _ => he s)
    norm_num only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hh
    exact hh
  have hsum : (∑ j, d j) = ∑ j ∈ S, d j := by
    symm
    apply Finset.sum_subset (Finset.subset_univ _)
    intro j _ hj
    have hj' : k ≤ j.val ∧ j.val+k < n+1 := by simpa [S] using hj
    apply Finset.sum_eq_zero
    intro s _
    exact sub_eq_zero.mpr (finiteCMV_power_diagonal_interior n a r Φ θ k j.val hj'.1 hj'.2 s)
  have hbound : ‖∑ j, d j‖ ≤ 8 * (k : ℝ) := by
    rw [hsum]
    calc
      _ ≤ ∑ _j ∈ S, (4 : ℝ) :=
        (norm_sum_le _ _).trans (Finset.sum_le_sum (fun j _ => hnorm j))
      _ = (S.card : ℝ)*4 := by simp
      _ ≤ ((2*k : ℕ) : ℝ)*4 := mul_le_mul_of_nonneg_right
        (by exact_mod_cast cmv_boundary_card_le (n+1) k) (by norm_num)
      _ = _ := by push_cast; ring
  rw [finiteMatrix_trace_cells, ← sub_div, ← Finset.sum_sub_distrib]
  simp only [← Finset.sum_sub_distrib]
  change ‖(∑ j, d j) / ((2*(n+1) : ℕ) : ℂ)‖ ≤ _
  rw [norm_div, Complex.norm_natCast]
  calc
    _ ≤ (8*(k : ℝ)) / ((2*(n+1) : ℕ) : ℝ) :=
      div_le_div_of_nonneg_right hbound (by positivity)
    _ = _ := by
      push_cast
      field_simp
      ring

end UAMO.CMV

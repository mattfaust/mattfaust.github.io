import UAMO.PolynomialCocycleFourier
import UAMO.CMVLogAlmostInvariance
import Mathlib.Analysis.Fourier.AddCircle

noncomputable section
namespace UAMO.CMV
open MeasureTheory CircleDOS

local instance finiteLogCirclePeriod : Fact (0<(1:ℝ)) := ⟨by norm_num⟩

def finiteFrobeniusLog (A : ℝ→TransferMatrix) (ω : ℝ) (n : ℕ) (t : ℝ) : ℝ :=
  Real.log (transferFrobeniusSq (transferProduct A ω (2*Real.pi*t) n))/(2*(n:ℝ))

theorem continuous_transferFrobeniusSq : Continuous transferFrobeniusSq := by
  unfold transferFrobeniusSq
  fun_prop

theorem continuous_finiteFrobeniusLog (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hd : ∀x,‖(A x).det‖=1) (ω : ℝ) (n : ℕ) : Continuous (finiteFrobeniusLog A ω n) := by
  have hprod := (continuous_transferProduct A hc ω n).comp
    (show Continuous (fun t:ℝ => 2*Real.pi*t) by fun_prop)
  exact ((continuous_transferFrobeniusSq.comp hprod).log (fun t =>
    (transferFrobeniusSq_pos_of_det_ne_zero _ (by
      intro h; dsimp only [Function.comp_def] at h
      have hh := transferProduct_det_norm A hd ω (2*Real.pi*t) n
      simp [h] at hh)).ne')).div_const _

theorem finiteFrobeniusLog_periodic (A : ℝ→TransferMatrix)
    (hp : Function.Periodic A (2*Real.pi)) (ω : ℝ) (n : ℕ) :
    Function.Periodic (finiteFrobeniusLog A ω n) 1 := by
  intro t
  unfold finiteFrobeniusLog
  rw [show 2*Real.pi*(t+1)=2*Real.pi*t+2*Real.pi by ring]
  exact congrArg (fun M => Real.log (transferFrobeniusSq M)/(2*(n:ℝ)))
    (transferProduct_periodic A hp ω n (2*Real.pi*t))

def finiteFrobeniusCircle (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    (ω : ℝ) (n : ℕ) : C(AddCircle (1:ℝ),ℂ) := by
  let hper : Function.Periodic (fun t => (finiteFrobeniusLog A ω n t:ℂ)) 1 :=
    fun t => congrArg Complex.ofReal (finiteFrobeniusLog_periodic A hp ω n t)
  exact ⟨hper.lift,(Complex.continuous_ofReal.comp
    (continuous_finiteFrobeniusLog A hc hd ω n)).quotient_liftOn' _⟩

@[simp] theorem finiteFrobeniusCircle_coe (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    (ω t : ℝ) (n : ℕ) :
    finiteFrobeniusCircle A hc hp hd ω n (t:AddCircle (1:ℝ))=
      (finiteFrobeniusLog A ω n t:ℂ) := rfl

theorem fourier_coe_eq_logFourierChar (k : ℤ) (t : ℝ) :
    _root_.fourier k (t:AddCircle (1:ℝ))=logFourierChar k t := by
  rw [_root_.fourier_coe_apply]
  unfold logFourierChar
  congr 1
  push_cast
  ring

theorem fourierCoeff_finiteFrobeniusCircle (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    (ω : ℝ) (n : ℕ) (k : ℤ) :
    _root_.fourierCoeff (finiteFrobeniusCircle A hc hp hd ω n) k=
      logFourierCoeff (finiteFrobeniusLog A ω n) k := by
  have h := _root_.fourierCoeff_eq_intervalIntegral (finiteFrobeniusCircle A hc hp hd ω n) k (0:ℝ)
  simpa only [zero_add,one_div_one,one_smul,fourier_coe_eq_logFourierChar,
    finiteFrobeniusCircle_coe,smul_eq_mul,mul_comm,logFourierCoeff] using h

theorem finiteFrobeniusLog_operator_bounds (A : ℝ→TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) (ω : ℝ) {n : ℕ} (hn : 0<n) (t : ℝ) :
    0≤finiteFrobeniusLog A ω n t-transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ) ∧
    finiteFrobeniusLog A ω n t-transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ)≤
      Real.log 2/(2*(n:ℝ)) := by
  have hdet := transferProduct_det_norm A hd ω (2*Real.pi*t) n
  have hd0 : (transferProduct A ω (2*Real.pi*t) n).det≠0 := by
    intro h; simp [h] at hdet
  simpa only [normalizedFrobeniusLog_of_det_norm_one _ hdet,hdet,Real.log_one,
    zero_div,sub_zero,finiteFrobeniusLog,transferLogNorm] using
    normalizedFrobeniusLog_operator_gap _ hd0 hn

theorem finiteFrobeniusLog_shift_difference (A : ℝ→TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (α t : ℝ) {n : ℕ} (hn : 0<n) :
    |finiteFrobeniusLog A (2*Real.pi*α) n (t+α)-finiteFrobeniusLog A (2*Real.pi*α) n t|≤
      (Real.log (4*C^2)+Real.log 2)/(n:ℝ) := by
  have hl := finiteFrobeniusLog_operator_bounds A hd (2*Real.pi*α) hn (t+α)
  have hr := finiteFrobeniusLog_operator_bounds A hd (2*Real.pi*α) hn t
  have h := normalized_transferLogNorm_int_shift_difference A hd hC
    (2*Real.pi*α) (2*Real.pi*t) hn 1
  simp only [Int.cast_one,one_mul,abs_one] at h
  rw [mul_add] at hl
  obtain ⟨hlo,hhi⟩ := abs_le.mp h
  have htwo : Real.log 2/(n:ℝ)=2*(Real.log 2/(2*(n:ℝ))) := by ring
  rw [abs_le,add_div]
  constructor <;> linarith [show 0≤Real.log 2/(2*(n:ℝ)) by positivity]

theorem finiteFrobeniusCircle_shift_difference (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    {C : ℝ} (hC : ∀x,transferNorm (A x)≤C) (α : ℝ) {n : ℕ} (hn : 0<n)
    (x : AddCircle (1:ℝ)) :
    ‖finiteFrobeniusCircle A hc hp hd (2*Real.pi*α) n (x+(α:AddCircle (1:ℝ)))-
      finiteFrobeniusCircle A hc hp hd (2*Real.pi*α) n x‖≤
      (Real.log (4*C^2)+Real.log 2)/(n:ℝ) := by
  induction x using QuotientAddGroup.induction_on with
  | H t =>
    change ‖finiteFrobeniusCircle A hc hp hd (2*Real.pi*α) n ((t+α:ℝ):AddCircle (1:ℝ))-
      finiteFrobeniusCircle A hc hp hd (2*Real.pi*α) n (t:AddCircle (1:ℝ))‖≤_
    rw [finiteFrobeniusCircle_coe,finiteFrobeniusCircle_coe,← Complex.ofReal_sub,
      Complex.norm_real,Real.norm_eq_abs]
    exact finiteFrobeniusLog_shift_difference A hd hC α t hn

theorem finiteLyapunov_eq_unit_interval (A : ℝ→TransferMatrix) (ω : ℝ) (n : ℕ) :
    finiteLyapunov A ω n=∫t in (0:ℝ)..1,transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ) := by
  have h := intervalIntegral.integral_comp_mul_left
    (a:=0) (b:=1) (c:=2*Real.pi) (fun x => transferLogNorm A ω x n) (by positivity)
  have he : (∫t in (0:ℝ)..1,transferLogNorm A ω (2*Real.pi*t) n)=
      (∫x in (0:ℝ)..2*Real.pi,transferLogNorm A ω x n)/(2*Real.pi) := by
    simpa only [mul_zero,mul_one,zero_mul,one_mul,smul_eq_mul,div_eq_mul_inv,mul_comm] using h
  rw [intervalIntegral.integral_div,he]
  rfl

theorem finiteFrobeniusLog_mean_bounds (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hd : ∀x,‖(A x).det‖=1) (ω : ℝ) {n : ℕ} (hn : 0<n) :
    0≤(∫t in (0:ℝ)..1,finiteFrobeniusLog A ω n t)-finiteLyapunov A ω n ∧
    (∫t in (0:ℝ)..1,finiteFrobeniusLog A ω n t)-finiteLyapunov A ω n≤Real.log 2/(2*(n:ℝ)) := by
  have hf := (continuous_finiteFrobeniusLog A hc hd ω n).intervalIntegrable (μ:=volume) 0 1
  have hg := (((continuous_transferLogNorm A hc hd ω n).comp
    (show Continuous (fun t:ℝ => 2*Real.pi*t) by fun_prop)).div_const (n:ℝ)).intervalIntegrable
      (μ:=volume) 0 1
  dsimp only [Function.comp_def] at hg
  rw [finiteLyapunov_eq_unit_interval,← intervalIntegral.integral_sub hf hg]
  constructor
  · exact intervalIntegral.integral_nonneg (by norm_num)
      (fun t _ => (finiteFrobeniusLog_operator_bounds A hd ω hn t).1)
  · have h := intervalIntegral.integral_mono (by norm_num : (0:ℝ)≤1)
      (hf.sub hg) (intervalIntegrable_const : IntervalIntegrable
        (fun _:ℝ => Real.log 2/(2*(n:ℝ))) volume 0 1)
      (fun t => (finiteFrobeniusLog_operator_bounds A hd ω hn t).2)
    simpa using h

end UAMO.CMV

import UAMO.CMVTransferDetGrowth
import UAMO.CMVHoppingIntegral

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter
open scoped Topology

def phaseMean (f : ℝ → ℝ) : ℝ := (∫ x in (0 : ℝ)..(2 * Real.pi), f x) / (2 * Real.pi)

theorem phaseMean_sub (f g : ℝ → ℝ) (hf : Continuous f) (hg : Continuous g) :
    phaseMean (fun x => f x - g x) = phaseMean f - phaseMean g := by
  rw [phaseMean, intervalIntegral.integral_sub (hf.intervalIntegrable _ _) (hg.intervalIntegrable _ _)]
  exact sub_div _ _ _

@[simp] theorem phaseMean_const (c : ℝ) : phaseMean (fun _ => c) = c := by
  simp only [phaseMean, intervalIntegral.integral_const, sub_zero, smul_eq_mul]
  exact mul_div_cancel_left₀ _ (by positivity : (2 * Real.pi : ℝ) ≠ 0)

theorem phaseMean_const_mul (c : ℝ) (f : ℝ → ℝ) :
    phaseMean (fun x => c * f x) = c * phaseMean f := by
  unfold phaseMean
  rw [intervalIntegral.integral_const_mul]
  ring

theorem phaseMean_div_const (f : ℝ → ℝ) (c : ℝ) :
    phaseMean (fun x => f x / c) = phaseMean f / c := by
  unfold phaseMean
  rw [intervalIntegral.integral_div]
  ring

theorem continuous_physicalHopping_log {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) :
    Continuous (fun x => Real.log ‖physicalHopping r x‖) := by
  apply Continuous.log
  · unfold physicalHopping; fun_prop
  · intro x; exact norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 x)

theorem physicalHopping_log_periodic (r : ℝ) :
    Function.Periodic (fun x => Real.log ‖physicalHopping r x‖) (2 * Real.pi) := by
  intro x
  simp only [physicalHopping, Real.cos_add_two_pi]

theorem phaseMean_physicalHopping_log {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) :
    phaseMean (fun x => Real.log ‖physicalHopping r x‖) = -Real.log (1 + r^2) := by
  have hc := intervalIntegral.integral_comp_mul_left (a := (0 : ℝ)) (b := 1)
    (c := 2 * Real.pi) (fun x => Real.log ‖physicalHopping r x‖) (by positivity)
  have hconv : (∫ t in (0 : ℝ)..1, Real.log ‖physicalHopping r (2 * Real.pi * t)‖) =
      phaseMean (fun x => Real.log ‖physicalHopping r x‖) := by
    simpa only [phaseMean, mul_zero, zero_mul, mul_one, one_mul, smul_eq_mul, div_eq_mul_inv, mul_comm] using hc
  rw [← hconv, physicalHopping_log_integral hr hr1]

theorem phaseMean_physicalHopping_log_shift {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (t : ℝ) :
    phaseMean (fun x => Real.log ‖physicalHopping r (x + t)‖) = -Real.log (1 + r^2) := by
  have h := (physicalHopping_log_periodic r).intervalIntegral_add_eq t 0
  unfold phaseMean
  dsimp only
  rw [intervalIntegral.integral_comp_add_right (fun y => Real.log ‖physicalHopping r y‖) t]
  have heq : (∫ x in t..(2 * Real.pi + t), Real.log ‖physicalHopping r x‖) =
      ∫ x in (0 : ℝ)..(2 * Real.pi), Real.log ‖physicalHopping r x‖ := by
    simpa only [zero_add, add_comm (2 * Real.pi) t] using h
  rw [zero_add, heq]
  exact phaseMean_physicalHopping_log hr hr1

theorem phaseMean_finiteHopping_log {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (n : ℕ) (ω : ℝ) :
    phaseMean (fun x => (∑ j : ZMod (n + 1), Real.log ‖physicalHopping r (x + j.val * ω)‖) /
      ((n + 1 : ℕ) : ℝ)) = -Real.log (1 + r^2) := by
  rw [phaseMean_div_const]
  have hsum : phaseMean (fun x => ∑ j : ZMod (n + 1),
      Real.log ‖physicalHopping r (x + j.val * ω)‖) =
      ∑ j : ZMod (n + 1), phaseMean (fun x => Real.log ‖physicalHopping r (x + j.val * ω)‖) := by
    unfold phaseMean
    dsimp only
    rw [intervalIntegral.integral_finset_sum
      (f := fun j : ZMod (n + 1) => fun x => Real.log ‖physicalHopping r (x + j.val * ω)‖)
      (fun j _ =>
      ((continuous_physicalHopping_log hr hr1).comp (continuous_id.add continuous_const)).intervalIntegrable _ _)]
    exact Finset.sum_div _ _ _
  rw [hsum]
  simp only [phaseMean_physicalHopping_log_shift hr hr1, Finset.sum_const, Finset.card_univ,
    ZMod.card, nsmul_eq_mul]
  exact mul_div_cancel_left₀ _ (by positivity : ((n + 1 : ℕ) : ℝ) ≠ 0)

def finiteSpectralLogAverage (a r ω : ℝ) (z : ℂ) (n : ℕ) : ℝ :=
  phaseMean (fun x => ∫ w, Real.log ‖z - w‖ ∂finiteSpectralMeasure n a r ω x)

theorem finiteMonodromyLogAverage_eq_spectral (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    finiteMonodromyLogAverage a r ω z n = 2 * finiteSpectralLogAverage a r ω z n -
      Real.log (coupling a) - Real.log ‖z‖ + Real.log (1 + r^2) := by
  let f := fun x => ∫ w, Real.log ‖z - w‖ ∂finiteSpectralMeasure n a r ω x
  let g := fun x => Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖ / ((n + 1 : ℕ) : ℝ)
  let h := fun x => (∑ j : ZMod (n + 1), Real.log ‖physicalHopping r (x + j.val * ω)‖) /
    ((n + 1 : ℕ) : ℝ)
  have hg : Continuous g := (continuous_finiteMonodromy_logDet ha hr hr1 ω hz hcircle n).div_const _
  have hh : Continuous h := by
    apply Continuous.div_const
    apply continuous_finset_sum
    intro j _
    exact (continuous_physicalHopping_log hr hr1).comp (continuous_id.add continuous_const)
  have heq (x : ℝ) : g x = 2 * f x - Real.log (coupling a) - Real.log ‖z‖ - h x :=
    finite_monodromy_log_potential_identity n ha hr hr1 ω x hz hcircle
  have hf : Continuous f := by
    have he : f = fun x => (g x + Real.log (coupling a) + Real.log ‖z‖ + h x) / 2 := by
      funext x
      have := heq x
      linarith
    rw [he]
    exact (((hg.add continuous_const).add continuous_const).add hh).div_const 2
  have hmean : phaseMean g =
      2 * phaseMean f - Real.log (coupling a) - Real.log ‖z‖ - phaseMean h := by
    rw [show g = (fun x => 2 * f x - Real.log (coupling a) - Real.log ‖z‖ - h x) from funext heq]
    rw [phaseMean_sub _ _ (((continuous_const.mul hf).sub continuous_const).sub continuous_const) hh,
      phaseMean_sub _ _ ((continuous_const.mul hf).sub continuous_const) continuous_const,
      phaseMean_sub _ _ (continuous_const.mul hf) continuous_const,
      phaseMean_const_mul, phaseMean_const, phaseMean_const]
  have hgmean : phaseMean g = finiteMonodromyLogAverage a r ω z n := by
    dsimp only [g]
    rw [phaseMean_div_const]
    rfl
  rw [hgmean, show phaseMean h = -Real.log (1 + r^2) from
    phaseMean_finiteHopping_log hr hr1 n ω] at hmean
  simpa only [finiteSpectralLogAverage, f, sub_neg_eq_add] using hmean

theorem tendsto_finiteSpectralLogAverage {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Tendsto (finiteSpectralLogAverage a r ω z) atTop
      (𝓝 ((uamoLyapunov a r ω z + Real.log (coupling a) + Real.log ‖z‖ -
        Real.log (1 + r^2)) / 2)) := by
  have h := ((((tendsto_finiteMonodromyLogAverage ha hr hr1 ω hz hcircle).add_const
    (Real.log (coupling a))).add_const (Real.log ‖z‖)).sub_const (Real.log (1 + r^2))).div_const 2
  have heq (n : ℕ) : finiteSpectralLogAverage a r ω z n =
      (finiteMonodromyLogAverage a r ω z n + Real.log (coupling a) + Real.log ‖z‖ -
        Real.log (1 + r^2)) / 2 := by
    have hh := finiteMonodromyLogAverage_eq_spectral n ha hr hr1 ω hz hcircle
    linarith
  simpa only [← heq] using h

end UAMO.CMV

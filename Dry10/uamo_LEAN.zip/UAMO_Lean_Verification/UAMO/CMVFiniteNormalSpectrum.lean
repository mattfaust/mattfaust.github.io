import UAMO.CMVFiniteSpectral
import Mathlib.Analysis.InnerProductSpace.JointEigenspace
import Mathlib.LinearAlgebra.Charpoly.ToMatrix
import Mathlib.LinearAlgebra.Trace
import Mathlib.LinearAlgebra.Matrix.Hermitian

noncomputable section
namespace UAMO.CMV
open Matrix Module.End Polynomial
open scoped ComplexStarModule

set_option maxHeartbeats 1200000
set_option maxRecDepth 4096

section NormalMatrices
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

omit [DecidableEq ι] in
private theorem normal_real_imag_commute (U : Matrix ι ι ℂ) (hU : Commute U (star U)) :
    Commute (realPart U : Matrix ι ι ℂ) (imaginaryPart U : Matrix ι ι ℂ) := by
  rw [realPart_apply_coe, imaginaryPart_apply_coe]
  exact (((Commute.refl U).sub_right hU).add_left
    (hU.symm.sub_right (Commute.refl (star U)))).smul_left _ |>.smul_right _ |>.smul_right _

theorem normal_matrix_eigenbasis (U : Matrix ι ι ℂ) (hU : Commute U (star U)) :
    ∃ (b : Basis (Fin (Fintype.card ι)) ℂ (EuclideanSpace ℂ ι))
      (d : Fin (Fintype.card ι) → ℂ),
      ∀ i, Matrix.toEuclideanLin U (b i) = d i • b i := by
  classical
  let A := Matrix.toEuclideanLin (realPart U : Matrix ι ι ℂ)
  let B := Matrix.toEuclideanLin (imaginaryPart U : Matrix ι ι ℂ)
  have hA : A.IsSymmetric := (Matrix.isHermitian_iff_isSymmetric).mp (realPart U).property
  have hB : B.IsSymmetric := (Matrix.isHermitian_iff_isSymmetric).mp (imaginaryPart U).property
  have hAB : Commute A B := by
    exact (normal_real_imag_commute U hU).map (Matrix.toLinAlgEquiv (PiLp.basisFun 2 ℂ ι))
  let V : ℂ × ℂ → Submodule ℂ (EuclideanSpace ℂ ι) :=
    fun i => eigenspace A i.2 ⊓ eigenspace B i.1
  let ho₀ := hA.orthogonalFamily_eigenspace_inf_eigenspace hB
  letI := ho₀.independent.fintypeNeBotOfFiniteDimensional
  let ho := ho₀.comp (Subtype.val_injective (p := fun i => V i ≠ ⊥))
  have hd : DirectSum.IsInternal (fun i : {i // V i ≠ ⊥} => V i) := by
    apply ho.isInternal_iff.mpr
    rw [Submodule.orthogonal_eq_bot_iff, iSup_ne_bot_subtype]
    change (⨆ i : ℂ × ℂ, eigenspace A i.2 ⊓ eigenspace B i.1) = ⊤
    rw [iSup_prod, iSup_comm]
    exact hA.iSup_iSup_eigenspace_inf_eigenspace_eq_top_of_commute hB hAB
  let b := hd.subordinateOrthonormalBasis finrank_euclideanSpace ho
  let idx := fun i => hd.subordinateOrthonormalBasisIndex finrank_euclideanSpace i ho
  refine ⟨b.toBasis, fun i => (idx i).val.2 + Complex.I * (idx i).val.1, ?_⟩
  intro i
  have hi := hd.subordinateOrthonormalBasis_subordinate finrank_euclideanSpace i ho
  have hiA : A (b i) = (idx i).val.2 • b i := mem_eigenspace_iff.mp hi.1
  have hiB : B (b i) = (idx i).val.1 • b i := mem_eigenspace_iff.mp hi.2
  have hdecomp : Matrix.toEuclideanLin U = A + Complex.I • B := by
    dsimp only [A, B]
    rw [← map_smul, ← map_add, realPart_add_I_smul_imaginaryPart]
  rw [hdecomp, LinearMap.add_apply, LinearMap.smul_apply]
  change A (b i) + Complex.I • B (b i) = _
  rw [hiA, hiB, smul_smul, add_smul]
  rfl

theorem normal_matrix_trace_power_roots (U : Matrix ι ι ℂ)
    (hU : Commute U (star U)) (k : ℕ) :
    (U ^ k).trace = (U.charpoly.roots.map (fun z => z ^ k)).sum := by
  classical
  obtain ⟨b, d, hb⟩ := normal_matrix_eigenbasis U hU
  simp only [Matrix.toEuclideanLin_eq_toLin] at hb
  let b₀ := PiLp.basisFun 2 ℂ ι
  let f := Matrix.toLinAlgEquiv b₀ U
  have hdiag : LinearMap.toMatrix b b f = Matrix.diagonal d := by
    ext i j
    rw [LinearMap.toMatrix_apply]
    change b.repr ((Matrix.toLin b₀ b₀ U) (b j)) i = _
    rw [hb j, map_smul, Finsupp.smul_apply, b.repr_self]
    simp only [Matrix.diagonal_apply, Finsupp.single_apply, smul_eq_mul, mul_ite, mul_one, mul_zero]
    by_cases h : i = j
    · subst j; simp only [↓reduceIte]
    · simp only [h, Ne.symm h, ↓reduceIte]
  have hstd : LinearMap.toMatrix b₀ b₀ f = U := LinearMap.toMatrix_toLin b₀ b₀ U
  have hchar : U.charpoly = (Matrix.diagonal d).charpoly := by
    rw [← hstd, LinearMap.charpoly_toMatrix, ← hdiag, LinearMap.charpoly_toMatrix]
  have htrace : (U ^ k).trace = ∑ i, (d i) ^ k := by
    rw [← hstd, LinearMap.toMatrix_pow, ← LinearMap.trace_eq_matrix_trace ℂ b₀,
      LinearMap.trace_eq_matrix_trace ℂ b, ← LinearMap.toMatrix_pow, hdiag,
      Matrix.diagonal_pow, Matrix.trace_diagonal]
    rfl
  rw [htrace, hchar, Matrix.charpoly_of_upperTriangular _ (Matrix.blockTriangular_diagonal _)]
  simp only [Matrix.diagonal_apply_eq]
  rw [Polynomial.roots_prod]
  · simp [List.sum_ofFn]
  · exact Finset.prod_ne_zero_iff.mpr (fun _ _ => Polynomial.X_sub_C_ne_zero _)

end NormalMatrices
end UAMO.CMV

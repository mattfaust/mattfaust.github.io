import UAMO.CMVEmpiricalDOSMoments
import Mathlib.Topology.Instances.Matrix

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory

theorem continuous_finiteOdd (n : ℕ) (r ω : ℝ) :
    Continuous (fun x : ℝ => finiteOdd n r ω x) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  change Continuous (fun x : ℝ =>
    Matrix.blockDiagonal (fun l : ZMod (n+1) =>
      thetaBlock (oddAlpha r (x+l.val*ω)) (star (physicalHopping r (x+l.val*ω))))
        ((oddPairEquiv n).symm i) ((oddPairEquiv n).symm j))
  simp only [Matrix.blockDiagonal_apply]
  split_ifs
  · generalize ((oddPairEquiv n).symm i).1 = s
    generalize ((oddPairEquiv n).symm j).1 = t
    fin_cases s <;> fin_cases t <;>
      simp only [Fin.zero_eta, Fin.mk_one, thetaBlock, Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
        Matrix.cons_val_fin_one, oddAlpha, physicalHopping, star_star] <;> fun_prop
  · exact continuous_const

theorem continuous_finiteCMV (n : ℕ) (a r ω : ℝ) :
    Continuous (fun x : ℝ => finiteCMV n a r ω x) :=
  continuous_const.mul (continuous_finiteOdd n r ω)

theorem continuous_finiteSpectralMeasure_moment (n : ℕ) (a r ω : ℝ) (k : ℕ) :
    Continuous (fun x : ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r ω x) := by
  simp only [finiteSpectralMeasure_moment, Matrix.trace, Matrix.diag]
  apply Continuous.div_const
  apply continuous_finset_sum
  intro i _
  exact (continuous_apply i).comp ((continuous_apply i).comp ((continuous_finiteCMV n a r ω).pow k))

end UAMO.CMV

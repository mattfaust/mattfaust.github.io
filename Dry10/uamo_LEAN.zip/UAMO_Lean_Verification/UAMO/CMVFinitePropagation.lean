import UAMO.CMVFiniteTransfer
import UAMO.PhysicalCMVConjugacy

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalCMV PhysicalRealPart PhysicalRepresentation

theorem finiteCMV_step_interior (n : ℕ) (a r Φ θ : ℝ)
    (u : FiniteSite n → ℂ) (ψ : SpinHilbert) (j : ℕ)
    (hj0 : 0 < j) (hj1 : j + 1 < n + 1)
    (hu : ∀ (s : Fin 2) (l : ℕ), j - 1 ≤ l → l ≤ j + 1 →
      u (s, (l : ZMod (n+1))) = ψ s (l : ℤ)) (s : Fin 2) :
    (finiteCMV n a r (2 * Real.pi * Φ) (2 * Real.pi * θ) *ᵥ u)
      (s, (j : ZMod (n+1))) =
      spinAction (infiniteCMV a r Φ θ) ψ s (j : ℤ) := by
  have hcast : ((j - 1 : ℕ) : ZMod (n+1)) + 1 = (j : ZMod (n+1)) := by
    simpa only [Nat.cast_add, Nat.cast_one] using
      congrArg (fun l : ℕ => (l : ZMod (n+1))) (Nat.sub_add_cancel (show 1 ≤ j by omega))
  have hint : ((j - 1 : ℕ) : ℤ) + 1 = (j : ℤ) := by
    exact_mod_cast (Nat.sub_add_cancel (show 1 ≤ j by omega))
  have hphase (l : ℕ) : 2 * Real.pi * θ + (l : ℝ) * (2 * Real.pi * Φ) =
      phaseAngle Φ θ (l : ℤ) := by simp only [phaseAngle, Int.cast_natCast]; ring
  have hodd₀ : (finiteOdd n r (2 * Real.pi * Φ) (2 * Real.pi * θ) *ᵥ u)
      (0, (j : ZMod (n+1))) = spinAction (infiniteOdd r Φ θ) ψ 0 (j : ℤ) := by
    rw [← hcast, finiteOdd_mulVec_zero_next, ZMod.val_natCast_of_lt (by omega : j-1 < n+1),
      hphase, ← hint, infiniteOdd_zero_next]
    rw [hcast, hint, hu 1 (j-1) (by omega) (by omega), hu 0 j (by omega) (by omega)]
  have hodd₁ : (finiteOdd n r (2 * Real.pi * Φ) (2 * Real.pi * θ) *ᵥ u)
      (1, (j : ZMod (n+1))) = spinAction (infiniteOdd r Φ θ) ψ 1 (j : ℤ) := by
    rw [finiteOdd_mulVec_one, ZMod.val_natCast_of_lt (by omega : j < n+1),
      hphase, infiniteOdd_one]
    rw [hu 1 j (by omega) (by omega), ← Nat.cast_add_one,
      hu 0 (j+1) (by omega) (by omega)]
    simp only [Nat.cast_add, Nat.cast_one]
  rw [finiteCMV, ← Matrix.mulVec_mulVec, infiniteCMV, spinAction_mul]
  fin_cases s <;> simp only [Fin.zero_eta, Fin.mk_one]
  · rw [finiteEven_mulVec_zero, infiniteEven_zero, hodd₀, hodd₁]
  · rw [finiteEven_mulVec_one, infiniteEven_one, hodd₀, hodd₁]

theorem finiteCMV_power_interior (n : ℕ) (a r Φ θ : ℝ)
    (u : FiniteSite n → ℂ) (ψ : SpinHilbert)
    (hu : ∀ (s : Fin 2) (j : ℕ), j < n+1 →
      u (s, (j : ZMod (n+1))) = ψ s (j : ℤ))
    (k j : ℕ) (hj0 : k ≤ j) (hj1 : j + k < n+1) (s : Fin 2) :
    (finiteCMV n a r (2 * Real.pi * Φ) (2 * Real.pi * θ) ^ k *ᵥ u)
      (s, (j : ZMod (n+1))) =
      spinAction (infiniteCMV a r Φ θ ^ k) ψ s (j : ℤ) := by
  induction k generalizing j s with
  | zero => simpa only [pow_zero, Matrix.one_mulVec, spinAction_one] using hu s j hj1
  | succ k ih =>
    rw [pow_succ', ← Matrix.mulVec_mulVec, pow_succ', spinAction_mul]
    apply finiteCMV_step_interior n a r Φ θ _ _ j (by omega) (by omega)
    intro t l hl₀ hl₁
    exact ih l (by omega) (by omega) t

def spinCoordinateVector (s : Fin 2) (j : ℤ) : SpinHilbert :=
  (WithLp.equiv 2 (Fin 2 → Hilbert)).symm (Pi.single s (delta j))

@[simp] theorem spinCoordinateVector_norm (s : Fin 2) (j : ℤ) :
    ‖spinCoordinateVector s j‖ = 1 := by
  simp [spinCoordinateVector, delta, lp.norm_single]

theorem spinCoordinateVector_action (M : PhysicalWalk.TwoByTwo Operator)
    (s : Fin 2) (j : ℤ) :
    spinAction M (spinCoordinateVector s j) s = M s s (delta j) := by
  fin_cases s <;>
    simp [spinAction, spinCoordinateVector, Pi.single_apply, Fin.zero_eta, Fin.mk_one]

theorem spin_coordinate_entry_norm_le_one (M : PhysicalWalk.TwoByTwo Operator)
    (hM : M ∈ unitary (PhysicalWalk.TwoByTwo Operator)) (s : Fin 2) (j : ℤ) :
    ‖(M s s (delta j)) j‖ ≤ 1 := by
  rw [← spinCoordinateVector_action M s j]
  calc
    _ ≤ ‖spinAction M (spinCoordinateVector s j) s‖ := lp.norm_apply_le_norm (by norm_num) _ _
    _ ≤ ‖spinAction M (spinCoordinateVector s j)‖ := PiLp.norm_apply_le _ _
    _ = 1 := by rw [spinAction_norm M hM, spinCoordinateVector_norm]

theorem finiteCMV_power_diagonal_interior (n : ℕ) (a r Φ θ : ℝ)
    (k j : ℕ) (hj0 : k ≤ j) (hj1 : j + k < n+1) (s : Fin 2) :
    (finiteCMV n a r (2 * Real.pi * Φ) (2 * Real.pi * θ) ^ k)
      (s, (j : ZMod (n+1))) (s, (j : ZMod (n+1))) =
      ((infiniteCMV a r Φ θ ^ k) s s (delta (j : ℤ))) (j : ℤ) := by
  have hj : j < n+1 := by omega
  have hv : ∀ (t : Fin 2) (l : ℕ), l < n+1 →
      (Pi.single (s, (j : ZMod (n+1))) (1 : ℂ) : FiniteSite n → ℂ) (t, (l : ZMod (n+1))) =
        spinCoordinateVector s (j : ℤ) t (l : ℤ) := by
    intro t l hl
    have hc : (l : ZMod (n+1)) = (j : ZMod (n+1)) ↔ l = j := by
      constructor
      · intro h
        have hh := congrArg ZMod.val h
        simpa only [ZMod.val_natCast_of_lt hl, ZMod.val_natCast_of_lt hj] using hh
      · exact fun h => congrArg (fun z : ℕ => (z : ZMod (n+1))) h
    have hc' : (j : ZMod (n+1)) = (l : ZMod (n+1)) ↔ j = l := by
      simpa only [eq_comm] using hc
    by_cases hst : s = t <;>
      simp [spinCoordinateVector, delta, lp.coeFn_single, Pi.single_apply, Prod.mk.injEq,
        hc, hc', hst, and_comm]
  have h := finiteCMV_power_interior n a r Φ θ _ _ hv k j hj0 hj1 s
  simpa only [Matrix.mulVec_single_one, Matrix.transpose_apply, spinCoordinateVector_action] using h

end UAMO.CMV

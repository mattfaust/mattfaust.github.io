import UAMO.CMVFrequencyContinuity
import UAMO.BJRotationRecords
import Mathlib.Topology.Instances.Irrational

noncomputable section
namespace UAMO.CMV
open Filter Set BourgainJitomirskaya
open scoped Topology Matrix.L2OpNorm

theorem le_of_upperSemicontinuous_on_dense_open
    {X : Type*} [TopologicalSpace X] {f : X→ℝ} {D U : Set X} {c : ℝ}
    (hf : UpperSemicontinuous f) (hD : Dense D) (hU : IsOpen U)
    (h : ∀x∈U∩D,c≤f x) : ∀x∈U,c≤f x := by
  intro x hx
  by_contra hxc
  have hxc' : f x<c := lt_of_not_ge hxc
  obtain ⟨y,hyD,hyU,hyc⟩ := hD.exists_mem_open
    (hU.inter (hf.isOpen_preimage c)) ⟨x,hx,hxc'⟩
  exact (not_lt_of_ge (h y ⟨hyU,hyD⟩)) hyc

variable {P : Type*} [TopologicalSpace P] [LocallyCompactSpace P] [FirstCountableTopology P]

theorem exists_parametric_finite_record_seed
    (A : P→ℝ→TransferMatrix) (α : P→ℝ)
    (hA : Continuous (fun p:P×ℝ => A p.1 p.2)) (hα : Continuous α)
    (hdet : ∀p x,‖(A p x).det‖=1)
    (hperiod : ∀p,Function.Periodic (A p) (2*Real.pi))
    {p₀ : P} (hirr : Irrational (α p₀)) {κ ε : ℝ} (hκ : 0<κ) (hε : 0<ε)
    (hL : 16000*κ<lyapunov (A p₀) (2*Real.pi*α p₀)) (Q : ℕ) :
    ∃q₀:ℕ,max Q 8≤q₀ ∧ ∃U:Set P,IsOpen U ∧ p₀∈U ∧ ∀p∈U,
      rotationRecord (α p) q₀ ∧
      8000*κ<finiteLyapunov (A p) (2*Real.pi*α p) (q₀^4) ∧
      finiteLyapunov (A p) (2*Real.pi*α p) (q₀^4)-
        finiteLyapunov (A p) (2*Real.pi*α p) (2*q₀^4)<κ/100 ∧
      lyapunov (A p₀) (2*Real.pi*α p₀)-ε<finiteLyapunov (A p) (2*Real.pi*α p) (q₀^4) := by
  let F : P→ℕ→ℝ := fun p => finiteLyapunov (A p) (2*Real.pi*α p)
  let L : ℝ := lyapunov (A p₀) (2*Real.pi*α p₀)
  have hc (n:ℕ) : Continuous (fun p => F p n) :=
    continuous_parametric_finiteLyapunov A (fun p=>2*Real.pi*α p) hA
      (continuous_const.mul hα) hdet n
  have hAp : Continuous (A p₀) := hA.comp (continuous_const.prodMk continuous_id)
  have ht : Tendsto (F p₀) atTop (𝓝 L) :=
    tendsto_finiteLyapunov (A p₀) hAp (hperiod p₀) (hdet p₀) (2*Real.pi*α p₀)
  have hupper : ∀ᶠn:ℕ in atTop,F p₀ n<L+κ/200 :=
    ht.eventually (gt_mem_nhds (show L<L+κ/200 by linarith))
  obtain ⟨N,hN⟩ := eventually_atTop.mp hupper
  obtain ⟨q₀,hq₀,hrecord⟩ := exists_rotationRecord_gt hirr (max (max Q 8) N)
  have hqQ : max Q 8≤q₀ := (le_max_left _ _).trans (Nat.le_of_lt hq₀)
  have hqN : N≤q₀ := (le_max_right _ _).trans (Nat.le_of_lt hq₀)
  have hqpow : q₀≤q₀^4 := Nat.le_self_pow (by decide) q₀
  have hpow : 1≤q₀^4 := (Nat.succ_le_iff.mpr hrecord.1).trans hqpow
  have hbase : L≤F p₀ (q₀^4) := lyapunov_le_finite _ (hdet p₀) _ hpow
  have hfinite : 8000*κ<F p₀ (q₀^4) := by
    change 16000*κ<L at hL
    linarith
  have hdiff : F p₀ (q₀^4)-F p₀ (2*q₀^4)<κ/100 := by
    have hu := hN (q₀^4) (hqN.trans hqpow)
    have hl : L≤F p₀ (2*q₀^4) :=
      lyapunov_le_finite _ (hdet p₀) _ (by omega)
    linarith
  let U : Set P := {p | rotationRecord (α p) q₀ ∧
    8000*κ<F p (q₀^4) ∧ F p (q₀^4)-F p (2*q₀^4)<κ/100 ∧ L-ε<F p (q₀^4)}
  have hU : IsOpen U :=
    ((isOpen_rotationRecord q₀).preimage hα).inter
      ((isOpen_lt continuous_const (hc (q₀^4))).inter
        ((isOpen_lt ((hc (q₀^4)).sub (hc (2*q₀^4))) continuous_const).inter
          (isOpen_lt continuous_const (hc (q₀^4)))))
  exact ⟨q₀,hqQ,U,hU,⟨hrecord,hfinite,hdiff,by linarith⟩,fun _ hp => hp⟩

end UAMO.CMV

import UAMO.CMVFiniteVolume
import Mathlib.LinearAlgebra.Matrix.Charpoly.Eigs
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial MeasureTheory
open scoped ENNReal

def finiteEigenvalueList (n : ℕ) (a r ω x : ℝ) : List ℂ :=
  (finiteCMV n a r ω x).charpoly.roots.toList

theorem finiteEigenvalueList_length (n : ℕ) (a r ω x : ℝ) :
    (finiteEigenvalueList n a r ω x).length = 2 * (n + 1) := by
  rw [finiteEigenvalueList, Multiset.length_toList]
  have h := Polynomial.natDegree_eq_card_roots (IsAlgClosed.splits (finiteCMV n a r ω x).charpoly)
  rw [Polynomial.map_id, Matrix.charpoly_natDegree_eq_dim] at h
  rw [← h]
  simp only [FiniteSite, Fintype.card_prod, Fintype.card_fin, ZMod.card]

theorem finiteCharpoly_eval {ι : Type*} [Fintype ι] [DecidableEq ι]
    (M : Matrix ι ι ℂ) (z : ℂ) :
    M.charpoly.eval z = (z • (1 : Matrix ι ι ℂ) - M).det := by
  rw [Matrix.charpoly, Matrix.eval_det, Matrix.matPolyEquiv_charmatrix]
  simp [Matrix.smul_one_eq_diagonal]

theorem finiteEigenvalueList_mem_root (n : ℕ) (a r ω x : ℝ)
    (i : Fin (finiteEigenvalueList n a r ω x).length) :
    (finiteCMV n a r ω x).charpoly.IsRoot ((finiteEigenvalueList n a r ω x).get i) := by
  apply (Polynomial.mem_roots (finiteCMV n a r ω x).charpoly_monic.ne_zero).mp
  have h := List.get_mem (finiteEigenvalueList n a r ω x) i
  have hc : (↑(finiteEigenvalueList n a r ω x) : Multiset ℂ) =
      (finiteCMV n a r ω x).charpoly.roots := Multiset.coe_toList _
  rw [← hc]
  exact h

theorem finiteEigenvalueList_norm (n : ℕ) (a r ω x : ℝ)
    (i : Fin (finiteEigenvalueList n a r ω x).length) :
    ‖(finiteEigenvalueList n a r ω x).get i‖ = 1 := by
  by_contra h
  have hz := finiteEigenvalueList_mem_root n a r ω x i
  rw [Polynomial.IsRoot, finiteCharpoly_eval] at hz
  exact finiteCMV_det_ne_zero n a r ω x h hz

theorem finiteCMV_det_eq_prod_eigenvalues (n : ℕ) (a r ω x : ℝ) (z : ℂ) :
    (z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det =
      ∏ i : Fin (finiteEigenvalueList n a r ω x).length,
        (z - (finiteEigenvalueList n a r ω x).get i) := by
  rw [← finiteCharpoly_eval,
    Polynomial.eval_eq_prod_roots_sub_of_monic_of_splits_id
      (finiteCMV n a r ω x).charpoly_monic (IsAlgClosed.splits _) z]
  have hc : (↑(finiteEigenvalueList n a r ω x) : Multiset ℂ) =
      (finiteCMV n a r ω x).charpoly.roots := Multiset.coe_toList _
  rw [← hc, Multiset.map_coe, Multiset.prod_coe]
  conv_lhs => rw [← List.ofFn_get (finiteEigenvalueList n a r ω x)]
  rw [List.map_ofFn, List.prod_ofFn]
  rfl

def finiteSpectralMeasure (n : ℕ) (a r ω x : ℝ) : Measure ℂ :=
  ((2 * (n + 1) : ℕ) : ℝ≥0∞)⁻¹ •
    ∑ i : Fin (finiteEigenvalueList n a r ω x).length,
      Measure.dirac ((finiteEigenvalueList n a r ω x).get i)

instance finiteSpectralMeasure_isProbabilityMeasure (n : ℕ) (a r ω x : ℝ) :
    IsProbabilityMeasure (finiteSpectralMeasure n a r ω x) := by
  constructor
  simp only [finiteSpectralMeasure, Measure.smul_apply, Measure.finset_sum_apply,
    measure_univ, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    finiteEigenvalueList_length, nsmul_eq_mul, mul_one, smul_eq_mul]
  exact ENNReal.inv_mul_cancel (by simp : ((2 * (n + 1) : ℕ) : ℝ≥0∞) ≠ 0) (ENNReal.natCast_ne_top _)

theorem finiteSpectralMeasure_integral (n : ℕ) (a r ω x : ℝ) (f : ℂ → ℝ) :
    ∫ w, f w ∂finiteSpectralMeasure n a r ω x =
      ((2 * (n + 1) : ℕ) : ℝ)⁻¹ *
        ∑ i : Fin (finiteEigenvalueList n a r ω x).length,
          f ((finiteEigenvalueList n a r ω x).get i) := by
  rw [finiteSpectralMeasure, integral_smul_measure,
    integral_finset_sum_measure (fun _ _ => integrable_dirac)]
  simp only [integral_dirac, ENNReal.toReal_inv, ENNReal.toReal_natCast, smul_eq_mul]

theorem finiteSpectralMeasure_off_circle (n : ℕ) (a r ω x : ℝ) :
    finiteSpectralMeasure n a r ω x {w : ℂ | ‖w‖ ≠ 1} = 0 := by
  have hm : MeasurableSet {w : ℂ | ‖w‖ ≠ 1} :=
    (isClosed_eq continuous_norm continuous_const).measurableSet.compl
  simp only [finiteSpectralMeasure, Measure.smul_apply, Measure.finset_sum_apply]
  have hd (i : Fin (finiteEigenvalueList n a r ω x).length) :
      Measure.dirac ((finiteEigenvalueList n a r ω x).get i) {w : ℂ | ‖w‖ ≠ 1} = 0 := by
    rw [Measure.dirac_apply' _ hm]
    simp only [Set.indicator_apply, Set.mem_setOf_eq, finiteEigenvalueList_norm, ne_eq,
      not_true_eq_false, ↓reduceIte]
  simp only [hd, Finset.sum_const_zero, smul_zero]

theorem finiteCMV_log_det (n : ℕ) (a r ω x : ℝ) {z : ℂ} (hz : ‖z‖ ≠ 1) :
    Real.log ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
      ∑ i : Fin (finiteEigenvalueList n a r ω x).length,
        Real.log ‖z - (finiteEigenvalueList n a r ω x).get i‖ := by
  rw [finiteCMV_det_eq_prod_eigenvalues, norm_prod, Real.log_prod]
  intro i _
  apply norm_ne_zero_iff.mpr
  intro h
  apply hz
  rw [sub_eq_zero.mp h]
  exact finiteEigenvalueList_norm n a r ω x i

theorem finiteSpectralMeasure_log_integral (n : ℕ) (a r ω x : ℝ) {z : ℂ} (hz : ‖z‖ ≠ 1) :
    ∫ w, Real.log ‖z - w‖ ∂finiteSpectralMeasure n a r ω x =
      Real.log ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ /
        ((2 * (n + 1) : ℕ) : ℝ) := by
  rw [finiteSpectralMeasure_integral, finiteCMV_log_det n a r ω x hz]
  rw [div_eq_mul_inv, mul_comm]

end UAMO.CMV

import UAMO.CMVFinitePhaseContinuity
import UAMO.CircleMomentConvergence

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory CircleDOS Filter
open scoped Topology

local instance : MeasurableSpace Circle := borel Circle
local instance : BorelSpace Circle := ⟨rfl⟩

theorem finiteSpectralMeasure_ae_circle (n : ℕ) (a r ω x : ℝ) :
    ∀ᵐ z ∂finiteSpectralMeasure n a r ω x, ‖z‖ = 1 := by
  rw [ae_iff]
  exact finiteSpectralMeasure_off_circle n a r ω x

local instance (n : ℕ) (a r ω x : ℝ) :
    IsProbabilityMeasure (circleComap (finiteSpectralMeasure n a r ω x)) :=
  circleComap_probability _ (finiteSpectralMeasure_ae_circle n a r ω x)

def finiteCircleTest (n : ℕ) (a r ω x : ℝ) : C(Circle, ℂ) →L[ℂ] ℂ :=
  circleIntegralCLM (circleComap (finiteSpectralMeasure n a r ω x))

theorem finiteCircleTest_bound (n : ℕ) (a r ω x : ℝ) (f : C(Circle, ℂ)) :
    ‖finiteCircleTest n a r ω x f‖ ≤ ‖f‖ := circleIntegralCLM_bound _ f

theorem finiteCircleTest_star (n : ℕ) (a r ω x : ℝ) (f : C(Circle, ℂ)) :
    finiteCircleTest n a r ω x (star f) = star (finiteCircleTest n a r ω x f) := by
  change (∫ z : Circle, star (f z) ∂circleComap (finiteSpectralMeasure n a r ω x)) = _
  simp only [Complex.star_def, integral_conj]
  rfl

theorem finiteCircleTest_character (n : ℕ) (a r ω x : ℝ) (k : ℕ) :
    finiteCircleTest n a r ω x (circleCharacter k) =
      (finiteCMV n a r ω x ^ k).trace / ((2*(n+1) : ℕ) : ℂ) := by
  change (∫ z : Circle, (z : ℂ)^(k : ℤ) ∂circleComap (finiteSpectralMeasure n a r ω x)) = _
  simp only [zpow_natCast]
  rw [circleComap_integral _ (finiteSpectralMeasure_ae_circle n a r ω x) (fun z : ℂ => z^k),
    finiteSpectralMeasure_moment]

theorem finiteCircleTest_restrict (n : ℕ) (a r ω x : ℝ) (f : ℂ → ℂ)
    (hf : Continuous (fun z : Circle => f z)) :
    finiteCircleTest n a r ω x ⟨fun z => f z, hf⟩ =
      ∫ z : ℂ, f z ∂finiteSpectralMeasure n a r ω x :=
  circleComap_integral _ (finiteSpectralMeasure_ae_circle n a r ω x) f

theorem continuous_finiteCircleTest (n : ℕ) (a r ω : ℝ) (f : C(Circle, ℂ)) :
    Continuous (fun x => finiteCircleTest n a r ω x f) := by
  apply continuous_iff_continuousAt.mpr
  intro x
  apply circleFunctional_tendsto_of_nat_characters_filter (𝓝 x)
    (finiteCircleTest n a r ω) (finiteCircleTest n a r ω x)
    (finiteCircleTest_bound n a r ω) (finiteCircleTest_bound n a r ω x)
    (finiteCircleTest_star n a r ω) (finiteCircleTest_star n a r ω x) _ f
  intro k
  simp only [finiteCircleTest_character]
  exact (((continuous_finiteCMV n a r ω).pow k).matrix_trace.div_const _).continuousAt

def finitePhaseCircleTest (n : ℕ) (a r Φ : ℝ) : C(Circle, ℂ) →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun f => ∫ θ in (0 : ℝ)..1,
        finiteCircleTest n a r (2*Real.pi*Φ) (2*Real.pi*θ) f
      map_add' := by
        intro f g
        simp only [map_add]
        exact intervalIntegral.integral_add
          (((continuous_finiteCircleTest n a r (2*Real.pi*Φ) f).comp
            (continuous_const.mul continuous_id)).intervalIntegrable _ _)
          (((continuous_finiteCircleTest n a r (2*Real.pi*Φ) g).comp
            (continuous_const.mul continuous_id)).intervalIntegrable _ _)
      map_smul' := by
        intro c f
        simp only [map_smul, RingHom.id_apply]
        exact intervalIntegral.integral_smul c _ }
    1 (fun f => by
      have h := intervalIntegral.norm_integral_le_of_norm_le_const
        (a := (0 : ℝ)) (b := 1) (fun θ _ =>
          finiteCircleTest_bound n a r (2*Real.pi*Φ) (2*Real.pi*θ) f)
      simpa only [sub_zero, abs_one, mul_one, one_mul] using h)

theorem finitePhaseCircleTest_apply (n : ℕ) (a r Φ : ℝ) (f : C(Circle, ℂ)) :
    finitePhaseCircleTest n a r Φ f = ∫ θ in (0 : ℝ)..1,
      finiteCircleTest n a r (2*Real.pi*Φ) (2*Real.pi*θ) f := rfl

theorem finitePhaseCircleTest_bound (n : ℕ) (a r Φ : ℝ) (f : C(Circle, ℂ)) :
    ‖finitePhaseCircleTest n a r Φ f‖ ≤ ‖f‖ := by
  have h := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0 : ℝ)) (b := 1) (fun θ _ =>
      finiteCircleTest_bound n a r (2*Real.pi*Φ) (2*Real.pi*θ) f)
  simpa only [finitePhaseCircleTest_apply, sub_zero, abs_one, mul_one] using h

theorem finitePhaseCircleTest_star (n : ℕ) (a r Φ : ℝ) (f : C(Circle, ℂ)) :
    finitePhaseCircleTest n a r Φ (star f) = star (finitePhaseCircleTest n a r Φ f) := by
  simp only [finitePhaseCircleTest_apply, finiteCircleTest_star, Complex.star_def]
  simp only [intervalIntegral, integral_conj, map_sub]

theorem finitePhaseCircleTest_character (n : ℕ) (a r Φ : ℝ) (k : ℕ) :
    finitePhaseCircleTest n a r Φ (circleCharacter k) =
      ∫ θ in (0 : ℝ)..1,
        (finiteCMV n a r (2*Real.pi*Φ) (2*Real.pi*θ) ^ k).trace /
          ((2*(n+1) : ℕ) : ℂ) := by
  simp only [finitePhaseCircleTest_apply, finiteCircleTest_character]

theorem finitePhaseCircleTest_restrict (n : ℕ) (a r Φ : ℝ) (f : ℂ → ℂ)
    (hf : Continuous (fun z : Circle => f z)) :
    finitePhaseCircleTest n a r Φ ⟨fun z => f z, hf⟩ =
      ∫ θ in (0 : ℝ)..1, ∫ z : ℂ, f z
        ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ) := by
  simp only [finitePhaseCircleTest_apply, finiteCircleTest_restrict]

end UAMO.CMV

namespace UAMO.CircleDOS

def circleLogTest (z : ℂ) (hz : ‖z‖ ≠ 1) : C(Circle, ℂ) :=
  ⟨fun w => (Real.log ‖z-(w : ℂ)‖ : ℂ), by
    apply Complex.continuous_ofReal.comp
    apply Continuous.log ((continuous_const.sub continuous_subtype_val).norm)
    intro w h
    have heq := sub_eq_zero.mp (norm_eq_zero.mp h)
    exact hz (heq ▸ Circle.norm_coe w)⟩

end UAMO.CircleDOS

namespace UAMO.CMV
open CircleDOS MeasureTheory

end UAMO.CMV

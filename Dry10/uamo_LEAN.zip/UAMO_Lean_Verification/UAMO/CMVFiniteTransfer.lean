import UAMO.CMVFiniteVolume
import UAMO.CMVLyapunov

noncomputable section
namespace UAMO.CMV
open Matrix

def gzEven (lam t : ℝ) (z : ℂ) : TransferMatrix :=
  (lam : ℂ)⁻¹ • !![-(t : ℂ), z⁻¹; z, -(t : ℂ)]

def gzOdd (b : ℝ) (ρ : ℂ) : TransferMatrix := ρ⁻¹ • !![-(b : ℂ), 1; 1, -(b : ℂ)]

def gzCell (lam t b : ℝ) (ρ z : ℂ) : TransferMatrix := gzOdd b ρ * gzEven lam t z

theorem gzCell_eq_szego (lam t b : ℝ) (ρ : ℂ) {z : ℂ} (hz : z ≠ 0) :
    gzCell lam t b ρ z = z⁻¹ • (szegoStep (b : ℂ) ρ z * szegoStep (t : ℂ) (lam : ℂ) z) := by
  have hz' := inv_mul_cancel₀ hz
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [gzCell, gzOdd, gzEven, szegoStep, szegoNumerator, Matrix.mul_apply, Fin.sum_univ_two]
  · linear_combination -((lam : ℂ)⁻¹ * ρ⁻¹ * (z + (b : ℂ) * (t : ℂ))) * hz'
  · linear_combination ((lam : ℂ)⁻¹ * ρ⁻¹ * (t : ℂ)) * hz'
  · linear_combination ((lam : ℂ)⁻¹ * ρ⁻¹ * ((b : ℂ) * z + (t : ℂ))) * hz'
  · linear_combination -((lam : ℂ)⁻¹ * ρ⁻¹ * (b : ℂ) * (t : ℂ)) * hz'

theorem blockDiagonal_mulVec_apply {ι : Type*} [Fintype ι] [DecidableEq ι]
    (B : ι → TransferMatrix) (v : Fin 2 × ι → ℂ) (s : Fin 2) (j : ι) :
    (Matrix.blockDiagonal B *ᵥ v) (s, j) =
      B j s 0 * v (0, j) + B j s 1 * v (1, j) := by
  simp [Matrix.mulVec, dotProduct, Matrix.blockDiagonal_apply, Fintype.sum_prod_type,
    Fin.sum_univ_two]

theorem finiteEven_mulVec_zero (n : ℕ) (a : ℝ) (v : FiniteSite n → ℂ) (j : ZMod (n + 1)) :
    (finiteEven n a *ᵥ v) (0, j) =
      (complementaryCoupling a : ℂ) * v (0, j) + (coupling a : ℂ) * v (1, j) := by
  rw [finiteEven, blockDiagonal_mulVec_apply]
  rfl

theorem finiteEven_mulVec_one (n : ℕ) (a : ℝ) (v : FiniteSite n → ℂ) (j : ZMod (n + 1)) :
    (finiteEven n a *ᵥ v) (1, j) =
      (coupling a : ℂ) * v (0, j) - (complementaryCoupling a : ℂ) * v (1, j) := by
  rw [finiteEven, blockDiagonal_mulVec_apply]
  simp [thetaBlock, sub_eq_add_neg]

theorem finiteOdd_mulVec_one (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n + 1)) :
    (finiteOdd n r ω x *ᵥ u) (1, j) =
      (oddAlpha r (x + j.val * ω) : ℂ) * u (1, j) +
        star (physicalHopping r (x + j.val * ω)) * u (0, j + 1) := by
  change ((Matrix.blockDiagonal _).submatrix (oddPairEquiv n).symm (oddPairEquiv n).symm *ᵥ u)
    (1, j) = _
  rw [Matrix.submatrix_mulVec_equiv]
  change (Matrix.blockDiagonal _ *ᵥ (u ∘ oddPairEquiv n)) ((oddPairEquiv n).symm (1, j)) = _
  simp only [oddPairEquiv, Equiv.coe_fn_mk, Equiv.coe_fn_symm_mk, show (1 : Fin 2) ≠ 0 by decide, ↓reduceIte]
  rw [blockDiagonal_mulVec_apply]
  simp [thetaBlock, Function.comp_def, oddPairEquiv]

theorem finiteOdd_mulVec_zero_next (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n + 1)) :
    (finiteOdd n r ω x *ᵥ u) (0, j + 1) =
      physicalHopping r (x + j.val * ω) * u (1, j) -
        (oddAlpha r (x + j.val * ω) : ℂ) * u (0, j + 1) := by
  change ((Matrix.blockDiagonal _).submatrix (oddPairEquiv n).symm (oddPairEquiv n).symm *ᵥ u)
    (0, j + 1) = _
  rw [Matrix.submatrix_mulVec_equiv]
  change (Matrix.blockDiagonal _ *ᵥ (u ∘ oddPairEquiv n)) ((oddPairEquiv n).symm (0, j + 1)) = _
  simp only [oddPairEquiv, Equiv.coe_fn_mk, Equiv.coe_fn_symm_mk, ↓reduceIte, add_sub_cancel_right]
  rw [blockDiagonal_mulVec_apply]
  simp [thetaBlock, Function.comp_def, oddPairEquiv, sub_eq_add_neg]

theorem even_block_transfer (lam t : ℝ) (hlam : lam ≠ 0)
    (hlt : lam^2 + t^2 = 1) {z : ℂ} (hz : z ≠ 0) (u₀ v₀ u₁ v₁ : ℂ)
    (h₀ : (t : ℂ) * v₀ + (lam : ℂ) * v₁ = z * u₀)
    (h₁ : (lam : ℂ) * v₀ - (t : ℂ) * v₁ = z * u₁) :
    gzEven lam t z *ᵥ ![u₀, v₀] = ![u₁, v₁] := by
  have hlc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hltc : (lam : ℂ)^2 + (t : ℂ)^2 = 1 := by exact_mod_cast hlt
  have hl' := inv_mul_cancel₀ hlc
  have hz' := inv_mul_cancel₀ hz
  ext i
  fin_cases i <;> simp [gzEven, Matrix.mulVec, dotProduct, Fin.sum_univ_two]
  · linear_combination
      ((lam : ℂ)⁻¹ * z⁻¹ * (t : ℂ)) * h₀ +
      ((lam : ℂ)⁻¹ * z⁻¹ * (lam : ℂ)) * h₁ -
      ((lam : ℂ)⁻¹ * z⁻¹ * v₀) * hltc -
      -u₁ * hl' +
      ((lam : ℂ)⁻¹ * ((lam : ℂ) * u₁ + (t : ℂ) * u₀)) * hz'
  · linear_combination -((lam : ℂ)⁻¹) * h₀ + v₁ * hl'

theorem odd_block_transfer (b : ℝ) (ρ : ℂ) (hρ : ρ ≠ 0)
    (hb : (b : ℂ)^2 + ρ * star ρ = 1) (u₀ v₀ u₁ v₁ : ℂ)
    (h₀ : (b : ℂ) * u₀ + ρ * u₁ = v₀)
    (h₁ : star ρ * u₀ - (b : ℂ) * u₁ = v₁) :
    gzOdd b ρ *ᵥ ![u₀, v₀] = ![u₁, v₁] := by
  have hρ' := inv_mul_cancel₀ hρ
  ext i
  fin_cases i <;> simp [gzOdd, Matrix.mulVec, dotProduct, Fin.sum_univ_two]
  · linear_combination -ρ⁻¹ * h₀ + u₁ * hρ'
  · linear_combination ρ⁻¹ * (b : ℂ) * h₀ + h₁ -
      ρ⁻¹ * u₀ * hb + (star ρ * u₀ - (b : ℂ) * u₁) * hρ'

theorem even_block_of_transfer (lam t : ℝ) (hlam : lam ≠ 0)
    (hlt : lam^2 + t^2 = 1) {z : ℂ} (hz : z ≠ 0) (u₀ v₀ u₁ v₁ : ℂ)
    (h : gzEven lam t z *ᵥ ![u₀, v₀] = ![u₁, v₁]) :
    (t : ℂ) * v₀ + (lam : ℂ) * v₁ = z * u₀ ∧
      (lam : ℂ) * v₀ - (t : ℂ) * v₁ = z * u₁ := by
  have hl' := inv_mul_cancel₀ (Complex.ofReal_ne_zero.mpr hlam)
  have hz' := inv_mul_cancel₀ hz
  have hltc : (lam : ℂ)^2 + (t : ℂ)^2 = 1 := by exact_mod_cast hlt
  have h₀ := congrFun h 0
  have h₁ := congrFun h 1
  simp [gzEven, Matrix.mulVec, dotProduct, Fin.sum_univ_two] at h₀ h₁
  constructor
  · linear_combination -(lam : ℂ) * h₁ + (z * u₀ - (t : ℂ) * v₀) * hl'
  · linear_combination z * h₀ + (t : ℂ) * h₁ +
      (lam : ℂ)⁻¹ * v₀ * hltc - (lam : ℂ) * v₀ * hl' -
      (lam : ℂ)⁻¹ * v₀ * hz'

theorem odd_block_of_transfer (b : ℝ) (ρ : ℂ) (hρ : ρ ≠ 0)
    (hb : (b : ℂ)^2 + ρ * star ρ = 1) (u₀ v₀ u₁ v₁ : ℂ)
    (h : gzOdd b ρ *ᵥ ![u₀, v₀] = ![u₁, v₁]) :
    (b : ℂ) * u₀ + ρ * u₁ = v₀ ∧ star ρ * u₀ - (b : ℂ) * u₁ = v₁ := by
  have hρ' := inv_mul_cancel₀ hρ
  have h₀ := congrFun h 0
  have h₁ := congrFun h 1
  simp [gzOdd, Matrix.mulVec, dotProduct, Fin.sum_univ_two] at h₀ h₁
  constructor
  · linear_combination -ρ * h₀ + (v₀ - (b : ℂ) * u₀) * hρ'
  · linear_combination (b : ℂ) * h₀ + h₁ + ρ⁻¹ * u₀ * hb - star ρ * u₀ * hρ'

end UAMO.CMV

import UAMO.CMVTransfer
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Analysis.CStarAlgebra.Spectrum
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Data.ZMod.Basic

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

def thetaBlock (b : ℝ) (ρ : ℂ) : TransferMatrix := !![(b : ℂ), ρ; star ρ, -(b : ℂ)]

theorem thetaBlock_star (b : ℝ) (ρ : ℂ) : star (thetaBlock b ρ) = thetaBlock b ρ := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [thetaBlock, Matrix.star_eq_conjTranspose]

theorem thetaBlock_mul_self (b : ℝ) (ρ : ℂ)
    (h : (b : ℂ)^2 + ρ * star ρ = 1) : thetaBlock b ρ * thetaBlock b ρ = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [thetaBlock, Matrix.mul_apply, Fin.sum_univ_two]
  · simpa [pow_two, Complex.star_def] using h
  · ring
  · ring
  · simpa [pow_two, mul_comm, add_comm, Complex.star_def] using h

theorem thetaBlock_det (b : ℝ) (ρ : ℂ)
    (h : (b : ℂ)^2 + ρ * star ρ = 1) : (thetaBlock b ρ).det = -1 := by
  simp only [thetaBlock, det_fin_two_of]
  linear_combination -h

abbrev FiniteSite (n : ℕ) := Fin 2 × ZMod (n + 1)
abbrev FiniteMatrix (n : ℕ) := Matrix (FiniteSite n) (FiniteSite n) ℂ

def oddPairEquiv (n : ℕ) : FiniteSite n ≃ FiniteSite n where
  toFun p := if p.1 = 0 then (1, p.2) else (0, p.2 + 1)
  invFun p := if p.1 = 0 then (1, p.2 - 1) else (0, p.2)
  left_inv p := by
    rcases p with ⟨s, j⟩
    fin_cases s <;> simp
  right_inv p := by
    rcases p with ⟨s, j⟩
    fin_cases s <;> simp

def finiteEven (n : ℕ) (a : ℝ) : FiniteMatrix n :=
  Matrix.blockDiagonal (fun _ : ZMod (n + 1) =>
    thetaBlock (complementaryCoupling a) (coupling a : ℂ))

def finiteOdd (n : ℕ) (r ω x : ℝ) : FiniteMatrix n :=
  Matrix.reindexAlgEquiv ℂ ℂ (oddPairEquiv n)
    (Matrix.blockDiagonal (fun j : ZMod (n + 1) =>
      thetaBlock (oddAlpha r (x + j.val * ω)) (star (physicalHopping r (x + j.val * ω)))))

def finiteCMV (n : ℕ) (a r ω x : ℝ) : FiniteMatrix n :=
  finiteEven n a * finiteOdd n r ω x

private theorem blockDiagonal_star {ι : Type*} [Fintype ι] [DecidableEq ι]
    (B : ι → TransferMatrix) (hs : ∀ i, star (B i) = B i) :
    star (Matrix.blockDiagonal B) = Matrix.blockDiagonal B := by
  simp only [Matrix.star_eq_conjTranspose] at hs
  simp only [Matrix.star_eq_conjTranspose, Matrix.blockDiagonal_conjTranspose, hs]

private theorem blockDiagonal_square {ι : Type*} [Fintype ι] [DecidableEq ι]
    (B : ι → TransferMatrix) (hs : ∀ i, B i * B i = 1) :
    Matrix.blockDiagonal B * Matrix.blockDiagonal B = 1 := by
  rw [← Matrix.blockDiagonal_mul]
  simp only [hs]
  exact Matrix.blockDiagonal_one

private theorem reindex_star {ι : Type*} [Fintype ι] [DecidableEq ι]
    (e : ι ≃ ι) (B : Matrix ι ι ℂ) :
    star (Matrix.reindexAlgEquiv ℂ ℂ e B) = Matrix.reindexAlgEquiv ℂ ℂ e (star B) := by
  ext i j
  rfl

theorem finiteEven_star (n : ℕ) (a : ℝ) : star (finiteEven n a) = finiteEven n a :=
  blockDiagonal_star _ (fun _ => thetaBlock_star _ _)

theorem finiteEven_square (n : ℕ) (a : ℝ) : finiteEven n a * finiteEven n a = 1 := by
  apply blockDiagonal_square
  intro j
  apply thetaBlock_mul_self
  have h := coupling_square_identity a
  simp only [Complex.star_def, Complex.conj_ofReal]
  exact_mod_cast (show complementaryCoupling a ^ 2 + coupling a * coupling a = 1 by nlinarith)

theorem finiteOdd_star (n : ℕ) (r ω x : ℝ) : star (finiteOdd n r ω x) = finiteOdd n r ω x := by
  rw [finiteOdd, reindex_star, blockDiagonal_star _ (fun _ => thetaBlock_star _ _)]

theorem finiteOdd_square (n : ℕ) (r ω x : ℝ) :
    finiteOdd n r ω x * finiteOdd n r ω x = 1 := by
  unfold finiteOdd
  rw [← map_mul]
  have hs := blockDiagonal_square
    (fun j : ZMod (n + 1) =>
      thetaBlock (oddAlpha r (x + j.val * ω)) (star (physicalHopping r (x + j.val * ω))))
    (fun j => thetaBlock_mul_self _ _ (by
      simpa only [star_star, mul_comm (star (physicalHopping r (x + j.val * ω)))] using
        physicalHopping_normalization r (x + j.val * ω)))
  rw [hs, map_one]

theorem finiteCMV_unitary (n : ℕ) (a r ω x : ℝ) :
    finiteCMV n a r ω x ∈ unitary (FiniteMatrix n) := by
  apply unitary.mem_iff.mpr
  simp only [finiteCMV, Matrix.star_mul, finiteEven_star, finiteOdd_star]
  constructor
  · rw [mul_assoc, ← mul_assoc (finiteEven n a), finiteEven_square, one_mul, finiteOdd_square]
  · rw [mul_assoc, ← mul_assoc (finiteOdd n r ω x), finiteOdd_square, one_mul, finiteEven_square]

theorem finiteCMV_pencil_factor (n : ℕ) (a r ω x : ℝ) (z : ℂ) :
    z • (1 : FiniteMatrix n) - finiteCMV n a r ω x =
      finiteEven n a * (z • finiteEven n a - finiteOdd n r ω x) := by
  rw [mul_sub, Matrix.mul_smul, finiteEven_square, finiteCMV]

theorem finiteCMV_det_pencil (n : ℕ) (a r ω x : ℝ) (z : ℂ) :
    (z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det =
      (finiteEven n a).det * (z • finiteEven n a - finiteOdd n r ω x).det := by
  rw [finiteCMV_pencil_factor, Matrix.det_mul]

theorem finiteEven_det (n : ℕ) (a : ℝ) : (finiteEven n a).det = (-1 : ℂ) ^ (n + 1) := by
  unfold finiteEven
  rw [Matrix.det_blockDiagonal]
  have htheta : (thetaBlock (complementaryCoupling a) (coupling a : ℂ)).det = -1 := by
    apply thetaBlock_det
    have h := coupling_square_identity a
    simp only [Complex.star_def, Complex.conj_ofReal]
    exact_mod_cast (show complementaryCoupling a ^ 2 + coupling a * coupling a = 1 by nlinarith)
  simp only [htheta, Finset.prod_const, Finset.card_univ, ZMod.card]

theorem finiteCMV_spectrum_norm (n : ℕ) (a r ω x : ℝ) {z : ℂ}
    (hz : z ∈ spectrum ℂ (finiteCMV n a r ω x)) : ‖z‖ = 1 := by
  have h := spectrum.subset_circle_of_unitary (𝕜 := ℂ) (finiteCMV_unitary n a r ω x) hz
  simpa only [Metric.mem_sphere, dist_zero_right] using h

theorem finiteCMV_det_ne_zero (n : ℕ) (a r ω x : ℝ) {z : ℂ} (hz : ‖z‖ ≠ 1) :
    (z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det ≠ 0 := by
  have hs : z ∉ spectrum ℂ (finiteCMV n a r ω x) :=
    fun h => hz (finiteCMV_spectrum_norm n a r ω x h)
  have hu : IsUnit (z • (1 : FiniteMatrix n) - finiteCMV n a r ω x) := by
    simpa only [spectrum.mem_iff, not_not, Algebra.algebraMap_eq_smul_one] using hs
  exact isUnit_iff_ne_zero.mp ((Matrix.isUnit_iff_isUnit_det _).mp hu)

end UAMO.CMV

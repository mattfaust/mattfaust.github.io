import UAMO.CMVLyapunov
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Topology.Semicontinuous

noncomputable section
namespace UAMO.CMV
open Filter MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

variable {P : Type*} [TopologicalSpace P]

theorem continuous_parametric_transferProduct
    (A : P→ℝ→TransferMatrix) (ω : P→ℝ)
    (hA : Continuous (fun p:P×ℝ => A p.1 p.2)) (hω : Continuous ω) (n : ℕ) :
    Continuous (fun p:P×ℝ => transferProduct (A p.1) (ω p.1) p.2 n) := by
  induction n with
  | zero => exact continuous_const
  | succ n ih =>
    exact (hA.comp (continuous_fst.prodMk
      (continuous_snd.add (continuous_const.mul (hω.comp continuous_fst))))).mul ih

theorem continuous_parametric_transferLogNorm
    (A : P→ℝ→TransferMatrix) (ω : P→ℝ)
    (hA : Continuous (fun p:P×ℝ => A p.1 p.2)) (hω : Continuous ω)
    (hd : ∀p x,‖(A p x).det‖=1) (n : ℕ) :
    Continuous (fun p:P×ℝ => transferLogNorm (A p.1) (ω p.1) p.2 n) := by
  exact (continuous_transferNorm.comp
    (continuous_parametric_transferProduct A ω hA hω n)).log
      (fun p => (transferProduct_norm_pos (A p.1) (hd p.1) (ω p.1) p.2 n).ne')

theorem continuous_parametric_finiteLyapunov [LocallyCompactSpace P] [FirstCountableTopology P]
    (A : P→ℝ→TransferMatrix) (ω : P→ℝ)
    (hA : Continuous (fun p:P×ℝ => A p.1 p.2)) (hω : Continuous ω)
    (hd : ∀p x,‖(A p x).det‖=1) (n : ℕ) :
    Continuous (fun p => finiteLyapunov (A p) (ω p) n) := by
  have hc := continuous_parametric_integral_of_continuous (μ:=volume)
    (f:=fun p:P => fun x:ℝ => transferLogNorm (A p) (ω p) x n)
    (continuous_parametric_transferLogNorm A ω hA hω hd n)
    (isCompact_Icc (a:=(0:ℝ)) (b:=2*Real.pi))
  have heq : (fun p:P => ∫x in Icc (0:ℝ) (2*Real.pi),transferLogNorm (A p) (ω p) x n)=
      (fun p:P => ∫x in (0:ℝ)..(2*Real.pi),transferLogNorm (A p) (ω p) x n) := by
    funext p
    rw [intervalIntegral.integral_of_le (by positivity : (0:ℝ)≤2*Real.pi),
      integral_Icc_eq_integral_Ioc]
  rw [heq] at hc
  exact (hc.div_const (2*Real.pi)).div_const (n:ℝ)

theorem upperSemicontinuous_parametric_lyapunov [LocallyCompactSpace P] [FirstCountableTopology P]
    (A : P→ℝ→TransferMatrix) (ω : P→ℝ)
    (hA : Continuous (fun p:P×ℝ => A p.1 p.2)) (hω : Continuous ω)
    (hd : ∀p x,‖(A p x).det‖=1) :
    UpperSemicontinuous (fun p => lyapunov (A p) (ω p)) := by
  intro p b hb
  obtain ⟨v,⟨n,hn,rfl⟩,hnb⟩ := exists_lt_of_csInf_lt
    (show ((fun n => finiteLyapunov (A p) (ω p) n) '' Ici 1).Nonempty from
      ⟨finiteLyapunov (A p) (ω p) 1,1,by simp,rfl⟩) hb
  have hnear := (continuous_parametric_finiteLyapunov A ω hA hω hd n).continuousAt.tendsto.eventually
    (Iio_mem_nhds hnb)
  filter_upwards [hnear] with q hq
  exact (lyapunov_le_finite (A q) (hd q) (ω q) hn).trans_lt hq

end UAMO.CMV

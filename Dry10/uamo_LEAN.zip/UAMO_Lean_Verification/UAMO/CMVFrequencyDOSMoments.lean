import UAMO.CMVEmpiricalDOSLimit
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Topology.UniformSpace.UniformConvergence
import Mathlib.Topology.UniformSpace.Ascoli

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set PhysicalDOS
open scoped Topology

theorem continuous_finiteOdd_frequency_phase (n : ℕ) (r : ℝ) :
    Continuous (fun p : ℝ × ℝ => finiteOdd n r p.1 p.2) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  change Continuous (fun p : ℝ × ℝ =>
    Matrix.blockDiagonal (fun l : ZMod (n+1) =>
      thetaBlock (oddAlpha r (p.2+l.val*p.1)) (star (physicalHopping r (p.2+l.val*p.1))))
        ((oddPairEquiv n).symm i) ((oddPairEquiv n).symm j))
  simp only [Matrix.blockDiagonal_apply]
  split_ifs
  · generalize ((oddPairEquiv n).symm i).1 = s
    generalize ((oddPairEquiv n).symm j).1 = t
    fin_cases s <;> fin_cases t <;>
      simp only [Fin.zero_eta, Fin.mk_one, thetaBlock, Matrix.of_apply, Matrix.cons_val_zero,
        Matrix.cons_val_one, Matrix.cons_val_fin_one, oddAlpha, physicalHopping, star_star] <;> fun_prop
  · exact continuous_const

theorem continuous_finiteCMV_frequency_phase (n : ℕ) (a r : ℝ) :
    Continuous (fun p : ℝ × ℝ => finiteCMV n a r p.1 p.2) :=
  continuous_const.mul (continuous_finiteOdd_frequency_phase n r)

theorem continuous_finiteSpectralMeasure_moment_frequency_phase
    (n : ℕ) (a r : ℝ) (k : ℕ) :
    Continuous (fun p : ℝ × ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r p.1 p.2) := by
  simp only [finiteSpectralMeasure_moment, Matrix.trace, Matrix.diag]
  apply Continuous.div_const
  apply continuous_finset_sum
  intro i _
  exact (continuous_apply i).comp ((continuous_apply i).comp
    ((continuous_finiteCMV_frequency_phase n a r).pow k))

set_option maxHeartbeats 800000 in
theorem continuous_finiteSpectralMeasure_phase_moment_frequency
    (n : ℕ) (a r : ℝ) (k : ℕ) :
    Continuous (fun Φ : ℝ => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) := by
  have harg : Continuous (fun p : ℝ × ℝ => (2*Real.pi*p.1, 2*Real.pi*p.2)) := by
    fun_prop
  have hcomp := (continuous_finiteSpectralMeasure_moment_frequency_phase n a r k).comp harg
  have hfun : Continuous (fun p : ℝ × ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r
      (2*Real.pi*p.1) (2*Real.pi*p.2)) := hcomp
  have hc := continuous_parametric_integral_of_continuous (μ := volume)
    (f := fun Φ : ℝ => fun θ : ℝ => ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r
      (2*Real.pi*Φ) (2*Real.pi*θ))
    hfun
    (isCompact_Icc (a := (0:ℝ)) (b := 1))
  have heq : (fun Φ : ℝ => ∫ θ in Icc (0:ℝ) 1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) =
      (fun Φ : ℝ => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) := by
    funext Φ
    rw [intervalIntegral.integral_of_le (by norm_num : (0:ℝ) ≤ 1),
      integral_Icc_eq_integral_Ioc]
  rwa [heq] at hc

theorem continuous_physicalUnitaryDOS_moment_frequency (a r : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (k : ℕ) :
    Continuous (fun Φ : ℝ => ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1) := by
  have hu : TendstoUniformly
      (fun n : ℕ => fun Φ : ℝ => ∫ θ in (0:ℝ)..1,
        ∫ z : ℂ, z^k ∂finiteSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ))
      (fun Φ : ℝ => ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1) atTop := by
    apply Metric.tendstoUniformly_iff.mpr
    intro ε hε
    have hlim := (tendsto_add_atTop_iff_nat 1).2
      (tendsto_const_div_atTop_nhds_zero_nat (4*(k:ℝ)))
    filter_upwards [hlim.eventually (Iio_mem_nhds hε)] with n hn Φ
    rw [dist_eq_norm, norm_sub_rev]
    exact (finiteSpectralMeasure_phase_moment_error n a r Φ ha0 ha1 hr0 hr1 k).trans_lt hn
  exact hu.continuous (Eventually.of_forall
    (fun n => continuous_finiteSpectralMeasure_phase_moment_frequency n a r k))

theorem finiteSpectralMeasure_moving_frequency_moments_tendsto
    (a r : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (N : ℕ → ℕ) (Φ : ℕ → ℝ) {α : ℝ}
    (hN : Tendsto N atTop atTop) (hΦ : Tendsto Φ atTop (𝓝 α)) (k : ℕ) :
    Tendsto (fun j : ℕ => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, z^k ∂finiteSpectralMeasure (N j) a r (2*Real.pi*Φ j) (2*Real.pi*θ)) atTop
        (𝓝 (∫ z : ℂ, z^k ∂physicalUnitaryDOS a r α ha0 ha1 hr0 hr1)) := by
  have herr : Tendsto (fun j =>
      (∫ θ in (0:ℝ)..1, ∫ z : ℂ, z^k ∂finiteSpectralMeasure (N j) a r
        (2*Real.pi*Φ j) (2*Real.pi*θ)) -
      ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r (Φ j) ha0 ha1 hr0 hr1) atTop (𝓝 0) := by
    apply tendsto_zero_iff_norm_tendsto_zero.mpr
    apply squeeze_zero (fun _ => norm_nonneg _)
      (fun j => finiteSpectralMeasure_phase_moment_error (N j) a r (Φ j) ha0 ha1 hr0 hr1 k)
    exact ((tendsto_add_atTop_iff_nat 1).2
      (tendsto_const_div_atTop_nhds_zero_nat (4*(k:ℝ)))).comp hN
  have hmoment := (continuous_physicalUnitaryDOS_moment_frequency a r ha0 ha1 hr0 hr1 k).tendsto α
  simpa only [Function.comp_def, sub_add_cancel, zero_add] using herr.add (hmoment.comp hΦ)

end UAMO.CMV

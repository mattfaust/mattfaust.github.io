import UAMO.UAMOSpectralLyapunovPolynomial
import UAMO.CMVSingularLyapunov
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Algebra.Polynomial.BigOperators

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial

theorem reflectedPolynomial_natDegree_le (p : Polynomial ℂ) (D : ℕ)
    (hp : p.natDegree ≤ D) : (Polynomial.reflect D p).natDegree ≤ D := by
  apply Polynomial.natDegree_le_iff_coeff_eq_zero.mpr
  intro j hj
  rw [Polynomial.coeff_reflect, Polynomial.revAt_eq_self_of_lt hj]
  exact Polynomial.coeff_eq_zero_of_natDegree_lt (hp.trans_lt hj)

theorem reflectedPolynomial_eval (p : Polynomial ℂ) {D : ℕ} (hp : p.natDegree ≤ D)
    {w : ℂ} (hw : ‖w‖ = 1) :
    (Polynomial.reflect D (p.map (starRingEnd ℂ))).eval w = w ^ D * star (p.eval w) := by
  have hw0 : w ≠ 0 := by intro h; simp [h] at hw
  have hconj : star w = w⁻¹ := by
    rw [Complex.inv_def, Complex.normSq_eq_norm_sq, hw]
    simp
  have heval : (p.map (starRingEnd ℂ)).eval (w⁻¹) = star (p.eval w) := by
    rw [← hconj, Polynomial.eval_map]
    exact Polynomial.eval₂_hom (starRingEnd ℂ) w
  letI : Invertible (w⁻¹) := invertibleOfNonzero (inv_ne_zero hw0)
  have hreflect := Polynomial.eval₂_reflect_mul_pow (RingHom.id ℂ) (w⁻¹) D
    (p.map (starRingEnd ℂ)) (Polynomial.natDegree_map_le.trans hp)
  simp only [invOf_eq_inv, inv_inv] at hreflect
  change (Polynomial.reflect D (p.map (starRingEnd ℂ))).eval w * (w⁻¹) ^ D =
    (p.map (starRingEnd ℂ)).eval (w⁻¹) at hreflect
  rw [heval] at hreflect
  apply mul_right_cancel₀ (pow_ne_zero D (inv_ne_zero hw0))
  calc
    _ = star (p.eval w) := hreflect
    _ = star (p.eval w) * (w * w⁻¹) ^ D := by
      rw [mul_inv_cancel₀ hw0, one_pow, mul_one]
    _ = _ := by rw [mul_pow]; ring

def transferFrobeniusSq (M : TransferMatrix) : ℝ :=
  ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ ^ 2

theorem transferFrobeniusSq_nonneg (M : TransferMatrix) :
    0≤transferFrobeniusSq M :=
  Finset.sum_nonneg fun _ _ => Finset.sum_nonneg fun _ _ => sq_nonneg _

theorem transferFrobeniusSq_smul (c : ℂ) (M : TransferMatrix) :
    transferFrobeniusSq (c • M)=‖c‖^2*transferFrobeniusSq M := by
  simp only [transferFrobeniusSq, Matrix.smul_apply,smul_eq_mul,norm_mul,mul_pow,
    Finset.mul_sum]

def frobeniusPolynomial (P : TransferPolynomialMatrix) (D : ℕ) : Polynomial ℂ :=
  ∑ i : Fin 2, ∑ j : Fin 2,
    P i j * Polynomial.reflect D ((P i j).map (starRingEnd ℂ))

theorem frobeniusPolynomial_natDegree_le (P : TransferPolynomialMatrix) (D : ℕ)
    (hP : ∀i j,(P i j).natDegree≤D) :
    (frobeniusPolynomial P D).natDegree≤2*D := by
  unfold frobeniusPolynomial
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro i _
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro j _
  exact (Polynomial.natDegree_mul_le_of_le (hP i j)
    (reflectedPolynomial_natDegree_le _ D (Polynomial.natDegree_map_le.trans (hP i j)))).trans
    (by omega)

theorem frobeniusPolynomial_eval (P : TransferPolynomialMatrix) (D : ℕ)
    (hP : ∀i j,(P i j).natDegree≤D) {w : ℂ} (hw : ‖w‖=1) :
    (frobeniusPolynomial P D).eval w =
      w^D*(transferFrobeniusSq (P.map (Polynomial.eval w)) : ℂ) := by
  simp only [frobeniusPolynomial,Polynomial.eval_finset_sum,Polynomial.eval_mul,
    transferFrobeniusSq,Complex.ofReal_sum,Finset.mul_sum,Matrix.map_apply]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  rw [reflectedPolynomial_eval _ (hP i j) hw,mul_left_comm,Complex.star_def,
    Complex.mul_conj,Complex.normSq_eq_norm_sq]

theorem norm_frobeniusPolynomial_eval (P : TransferPolynomialMatrix) (D : ℕ)
    (hP : ∀i j,(P i j).natDegree≤D) {w : ℂ} (hw : ‖w‖=1) :
    ‖(frobeniusPolynomial P D).eval w‖ =
      transferFrobeniusSq (P.map (Polynomial.eval w)) := by
  rw [frobeniusPolynomial_eval P D hP hw,norm_mul,norm_pow,hw,one_pow,one_mul,
    Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (transferFrobeniusSq_nonneg _)]

private theorem transfer_apply_norm_sq_le (M : TransferMatrix)
    (x : EuclideanSpace ℂ (Fin 2)) :
    ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M x‖ ^ 2 ≤
      transferFrobeniusSq M * ‖x‖ ^ 2 := by
  rw [PiLp.norm_sq_eq_of_L2, PiLp.norm_sq_eq_of_L2]
  change (∑ i : Fin 2, ‖∑ j : Fin 2, M i j * x j‖ ^ 2) ≤ _
  calc
    _ ≤ ∑ i : Fin 2, (∑ j : Fin 2, ‖M i j‖ * ‖x j‖) ^ 2 := by
      apply Finset.sum_le_sum
      intro i _
      have h := norm_sum_le (Finset.univ : Finset (Fin 2)) (fun j => M i j * x j)
      simp only [norm_mul] at h
      exact pow_le_pow_left₀ (norm_nonneg _) h 2
    _ ≤ ∑ i : Fin 2, (∑ j : Fin 2, ‖M i j‖ ^ 2) * (∑ j : Fin 2, ‖x j‖ ^ 2) := by
      exact Finset.sum_le_sum fun i _ =>
        Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin 2))
          (fun j => ‖M i j‖) (fun j => ‖x j‖)
    _ = _ := by simp only [transferFrobeniusSq, Finset.sum_mul]

theorem transferNorm_sq_le_frobeniusSq (M : TransferMatrix) :
    transferNorm M ^ 2 ≤ transferFrobeniusSq M := by
  have hbound : transferNorm M ≤ Real.sqrt (transferFrobeniusSq M) := by
    unfold transferNorm
    apply ContinuousLinearMap.opNorm_le_bound _ (Real.sqrt_nonneg _)
    intro x
    apply (sq_le_sq₀ (norm_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) (norm_nonneg _))).mp
    rw [mul_pow, Real.sq_sqrt (transferFrobeniusSq_nonneg M)]
    exact transfer_apply_norm_sq_le M x
  have hsq := pow_le_pow_left₀ (norm_nonneg _) hbound 2
  rwa [Real.sq_sqrt (transferFrobeniusSq_nonneg M)] at hsq

theorem transfer_column_norm_sq_le (M : TransferMatrix) (j : Fin 2) :
    (∑ i : Fin 2, ‖M i j‖ ^ 2) ≤ transferNorm M ^ 2 := by
  let T := Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M
  let v : EuclideanSpace ℂ (Fin 2) := EuclideanSpace.single j 1
  have hentry (i : Fin 2) : (T v) i = M i j := by
    change (M *ᵥ Pi.single j 1) i = M i j
    rw [Matrix.mulVec_single_one]
    rfl
  have hnorm : ‖T v‖ ≤ transferNorm M := by
    simpa [T, v, transferNorm] using T.le_opNorm v
  have hsq := pow_le_pow_left₀ (norm_nonneg (T v)) hnorm 2
  rw [PiLp.norm_sq_eq_of_L2] at hsq
  simpa only [hentry] using hsq

theorem transferFrobeniusSq_le_two_mul_norm_sq (M : TransferMatrix) :
    transferFrobeniusSq M ≤ 2 * transferNorm M ^ 2 := by
  unfold transferFrobeniusSq
  rw [Finset.sum_comm]
  calc
    _ ≤ ∑ _j : Fin 2, transferNorm M ^ 2 :=
      Finset.sum_le_sum fun j _ => transfer_column_norm_sq_le M j
    _ = _ := by simp [Fin.sum_univ_two, two_mul]

theorem transfer_log_frobenius_gap_of_pos (M : TransferMatrix)
    (hM : 0 < transferNorm M) :
    0 ≤ Real.log (transferFrobeniusSq M) / 2 - Real.log (transferNorm M) ∧
      Real.log (transferFrobeniusSq M) / 2 - Real.log (transferNorm M) ≤
        Real.log 2 / 2 := by
  have hs : 0 < transferNorm M ^ 2 := sq_pos_of_pos hM
  have hf : 0 < transferFrobeniusSq M := hs.trans_le (transferNorm_sq_le_frobeniusSq M)
  have hlo := Real.log_le_log hs (transferNorm_sq_le_frobeniusSq M)
  have hhi := Real.log_le_log hf (transferFrobeniusSq_le_two_mul_norm_sq M)
  rw [Real.log_pow] at hlo
  rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) hs.ne', Real.log_pow] at hhi
  norm_num only [Nat.cast_ofNat] at hlo hhi
  constructor <;> linarith

end UAMO.CMV

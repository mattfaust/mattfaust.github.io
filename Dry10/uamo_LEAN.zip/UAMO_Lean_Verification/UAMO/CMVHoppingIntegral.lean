import UAMO.CMVTransfer
import UAMO.CircleLogMean

noncomputable section
namespace UAMO.CMV
open MeasureTheory CircleDOS

theorem logFourierChar_one_trig (t : ℝ) :
    logFourierChar 1 t = (Real.cos (2*Real.pi*t) : ℂ) +
      (Real.sin (2*Real.pi*t) : ℂ)*Complex.I := by
  have h : ((1 : ℤ) : ℂ) * (2*(Real.pi : ℂ)*Complex.I)*t =
      ((2*Real.pi*t : ℝ) : ℂ)*Complex.I := by push_cast; ring
  rw [logFourierChar, h, Complex.exp_mul_I]
  simp

theorem physicalHopping_factorization (r t : ℝ) :
    star (physicalHopping r (2*Real.pi*t)) =
      (-Complex.I / (1+(r : ℂ)^2)) *
        (1+(r : ℂ)*Complex.I*logFourierChar 1 t) *
        (1+(r : ℂ)*Complex.I*star (logFourierChar 1 t)) := by
  have hd : (1+r^2 : ℝ) ≠ 0 := by positivity
  have hdc : (1+(r : ℂ)^2) ≠ 0 := by exact_mod_cast hd
  rw [logFourierChar_one_trig]
  simp only [physicalHopping, coupling, complementaryCoupling, Complex.ofReal_div,
    Complex.ofReal_mul, Complex.ofReal_sub, Complex.ofReal_add, Complex.ofReal_pow,
    Complex.ofReal_one, Complex.ofReal_ofNat, star_add, star_sub, star_mul,
    star_div₀, star_pow, star_one, Complex.star_def, Complex.conj_ofReal, Complex.conj_I,
    map_ofNat]
  field_simp
  simp only [show 2*(Real.pi : ℂ)*(t : ℂ) = ((2*Real.pi*t : ℝ) : ℂ) by push_cast; rfl,
    ← Complex.ofReal_cos, ← Complex.ofReal_sin]
  have htrig : (Real.sin (2*Real.pi*t) : ℂ)^2 + (Real.cos (2*Real.pi*t) : ℂ)^2 = 1 := by
    exact_mod_cast Real.sin_sq_add_cos_sq (2*Real.pi*t)
  apply Complex.ext <;>
    simp only [Complex.mul_re, Complex.mul_im, Complex.add_re, Complex.add_im,
      Complex.sub_re, Complex.sub_im, Complex.neg_re, Complex.neg_im, Complex.ofReal_re,
      Complex.ofReal_im, Complex.I_re, Complex.I_im, Complex.one_re, Complex.one_im,
      pow_two] at * <;> norm_num at * <;>
    nlinarith [Real.sin_sq_add_cos_sq (2*Real.pi*t)]

theorem one_sub_logFourierChar_ne_zero {c : ℂ} (hc : ‖c‖ < 1) (t : ℝ) :
    1-c*logFourierChar 1 t ≠ 0 := by
  intro h
  have hn := congrArg norm (sub_eq_zero.mp h)
  simp only [norm_one, norm_mul, logFourierChar_norm, mul_one] at hn
  exact (ne_of_lt hc) hn.symm

theorem continuous_log_norm_one_sub {c : ℂ} (hc : ‖c‖ < 1) :
    Continuous (fun t => Real.log ‖1-c*logFourierChar 1 t‖) :=
  ((continuous_const.sub (continuous_const.mul (logFourierChar_continuous 1))).norm).log
    (fun t => norm_ne_zero_iff.mpr (one_sub_logFourierChar_ne_zero hc t))

theorem physicalHopping_log_norm {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r < 1) (t : ℝ) :
    Real.log ‖physicalHopping r (2*Real.pi*t)‖ =
      -Real.log (1+r^2) +
        Real.log ‖1-(-(r : ℂ)*Complex.I)*logFourierChar 1 t‖ +
        Real.log ‖1-((r : ℂ)*Complex.I)*logFourierChar 1 t‖ := by
  have hplus : ‖-(r : ℂ)*Complex.I‖ < 1 := by
    simpa only [norm_mul, norm_neg, Complex.norm_real, Real.norm_eq_abs,
      Complex.norm_I, mul_one, abs_of_nonneg hr0] using hr1
  have hminus : ‖(r : ℂ)*Complex.I‖ < 1 := by
    simpa only [norm_mul, Complex.norm_real, Real.norm_eq_abs,
      Complex.norm_I, mul_one, abs_of_nonneg hr0] using hr1
  have hp := norm_ne_zero_iff.mpr (one_sub_logFourierChar_ne_zero hplus t)
  have hm := norm_ne_zero_iff.mpr (one_sub_logFourierChar_ne_zero hminus t)
  have hconj : 1+(r : ℂ)*Complex.I*star (logFourierChar 1 t) =
      star (1-((r : ℂ)*Complex.I)*logFourierChar 1 t) := by simp
  have hn := congrArg norm (physicalHopping_factorization r t)
  rw [norm_star, norm_mul, norm_mul, hconj, norm_star] at hn
  have hd : ‖1+(r : ℂ)^2‖ = 1+r^2 := by
    rw [← Complex.ofReal_one, ← Complex.ofReal_pow, ← Complex.ofReal_add,
      Complex.norm_real, Real.norm_eq_abs, abs_of_pos (by positivity)]
  simp only [norm_div, norm_neg, Complex.norm_I, hd] at hn
  rw [show 1+(r : ℂ)*Complex.I*logFourierChar 1 t =
      1-(-(r : ℂ)*Complex.I)*logFourierChar 1 t by ring] at hn
  rw [hn, Real.log_mul (mul_ne_zero (by positivity) hp) hm,
    Real.log_mul (by positivity) hp, Real.log_div (by norm_num) (by positivity), Real.log_one]
  ring

theorem physicalHopping_log_integral {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r < 1) :
    (∫ t in (0 : ℝ)..1, Real.log ‖physicalHopping r (2*Real.pi*t)‖) =
      -Real.log (1+r^2) := by
  have hplus : ‖-(r : ℂ)*Complex.I‖ < 1 := by
    simpa only [norm_mul, norm_neg, Complex.norm_real, Real.norm_eq_abs,
      Complex.norm_I, mul_one, abs_of_nonneg hr0] using hr1
  have hminus : ‖(r : ℂ)*Complex.I‖ < 1 := by
    simpa only [norm_mul, Complex.norm_real, Real.norm_eq_abs,
      Complex.norm_I, mul_one, abs_of_nonneg hr0] using hr1
  have hi₁ := (continuous_log_norm_one_sub hplus).intervalIntegrable (μ := volume) (0 : ℝ) 1
  have hi₂ := (continuous_log_norm_one_sub hminus).intervalIntegrable (μ := volume) (0 : ℝ) 1
  simp_rw [physicalHopping_log_norm hr0 hr1]
  rw [intervalIntegral.integral_add (intervalIntegrable_const.add hi₁) hi₂,
    intervalIntegral.integral_add intervalIntegrable_const hi₁,
    integral_log_norm_one_sub hplus, integral_log_norm_one_sub hminus]
  simp

end UAMO.CMV

import UAMO.CMVUniformGrowth

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped BigOperators

theorem transferProduct_step_intertwining (A : ℝ → TransferMatrix)
    (ω x : ℝ) (n : ℕ) :
    A (x+(n:ℝ)*ω)*transferProduct A ω x n =
      transferProduct A ω (x+ω) n*A x := by
  have h := transferProduct_add A ω x n 1
  simpa only [transferProduct_succ,transferProduct_zero,
    Nat.cast_one,one_mul,Matrix.mul_one,Nat.cast_zero,zero_mul,add_zero] using h

theorem transferProduct_shift_norm_le (A : ℝ → TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (ω x : ℝ) (n : ℕ) :
    transferNorm (transferProduct A ω (x+ω) n) ≤
      (4*C^2)*transferNorm (transferProduct A ω x n) := by
  have hC0 : 0≤C := (norm_nonneg _).trans (hC x)
  have hunit : IsUnit (A x).det := isUnit_iff_ne_zero.mpr (by
    intro h; have hh := hd x; simp [h] at hh)
  have heq : transferProduct A ω (x+ω) n =
      (A (x+(n:ℝ)*ω)*transferProduct A ω x n)*(A x)⁻¹ := by
    rw [transferProduct_step_intertwining,Matrix.mul_assoc,Matrix.mul_nonsing_inv _ hunit,
      Matrix.mul_one]
  rw [heq]
  have hi := (transferNorm_inv_le_four (A x) (hd x)).trans
    (mul_le_mul_of_nonneg_left (hC x) (by norm_num : (0:ℝ)≤4))
  calc
    _ ≤ (transferNorm (A (x+(n:ℝ)*ω))*transferNorm (transferProduct A ω x n))*
        transferNorm (A x)⁻¹ := (transferNorm_mul_le _ _).trans
          (mul_le_mul_of_nonneg_right (transferNorm_mul_le _ _) (norm_nonneg _))
    _ ≤ (C*transferNorm (transferProduct A ω x n))*(4*C) :=
      mul_le_mul (mul_le_mul_of_nonneg_right (hC _) (norm_nonneg _)) hi
        (norm_nonneg _) (mul_nonneg hC0 (norm_nonneg _))
    _ = _ := by ring

theorem transferProduct_norm_le_shift (A : ℝ → TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (ω x : ℝ) (n : ℕ) :
    transferNorm (transferProduct A ω x n) ≤
      (4*C^2)*transferNorm (transferProduct A ω (x+ω) n) := by
  have hC0 : 0≤C := (norm_nonneg _).trans (hC x)
  have hunit : IsUnit (A (x+(n:ℝ)*ω)).det := isUnit_iff_ne_zero.mpr (by
    intro h; have hh := hd (x+(n:ℝ)*ω); simp [h] at hh)
  have heq : transferProduct A ω x n =
      (A (x+(n:ℝ)*ω))⁻¹*(transferProduct A ω (x+ω) n*A x) := by
    rw [← transferProduct_step_intertwining,← Matrix.mul_assoc,
      Matrix.nonsing_inv_mul _ hunit,Matrix.one_mul]
  rw [heq]
  have hi := (transferNorm_inv_le_four (A (x+(n:ℝ)*ω)) (hd _)).trans
    (mul_le_mul_of_nonneg_left (hC _) (by norm_num : (0:ℝ)≤4))
  calc
    _ ≤ transferNorm (A (x+(n:ℝ)*ω))⁻¹*
        (transferNorm (transferProduct A ω (x+ω) n)*transferNorm (A x)) :=
      (transferNorm_mul_le _ _).trans
        (mul_le_mul_of_nonneg_left (transferNorm_mul_le _ _) (norm_nonneg _))
    _ ≤ (4*C)*(transferNorm (transferProduct A ω (x+ω) n)*C) :=
      mul_le_mul hi (mul_le_mul_of_nonneg_left (hC _) (norm_nonneg _))
        (mul_nonneg (norm_nonneg _) (norm_nonneg _)) (by positivity)
    _ = _ := by ring

theorem transferLogNorm_step_difference (A : ℝ → TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (ω x : ℝ) (n : ℕ) :
    |transferLogNorm A ω (x+ω) n-transferLogNorm A ω x n|≤Real.log (4*C^2) := by
  have hC1 : 1≤C := (one_le_transferNorm_of_det_norm (A x) (hd x)).trans (hC x)
  have hCp : 0<4*C^2 := by positivity
  have h₁ := Real.log_le_log (transferProduct_norm_pos A hd ω (x+ω) n)
    (transferProduct_shift_norm_le A hd hC ω x n)
  have h₂ := Real.log_le_log (transferProduct_norm_pos A hd ω x n)
    (transferProduct_norm_le_shift A hd hC ω x n)
  rw [Real.log_mul hCp.ne' (transferProduct_norm_pos A hd ω x n).ne'] at h₁
  rw [Real.log_mul hCp.ne' (transferProduct_norm_pos A hd ω (x+ω) n).ne'] at h₂
  rw [abs_le]
  constructor <;> unfold transferLogNorm <;> linarith

theorem transferLogNorm_nat_shift_difference (A : ℝ → TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (ω x : ℝ) (n j : ℕ) :
    |transferLogNorm A ω (x+(j:ℝ)*ω) n-transferLogNorm A ω x n|≤
      (j:ℝ)*Real.log (4*C^2) := by
  induction j with
  | zero => simp
  | succ j ih =>
    have h := transferLogNorm_step_difference A hd hC ω (x+(j:ℝ)*ω) n
    have ht := abs_sub_le (transferLogNorm A ω (x+(j:ℝ)*ω+ω) n)
      (transferLogNorm A ω (x+(j:ℝ)*ω) n) (transferLogNorm A ω x n)
    rw [show x+((j+1:ℕ):ℝ)*ω=x+(j:ℝ)*ω+ω by push_cast; ring]
    push_cast
    linarith

theorem transferLogNorm_int_shift_difference (A : ℝ → TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (ω x : ℝ) (n : ℕ) (j : ℤ) :
    |transferLogNorm A ω (x+(j:ℝ)*ω) n-transferLogNorm A ω x n|≤
      |(j:ℝ)| *Real.log (4*C^2) := by
  rcases j with j | j
  · simpa using transferLogNorm_nat_shift_difference A hd hC ω x n j
  · have h := transferLogNorm_nat_shift_difference A hd hC ω (x-((j:ℝ)+1)*ω) n (j+1)
    have he : x-((j:ℝ)+1)*ω+((j+1:ℕ):ℝ)*ω=x := by push_cast; ring
    rw [he,abs_sub_comm] at h
    simpa only [Int.cast_negSucc,abs_neg,abs_of_nonneg (by positivity : 0≤(j:ℝ)+1),
      Nat.cast_add,Nat.cast_one,neg_mul,← sub_eq_add_neg] using h

theorem normalized_transferLogNorm_int_shift_difference (A : ℝ → TransferMatrix)
    (hd : ∀x,‖(A x).det‖=1) {C : ℝ} (hC : ∀x,transferNorm (A x)≤C)
    (ω x : ℝ) {n : ℕ} (hn : 0<n) (j : ℤ) :
    |transferLogNorm A ω (x+(j:ℝ)*ω) n/(n:ℝ)-transferLogNorm A ω x n/(n:ℝ)|≤
      |(j:ℝ)| *Real.log (4*C^2)/(n:ℝ) := by
  rw [← sub_div,abs_div,abs_of_pos (by exact_mod_cast hn : (0:ℝ)<n)]
  exact div_le_div_of_nonneg_right (transferLogNorm_int_shift_difference A hd hC ω x n j)
    (Nat.cast_nonneg n)

end UAMO.CMV

import UAMO.CMVFiniteLogCircle
import UAMO.BJLargeDeviation

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set CircleDOS BourgainJitomirskaya
open scoped Matrix.L2OpNorm
local instance logLargeDeviationCirclePeriod : Fact (0<(1:ℝ)) := ⟨by norm_num⟩

theorem unitCircle_measurePreserving_mk :
    MeasurePreserving (fun t:ℝ => (t:AddCircle (1:ℝ)))
      (volume.restrict (Ioc (0:ℝ) 1)) AddCircle.haarAddCircle := by
  have hv : (volume:Measure (AddCircle (1:ℝ)))=AddCircle.haarAddCircle := by
    simpa using AddCircle.volume_eq_smul_haarAddCircle (T:=(1:ℝ))
  simpa only [zero_add,hv] using AddCircle.measurePreserving_mk (T:=(1:ℝ)) 0

theorem fourierCoeff_finiteFrobeniusCircle_zero (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1) (ω : ℝ) (n : ℕ) :
    fourierCoeff (finiteFrobeniusCircle A hc hp hd ω n) 0=
      ((∫t in (0:ℝ)..1,finiteFrobeniusLog A ω n t : ℝ):ℂ) := by
  rw [fourierCoeff_finiteFrobeniusCircle,logFourierCoeff]
  simp only [neg_zero,logFourierChar_zero,mul_one]
  exact Complex.ofRealCLM.intervalIntegral_comp_comm
    ((continuous_finiteFrobeniusLog A hc hd ω n).intervalIntegrable 0 1)

theorem operatorDeviation_subset_frobenius_preimage (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    (ω : ℝ) {n : ℕ} (hn : 0<n) (κ : ℝ) (hscale : Real.log 2/(n:ℝ)≤κ/2) :
    {t:ℝ | κ < |transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ)-finiteLyapunov A ω n| } ⊆
      (fun t:ℝ => (t:AddCircle (1:ℝ))) ⁻¹'
        {x:AddCircle (1:ℝ)|κ/2<‖finiteFrobeniusCircle A hc hp hd ω n x-
          fourierCoeff (finiteFrobeniusCircle A hc hp hd ω n) 0‖} := by
  intro t ht
  change κ/2<‖finiteFrobeniusCircle A hc hp hd ω n (t:AddCircle (1:ℝ))-
    fourierCoeff (finiteFrobeniusCircle A hc hp hd ω n) 0‖
  rw [finiteFrobeniusCircle_coe,fourierCoeff_finiteFrobeniusCircle_zero,
    ← Complex.ofReal_sub,Complex.norm_real,Real.norm_eq_abs]
  have hp' := finiteFrobeniusLog_operator_bounds A hd ω hn t
  have hm := finiteFrobeniusLog_mean_bounds A hc hd ω hn
  have hpoint : |transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ)-finiteFrobeniusLog A ω n t|≤
      Real.log 2/(2*(n:ℝ)) := by
    rw [abs_sub_comm,abs_of_nonneg hp'.1]
    exact hp'.2
  have hmean : |(∫s in (0:ℝ)..1,finiteFrobeniusLog A ω n s)-finiteLyapunov A ω n|≤
      Real.log 2/(2*(n:ℝ)) := by
    rw [abs_of_nonneg hm.1]
    exact hm.2
  have ht₁ := abs_sub_le (transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ))
    (finiteFrobeniusLog A ω n t) (finiteLyapunov A ω n)
  have ht₂ := abs_sub_le (finiteFrobeniusLog A ω n t)
    (∫s in (0:ℝ)..1,finiteFrobeniusLog A ω n s) (finiteLyapunov A ω n)
  have htwo : Real.log 2/(n:ℝ)=2*(Real.log 2/(2*(n:ℝ))) := by ring
  change κ < |transferLogNorm A ω (2*Real.pi*t) n/(n:ℝ)-finiteLyapunov A ω n| at ht
  linarith

end UAMO.CMV

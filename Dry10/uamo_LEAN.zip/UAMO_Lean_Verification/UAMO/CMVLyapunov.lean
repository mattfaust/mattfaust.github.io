import UAMO.CMVTransfer
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.Subadditive
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.Analysis.SpecialFunctions.Log.Basic

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

def transferNorm (M : TransferMatrix) : ℝ :=
  ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M‖

@[simp] theorem transferNorm_one : transferNorm 1 = 1 := by simp [transferNorm]

theorem transferNorm_mul_le (M N : TransferMatrix) :
    transferNorm (M * N) ≤ transferNorm M * transferNorm N := by
  simpa only [transferNorm, map_mul] using
    norm_mul_le (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M)
      (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) N)

theorem continuous_transferNorm : Continuous transferNorm := by
  change Continuous (fun M : TransferMatrix => ‖M‖)
  exact continuous_norm

theorem one_le_transferNorm_of_det_norm (M : TransferMatrix) (hM : ‖M.det‖ = 1) :
    1 ≤ transferNorm M := by
  by_contra h
  have hnorm : ‖M‖ < 1 := lt_of_not_ge h
  have ht := ((continuous_id.matrix_det :
    Continuous (fun N : TransferMatrix => N.det)).norm).tendsto 0
  have hz : Tendsto (fun _ : ℕ => (1 : ℝ)) atTop (𝓝 0) := by
    simpa only [Function.comp_def, id_eq, Matrix.det_pow, norm_pow, hM, one_pow,
      Matrix.det_zero, norm_zero] using
      ht.comp (tendsto_pow_atTop_nhds_zero_of_norm_lt_one hnorm)
  exact one_ne_zero (tendsto_nhds_unique tendsto_const_nhds hz)

theorem transferProduct_add (A : ℝ → TransferMatrix) (ω x : ℝ) (m n : ℕ) :
    transferProduct A ω x (m + n) =
      transferProduct A ω (x + n * ω) m * transferProduct A ω x n := by
  induction m with
  | zero => simp
  | succ m ih =>
    have hp : x + ((m + n : ℕ) : ℝ) * ω = (x + n * ω) + m * ω := by
      push_cast
      ring
    rw [Nat.succ_add, transferProduct_succ, ih, transferProduct_succ, hp]
    simp only [mul_assoc]

theorem transferProduct_det_norm (A : ℝ → TransferMatrix) (hd : ∀ x, ‖(A x).det‖ = 1)
    (ω x : ℝ) (n : ℕ) : ‖(transferProduct A ω x n).det‖ = 1 := by
  induction n with
  | zero => simp
  | succ n ih => simp only [transferProduct_succ, Matrix.det_mul, norm_mul, hd, ih, one_mul]

theorem one_le_transferProduct_norm (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω x : ℝ) (n : ℕ) :
    1 ≤ transferNorm (transferProduct A ω x n) :=
  one_le_transferNorm_of_det_norm _ (transferProduct_det_norm A hd ω x n)

theorem transferProduct_norm_pos (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω x : ℝ) (n : ℕ) :
    0 < transferNorm (transferProduct A ω x n) :=
  zero_lt_one.trans_le (one_le_transferProduct_norm A hd ω x n)

theorem continuous_transferProduct (A : ℝ → TransferMatrix) (hc : Continuous A)
    (ω : ℝ) (n : ℕ) : Continuous (fun x => transferProduct A ω x n) := by
  induction n with
  | zero => exact continuous_const
  | succ n ih => exact (hc.comp (continuous_id.add continuous_const)).mul ih

theorem transferProduct_periodic (A : ℝ → TransferMatrix) {T : ℝ}
    (hp : Function.Periodic A T) (ω : ℝ) (n : ℕ) :
    Function.Periodic (fun x => transferProduct A ω x n) T := by
  induction n with
  | zero => intro x; rfl
  | succ n ih =>
    intro x
    simp only [transferProduct_succ, ih x]
    rw [show x + T + n * ω = (x + n * ω) + T by ring, hp]

def transferLogNorm (A : ℝ → TransferMatrix) (ω x : ℝ) (n : ℕ) : ℝ :=
  Real.log (transferNorm (transferProduct A ω x n))

def transferLogAverage (A : ℝ → TransferMatrix) (ω : ℝ) (n : ℕ) : ℝ :=
  (∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω x n) / (2 * Real.pi)

def finiteLyapunov (A : ℝ → TransferMatrix) (ω : ℝ) (n : ℕ) : ℝ :=
  transferLogAverage A ω n / (n : ℝ)

def lyapunov (A : ℝ → TransferMatrix) (ω : ℝ) : ℝ :=
  sInf ((fun n => finiteLyapunov A ω n) '' Ici 1)

theorem transferLogNorm_nonneg (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω x : ℝ) (n : ℕ) :
    0 ≤ transferLogNorm A ω x n :=
  Real.log_nonneg (one_le_transferProduct_norm A hd ω x n)

theorem continuous_transferLogNorm (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) (n : ℕ) :
    Continuous (fun x => transferLogNorm A ω x n) :=
  (continuous_transferNorm.comp (continuous_transferProduct A hc ω n)).log
    (fun x => ne_of_gt (transferProduct_norm_pos A hd ω x n))

theorem transferLogNorm_periodic (A : ℝ → TransferMatrix)
    (hp : Function.Periodic A (2 * Real.pi)) (ω : ℝ) (n : ℕ) :
    Function.Periodic (fun x => transferLogNorm A ω x n) (2 * Real.pi) := by
  intro x
  exact congrArg (fun M => Real.log (transferNorm M)) (transferProduct_periodic A hp ω n x)

theorem transferLogNorm_integral_shift (A : ℝ → TransferMatrix)
    (hp : Function.Periodic A (2 * Real.pi)) (ω : ℝ) (n : ℕ) (t : ℝ) :
    (∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω (x + t) n) =
      ∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω x n := by
  rw [intervalIntegral.integral_comp_add_right (fun x => transferLogNorm A ω x n) t]
  simpa only [zero_add, add_comm (2 * Real.pi) t] using
    (transferLogNorm_periodic A hp ω n).intervalIntegral_add_eq t 0

theorem transferLogNorm_add_le (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω x : ℝ) (m n : ℕ) :
    transferLogNorm A ω x (m + n) ≤
      transferLogNorm A ω (x + n * ω) m + transferLogNorm A ω x n := by
  unfold transferLogNorm
  rw [transferProduct_add]
  calc
    Real.log (transferNorm
        (transferProduct A ω (x + n * ω) m * transferProduct A ω x n)) ≤
        Real.log (transferNorm (transferProduct A ω (x + n * ω) m) *
          transferNorm (transferProduct A ω x n)) := by
      apply Real.log_le_log
      · rw [← transferProduct_add]
        exact transferProduct_norm_pos A hd ω x (m + n)
      · exact transferNorm_mul_le _ _
    _ = _ := Real.log_mul
      (ne_of_gt (transferProduct_norm_pos A hd ω _ m))
      (ne_of_gt (transferProduct_norm_pos A hd ω x n))

theorem transferLogAverage_subadditive (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2 * Real.pi)) (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) :
    Subadditive (transferLogAverage A ω) := by
  intro m n
  unfold transferLogAverage
  rw [← add_div]
  apply div_le_div_of_nonneg_right _ (by positivity)
  have hm : IntervalIntegrable (fun x => transferLogNorm A ω (x + n * ω) m)
      volume 0 (2 * Real.pi) := ((continuous_transferLogNorm A hc hd ω m).comp
    (show Continuous (fun x : ℝ => x + n * ω) from
      continuous_id.add continuous_const)).intervalIntegrable 0 (2 * Real.pi)
  have hn : IntervalIntegrable (fun x => transferLogNorm A ω x n)
      volume 0 (2 * Real.pi) :=
    (continuous_transferLogNorm A hc hd ω n).intervalIntegrable 0 (2 * Real.pi)
  calc
    (∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω x (m + n)) ≤
        ∫ x in (0 : ℝ)..(2 * Real.pi),
          (transferLogNorm A ω (x + n * ω) m + transferLogNorm A ω x n) :=
      intervalIntegral.integral_mono (by positivity)
        ((continuous_transferLogNorm A hc hd ω (m + n)).intervalIntegrable _ _)
        (hm.add hn) (fun x => transferLogNorm_add_le A hd ω x m n)
    _ = (∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω (x + n * ω) m) +
        ∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm A ω x n :=
      intervalIntegral.integral_add hm hn
    _ = _ := by rw [transferLogNorm_integral_shift A hp]

theorem finiteLyapunov_nonneg (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) (n : ℕ) :
    0 ≤ finiteLyapunov A ω n := by
  apply div_nonneg _ (Nat.cast_nonneg n)
  apply div_nonneg _ (by positivity)
  exact intervalIntegral.integral_nonneg (by positivity)
    (fun x _ => transferLogNorm_nonneg A hd ω x n)

theorem finiteLyapunov_bddBelow (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) : BddBelow (range (finiteLyapunov A ω)) := by
  refine ⟨0, ?_⟩
  rintro _ ⟨n, rfl⟩
  exact finiteLyapunov_nonneg A hd ω n

theorem lyapunov_nonneg (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) : 0 ≤ lyapunov A ω := by
  apply le_csInf (show ((fun n => finiteLyapunov A ω n) '' Ici 1).Nonempty from
    ⟨finiteLyapunov A ω 1, 1, by simp, rfl⟩)
  rintro _ ⟨n, _, rfl⟩
  exact finiteLyapunov_nonneg A hd ω n

theorem lyapunov_le_finite (A : ℝ → TransferMatrix)
    (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) {n : ℕ} (hn : 1 ≤ n) :
    lyapunov A ω ≤ finiteLyapunov A ω n :=
  csInf_le ((finiteLyapunov_bddBelow A hd ω).mono (image_subset_range _ _)) ⟨n, hn, rfl⟩

theorem tendsto_finiteLyapunov (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2 * Real.pi)) (hd : ∀ x, ‖(A x).det‖ = 1) (ω : ℝ) :
    Tendsto (finiteLyapunov A ω) atTop (𝓝 (lyapunov A ω)) := by
  have h := (transferLogAverage_subadditive A hc hp hd ω).tendsto_lim
    (finiteLyapunov_bddBelow A hd ω)
  simpa only [Subadditive.lim, lyapunov, finiteLyapunov] using h

theorem uamoTransfer_periodic (a r : ℝ) (z : ℂ) :
    Function.Periodic (uamoTransfer a r z) (2 * Real.pi) := by
  intro x
  simp only [uamoTransfer, oddAlpha, physicalHopping, Real.sin_add_two_pi, Real.cos_add_two_pi]

theorem continuous_uamoTransfer (a : ℝ) {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (z : ℂ) :
    Continuous (uamoTransfer a r z) := by
  have hq : Continuous (physicalHopping r) := by
    unfold physicalHopping
    fun_prop
  have hqi := hq.star.inv₀ (fun x => star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x))
  unfold uamoTransfer physicalTransfer
  apply hqi.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp [oddAlpha] <;> fun_prop

def uamoLyapunov (a r ω : ℝ) (z : ℂ) : ℝ := lyapunov (uamoTransfer a r z) ω

theorem uamoLyapunov_nonneg {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) : 0 ≤ uamoLyapunov a r ω z :=
  lyapunov_nonneg _ (uamoTransfer_det_norm ha hr hr1 hz) ω

theorem tendsto_uamoFiniteLyapunov {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    Tendsto (finiteLyapunov (uamoTransfer a r z) ω) atTop (𝓝 (uamoLyapunov a r ω z)) :=
  tendsto_finiteLyapunov _ (continuous_uamoTransfer a hr hr1 z)
    (uamoTransfer_periodic a r z) (uamoTransfer_det_norm ha hr hr1 hz) ω

end UAMO.CMV

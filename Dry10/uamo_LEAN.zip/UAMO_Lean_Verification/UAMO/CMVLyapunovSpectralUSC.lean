import UAMO.CMVLyapunov
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Topology.Semicontinuous

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

abbrev NonzeroEnergy := {z : ℂ // z ≠ 0}

local instance nonzeroEnergy_locallyCompactSpace : LocallyCompactSpace NonzeroEnergy :=
  (isOpen_ne : IsOpen {z : ℂ | z ≠ 0}).locallyCompactSpace

theorem continuous_uamoTransfer_spectral_phase (a : ℝ) {r : ℝ}
    (hr : 0 ≤ r) (hr1 : r < 1) :
    Continuous (fun p : NonzeroEnergy × ℝ => uamoTransfer a r p.1.val p.2) := by
  have hz : Continuous (fun p : NonzeroEnergy × ℝ => p.1.val) :=
    continuous_subtype_val.comp continuous_fst
  have hzi := hz.inv₀ (fun p => p.1.property)
  have hq : Continuous (fun p : NonzeroEnergy × ℝ => physicalHopping r p.2) := by
    unfold physicalHopping
    fun_prop
  have hqi := hq.star.inv₀
    (fun p => star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 p.2))
  unfold uamoTransfer physicalTransfer
  apply hqi.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp [oddAlpha] <;> fun_prop

theorem continuous_uamoTransferProduct_spectral_phase (a : ℝ) {r : ℝ}
    (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) (n : ℕ) :
    Continuous (fun p : NonzeroEnergy × ℝ =>
      transferProduct (uamoTransfer a r p.1.val) ω p.2 n) := by
  induction n with
  | zero => exact continuous_const
  | succ n ih =>
    exact ((continuous_uamoTransfer_spectral_phase a hr hr1).comp
      (continuous_fst.prodMk (continuous_snd.add continuous_const))).mul ih

theorem continuous_uamoTransferLogNorm_spectral_phase {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) (n : ℕ) :
    Continuous (fun p : NonzeroEnergy × ℝ =>
      transferLogNorm (uamoTransfer a r p.1.val) ω p.2 n) := by
  apply (continuous_transferNorm.comp
    (continuous_uamoTransferProduct_spectral_phase a hr hr1 ω n)).log
  intro p
  exact ne_of_gt (transferProduct_norm_pos _
    (uamoTransfer_det_norm ha hr hr1 p.1.property) ω p.2 n)

theorem continuous_uamoFiniteLyapunov_nonzero {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) (n : ℕ) :
    Continuous (fun z : NonzeroEnergy => finiteLyapunov (uamoTransfer a r z.val) ω n) := by
  have hc := continuous_parametric_integral_of_continuous (μ := volume)
    (f := fun z : NonzeroEnergy => fun x : ℝ =>
      transferLogNorm (uamoTransfer a r z.val) ω x n)
    (continuous_uamoTransferLogNorm_spectral_phase ha hr hr1 ω n) (isCompact_Icc (a := (0 : ℝ)) (b := 2 * Real.pi))
  have heq : (fun z : NonzeroEnergy =>
      ∫ x in Icc (0 : ℝ) (2 * Real.pi), transferLogNorm (uamoTransfer a r z.val) ω x n) =
      (fun z : NonzeroEnergy =>
      ∫ x in (0 : ℝ)..(2 * Real.pi), transferLogNorm (uamoTransfer a r z.val) ω x n) := by
    funext z
    rw [intervalIntegral.integral_of_le (by positivity : (0 : ℝ) ≤ 2 * Real.pi),
      integral_Icc_eq_integral_Ioc]
  rw [heq] at hc
  exact (hc.div_const (2 * Real.pi)).div_const (n : ℝ)

theorem continuousAt_uamoFiniteLyapunov {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) (n : ℕ)
    {z : ℂ} (hz : z ≠ 0) :
    ContinuousAt (fun w : ℂ => finiteLyapunov (uamoTransfer a r w) ω n) z := by
  apply ContinuousWithinAt.continuousAt (s := {w : ℂ | w ≠ 0})
  · exact (continuousOn_iff_continuous_restrict.mpr
      (continuous_uamoFiniteLyapunov_nonzero ha hr hr1 ω n)) z hz
  · exact isOpen_ne.mem_nhds hz

theorem upperSemicontinuousAt_uamoLyapunov {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ)
    {z : ℂ} (hz : z ≠ 0) :
    UpperSemicontinuousAt (uamoLyapunov a r ω) z := by
  intro b hb
  obtain ⟨v, ⟨n, hn, rfl⟩, hnb⟩ := exists_lt_of_csInf_lt
    (show ((fun n => finiteLyapunov (uamoTransfer a r z) ω n) '' Ici 1).Nonempty from
      ⟨finiteLyapunov (uamoTransfer a r z) ω 1, 1, by simp, rfl⟩) hb
  have hnz : ∀ᶠ w : ℂ in 𝓝 z, w ≠ 0 := isOpen_ne.mem_nhds hz
  have hnear : ∀ᶠ w : ℂ in 𝓝 z, finiteLyapunov (uamoTransfer a r w) ω n < b :=
    (continuousAt_uamoFiniteLyapunov ha hr hr1 ω n hz).tendsto.eventually
      (Iio_mem_nhds hnb)
  filter_upwards [hnz, hnear] with w hw hwb
  exact (lyapunov_le_finite _ (uamoTransfer_det_norm ha hr hr1 hw) ω hn).trans_lt hwb

end UAMO.CMV

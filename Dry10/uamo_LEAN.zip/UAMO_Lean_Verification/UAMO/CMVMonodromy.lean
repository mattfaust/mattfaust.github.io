import UAMO.CMVFiniteTransfer

noncomputable section
namespace UAMO.CMV
open Matrix

def indexedProduct (A : ℕ → TransferMatrix) : ℕ → TransferMatrix
  | 0 => 1
  | k + 1 => A k * indexedProduct A k

def finiteCellTransfer (n : ℕ) (a r ω x : ℝ) (z : ℂ)
    (j : ZMod (n + 1)) : TransferMatrix :=
  gzCell (coupling a) (complementaryCoupling a) (oddAlpha r (x + j.val * ω))
    (star (physicalHopping r (x + j.val * ω))) z

def finiteMonodromy (n : ℕ) (a r ω x : ℝ) (z : ℂ) : TransferMatrix :=
  indexedProduct (fun j => finiteCellTransfer n a r ω x z j) (n + 1)

def finiteState (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ) (j : ZMod (n + 1)) : Fin 2 → ℂ :=
  ![u (0, j), (finiteOdd n r ω x *ᵥ u) (0, j)]

end UAMO.CMV

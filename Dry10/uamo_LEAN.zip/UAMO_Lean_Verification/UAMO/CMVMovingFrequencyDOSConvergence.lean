import UAMO.CMVFrequencyDOSMoments
import UAMO.CMVEmpiricalDOSConvergence

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter CircleDOS PhysicalDOS
open scoped Topology

local instance : MeasurableSpace Circle := borel Circle
local instance : BorelSpace Circle := ⟨rfl⟩

theorem finiteSpectralMeasure_moving_frequency_tests_tendsto
    (a r : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (N : ℕ → ℕ) (Φ : ℕ → ℝ) {α : ℝ}
    (hN : Tendsto N atTop atTop) (hΦ : Tendsto Φ atTop (𝓝 α))
    (f : ℂ → ℂ) (hf : Continuous (fun z : Circle => f z)) :
    Tendsto (fun j => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, f z ∂finiteSpectralMeasure (N j) a r (2*Real.pi*Φ j) (2*Real.pi*θ)) atTop
        (𝓝 (∫ z : ℂ, f z ∂physicalUnitaryDOS a r α ha0 ha1 hr0 hr1)) := by
  let ν := physicalUnitaryDOS a r α ha0 ha1 hr0 hr1
  have hcircle := physicalUnitaryDOS_ae_circle a r α ha0 ha1 hr0 hr1
  letI := circleComap_probability ν hcircle
  let L₀ := circleIntegralCLM (circleComap ν)
  have hstar (g : C(Circle, ℂ)) : L₀ (star g) = star (L₀ g) := by
    change (∫ z : Circle, star (g z) ∂circleComap ν) = _
    simp only [Complex.star_def, integral_conj]
    rfl
  have hmoment (k : ℕ) : L₀ (circleCharacter k) = ∫ z : ℂ, z^k ∂ν := by
    change (∫ z : Circle, (z : ℂ)^(k : ℤ) ∂circleComap ν) = _
    simp only [zpow_natCast]
    exact circleComap_integral ν hcircle (fun z : ℂ => z^k)
  have hm (k : ℕ) : Tendsto
      (fun j => finitePhaseCircleTest (N j) a r (Φ j) (circleCharacter k))
      atTop (𝓝 (L₀ (circleCharacter k))) := by
    rw [hmoment]
    simp only [finitePhaseCircleTest_character]
    simpa only [finiteSpectralMeasure_moment] using
      finiteSpectralMeasure_moving_frequency_moments_tendsto a r ha0 ha1 hr0 hr1 N Φ hN hΦ k
  have h := circleFunctional_tendsto_of_nat_characters
    (fun j => finitePhaseCircleTest (N j) a r (Φ j)) L₀
    (fun j => finitePhaseCircleTest_bound (N j) a r (Φ j)) (circleIntegralCLM_bound _)
    (fun j => finitePhaseCircleTest_star (N j) a r (Φ j)) hstar hm
    ⟨fun z : Circle => f z, hf⟩
  rw [show L₀ ⟨fun z : Circle => f z, hf⟩ = ∫ z : ℂ, f z ∂ν from
    circleComap_integral ν hcircle f] at h
  simpa only [finitePhaseCircleTest_restrict] using h

theorem finiteSpectralMeasure_moving_frequency_real_tests_tendsto
    (a r : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (N : ℕ → ℕ) (Φ : ℕ → ℝ) {α : ℝ}
    (hN : Tendsto N atTop atTop) (hΦ : Tendsto Φ atTop (𝓝 α))
    (f : ℂ → ℝ) (hf : Continuous (fun z : Circle => f z)) :
    Tendsto (fun j => ∫ θ in (0:ℝ)..1,
      ∫ z : ℂ, f z ∂finiteSpectralMeasure (N j) a r (2*Real.pi*Φ j) (2*Real.pi*θ)) atTop
        (𝓝 (∫ z : ℂ, f z ∂physicalUnitaryDOS a r α ha0 ha1 hr0 hr1)) := by
  have h := finiteSpectralMeasure_moving_frequency_tests_tendsto
    a r ha0 ha1 hr0 hr1 N Φ hN hΦ (fun z => (f z : ℂ))
    (Complex.continuous_ofReal.comp hf)
  have hre := Complex.continuous_re.continuousAt.tendsto.comp h
  simpa only [integral_complex_ofReal, intervalIntegral, integral_complex_ofReal,
    ← Complex.ofReal_sub, Complex.ofReal_re, Function.comp_def] using hre

end UAMO.CMV

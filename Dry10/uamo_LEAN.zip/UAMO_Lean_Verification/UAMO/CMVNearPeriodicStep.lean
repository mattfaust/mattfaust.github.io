import UAMO.UAMOPhaseBadSetGeometry
import UAMO.CMVAvalancheDeviations

noncomputable section

namespace UAMO.CMV
open BourgainJitomirskaya

open MeasureTheory Set

def FrobeniusHullBound (A:ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1) : Prop :=
  ∀(ω:ℝ)(n:ℕ),0<n → ∀c κ δ:ℝ,0≤κ → 0≤δ →
    AddCircle.haarAddCircle.real (phaseBadHull (finiteFrobeniusBadSet A hc hp hd ω n c κ) δ)≤
      AddCircle.haarAddCircle.real (finiteFrobeniusBadSet A hc hp hd ω n c κ)+32*(n:ℝ)*δ

theorem uamo_normalizedTransfer_hullBound {a r:ℝ} (ha:a≠0)
    (hr:0<r) (hr1:r≤1) {z:ℂ} (hz:z≠0) {y:ℝ} (hy:|y|≠ -Real.log r)
    (A:ℝ→TransferMatrix) (g:ℝ→ℂ) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (hrel:∀x,g x • A x=complexifiedPhaseTransfer a r z y x) :
    FrobeniusHullBound A hc hp hd := by
  intro ω n hn c κ δ hκ hδ
  exact measureReal_uamo_finiteFrobeniusBadHull_le ha hr hr1 hz hy A g hc hp hd hrel ω hn c hκ hδ

theorem unitCircle_measureReal_preimage {s:Set (AddCircle (1:ℝ))} (hs:MeasurableSet s) :
    (volume.restrict (Ioc (0:ℝ) 1)).real ((fun x:ℝ => (x:AddCircle (1:ℝ))) ⁻¹' s)=
      AddCircle.haarAddCircle.real s :=
  unitCircle_measurePreserving_mk.measureReal_preimage hs.nullMeasurableSet

theorem unitCircle_nearPeriodic_shift (α : ℝ) (N j : ℕ) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) :
    ((α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) =
      ((((j * N : ℕ) : ℝ) * (α - (a : ℝ) / (q : ℝ)) : ℝ) : AddCircle (1 : ℝ)) := by
  obtain ⟨r, hr⟩ := hqN
  have hqr : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  have heq : α * ((j * N : ℕ) : ℝ) -
      ((j * N : ℕ) : ℝ) * (α - (a : ℝ) / (q : ℝ)) =
        (((j : ℤ) * (r : ℤ) * a : ℤ) : ℝ) := by
    rw [hr]
    push_cast
    field_simp
    ring
  have hz : (((((j : ℤ) * (r : ℤ) * a : ℤ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) = 0 := by
    apply (AddCircle.coe_eq_zero_iff (1 : ℝ)).mpr
    refine ⟨(j : ℤ) * (r : ℤ) * a, ?_⟩
    simp
  apply sub_eq_zero.mp
  rw [← AddCircle.coe_sub, heq, hz]

theorem not_mem_phaseBadSet_nearPeriodic_shift
    {s : Set (AddCircle (1 : ℝ))} {x : AddCircle (1 : ℝ)}
    (α : ℝ) (N m j : ℕ) (a : ℤ) (q : ℕ) (hq : 0 < q) (hqN : q ∣ N)
    (hj : j ≤ m) {η : ℝ}
    (hnear : (((m * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hx : x ∉ phaseBadHull s η) :
    x + ((α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) ∉ s := by
  intro hbad
  apply hx
  refine ⟨((j * N : ℕ) : ℝ) * (α - (a : ℝ) / (q : ℝ)), ?_, ?_⟩
  · rw [abs_mul, abs_of_nonneg (Nat.cast_nonneg _)]
    refine le_trans ?_ hnear
    exact mul_le_mul_of_nonneg_right
      (by exact_mod_cast Nat.mul_le_mul_right N hj) (abs_nonneg _)
  · rw [← unitCircle_nearPeriodic_shift α N j a q hq hqN]
    exact hbad

def nearPeriodicBadSet (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,‖(A x).det‖=1) (α:ℝ) (N : ℕ) (κ η : ℝ) :
    Set (AddCircle (1 : ℝ)) :=
  phaseBadHull (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) N (finiteLyapunov A (2*Real.pi*α) N) κ) η ∪
    phaseBadHull (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) (2 * N)
      (finiteLyapunov A (2*Real.pi*α) (2 * N)) κ) η

theorem measurableSet_nearPeriodicBadSet
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,‖(A x).det‖=1) (α:ℝ) (N : ℕ) (κ η : ℝ) :
    MeasurableSet (nearPeriodicBadSet A hc hp hd α N κ η) :=
  (measurableSet_finiteFrobeniusBadHull A hc hp hd (2*Real.pi*α) N _ κ η).union
    (measurableSet_finiteFrobeniusBadHull A hc hp hd (2*Real.pi*α) (2 * N) _ κ η)

theorem nearPeriodicBadSet_mass_le
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,‖(A x).det‖=1) (hhull:FrobeniusHullBound A hc hp hd) (α:ℝ) (N : ℕ) (hN : 0 < N) {κ η δ : ℝ}
    (hκ : 0 ≤ κ) (hη : 0 ≤ η)
    (hbadN : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) N (finiteLyapunov A (2*Real.pi*α) N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) (2 * N) (finiteLyapunov A (2*Real.pi*α) (2 * N)) κ) ≤ δ) :
    AddCircle.haarAddCircle.real (nearPeriodicBadSet A hc hp hd α N κ η) ≤
      2 * δ + 96 * (N : ℝ) * η := by
  have h1 := hhull (2*Real.pi*α) N hN (finiteLyapunov A (2*Real.pi*α) N) κ η hκ hη
  have h2 := hhull (2*Real.pi*α) (2*N) (by omega) (finiteLyapunov A (2*Real.pi*α) (2*N)) κ η hκ hη
  have hu := measureReal_union_le (μ := AddCircle.haarAddCircle)
    (phaseBadHull (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) N (finiteLyapunov A (2*Real.pi*α) N) κ) η)
    (phaseBadHull (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) (2 * N)
      (finiteLyapunov A (2*Real.pi*α) (2 * N)) κ) η)
  change AddCircle.haarAddCircle.real (_ ∪ _) ≤ _
  simp only [Nat.cast_mul, Nat.cast_ofNat] at h2
  simp only [Measure.real] at hbadN hbad2N h1 h2 hu ⊢
  linarith

theorem nearPeriodicBadSet_frobenius_good
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,‖(A x).det‖=1) (α:ℝ) (N n : ℕ) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) {κ η : ℝ}
    (hnear : ((((n + 2) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (x : ℝ) (hx : (x : AddCircle (1 : ℝ)) ∉ nearPeriodicBadSet A hc hp hd α N κ η) :
    (∀ j < n + 2,
      |finiteFrobeniusLog A (2*Real.pi*α) N (x + α * ((j * N : ℕ) : ℝ)) -
        finiteLyapunov A (2*Real.pi*α) N| ≤ κ) ∧
    (∀ j < n + 1,
      |finiteFrobeniusLog A (2*Real.pi*α) (2 * N) (x + α * ((j * N : ℕ) : ℝ)) -
        finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤ κ) := by
  have hxs := not_or.mp hx
  constructor
  · intro j hj
    have h := not_mem_phaseBadSet_nearPeriodic_shift α N (n + 2) j a q hq hqN
      (by omega) hnear hxs.1
    change ((x + α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) ∉ _ at h
    rw [mem_finiteFrobeniusBadSet_coe] at h
    exact le_of_not_gt h
  · intro j hj
    have h := not_mem_phaseBadSet_nearPeriodic_shift α N (n + 2) j a q hq hqN
      (by omega) hnear hxs.2
    change ((x + α * ((j * N : ℕ) : ℝ) : ℝ) : AddCircle (1 : ℝ)) ∉ _ at h
    rw [mem_finiteFrobeniusBadSet_coe] at h
    exact le_of_not_gt h

theorem transferLogNorm_deviation_le_of_frobenius
    (A:ℝ→TransferMatrix) (hd:∀x,‖(A x).det‖=1) (α:ℝ) (N : ℕ) (hN : 0 < N) (x c : ℝ) {κ : ℝ}
    (hκ : 0 ≤ κ) (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hf : |finiteFrobeniusLog A (2*Real.pi*α) N x - c| ≤ κ) :
    |transferLogNorm A (2*Real.pi*α) (2 * Real.pi * x) N / (N : ℝ) - c| ≤ 2 * κ := by
  have h := finiteFrobeniusLog_operator_bounds A hd (2*Real.pi*α) hN x
  obtain ⟨hlo, hhi⟩ := abs_le.mp hf
  apply abs_le.mpr
  constructor <;> linarith [h.1, h.2]

theorem nearPeriodicBadSet_operator_good
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,‖(A x).det‖=1) (α:ℝ) (N n : ℕ) (hN : 0 < N) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) {κ η : ℝ} (hκ : 0 ≤ κ)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hnear : ((((n + 2) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (x : ℝ) (hx : (x : AddCircle (1 : ℝ)) ∉ nearPeriodicBadSet A hc hp hd α N κ η) :
    (∀ j < n + 2,
      |transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) N / (N : ℝ) -
          finiteLyapunov A (2*Real.pi*α) N| ≤ 2 * κ) ∧
    (∀ j < n + 1,
      |transferLogNorm A (2*Real.pi*α)
        (2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ)) (2 * N) / ((2 * N : ℕ) : ℝ) -
          finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤ 2 * κ) := by
  have hf := nearPeriodicBadSet_frobenius_good A hc hp hd α N n a q hq hqN hnear x hx
  have hgap2 : Real.log 2 / (2 * ((2 * N : ℕ) : ℝ)) ≤ κ := by
    calc
      _ = (Real.log 2 / (2 * (N : ℝ))) / 2 := by push_cast; ring
      _ ≤ κ := by linarith
  have hphase (j : ℕ) : 2 * Real.pi * (x + α * ((j * N : ℕ) : ℝ)) =
      2 * Real.pi * x + 2 * Real.pi * α * ((j * N : ℕ) : ℝ) := by ring
  constructor
  · intro j hj
    simpa only [hphase] using transferLogNorm_deviation_le_of_frobenius A hd α N hN
      (x + α * ((j * N : ℕ) : ℝ)) _ hκ hgap (hf.1 j hj)
  · intro j hj
    simpa only [hphase] using transferLogNorm_deviation_le_of_frobenius A hd α (2 * N)
      (by omega) (x + α * ((j * N : ℕ) : ℝ)) _ hκ hgap2 (hf.2 j hj)

theorem finiteLyapunov_nearPeriodic_step
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,‖(A x).det‖=1) (hdet:∀x,(A x).det=1) (hhull:FrobeniusHullBound A hc hp hd)
    (B:ℝ) (hB:0≤B) (hlinear:∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B) (α:ℝ) (N n : ℕ) (hN : 0 < N) (a : ℤ) (q : ℕ)
    (hq : 0 < q) (hqN : q ∣ N) {κ η δ : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hnear : ((((n + 2) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hL : 800 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hL2 : (9 / 10 : ℝ) * finiteLyapunov A (2*Real.pi*α) N ≤ finiteLyapunov A (2*Real.pi*α) (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)
    (hbadN : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) N (finiteLyapunov A (2*Real.pi*α) N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) (2 * N) (finiteLyapunov A (2*Real.pi*α) (2 * N)) κ) ≤ δ) :
    |finiteLyapunov A (2*Real.pi*α) ((n + 2) * N) +
      (1 - 2 / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) N -
      2 * (1 - 1 / (n + 2 : ℕ)) * finiteLyapunov A (2*Real.pi*α) (2 * N)| ≤
        1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
          4 * B * δ +
          192 * B * (N : ℝ) * η := by
  let s : Set ℝ := (fun x : ℝ => (x : AddCircle (1 : ℝ))) ⁻¹'
    nearPeriodicBadSet A hc hp hd α N κ η
  have hs : MeasurableSet s := (measurableSet_nearPeriodicBadSet A hc hp hd α N κ η).preimage
    QuotientAddGroup.continuous_mk.measurable
  have hmass : (volume.restrict (Ioc (0 : ℝ) 1)).real s ≤ 2 * δ + 96 * (N : ℝ) * η := by
    rw [unitCircle_measureReal_preimage (measurableSet_nearPeriodicBadSet A hc hp hd α N κ η)]
    exact nearPeriodicBadSet_mass_le A hc hp hd hhull α N hN hκ.le hη hbadN hbad2N
  have hμ : 10000 ≤ Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2) := by
    have h := Real.exp_le_exp.mpr hscale
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 10000)] using h
  have hgood (x : ℝ) (hx : x ∉ s) :=
    nearPeriodicBadSet_operator_good A hc hp hd α N n hN a q hq hqN hκ.le hgap hnear x hx
  have hconditions (x : ℝ) (hx : x ∉ s) :=
    avalanche_good_of_deviations A hdet α N n hN x (show 0 < 2 * κ by positivity)
      (by linarith : 400 * (2 * κ) ≤ finiteLyapunov A (2*Real.pi*α) N) hL2
      (hgood x hx).1 (hgood x hx).2
  have havg := finiteLyapunov_avalanche_average A hc hp hdet B hB hlinear α N n hN hμ hs hmass
    (fun x hx => (hconditions x hx).1) (fun x hx => (hconditions x hx).2)
  have hm : ((n + 2 : ℕ) : ℝ) ≠ 0 := by positivity
  have hcoeff1 : (n : ℝ) / (n + 2 : ℕ) = 1 - 2 / (n + 2 : ℕ) := by
    push_cast
    field_simp
  have hcoeff2 : (2 * (n + 1 : ℕ) / (n + 2 : ℕ) : ℝ) = 2 * (1 - 1 / (n + 2 : ℕ)) := by
    push_cast
    field_simp
    ring
  rw [hcoeff1, hcoeff2] at havg
  convert havg using 1
  ring

end UAMO.CMV

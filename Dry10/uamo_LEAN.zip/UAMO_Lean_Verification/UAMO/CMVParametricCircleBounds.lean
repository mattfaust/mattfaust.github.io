import UAMO.CMVTransferCircleBounds

noncomputable section
namespace UAMO.CMV
open Set
open scoped Matrix.L2OpNorm

theorem exists_uniform_transferCircleBounds {P:Type*} [TopologicalSpace P] [CompactSpace P]
    (A:P→ℝ→TransferMatrix) (hc:Continuous (fun p:P×ℝ => A p.1 p.2))
    (hp:∀p,Function.Periodic (A p) (2*Real.pi)) (hd:∀p x,‖(A p x).det‖=1) :
    ∃K:ℝ,∀p,TransferCircleBounds (A p) K := by
  have hnc := continuous_transferNorm.comp hc
  obtain ⟨C,hC⟩ := (isCompact_univ.prod (isCompact_Icc (a:=(0:ℝ)) (b:=2*Real.pi))).bddAbove_image
    hnc.continuousOn
  let D := max 1 C
  have hD : 1≤D := le_max_left _ _
  have hf (p:P) (x:ℝ) : transferNorm (A p x)≤D := by
    have hper : Function.Periodic (fun t=>transferNorm (A p t)) (2*Real.pi) :=
      fun t=>congrArg transferNorm (hp p t)
    have hm : transferNorm (A p x)∈(fun t=>transferNorm (A p t)) '' Icc (0:ℝ) (2*Real.pi) := by
      rw [show (2*Real.pi:ℝ)=0+2*Real.pi by ring,hper.image_Icc (by positivity) 0]
      exact mem_range_self x
    obtain ⟨t,ht,he⟩ := hm
    rw [← he]
    exact (hC ⟨(p,t),⟨mem_univ _,ht⟩,rfl⟩).trans (le_max_right _ _)
  refine ⟨4*D,?_⟩
  intro p
  refine ⟨hc.comp (continuous_const.prodMk continuous_id),hp p,hd p,by linarith,?_,?_⟩
  · intro x
    exact (hf p x).trans (by linarith)
  · intro x
    exact (transferNorm_inv_le_four (A p x) (hd p x)).trans
      (mul_le_mul_of_nonneg_left (hf p x) (by norm_num))

end UAMO.CMV

import UAMO.UAMOSpectralFrequencyContinuity
import UAMO.CMVParametricCircleBounds

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

def physicalUnitGauge (r x:ℝ) : ℂ :=
  star (physicalHopping r x)/(‖physicalHopping r x‖:ℂ)

def physicalSL2Transfer (a r:ℝ) (z:ℂ) (x:ℝ) : TransferMatrix :=
  physicalUnitGauge r x • uamoTransfer a r z x

def physicalSL2Scalar (r x:ℝ) : ℂ := ((1+r^2)*‖physicalHopping r x‖:ℝ)

theorem physicalUnitGauge_norm {r:ℝ} (hr:0≤r) (hr1:r<1) (x:ℝ) :
    ‖physicalUnitGauge r x‖=1 := by
  rw [physicalUnitGauge,norm_div,norm_star,Complex.norm_real,Real.norm_eq_abs,
    abs_of_nonneg (norm_nonneg _),div_self (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 x))]

theorem continuous_physicalUnitGauge {r:ℝ} (hr:0≤r) (hr1:r<1) :
    Continuous (physicalUnitGauge r) := by
  have hq:Continuous (physicalHopping r) := by unfold physicalHopping;fun_prop
  exact hq.star.div (Complex.continuous_ofReal.comp hq.norm)
    (fun x=>Complex.ofReal_ne_zero.mpr (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 x)))

theorem physicalSL2Transfer_periodic (a r:ℝ) (z:ℂ) :
    Function.Periodic (physicalSL2Transfer a r z) (2*Real.pi) := by
  intro x
  unfold physicalSL2Transfer
  rw [uamoTransfer_periodic a r z x]
  congr 1
  simp [physicalUnitGauge,physicalHopping]

theorem physicalSL2Transfer_det {a r:ℝ} (ha:0<a) (hr:0≤r) (hr1:r<1)
    {z:ℂ} (hz:z≠0) (x:ℝ) : (physicalSL2Transfer a r z x).det=1 :=
  uamoTransfer_det_normalized ha hr hr1 hz x

theorem continuous_physicalSL2Transfer_circle (a:ℝ) {r:ℝ} (hr:0≤r) (hr1:r<1) :
    Continuous (fun p:Circle×ℝ => physicalSL2Transfer a r (p.1:ℂ) p.2) := by
  have hz : Continuous (fun p:Circle×ℝ => ((p.1:ℂ)⁻¹)) :=
    (continuous_subtype_val.comp continuous_fst).inv₀ (fun p=>Circle.coe_ne_zero p.1)
  have hq : Continuous (fun p:Circle×ℝ => physicalHopping r p.2) := by unfold physicalHopping;fun_prop
  have hqi := hq.star.inv₀ (fun p=>star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 p.2))
  unfold physicalSL2Transfer
  apply ((continuous_physicalUnitGauge hr hr1).comp continuous_snd).smul
  unfold uamoTransfer physicalTransfer
  apply hqi.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp [oddAlpha] <;> fun_prop

theorem physicalSL2Transfer_lyapunov {r:ℝ} (hr:0≤r) (hr1:r<1)
    (a:ℝ) (z:ℂ) (ω:ℝ) :
    lyapunov (physicalSL2Transfer a r z) ω=uamoLyapunov a r ω z :=
  lyapunov_unit_gauge (uamoTransfer a r z) (physicalUnitGauge r) (physicalUnitGauge_norm hr hr1) ω

theorem physicalSL2Transfer_regularized {a r:ℝ} (ha:a≠0) (hr:0≤r) (hr1:r<1)
    (z:ℂ) (x:ℝ) :
    physicalSL2Scalar r x • physicalSL2Transfer a r z x=complexifiedPhaseTransfer a r z 0 x := by
  have hn : (‖physicalHopping r x‖:ℂ)≠0 :=
    Complex.ofReal_ne_zero.mpr (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 x))
  have he : complexifiedPhaseTransfer a r z 0 x=regularizedTransfer a r z x := by
    simpa only [complexifiedPhaseTransfer,Complex.ofReal_zero,zero_mul,add_zero] using
      complexifiedRegularizedTransfer_real ha r z x
  rw [he,regularizedTransfer_eq_scalar _ _ _ _ (physicalHopping_ne_zero hr hr1 x),
    physicalSL2Transfer,smul_smul]
  congr 1
  unfold physicalSL2Scalar physicalUnitGauge regularizingScalar
  push_cast
  field_simp
  ring

theorem exists_physicalSL2Transfer_circleBounds {a r:ℝ} (ha:0<a) (hr:0≤r) (hr1:r<1) :
    ∃K:ℝ,∀z:Circle,TransferCircleBounds (physicalSL2Transfer a r (z:ℂ)) K := by
  apply exists_uniform_transferCircleBounds (fun z:Circle => physicalSL2Transfer a r (z:ℂ))
    (continuous_physicalSL2Transfer_circle a hr hr1) (fun z=>physicalSL2Transfer_periodic a r z)
  intro z x
  rw [physicalSL2Transfer_det ha hr hr1 (Circle.coe_ne_zero z),norm_one]

end UAMO.CMV

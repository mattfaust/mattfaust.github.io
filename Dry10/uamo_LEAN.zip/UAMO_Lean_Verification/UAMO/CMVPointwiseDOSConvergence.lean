import UAMO.CMVPointwiseDOSMoments
import UAMO.CircleArcWeakConvergence

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter PhysicalDOS CircleDOS
open scoped Topology

def separatedEmpiricalProbability (n : ℕ) (a r Φ θ : ℝ) : ProbabilityMeasure ℂ :=
  ⟨separatedSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ),inferInstance⟩

def physicalDOSProbability (a r Φ : ℝ) (ha0 : 0≤a) (ha1 : a≤1)
    (hr0 : 0≤r) (hr1 : r≤1) : ProbabilityMeasure ℂ :=
  ⟨physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1,inferInstance⟩

theorem separatedSpectralMeasure_pointwise_weak_tendsto (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ) :
    Tendsto (fun n : ℕ => separatedEmpiricalProbability n a r Φ θ)
      atTop (𝓝 (physicalDOSProbability a r Φ ha0 ha1 hr0 hr1)) := by
  apply circleProbability_weak_tendsto_of_moments
  · intro n
    exact separatedSpectralMeasure_ae_circle n a r (2*Real.pi*Φ) (2*Real.pi*θ)
  · exact physicalUnitaryDOS_ae_circle a r Φ ha0 ha1 hr0 hr1
  · exact separatedSpectralMeasure_pointwise_moments_tendsto a r Φ θ ha0 ha1 hr0 hr1 hΦ

theorem separatedSpectralMeasure_pointwise_arcLabel_tendsto {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (Φ θ : ℝ)
    (hΦ : Irrational Φ) (z : ℂ) :
    Tendsto (fun n : ℕ => arcLabel
      (separatedSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ)) z) atTop
      (𝓝 (arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr0 hr1) z)) := by
  exact physical_arcLabel_tendsto_of_weak ha ha1 hr0 hr1 Φ _
    (separatedSpectralMeasure_pointwise_weak_tendsto a r Φ θ ha.le ha1 hr0 hr1 hΦ) z

end UAMO.CMV

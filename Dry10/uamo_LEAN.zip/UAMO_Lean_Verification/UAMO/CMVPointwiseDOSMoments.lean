import UAMO.PeriodicRotationAverages
import UAMO.CMVEmpiricalDOSLimit
import UAMO.CMVSeparatedBoundaryMoments
import UAMO.CMVSeparatedSpectral

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalCMV PhysicalRepresentation PhysicalRealPart PhysicalDOS MeasureTheory Filter
open scoped Topology

theorem cmvSiteMoment_phase_covariance (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (k : ℕ) (j : ℤ) :
    cmvSiteMoment a r Φ θ k j=cmvSiteMoment a r Φ (θ+Φ*(j:ℝ)) k 0 := by
  simp only [cmvSiteMoment,infiniteCMV_power_zero_entry a r Φ _ ha0 ha1 hr0 hr1,
    infiniteCMV_power_one_entry a r Φ _ ha0 ha1 hr0 hr1,walk_power_diagonal_at_site,
    Int.cast_zero,mul_zero,add_zero]
  rw [show θ-Φ+Φ*(j:ℝ)=θ+Φ*(j:ℝ)-Φ by ring]

theorem cmvSiteMoment_zero_periodic (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (k : ℕ) :
    Function.Periodic (fun θ => cmvSiteMoment a r Φ θ k 0) 1 := by
  intro θ
  simp only [cmvSiteMoment,infiniteCMV_power_zero_entry a r Φ _ ha0 ha1 hr0 hr1,
    infiniteCMV_power_one_entry a r Φ _ ha0 ha1 hr0 hr1]
  rw [show θ+1-Φ=(θ-Φ)+1 by ring,walk_periodic,walk_periodic]

def cmvBulkMoment (n : ℕ) (a r Φ θ : ℝ) (k : ℕ) : ℂ :=
  (∑ j : Fin (n+1), cmvSiteMoment a r Φ θ k (j.val:ℤ))/((n+1:ℕ):ℂ)

theorem cmvBulkMoment_eq_rotationAverage (n : ℕ) (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (k : ℕ) :
    cmvBulkMoment n a r Φ θ k=
      (∑ j ∈ Finset.range (n+1), cmvSiteMoment a r Φ (θ+(j:ℝ)*Φ) k 0)/((n+1:ℕ):ℂ) := by
  unfold cmvBulkMoment
  congr 1
  simp_rw [cmvSiteMoment_phase_covariance a r Φ θ ha0 ha1 hr0 hr1 k,Int.cast_natCast]
  simpa only [mul_comm Φ] using Fin.sum_univ_eq_sum_range
    (fun j : ℕ => cmvSiteMoment a r Φ (θ+(j:ℝ)*Φ) k 0) (n+1)

theorem cmvBulkMoment_tendsto (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ) (k : ℕ) :
    Tendsto (fun n : ℕ => cmvBulkMoment n a r Φ θ k) atTop
      (𝓝 (∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)) := by
  have ht := CircleDOS.periodic_rotation_average_tendsto hΦ
    (fun x => cmvSiteMoment a r Φ x k 0)
    (continuous_cmvSiteMoment a r Φ ha0 ha1 hr0 hr1 k 0)
    (cmvSiteMoment_zero_periodic a r Φ ha0 ha1 hr0 hr1 k) θ
  have hmean : (∫ x in (0:ℝ)..1, cmvSiteMoment a r Φ x k 0)=
      ∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 :=
    infiniteCMV_site_phase_averaged_moments a r Φ ha0 ha1 hr0 hr1 k 0
  rw [hmean] at ht
  have hs := ht.comp (tendsto_add_atTop_nat 1)
  exact hs.congr' (Eventually.of_forall (fun n =>
    (cmvBulkMoment_eq_rotationAverage n a r Φ θ ha0 ha1 hr0 hr1 k).symm))

theorem separatedSpectralMeasure_pointwise_bulk_error (n : ℕ) (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (k : ℕ) :
    ‖(∫ z : ℂ, z^k ∂separatedSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ))-
      cmvBulkMoment n a r Φ θ k‖≤4*(k:ℝ)/((n+1:ℕ):ℝ) := by
  rw [separatedSpectralMeasure_moment]
  unfold cmvBulkMoment
  rw [← cmv_bulk_normalization]
  exact separatedCMV_trace_power_bulk_error n a r Φ θ ha0 ha1 hr0 hr1 k

theorem separatedSpectralMeasure_pointwise_moments_tendsto (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ) (k : ℕ) :
    Tendsto (fun n : ℕ => ∫ z : ℂ, z^k ∂separatedSpectralMeasure n a r
      (2*Real.pi*Φ) (2*Real.pi*θ)) atTop
      (𝓝 (∫ z : ℂ, z^k ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)) := by
  have he : Tendsto (fun n : ℕ =>
      (∫ z : ℂ, z^k ∂separatedSpectralMeasure n a r (2*Real.pi*Φ) (2*Real.pi*θ))-
        cmvBulkMoment n a r Φ θ k) atTop (𝓝 0) := by
    apply squeeze_zero_norm
      (fun n => separatedSpectralMeasure_pointwise_bulk_error n a r Φ θ ha0 ha1 hr0 hr1 k)
    exact (tendsto_const_div_atTop_nhds_zero_nat (4*(k:ℝ))).comp (tendsto_add_atTop_nat 1)
  simpa only [sub_add_cancel,zero_add] using
    he.add (cmvBulkMoment_tendsto a r Φ θ ha0 ha1 hr0 hr1 hΦ k)

end UAMO.CMV

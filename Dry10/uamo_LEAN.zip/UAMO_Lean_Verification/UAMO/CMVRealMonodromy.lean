import UAMO.CMVTransferDetGrowthComparison
import UAMO.RealCocycleConjugacy

noncomputable section
namespace UAMO.CMV
open Matrix

def finiteHoppingPhase (r ω x : ℝ) (N : ℕ) : ℂ :=
  ∏ j ∈ Finset.range N,
    star (physicalHopping r (x+j*ω)) / (‖physicalHopping r (x+j*ω)‖ : ℂ)

def realMonodromy (a r t ω x : ℝ) (N : ℕ) : TransferMatrix :=
  transferProduct (complexRealTransfer a (coupling r) t) ω x N

theorem finiteHoppingPhase_norm {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1)
    (ω x : ℝ) (N : ℕ) : ‖finiteHoppingPhase r ω x N‖ = 1 := by
  unfold finiteHoppingPhase
  rw [norm_prod]
  apply Finset.prod_eq_one
  intro j _
  rw [norm_div, norm_star, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (norm_nonneg _)]
  exact div_self (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 _))

theorem finiteHoppingPhase_ne_zero {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1)
    (ω x : ℝ) (N : ℕ) : finiteHoppingPhase r ω x N ≠ 0 := by
  intro h
  have := finiteHoppingPhase_norm hr hr1 ω x N
  rw [h, norm_zero] at this
  norm_num at this

end UAMO.CMV

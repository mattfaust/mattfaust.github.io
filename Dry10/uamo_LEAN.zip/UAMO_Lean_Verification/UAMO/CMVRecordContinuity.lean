import UAMO.CMVFiniteSeedTopology

noncomputable section
namespace UAMO.CMV
open Filter Set BourgainJitomirskaya
open scoped Topology Matrix.L2OpNorm

variable {P : Type*} [TopologicalSpace P] [LocallyCompactSpace P] [FirstCountableTopology P]

theorem continuousAt_parametric_lyapunov_of_record_lower_bound
    (A : P→ℝ→TransferMatrix) (α : P→ℝ)
    (hA : Continuous (fun p:P×ℝ => A p.1 p.2)) (hα : Continuous α)
    (hdet : ∀p x,‖(A p x).det‖=1)
    (hperiod : ∀p,Function.Periodic (A p) (2*Real.pi))
    (hdense : Dense {p:P | Irrational (α p)})
    (hrecord : ∀κ:ℝ,0<κ→κ≤1→∃Q:ℕ,∀(p:P)(q:ℕ),
      Irrational (α p) → Q≤q → rotationRecord (α p) q →
      8000*κ≤finiteLyapunov (A p) (2*Real.pi*α p) (q^4)→
      finiteLyapunov (A p) (2*Real.pi*α p) (q^4)-
        finiteLyapunov (A p) (2*Real.pi*α p) (2*q^4)≤κ/100→
      finiteLyapunov (A p) (2*Real.pi*α p) (q^4)-κ≤lyapunov (A p) (2*Real.pi*α p))
    {p₀:P} (hirr : Irrational (α p₀)) :
    ContinuousAt (fun p => lyapunov (A p) (2*Real.pi*α p)) p₀ := by
  let L : P→ℝ := fun p => lyapunov (A p) (2*Real.pi*α p)
  have hupper : UpperSemicontinuous L :=
    upperSemicontinuous_parametric_lyapunov A (fun p=>2*Real.pi*α p) hA
      (continuous_const.mul hα) hdet
  have hnonneg (p:P) : 0≤L p := lyapunov_nonneg _ (hdet p) _
  apply continuousAt_iff_lower_upperSemicontinuousAt.mpr
  refine ⟨?_,hupper p₀⟩
  intro b hb
  change b<L p₀ at hb
  by_cases hbneg : b<0
  · exact Eventually.of_forall (fun p => hbneg.trans_le (hnonneg p))
  · have hb0 : 0≤b := le_of_not_gt hbneg
    have hL : 0<L p₀ := hb0.trans_lt hb
    let κ : ℝ := min 1 (min (L p₀/32000) ((L p₀-b)/4))
    have hκ : 0<κ := lt_min zero_lt_one (lt_min (by positivity) (by linarith))
    have hκ1 : κ≤1 := min_le_left _ _
    have hκL : κ≤L p₀/32000 := (min_le_right _ _).trans (min_le_left _ _)
    have hκb : κ≤(L p₀-b)/4 := (min_le_right _ _).trans (min_le_right _ _)
    have hmargin : 16000*κ<L p₀ := by linarith
    obtain ⟨Q,hQ⟩ := hrecord κ hκ hκ1
    obtain ⟨q,hq,U,hU,hp₀,hseed⟩ := exists_parametric_finite_record_seed A α hA hα
      hdet hperiod hirr hκ hκ hmargin Q
    have hlower : ∀p∈U∩{p:P | Irrational (α p)},L p₀-2*κ≤L p := by
      intro p hp
      obtain ⟨hr,hh,hg,hclose⟩ := hseed p hp.1
      have h := hQ p q hp.2 ((le_max_left _ _).trans hq) hr hh.le hg.le
      change L p₀-κ<finiteLyapunov (A p) (2*Real.pi*α p) (q^4) at hclose
      change finiteLyapunov (A p) (2*Real.pi*α p) (q^4)-κ≤L p at h
      linarith
    have hall := le_of_upperSemicontinuous_on_dense_open hupper hdense hU hlower
    filter_upwards [hU.mem_nhds hp₀] with p hp
    have hh := hall p hp
    change b<L p
    linarith

end UAMO.CMV

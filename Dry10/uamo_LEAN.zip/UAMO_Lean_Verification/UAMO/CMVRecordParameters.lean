import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

noncomputable section
namespace UAMO.CMV

open Filter
open scoped Topology

def recordGamma (c : ℝ) : ℝ := c / 1000

def recordEta (c : ℝ) (q : ℕ) : ℝ :=
  Real.exp (-recordGamma c * (q : ℝ))

def recordEpsilon (c D : ℝ) (q : ℕ) : ℝ :=
  D * Real.exp (-c * (q : ℝ))

def recordNearError (c D : ℝ) (q : ℕ) : ℝ :=
  D * ((q : ℝ) ^ 6 * recordEta c q + Real.exp (-c * (q : ℝ)))

def recordDecay (c : ℝ) (q : ℕ) : ℝ :=
  Real.exp (-(recordGamma c / 2) * (q : ℝ))

theorem recordGamma_pos {c : ℝ} (hc : 0 < c) : 0 < recordGamma c := by
  unfold recordGamma
  positivity

theorem tendsto_nat_pow_mul_exp_neg {a : ℝ} (ha : 0 < a) (degree : ℕ) :
    Tendsto (fun q : ℕ => (q : ℝ) ^ degree * Real.exp (-a * (q : ℝ)))
      atTop (𝓝 0) := by
  simpa only [Real.rpow_natCast] using
    (tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (degree : ℝ) a ha).comp
      tendsto_natCast_atTop_atTop

theorem eventually_nat_pow_mul_exp_neg_le (K : ℝ) (degree : ℕ)
    {a u : ℝ} (ha : 0 < a) (hu : 0 < u) :
    ∀ᶠ q : ℕ in atTop,
      K * (q : ℝ) ^ degree * Real.exp (-a * (q : ℝ)) ≤ u := by
  have hlim : Tendsto
      (fun q : ℕ => K * (q : ℝ) ^ degree * Real.exp (-a * (q : ℝ)))
      atTop (𝓝 0) := by
    simpa only [mul_zero, mul_assoc] using
      (tendsto_nat_pow_mul_exp_neg ha degree).const_mul K
  exact hlim.eventually (eventually_le_nhds hu)

theorem eventually_nat_pow_mul_exp_neg_le_decay (K : ℝ) (degree : ℕ)
    {a b u : ℝ} (hab : b < a) (hu : 0 < u) :
    ∀ᶠ q : ℕ in atTop,
      K * (q : ℝ) ^ degree * Real.exp (-a * (q : ℝ)) ≤
        u * Real.exp (-b * (q : ℝ)) := by
  filter_upwards [eventually_nat_pow_mul_exp_neg_le K degree (sub_pos.mpr hab) hu]
    with q hq
  have h := mul_le_mul_of_nonneg_right hq (Real.exp_pos (-b * (q : ℝ))).le
  calc
    _ = (K * (q : ℝ) ^ degree * Real.exp (-(a - b) * (q : ℝ))) *
        Real.exp (-b * (q : ℝ)) := by
      simp only [mul_assoc, ← Real.exp_add]
      congr 3
      ring
    _ ≤ _ := h

theorem eventually_nat_pow_mul_exp_neg_le_min (K : ℝ) (degree : ℕ)
    {a b u v : ℝ} (ha : 0 < a) (hab : b < a) (hu : 0 < u) (hv : 0 < v) :
    ∀ᶠ q : ℕ in atTop,
      K * (q : ℝ) ^ degree * Real.exp (-a * (q : ℝ)) ≤
        min u (v * Real.exp (-b * (q : ℝ))) := by
  filter_upwards [eventually_nat_pow_mul_exp_neg_le K degree ha hu,
    eventually_nat_pow_mul_exp_neg_le_decay K degree hab hv] with q hq hq'
  exact le_min hq hq'

structure RecordParameterBounds (κ C c D : ℝ) (q : ℕ) : Prop where
  q_ge_eight : 8 ≤ q
  linear_le_pow_four : C * (q : ℝ) ≤ (q : ℝ) ^ 4
  pow_four_le_pow_six : (q : ℝ) ^ 4 ≤ (q : ℝ) ^ 6
  two_linear_le_pow_six : 2 * (C + 1) * (q : ℝ) ≤ (q : ℝ) ^ 6
  log_10000_le : Real.log 10000 ≤ 200 * κ * (q : ℝ) ^ 6
  log_two_div_le : Real.log 2 / (2 * (q : ℝ) ^ 6) ≤ κ
  growth : 24 * (q : ℝ) ^ 6 ≤ recordEta c q * (q : ℝ) *
    Real.exp (4 * recordGamma c * (q : ℝ))
  q_mul_eta_le_one : (q : ℝ) * recordEta c q ≤ 1
  near_le_kappa : recordNearError c D q ≤ κ / 100
  near_le_decay : recordNearError c D q ≤ recordDecay c q / 100
  eta_mul_near_le : recordEta c q * (q : ℝ) * recordNearError c D q ≤ 1 / 100
  bridge_error_le : 8 * (C + 1) * Real.exp (recordGamma c * (q : ℝ)) *
    recordEpsilon c D q ≤ min (κ / 100) (recordDecay c q / 100)
  dyadic_error_le : 6 * Real.exp (24 * recordGamma c * (q : ℝ)) *
    recordEpsilon c D q ≤ min (κ / 100) (recordDecay c q / 100)
  polynomial_error_le : 6 * (q : ℝ) ^ 6 * recordEpsilon c D q ≤
    min (κ / 100) (recordDecay c q / 100)
  polynomial_error_le_one : 6 * (q : ℝ) ^ 6 * recordEpsilon c D q ≤ 1
  seed_error_le : D * (q : ℝ) ^ 4 * Real.exp (-c * (q : ℝ)) ≤ κ / 100

theorem eventually_recordNearError_le {κ c D : ℝ} (hκ : 0 < κ) (hc : 0 < c) :
    ∀ᶠ q : ℕ in atTop,
      recordNearError c D q ≤ min (κ / 100) (recordDecay c q / 100) := by
  have hg : 0 < recordGamma c := recordGamma_pos hc
  have hgc : recordGamma c / 2 < c := by dsimp [recordGamma]; linarith
  have h₁ := eventually_nat_pow_mul_exp_neg_le_min D 6 hg (by linarith :
    recordGamma c / 2 < recordGamma c)
    (by positivity : 0 < κ / 200) (by norm_num : (0 : ℝ) < 1 / 200)
  have h₂ := eventually_nat_pow_mul_exp_neg_le_min D 0 hc hgc
    (by positivity : 0 < κ / 200) (by norm_num : (0 : ℝ) < 1 / 200)
  filter_upwards [h₁, h₂] with q hq₁ hq₂
  obtain ⟨h₁κ, h₁dec⟩ := le_min_iff.mp hq₁
  obtain ⟨h₂κ, h₂dec⟩ := le_min_iff.mp hq₂
  simp only [pow_zero, mul_one] at h₂κ h₂dec
  unfold recordNearError recordEta recordDecay
  apply le_min
  · linarith
  · linarith

private theorem record_exp_product (A B s a x : ℝ) :
    A * Real.exp (s * x) * (B * Real.exp (-a * x)) =
      (A * B) * Real.exp (-(a - s) * x) := by
  rw [show -(a - s) * x = s * x + -a * x by ring, Real.exp_add]
  ring

theorem eventually_record_bridge_error_le {κ C c D : ℝ}
    (hκ : 0 < κ) (hc : 0 < c) :
    ∀ᶠ q : ℕ in atTop,
      8 * (C + 1) * Real.exp (recordGamma c * (q : ℝ)) *
        recordEpsilon c D q ≤ min (κ / 100) (recordDecay c q / 100) := by
  have ha : 0 < c - recordGamma c := by dsimp [recordGamma]; linarith
  have hab : recordGamma c / 2 < c - recordGamma c := by
    dsimp [recordGamma]; linarith
  filter_upwards [eventually_nat_pow_mul_exp_neg_le_min (8 * (C + 1) * D) 0 ha hab
    (by positivity : 0 < κ / 100) (by norm_num : (0 : ℝ) < 1 / 100)] with q hq
  simpa only [recordEpsilon, record_exp_product, pow_zero, mul_one, recordDecay,
    div_eq_mul_inv, one_mul, mul_comm (100 : ℝ)⁻¹] using hq

theorem eventually_record_dyadic_error_le {κ c D : ℝ}
    (hκ : 0 < κ) (hc : 0 < c) :
    ∀ᶠ q : ℕ in atTop,
      6 * Real.exp (24 * recordGamma c * (q : ℝ)) * recordEpsilon c D q ≤
        min (κ / 100) (recordDecay c q / 100) := by
  have ha : 0 < c - 24 * recordGamma c := by dsimp [recordGamma]; linarith
  have hab : recordGamma c / 2 < c - 24 * recordGamma c := by
    dsimp [recordGamma]; linarith
  filter_upwards [eventually_nat_pow_mul_exp_neg_le_min (6 * D) 0 ha hab
    (by positivity : 0 < κ / 100) (by norm_num : (0 : ℝ) < 1 / 100)] with q hq
  simpa only [recordEpsilon, record_exp_product, pow_zero, mul_one, recordDecay,
    div_eq_mul_inv, one_mul, mul_comm (100 : ℝ)⁻¹] using hq

theorem eventually_record_polynomial_error_le {κ c D : ℝ}
    (hκ : 0 < κ) (hc : 0 < c) :
    ∀ᶠ q : ℕ in atTop,
      6 * (q : ℝ) ^ 6 * recordEpsilon c D q ≤
        min (κ / 100) (recordDecay c q / 100) := by
  have hab : recordGamma c / 2 < c := by dsimp [recordGamma]; linarith
  filter_upwards [eventually_nat_pow_mul_exp_neg_le_min (6 * D) 6 hc hab
    (by positivity : 0 < κ / 100) (by norm_num : (0 : ℝ) < 1 / 100)] with q hq
  simpa only [recordEpsilon, recordDecay, div_eq_mul_inv, one_mul, mul_comm (100 : ℝ)⁻¹,
    mul_assoc, mul_left_comm D] using hq

theorem eventually_record_growth {c : ℝ} (hc : 0 < c) :
    ∀ᶠ q : ℕ in atTop,
      24 * (q : ℝ) ^ 6 ≤ recordEta c q * (q : ℝ) *
        Real.exp (4 * recordGamma c * (q : ℝ)) := by
  have hg : 0 < recordGamma c := recordGamma_pos hc
  filter_upwards [eventually_nat_pow_mul_exp_neg_le 24 5
    (by positivity : 0 < 3 * recordGamma c) zero_lt_one] with q hq
  have heq : Real.exp (-(3 * recordGamma c) * (q : ℝ)) *
      Real.exp ((3 * recordGamma c) * (q : ℝ)) = 1 := by
    rw [← Real.exp_add]
    convert Real.exp_zero using 1
    ring
  calc
    24 * (q : ℝ) ^ 6 = (24 * (q : ℝ) ^ 5 *
        Real.exp (-(3 * recordGamma c) * (q : ℝ))) *
        ((q : ℝ) * Real.exp ((3 * recordGamma c) * (q : ℝ))) := by
      calc
        _ = 24 * (q : ℝ) ^ 6 * (Real.exp (-(3 * recordGamma c) * (q : ℝ)) *
            Real.exp ((3 * recordGamma c) * (q : ℝ))) := by rw [heq, mul_one]
        _ = _ := by ring
    _ ≤ (q : ℝ) * Real.exp ((3 * recordGamma c) * (q : ℝ)) := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right hq
        (show 0 ≤ (q : ℝ) * Real.exp ((3 * recordGamma c) * (q : ℝ)) by positivity)
    _ = _ := by
      unfold recordEta
      calc
        _ = (q : ℝ) * (Real.exp (-recordGamma c * (q : ℝ)) *
            Real.exp (4 * recordGamma c * (q : ℝ))) := by
          rw [← Real.exp_add]
          congr 2
          ring
        _ = _ := by ring

theorem eventually_record_q_mul_eta_le_one {c : ℝ} (hc : 0 < c) :
    ∀ᶠ q : ℕ in atTop, (q : ℝ) * recordEta c q ≤ 1 := by
  simpa only [one_mul, pow_one, recordEta] using
    eventually_nat_pow_mul_exp_neg_le 1 1 (recordGamma_pos hc) zero_lt_one

theorem eventually_recordParameterBounds {κ C c D : ℝ}
    (hκ : 0 < κ) (_hC : 0 < C) (hc : 0 < c) (hD : 0 < D) :
    ∀ᶠ q : ℕ in atTop, RecordParameterBounds κ C c D q := by
  have hg : 0 < recordGamma c := recordGamma_pos hc
  have hpow3 : Tendsto (fun q : ℕ => (q : ℝ) ^ 3) atTop atTop :=
    (tendsto_pow_atTop (by norm_num : (3 : ℕ) ≠ 0)).comp tendsto_natCast_atTop_atTop
  have hpow5 : Tendsto (fun q : ℕ => (q : ℝ) ^ 5) atTop atTop :=
    (tendsto_pow_atTop (by norm_num : (5 : ℕ) ≠ 0)).comp tendsto_natCast_atTop_atTop
  have hpow6 : Tendsto (fun q : ℕ => (q : ℝ) ^ 6) atTop atTop :=
    (tendsto_pow_atTop (by norm_num : (6 : ℕ) ≠ 0)).comp tendsto_natCast_atTop_atTop
  have hlog₁ : ∀ᶠ q : ℕ in atTop, Real.log 10000 ≤ 200 * κ * (q : ℝ) ^ 6 :=
    (hpow6.const_mul_atTop (by positivity : 0 < 200 * κ)).eventually
      (eventually_ge_atTop _)
  have hlog₂ : ∀ᶠ q : ℕ in atTop, Real.log 2 ≤ 2 * κ * (q : ℝ) ^ 6 :=
    (hpow6.const_mul_atTop (by positivity : 0 < 2 * κ)).eventually
      (eventually_ge_atTop _)
  filter_upwards [eventually_ge_atTop (8 : ℕ),
    hpow3.eventually (eventually_ge_atTop C),
    hpow5.eventually (eventually_ge_atTop (2 * (C + 1))), hlog₁, hlog₂,
    eventually_record_growth hc, eventually_record_q_mul_eta_le_one hc,
    eventually_recordNearError_le (D := D) hκ hc,
    eventually_record_bridge_error_le (C := C) (D := D) hκ hc,
    eventually_record_dyadic_error_le (D := D) hκ hc,
    eventually_record_polynomial_error_le (D := D) hκ hc,
    eventually_nat_pow_mul_exp_neg_le D 4 hc (by positivity : 0 < κ / 100)]
    with q hq8 hC3 hC5 hlog1 hlog2 hgrowth hqeta hnear hbridge hdyadic hpoly hseed
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast (show 1 ≤ q by omega)
  have hqpos : (0 : ℝ) < q := lt_of_lt_of_le zero_lt_one hq1
  have hCq : C * (q : ℝ) ≤ (q : ℝ) ^ 4 := by
    calc
      _ ≤ (q : ℝ) ^ 3 * (q : ℝ) := mul_le_mul_of_nonneg_right hC3 hqpos.le
      _ = _ := by ring
  have htwoq : 2 * (C + 1) * (q : ℝ) ≤ (q : ℝ) ^ 6 := by
    calc
      _ ≤ (q : ℝ) ^ 5 * (q : ℝ) := mul_le_mul_of_nonneg_right hC5 hqpos.le
      _ = _ := by ring
  have hlogtwo : Real.log 2 / (2 * (q : ℝ) ^ 6) ≤ κ := by
    apply (div_le_iff₀ (by positivity : 0 < 2 * (q : ℝ) ^ 6)).mpr
    linarith only [hlog2]
  have hdecay : recordDecay c q ≤ 1 := by
    unfold recordDecay
    calc
      _ ≤ Real.exp 0 := Real.exp_le_exp.mpr (by
        exact mul_nonpos_of_nonpos_of_nonneg (by linarith only [hg]) hqpos.le)
      _ = 1 := Real.exp_zero
  obtain ⟨hnearκ, hneardec⟩ := le_min_iff.mp hnear
  have hnear1 : recordNearError c D q ≤ 1 / 100 := by
    have hd := div_le_div_of_nonneg_right hdecay (by norm_num : (0 : ℝ) ≤ 100)
    exact hneardec.trans hd
  have hnear0 : 0 ≤ recordNearError c D q := by
    unfold recordNearError recordEta
    positivity
  have hηnear : recordEta c q * (q : ℝ) * recordNearError c D q ≤ 1 / 100 := by
    calc
      _ = ((q : ℝ) * recordEta c q) * recordNearError c D q := by ring
      _ ≤ 1 * recordNearError c D q := mul_le_mul_of_nonneg_right hqeta hnear0
      _ ≤ 1 / 100 := by simpa only [one_mul] using hnear1
  have hpoly1 : 6 * (q : ℝ) ^ 6 * recordEpsilon c D q ≤ 1 := by
    have hpdec := (le_min_iff.mp hpoly).2
    have hd := div_le_div_of_nonneg_right hdecay (by norm_num : (0 : ℝ) ≤ 100)
    linarith only [hpdec, hd]
  exact ⟨hq8, hCq, pow_le_pow_right₀ hq1 (by norm_num : (4 : ℕ) ≤ 6),
    htwoq, hlog1, hlogtwo, hgrowth, hqeta, hnearκ, hneardec, hηnear,
    hbridge, hdyadic, hpoly, hpoly1, hseed⟩

theorem exists_recordParameterBounds {κ C c D : ℝ}
    (hκ : 0 < κ) (hC : 0 < C) (hc : 0 < c) (hD : 0 < D) :
    ∃ Q : ℕ, ∀ q : ℕ, Q ≤ q → RecordParameterBounds κ C c D q :=
  eventually_atTop.mp (eventually_recordParameterBounds hκ hC hc hD)

end UAMO.CMV

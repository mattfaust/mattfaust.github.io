import UAMO.CMVRecordRounding
import UAMO.UAMONearPeriodicPropagation
import UAMO.CMVRecordTransitionScalar

noncomputable section
set_option maxHeartbeats 1000000
open MeasureTheory Set
namespace UAMO.CMV

theorem record_initial_scale_data {B κ C c : ℝ} (hκ : 0 < κ)
    {q N : ℕ} (hs : RecordTransitionScalar B κ C c q) (hNlo : q ^ 6 ≤ N) :
    0 < N ∧ C * (q : ℝ) ≤ (N : ℝ) ∧
      Real.log 10000 ≤ 200 * κ * (N : ℝ) ∧ Real.log 2 / (2 * (N : ℝ)) ≤ κ := by
  have hq : 0 < q := hs.positive
  have hN : 0 < N := (pow_pos hq 6).trans_le hNlo
  have hq0 : (0 : ℝ) ≤ q := Nat.cast_nonneg q
  have hlo : (q : ℝ) ^ 6 ≤ N := by exact_mod_cast hNlo
  have hNC : C * (q : ℝ) ≤ N := by
    have hpoly := hs.polynomial
    nlinarith
  refine ⟨hN, hNC, ?_, ?_⟩
  · exact hs.scale.trans (mul_le_mul_of_nonneg_left hlo (by positivity))
  · exact (div_le_div_of_nonneg_left (Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 2))
      (by positivity : (0 : ℝ) < 2 * (q : ℝ) ^ 6)
      (by linarith : 2 * (q : ℝ) ^ 6 ≤ 2 * (N : ℝ))).trans hs.gap

theorem recordTransition_ordinary
    (A:ℝ→TransferMatrix) {K:ℝ} (hA:TransferCircleBounds A K)
    (hdet:∀x,(A x).det=1) (α:ℝ)
    {κ C c : ℝ} (hκ : 0 < κ) (hc : 0 < c)
    (hCκ : c / (100 * κ) ≤ C)
    {q p N : ℕ} (hs : RecordTransitionScalar (Real.log K) κ C c q) (hqp : q < p)
    (hNlo : q ^ 6 ≤ N) (hNhi : N ≤ 3 * q ^ 6)
    (hL : 2000 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hd : recordGap A α N ≤ κ / 100)
    (hbad : RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c q)
    (hshort : (p : ℝ) ≤ Real.exp (4 * (c / 1000) * (q : ℝ))) :
    ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      finiteLyapunov A (2*Real.pi*α) N - 6 * recordGap A α N -
          Real.exp (-(c / 2000) * (q : ℝ)) - 2 * Real.log K / (p : ℝ) ^ 5 ≤
        finiteLyapunov A (2*Real.pi*α) R ∧
      (R : ℝ) * recordGap A α R ≤ (N : ℝ) * recordGap A α N +
        (3 + 9 * Real.log K) * (p : ℝ) := by
  obtain ⟨hN, hNC, hscale, _⟩ := record_initial_scale_data hκ hs hNlo
  have hq : 0 < q := hs.positive
  have hp : 0 < p := hq.trans hqp
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hpr : (1 : ℝ) ≤ p := by exact_mod_cast hp
  let ε : ℝ := recordErrorConstant (Real.log K) * Real.exp (-c * (q : ℝ))
  let τ : ℝ := Real.exp (-(c / 2000) * (q : ℝ))
  have hε : 0 ≤ ε := by dsimp only [ε]; exact mul_nonneg (recordErrorConstant_pos (Real.log K) (Real.log_nonneg hA.one_le)).le (Real.exp_pos _).le
  have hτ0 : 0 ≤ τ := (Real.exp_pos _).le
  have hτ1 : τ ≤ 1 := by
    apply Real.exp_le_one_iff.mpr
    have hqr : (0 : ℝ) ≤ q := Nat.cast_nonneg q
    nlinarith [hc]
  have hpower : (p : ℝ) ^ 6 ≤ Real.exp (24 * (c / 1000) * (q : ℝ)) := by
    calc
      _ ≤ (Real.exp (4 * (c / 1000) * (q : ℝ))) ^ 6 := by gcongr
      _ = _ := by rw [← Real.exp_nat_mul]; congr 1; ring
  have hsmall : 6 * (p : ℝ) ^ 6 * ε ≤ min (κ / 100) (τ / 100) := by
    exact (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpower (by norm_num : (0 : ℝ) ≤ 6)) hε).trans hs.ordinary_small
  have hsmallκ : 6 * (p : ℝ) ^ 6 * ε ≤ κ / 100 := hsmall.trans (min_le_left _ _)
  have hsmallτ : 6 * (p : ℝ) ^ 6 * ε ≤ τ / 100 := hsmall.trans (min_le_right _ _)
  have hmax : ((max N (2 * p ^ 6) : ℕ) : ℝ) ≤ 3 * (p : ℝ) ^ 6 := by
    have hqpow : q ^ 6 ≤ p ^ 6 := Nat.pow_le_pow_left hqp.le 6
    have hnat : max N (2 * p ^ 6) ≤ 3 * p ^ 6 := max_le (by omega) (by omega)
    exact_mod_cast hnat
  have hH : ((max N (2 * p ^ 6) : ℕ) : ℝ) ≤ 3 * (p : ℝ) ^ 6 * (N : ℝ) := by
    have ht := mul_le_mul_of_nonneg_left hNr (show 0 ≤ 3 * (p : ℝ) ^ 6 by positivity)
    nlinarith
  obtain ⟨P, hPT, hNP, hPmax, hLP, hwP, hdP⟩ := finiteLyapunov_dyadic_to_target
    A hA.continuous hA.periodic hdet (Real.log K) (Real.log_nonneg hA.one_le)
    (transferLogNorm_bound_length A hA) α N (p ^ 6) hN hκ (Real.exp_pos _).le hscale (by linarith)
    (by unfold recordGap at hd ⊢; linarith)
    (fun M hNM => (hbad M (hNC.trans (by exact_mod_cast hNM))).1)
    (record_dyadic_error_le (Real.log K) (Real.log_nonneg hA.one_le) hκ hCκ hq hN hNC) hH
    (by nlinarith : (3 * (p : ℝ) ^ 6) * ε ≤ κ)
  change finiteLyapunov A (2*Real.pi*α) N - 2 * recordGap A α N -
    2 * (3 * (p : ℝ) ^ 6) * ε ≤ finiteLyapunov A (2*Real.pi*α) P at hLP
  change (P : ℝ) * recordGap A α P ≤
    (N : ℝ) * recordGap A α N + 2 * (P : ℝ) * ε at hwP
  obtain ⟨R, hRd, hPR, hRT, hRmax, hLR, hwR⟩ :=
    finiteLyapunov_record_rounding A hA (2*Real.pi*α) hq hqp hNhi hPT hPmax
  change (R:ℝ)*recordGap A α R≤(P:ℝ)*recordGap A α P+9*Real.log K*(p:ℝ) at hwR
  have hPmaxR : (P : ℝ) ≤ ((max N (2 * p ^ 6) : ℕ) : ℝ) := by exact_mod_cast hPmax
  have hPbound : (P : ℝ) ≤ 3 * (p : ℝ) ^ 6 := hPmaxR.trans hmax
  have hwe : 2 * (P : ℝ) * ε ≤ τ / 100 := by
    have ht := mul_le_mul_of_nonneg_right hPbound hε
    nlinarith
  have hd0 := recordGap_nonneg A hA.continuous hA.periodic hdet α N
  refine ⟨R, hRd, hNP.trans hPR, hRT, hRmax, ?_, ?_⟩
  · change finiteLyapunov A (2*Real.pi*α) N - 6 * recordGap A α N - τ -
      2 * Real.log K / (p : ℝ) ^ 5 ≤ finiteLyapunov A (2*Real.pi*α) R
    linarith only [hLR, hLP, hsmallτ, hτ0, hd0]
  · nlinarith only [hwR, hwP, hwe, hτ1, hpr]

end UAMO.CMV

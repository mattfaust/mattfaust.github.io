import UAMO.CMVRecordTransitionSteps

noncomputable section
namespace UAMO.CMV

def recordErrorConstant (B:ℝ) : ℝ := 10000 * (1 + B)

theorem recordErrorConstant_pos (B:ℝ) (hB:0≤B) : 0 < recordErrorConstant B := by
  unfold recordErrorConstant
  positivity

theorem record_dyadic_error_le (B:ℝ) (hB:0≤B)
    {κ C c : ℝ} (hκ : 0 < κ)
    (hCκ : c / (100 * κ) ≤ C)
    {q N : ℕ} (hq : 0 < q) (hN : 0 < N) (hNC : C * (q : ℝ) ≤ N) :
    dyadicPropagationError B N κ (Real.exp (-c * (q : ℝ))) ≤
      recordErrorConstant B * Real.exp (-c * (q : ℝ)) := by
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hqr : (0 : ℝ) < q := by exact_mod_cast hq
  have hcC : c ≤ C * (100 * κ) := (div_le_iff₀ (by positivity)).mp hCκ
  have he : c * (q : ℝ) ≤ 200 * κ * (N : ℝ) := by
    have h1 := mul_le_mul_of_nonneg_right hcC hqr.le
    have h2 := mul_le_mul_of_nonneg_left hNC (show 0 ≤ 100 * κ by positivity)
    nlinarith [mul_nonneg hκ.le (Nat.cast_nonneg N : (0 : ℝ) ≤ N)]
  have hden : Real.exp (c * (q : ℝ)) ≤ (N : ℝ) * Real.exp (200 * κ * (N : ℝ)) := by
    exact (Real.exp_le_exp.mpr he).trans
      (by nlinarith [Real.exp_pos (200 * κ * (N : ℝ))])
  have hap : 4000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) ≤
      4000 * Real.exp (-c * (q : ℝ)) := by
    calc
      _ ≤ 4000 / Real.exp (c * (q : ℝ)) :=
        div_le_div_of_nonneg_left (by norm_num) (Real.exp_pos _) hden
      _ = _ := by rw [div_eq_mul_inv, ← Real.exp_neg]; congr 2; ring
  have hδ := Real.exp_pos (-c * (q : ℝ))
  unfold dyadicPropagationError recordErrorConstant
  nlinarith [mul_nonneg hB hδ.le]

theorem record_near_error_le
    (A:ℝ→TransferMatrix) (α B:ℝ) (hB:0≤B)
    {κ C c η : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hCκ : c / (100 * κ) ≤ C)
    {q N : ℕ} (hq : 0 < q) (hN : 0 < N) (hNC : C * (q : ℝ) ≤ N)
    (hNhi : N ≤ 3 * q ^ 6)
    (hL : 800 * κ ≤ finiteLyapunov A (2*Real.pi*α) N) :
    1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
      4 * B * Real.exp (-c * (q : ℝ)) +
      192 * B * (N : ℝ) * η ≤
        recordErrorConstant B * ((q : ℝ) ^ 6 * η + Real.exp (-c * (q : ℝ))) := by
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hexp : 200 * κ * (N : ℝ) ≤ (N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2 := by
    have h := mul_le_mul_of_nonneg_left hL hNr.le
    nlinarith
  have hden : (N : ℝ) * Real.exp (200 * κ * (N : ℝ)) ≤
      (N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2) :=
    mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hexp) hNr.le
  have hap : 1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) ≤
      4000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) := by
    calc
      _ ≤ 1000 / ((N : ℝ) * Real.exp (200 * κ * (N : ℝ))) :=
        div_le_div_of_nonneg_left (by norm_num) (by positivity) hden
      _ ≤ _ := div_le_div_of_nonneg_right (by norm_num) (by positivity)
  have hd := record_dyadic_error_le B hB hκ hCκ hq hN hNC
  have hNhiR : (N : ℝ) ≤ 3 * (q : ℝ) ^ 6 := by exact_mod_cast hNhi
  have hNη := mul_le_mul_of_nonneg_right hNhiR hη
  have hNηB := mul_le_mul_of_nonneg_left hNη hB
  have hδB := mul_nonneg hB (Real.exp_pos (-c * (q : ℝ))).le
  have hqη := mul_nonneg (pow_nonneg (Nat.cast_nonneg q : (0 : ℝ) ≤ q) 6) hη
  unfold dyadicPropagationError recordErrorConstant at hd
  unfold recordErrorConstant
  nlinarith [mul_nonneg hB hqη]

end UAMO.CMV

import UAMO.CMVRecordParameters
import UAMO.CMVRecordTransitionScalar

noncomputable section
namespace UAMO.CMV

theorem recordParameterBounds_to_transitionScalar
    {B κ C c : ℝ} {q : ℕ}
    (h : RecordParameterBounds κ C c (recordErrorConstant B) q) :
    RecordTransitionScalar B κ C c q := by
  have hgamma : (c / 1000) / 2 = c / 2000 := by ring
  refine ⟨by have := h.q_ge_eight; omega,
    h.two_linear_le_pow_six, h.log_10000_le, h.log_two_div_le, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simpa only [recordEta, recordGamma] using h.q_mul_eta_le_one
  · simpa only [recordEta, recordGamma] using h.growth
  · simpa only [recordNearError, recordEta, recordDecay, recordGamma, hgamma]
      using le_min h.near_le_kappa h.near_le_decay
  · simpa only [recordNearError, recordEta, recordGamma] using h.eta_mul_near_le
  · simpa only [recordEpsilon, recordDecay, recordGamma, hgamma] using h.bridge_error_le
  · simpa only [recordEpsilon, recordDecay, recordGamma, hgamma] using h.dyadic_error_le
  · simpa only [recordEpsilon, recordDecay, recordGamma, hgamma] using h.polynomial_error_le

theorem exists_recordTransitionScalar {B κ C c : ℝ}
    (hB:0≤B) (hκ : 0 < κ) (hC : 0 < C) (hc : 0 < c) :
    ∃ Q : ℕ, ∀ q : ℕ, Q ≤ q → RecordTransitionScalar B κ C c q := by
  obtain ⟨Q, hQ⟩ := exists_recordParameterBounds hκ hC hc (recordErrorConstant_pos B hB)
  exact ⟨Q, fun q hq => recordParameterBounds_to_transitionScalar (hQ q hq)⟩

end UAMO.CMV

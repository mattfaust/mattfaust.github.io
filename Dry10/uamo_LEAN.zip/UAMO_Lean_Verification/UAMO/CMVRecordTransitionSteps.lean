import UAMO.CMVDyadicPropagation
import UAMO.CMVNearPeriodicStep

noncomputable section
open MeasureTheory Set
namespace UAMO.CMV

def recordGap (A:ℝ→TransferMatrix) (α:ℝ) (N : ℕ) : ℝ :=
  finiteLyapunov A (2*Real.pi*α) N - finiteLyapunov A (2*Real.pi*α) (2 * N)

theorem recordGap_nonneg (A:ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,(A x).det=1) (α:ℝ) (N : ℕ) :
    0 ≤ recordGap A α N :=
  sub_nonneg.mpr (finiteLyapunov_double_le A hc hp hd α N)

theorem exists_dyadic_multiple_near_target (N T : ℕ) (hN : 0 < N) :
    ∃ r : ℕ, T ≤ 2 ^ r * N ∧ N ≤ 2 ^ r * N ∧
      2 ^ r * N ≤ max N (2 * T) ∧ r ≤ 2 ^ r := by
  have hex : ∃ r : ℕ, T ≤ 2 ^ r * N := by
    refine ⟨T, (show T < 2 ^ T from Nat.lt_two_pow_self).le.trans ?_⟩
    simpa only [Nat.succ_eq_add_one, zero_add, mul_one] using Nat.mul_le_mul_left (2 ^ T) hN
  let r := Nat.find hex
  have hr : T ≤ 2 ^ r * N := Nat.find_spec hex
  have hupper : 2 ^ r * N ≤ max N (2 * T) := by
    cases hr0 : r with
    | zero => simp only [hr0, pow_zero, one_mul]; exact le_max_left _ _
    | succ s =>
      have hs : ¬ T ≤ 2 ^ s * N := Nat.find_min hex (by omega)
      have hlt : 2 ^ s * N < T := Nat.lt_of_not_ge hs
      calc
        2 ^ (s + 1) * N = 2 * (2 ^ s * N) := by rw [pow_succ]; ring
        _ ≤ 2 * T := Nat.mul_le_mul_left 2 hlt.le
        _ ≤ _ := le_max_right _ _
  refine ⟨r, hr, ?_, hupper, (show r < 2 ^ r from Nat.lt_two_pow_self).le⟩
  simpa only [one_mul] using Nat.mul_le_mul_right N
    (one_le_pow₀ (by norm_num : 1 ≤ (2 : ℕ)))

theorem finiteLyapunov_dyadic_to_target
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,(A x).det=1) (B:ℝ) (hB:0≤B)
    (hlinear:∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B) (α:ℝ) (N T : ℕ) (hN : 0 < N)
    {κ δ ε H : ℝ} (hκ : 0 < κ) (hδ : 0 ≤ δ)
    (hscale : Real.log 10000 ≤ 200 * κ * (N : ℝ))
    (hinitial : 1000 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hpair : recordGap A α N ≤ finiteLyapunov A (2*Real.pi*α) N / 20)
    (hbad : ∀ M, N ≤ M → (volume.restrict (Ioc (0 : ℝ) 1)).real
      (avalancheBaseBadSet A α M κ) ≤ δ)
    (herr : dyadicPropagationError B N κ δ ≤ ε)
    (hH : ((max N (2 * T) : ℕ) : ℝ) ≤ H * (N : ℝ))
    (hbudget : H * ε ≤ κ) :
    ∃ P : ℕ, T ≤ P ∧ N ≤ P ∧ P ≤ max N (2 * T) ∧
      finiteLyapunov A (2*Real.pi*α) N - 2 * recordGap A α N - 2 * H * ε ≤
        finiteLyapunov A (2*Real.pi*α) P ∧
      (P : ℝ) * recordGap A α P ≤
        (N : ℝ) * recordGap A α N + 2 * (P : ℝ) * ε ∧
      recordGap A α P ≤ recordGap A α N + 2 * ε := by
  obtain ⟨r, hrT, hrN, hrupper, hrr⟩ := exists_dyadic_multiple_near_target N T hN
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hε : 0 ≤ ε := (dyadicPropagationError_nonneg B hB N hδ).trans herr
  have hH1 : 1 ≤ H := by
    have hmax : (N : ℝ) ≤ ((max N (2 * T) : ℕ) : ℝ) := by
      exact_mod_cast le_max_left N (2 * T)
    nlinarith
  have hrH : (r : ℝ) ≤ H := by
    have h1 : (r : ℝ) * (N : ℝ) ≤ ((2 ^ r * N : ℕ) : ℝ) := by
      exact_mod_cast Nat.mul_le_mul_right N hrr
    have h2 : ((2 ^ r * N : ℕ) : ℝ) ≤ ((max N (2 * T) : ℕ) : ℝ) := by
      exact_mod_cast hrupper
    nlinarith
  have herror : dyadicPropagationError B N κ δ ≤ κ := by
    have h := mul_le_mul_of_nonneg_right hH1 hε
    linarith
  have hrerr : (r : ℝ) * dyadicPropagationError B N κ δ ≤ κ := by
    calc
      _ ≤ (r : ℝ) * ε := mul_le_mul_of_nonneg_left herr (Nat.cast_nonneg r)
      _ ≤ H * ε := mul_le_mul_of_nonneg_right hrH hε
      _ ≤ _ := hbudget
  obtain ⟨hlower, _, hdrop, _, _, _⟩ := finiteLyapunov_dyadic_propagation
    A hc hp hd B hB hlinear α N hN hκ hδ hscale hinitial hpair hbad herror r hrerr
  have hsucc : 2 ^ (r + 1) * N = 2 * (2 ^ r * N) := by rw [pow_succ]; ring
  rw [hsucc] at hdrop
  change recordGap A α (2 ^ r * N) ≤
    (1 / 2 : ℝ) ^ r * recordGap A α N +
      2 * dyadicPropagationError B N κ δ at hdrop
  have hrε : (r : ℝ) * dyadicPropagationError B N κ δ ≤ H * ε := by
    exact (mul_le_mul_of_nonneg_left herr (Nat.cast_nonneg r)).trans
      (mul_le_mul_of_nonneg_right hrH hε)
  refine ⟨2 ^ r * N, hrT, hrN, hrupper, by dsimp only [recordGap] at *; linarith, ?_, ?_⟩
  · have hw := mul_le_mul_of_nonneg_left hdrop
      (Nat.cast_nonneg (2 ^ r * N) : (0 : ℝ) ≤ (2 ^ r * N : ℕ))
    have hcancel : ((2 ^ r * N : ℕ) : ℝ) * (1 / 2 : ℝ) ^ r = N := by
      push_cast
      calc
        (2 : ℝ) ^ r * (N : ℝ) * (1 / 2 : ℝ) ^ r =
            (2 * (1 / 2 : ℝ)) ^ r * (N : ℝ) := by rw [mul_pow]; ring
        _ = _ := by norm_num
    rw [mul_add, ← mul_assoc, hcancel] at hw
    have he := mul_le_mul_of_nonneg_left herr
      (show 0 ≤ 2 * ((2 ^ r * N : ℕ) : ℝ) by positivity)
    nlinarith
  · have hpow : (1 / 2 : ℝ) ^ r ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
    have ht := mul_le_mul_of_nonneg_right hpow (recordGap_nonneg A hc hp hd α N)
    linarith

theorem finiteLyapunov_nearPeriodic_blocks
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,(A x).det=1) (B:ℝ) (hB:0≤B)
    (hlinear:∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B)
    (hhull:FrobeniusHullBound A hc hp (fun x => by rw [hd x,norm_one])) (α:ℝ) (N m : ℕ) (hN : 0 < N) (hm : 2 ≤ m)
    (a : ℤ) (q : ℕ) (hq : 0 < q) (hqN : q ∣ N)
    {κ η δ E : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hnear : (((m * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hL : 800 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hL2 : (9 / 10 : ℝ) * finiteLyapunov A (2*Real.pi*α) N ≤ finiteLyapunov A (2*Real.pi*α) (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)
    (hbadN : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) N (finiteLyapunov A (2*Real.pi*α) N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) (2 * N) (finiteLyapunov A (2*Real.pi*α) (2 * N)) κ) ≤ δ)
    (herr : 1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
      4 * B * δ +
      192 * B * (N : ℝ) * η ≤ E) :
    |finiteLyapunov A (2*Real.pi*α) (m * N) - finiteLyapunov A (2*Real.pi*α) N +
      2 * (1 - 1 / (m : ℝ)) * recordGap A α N| ≤ E := by
  have hmidx : m - 2 + 2 = m := Nat.sub_add_cancel hm
  have h := finiteLyapunov_nearPeriodic_step A hc hp (fun x => by rw [hd x,norm_one]) hd hhull B hB hlinear α N (m - 2) hN a q hq hqN
    hκ hη (by simpa only [hmidx] using hnear) hgap hL hL2 hscale hbadN hbad2N
  simp only [hmidx] at h
  have heq : finiteLyapunov A (2*Real.pi*α) (m * N) +
      (1 - 2 / (m : ℝ)) * finiteLyapunov A (2*Real.pi*α) N -
      2 * (1 - 1 / (m : ℝ)) * finiteLyapunov A (2*Real.pi*α) (2 * N) =
      finiteLyapunov A (2*Real.pi*α) (m * N) - finiteLyapunov A (2*Real.pi*α) N +
        2 * (1 - 1 / (m : ℝ)) * recordGap A α N := by
    unfold recordGap
    ring
  rw [heq] at h
  exact h.trans herr

theorem finiteLyapunov_nearPeriodic_pair
    (A:ℝ→TransferMatrix) (hc:Continuous A) (hp:Function.Periodic A (2*Real.pi))
    (hd:∀x,(A x).det=1) (B:ℝ) (hB:0≤B)
    (hlinear:∀ω x:ℝ,∀n:ℕ,transferLogNorm A ω x n≤(n:ℝ)*B)
    (hhull:FrobeniusHullBound A hc hp (fun x => by rw [hd x,norm_one])) (α:ℝ) (N m : ℕ) (hN : 0 < N) (hm : 2 ≤ m)
    (a : ℤ) (q : ℕ) (hq : 0 < q) (hqN : q ∣ N)
    {κ η δ E : ℝ} (hκ : 0 < κ) (hη : 0 ≤ η)
    (hnear : ((((2 * m) * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η)
    (hgap : Real.log 2 / (2 * (N : ℝ)) ≤ κ)
    (hL : 800 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hL2 : (9 / 10 : ℝ) * finiteLyapunov A (2*Real.pi*α) N ≤ finiteLyapunov A (2*Real.pi*α) (2 * N))
    (hscale : Real.log 10000 ≤ (N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)
    (hbadN : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) N (finiteLyapunov A (2*Real.pi*α) N) κ) ≤ δ)
    (hbad2N : AddCircle.haarAddCircle.real
      (finiteFrobeniusBadSet A hc hp (fun x => by rw [hd x,norm_one]) (2*Real.pi*α) (2 * N) (finiteLyapunov A (2*Real.pi*α) (2 * N)) κ) ≤ δ)
    (herr : 1000 / ((N : ℝ) * Real.exp ((N : ℝ) * finiteLyapunov A (2*Real.pi*α) N / 2)) +
      4 * B * δ +
      192 * B * (N : ℝ) * η ≤ E) :
    finiteLyapunov A (2*Real.pi*α) N - 2 * recordGap A α N - E ≤
      finiteLyapunov A (2*Real.pi*α) (m * N) ∧
    recordGap A α (m * N) ≤ recordGap A α N / (m : ℝ) + 2 * E ∧
    ((m * N : ℕ) : ℝ) * recordGap A α (m * N) ≤
      (N : ℝ) * recordGap A α N + 2 * ((m * N : ℕ) : ℝ) * E := by
  have hnear1 : (((m * N : ℕ) : ℝ)) * |α - (a : ℝ) / (q : ℝ)| ≤ η := by
    have hmul : (((m * N : ℕ) : ℝ)) ≤ (((2 * m * N : ℕ) : ℝ)) := by
      exact_mod_cast Nat.mul_le_mul_right N (show m ≤ 2 * m by omega)
    exact (mul_le_mul_of_nonneg_right hmul (abs_nonneg _)).trans hnear
  have h1 := finiteLyapunov_nearPeriodic_blocks A hc hp hd B hB hlinear hhull α N m hN hm a q hq hqN
    hκ hη hnear1 hgap hL hL2 hscale hbadN hbad2N herr
  have h2 := finiteLyapunov_nearPeriodic_blocks A hc hp hd B hB hlinear hhull α N (2 * m) hN (by omega)
    a q hq hqN hκ hη hnear hgap hL hL2 hscale hbadN hbad2N herr
  have hmr : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hcoef : 2 * (1 - 1 / ((2 * m : ℕ) : ℝ)) - 2 * (1 - 1 / (m : ℝ)) =
      1 / (m : ℝ) := by push_cast; field_simp [hmr.ne']; ring
  have hidx : 2 * m * N = 2 * (m * N) := by ring
  rw [hidx] at h2
  have hdrop : recordGap A α (m * N) ≤ recordGap A α N / (m : ℝ) + 2 * E := by
    have hc := congrArg (fun t : ℝ => t * recordGap A α N) hcoef
    dsimp only at hc
    dsimp only [recordGap]
    dsimp only [recordGap] at h1 h2 hc
    rw [sub_mul] at hc
    simp only [div_eq_mul_inv, one_mul] at h1 h2 hc ⊢
    nlinarith only [hc, (abs_le.mp h1).2, (abs_le.mp h2).1]
  refine ⟨?_, hdrop, ?_⟩
  · have hnonneg := div_nonneg (recordGap_nonneg A hc hp hd α N) hmr.le
    have hcoef1 : 2 * (1 - 1 / (m : ℝ)) * recordGap A α N =
        2 * recordGap A α N - 2 * (recordGap A α N / (m : ℝ)) := by ring
    rw [hcoef1] at h1
    linarith [(abs_le.mp h1).1]
  · have hw := mul_le_mul_of_nonneg_left hdrop
      (Nat.cast_nonneg (m * N) : (0 : ℝ) ≤ ((m * N : ℕ) : ℝ))
    have hcancel : ((m * N : ℕ) : ℝ) * (recordGap A α N / (m : ℝ)) =
        (N : ℝ) * recordGap A α N := by push_cast; field_simp; ring
    rw [mul_add, hcancel] at hw
    nlinarith

end UAMO.CMV

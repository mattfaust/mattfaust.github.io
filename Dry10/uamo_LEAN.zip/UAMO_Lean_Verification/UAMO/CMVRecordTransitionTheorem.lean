import UAMO.CMVRecordTransitionLong
import UAMO.CMVRecordTransitionParameterBridge

noncomputable section
namespace UAMO.CMV

def recordTransitionConstant (B:ℝ) : ℝ := 10 * (1+B)

theorem recordTransitionConstant_pos (B:ℝ) (hB:0≤B) : 0 < recordTransitionConstant B := by
  unfold recordTransitionConstant
  positivity

theorem finiteLyapunov_record_transition_of_scalar_bounds
    (A:ℝ→TransferMatrix) {K:ℝ} (hA:TransferCircleBounds A K)
    (hdet:∀x,(A x).det=1) (hhull:FrobeniusHullBound A hA.continuous hA.periodic hA.determinant) (α:ℝ)
    {κ C c : ℝ} (hκ : 0 < κ) (hC : 1 ≤ C) (hc : 0 < c)
    (hCκ : c / (100 * κ) ≤ C)
    {q p N : ℕ} (hs : RecordTransitionScalar (Real.log K) κ C c q)
    (hpScalar : RecordTransitionScalar (Real.log K) κ C c p) (hqp : q < p)
    (hNlo : q ^ 6 ≤ N) (hNhi : N ≤ 3 * q ^ 6) (hqN : q ∣ N)
    (a : ℤ) (happrox : |α - (a : ℝ) / (q : ℝ)| ≤ 1 / ((q : ℝ) * (p : ℝ)))
    (hL : 2000 * κ ≤ finiteLyapunov A (2*Real.pi*α) N)
    (hd : recordGap A α N ≤ κ / 100)
    (hbadq : RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c q)
    (hbadp : RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c p) :
    ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      finiteLyapunov A (2*Real.pi*α) N - 6 * recordGap A α N -
          Real.exp (-(c / 2000) * (q : ℝ)) - recordTransitionConstant (Real.log K) / (p : ℝ) ^ 5 ≤
        finiteLyapunov A (2*Real.pi*α) R ∧
      (R : ℝ) * recordGap A α R ≤ (N : ℝ) * recordGap A α N +
        recordTransitionConstant (Real.log K) * (p : ℝ) := by
  have hstep : ∃ R : ℕ, p ∣ R ∧ N ≤ R ∧ p ^ 6 ≤ R ∧ R ≤ 3 * p ^ 6 ∧
      finiteLyapunov A (2*Real.pi*α) N - 6 * recordGap A α N -
          Real.exp (-(c / 2000) * (q : ℝ)) - 2 * Real.log K / (p : ℝ) ^ 5 ≤
        finiteLyapunov A (2*Real.pi*α) R ∧
      (R : ℝ) * recordGap A α R ≤ (N : ℝ) * recordGap A α N +
        (3 + 9 * Real.log K) * (p : ℝ) := by
    rcases le_or_gt (p : ℝ) (Real.exp (4 * (c / 1000) * (q : ℝ))) with hshort | hlong
    · exact recordTransition_ordinary A hA hdet α hκ hc hCκ hs hqp hNlo hNhi hL hd hbadq hshort
    · exact recordTransition_long A hA hdet hhull α hκ hC hc hCκ hs hpScalar hqp hNlo hNhi hqN
        a happrox hL hd hbadq hbadp hlong
  obtain ⟨R, hRd, hNR, hRT, hRmax, hLR, hwR⟩ := hstep
  have hlog : 0≤Real.log K := Real.log_nonneg hA.one_le
  have hAB : 2 * Real.log K ≤ recordTransitionConstant (Real.log K) := by
    unfold recordTransitionConstant
    linarith
  have hAw : 3 + 9 * Real.log K ≤ recordTransitionConstant (Real.log K) := by
    unfold recordTransitionConstant
    linarith
  have htail := div_le_div_of_nonneg_right hAB
    (pow_nonneg (Nat.cast_nonneg p : (0 : ℝ) ≤ p) 5)
  have hwA := mul_le_mul_of_nonneg_right hAw (Nat.cast_nonneg p : (0 : ℝ) ≤ p)
  exact ⟨R, hRd, hNR, hRT, hRmax, by linarith, by linarith⟩

theorem finiteLyapunov_record_transition {K κ C c:ℝ} (hK:1≤K)
    (hκ:0<κ) (hC:1≤C) (hc:0<c) (hCκ:c/(100*κ)≤C) :
    ∃Q:ℕ,∀(A:ℝ→TransferMatrix)(hA:TransferCircleBounds A K), (∀x,(A x).det=1) →
      FrobeniusHullBound A hA.continuous hA.periodic hA.determinant →
      ∀(α:ℝ)(q p N:ℕ)(a:ℤ),Q≤q → q<p →
      q^6≤N → N≤3*q^6 → q∣N →
      |α-(a:ℝ)/(q:ℝ)|≤1/((q:ℝ)*(p:ℝ)) →
      2000*κ≤finiteLyapunov A (2*Real.pi*α) N →
      recordGap A α N≤κ/100 →
      RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c q →
      RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c p →
      ∃R:ℕ,p∣R ∧ N≤R ∧ p^6≤R ∧ R≤3*p^6 ∧
        finiteLyapunov A (2*Real.pi*α) N-6*recordGap A α N-
          Real.exp (-(c/2000)*(q:ℝ))-recordTransitionConstant (Real.log K)/(p:ℝ)^5≤
            finiteLyapunov A (2*Real.pi*α) R ∧
        (R:ℝ)*recordGap A α R≤(N:ℝ)*recordGap A α N+
          recordTransitionConstant (Real.log K)*(p:ℝ) := by
  obtain ⟨Q,hQ⟩ := exists_recordTransitionScalar (Real.log_nonneg hK) hκ
    (zero_lt_one.trans_le hC) hc
  refine ⟨Q,?_⟩
  intro A hA hdet hhull α q p N a hq hqp hNlo hNhi hqN happ hL hd hbadq hbadp
  exact finiteLyapunov_record_transition_of_scalar_bounds A hA hdet hhull α
    hκ hC hc hCκ (hQ q hq) (hQ p (hq.trans hqp.le)) hqp hNlo hNhi hqN
    a happ hL hd hbadq hbadp

end UAMO.CMV

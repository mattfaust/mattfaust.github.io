import UAMO.CMVSeparatedSpectral

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial MeasureTheory
open scoped ENNReal BigOperators

local instance rootEnumerationDecidable (p : Prop) : Decidable p := Classical.propDecidable p

theorem polynomial_roots_eq_distinct_enumeration {ι : Type*} [Fintype ι]
    (p : ℂ[X]) (hp : p≠0) (e : ι → ℂ) (he : Function.Injective e)
    (hdegree : p.natDegree=Fintype.card ι) (hroot : ∀i,p.IsRoot (e i)) :
    p.roots=Finset.univ.val.map e := by
  classical
  have hnodup : (Finset.univ.val.map e).Nodup := Multiset.Nodup.map he Finset.univ.nodup
  have hle : Finset.univ.val.map e≤p.roots := by
    apply (Multiset.le_iff_subset hnodup).mpr
    intro z hz
    obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz
    exact (Polynomial.mem_roots hp).mpr (hroot i)
  apply (Multiset.eq_of_le_of_card_le hle _).symm
  simpa only [Multiset.card_map,Finset.card_univ,hdegree] using Polynomial.card_roots' p

def polynomialRootMeasure (p : ℂ[X]) : Measure ℂ :=
  (p.natDegree:ℝ≥0∞)⁻¹ • (p.roots.map (fun z => Measure.dirac z)).sum

theorem polynomialRootMeasure_eq_uniform_of_distinct_enumeration {ι : Type*} [Fintype ι]
    (p : ℂ[X]) (hp : p≠0) (e : ι → ℂ) (he : Function.Injective e)
    (hdegree : p.natDegree=Fintype.card ι) (hroot : ∀i,p.IsRoot (e i)) :
    polynomialRootMeasure p=(Fintype.card ι:ℝ≥0∞)⁻¹ • ∑i,Measure.dirac (e i) := by
  classical
  rw [polynomialRootMeasure,hdegree,
    polynomial_roots_eq_distinct_enumeration p hp e he hdegree hroot,Multiset.map_map]
  rfl

theorem uniform_dirac_measure_apply {ι : Type*} [Fintype ι]
    (e : ι → ℂ) (S : Set ℂ) (hS : MeasurableSet S) :
    ((Fintype.card ι:ℝ≥0∞)⁻¹ • ∑i,Measure.dirac (e i)) S=
      ((Finset.univ.filter (fun i => e i∈S)).card:ℝ≥0∞)/(Fintype.card ι:ℝ≥0∞) := by
  classical
  rw [Measure.smul_apply,Measure.finset_sum_apply]
  simp only [Measure.dirac_apply' _ hS,Set.indicator_apply,Pi.one_apply,smul_eq_mul]
  rw [← Finset.sum_filter]
  simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one,one_mul,div_eq_mul_inv,mul_comm]

theorem uniform_dirac_measureReal {ι : Type*} [Fintype ι]
    (e : ι → ℂ) (S : Set ℂ) (hS : MeasurableSet S) :
    ((Fintype.card ι:ℝ≥0∞)⁻¹ • ∑i,Measure.dirac (e i)).real S=
      ((Finset.univ.filter (fun i => e i∈S)).card:ℝ)/(Fintype.card ι:ℝ) := by
  rw [measureReal_def,uniform_dirac_measure_apply e S hS,ENNReal.toReal_div]
  simp

private theorem dirac_list_get_sum (l : List ℂ) :
    (∑i:Fin l.length,Measure.dirac (l.get i))=
      ((l:Multiset ℂ).map (fun z => Measure.dirac z)).sum := by
  rw [Multiset.map_coe,Multiset.sum_coe]
  conv_rhs => rw [← List.ofFn_get l]
  rw [List.map_ofFn,List.sum_ofFn]
  rfl

theorem separatedSpectralMeasure_eq_polynomialRootMeasure (n : ℕ) (a r ω x : ℝ) :
    separatedSpectralMeasure n a r ω x=polynomialRootMeasure (separatedCMV n a r ω x).charpoly := by
  rw [separatedSpectralMeasure,polynomialRootMeasure,dirac_list_get_sum,
    Matrix.charpoly_natDegree_eq_dim]
  simp only [separatedEigenvalueList,Multiset.coe_toList,FiniteSite,Fintype.card_prod,
    Fintype.card_fin,ZMod.card]

theorem separatedSpectralMeasure_eq_uniform_of_distinct_roots (n : ℕ) (a r ω x : ℝ)
    (e : Fin (2*(n+1)) → ℂ) (he : Function.Injective e)
    (hroot : ∀i,(separatedCMV n a r ω x).charpoly.IsRoot (e i)) :
    separatedSpectralMeasure n a r ω x=((2*(n+1):ℕ):ℝ≥0∞)⁻¹ • ∑i,Measure.dirac (e i) := by
  rw [separatedSpectralMeasure_eq_polynomialRootMeasure]
  have hd : (separatedCMV n a r ω x).charpoly.natDegree=Fintype.card (Fin (2*(n+1))) := by
    simp only [Matrix.charpoly_natDegree_eq_dim,FiniteSite,Fintype.card_prod,
      Fintype.card_fin,ZMod.card]
  simpa only [Fintype.card_fin] using polynomialRootMeasure_eq_uniform_of_distinct_enumeration _
    (separatedCMV n a r ω x).charpoly_monic.ne_zero e he hd hroot

theorem separatedSpectralMeasure_real_eq_count_of_distinct_roots (n : ℕ) (a r ω x : ℝ)
    (e : Fin (2*(n+1)) → ℂ) (he : Function.Injective e)
    (hroot : ∀i,(separatedCMV n a r ω x).charpoly.IsRoot (e i))
    (S : Set ℂ) (hS : MeasurableSet S) :
    (separatedSpectralMeasure n a r ω x).real S=
      ((Finset.univ.filter (fun i => e i∈S)).card:ℝ)/((2*(n+1):ℕ):ℝ) := by
  rw [separatedSpectralMeasure_eq_uniform_of_distinct_roots n a r ω x e he hroot]
  simpa only [Fintype.card_fin] using uniform_dirac_measureReal e S hS

theorem separatedSpectralMeasure_real_eq_count_of_distinct_det_zeros (n : ℕ) (a r ω x : ℝ)
    (e : Fin (2*(n+1)) → ℂ) (he : Function.Injective e)
    (hroot : ∀i,((e i) • (1:FiniteMatrix n)-separatedCMV n a r ω x).det=0)
    (S : Set ℂ) (hS : MeasurableSet S) :
    (separatedSpectralMeasure n a r ω x).real S=
      ((Finset.univ.filter (fun i => e i∈S)).card:ℝ)/((2*(n+1):ℕ):ℝ) := by
  apply separatedSpectralMeasure_real_eq_count_of_distinct_roots n a r ω x e he _ S hS
  intro i
  simpa only [Polynomial.IsRoot,finiteCharpoly_eval] using hroot i

end UAMO.CMV

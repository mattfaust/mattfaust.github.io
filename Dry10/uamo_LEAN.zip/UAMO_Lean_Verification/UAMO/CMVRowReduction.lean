import UAMO.CMVBlockCycle
import Mathlib.LinearAlgebra.Matrix.Permutation

noncomputable section
namespace UAMO.CMV
open Matrix

def evenResidualMap (lam t : ℝ) (z : ℂ) : TransferMatrix :=
  !![(lam : ℂ)⁻¹ * z⁻¹, 0; -(t : ℂ) * (lam : ℂ)⁻¹, -1]

def transferResidualMap (lam t b : ℝ) (ρ z : ℂ) : TransferMatrix :=
  gzOdd b ρ * evenResidualMap lam t z

theorem even_residual_identity (lam t : ℝ) (hlam : lam ≠ 0)
    (hlt : lam^2 + t^2 = 1) {z : ℂ} (hz : z ≠ 0) (u₀ v₀ u₁ v₁ : ℂ) :
    ![u₁, v₁] - gzEven lam t z *ᵥ ![u₀, v₀] =
      evenResidualMap lam t z *ᵥ
        ![z * ((t : ℂ) * u₀ + (lam : ℂ) * u₁) - v₀,
          z * ((lam : ℂ) * u₀ - (t : ℂ) * u₁) - v₁] := by
  have hl' := inv_mul_cancel₀ (Complex.ofReal_ne_zero.mpr hlam)
  have hz' := inv_mul_cancel₀ hz
  have hltc : (lam : ℂ)^2 + (t : ℂ)^2 = 1 := by exact_mod_cast hlt
  ext i
  fin_cases i <;> simp [evenResidualMap, gzEven, Matrix.mulVec, dotProduct, Fin.sum_univ_two]
  · linear_combination -((lam : ℂ)⁻¹ * (t : ℂ) * u₀ + u₁) * hz' - z * z⁻¹ * u₁ * hl'
  · linear_combination z * (lam : ℂ)⁻¹ * u₀ * hltc +
      z * ((t : ℂ) * u₁ - (lam : ℂ) * u₀) * hl'

theorem transfer_residual_identity (lam t b : ℝ) (ρ : ℂ) (hlam : lam ≠ 0)
    (hlt : lam^2 + t^2 = 1) (hρ : ρ ≠ 0)
    (hb : (b : ℂ)^2 + ρ * star ρ = 1) {z : ℂ} (hz : z ≠ 0)
    (u₀ v₀ u₁ v₁ u₂ v₂ : ℂ)
    (ho₀ : (b : ℂ) * u₁ + ρ * u₂ = v₁)
    (ho₁ : star ρ * u₁ - (b : ℂ) * u₂ = v₂) :
    ![u₂, v₂] - gzCell lam t b ρ z *ᵥ ![u₀, v₀] =
      transferResidualMap lam t b ρ z *ᵥ
        ![z * ((t : ℂ) * u₀ + (lam : ℂ) * u₁) - v₀,
          z * ((lam : ℂ) * u₀ - (t : ℂ) * u₁) - v₁] := by
  rw [← odd_block_transfer b ρ hρ hb u₁ v₁ u₂ v₂ ho₀ ho₁]
  rw [gzCell, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_sub,
    even_residual_identity lam t hlam hlt hz, transferResidualMap, Matrix.mulVec_mulVec]

theorem evenResidualMap_det (lam t : ℝ) (z : ℂ) :
    (evenResidualMap lam t z).det = -((lam : ℂ)⁻¹ * z⁻¹) := by
  simp [evenResidualMap, Matrix.det_fin_two_of]

theorem gzOdd_det (b : ℝ) (ρ : ℂ) (hρ : ρ ≠ 0)
    (hb : (b : ℂ)^2 + ρ * star ρ = 1) :
    (gzOdd b ρ).det = -(star ρ / ρ) := by
  rw [gzOdd, Matrix.det_smul, Fintype.card_fin, Matrix.det_fin_two_of]
  have hρ' := inv_mul_cancel₀ hρ
  linear_combination ρ⁻¹ ^ 2 * hb - ρ⁻¹ * star ρ * hρ'

theorem transferResidualMap_det (lam t b : ℝ) (ρ z : ℂ) (hρ : ρ ≠ 0)
    (hb : (b : ℂ)^2 + ρ * star ρ = 1) :
    (transferResidualMap lam t b ρ z).det = (lam : ℂ)⁻¹ * z⁻¹ * (star ρ / ρ) := by
  rw [transferResidualMap, Matrix.det_mul, gzOdd_det b ρ hρ hb, evenResidualMap_det]
  ring

theorem transferResidualMap_det_norm (lam t b : ℝ) (ρ z : ℂ) (hρ : ρ ≠ 0)
    (hb : (b : ℂ)^2 + ρ * star ρ = 1) :
    ‖(transferResidualMap lam t b ρ z).det‖ = (|lam| * ‖z‖)⁻¹ := by
  rw [transferResidualMap_det lam t b ρ z hρ hb, norm_mul, norm_mul, norm_div,
    norm_star, div_self (norm_ne_zero_iff.mpr hρ), mul_one, norm_inv, norm_inv,
    Complex.norm_real, Real.norm_eq_abs, mul_inv]

def cellBackward (n : ℕ) : Equiv.Perm (FiniteSite n) where
  toFun p := (p.1, p.2 - 1)
  invFun p := (p.1, p.2 + 1)
  left_inv p := by simp
  right_inv p := by simp

def finiteTransferSystem (n : ℕ) (a r ω x : ℝ) (z : ℂ) : FiniteMatrix n :=
  1 - (cellBackward n).permMatrix ℂ * Matrix.blockDiagonal (finiteCellTransfer n a r ω x z)

def finiteStateMatrix (n : ℕ) (r ω x : ℝ) : FiniteMatrix n := fun i j =>
  if i.1 = 0 then (1 : FiniteMatrix n) i j else finiteOdd n r ω x (0, i.2) j

def finiteResidualMatrix (n : ℕ) (a r ω x : ℝ) (z : ℂ) : FiniteMatrix n :=
  (cellBackward n).permMatrix ℂ * Matrix.blockDiagonal (fun j : ZMod (n + 1) =>
    transferResidualMap (coupling a) (complementaryCoupling a) (oddAlpha r (x + j.val * ω))
      (star (physicalHopping r (x + j.val * ω))) z)

theorem finiteStateMatrix_mulVec (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (s : Fin 2) (j : ZMod (n + 1)) :
    (finiteStateMatrix n r ω x *ᵥ u) (s, j) = finiteState n r ω x u j s := by
  fin_cases s
  · simp [finiteStateMatrix, Matrix.mulVec, dotProduct, finiteState, Matrix.one_apply]
  · simp [finiteStateMatrix, Matrix.mulVec, dotProduct, finiteState]

private theorem blockDiagonal_mulVec_cell {ι : Type*} [Fintype ι] [DecidableEq ι]
    (B : ι → TransferMatrix) (u : Fin 2 × ι → ℂ) (s : Fin 2) (j : ι) :
    (Matrix.blockDiagonal B *ᵥ u) (s, j) = (B j *ᵥ ![u (0, j), u (1, j)]) s := by
  rw [blockDiagonal_mulVec_apply]
  simp [Matrix.mulVec, dotProduct, Fin.sum_univ_two]

theorem finiteTransferSystem_mulVec_next (n : ℕ) (a r ω x : ℝ) (z : ℂ)
    (u : FiniteSite n → ℂ) (s : Fin 2) (j : ZMod (n + 1)) :
    (finiteTransferSystem n a r ω x z *ᵥ u) (s, j + 1) =
      u (s, j + 1) - (finiteCellTransfer n a r ω x z j *ᵥ ![u (0, j), u (1, j)]) s := by
  rw [finiteTransferSystem, Matrix.sub_mulVec, Matrix.one_mulVec, ← Matrix.mulVec_mulVec,
    PEquiv.toMatrix_toPEquiv_mulVec]
  simp only [Pi.sub_apply, Function.comp_apply, cellBackward, Equiv.coe_fn_mk, add_sub_cancel_right]
  rw [blockDiagonal_mulVec_cell]

theorem finiteResidualMatrix_mulVec_next (n : ℕ) (a r ω x : ℝ) (z : ℂ)
    (u : FiniteSite n → ℂ) (s : Fin 2) (j : ZMod (n + 1)) :
    (finiteResidualMatrix n a r ω x z *ᵥ u) (s, j + 1) =
      (transferResidualMap (coupling a) (complementaryCoupling a) (oddAlpha r (x + j.val * ω))
        (star (physicalHopping r (x + j.val * ω))) z *ᵥ ![u (0, j), u (1, j)]) s := by
  rw [finiteResidualMatrix, ← Matrix.mulVec_mulVec, PEquiv.toMatrix_toPEquiv_mulVec]
  simp only [Function.comp_apply, cellBackward, Equiv.coe_fn_mk, add_sub_cancel_right]
  rw [blockDiagonal_mulVec_cell]

theorem finiteTransferSystem_mul_stateMatrix (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) :
    finiteTransferSystem n a r ω x z * finiteStateMatrix n r ω x =
      finiteResidualMatrix n a r ω x z *
        (z • finiteEven n a - finiteOdd n r ω x) := by
  have hvec (u : FiniteSite n → ℂ) :
      (finiteTransferSystem n a r ω x z * finiteStateMatrix n r ω x) *ᵥ u =
      (finiteResidualMatrix n a r ω x z * (z • finiteEven n a - finiteOdd n r ω x)) *ᵥ u := by
    ext p
    rcases p with ⟨s, k⟩
    let j := k - 1
    have hj : j + 1 = k := sub_add_cancel k 1
    have h := transfer_residual_identity (coupling a) (complementaryCoupling a)
      (oddAlpha r (x + j.val * ω)) (star (physicalHopping r (x + j.val * ω)))
      (ne_of_gt (coupling_pos ha)) (coupling_square_identity a)
      (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 _))
      (by simpa only [star_star, mul_comm (star (physicalHopping r (x + j.val * ω)))] using
        physicalHopping_normalization r (x + j.val * ω)) hz
      (u (0, j)) ((finiteOdd n r ω x *ᵥ u) (0, j))
      (u (1, j)) ((finiteOdd n r ω x *ᵥ u) (1, j))
      (u (0, j + 1)) ((finiteOdd n r ω x *ᵥ u) (0, j + 1))
      (finiteOdd_mulVec_one n r ω x u j).symm
      (by simpa only [star_star] using (finiteOdd_mulVec_zero_next n r ω x u j).symm)
    have hs := congrFun h s
    rw [← hj, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec,
      finiteTransferSystem_mulVec_next, finiteResidualMatrix_mulVec_next]
    simp only [finiteStateMatrix_mulVec, finiteState, Matrix.cons_val_zero,
      Matrix.cons_val_one, Matrix.cons_val_fin_one, Matrix.sub_mulVec, Matrix.smul_mulVec_assoc,
      Pi.sub_apply, Pi.smul_apply, smul_eq_mul, finiteEven_mulVec_zero, finiteEven_mulVec_one,
      finiteCellTransfer]
    exact hs
  ext i j
  have h := congrFun (hvec (Pi.single j 1)) i
  simpa only [Matrix.mulVec_single_one, Matrix.transpose_apply] using h

theorem permutation_det_norm {ι : Type*} [Fintype ι] [DecidableEq ι] (e : Equiv.Perm ι) :
    ‖(e.permMatrix ℂ).det‖ = 1 := by
  rw [Matrix.det_permutation]
  rcases Int.units_eq_one_or (Equiv.Perm.sign e) with h | h <;> simp [h]

theorem finiteResidualMatrix_det_norm (n : ℕ) (a : ℝ) {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1)
    (ω x : ℝ) (z : ℂ) :
    ‖(finiteResidualMatrix n a r ω x z).det‖ = (|coupling a| * ‖z‖)⁻¹ ^ (n + 1) := by
  rw [finiteResidualMatrix, Matrix.det_mul, norm_mul, permutation_det_norm, one_mul,
    Matrix.det_blockDiagonal, norm_prod]
  have h (j : ZMod (n + 1)) :
      ‖(transferResidualMap (coupling a) (complementaryCoupling a) (oddAlpha r (x + j.val * ω))
        (star (physicalHopping r (x + j.val * ω))) z).det‖ = (|coupling a| * ‖z‖)⁻¹ := by
    apply transferResidualMap_det_norm
    · exact star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 _)
    · simpa only [star_star, mul_comm (star (physicalHopping r (x + j.val * ω)))] using
        physicalHopping_normalization r (x + j.val * ω)
  simp only [h, Finset.prod_const, Finset.card_univ, ZMod.card]

end UAMO.CMV

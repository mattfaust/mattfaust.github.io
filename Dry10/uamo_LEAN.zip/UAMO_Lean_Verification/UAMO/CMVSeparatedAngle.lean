import UAMO.CMVSeparatedEndpoint
import UAMO.CMVSeparatedCoordinates
import UAMO.FiniteAngularDirection

noncomputable section
namespace UAMO.CMV
open Matrix ProjectiveAngle StablePlane

def separatedLeftAngle (a t : ℝ) : ℝ :=
  positiveAngleLift (diagonalFactor a) (t/2-Real.pi/2)

def separatedAngularEndpoint (n : ℕ) (a r t ω x : ℝ) : ℝ :=
  angleIterate (fun y => realTransferAngleLift a (coupling r) t y) ω x
    (separatedLeftAngle a t) n+t/2

def separatedLeftVector (a t : ℝ) : Fin 2 → ℂ :=
  ![((a*Real.sin (t/2):ℝ):ℂ),((-a⁻¹*Real.cos (t/2):ℝ):ℂ)]

def separatedHalfPhase (t : ℝ) : ℂ := Complex.exp (((t/2:ℝ):ℂ)*Complex.I)

theorem separatedHalfPhase_sq (t : ℝ) :
    separatedHalfPhase t*separatedHalfPhase t=Complex.exp ((t:ℂ)*Complex.I) := by
  rw [separatedHalfPhase,← Complex.exp_add]
  congr 1
  push_cast
  ring

theorem separatedHalfPhase_euler (t : ℝ) :
    separatedHalfPhase t=(Real.cos (t/2):ℂ)+(Real.sin (t/2):ℂ)*Complex.I := by
  rw [separatedHalfPhase,Complex.exp_mul_I,Complex.ofReal_cos,Complex.ofReal_sin]

theorem separatedHalfPhase_inv (t : ℝ) :
    (separatedHalfPhase t)⁻¹=(Real.cos (t/2):ℂ)-(Real.sin (t/2):ℂ)*Complex.I := by
  rw [separatedHalfPhase,← Complex.exp_neg]
  rw [show -(((t/2:ℝ):ℂ)*Complex.I)=((-(t/2):ℝ):ℂ)*Complex.I by push_cast; ring]
  rw [Complex.exp_mul_I]
  simp only [Complex.ofReal_neg,Complex.cos_neg,Complex.sin_neg,
    ← Complex.ofReal_cos,← Complex.ofReal_sin]
  ring

theorem separatedRealCoordinates_left_boundary {a : ℝ} (ha : 0<a) (t : ℝ) :
    separatedRealCoordinates a (Complex.exp ((t:ℂ)*Complex.I)) *ᵥ ![1,-1] =
      separatedHalfPhase t • separatedLeftVector a t := by
  have he : separatedHalfPhase t≠0 := Complex.exp_ne_zero _
  have hm : Complex.exp ((t:ℂ)*Complex.I)-1=
      2*Complex.I*separatedHalfPhase t*(Real.sin (t/2):ℂ) := by
    rw [← separatedHalfPhase_sq,← mul_inv_cancel₀ he,separatedHalfPhase_inv,separatedHalfPhase_euler]
    ring
  have hp : Complex.exp ((t:ℂ)*Complex.I)+1=
      2*separatedHalfPhase t*(Real.cos (t/2):ℂ) := by
    rw [← separatedHalfPhase_sq,← mul_inv_cancel₀ he,separatedHalfPhase_inv,separatedHalfPhase_euler]
    ring
  have hac : (a:ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha.ne'
  ext i
  fin_cases i
  · simp only [Matrix.mulVec,dotProduct,Fin.sum_univ_two]
    change (-Complex.I*(a:ℂ)*Complex.exp ((t:ℂ)*Complex.I)/2)*1+
      (-Complex.I*(a:ℂ)/2)*(-1)=separatedHalfPhase t*(a*Real.sin (t/2):ℝ)
    push_cast
    calc
      _ = -Complex.I*(a:ℂ)*(Complex.exp ((t:ℂ)*Complex.I)-1)/2 := by ring
      _ = _ := by rw [hm]; ring_nf; simp [Complex.I_sq]
  · simp only [Matrix.mulVec,dotProduct,Fin.sum_univ_two]
    change (-Complex.exp ((t:ℂ)*Complex.I)/(2*(a:ℂ)))*1+
      (1/(2*(a:ℂ)))*(-1)=separatedHalfPhase t*(-a⁻¹*Real.cos (t/2):ℝ)
    push_cast
    calc
      _ = -(Complex.exp ((t:ℂ)*Complex.I)+1)/(2*(a:ℂ)) := by ring
      _ = _ := by rw [hp]; field_simp [hac]; ring

theorem separatedLeftAngle_direction {a : ℝ} (ha : 0<a) (t : ℝ) :
    ∃c:ℝ,0<c ∧ complexAngleVector (separatedLeftAngle a t)=
      (c:ℂ) • separatedLeftVector a t := by
  obtain ⟨c,hc,h⟩ := positiveAngleLift_direction (diagonalFactor a)
    (t/2-Real.pi/2) (diagonalFactor_radial_pos ha _)
  refine ⟨c,hc,?_⟩
  ext i
  have hi := congrFun h i
  fin_cases i
  · change (Real.cos (separatedLeftAngle a t):ℂ)=(c:ℂ)*(a*Real.sin (t/2):ℝ)
    have hh : Real.cos (separatedLeftAngle a t)=c*(a*Real.sin (t/2)) := by
      simpa [separatedLeftAngle,diagonalFactor,angleVector,Matrix.mulVec,dotProduct,
        Fin.sum_univ_two,Real.cos_sub,Real.sin_sub,mul_comm] using hi
    exact_mod_cast hh
  · change (Real.sin (separatedLeftAngle a t):ℂ)=(c:ℂ)*(-a⁻¹*Real.cos (t/2):ℝ)
    have hh : Real.sin (separatedLeftAngle a t)=c*(-a⁻¹*Real.cos (t/2)) := by
      simpa [separatedLeftAngle,diagonalFactor,angleVector,Matrix.mulVec,dotProduct,
        Fin.sum_univ_two,Real.cos_sub,Real.sin_sub,mul_comm] using hi
    exact_mod_cast hh

theorem separated_halfstep_projection (t : ℝ) (v : Fin 2 → ℂ) :
    let H : TransferMatrix := !![Complex.I/Complex.exp ((t:ℂ)*Complex.I),
      1/Complex.exp ((t:ℂ)*Complex.I);Complex.I,-1]
    (separatedHalfPhase t • (H*ᵥv)) 0-(separatedHalfPhase t • (H*ᵥv)) 1 =
      2*((Real.sin (t/2):ℂ)*v 0+(Real.cos (t/2):ℂ)*v 1) := by
  intro H
  have he : separatedHalfPhase t≠0 := Complex.exp_ne_zero _
  have hratio : separatedHalfPhase t / Complex.exp ((t:ℂ)*Complex.I) =
      (separatedHalfPhase t)⁻¹ := by
    rw [← separatedHalfPhase_sq]
    field_simp [he]
  have hi : separatedHalfPhase t*(Complex.I/Complex.exp ((t:ℂ)*Complex.I)-Complex.I)=
      2*(Real.sin (t/2):ℂ) := by
    calc
      _ = Complex.I*(separatedHalfPhase t/Complex.exp ((t:ℂ)*Complex.I)-separatedHalfPhase t) := by ring
      _ = _ := by rw [hratio,separatedHalfPhase_inv,separatedHalfPhase_euler]; ring_nf; simp [Complex.I_sq]
  have hc : separatedHalfPhase t*(1/Complex.exp ((t:ℂ)*Complex.I)+1)=
      2*(Real.cos (t/2):ℂ) := by
    calc
      _ = separatedHalfPhase t/Complex.exp ((t:ℂ)*Complex.I)+separatedHalfPhase t := by ring
      _ = _ := by rw [hratio,separatedHalfPhase_inv,separatedHalfPhase_euler]; ring
  simp only [H,Pi.smul_apply,smul_eq_mul,Matrix.mulVec,dotProduct,Fin.sum_univ_two,
    Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one]
  calc
    _ = (separatedHalfPhase t*(Complex.I/Complex.exp ((t:ℂ)*Complex.I)-Complex.I))*v 0+
      (separatedHalfPhase t*(1/Complex.exp ((t:ℂ)*Complex.I)+1))*v 1 := by ring
    _ = _ := by rw [hi,hc]; ring

theorem separatedEndpoint_projection {a r : ℝ} (ha : 0<a) (hr : 0≤r)
    (hr1 : r<1) (n : ℕ) (t ω x : ℝ) :
    finiteHoppingPhase r ω x n *
      (separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 0-
       separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 1) =
    2*((Real.sin (t/2):ℂ)*(realMonodromy a r t ω x n*ᵥseparatedLeftVector a t) 0+
      (Real.cos (t/2):ℂ)*(realMonodromy a r t ω x n*ᵥseparatedLeftVector a t) 1) := by
  let z := Complex.exp ((t:ℂ)*Complex.I)
  let B := separatedRealCoordinates a z
  let K := separatedRealCoordinatesInv a z
  let E := gzEven (coupling a) (complementaryCoupling a) z
  let P := transferProduct (uamoGZCell a r z) ω x n
  let R := realMonodromy a r t ω x n
  let γ := finiteHoppingPhase r ω x n
  have hKB : K*B=1 := separatedRealCoordinates_inv_mul ha.ne' (Complex.exp_ne_zero _)
  have hprod : B*(γ•P)=R*B := separatedRealCoordinates_product ha hr hr1 t ω x n
  have hvec : γ•(P*ᵥ ![1,-1]) =
      K*ᵥ(R*ᵥ(separatedHalfPhase t•separatedLeftVector a t)) := by
    have h := congrArg (fun M : TransferMatrix => (K*M)*ᵥ ![1,-1]) hprod
    dsimp only at h
    rw [← mul_assoc,hKB,one_mul,Matrix.smul_mulVec_assoc] at h
    rw [← Matrix.mulVec_mulVec,← Matrix.mulVec_mulVec,
      separatedRealCoordinates_left_boundary ha t] at h
    exact h
  have hE : γ•separatedEndpointVector n a r ω x z =
      separatedHalfPhase t•
        ((!![Complex.I/z,1/z;Complex.I,-1]:TransferMatrix)*ᵥ(R*ᵥseparatedLeftVector a t)) := by
    change γ•(E*ᵥ(P*ᵥ ![1,-1]))=_
    rw [← Matrix.mulVec_smul,hvec,Matrix.mulVec_mulVec]
    change (gzEven (coupling a) (complementaryCoupling a) z *
      separatedRealCoordinatesInv a z)*ᵥ(R*ᵥ(separatedHalfPhase t•separatedLeftVector a t))=_
    rw [gzEven_mul_separatedRealCoordinatesInv ha (Complex.exp_ne_zero _),
      Matrix.mulVec_smul,Matrix.mulVec_smul]
  have h := congrArg (fun v : Fin 2 → ℂ => v 0-v 1) hE
  simp only [Pi.smul_apply,smul_eq_mul] at h
  rw [← mul_sub] at h
  exact h.trans (separated_halfstep_projection t (R*ᵥseparatedLeftVector a t))

theorem separatedEndpoint_eq_iff_angle (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (t ω x : ℝ) :
    separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 0 =
      separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 1 ↔
      ∃k:ℤ,separatedAngularEndpoint n a r t ω x=(k:ℝ)*Real.pi := by
  let f := angleIterate (fun y => realTransferAngleLift a (coupling r) t y) ω x
    (separatedLeftAngle a t) n
  let v := realMonodromy a r t ω x n*ᵥseparatedLeftVector a t
  let p := (Real.sin (t/2):ℂ)*v 0+(Real.cos (t/2):ℂ)*v 1
  obtain ⟨c,hc,hcdir⟩ := realMonodromy_angleIterate_direction ha hr hr1 t ω x
    (separatedLeftAngle a t) n
  obtain ⟨d,hd,hddir⟩ := separatedLeftAngle_direction ha t
  rw [hddir,Matrix.mulVec_smul,smul_smul] at hcdir
  have h0 := congrFun hcdir 0
  have h1 := congrFun hcdir 1
  change (Real.cos f:ℂ)=(c:ℂ)*(d:ℂ)*v 0 at h0
  change (Real.sin f:ℂ)=(c:ℂ)*(d:ℂ)*v 1 at h1
  have hsin : (Real.sin (separatedAngularEndpoint n a r t ω x):ℂ)=
      ((c*d:ℝ):ℂ)*p := by
    change (Real.sin (f+t/2):ℂ)=_
    rw [Real.sin_add]
    simp only [Complex.ofReal_add,Complex.ofReal_mul]
    rw [h0,h1]
    dsimp only [p]
    ring
  have hcd : ((c*d:ℝ):ℂ)≠0 := Complex.ofReal_ne_zero.mpr (mul_pos hc hd).ne'
  have hg : finiteHoppingPhase r ω x n≠0 := finiteHoppingPhase_ne_zero hr hr1 ω x n
  have hproj := separatedEndpoint_projection ha hr hr1 n t ω x
  change finiteHoppingPhase r ω x n *
      (separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 0-
        separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 1)=2*p at hproj
  have he : (separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 0=
      separatedEndpointVector n a r ω x (Complex.exp ((t:ℂ)*Complex.I)) 1) ↔ p=0 := by
    rw [← sub_eq_zero]
    have hh := congrArg (fun z : ℂ => z=0) hproj
    simpa only [mul_eq_zero,hg,false_or,show (2:ℂ)≠0 by norm_num] using Iff.of_eq hh
  rw [he]
  have hs : p=0 ↔ Real.sin (separatedAngularEndpoint n a r t ω x)=0 := by
    have hh := congrArg (fun z : ℂ => z=0) hsin
    have hh' : (Real.sin (separatedAngularEndpoint n a r t ω x)=0) ↔ p=0 := by
      simpa only [Complex.ofReal_eq_zero,mul_eq_zero,hcd,false_or] using Iff.of_eq hh
    exact hh'.symm
  rw [hs,Real.sin_eq_zero_iff]
  exact exists_congr (fun k => eq_comm)

theorem separatedCMV_det_zero_iff_angle (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (t ω x : ℝ) :
    ((Complex.exp ((t:ℂ)*Complex.I))•(1 : FiniteMatrix n)-
      separatedCMV n a r ω x).det=0 ↔
      ∃k:ℤ,separatedAngularEndpoint n a r t ω x=(k:ℝ)*Real.pi := by
  rw [separatedCMV_det_zero_iff_endpoint n ha hr hr1 ω x (Complex.exp_ne_zero _)]
  exact separatedEndpoint_eq_iff_angle n ha hr hr1 t ω x

end UAMO.CMV

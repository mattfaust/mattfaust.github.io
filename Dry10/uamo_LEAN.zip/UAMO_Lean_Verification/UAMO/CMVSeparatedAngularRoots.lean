import UAMO.CMVSeparatedAngle
import UAMO.FiniteAngularCrossings
import UAMO.AngularMeanComparison

noncomputable section
namespace UAMO.CMV
open Matrix ProjectiveAngle StablePlane Set

theorem separatedAngularEndpoint_eq_flow (n : ℕ) (a r t ω x : ℝ) :
    separatedAngularEndpoint n a r t ω x =
      finiteAngularFlow a (coupling r) t (ω/(2*Real.pi)) (x/(2*Real.pi))
        (separatedLeftAngle a t) n+t/2 := by
  have h := angleIterate_base_rescaling (fun y => realTransferAngleLift a (coupling r) t y)
    (2*Real.pi) (ω/(2*Real.pi)) (x/(2*Real.pi)) (separatedLeftAngle a t) n
  have hp : 2*Real.pi≠0 := by positivity
  simpa only [mul_div_cancel₀ _ hp] using congrArg (fun s : ℝ => s+t/2) h

theorem continuous_separatedLeftAngle {a : ℝ} (ha : 0<a) :
    Continuous (separatedLeftAngle a) :=
  continuous_positiveAngleLift _ _ continuous_const (by fun_prop)
    (fun _ => (diagonalFactor_radial_pos ha _).ne')

theorem separatedLeftAngle_strictMono {a : ℝ} (ha : 0<a) :
    StrictMono (separatedLeftAngle a) := by
  have hD := positiveAngleLift_strictMono (diagonalFactor a)
    (by rw [diagonalFactor_det ha.ne']; norm_num) (diagonalFactor_radial_pos ha)
  intro t u htu
  apply hD
  dsimp only
  linarith

theorem continuous_separatedAngularEndpoint (n : ℕ) {a r : ℝ}
    (ha : 0<a) (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) :
    Continuous (fun t => separatedAngularEndpoint n a r t ω x) := by
  have hlam : 0≤coupling r := by unfold coupling; positivity
  have hc := (continuous_finiteAngularFlow ha hlam (coupling_lt_one_of_lt_one hr1)
    (ω/(2*Real.pi)) n).comp
    (show Continuous (fun t : ℝ => (t,x/(2*Real.pi),separatedLeftAngle a t)) from
      continuous_id.prodMk (continuous_const.prodMk (continuous_separatedLeftAngle ha)))
  simpa only [separatedAngularEndpoint_eq_flow] using hc.add (continuous_id.div_const 2)

theorem separatedAngularEndpoint_strictMono (n : ℕ) {a r : ℝ}
    (ha : 0<a) (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) :
    StrictMono (fun t => separatedAngularEndpoint n a r t ω x) := by
  have hlam : 0≤coupling r := by unfold coupling; positivity
  have hlam1 := coupling_lt_one_of_lt_one hr1
  intro t u htu
  dsimp only
  rw [separatedAngularEndpoint_eq_flow,separatedAngularEndpoint_eq_flow]
  have hd := finiteAngularFlow_direction_strictMono ha hlam hlam1 t
    (ω/(2*Real.pi)) (x/(2*Real.pi)) n (separatedLeftAngle_strictMono ha htu)
  have hs := finiteAngularFlow_spectral_monotone ha hlam hlam1
    (ω/(2*Real.pi)) (x/(2*Real.pi)) (separatedLeftAngle a u) n htu.le
  linarith

theorem separatedLeftAngle_add_two_pi (a t : ℝ) :
    separatedLeftAngle a (t+2*Real.pi)=separatedLeftAngle a t+Real.pi := by
  unfold separatedLeftAngle
  rw [show (t+2*Real.pi)/2-Real.pi/2=(t/2-Real.pi/2)+Real.pi by ring,
    positiveAngleLift_add_pi]

theorem separatedAngularEndpoint_turn (n : ℕ) (a r t ω x : ℝ) :
    separatedAngularEndpoint n a r (t+2*Real.pi) ω x=
      separatedAngularEndpoint n a r t ω x+(2*(n+1):ℕ)*Real.pi := by
  rw [separatedAngularEndpoint_eq_flow,separatedAngularEndpoint_eq_flow,
    separatedLeftAngle_add_two_pi,finiteAngularFlow_add_pi,finiteAngularFlow_spectral_periodic]
  push_cast
  ring

theorem positiveAngleLift_neg_half_pi (M : PlaneMatrix) (hM : M 0 1=0) :
    positiveAngleLift M (-Real.pi/2)= -Real.pi/2 := by
  simp [positiveAngleLift,transverse,actionX,actionY,hM,Real.cos_neg,Real.sin_neg,
    neg_div]

theorem separatedLeftAngle_zero (a : ℝ) : separatedLeftAngle a 0= -Real.pi/2 := by
  simp only [separatedLeftAngle,zero_div,zero_sub]
  rw [show -(Real.pi/2)= -Real.pi/2 by ring]
  exact positiveAngleLift_neg_half_pi _ (by simp [diagonalFactor])

theorem realTransferAngleLift_zero_neg_half_pi (a lam x : ℝ) :
    realTransferAngleLift a lam 0 x (-Real.pi/2)= -Real.pi/2 := by
  unfold realTransferAngleLift
  rw [positiveAngleLift_neg_half_pi _ (by simp [symmetricFactor]),zero_add]
  exact positiveAngleLift_neg_half_pi _ (by simp [diagonalFactor])

theorem separatedAngularEndpoint_zero (n : ℕ) (a r ω x : ℝ) :
    separatedAngularEndpoint n a r 0 ω x= -Real.pi/2 := by
  have h (n : ℕ) : angleIterate (fun y => realTransferAngleLift a (coupling r) 0 y)
      ω x (-Real.pi/2) n= -Real.pi/2 := by
    induction n with
    | zero => rfl
    | succ n ih => rw [angleIterate_succ,ih,realTransferAngleLift_zero_neg_half_pi]
  simp only [separatedAngularEndpoint,separatedLeftAngle_zero,h,zero_div,add_zero]

def separatedCrossingEquiv (n : ℕ) {a r : ℝ} (ha : 0<a) (hr : 0≤r) (hr1 : r<1)
    (ω x : ℝ) : Fin (2*(n+1)) ≃
      angularCrossingSet (fun t => separatedAngularEndpoint n a r t ω x)
        0 (2*Real.pi) (Real.pi/2) :=
  angularCrossingEquiv _ (continuous_separatedAngularEndpoint n ha hr hr1 ω x)
    (separatedAngularEndpoint_strictMono n ha hr hr1 ω x) _ _ _
    (by positivity) (by positivity) (by linarith [Real.pi_pos]) _
    (by simpa only [zero_add] using separatedAngularEndpoint_turn n a r 0 ω x)

def separatedEigenangle (n : ℕ) {a r : ℝ} (ha : 0<a) (hr : 0≤r) (hr1 : r<1)
    (ω x : ℝ) (j : Fin (2*(n+1))) : ℝ :=
  (separatedCrossingEquiv n ha hr hr1 ω x j).val

theorem separatedEigenangle_spec (n : ℕ) {a r : ℝ} (ha : 0<a) (hr : 0≤r)
    (hr1 : r<1) (ω x : ℝ) (j : Fin (2*(n+1))) :
    separatedEigenangle n ha hr hr1 ω x j ∈ Ico 0 (2*Real.pi) ∧
      separatedAngularEndpoint n a r (separatedEigenangle n ha hr hr1 ω x j) ω x=
        (j.val:ℝ)*Real.pi := by
  have h := angularCrossingRoot_spec _ (continuous_separatedAngularEndpoint n ha hr hr1 ω x)
    (separatedAngularEndpoint_strictMono n ha hr hr1 ω x) 0 (2*Real.pi) (Real.pi/2)
    (by positivity) (by positivity) (by linarith [Real.pi_pos]) (2*(n+1))
    (by simpa only [zero_add] using separatedAngularEndpoint_turn n a r 0 ω x) j
  change separatedEigenangle n ha hr hr1 ω x j∈Ico 0 (0+2*Real.pi) ∧
    separatedAngularEndpoint n a r (separatedEigenangle n ha hr hr1 ω x j) ω x=
      separatedAngularEndpoint n a r 0 ω x+Real.pi/2+(j.val:ℝ)*Real.pi at h
  refine ⟨by simpa only [zero_add] using h.1,?_⟩
  rw [separatedAngularEndpoint_zero] at h
  linarith [h.2]

theorem separatedEigenangle_injective (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) :
    Function.Injective (separatedEigenangle n ha hr hr1 ω x) := by
  intro i j hij
  have hi := (separatedEigenangle_spec n ha hr hr1 ω x i).2
  have hj := (separatedEigenangle_spec n ha hr hr1 ω x j).2
  rw [hij] at hi
  have hval : (i.val:ℝ)=(j.val:ℝ) := mul_right_cancel₀ Real.pi_ne_zero (hi.symm.trans hj)
  exact Fin.ext (by exact_mod_cast hval)

theorem separatedEigenangle_det_zero (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) (j : Fin (2*(n+1))) :
    ((Complex.exp ((separatedEigenangle n ha hr hr1 ω x j:ℂ)*Complex.I))•
      (1 : FiniteMatrix n)-separatedCMV n a r ω x).det=0 := by
  rw [separatedCMV_det_zero_iff_angle n ha hr hr1]
  exact ⟨(j.val:ℤ),by simpa only [Int.cast_natCast] using
    (separatedEigenangle_spec n ha hr hr1 ω x j).2⟩

end UAMO.CMV

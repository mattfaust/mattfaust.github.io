import UAMO.CMVRealMonodromy

noncomputable section
namespace UAMO.CMV
open Matrix
set_option linter.unnecessarySeqFocus false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

def separatedRealCoordinates (a : ℝ) (z : ℂ) : TransferMatrix :=
  !![-Complex.I*(a:ℂ)*z/2,-Complex.I*(a:ℂ)/2;
    -z/(2*(a:ℂ)),1/(2*(a:ℂ))]

def separatedRealCoordinatesInv (a : ℝ) (z : ℂ) : TransferMatrix :=
  !![Complex.I/((a:ℂ)*z),-(a:ℂ)/z;Complex.I/(a:ℂ),(a:ℂ)]

theorem separatedRealCoordinates_inv_mul {a : ℝ} (ha : a≠0) {z : ℂ} (hz : z≠0) :
    separatedRealCoordinatesInv a z*separatedRealCoordinates a z=1 := by
  have hac : (a:ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [separatedRealCoordinates,separatedRealCoordinatesInv,Matrix.mul_apply,Fin.sum_univ_two] <;>
    field_simp <;> ring_nf <;> simp [Complex.I_sq,hac,hz] <;> try ring

theorem separatedRealCoordinates_physical {a : ℝ} (ha : 0<a) (z : ℂ) :
    realCocycleConjugator a*separatedRealCoordinates a z =
      physicalConjugatorInv (coupling a) (complementaryCoupling a) *
        szegoStep (complementaryCoupling a:ℂ) (coupling a:ℂ) z := by
  have hac : (a:ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha.ne'
  have hLam : (coupling a:ℂ)≠0 := Complex.ofReal_ne_zero.mpr (coupling_pos ha).ne'
  have hsq : (coupling a:ℂ)^2+(complementaryCoupling a:ℂ)^2=1 := by
    exact_mod_cast coupling_square_identity a
  have hDS : physicalConjugatorInv (coupling a) (complementaryCoupling a) *
      szegoStep (complementaryCoupling a:ℂ) (coupling a:ℂ) z =
      !![-(complementaryCoupling a:ℂ)*(coupling a:ℂ)⁻¹*z,(coupling a:ℂ)⁻¹;z,0] := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [physicalConjugatorInv,szegoStep,szegoNumerator,Matrix.mul_apply,Fin.sum_univ_two]
    · ring
    · field_simp [hLam]
      linear_combination -z*hsq
    · ring
  rw [hDS]
  have hi : ((coupling a:ℂ))⁻¹ = (1+(a:ℂ)^2)/(2*(a:ℂ)) := by simp [coupling,inv_div]
  have hr : (complementaryCoupling a:ℂ)*(coupling a:ℂ)⁻¹ = (1-(a:ℂ)^2)/(2*(a:ℂ)) := by
    have hs : (1+(a:ℂ)^2)≠0 := by exact_mod_cast (show 1+a^2≠0 by positivity)
    simp only [hi,complementaryCoupling,Complex.ofReal_div,Complex.ofReal_sub,
      Complex.ofReal_one,Complex.ofReal_add,Complex.ofReal_pow]
    field_simp <;> ring
  rw [show -(complementaryCoupling a:ℂ)*(coupling a:ℂ)⁻¹*z =
    -((1-(a:ℂ)^2)/(2*(a:ℂ)))*z by rw [neg_mul,hr],hi]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [realCocycleConjugator,separatedRealCoordinates,Matrix.mul_apply,Fin.sum_univ_two,
      neg_mul,hr,hi] <;>
    field_simp [hac] <;> ring_nf <;> simp [Complex.I_sq] <;> ring

theorem gzEven_mul_separatedRealCoordinatesInv {a : ℝ} (ha : 0<a)
    {z : ℂ} (hz : z≠0) :
    gzEven (coupling a) (complementaryCoupling a) z *
      separatedRealCoordinatesInv a z = !![Complex.I/z,1/z;Complex.I,-1] := by
  have hac : (a:ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha.ne'
  have hi : ((coupling a:ℂ))⁻¹ = (1+(a:ℂ)^2)/(2*(a:ℂ)) := by simp [coupling,inv_div]
  have hr : (coupling a:ℂ)⁻¹*(complementaryCoupling a:ℂ) = (1-(a:ℂ)^2)/(2*(a:ℂ)) := by
    have hs : (1+(a:ℂ)^2)≠0 := by exact_mod_cast (show 1+a^2≠0 by positivity)
    simp only [hi,complementaryCoupling,Complex.ofReal_div,Complex.ofReal_sub,
      Complex.ofReal_one,Complex.ofReal_add,Complex.ofReal_pow]
    field_simp <;> ring
  have he : gzEven (coupling a) (complementaryCoupling a) z =
      !![-((1-(a:ℂ)^2)/(2*(a:ℂ))),((1+(a:ℂ)^2)/(2*(a:ℂ)))*z⁻¹;
        ((1+(a:ℂ)^2)/(2*(a:ℂ)))*z,-((1-(a:ℂ)^2)/(2*(a:ℂ)))] := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [gzEven,mul_neg,hr,hi]
    all_goals simpa only [hi] using hr
  rw [he]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [separatedRealCoordinatesInv,Matrix.mul_apply,Fin.sum_univ_two] <;>
    field_simp [hac,hz] <;> ring_nf <;> field_simp [hac,hz] <;> ring

theorem separatedRealCoordinates_intertwining {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (t x : ℝ) :
    separatedRealCoordinates a (Complex.exp ((t:ℂ)*Complex.I)) *
      ((star (physicalHopping r x)/(‖physicalHopping r x‖:ℂ)) •
        uamoGZCell a r (Complex.exp ((t:ℂ)*Complex.I)) x) =
      complexRealTransfer a (coupling r) t x *
        separatedRealCoordinates a (Complex.exp ((t:ℂ)*Complex.I)) := by
  let z := Complex.exp ((t:ℂ)*Complex.I)
  let X := szegoStep (complementaryCoupling a:ℂ) (coupling a:ℂ) z
  let D := physicalConjugatorInv (coupling a) (complementaryCoupling a)
  let C := physicalConjugator (coupling a) (complementaryCoupling a)
  let J := realCocycleConjugator a
  let B := separatedRealCoordinates a z
  let g := star (physicalHopping r x)/(‖physicalHopping r x‖:ℂ)
  have hz : z≠0 := Complex.exp_ne_zero _
  have hDC : D*C=1 := physicalConjugator_inv_mul _ _ (coupling_pos ha).ne'
  have hiX : IsUnit X.det := by
    rw [show X.det=z from realSzegoStep_det _ _ (coupling_pos ha).ne'
      (coupling_square_identity a) z]
    exact isUnit_iff_ne_zero.mpr hz
  have hXX : X*X⁻¹=1 := Matrix.mul_nonsing_inv _ hiX
  have hJB : J*B=D*X := separatedRealCoordinates_physical ha z
  have hcell : D*X*uamoGZCell a r z x = uamoTransfer a r z x*(D*X) := by
    rw [uamoGZCell,gzCell_szego_conjugacy _ _ _ _ (coupling_pos ha).ne'
      (coupling_square_identity a) hz]
    change D*X*(X⁻¹*(z⁻¹•uamoSzegoCell a r z x)*X)=_
    rw [uamoTransfer_szego_conjugacy ha r hz]
    change D*X*(X⁻¹*(C*uamoTransfer a r z x*D)*X)=_
    calc
      _ = D*(X*X⁻¹)*C*uamoTransfer a r z x*D*X := by simp only [mul_assoc]
      _ = _ := by rw [hXX,mul_one,hDC,one_mul]; simp only [mul_assoc]
  have hJ : J*(B*(g•uamoGZCell a r z x)) =
      J*(complexRealTransfer a (coupling r) t x*B) := by
    calc
      _ = g•(D*X*uamoGZCell a r z x) := by rw [← mul_assoc,hJB,Matrix.mul_smul]
      _ = (g•uamoTransfer a r z x)*(J*B) := by rw [hcell,hJB,Matrix.smul_mul]
      _ = J*(complexRealTransfer a (coupling r) t x*B) := by
        rw [← mul_assoc,realCocycle_intertwining ha hr hr1 t x,mul_assoc]
  have hiJ : IsUnit J.det := isUnit_iff_ne_zero.mpr (realCocycleConjugator_det ha)
  have hh := congrArg (fun M : TransferMatrix => J⁻¹*M) hJ
  simpa only [← mul_assoc,Matrix.nonsing_inv_mul J hiJ,one_mul] using hh

theorem separatedRealCoordinates_product {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (t ω x : ℝ) (N : ℕ) :
    separatedRealCoordinates a (Complex.exp ((t:ℂ)*Complex.I)) *
      (finiteHoppingPhase r ω x N •
        transferProduct (uamoGZCell a r (Complex.exp ((t:ℂ)*Complex.I))) ω x N) =
    realMonodromy a r t ω x N * separatedRealCoordinates a (Complex.exp ((t:ℂ)*Complex.I)) := by
  let B := separatedRealCoordinates a (Complex.exp ((t:ℂ)*Complex.I))
  have h (N : ℕ) : B*transferProduct (fun y =>
      (star (physicalHopping r y)/(‖physicalHopping r y‖:ℂ)) •
      uamoGZCell a r (Complex.exp ((t:ℂ)*Complex.I)) y) ω x N =
      realMonodromy a r t ω x N*B := by
    induction N with
    | zero => simp [realMonodromy]
    | succ N ih =>
      rw [transferProduct_succ,← mul_assoc,separatedRealCoordinates_intertwining ha hr hr1,
        mul_assoc,ih,← mul_assoc]
      rfl
  simpa only [transferProduct_scalar_gauge,finiteHoppingPhase] using h N

end UAMO.CMV

import UAMO.CMVSeparatedFinite
import UAMO.CMVCellConjugacy

noncomputable section
namespace UAMO.CMV
open Matrix

def separatedEndpointVector (n : ℕ) (a r ω x : ℝ) (z : ℂ) : Fin 2 → ℂ :=
  gzEven (coupling a) (complementaryCoupling a) z *ᵥ
    (transferProduct (uamoGZCell a r z) ω x n *ᵥ ![1,-1])

def separatedState (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n+1)) : Fin 2 → ℂ := ![u (0,j),(separatedOdd n r ω x *ᵥ u) (0,j)]

private theorem pair_eta (w : Fin 2 → ℂ) : ![w 0,w 1]=w := by
  ext i
  fin_cases i <;> rfl

theorem separatedState_even (n : ℕ) {a : ℝ} (ha : 0<a) (r ω x : ℝ)
    {z : ℂ} (hz : z≠0) (u : FiniteSite n → ℂ)
    (hu : separatedCMV n a r ω x *ᵥu=z•u) (j : ZMod (n+1)) :
    gzEven (coupling a) (complementaryCoupling a) z *ᵥ separatedState n r ω x u j =
      ![u (1,j),(separatedOdd n r ω x *ᵥu) (1,j)] := by
  have he : finiteEven n a *ᵥ (separatedOdd n r ω x *ᵥu)=z•u := by
    simpa only [Matrix.mulVec_mulVec,separatedCMV] using hu
  have h0 := congrFun he (0,j)
  have h1 := congrFun he (1,j)
  simp only [finiteEven_mulVec_zero,finiteEven_mulVec_one,Pi.smul_apply,smul_eq_mul] at h0 h1
  exact even_block_transfer _ _ (coupling_pos ha).ne' (coupling_square_identity a) hz
    _ _ _ _ h0 h1

theorem separatedState_step (n : ℕ) {a r : ℝ} (ha : 0<a) (hr : 0≤r)
    (hr1 : r<1) (ω x : ℝ) {z : ℂ} (hz : z≠0) (u : FiniteSite n → ℂ)
    (hu : separatedCMV n a r ω x *ᵥu=z•u) (j : ZMod (n+1)) (hj : j.val≠n) :
    uamoGZCell a r z (x+j.val*ω) *ᵥ separatedState n r ω x u j =
      separatedState n r ω x u (j+1) := by
  rw [uamoGZCell,gzCell,← Matrix.mulVec_mulVec,separatedState_even n ha r ω x hz u hu j]
  apply odd_block_transfer _ _ (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 _))
    (by simpa only [star_star,mul_comm (star (physicalHopping r (x+j.val*ω)))] using
      physicalHopping_normalization r (x+j.val*ω))
  · rw [separatedOdd_one_interior n r ω x u j hj,finiteOdd_mulVec_one]
  · rw [separatedOdd_zero_next_interior n r ω x u j hj,finiteOdd_mulVec_zero_next,star_star]

theorem separatedState_propagation (n : ℕ) {a r : ℝ} (ha : 0<a) (hr : 0≤r)
    (hr1 : r<1) (ω x : ℝ) {z : ℂ} (hz : z≠0) (u : FiniteSite n → ℂ)
    (hu : separatedCMV n a r ω x *ᵥu=z•u) (k : ℕ) (hk : k≤n) :
    transferProduct (uamoGZCell a r z) ω x k *ᵥ separatedState n r ω x u 0 =
      separatedState n r ω x u (k:ZMod (n+1)) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [transferProduct_succ,← Matrix.mulVec_mulVec,ih (by omega)]
    have hv : (k:ZMod (n+1)).val=k := ZMod.val_natCast_of_lt (by omega)
    simpa only [hv,Nat.cast_add,Nat.cast_one] using
      separatedState_step n ha hr hr1 ω x hz u hu (k:ZMod (n+1)) (by rw [hv]; omega)

theorem separated_eigenvector_origin_ne_zero (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) {z : ℂ} (hz : z≠0)
    (u : FiniteSite n → ℂ) (hu : separatedCMV n a r ω x *ᵥu=z•u) (hune : u≠0) :
    u (0,0)≠0 := by
  intro h0
  have hs0 : separatedState n r ω x u 0=0 := by
    ext i
    fin_cases i
    · exact h0
    · change (separatedOdd n r ω x *ᵥu) (0,0)=0
      rw [separatedOdd_left_boundary,h0,neg_zero]
  have hs (j : ZMod (n+1)) : separatedState n r ω x u j=0 := by
    have h := separatedState_propagation n ha hr hr1 ω x hz u hu j.val
      (Nat.le_of_lt_succ (ZMod.val_lt j))
    rw [hs0,Matrix.mulVec_zero,ZMod.natCast_zmod_val] at h
    exact h.symm
  apply hune
  ext p
  rcases p with ⟨i,j⟩
  fin_cases i
  · exact congrFun (hs j) 0
  · have h := separatedState_even n ha r ω x hz u hu j
    rw [hs j,Matrix.mulVec_zero] at h
    exact (congrFun h 0).symm

theorem separated_eigenvector_endpoint (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) {z : ℂ} (hz : z≠0)
    (u : FiniteSite n → ℂ) (hu : separatedCMV n a r ω x *ᵥu=z•u) (hune : u≠0) :
    separatedEndpointVector n a r ω x z 0 = separatedEndpointVector n a r ω x z 1 := by
  have h0 := separated_eigenvector_origin_ne_zero n ha hr hr1 ω x hz u hu hune
  have hs0 : separatedState n r ω x u 0 = u (0,0) • ![1,-1] := by
    ext i
    fin_cases i
    · change u (0,0)=u (0,0)*1
      rw [mul_one]
    · change (separatedOdd n r ω x *ᵥu) (0,0)=u (0,0)*(-1)
      rw [separatedOdd_left_boundary,mul_neg_one]
  have hp := separatedState_propagation n ha hr hr1 ω x hz u hu n le_rfl
  have he := separatedState_even n ha r ω x hz u hu (n:ZMod (n+1))
  rw [← hp,hs0,Matrix.mulVec_smul,Matrix.mulVec_smul] at he
  change u (0,0) • separatedEndpointVector n a r ω x z = _ at he
  rw [separatedOdd_right_boundary] at he
  have hleft := congrFun he 0
  have hright := congrFun he 1
  simp only [Pi.smul_apply,smul_eq_mul,Matrix.cons_val_zero,Matrix.cons_val_one,
    Matrix.cons_val_fin_one] at hleft hright
  exact mul_left_cancel₀ h0 (hleft.trans hright.symm)

theorem separated_endpoint_eigenvector (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) {z : ℂ} (hz : z≠0)
    (hend : separatedEndpointVector n a r ω x z 0 = separatedEndpointVector n a r ω x z 1) :
    ∃ u : FiniteSite n → ℂ, u (0,0)=1 ∧ separatedCMV n a r ω x *ᵥu=z•u := by
  let s : ZMod (n+1) → Fin 2 → ℂ := fun j =>
    transferProduct (uamoGZCell a r z) ω x j.val *ᵥ ![1,-1]
  let w := fun j => gzEven (coupling a) (complementaryCoupling a) z *ᵥs j
  let u : FiniteSite n → ℂ := fun p => if p.1=0 then s p.2 0 else w p.2 0
  let v : FiniteSite n → ℂ := fun p => if p.1=0 then s p.2 1 else w p.2 1
  have hs0 : s 0 = ![1,-1] := by simp [s]
  have hs (j : ZMod (n+1)) (hj : j.val≠n) :
      uamoGZCell a r z (x+j.val*ω) *ᵥs j=s (j+1) := by
    have hlt : j.val+1<n+1 := by have := ZMod.val_lt j; omega
    have hj' : j+1=((j.val+1:ℕ):ZMod (n+1)) := by simp
    rw [show s (j+1)=transferProduct (uamoGZCell a r z) ω x (j.val+1) *ᵥ ![1,-1] by
      simp only [s,hj',ZMod.val_natCast_of_lt hlt]]
    rw [transferProduct_succ,← Matrix.mulVec_mulVec]
  have hE (j : ZMod (n+1)) :
      (complementaryCoupling a:ℂ)*v (0,j)+(coupling a:ℂ)*v (1,j)=z*u (0,j) ∧
      (coupling a:ℂ)*v (0,j)-(complementaryCoupling a:ℂ)*v (1,j)=z*u (1,j) := by
    apply even_block_of_transfer _ _ (coupling_pos ha).ne' (coupling_square_identity a) hz
    simp only [u,v,w,↓reduceIte,show (1:Fin 2)≠0 by decide,pair_eta]
  have hO (j : ZMod (n+1)) (hj : j.val≠n) :
      (oddAlpha r (x+j.val*ω):ℂ)*u (1,j)+star (physicalHopping r (x+j.val*ω))*u (0,j+1)=v (1,j) ∧
      physicalHopping r (x+j.val*ω)*u (1,j)-(oddAlpha r (x+j.val*ω):ℂ)*u (0,j+1)=v (0,j+1) := by
    have h := odd_block_of_transfer (oddAlpha r (x+j.val*ω))
      (star (physicalHopping r (x+j.val*ω)))
      (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 _))
      (by simpa only [star_star,mul_comm (star (physicalHopping r (x+j.val*ω)))] using
        physicalHopping_normalization r (x+j.val*ω))
      (u (1,j)) (v (1,j)) (u (0,j+1)) (v (0,j+1))
    apply (by simpa only [star_star] using h)
    simpa only [u,v,w,↓reduceIte,show (1:Fin 2)≠0 by decide,pair_eta,
      Matrix.mulVec_mulVec,gzCell,uamoGZCell] using hs j hj
  have hright : v (1,(n:ZMod (n+1)))=u (1,(n:ZMod (n+1))) := by
    simpa only [v,u,show (1:Fin 2)≠0 by decide,↓reduceIte,w,s,
      ZMod.val_natCast_of_lt (Nat.lt_succ_self n)] using hend.symm
  have hleft : v (0,0)= -u (0,0) := by simp [u,v,hs0]
  have hM : separatedOdd n r ω x *ᵥu=v := by
    ext p
    rcases p with ⟨i,j⟩
    fin_cases i
    · change (separatedOdd n r ω x *ᵥu) (0,j)=v (0,j)
      by_cases hj : j=0
      · subst j
        rw [separatedOdd_left_boundary,hleft]
      · have hp : (j-1).val≠n := by
          intro h
          have he : j-1=(n:ZMod (n+1)) :=
            (ZMod.natCast_zmod_val (j-1)).symm.trans
              (congrArg (fun k : ℕ => (k:ZMod (n+1))) h)
          have he' := congrArg (fun k : ZMod (n+1) => k+1) he
          simp only [sub_add_cancel] at he'
          have hn : (n:ZMod (n+1))+1=0 := by rw [← Nat.cast_add_one,ZMod.natCast_self]
          exact hj (he'.trans hn)
        have h := (hO (j-1) hp).2
        have he := separatedOdd_zero_next_interior n r ω x u (j-1) hp
        rw [finiteOdd_mulVec_zero_next] at he
        simp only [sub_add_cancel] at h he
        exact he.trans h
    · change (separatedOdd n r ω x *ᵥu) (1,j)=v (1,j)
      by_cases hj : j.val=n
      · have he : j=(n:ZMod (n+1)) :=
          (ZMod.natCast_zmod_val j).symm.trans
            (congrArg (fun k : ℕ => (k:ZMod (n+1))) hj)
        subst j
        exact (separatedOdd_right_boundary n r ω x u).trans hright.symm
      · rw [separatedOdd_one_interior n r ω x u j hj,finiteOdd_mulVec_one]
        exact (hO j hj).1
  have hL : finiteEven n a *ᵥv=z•u := by
    ext p
    rcases p with ⟨i,j⟩
    fin_cases i
    · exact (finiteEven_mulVec_zero n a v j).trans (hE j).1
    · exact (finiteEven_mulVec_one n a v j).trans (hE j).2
  refine ⟨u,by simp [u,hs0],?_⟩
  rw [separatedCMV,← Matrix.mulVec_mulVec,hM,hL]

theorem separatedCMV_det_zero_iff_endpoint (n : ℕ) {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (ω x : ℝ) {z : ℂ} (hz : z≠0) :
    (z•(1 : FiniteMatrix n)-separatedCMV n a r ω x).det=0 ↔
      separatedEndpointVector n a r ω x z 0 = separatedEndpointVector n a r ω x z 1 := by
  constructor
  · intro h
    obtain ⟨u,hu0,hu⟩ := Matrix.exists_mulVec_eq_zero_iff.mpr h
    have he : separatedCMV n a r ω x *ᵥu=z•u := by
      have heq : z•u-separatedCMV n a r ω x *ᵥu=0 := by
        simpa only [Matrix.sub_mulVec,Matrix.smul_mulVec_assoc,Matrix.one_mulVec] using hu
      exact (sub_eq_zero.mp heq).symm
    exact separated_eigenvector_endpoint n ha hr hr1 ω x hz u he hu0
  · intro h
    obtain ⟨u,hu0,hu⟩ := separated_endpoint_eigenvector n ha hr hr1 ω x hz h
    apply Matrix.exists_mulVec_eq_zero_iff.mp
    refine ⟨u,?_,?_⟩
    · intro he
      have h0 := congrFun he (0,0)
      rw [hu0] at h0
      norm_num at h0
    · rw [Matrix.sub_mulVec,Matrix.smul_mulVec_assoc,Matrix.one_mulVec,hu,sub_self]

end UAMO.CMV

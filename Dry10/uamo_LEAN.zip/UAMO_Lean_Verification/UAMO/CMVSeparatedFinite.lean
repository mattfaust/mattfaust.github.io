import UAMO.CMVFiniteTransfer

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

def separatedOddBlock (n : ℕ) (r ω x : ℝ) (j : ZMod (n+1)) : TransferMatrix :=
  if j.val=n then thetaBlock 1 0 else
    thetaBlock (oddAlpha r (x+j.val*ω)) (star (physicalHopping r (x+j.val*ω)))

def separatedOdd (n : ℕ) (r ω x : ℝ) : FiniteMatrix n :=
  Matrix.reindexAlgEquiv ℂ ℂ (oddPairEquiv n)
    (Matrix.blockDiagonal (separatedOddBlock n r ω x))

def separatedCMV (n : ℕ) (a r ω x : ℝ) : FiniteMatrix n :=
  finiteEven n a*separatedOdd n r ω x

theorem separatedOddBlock_star (n : ℕ) (r ω x : ℝ) (j : ZMod (n+1)) :
    star (separatedOddBlock n r ω x j)=separatedOddBlock n r ω x j := by
  unfold separatedOddBlock
  split_ifs <;> exact thetaBlock_star _ _

theorem separatedOddBlock_square (n : ℕ) (r ω x : ℝ) (j : ZMod (n+1)) :
    separatedOddBlock n r ω x j*separatedOddBlock n r ω x j=1 := by
  unfold separatedOddBlock
  split_ifs
  · exact thetaBlock_mul_self 1 0 (by norm_num)
  · apply thetaBlock_mul_self
    simpa only [star_star,mul_comm (star (physicalHopping r (x+j.val*ω)))] using
      physicalHopping_normalization r (x+j.val*ω)

theorem separatedOdd_star (n : ℕ) (r ω x : ℝ) :
    star (separatedOdd n r ω x)=separatedOdd n r ω x := by
  have hs := separatedOddBlock_star n r ω x
  simp only [Matrix.star_eq_conjTranspose] at hs
  change (Matrix.blockDiagonal (separatedOddBlock n r ω x)).conjTranspose.submatrix
      (oddPairEquiv n).symm (oddPairEquiv n).symm = _
  simp only [Matrix.blockDiagonal_conjTranspose,hs]
  rfl

theorem separatedOdd_square (n : ℕ) (r ω x : ℝ) :
    separatedOdd n r ω x*separatedOdd n r ω x=1 := by
  unfold separatedOdd
  rw [← map_mul,← Matrix.blockDiagonal_mul]
  simp only [separatedOddBlock_square]
  change Matrix.reindexAlgEquiv ℂ ℂ (oddPairEquiv n)
    (Matrix.blockDiagonal (1 : ZMod (n+1) → TransferMatrix))=1
  rw [Matrix.blockDiagonal_one,map_one]

theorem separatedCMV_unitary (n : ℕ) (a r ω x : ℝ) :
    separatedCMV n a r ω x∈unitary (FiniteMatrix n) := by
  apply unitary.mem_iff.mpr
  simp only [separatedCMV,Matrix.star_mul,finiteEven_star,separatedOdd_star]
  constructor
  · rw [mul_assoc,← mul_assoc (finiteEven n a),finiteEven_square,one_mul,separatedOdd_square]
  · rw [mul_assoc,← mul_assoc (separatedOdd n r ω x),separatedOdd_square,one_mul,finiteEven_square]

theorem separatedOdd_mulVec_one (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n+1)) :
    (separatedOdd n r ω x*ᵥu) (1,j)=
      separatedOddBlock n r ω x j 0 0*u (1,j)+
        separatedOddBlock n r ω x j 0 1*u (0,j+1) := by
  change ((Matrix.blockDiagonal _).submatrix (oddPairEquiv n).symm (oddPairEquiv n).symm*ᵥu)
    (1,j)=_
  rw [Matrix.submatrix_mulVec_equiv]
  change (Matrix.blockDiagonal _*ᵥ(u ∘ oddPairEquiv n)) ((oddPairEquiv n).symm (1,j))=_
  simp only [oddPairEquiv,Equiv.coe_fn_mk,Equiv.coe_fn_symm_mk,
    show (1:Fin 2)≠0 by decide,↓reduceIte]
  rw [blockDiagonal_mulVec_apply]
  simp [Function.comp_def,oddPairEquiv]

theorem separatedOdd_mulVec_zero_next (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n+1)) :
    (separatedOdd n r ω x*ᵥu) (0,j+1)=
      separatedOddBlock n r ω x j 1 0*u (1,j)+
        separatedOddBlock n r ω x j 1 1*u (0,j+1) := by
  change ((Matrix.blockDiagonal _).submatrix (oddPairEquiv n).symm (oddPairEquiv n).symm*ᵥu)
    (0,j+1)=_
  rw [Matrix.submatrix_mulVec_equiv]
  change (Matrix.blockDiagonal _*ᵥ(u ∘ oddPairEquiv n)) ((oddPairEquiv n).symm (0,j+1))=_
  simp only [oddPairEquiv,Equiv.coe_fn_mk,Equiv.coe_fn_symm_mk,↓reduceIte,add_sub_cancel_right]
  rw [blockDiagonal_mulVec_apply]
  simp [Function.comp_def,oddPairEquiv]

theorem separatedOdd_one_interior (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n+1)) (hj : j.val≠n) :
    (separatedOdd n r ω x*ᵥu) (1,j)=(finiteOdd n r ω x*ᵥu) (1,j) := by
  rw [separatedOdd_mulVec_one,finiteOdd_mulVec_one]
  simp [separatedOddBlock,hj,thetaBlock]

theorem separatedOdd_zero_next_interior (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n+1)) (hj : j.val≠n) :
    (separatedOdd n r ω x*ᵥu) (0,j+1)=(finiteOdd n r ω x*ᵥu) (0,j+1) := by
  rw [separatedOdd_mulVec_zero_next,finiteOdd_mulVec_zero_next]
  simp [separatedOddBlock,hj,thetaBlock,sub_eq_add_neg]

theorem separatedOdd_right_boundary (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ) :
    (separatedOdd n r ω x*ᵥu) (1,(n:ZMod (n+1)))=u (1,(n:ZMod (n+1))) := by
  rw [separatedOdd_mulVec_one]
  simp [separatedOddBlock,ZMod.val_natCast_of_lt (Nat.lt_succ_self n),thetaBlock]

theorem separatedOdd_left_boundary (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ) :
    (separatedOdd n r ω x*ᵥu) (0,0)= -u (0,0) := by
  have hj : (n:ZMod (n+1))+1=0 := by
    rw [← Nat.cast_add_one,ZMod.natCast_self]
  have h := separatedOdd_mulVec_zero_next n r ω x u (n:ZMod (n+1))
  simpa [hj,separatedOddBlock,ZMod.val_natCast_of_lt (Nat.lt_succ_self n),thetaBlock] using h

theorem separatedCMV_power_entry_norm_le_one (n : ℕ) (a r ω x : ℝ) (k : ℕ)
    (i j : FiniteSite n) : ‖(separatedCMV n a r ω x^k) i j‖≤1 :=
  entry_norm_bound_of_unitary ((unitary _).pow_mem (separatedCMV_unitary n a r ω x) k) i j

end UAMO.CMV

import UAMO.CMVSeparatedFinite
import UAMO.CMVFinitePropagation

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalCMV PhysicalRealPart PhysicalRepresentation

theorem separatedCMV_step_eq_finite (n : ℕ) (a r ω x : ℝ)
    (u : FiniteSite n → ℂ) (j : ℕ) (hj0 : 0<j) (hj1 : j+1<n+1) (s : Fin 2) :
    (separatedCMV n a r ω x*ᵥu) (s,(j:ZMod (n+1)))=
      (finiteCMV n a r ω x*ᵥu) (s,(j:ZMod (n+1))) := by
  have hc : ((j-1:ℕ):ZMod (n+1))+1=(j:ZMod (n+1)) := by
    simpa only [Nat.cast_add,Nat.cast_one] using congrArg
      (fun l : ℕ => (l:ZMod (n+1))) (Nat.sub_add_cancel (show 1≤j by omega))
  have hlast : (j:ZMod (n+1)).val≠n := by
    rw [ZMod.val_natCast_of_lt (by omega : j<n+1)]
    omega
  have hprev : ((j-1:ℕ):ZMod (n+1)).val≠n := by
    rw [ZMod.val_natCast_of_lt (by omega : j-1<n+1)]
    omega
  have hzero : (separatedOdd n r ω x*ᵥu) (0,(j:ZMod (n+1)))=
      (finiteOdd n r ω x*ᵥu) (0,(j:ZMod (n+1))) := by
    rw [← hc]
    exact separatedOdd_zero_next_interior n r ω x u _ hprev
  have hone := separatedOdd_one_interior n r ω x u (j:ZMod (n+1)) hlast
  rw [separatedCMV,finiteCMV,← Matrix.mulVec_mulVec,← Matrix.mulVec_mulVec]
  fin_cases s <;> simp only [Fin.zero_eta,Fin.mk_one]
  · rw [finiteEven_mulVec_zero,finiteEven_mulVec_zero,hzero,hone]
  · rw [finiteEven_mulVec_one,finiteEven_mulVec_one,hzero,hone]

theorem separatedCMV_step_interior (n : ℕ) (a r Φ θ : ℝ)
    (u : FiniteSite n → ℂ) (ψ : SpinHilbert) (j : ℕ)
    (hj0 : 0<j) (hj1 : j+1<n+1)
    (hu : ∀ (s : Fin 2) (l : ℕ), j-1≤l → l≤j+1 →
      u (s,(l:ZMod (n+1)))=ψ s (l:ℤ)) (s : Fin 2) :
    (separatedCMV n a r (2*Real.pi*Φ) (2*Real.pi*θ)*ᵥu) (s,(j:ZMod (n+1)))=
      spinAction (infiniteCMV a r Φ θ) ψ s (j:ℤ) := by
  rw [separatedCMV_step_eq_finite n a r _ _ u j hj0 hj1 s]
  exact finiteCMV_step_interior n a r Φ θ u ψ j hj0 hj1 hu s

theorem separatedCMV_power_interior (n : ℕ) (a r Φ θ : ℝ)
    (u : FiniteSite n → ℂ) (ψ : SpinHilbert)
    (hu : ∀ (s : Fin 2) (j : ℕ), j < n+1 →
      u (s, (j : ZMod (n+1))) = ψ s (j : ℤ))
    (k j : ℕ) (hj0 : k ≤ j) (hj1 : j + k < n+1) (s : Fin 2) :
    (separatedCMV n a r (2 * Real.pi * Φ) (2 * Real.pi * θ) ^ k *ᵥ u)
      (s, (j : ZMod (n+1))) =
      spinAction (infiniteCMV a r Φ θ ^ k) ψ s (j : ℤ) := by
  induction k generalizing j s with
  | zero => simpa only [pow_zero, Matrix.one_mulVec, spinAction_one] using hu s j hj1
  | succ k ih =>
    rw [pow_succ', ← Matrix.mulVec_mulVec, pow_succ', spinAction_mul]
    apply separatedCMV_step_interior n a r Φ θ _ _ j (by omega) (by omega)
    intro t l hl₀ hl₁
    exact ih l (by omega) (by omega) t

theorem separatedCMV_power_diagonal_interior (n : ℕ) (a r Φ θ : ℝ)
    (k j : ℕ) (hj0 : k ≤ j) (hj1 : j + k < n+1) (s : Fin 2) :
    (separatedCMV n a r (2 * Real.pi * Φ) (2 * Real.pi * θ) ^ k)
      (s, (j : ZMod (n+1))) (s, (j : ZMod (n+1))) =
      ((infiniteCMV a r Φ θ ^ k) s s (delta (j : ℤ))) (j : ℤ) := by
  have hj : j < n+1 := by omega
  have hv : ∀ (t : Fin 2) (l : ℕ), l < n+1 →
      (Pi.single (s, (j : ZMod (n+1))) (1 : ℂ) : FiniteSite n → ℂ) (t, (l : ZMod (n+1))) =
        spinCoordinateVector s (j : ℤ) t (l : ℤ) := by
    intro t l hl
    have hc : (l : ZMod (n+1)) = (j : ZMod (n+1)) ↔ l = j := by
      constructor
      · intro h
        have hh := congrArg ZMod.val h
        simpa only [ZMod.val_natCast_of_lt hl, ZMod.val_natCast_of_lt hj] using hh
      · exact fun h => congrArg (fun z : ℕ => (z : ZMod (n+1))) h
    have hc' : (j : ZMod (n+1)) = (l : ZMod (n+1)) ↔ j = l := by
      simpa only [eq_comm] using hc
    by_cases hst : s = t <;>
      simp [spinCoordinateVector, delta, lp.coeFn_single, Pi.single_apply, Prod.mk.injEq,
        hc, hc', hst, and_comm]
  have h := separatedCMV_power_interior n a r Φ θ _ _ hv k j hj0 hj1 s
  simpa only [Matrix.mulVec_single_one, Matrix.transpose_apply, spinCoordinateVector_action] using h

end UAMO.CMV

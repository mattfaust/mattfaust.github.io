import UAMO.CMVSeparatedFinite
import Mathlib.Topology.Instances.Matrix
import UAMO.CMVFiniteNormalSpectrum
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial MeasureTheory
open scoped ENNReal Matrix.L2OpNorm

theorem separatedCMV_spectrum_norm (n : ℕ) (a r ω x : ℝ) {z : ℂ}
    (hz : z∈spectrum ℂ (separatedCMV n a r ω x)) : ‖z‖=1 := by
  have h := spectrum.subset_circle_of_unitary (𝕜:=ℂ) (separatedCMV_unitary n a r ω x) hz
  simpa only [Metric.mem_sphere,dist_zero_right] using h

theorem separatedCMV_det_ne_zero (n : ℕ) (a r ω x : ℝ) {z : ℂ} (hz : ‖z‖≠1) :
    (z • (1:FiniteMatrix n)-separatedCMV n a r ω x).det≠0 := by
  have hs : z∉spectrum ℂ (separatedCMV n a r ω x) :=
    fun h => hz (separatedCMV_spectrum_norm n a r ω x h)
  have hu : IsUnit (z • (1:FiniteMatrix n)-separatedCMV n a r ω x) := by
    simpa only [spectrum.mem_iff,not_not,Algebra.algebraMap_eq_smul_one] using hs
  exact isUnit_iff_ne_zero.mp ((Matrix.isUnit_iff_isUnit_det _).mp hu)

def separatedEigenvalueList (n : ℕ) (a r ω x : ℝ) : List ℂ :=
  (separatedCMV n a r ω x).charpoly.roots.toList

theorem separatedEigenvalueList_length (n : ℕ) (a r ω x : ℝ) :
    (separatedEigenvalueList n a r ω x).length = 2 * (n + 1) := by
  rw [separatedEigenvalueList, Multiset.length_toList]
  have h := Polynomial.natDegree_eq_card_roots (IsAlgClosed.splits (separatedCMV n a r ω x).charpoly)
  rw [Polynomial.map_id, Matrix.charpoly_natDegree_eq_dim] at h
  rw [← h]
  simp only [FiniteSite, Fintype.card_prod, Fintype.card_fin, ZMod.card]

theorem separatedEigenvalueList_mem_root (n : ℕ) (a r ω x : ℝ)
    (i : Fin (separatedEigenvalueList n a r ω x).length) :
    (separatedCMV n a r ω x).charpoly.IsRoot ((separatedEigenvalueList n a r ω x).get i) := by
  apply (Polynomial.mem_roots (separatedCMV n a r ω x).charpoly_monic.ne_zero).mp
  have h := List.get_mem (separatedEigenvalueList n a r ω x) i
  have hc : (↑(separatedEigenvalueList n a r ω x) : Multiset ℂ) =
      (separatedCMV n a r ω x).charpoly.roots := Multiset.coe_toList _
  rw [← hc]
  exact h

theorem separatedEigenvalueList_norm (n : ℕ) (a r ω x : ℝ)
    (i : Fin (separatedEigenvalueList n a r ω x).length) :
    ‖(separatedEigenvalueList n a r ω x).get i‖ = 1 := by
  by_contra h
  have hz := separatedEigenvalueList_mem_root n a r ω x i
  rw [Polynomial.IsRoot, finiteCharpoly_eval] at hz
  exact separatedCMV_det_ne_zero n a r ω x h hz

def separatedSpectralMeasure (n : ℕ) (a r ω x : ℝ) : Measure ℂ :=
  ((2 * (n + 1) : ℕ) : ℝ≥0∞)⁻¹ •
    ∑ i : Fin (separatedEigenvalueList n a r ω x).length,
      Measure.dirac ((separatedEigenvalueList n a r ω x).get i)

instance separatedSpectralMeasure_isProbabilityMeasure (n : ℕ) (a r ω x : ℝ) :
    IsProbabilityMeasure (separatedSpectralMeasure n a r ω x) := by
  constructor
  simp only [separatedSpectralMeasure, Measure.smul_apply, Measure.finset_sum_apply,
    measure_univ, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    separatedEigenvalueList_length, nsmul_eq_mul, mul_one, smul_eq_mul]
  exact ENNReal.inv_mul_cancel (by simp : ((2 * (n + 1) : ℕ) : ℝ≥0∞) ≠ 0) (ENNReal.natCast_ne_top _)

theorem separatedSpectralMeasure_off_circle (n : ℕ) (a r ω x : ℝ) :
    separatedSpectralMeasure n a r ω x {w : ℂ | ‖w‖ ≠ 1} = 0 := by
  have hm : MeasurableSet {w : ℂ | ‖w‖ ≠ 1} :=
    (isClosed_eq continuous_norm continuous_const).measurableSet.compl
  simp only [separatedSpectralMeasure, Measure.smul_apply, Measure.finset_sum_apply]
  have hd (i : Fin (separatedEigenvalueList n a r ω x).length) :
      Measure.dirac ((separatedEigenvalueList n a r ω x).get i) {w : ℂ | ‖w‖ ≠ 1} = 0 := by
    rw [Measure.dirac_apply' _ hm]
    simp only [Set.indicator_apply, Set.mem_setOf_eq, separatedEigenvalueList_norm, ne_eq,
      not_true_eq_false, ↓reduceIte]
  simp only [hd, Finset.sum_const_zero, smul_zero]

theorem separatedSpectralMeasure_integral_complex (n : ℕ) (a r ω x : ℝ) (f : ℂ → ℂ) :
    ∫ w, f w ∂separatedSpectralMeasure n a r ω x =
      (((2 * (n + 1) : ℕ) : ℂ)⁻¹) *
        ∑ i : Fin (separatedEigenvalueList n a r ω x).length,
          f ((separatedEigenvalueList n a r ω x).get i) := by
  rw [separatedSpectralMeasure, integral_smul_measure,
    integral_finset_sum_measure (fun _ _ => integrable_dirac)]
  simp only [integral_dirac, ENNReal.toReal_inv, ENNReal.toReal_natCast,
    Complex.real_smul, Complex.ofReal_inv, Complex.ofReal_natCast]

theorem separatedCMV_trace_power (n : ℕ) (a r ω x : ℝ) (k : ℕ) :
    (separatedCMV n a r ω x ^ k).trace =
      ∑ i : Fin (separatedEigenvalueList n a r ω x).length,
        ((separatedEigenvalueList n a r ω x).get i) ^ k := by
  have hU := separatedCMV_unitary n a r ω x
  have hc : Commute (separatedCMV n a r ω x) (star (separatedCMV n a r ω x)) := by
    show _ * _ = _ * _
    rw [unitary.mul_star_self_of_mem hU, unitary.star_mul_self_of_mem hU]
  rw [normal_matrix_trace_power_roots _ hc k]
  have hl : (↑(separatedEigenvalueList n a r ω x) : Multiset ℂ) =
      (separatedCMV n a r ω x).charpoly.roots := Multiset.coe_toList _
  rw [← hl, Multiset.map_coe, Multiset.sum_coe]
  conv_lhs => rw [← List.ofFn_get (separatedEigenvalueList n a r ω x)]
  rw [List.map_ofFn, List.sum_ofFn]
  rfl

theorem separatedSpectralMeasure_moment (n : ℕ) (a r ω x : ℝ) (k : ℕ) :
    (∫ w : ℂ, w ^ k ∂separatedSpectralMeasure n a r ω x) =
      (separatedCMV n a r ω x ^ k).trace / ((2 * (n + 1) : ℕ) : ℂ) := by
  rw [separatedSpectralMeasure_integral_complex, ← separatedCMV_trace_power]
  rw [div_eq_mul_inv, mul_comm]

theorem separatedSpectralMeasure_ae_circle (n : ℕ) (a r ω x : ℝ) :
    ∀ᵐ z ∂separatedSpectralMeasure n a r ω x,‖z‖=1 := by
  rw [ae_iff]
  exact separatedSpectralMeasure_off_circle n a r ω x

end UAMO.CMV

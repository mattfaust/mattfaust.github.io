import UAMO.CMVCellConjugacy
import UAMO.CMVSingularLyapunov

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter
open scoped Topology Matrix.L2OpNorm

local instance singularCellMatrixMeasurableSpace : MeasurableSpace TransferMatrix := borel _
local instance singularCellMatrixBorelSpace : BorelSpace TransferMatrix := ⟨rfl⟩

theorem constantConjugacy_det_norm_ae (B : ℝ → TransferMatrix)
    (hd : ∀ᵐ x ∂volume, ‖(B x).det‖ = 1) (C D : TransferMatrix) (hCD : C*D = 1) :
    ∀ᵐ x ∂volume, ‖(C*B x*D).det‖ = 1 := by
  have hh := congrArg Matrix.det hCD
  rw [Matrix.det_mul, Matrix.det_one] at hh
  filter_upwards [hd] with x hx
  rw [Matrix.det_mul, Matrix.det_mul, show C.det*(B x).det*D.det =
    (C.det*D.det)*(B x).det by ring, hh, one_mul, hx]

theorem transferLogNorm_conjugacy_le_at (A B : ℝ → TransferMatrix)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1)
    (hconj : ∀ x, A x = C*B x*D) (ω x : ℝ) (n : ℕ)
    (hA : ‖(transferProduct A ω x n).det‖ = 1)
    (hB : ‖(transferProduct B ω x n).det‖ = 1) :
    transferLogNorm A ω x n ≤ transferLogNorm B ω x n +
      Real.log (transferNorm C*transferNorm D) := by
  have hc := transferNorm_conjugator_pos C D hCD
  have ha := zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ hA)
  have hb := zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ hB)
  have hn : transferNorm (transferProduct A ω x n) ≤
      (transferNorm C*transferNorm D)*transferNorm (transferProduct B ω x n) := by
    rw [transferProduct_conjugacy A B C D hCD hDC hconj]
    calc
      _ ≤ (transferNorm C*transferNorm (transferProduct B ω x n))*transferNorm D :=
        (transferNorm_mul_le _ D).trans
          (mul_le_mul_of_nonneg_right (transferNorm_mul_le C _) (norm_nonneg _))
      _ = _ := by ring
  have hl := Real.log_le_log ha hn
  rw [Real.log_mul hc.ne' hb.ne'] at hl
  simpa only [transferLogNorm, add_comm] using hl

theorem transferLogNorm_conjugacy_le_ae (A B : ℝ → TransferMatrix)
    (hdA : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (hdB : ∀ᵐ x ∂volume, ‖(B x).det‖ = 1)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1)
    (hconj : ∀ x, A x = C*B x*D) (ω : ℝ) (n : ℕ) :
    ∀ᵐ x ∂volume, transferLogNorm A ω x n ≤ transferLogNorm B ω x n +
      Real.log (transferNorm C*transferNorm D) := by
  filter_upwards [transferProduct_det_norm_ae A hdA ω n,
    transferProduct_det_norm_ae B hdB ω n] with x hx hy
  exact transferLogNorm_conjugacy_le_at A B C D hCD hDC hconj ω x n hx hy

theorem constantConjugacy_logNorm_integrable_ae (B : ℝ → TransferMatrix)
    (hB : Measurable B) (hd : ∀ᵐ x ∂volume, ‖(B x).det‖ = 1)
    (hi : ∀ s t, IntervalIntegrable (fun x => Real.log (transferNorm (B x))) volume s t)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log (transferNorm (C*B x*D))) volume s t := by
  let A := fun x => C*B x*D
  have hA : Measurable A := (measurable_const.mul hB).mul measurable_const
  have hdA := constantConjugacy_det_norm_ae B hd C D hCD
  apply ((hi s t).add intervalIntegrable_const).mono_fun'
  · exact (Real.measurable_log.comp (continuous_transferNorm.measurable.comp hA)).aestronglyMeasurable
  · filter_upwards [ae_restrict_of_ae (transferLogNorm_conjugacy_le_ae A B hdA hd C D
      hCD hDC (fun _ => rfl) 0 1), ae_restrict_of_ae hdA] with x hx hdet
    have hn := Real.log_nonneg (one_le_transferNorm_of_det_norm _ hdet)
    rw [Real.norm_eq_abs, abs_of_nonneg hn]
    simpa only [transferLogNorm, transferProduct_succ, transferProduct_zero, Nat.cast_zero,
      zero_mul, add_zero, mul_one] using hx

theorem finiteLyapunov_conjugacy_le_ae (A B : ℝ → TransferMatrix)
    (hiA : ∀ n, IntervalIntegrable (fun x => transferLogNorm A ω x n) volume 0 (2*Real.pi))
    (hiB : ∀ n, IntervalIntegrable (fun x => transferLogNorm B ω x n) volume 0 (2*Real.pi))
    (hdA : ∀ᵐ x ∂volume, ‖(A x).det‖ = 1) (hdB : ∀ᵐ x ∂volume, ‖(B x).det‖ = 1)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1)
    (hconj : ∀ x, A x = C*B x*D) (n : ℕ) :
    finiteLyapunov A ω n ≤ finiteLyapunov B ω n +
      Real.log (transferNorm C*transferNorm D)/(n : ℝ) := by
  have hi := intervalIntegral.integral_mono_ae (by positivity : (0 : ℝ) ≤ 2*Real.pi)
    (hiA n) ((hiB n).add intervalIntegrable_const)
    (transferLogNorm_conjugacy_le_ae A B hdA hdB C D hCD hDC hconj ω n)
  rw [intervalIntegral.integral_add (hiB n) intervalIntegrable_const] at hi
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hi
  have hdiv := div_le_div_of_nonneg_right hi (by positivity : (0 : ℝ) ≤ 2*Real.pi)
  rw [add_div, mul_div_cancel_left₀ _ (by positivity : (2*Real.pi : ℝ) ≠ 0)] at hdiv
  have hfin := div_le_div_of_nonneg_right hdiv (Nat.cast_nonneg n)
  simpa only [add_div, finiteLyapunov, transferLogAverage] using hfin

theorem lyapunov_constant_conjugacy_ae (B : ℝ → TransferMatrix)
    (hB : Measurable B) (hp : Function.Periodic B (2*Real.pi))
    (hd : ∀ᵐ x ∂volume, ‖(B x).det‖ = 1)
    (hi : ∀ s t, IntervalIntegrable (fun x => Real.log (transferNorm (B x))) volume s t)
    (C D : TransferMatrix) (hCD : C*D = 1) (hDC : D*C = 1) (ω : ℝ) :
    lyapunov (fun x => C*B x*D) ω = lyapunov B ω := by
  let A := fun x => C*B x*D
  have hA : Measurable A := (measurable_const.mul hB).mul measurable_const
  have hpA : Function.Periodic A (2*Real.pi) := by
    intro x
    change C*B (x+2*Real.pi)*D = C*B x*D
    rw [hp x]
  have hdA := constantConjugacy_det_norm_ae B hd C D hCD
  have hiA := constantConjugacy_logNorm_integrable_ae B hB hd hi C D hCD hDC
  have hsA := tendsto_finiteLyapunov_ae A hA hpA hdA hiA ω
  have hsB := tendsto_finiteLyapunov_ae B hB hp hd hi ω
  have hiAn := fun n => transferLogNorm_intervalIntegrable_ae A hA hdA hiA ω n 0 (2*Real.pi)
  have hiBn := fun n => transferLogNorm_intervalIntegrable_ae B hB hd hi ω n 0 (2*Real.pi)
  have hAB := le_of_tendsto_of_tendsto' hsA
    (hsB.add (tendsto_const_div_atTop_nhds_zero_nat (Real.log (transferNorm C*transferNorm D))))
    (fun n => finiteLyapunov_conjugacy_le_ae A B hiAn hiBn hdA hd C D hCD hDC (fun _ => rfl) n)
  have hrev (x : ℝ) : B x = D*A x*C := by
    simp only [A, mul_assoc, ← mul_assoc D C, hDC, one_mul, mul_one]
  have hBA := le_of_tendsto_of_tendsto' hsB
    (hsA.add (tendsto_const_div_atTop_nhds_zero_nat (Real.log (transferNorm D*transferNorm C))))
    (fun n => finiteLyapunov_conjugacy_le_ae B A hiBn hiAn hd hdA D C hDC hCD hrev n)
  exact le_antisymm (by simpa using hAB) (by simpa using hBA)

theorem exists_gz_physical_conjugators {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0) :
    ∃ C D : TransferMatrix, C*D = 1 ∧ D*C = 1 ∧
      ∀ r x : ℝ, uamoGZCell a r z x = C*uamoTransfer a r z x*D := by
  let X := szegoStep (complementaryCoupling a : ℂ) (coupling a : ℂ) z
  let C := physicalConjugator (coupling a) (complementaryCoupling a)
  let D := physicalConjugatorInv (coupling a) (complementaryCoupling a)
  have hCD : C*D = 1 := physicalConjugator_mul_inv _ _ (coupling_pos ha).ne'
  have hDC : D*C = 1 := physicalConjugator_inv_mul _ _ (coupling_pos ha).ne'
  have hi : IsUnit X.det := by
    rw [show X.det = z from realSzegoStep_det _ _ (coupling_pos ha).ne' (coupling_square_identity a) z]
    exact isUnit_iff_ne_zero.mpr hz
  have hXX : X*X⁻¹ = 1 := Matrix.mul_nonsing_inv X hi
  have hXX' : X⁻¹*X = 1 := Matrix.nonsing_inv_mul X hi
  have hpair : (X⁻¹*C)*(D*X) = 1 := by
    calc
      _ = X⁻¹*(C*D)*X := by simp only [mul_assoc]
      _ = 1 := by rw [hCD, mul_one, hXX']
  have hpair' : (D*X)*(X⁻¹*C) = 1 := by
    calc
      _ = D*(X*X⁻¹)*C := by simp only [mul_assoc]
      _ = 1 := by rw [hXX, mul_one, hDC]
  refine ⟨X⁻¹*C, D*X, hpair, hpair', ?_⟩
  intro r x
  rw [uamoGZCell, gzCell_szego_conjugacy _ _ _ _ (coupling_pos ha).ne'
    (coupling_square_identity a) hz]
  change X⁻¹*(z⁻¹ • uamoSzegoCell a r z x)*X = _
  rw [uamoTransfer_szego_conjugacy ha r hz]
  simp only [C, D, mul_assoc]

theorem measurable_uamoGZCell_one {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0) :
    Measurable (uamoGZCell a 1 z) := by
  obtain ⟨C,D,_,_,heq⟩ := exists_gz_physical_conjugators ha hz
  have hfun := funext (heq 1)
  rw [hfun]
  exact (measurable_const.mul (measurable_uamoTransfer_one a z)).mul measurable_const

theorem uamoGZCell_periodic (a r : ℝ) (z : ℂ) :
    Function.Periodic (uamoGZCell a r z) (2*Real.pi) := by
  intro x
  simp [uamoGZCell, oddAlpha, physicalHopping]

theorem uamoGZCell_one_det_norm_ae {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0) :
    ∀ᵐ x ∂volume, ‖(uamoGZCell a 1 z x).det‖ = 1 := by
  obtain ⟨C,D,hCD,_,heq⟩ := exists_gz_physical_conjugators ha hz
  simp_rw [heq 1]
  exact constantConjugacy_det_norm_ae _ (uamoTransfer_one_det_norm_ae ha hz) C D hCD

theorem uamoGZCell_one_logNorm_integrable {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log (transferNorm (uamoGZCell a 1 z x))) volume s t := by
  obtain ⟨C,D,hCD,hDC,heq⟩ := exists_gz_physical_conjugators ha hz
  simp_rw [heq 1]
  exact constantConjugacy_logNorm_integrable_ae _ (measurable_uamoTransfer_one a z)
    (uamoTransfer_one_det_norm_ae ha hz) (uamoTransfer_one_logNorm_integrable ha hz) C D hCD hDC s t

theorem uamoGZCell_one_product_log_integrable {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (ω : ℝ) (n : ℕ) (s t : ℝ) :
    IntervalIntegrable (fun x => transferLogNorm (uamoGZCell a 1 z) ω x n) volume s t :=
  transferLogNorm_intervalIntegrable_ae _ (measurable_uamoGZCell_one ha hz)
    (uamoGZCell_one_det_norm_ae ha hz) (uamoGZCell_one_logNorm_integrable ha hz) ω n s t

theorem gzLyapunov_one_eq_uamo {a : ℝ} (ha : 0 < a) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    lyapunov (uamoGZCell a 1 z) ω = uamoLyapunov a 1 ω z := by
  obtain ⟨C,D,hCD,hDC,heq⟩ := exists_gz_physical_conjugators ha hz
  rw [funext (heq 1)]
  exact lyapunov_constant_conjugacy_ae _ (measurable_uamoTransfer_one a z)
    (uamoTransfer_periodic a 1 z) (uamoTransfer_one_det_norm_ae ha hz)
    (uamoTransfer_one_logNorm_integrable ha hz) C D hCD hDC ω

theorem tendsto_gzFiniteLyapunov_one {a : ℝ} (ha : 0 < a) (ω : ℝ)
    {z : ℂ} (hz : z ≠ 0) :
    Tendsto (finiteLyapunov (uamoGZCell a 1 z) ω) atTop (𝓝 (uamoLyapunov a 1 ω z)) := by
  rw [← gzLyapunov_one_eq_uamo ha ω hz]
  exact tendsto_finiteLyapunov_ae _ (measurable_uamoGZCell_one ha hz)
    (uamoGZCell_periodic a 1 z) (uamoGZCell_one_det_norm_ae ha hz)
    (uamoGZCell_one_logNorm_integrable ha hz) ω

end UAMO.CMV

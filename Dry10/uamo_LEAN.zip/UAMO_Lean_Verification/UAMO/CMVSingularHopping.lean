import UAMO.CMVHoppingIntegral
import Mathlib.Analysis.SpecialFunctions.Integrals
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set

private theorem log_sin_half_integrable :
    IntervalIntegrable (fun x => Real.log (Real.sin x)) volume 0 (Real.pi / 2) := by
  have hdom : IntervalIntegrable
      (fun x : ℝ => |Real.log (2 / Real.pi)| + |Real.log x|) volume 0 (Real.pi / 2) :=
    intervalIntegrable_const.add (by simpa only [Real.norm_eq_abs] using
      (intervalIntegral.intervalIntegrable_log' (a := 0) (b := Real.pi / 2)).norm)
  apply hdom.mono_fun'
  · exact (Real.measurable_log.comp Real.continuous_sin.measurable).aestronglyMeasurable
  · filter_upwards [ae_restrict_mem measurableSet_uIoc] with x hx
    rw [uIoc_of_le (by positivity)] at hx
    have hs : 0 < Real.sin x := Real.sin_pos_of_pos_of_lt_pi hx.1 (by
      have := Real.pi_pos
      linarith [hx.2])
    have hl := Real.log_le_log (show 0 < 2 / Real.pi * x from
      mul_pos (by positivity) hx.1)
      (Real.mul_le_sin hx.1.le hx.2)
    rw [Real.log_mul (by positivity) (ne_of_gt hx.1)] at hl
    rw [Real.norm_eq_abs, abs_of_nonpos (Real.log_nonpos hs.le (Real.sin_le_one x))]
    linarith [neg_le_abs (Real.log (2 / Real.pi)), neg_le_abs (Real.log x)]

private theorem log_cos_half_integrable :
    IntervalIntegrable (fun x => Real.log (Real.cos x)) volume 0 (Real.pi / 2) := by
  simpa only [sub_zero, sub_self, Real.sin_pi_div_two_sub] using
    (log_sin_half_integrable.comp_sub_left (Real.pi / 2)).symm

private theorem log_sin_integrable_zero_pi :
    IntervalIntegrable (fun x => Real.log (Real.sin x)) volume 0 Real.pi := by
  have hi := (log_sin_half_integrable.comp_sub_left Real.pi).symm
  simp only [sub_zero, Real.sin_pi_sub] at hi
  rw [show Real.pi - Real.pi / 2 = Real.pi / 2 by ring] at hi
  exact log_sin_half_integrable.trans hi

private theorem log_cos_half_integral :
    (∫ x in (0 : ℝ)..Real.pi / 2, Real.log (Real.cos x)) =
      ∫ x in (0 : ℝ)..Real.pi / 2, Real.log (Real.sin x) := by
  have h := intervalIntegral.integral_comp_sub_left
    (fun x => Real.log (Real.sin x)) (a := 0) (b := Real.pi / 2) (Real.pi / 2)
  simpa only [Real.sin_pi_div_two_sub, sub_self, sub_zero] using h

private theorem log_sin_integral_pi_twice_half :
    (∫ x in (0 : ℝ)..Real.pi, Real.log (Real.sin x)) =
      2 * ∫ x in (0 : ℝ)..Real.pi / 2, Real.log (Real.sin x) := by
  have hi := (log_sin_half_integrable.comp_sub_left Real.pi).symm
  simp only [sub_zero, Real.sin_pi_sub] at hi
  rw [show Real.pi - Real.pi / 2 = Real.pi / 2 by ring] at hi
  have he := intervalIntegral.integral_comp_sub_left
    (fun x => Real.log (Real.sin x)) (a := Real.pi / 2) (b := Real.pi) Real.pi
  simp only [Real.sin_pi_sub, sub_self] at he
  rw [show Real.pi - Real.pi / 2 = Real.pi / 2 by ring] at he
  rw [← intervalIntegral.integral_add_adjacent_intervals log_sin_half_integrable hi, he]
  ring

private theorem log_sin_half_integral :
    (∫ x in (0 : ℝ)..Real.pi / 2, Real.log (Real.sin x)) =
      -(Real.pi / 2) * Real.log 2 := by
  have hdouble :
      (∫ x in (0 : ℝ)..Real.pi / 2, Real.log (Real.sin (2*x))) =
      ∫ x in (0 : ℝ)..Real.pi / 2,
        Real.log 2 + Real.log (Real.sin x) + Real.log (Real.cos x) := by
    apply intervalIntegral.integral_congr_ae
    have hne : ∀ᵐ x : ℝ ∂volume, x ≠ Real.pi / 2 := by
      simpa only [mem_singleton_iff] using (countable_singleton (Real.pi / 2)).ae_not_mem volume
    filter_upwards [hne] with x hx hmem
    rw [uIoc_of_le (by positivity)] at hmem
    have hx' : x < Real.pi / 2 := lt_of_le_of_ne hmem.2 hx
    have hs : Real.sin x ≠ 0 := ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hmem.1 (by
      have := Real.pi_pos
      linarith))
    have hc : Real.cos x ≠ 0 := ne_of_gt (Real.cos_pos_of_mem_Ioo ⟨by
      have := Real.pi_pos
      linarith [hmem.1], hx'⟩)
    rw [Real.sin_two_mul, Real.log_mul (mul_ne_zero (by norm_num) hs) hc,
      Real.log_mul (by norm_num) hs]
  rw [intervalIntegral.integral_comp_mul_left (fun x => Real.log (Real.sin x))
    (by norm_num : (2 : ℝ) ≠ 0)] at hdouble
  simp only [mul_zero, show (2 : ℝ) * (Real.pi / 2) = Real.pi by ring,
    smul_eq_mul] at hdouble
  rw [log_sin_integral_pi_twice_half,
    intervalIntegral.integral_add (intervalIntegrable_const.add log_sin_half_integrable)
      log_cos_half_integrable,
    intervalIntegral.integral_add intervalIntegrable_const log_sin_half_integrable,
    intervalIntegral.integral_const, log_cos_half_integral] at hdouble
  simp only [sub_zero, smul_eq_mul] at hdouble
  linarith

private theorem log_sin_periodic :
    Function.Periodic (fun x => Real.log (Real.sin x)) Real.pi := by
  intro x
  simp only [Real.sin_add_pi, Real.log_neg_eq_log]

theorem log_sin_intervalIntegrable (a b : ℝ) :
    IntervalIntegrable (fun x => Real.log (Real.sin x)) volume a b :=
  log_sin_periodic.intervalIntegrable₀ Real.pi_pos log_sin_integrable_zero_pi a b

theorem log_cos_intervalIntegrable (a b : ℝ) :
    IntervalIntegrable (fun x => Real.log (Real.cos x)) volume a b := by
  simpa only [Real.sin_add_pi_div_two, add_sub_cancel_right] using
    (log_sin_intervalIntegrable (a + Real.pi / 2) (b + Real.pi / 2)).comp_add_right
      (Real.pi / 2)

theorem log_sin_integral_zero_pi :
    (∫ x in (0 : ℝ)..Real.pi, Real.log (Real.sin x)) = -Real.pi * Real.log 2 := by
  rw [log_sin_integral_pi_twice_half, log_sin_half_integral]
  ring

theorem log_cos_integral_zero_two_pi :
    (∫ x in (0 : ℝ)..2*Real.pi, Real.log (Real.cos x)) =
      -(2*Real.pi) * Real.log 2 := by
  have hp : Function.Periodic (fun x => Real.log (Real.sin x)) (2*Real.pi) := by
    simpa only [two_smul, ← two_mul] using log_sin_periodic.nsmul 2
  have hshift := intervalIntegral.integral_comp_add_right
    (fun x => Real.log (Real.sin x)) (a := 0) (b := 2*Real.pi) (Real.pi / 2)
  simp only [Real.sin_add_pi_div_two, zero_add] at hshift
  rw [add_comm (2*Real.pi) (Real.pi / 2), hp.intervalIntegral_add_eq (Real.pi / 2) 0,
    zero_add] at hshift
  have htwice := log_sin_periodic.intervalIntegral_add_zsmul_eq 2 0
    log_sin_intervalIntegrable
  simp only [zsmul_eq_mul, Int.cast_ofNat, zero_add] at htwice
  rw [hshift, htwice, log_sin_integral_zero_pi]
  ring

theorem physicalHopping_one (x : ℝ) : physicalHopping 1 x = (Real.cos x : ℂ) := by
  norm_num [physicalHopping, coupling, complementaryCoupling]

theorem physicalHopping_one_log (x : ℝ) :
    Real.log ‖physicalHopping 1 x‖ = Real.log (Real.cos x) := by
  rw [physicalHopping_one, Complex.norm_real, Real.norm_eq_abs, Real.log_abs]

theorem physicalHopping_one_log_integral :
    (∫ t in (0 : ℝ)..1, Real.log ‖physicalHopping 1 (2*Real.pi*t)‖) =
      -Real.log 2 := by
  simp_rw [physicalHopping_one_log]
  rw [intervalIntegral.integral_comp_mul_left (fun x => Real.log (Real.cos x))
    (by positivity : 2*Real.pi ≠ 0)]
  simp only [mul_zero, mul_one, log_cos_integral_zero_two_pi, smul_eq_mul]
  field_simp
  ring

theorem physicalHopping_log_integral_closed {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (∫ t in (0 : ℝ)..1, Real.log ‖physicalHopping r (2*Real.pi*t)‖) =
      -Real.log (1+r^2) := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact physicalHopping_log_integral hr0 hlt
  · simpa only [one_pow, show (1 : ℝ) + 1 = 2 by norm_num] using
      physicalHopping_one_log_integral

theorem cmv_normalization_cancellation_closed {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    Real.log (2*a/((1+a^2)*(1+r^2))) - Real.log (coupling a) -
      (∫ t in (0 : ℝ)..1, Real.log ‖physicalHopping r (2*Real.pi*t)‖) = 0 := by
  rw [physicalHopping_log_integral_closed hr0 hr1]
  unfold coupling
  rw [Real.log_div (by positivity) (by positivity),
    Real.log_div (by positivity) (by positivity),
    Real.log_mul (by positivity : 1+a^2 ≠ 0) (by positivity : 1+r^2 ≠ 0)]
  ring

end UAMO.CMV

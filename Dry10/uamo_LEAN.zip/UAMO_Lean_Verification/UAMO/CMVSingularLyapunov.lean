import UAMO.CMVAELyapunov
import UAMO.CMVSingularHopping

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

local instance singularTransferMatrixMeasurableSpace : MeasurableSpace TransferMatrix :=
  borel TransferMatrix
local instance singularTransferMatrixBorelSpace : BorelSpace TransferMatrix := ⟨rfl⟩

theorem cos_ne_zero_ae : ∀ᵐ x : ℝ ∂volume, Real.cos x ≠ 0 := by
  have hc : (range (fun k : ℤ => (2*(k : ℝ)+1)*Real.pi/2)).Countable := countable_range _
  filter_upwards [hc.ae_not_mem volume] with x hx
  intro h
  obtain ⟨k, hk⟩ := Real.cos_eq_zero_iff.mp h
  exact hx ⟨k, hk.symm⟩

theorem cos_orbit_ne_zero_ae (ω : ℝ) :
    ∀ᵐ x : ℝ ∂volume, ∀ n : ℕ, Real.cos (x+n*ω) ≠ 0 := by
  rw [ae_all_iff]
  intro n
  exact (quasiMeasurePreserving_add_right volume (n*ω)).ae cos_ne_zero_ae

theorem uamoTransfer_one_det {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    {x : ℝ} (hx : Real.cos x ≠ 0) : (uamoTransfer a 1 z x).det = 1 := by
  rw [uamoTransfer, physicalTransfer_det _ _ _ _ _ (ne_of_gt (coupling_pos ha)) hz]
  have hnorm := physicalHopping_normalization 1 x
  rw [show 1 - (oddAlpha 1 x : ℂ)^2 =
    physicalHopping 1 x * star (physicalHopping 1 x) by linear_combination -hnorm]
  rw [physicalHopping_one]
  simp only [Complex.star_def, Complex.conj_ofReal]
  have hxc : (Real.cos x : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hx
  rw [← pow_two, ← mul_pow, inv_mul_cancel₀ hxc, one_pow]

theorem uamoTransfer_one_det_norm_ae {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0) :
    ∀ᵐ x ∂volume, ‖(uamoTransfer a 1 z x).det‖ = 1 := by
  filter_upwards [cos_ne_zero_ae] with x hx
  rw [uamoTransfer_one_det ha hz hx, norm_one]

def singularTransferNumerator (a : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  physicalTransfer (coupling a) (complementaryCoupling a) (Real.sin x) 1 z

theorem continuous_singularTransferNumerator (a : ℝ) (z : ℂ) :
    Continuous (singularTransferNumerator a z) := by
  unfold singularTransferNumerator physicalTransfer
  apply continuous_const.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp <;> fun_prop

theorem singularTransferNumerator_ne_zero {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (x : ℝ) : singularTransferNumerator a z x ≠ 0 := by
  intro h
  have he := congrArg (fun M : TransferMatrix => M 1 1) h
  have hcoupling : (coupling a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (coupling_pos ha).ne'
  simp [singularTransferNumerator, physicalTransfer, hcoupling, hz] at he

theorem transferNorm_pos_of_ne_zero {M : TransferMatrix} (hM : M ≠ 0) :
    0 < transferNorm M := by
  change 0 < ‖M‖
  exact norm_pos_iff.mpr hM

theorem uamoTransfer_one_factor (a : ℝ) (z : ℂ) (x : ℝ) :
    uamoTransfer a 1 z x = (Real.cos x : ℂ)⁻¹ • singularTransferNumerator a z x := by
  have hc : coupling 1 = 1 := by norm_num [coupling]
  simp only [uamoTransfer, physicalHopping_one, oddAlpha, hc, one_mul,
    singularTransferNumerator, physicalTransfer, inv_one, one_smul,
    Complex.star_def, Complex.conj_ofReal]

theorem measurable_uamoTransfer_one (a : ℝ) (z : ℂ) :
    Measurable (uamoTransfer a 1 z) := by
  change Measurable (fun x => uamoTransfer a 1 z x)
  simp_rw [uamoTransfer_one_factor]
  exact ((Complex.continuous_ofReal.comp Real.continuous_cos).measurable.inv).smul
    (continuous_singularTransferNumerator a z).measurable

theorem uamoTransfer_one_logNorm_ae {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0) :
    (fun x => Real.log (transferNorm (uamoTransfer a 1 z x))) =ᵐ[volume]
      (fun x => Real.log (transferNorm (singularTransferNumerator a z x)) -
        Real.log (Real.cos x)) := by
  filter_upwards [cos_ne_zero_ae] with x hx
  have hn := transferNorm_pos_of_ne_zero (singularTransferNumerator_ne_zero ha hz x)
  change 0 < ‖singularTransferNumerator a z x‖ at hn
  rw [uamoTransfer_one_factor]
  change Real.log ‖(Real.cos x : ℂ)⁻¹ • singularTransferNumerator a z x‖ = _
  rw [norm_smul, norm_inv, Complex.norm_real, Real.norm_eq_abs,
    Real.log_mul (inv_ne_zero (abs_ne_zero.mpr hx)) hn.ne', Real.log_inv,
    Real.log_abs]
  change -Real.log (Real.cos x) + Real.log (transferNorm (singularTransferNumerator a z x)) = _
  ring

theorem uamoTransfer_one_logNorm_integrable {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log (transferNorm (uamoTransfer a 1 z x)))
      volume s t := by
  have hc : Continuous (fun x => Real.log (transferNorm (singularTransferNumerator a z x))) :=
    (continuous_transferNorm.comp (continuous_singularTransferNumerator a z)).log
      (fun x => (transferNorm_pos_of_ne_zero (singularTransferNumerator_ne_zero ha hz x)).ne')
  exact ((hc.intervalIntegrable (μ := volume) s t).sub (log_cos_intervalIntegrable s t)).congr
    (ae_restrict_of_ae (uamoTransfer_one_logNorm_ae ha hz).symm)

theorem uamoTransfer_one_product_det_norm_ae {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (ω : ℝ) (n : ℕ) :
    ∀ᵐ x ∂volume, ‖(transferProduct (uamoTransfer a 1 z) ω x n).det‖ = 1 :=
  transferProduct_det_norm_ae _ (uamoTransfer_one_det_norm_ae ha hz) ω n

theorem uamoTransfer_one_product_log_integrable {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (ω : ℝ) (n : ℕ) (s t : ℝ) :
    IntervalIntegrable (fun x => transferLogNorm (uamoTransfer a 1 z) ω x n) volume s t :=
  transferLogNorm_intervalIntegrable_ae _ (measurable_uamoTransfer_one a z)
    (uamoTransfer_one_det_norm_ae ha hz) (uamoTransfer_one_logNorm_integrable ha hz) ω n s t

theorem uamoTransfer_one_logAverage_subadditive {a : ℝ} (ha : 0 < a)
    {z : ℂ} (hz : z ≠ 0) (ω : ℝ) :
    Subadditive (transferLogAverage (uamoTransfer a 1 z) ω) :=
  transferLogAverage_subadditive_ae _ (measurable_uamoTransfer_one a z)
    (uamoTransfer_periodic a 1 z) (uamoTransfer_one_det_norm_ae ha hz)
    (uamoTransfer_one_logNorm_integrable ha hz) ω

theorem uamoLyapunov_one_nonneg {a : ℝ} (ha : 0 < a) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    0 ≤ uamoLyapunov a 1 ω z :=
  lyapunov_nonneg_ae _ (uamoTransfer_one_det_norm_ae ha hz) ω

theorem tendsto_uamoFiniteLyapunov_one {a : ℝ} (ha : 0 < a) (ω : ℝ)
    {z : ℂ} (hz : z ≠ 0) :
    Tendsto (finiteLyapunov (uamoTransfer a 1 z) ω) atTop (𝓝 (uamoLyapunov a 1 ω z)) :=
  tendsto_finiteLyapunov_ae _ (measurable_uamoTransfer_one a z) (uamoTransfer_periodic a 1 z)
    (uamoTransfer_one_det_norm_ae ha hz) (uamoTransfer_one_logNorm_integrable ha hz) ω

end UAMO.CMV

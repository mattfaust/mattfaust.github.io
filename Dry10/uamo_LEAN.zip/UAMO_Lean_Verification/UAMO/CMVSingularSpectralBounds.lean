import UAMO.CMVSingularSpectralRegular
import UAMO.CMVSingularThoulessLimit
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem continuous_singularTransferNumerator_spectral_phase (a : ℝ) :
    Continuous (fun p : NonzeroEnergy × ℝ => singularTransferNumerator a p.1.val p.2) := by
  have hz : Continuous (fun p : NonzeroEnergy × ℝ => p.1.val) := continuous_subtype_val.comp continuous_fst
  have hzi := hz.inv₀ (fun p => p.1.property)
  unfold singularTransferNumerator physicalTransfer
  apply continuous_const.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp <;> fun_prop

theorem continuous_singularNumeratorProduct_spectral_phase (a ω : ℝ) (n : ℕ) :
    Continuous (fun p : NonzeroEnergy × ℝ =>
      transferProduct (singularTransferNumerator a p.1.val) ω p.2 n) := by
  induction n with
  | zero => exact continuous_const
  | succ n ih =>
    exact ((continuous_singularTransferNumerator_spectral_phase a).comp
      (continuous_fst.prodMk (continuous_snd.add continuous_const))).mul ih

theorem singular_transferProduct_factor (a ω x : ℝ) (z : ℂ) (n : ℕ) :
    transferProduct (uamoTransfer a 1 z) ω x n =
      (∏ j ∈ Finset.range n, (Real.cos (x+j*ω) : ℂ)⁻¹) •
        transferProduct (singularTransferNumerator a z) ω x n := by
  rw [show uamoTransfer a 1 z = fun y => (Real.cos y : ℂ)⁻¹ • singularTransferNumerator a z y
    from funext (uamoTransfer_one_factor a z)]
  exact transferProduct_scalar_gauge _ _ ω x n

def singularLogDenominator (ω : ℝ) (n : ℕ) (x : ℝ) : ℝ :=
  ∑ j ∈ Finset.range n, Real.log (Real.cos (x+j*ω))

theorem singularLogDenominator_integrable (ω : ℝ) (n : ℕ) (s t : ℝ) :
    IntervalIntegrable (singularLogDenominator ω n) volume s t := by
  convert IntervalIntegrable.sum (Finset.range n)
    (f := fun j x => Real.log (Real.cos (x+j*ω)))
    (fun j _ => log_cos_shift_integrable (j*ω) s t) using 1
  ext x
  simp only [singularLogDenominator, Finset.sum_apply]

theorem transferLogNorm_one_le_numerator_bound {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (ω x : ℝ) (n : ℕ) (hx : ∀ k : ℕ, Real.cos (x+k*ω) ≠ 0)
    (B : ℝ) (hB : 0 < B)
    (hnum : transferNorm (transferProduct (singularTransferNumerator a z) ω x n) ≤ B) :
    transferLogNorm (uamoTransfer a 1 z) ω x n ≤ Real.log B-singularLogDenominator ω n x := by
  let q := ∏ j ∈ Finset.range n, (Real.cos (x+j*ω) : ℂ)⁻¹
  have hq : q ≠ 0 := Finset.prod_ne_zero_iff.mpr
    (fun j _ => inv_ne_zero (Complex.ofReal_ne_zero.mpr (hx j)))
  have hpos : 0 < transferNorm (transferProduct (uamoTransfer a 1 z) ω x n) :=
    zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _
      (uamoTransfer_one_product_det_norm_at ha hz ω x n hx))
  have hn : transferNorm (transferProduct (uamoTransfer a 1 z) ω x n) ≤ ‖q‖*B := by
    rw [singular_transferProduct_factor, transferNorm_smul]
    exact mul_le_mul_of_nonneg_left hnum (norm_nonneg _)
  have hlog := Real.log_le_log hpos hn
  rw [Real.log_mul (norm_ne_zero_iff.mpr hq) hB.ne'] at hlog
  have hqlog : Real.log ‖q‖ = -singularLogDenominator ω n x := by
    dsimp only [q]
    rw [norm_prod, Real.log_prod _ _
      (fun j _ => norm_ne_zero_iff.mpr (inv_ne_zero (Complex.ofReal_ne_zero.mpr (hx j))))]
    simp only [norm_inv, Real.log_inv, Complex.norm_real, Real.norm_eq_abs,
      Real.log_abs, Finset.sum_neg_distrib, singularLogDenominator]
  rw [hqlog] at hlog
  exact hlog.trans_eq (by ring)

theorem exists_singular_product_log_bound_compact {a : ℝ} (ha : 0 < a)
    (ω : ℝ) (n : ℕ) (K : Set NonzeroEnergy) (hK : IsCompact K) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ z ∈ K, ∀ x ∈ Icc (0 : ℝ) (2*Real.pi),
      (∀ k : ℕ, Real.cos (x+k*ω) ≠ 0) →
      ‖transferLogNorm (uamoTransfer a 1 z.val) ω x n‖ ≤ C-singularLogDenominator ω n x := by
  have hfun : Continuous (fun p : NonzeroEnergy × ℝ =>
      transferNorm (transferProduct (singularTransferNumerator a p.1.val) ω p.2 n)) :=
    continuous_transferNorm.comp (continuous_singularNumeratorProduct_spectral_phase a ω n)
  have hb := (hK.prod (isCompact_Icc (a := (0 : ℝ)) (b := 2*Real.pi))).bddAbove_image hfun.continuousOn
  obtain ⟨B,hB⟩ := hb
  let D := max 1 B
  have hD : 1 ≤ D := le_max_left _ _
  refine ⟨Real.log D, Real.log_nonneg hD, ?_⟩
  intro z hz x hx hreg
  have hnonneg : 0 ≤ transferLogNorm (uamoTransfer a 1 z.val) ω x n :=
    Real.log_nonneg (one_le_transferNorm_of_det_norm _
      (uamoTransfer_one_product_det_norm_at ha z.property ω x n hreg))
  rw [Real.norm_eq_abs, abs_of_nonneg hnonneg]
  have hbz : transferNorm (transferProduct (singularTransferNumerator a z.val) ω x n) ≤ B :=
    hB ⟨(z,x), ⟨hz,hx⟩, rfl⟩
  exact transferLogNorm_one_le_numerator_bound ha z.property ω x n hreg D
    (zero_lt_one.trans_le hD) (hbz.trans (le_max_right _ _))

end UAMO.CMV

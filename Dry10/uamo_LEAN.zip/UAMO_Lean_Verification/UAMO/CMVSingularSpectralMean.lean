import UAMO.CMVSingularSpectralMeanFinite
import UAMO.CMVSingularSpectralUSC
import UAMO.CMVSpectralMean
import UAMO.CirclePotentialMean

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set CircleDOS
open scoped Topology Matrix.L2OpNorm

local instance singularMeanMatrixMeasurableSpace : MeasurableSpace TransferMatrix :=
  borel TransferMatrix
local instance singularMeanMatrixBorelSpace : BorelSpace TransferMatrix := ⟨rfl⟩

theorem measurable_transferLogNorm_spectralCircle_phase_one
    (a ω : ℝ) (n : ℕ) (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Measurable (fun p : ℝ × ℝ =>
      transferLogNorm (uamoTransfer a 1 (c+R*logFourierChar 1 p.2)) ω p.1 n) := by
  have hn := (continuous_singularNumeratorProduct_spectral_phase a ω n).comp
    (((continuous_nonzeroSpectralCircle c R hR).comp continuous_snd).prodMk continuous_fst)
  have hq : Measurable (fun p : ℝ × ℝ =>
      ∏ j ∈ Finset.range n, (Real.cos (p.1+j*ω) : ℂ)⁻¹) := by
    apply Finset.measurable_prod
    intro j _
    exact ((Complex.continuous_ofReal.comp
      (Real.continuous_cos.comp (continuous_fst.add continuous_const))).measurable).inv
  simp_rw [transferLogNorm, singular_transferProduct_factor]
  exact Real.measurable_log.comp (continuous_transferNorm.measurable.comp (hq.smul hn.measurable))

theorem integrable_transferLogNorm_spectralCircle_phase_one {a : ℝ}
    (ha : 0 < a) (ω : ℝ) (n : ℕ) (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Integrable (fun p : ℝ × ℝ =>
      transferLogNorm (uamoTransfer a 1 (c+R*logFourierChar 1 p.2)) ω p.1 n)
      ((volume.restrict (Ioc (0 : ℝ) (2*Real.pi))).prod angularParameterMeasure) := by
  let K := (nonzeroSpectralCircle c R hR) '' Icc (0 : ℝ) 1
  obtain ⟨C, _, hC⟩ := exists_singular_product_log_bound_compact ha ω n K
    (isCompact_Icc.image (continuous_nonzeroSpectralCircle c R hR))
  have hm := (measurable_transferLogNorm_spectralCircle_phase_one a ω n c R hR).aestronglyMeasurable
    (μ := (volume.restrict (Ioc (0 : ℝ) (2*Real.pi))).prod angularParameterMeasure)
  apply (integrable_prod_iff hm).mpr
  constructor
  · filter_upwards [ae_restrict_of_ae (cos_orbit_ne_zero_ae ω)] with x hx
    exact (continuous_transferLogNorm_spectralCircle_one ha ω x n c R hR hx).intervalIntegrable
      (μ := volume) 0 1 |>.1
  · apply ((integrable_const C).sub (singularLogDenominator_integrable ω n 0 (2*Real.pi)).1).mono'
      hm.norm.integral_prod_right'
    filter_upwards [ae_restrict_of_ae (cos_orbit_ne_zero_ae ω),
      ae_restrict_mem measurableSet_Ioc] with x hx hxi
    rw [Real.norm_eq_abs, abs_of_nonneg (integral_nonneg (fun _ => norm_nonneg _))]
    calc
      _ ≤ ∫ _t, (C-singularLogDenominator ω n x) ∂angularParameterMeasure := by
        apply integral_mono_ae
        · exact ((continuous_transferLogNorm_spectralCircle_one ha ω x n c R hR hx).intervalIntegrable
            (μ := volume) 0 1).1.norm
        · exact integrable_const _
        · filter_upwards [show ∀ᵐ t ∂angularParameterMeasure, t ∈ Ioc (0 : ℝ) 1 from
            ae_restrict_mem measurableSet_Ioc] with t ht
          exact hC (nonzeroSpectralCircle c R hR t)
            (mem_image_of_mem _ ⟨ht.1.le, ht.2⟩) x ⟨hxi.1.le,hxi.2⟩ hx
      _ = _ := by simp

theorem finiteLyapunov_spectral_submean_one {a : ℝ} (ha : 0 < a)
    (ω : ℝ) {n : ℕ} (hn : 1 ≤ n) (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    finiteLyapunov (uamoTransfer a 1 c) ω n ≤ Real.log 4 / (n : ℝ) +
      ∫ t in (0 : ℝ)..1,
        finiteLyapunov (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω n := by
  have hc : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  let f := fun x t => transferLogNorm (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω x n
  have hp := integrable_transferLogNorm_spectralCircle_phase_one ha ω n c R hR
  have hi : IntervalIntegrable (fun x => ∫ t in (0 : ℝ)..1, f x t)
      volume (0 : ℝ) (2*Real.pi) := by
    apply (intervalIntegrable_iff_integrableOn_Ioc_of_le (by positivity)).mpr
    simpa only [integral_angularParameterMeasure] using hp.integral_prod_left
  have havg := intervalIntegral.integral_mono_ae (μ := volume) (by positivity : (0 : ℝ) ≤ 2*Real.pi)
    (uamoTransfer_one_product_log_integrable ha hc ω n 0 (2*Real.pi))
    (intervalIntegrable_const.add hi)
    (by filter_upwards [cos_orbit_ne_zero_ae ω] with x hx
        exact transferLogNorm_spectral_submean_one ha ω x n c R hR hx)
  have hswap : (∫ x in (0 : ℝ)..(2*Real.pi), ∫ t in (0 : ℝ)..1, f x t) =
      ∫ t in (0 : ℝ)..1, ∫ x in (0 : ℝ)..(2*Real.pi), f x t := by
    have h := integral_integral_swap (μ := volume.restrict (Ioc (0 : ℝ) (2*Real.pi)))
      (ν := angularParameterMeasure) (f := f) hp
    simpa only [integral_angularParameterMeasure,
      intervalIntegral.integral_of_le (by positivity : (0 : ℝ) ≤ 2*Real.pi)] using h
  rw [intervalIntegral.integral_add intervalIntegrable_const hi,
    intervalIntegral.integral_const, hswap] at havg
  simp only [sub_zero, smul_eq_mul] at havg
  have hd := div_le_div_of_nonneg_right
    (div_le_div_of_nonneg_right havg (by positivity : (0 : ℝ) ≤ 2*Real.pi))
    (Nat.cast_nonneg n)
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt (lt_of_lt_of_le Nat.zero_lt_one hn))
  have hpi : (2 * Real.pi : ℝ) ≠ 0 := by positivity
  have heq : ((2*Real.pi)*Real.log 4 +
      (∫ t in (0 : ℝ)..1, ∫ x in (0 : ℝ)..(2*Real.pi), f x t)) / (2*Real.pi) / (n : ℝ) =
      Real.log 4 / (n : ℝ) + ∫ t in (0 : ℝ)..1,
        finiteLyapunov (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω n := by
    simp only [finiteLyapunov, transferLogAverage]
    rw [intervalIntegral.integral_div, intervalIntegral.integral_div]
    dsimp only [f]
    field_simp
    ring
  exact hd.trans_eq heq

theorem finiteLyapunov_one_le_first {a : ℝ} (ha : 0 < a) (ω : ℝ)
    {z : ℂ} (hz : z ≠ 0) (n : ℕ) :
    finiteLyapunov (uamoTransfer a 1 z) ω n ≤ finiteLyapunov (uamoTransfer a 1 z) ω 1 := by
  by_cases hn : n = 0
  · simp only [hn, finiteLyapunov, transferLogAverage_zero, Nat.cast_zero, div_zero,
      Nat.cast_one, div_one]
    have h := finiteLyapunov_nonneg_ae _ (uamoTransfer_one_det_norm_ae ha hz) ω 1
    simpa only [finiteLyapunov, Nat.cast_one, div_one] using h
  have h := (uamoTransfer_one_logAverage_subadditive ha hz ω).apply_mul_add_le n 1 0
  simp only [mul_one, add_zero, transferLogAverage_zero] at h
  simp only [finiteLyapunov, Nat.cast_one, div_one]
  exact (div_le_iff₀ (by exact_mod_cast Nat.pos_of_ne_zero hn)).mpr (by simpa only [mul_comm] using h)

theorem continuous_uamoFiniteLyapunov_spectralCircle_one {a : ℝ}
    (ha : 0 < a) (ω : ℝ) (n : ℕ) (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Continuous (fun t => finiteLyapunov (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω n) := by
  have hh := (continuous_uamoFiniteLyapunov_one_nonzero ha ω n).comp
    (continuous_nonzeroSpectralCircle c R hR)
  simpa only [Function.comp_def, nonzeroSpectralCircle] using hh

theorem tendsto_uamoFiniteLyapunov_spectralMean_one {a : ℝ}
    (ha : 0 < a) (ω : ℝ) (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1,
      finiteLyapunov (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω n) atTop
      (𝓝 (∫ t in (0 : ℝ)..1, uamoLyapunov a 1 ω (c+R*logFourierChar 1 t))) := by
  let b := fun t => finiteLyapunov (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω 1
  apply intervalIntegral.tendsto_integral_filter_of_dominated_convergence b
  · exact Eventually.of_forall (fun n =>
      (continuous_uamoFiniteLyapunov_spectralCircle_one ha ω n c R hR).aestronglyMeasurable)
  · apply Eventually.of_forall
    intro n
    exact Eventually.of_forall (fun t _ => by
      have hw := CircleDOS.circle_affine_ne_zero c R hR t
      rw [Real.norm_eq_abs, abs_of_nonneg
        (finiteLyapunov_nonneg_ae _ (uamoTransfer_one_det_norm_ae ha hw) ω n)]
      exact finiteLyapunov_one_le_first ha ω hw n)
  · exact (continuous_uamoFiniteLyapunov_spectralCircle_one ha ω 1 c R hR).intervalIntegrable 0 1
  · exact Eventually.of_forall (fun t _ => tendsto_uamoFiniteLyapunov_one ha ω
      (CircleDOS.circle_affine_ne_zero c R hR t))

theorem uamoLyapunov_spectral_submean_one {a : ℝ}
    (ha : 0 < a) (ω : ℝ) (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    uamoLyapunov a 1 ω c ≤ ∫ t in (0 : ℝ)..1,
      uamoLyapunov a 1 ω (c+R*logFourierChar 1 t) := by
  have hc : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  have ht := (tendsto_const_div_atTop_nhds_zero_nat (Real.log 4)).add
    (tendsto_uamoFiniteLyapunov_spectralMean_one ha ω c R hR)
  simp only [zero_add] at ht
  apply le_of_tendsto_of_tendsto (tendsto_uamoFiniteLyapunov_one ha ω hc) ht
  filter_upwards [eventually_ge_atTop (1 : ℕ)] with n hn
  exact finiteLyapunov_spectral_submean_one ha ω hn c R hR

theorem uamoLyapunov_spectral_submean_closed {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    uamoLyapunov a r ω c ≤ ∫ t in (0 : ℝ)..1,
      uamoLyapunov a r ω (c+R*logFourierChar 1 t) := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact uamoLyapunov_spectral_submean ha hr hlt ω c R hR
  · exact uamoLyapunov_spectral_submean_one ha ω c R hR

end UAMO.CMV

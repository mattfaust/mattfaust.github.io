import UAMO.CMVSpectralMeanFinite
import UAMO.CMVSingularSpectralRegular

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Polynomial Set CircleDOS
open scoped Topology Matrix.L2OpNorm

theorem continuous_transferLogNorm_spectralCircle_one {a : ℝ}
    (ha : 0 < a) (ω x : ℝ) (n : ℕ) (c R : ℂ) (hR : ‖R‖ < ‖c‖)
    (hx : ∀ k : ℕ, Real.cos (x+k*ω) ≠ 0) :
    Continuous (fun t => transferLogNorm (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω x n) := by
  have hh := (continuous_transferLogNorm_one_spectral ha ω x n hx).comp
    (continuous_nonzeroSpectralCircle c R hR)
  simpa only [Function.comp_def, nonzeroSpectralCircle] using hh

theorem transferLogNorm_spectral_submean_one {a : ℝ}
    (ha : 0 < a) (ω x : ℝ) (n : ℕ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) (hx : ∀ k : ℕ, Real.cos (x+k*ω) ≠ 0) :
    transferLogNorm (uamoTransfer a 1 c) ω x n ≤ Real.log 4 +
      ∫ t in (0 : ℝ)..1,
        transferLogNorm (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω x n := by
  have hc : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  let M := transferProduct (uamoTransfer a 1 c) ω x n
  obtain ⟨i,j,hij,hM⟩ := exists_transfer_entry_norm_lower M
    (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _
      (uamoTransfer_one_product_det_norm_at ha hc ω x n hx)))
  let P := spectralTransferPolynomialProduct a 1 ω x n i j
  have hPc : P.eval c = c^n * M i j := spectralTransferPolynomialProduct_entry a 1 ω x hc n i j
  have hPcn : P.eval c ≠ 0 := by rw [hPc]; exact mul_ne_zero (pow_ne_zero _ hc) hij
  have hlogM : transferLogNorm (uamoTransfer a 1 c) ω x n ≤
      Real.log 4 + Real.log ‖P.eval c‖ - (n : ℝ)*Real.log ‖c‖ := by
    have h := Real.log_le_log
      (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _
      (uamoTransfer_one_product_det_norm_at ha hc ω x n hx))) hM
    rw [Real.log_mul (by norm_num : (4 : ℝ) ≠ 0) (norm_ne_zero_iff.mpr hij)] at h
    have hp : Real.log ‖P.eval c‖ = (n : ℝ)*Real.log ‖c‖ + Real.log ‖M i j‖ := by
      rw [hPc, norm_mul, norm_pow, Real.log_mul (pow_ne_zero _ (norm_ne_zero_iff.mpr hc))
        (norm_ne_zero_iff.mpr hij), Real.log_pow]
    change Real.log (transferNorm M) ≤ _
    linarith
  have hJ := CircleDOS.polynomial_circle_log_ge_center P c R hPcn
  let f := fun t => transferLogNorm (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω x n
  let g := fun t => (n : ℝ)*Real.log ‖c+R*logFourierChar 1 t‖
  have hf : Continuous f := continuous_transferLogNorm_spectralCircle_one ha ω x n c R hR hx
  have hg : Continuous g := continuous_const.mul
    ((continuous_const.add (continuous_const.mul (logFourierChar_continuous 1))).norm.log
      (fun t => norm_ne_zero_iff.mpr (CircleDOS.circle_affine_ne_zero c R hR t)))
  have hae : (fun t => Real.log ‖P.eval (c+R*logFourierChar 1 t)‖) ≤ᵐ[volume]
      (fun t => g t + f t) := by
    filter_upwards [polynomial_circle_eval_ne_zero_ae_center P c R hPcn] with t ht
    have hw := CircleDOS.circle_affine_ne_zero c R hR t
    have he : P.eval (c+R*logFourierChar 1 t) = (c+R*logFourierChar 1 t)^n *
        (transferProduct (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω x n) i j :=
      spectralTransferPolynomialProduct_entry a 1 ω x hw n i j
    have hentry : (transferProduct (uamoTransfer a 1 (c+R*logFourierChar 1 t)) ω x n) i j ≠ 0 := by
      intro hz
      rw [he, hz, mul_zero] at ht
      exact ht rfl
    rw [he, norm_mul, norm_pow,
      Real.log_mul (pow_ne_zero _ (norm_ne_zero_iff.mpr hw)) (norm_ne_zero_iff.mpr hentry), Real.log_pow]
    exact add_le_add_left (Real.log_le_log (norm_pos_iff.mpr hentry)
      (transferNorm_entry_le _ i j)) _
  have hmean := intervalIntegral.integral_mono_ae (by norm_num : (0 : ℝ) ≤ 1)
    (CircleDOS.polynomial_circle_log_integrable_center P c R hPcn 0 1)
    ((hg.add hf).intervalIntegrable 0 1) hae
  have hgmean : (∫ t in (0 : ℝ)..1, g t) = (n : ℝ)*Real.log ‖c‖ := by
    dsimp only [g]
    rw [intervalIntegral.integral_const_mul, CircleDOS.integral_circle_log_of_radius_lt c R hR]
  rw [intervalIntegral.integral_add (hg.intervalIntegrable _ _) (hf.intervalIntegrable _ _),
    hgmean] at hmean
  linarith

end UAMO.CMV

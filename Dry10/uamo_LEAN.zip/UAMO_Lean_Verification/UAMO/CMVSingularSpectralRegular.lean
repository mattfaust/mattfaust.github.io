import UAMO.CMVLyapunovSpectralUSC
import UAMO.CMVSingularCellConjugacy

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem uamoTransfer_one_product_det_norm_at {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (ω x : ℝ) (n : ℕ) (hx : ∀ k : ℕ, Real.cos (x+k*ω) ≠ 0) :
    ‖(transferProduct (uamoTransfer a 1 z) ω x n).det‖ = 1 := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ, Matrix.det_mul, norm_mul,
      uamoTransfer_one_det ha hz (hx n), norm_one, one_mul, ih]

theorem continuous_uamoTransfer_one_spectral (a x : ℝ) :
    Continuous (fun z : NonzeroEnergy => uamoTransfer a 1 z.val x) := by
  have hz : Continuous (fun z : NonzeroEnergy => z.val) := continuous_subtype_val
  have hzi := hz.inv₀ (fun z => z.property)
  unfold uamoTransfer physicalTransfer
  apply continuous_const.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp <;> fun_prop

theorem continuous_transferProduct_one_spectral (a ω x : ℝ) (n : ℕ) :
    Continuous (fun z : NonzeroEnergy => transferProduct (uamoTransfer a 1 z.val) ω x n) := by
  induction n with
  | zero => exact continuous_const
  | succ n ih => exact (continuous_uamoTransfer_one_spectral a (x+n*ω)).mul ih

theorem continuous_transferLogNorm_one_spectral {a : ℝ} (ha : 0 < a)
    (ω x : ℝ) (n : ℕ) (hx : ∀ k : ℕ, Real.cos (x+k*ω) ≠ 0) :
    Continuous (fun z : NonzeroEnergy => transferLogNorm (uamoTransfer a 1 z.val) ω x n) := by
  apply (continuous_transferNorm.comp (continuous_transferProduct_one_spectral a ω x n)).log
  intro z
  exact (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _
    (uamoTransfer_one_product_det_norm_at ha z.property ω x n hx))).ne'

end UAMO.CMV

import UAMO.CMVSingularSpectralBounds

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

local instance singularSpectralMatrixMeasurableSpace : MeasurableSpace TransferMatrix := borel _
local instance singularSpectralMatrixBorelSpace : BorelSpace TransferMatrix := ⟨rfl⟩
local instance singularSpectralNonzeroLocallyCompact : LocallyCompactSpace NonzeroEnergy :=
  (isOpen_ne : IsOpen {z : ℂ | z ≠ 0}).locallyCompactSpace

theorem continuous_uamoFiniteLyapunov_one_nonzero {a : ℝ}
    (ha : 0 < a) (ω : ℝ) (n : ℕ) :
    Continuous (fun z : NonzeroEnergy => finiteLyapunov (uamoTransfer a 1 z.val) ω n) := by
  apply continuous_iff_continuousAt.mpr
  intro z
  obtain ⟨K,hK,hKz⟩ := exists_compact_mem_nhds z
  obtain ⟨C,_,hC⟩ := exists_singular_product_log_bound_compact ha ω n K hK
  have hi : ContinuousAt (fun w : NonzeroEnergy =>
      ∫ x in (0 : ℝ)..(2*Real.pi), transferLogNorm (uamoTransfer a 1 w.val) ω x n) z := by
    apply intervalIntegral.continuousAt_of_dominated_interval
      (bound := fun x => C-singularLogDenominator ω n x)
    · exact Eventually.of_forall (fun w =>
        (measurable_transferLogNorm _ (measurable_uamoTransfer_one a w.val) ω n).aestronglyMeasurable)
    · filter_upwards [hKz] with w hw
      filter_upwards [cos_orbit_ne_zero_ae ω] with x hx hmem
      rw [uIoc_of_le (by positivity : (0 : ℝ) ≤ 2*Real.pi)] at hmem
      exact hC w hw x ⟨hmem.1.le,hmem.2⟩ hx
    · exact intervalIntegrable_const.sub (singularLogDenominator_integrable ω n 0 (2*Real.pi))
    · filter_upwards [cos_orbit_ne_zero_ae ω] with x hx _
      exact (continuous_transferLogNorm_one_spectral ha ω x n hx).continuousAt
  exact (hi.div_const (2*Real.pi)).div_const (n : ℝ)

theorem continuousAt_uamoFiniteLyapunov_one {a : ℝ} (ha : 0 < a)
    (ω : ℝ) (n : ℕ) {z : ℂ} (hz : z ≠ 0) :
    ContinuousAt (fun w : ℂ => finiteLyapunov (uamoTransfer a 1 w) ω n) z := by
  apply ContinuousWithinAt.continuousAt (s := {w : ℂ | w ≠ 0})
  · exact (continuousOn_iff_continuous_restrict.mpr
      (continuous_uamoFiniteLyapunov_one_nonzero ha ω n)) z hz
  · exact isOpen_ne.mem_nhds hz

theorem lyapunov_le_finite_one {a : ℝ} (ha : 0 < a) (ω : ℝ) {z : ℂ} (hz : z ≠ 0)
    {n : ℕ} (hn : 1 ≤ n) :
    uamoLyapunov a 1 ω z ≤ finiteLyapunov (uamoTransfer a 1 z) ω n :=
  csInf_le ((finiteLyapunov_bddBelow_ae _ (uamoTransfer_one_det_norm_ae ha hz) ω).mono
    (image_subset_range _ _)) ⟨n,hn,rfl⟩

theorem upperSemicontinuousAt_uamoLyapunov_one {a : ℝ} (ha : 0 < a)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) : UpperSemicontinuousAt (uamoLyapunov a 1 ω) z := by
  intro b hb
  obtain ⟨v,⟨n,hn,rfl⟩,hnb⟩ := exists_lt_of_csInf_lt
    (show ((fun n => finiteLyapunov (uamoTransfer a 1 z) ω n) '' Ici 1).Nonempty from
      ⟨finiteLyapunov (uamoTransfer a 1 z) ω 1,1,by simp,rfl⟩) hb
  have hnz : ∀ᶠ w : ℂ in 𝓝 z, w ≠ 0 := isOpen_ne.mem_nhds hz
  have hnear : ∀ᶠ w : ℂ in 𝓝 z, finiteLyapunov (uamoTransfer a 1 w) ω n < b :=
    (continuousAt_uamoFiniteLyapunov_one ha ω n hz).tendsto.eventually (Iio_mem_nhds hnb)
  filter_upwards [hnz,hnear] with w hw hwb
  exact (lyapunov_le_finite_one ha ω hw hn).trans_lt hwb

theorem upperSemicontinuousAt_uamoLyapunov_closed {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    UpperSemicontinuousAt (uamoLyapunov a r ω) z := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact upperSemicontinuousAt_uamoLyapunov ha hr hlt ω hz
  · exact upperSemicontinuousAt_uamoLyapunov_one ha ω hz

end UAMO.CMV

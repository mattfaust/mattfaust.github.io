import UAMO.CMVSingularThoulessLimit
import UAMO.CMVEmpiricalDOSConvergence

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter CircleDOS PhysicalDOS
open scoped Topology

theorem phaseMean_sub_integrable (f g : ℝ → ℝ)
    (hf : IntervalIntegrable f volume 0 (2*Real.pi))
    (hg : IntervalIntegrable g volume 0 (2*Real.pi)) :
    phaseMean (fun x => f x-g x) = phaseMean f-phaseMean g := by
  rw [phaseMean, intervalIntegral.integral_sub hf hg]
  exact sub_div _ _ _

theorem phaseMean_finiteHopping_log_one (n : ℕ) (ω : ℝ) :
    phaseMean (fun x => (∑ j : ZMod (n+1), Real.log ‖physicalHopping 1 (x+j.val*ω)‖) /
      ((n+1 : ℕ) : ℝ)) = -Real.log 2 := by
  unfold phaseMean
  simp_rw [physicalHopping_one_log]
  rw [intervalIntegral.integral_div, intervalIntegral.integral_finset_sum
    (f := fun j : ZMod (n+1) => fun x => Real.log (Real.cos (x+j.val*ω)))
    (fun j _ => log_cos_shift_integrable (j.val*ω) 0 (2*Real.pi))]
  simp only [integral_log_cos_shift, Finset.sum_const, Finset.card_univ,
    ZMod.card, nsmul_eq_mul]
  have hn : ((n+1 : ℕ) : ℝ) ≠ 0 := by positivity
  have hp : (2*Real.pi : ℝ) ≠ 0 := by positivity
  field_simp
  ring

theorem finiteMonodromyLogAverage_eq_spectral_one (n : ℕ) {a : ℝ} (ha : 0 < a)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    finiteMonodromyLogAverage a 1 ω z n = 2*finiteSpectralLogAverage a 1 ω z n -
      Real.log (coupling a)-Real.log ‖z‖+Real.log 2 := by
  let f := fun x => ∫ w, Real.log ‖z-w‖ ∂finiteSpectralMeasure n a 1 ω x
  let g := fun x => Real.log ‖(1-finiteMonodromy n a 1 ω x z).det‖ / ((n+1 : ℕ) : ℝ)
  let h := fun x => (∑ j : ZMod (n+1), Real.log ‖physicalHopping 1 (x+j.val*ω)‖) /
    ((n+1 : ℕ) : ℝ)
  have hf : Continuous f := continuous_finiteSpectralLog n a 1 ω hcircle
  have hfi := hf.intervalIntegrable (μ := volume) 0 (2*Real.pi)
  have hh : IntervalIntegrable h volume 0 (2*Real.pi) :=
    (singular_finiteHopping_log_integrable n ω 0 (2*Real.pi)).div_const _
  have heq : phaseMean g =
      phaseMean (fun x => 2*f x-Real.log (coupling a)-Real.log ‖z‖-h x) := by
    unfold phaseMean
    congr 1
    apply intervalIntegral.integral_congr_ae
    filter_upwards [finiteHoppingRegular_one_ae n ω] with x hx _
    exact finite_monodromy_log_potential_identity_regular n ha ω x hx hz hcircle
  have hmean : phaseMean g =
      2*phaseMean f-Real.log (coupling a)-Real.log ‖z‖-phaseMean h := by
    rw [heq, phaseMean_sub_integrable _ _
      (((hfi.const_mul 2).sub intervalIntegrable_const).sub intervalIntegrable_const) hh,
      phaseMean_sub_integrable _ _ ((hfi.const_mul 2).sub intervalIntegrable_const) intervalIntegrable_const,
      phaseMean_sub_integrable _ _ (hfi.const_mul 2) intervalIntegrable_const,
      phaseMean_const_mul, phaseMean_const, phaseMean_const]
  have hgmean : phaseMean g = finiteMonodromyLogAverage a 1 ω z n := by
    dsimp only [g]
    rw [phaseMean_div_const]
    rfl
  rw [hgmean, show phaseMean h = -Real.log 2 from phaseMean_finiteHopping_log_one n ω] at hmean
  simpa only [finiteSpectralLogAverage, f, sub_neg_eq_add] using hmean

theorem tendsto_finiteSpectralLogAverage_one {a : ℝ} (ha : 0 < a)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Tendsto (finiteSpectralLogAverage a 1 ω z) atTop
      (𝓝 ((uamoLyapunov a 1 ω z+Real.log (coupling a)+Real.log ‖z‖-Real.log 2)/2)) := by
  have h := ((((tendsto_finiteMonodromyLogAverage_one ha ω hz hcircle).add_const
    (Real.log (coupling a))).add_const (Real.log ‖z‖)).sub_const (Real.log 2)).div_const 2
  have heq (n : ℕ) : finiteSpectralLogAverage a 1 ω z n =
      (finiteMonodromyLogAverage a 1 ω z n+Real.log (coupling a)+Real.log ‖z‖-Real.log 2)/2 := by
    have hh := finiteMonodromyLogAverage_eq_spectral_one n ha ω hz hcircle
    linarith
  simpa only [← heq] using h

theorem uamoLyapunov_thouless_one_off_circle {a : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (Φ : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    uamoLyapunov a 1 (2*Real.pi*Φ) z =
      2*(∫ w : ℂ, Real.log ‖z-w‖ ∂physicalUnitaryDOS a 1 Φ ha.le ha1 (by norm_num) le_rfl)-
        Real.log (coupling a)-Real.log ‖z‖+Real.log 2 := by
  have h := tendsto_nhds_unique
    (finiteSpectralLogAverage_tendsto_physical_DOS a 1 Φ ha.le ha1 (by norm_num) le_rfl z hcircle)
    (tendsto_finiteSpectralLogAverage_one ha (2*Real.pi*Φ) hz hcircle)
  linarith

theorem uamoLyapunov_thouless_off_circle_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    uamoLyapunov a r (2*Real.pi*Φ) z =
      2*(∫ w : ℂ, Real.log ‖z-w‖ ∂physicalUnitaryDOS a r Φ ha.le ha1 hr hr1)-
        Real.log (coupling a)-Real.log ‖z‖+Real.log (1+r^2) := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact uamoLyapunov_thouless_off_circle ha ha1 hr hlt Φ hz hcircle
  · simpa only [one_pow, show (1 : ℝ)+1 = 2 by norm_num] using
      uamoLyapunov_thouless_one_off_circle ha ha1 Φ hz hcircle

end UAMO.CMV

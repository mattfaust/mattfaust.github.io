import UAMO.CMVSingularThoulessFinite

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Set
open scoped Matrix.L2OpNorm

def singularEvenResidualInverse (a : ℝ) (z : ℂ) : TransferMatrix :=
  !![(coupling a : ℂ)*z, 0; -(complementaryCoupling a : ℂ)*z, -1]

theorem evenResidualMap_inverse {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0) :
    (evenResidualMap (coupling a) (complementaryCoupling a) z)⁻¹ =
      singularEvenResidualInverse a z := by
  apply Matrix.inv_eq_right_inv
  have hl : (coupling a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (coupling_pos ha).ne'
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [evenResidualMap, singularEvenResidualInverse, Matrix.mul_apply, Fin.sum_univ_two, hl, hz] <;>
    field_simp
  all_goals ring

theorem gzOdd_real_inverse (b c : ℝ) (hc : c ≠ 0) (hbc : b^2+c^2 = 1) :
    (gzOdd b (c : ℂ))⁻¹ = (c : ℂ)⁻¹ • !![(b : ℂ), 1; 1, (b : ℂ)] := by
  apply Matrix.inv_eq_right_inv
  have hcc : (c : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hc
  have htrig : (b : ℂ)^2 + (c : ℂ)^2 = 1 := by exact_mod_cast hbc
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [gzOdd, Matrix.mul_apply, Fin.sum_univ_two] <;> field_simp
  · linear_combination -(c : ℂ)^2 * htrig
  · linear_combination -htrig

theorem gzOdd_one_inverse (x : ℝ) (hx : Real.cos x ≠ 0) :
    (gzOdd (oddAlpha 1 x) (star (physicalHopping 1 x)))⁻¹ =
      (Real.cos x : ℂ)⁻¹ • !![(Real.sin x : ℂ), 1; 1, (Real.sin x : ℂ)] := by
  have hc : coupling 1 = 1 := by norm_num [coupling]
  simpa only [oddAlpha, hc, one_mul, physicalHopping_one,
    Complex.star_def, Complex.conj_ofReal] using
      gzOdd_real_inverse (Real.sin x) (Real.cos x) hx (Real.sin_sq_add_cos_sq x)

theorem localResidual_one_inverse {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (x : ℝ) (hx : Real.cos x ≠ 0) :
    (localResidual a 1 z x)⁻¹ = (Real.cos x : ℂ)⁻¹ •
      (singularEvenResidualInverse a z * !![(Real.sin x : ℂ), 1; 1, (Real.sin x : ℂ)]) := by
  rw [localResidual, transferResidualMap, Matrix.mul_inv_rev,
    evenResidualMap_inverse ha hz, gzOdd_one_inverse x hx, Matrix.mul_smul]

theorem localResidual_one_inverse_norm_bound {a : ℝ} (ha : 0 < a) {z : ℂ} (hz : z ≠ 0)
    (x : ℝ) (hx : Real.cos x ≠ 0) :
    ‖(localResidual a 1 z x)⁻¹‖ ≤
      (4*transferNorm (singularEvenResidualInverse a z)) / |Real.cos x| := by
  have hm : transferNorm (!![(Real.sin x : ℂ), 1; 1, (Real.sin x : ℂ)] : TransferMatrix) ≤ 4 := by
    have h := transferNorm_le_sum_entries (!![(Real.sin x : ℂ), 1; 1, (Real.sin x : ℂ)] : TransferMatrix)
    simp only [Fin.sum_univ_two, Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
      Matrix.cons_val_fin_one, Complex.norm_real, Real.norm_eq_abs, norm_one] at h
    linarith [Real.abs_sin_le_one x]
  rw [localResidual_one_inverse ha hz x hx, norm_smul, norm_inv, Complex.norm_real, Real.norm_eq_abs]
  have hmul := transferNorm_mul_le (singularEvenResidualInverse a z)
    (!![(Real.sin x : ℂ), 1; 1, (Real.sin x : ℂ)] : TransferMatrix)
  have hnonneg : 0 ≤ transferNorm (singularEvenResidualInverse a z) := norm_nonneg _
  have hb : ‖singularEvenResidualInverse a z *
      !![(Real.sin x : ℂ), 1; 1, (Real.sin x : ℂ)]‖ ≤ 4*transferNorm (singularEvenResidualInverse a z) :=
    hmul.trans (by nlinarith)
  exact (mul_le_mul_of_nonneg_left hb (inv_nonneg.mpr (abs_nonneg _))).trans_eq (by ring)

theorem finiteMonodromy_det_norm_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) :
    ‖(finiteMonodromy n a r ω x z).det‖ = 1 := by
  have he (j : ZMod (n+1)) : ‖(finiteCellTransfer n a r ω x z j).det‖ = 1 := by
    rw [finiteCellTransfer, gzCell, Matrix.det_mul,
      gzEven_det _ _ (coupling_pos ha).ne' (coupling_square_identity a) hz,
      gzOdd_det _ _ (star_ne_zero.mpr (hq j))
        (by simpa only [star_star, mul_comm (star (physicalHopping r (x+j.val*ω)))] using
          physicalHopping_normalization r (x+j.val*ω)), norm_mul,
      norm_neg, norm_neg, norm_one, mul_one, norm_div, norm_star, norm_star]
    exact div_self (norm_ne_zero_iff.mpr (hq j))
  have hh (k : ℕ) : ‖(indexedProduct (fun j => finiteCellTransfer n a r ω x z j) k).det‖ = 1 := by
    induction k with
    | zero => simp [indexedProduct]
    | succ k ih => simp only [indexedProduct, Matrix.det_mul, norm_mul, he, ih, one_mul]
  exact hh (n+1)

theorem log_comparison_majorant {D c : ℝ} (hD : 1 ≤ D) (hc : 0 < c) (hc1 : c ≤ 1) :
    Real.log (4 + 2*(D/c)^2 + 4*(D/c)) ≤
      Real.log (4+2*D^2+4*D) - 2*Real.log c := by
  have hDp : 0 < D := zero_lt_one.trans_le hD
  have hb : 0 < 4+2*D^2+4*D := by positivity
  have hm : 4+2*(D/c)^2+4*(D/c) ≤ (4+2*D^2+4*D) / c^2 := by
    apply (le_div_iff₀ (sq_pos_of_pos hc)).mpr
    have hdiv : (D/c)*c = D := div_mul_cancel₀ D hc.ne'
    have hsq : c^2 ≤ 1 := by nlinarith
    have hcc : (D/c)^2*c^2 = D^2 := by rw [← mul_pow, hdiv]
    nlinarith [mul_nonneg hDp.le (sub_nonneg.mpr hc1)]
  have h := Real.log_le_log (by positivity : 0 < 4+2*(D/c)^2+4*(D/c)) hm
  rw [Real.log_div hb.ne' (pow_ne_zero _ hc.ne'), Real.log_pow] at h
  exact h

theorem exists_singular_monodromy_log_majorant {a : ℝ} (ha : 0 < a)
    {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n ω x, FiniteHoppingRegular n 1 ω x →
      |transferLogNorm (uamoGZCell a 1 z) ω x (n+1) -
        Real.log ‖(1-finiteMonodromy n a 1 ω x z).det‖| ≤
          C - 2*Real.log (Real.cos (x+n*ω)) := by
  let B := 4*transferNorm (singularEvenResidualInverse a z)
  let δ := |‖z‖-1|
  let D := max 1 (4*B/δ)
  have hB : 0 ≤ B := mul_nonneg (by norm_num) (norm_nonneg _)
  have hδ : 0 < δ := abs_pos.mpr (sub_ne_zero.mpr hcircle)
  have hD : 1 ≤ D := le_max_left _ _
  have hDp : 0 < D := zero_lt_one.trans_le hD
  refine ⟨Real.log (4+2*D^2+4*D), Real.log_nonneg (by nlinarith [sq_nonneg D]), ?_⟩
  intro n ω x hq
  have hlast : (n : ZMod (n+1)).val = n := by simp [ZMod.val_natCast, Nat.mod_eq_of_lt (Nat.lt_succ_self n)]
  have hx : Real.cos (x+n*ω) ≠ 0 := by
    have hh := hq (n : ZMod (n+1))
    rw [physicalHopping_one, hlast] at hh
    exact Complex.ofReal_ne_zero.mp hh
  let c := |Real.cos (x+n*ω)|
  have hc : 0 < c := abs_pos.mpr hx
  have hc1 : c ≤ 1 := Real.abs_cos_le_one _
  have hK : 1 ≤ D/c := (le_div_iff₀ hc).mpr (by linarith)
  have hinv : transferNorm ((1-finiteMonodromy n a 1 ω x z)⁻¹) ≤ D/c := by
    unfold transferNorm
    apply ContinuousLinearMap.opNorm_le_bound _ (by positivity)
    intro w
    have hbound : ‖(localResidual a 1 z (x+(n : ZMod (n+1)).val*ω))⁻¹‖ ≤ B/c := by
      rw [hlast]
      exact localResidual_one_inverse_norm_bound ha hz _ hx
    have h := finiteMonodromy_inverse_vectorNorm_le_regular n ha ω x hq hz hcircle
      (B/c) hbound w
    have hcoef : 4*(B/c)/δ ≤ D/c := by
      rw [show 4*(B/c)/δ = (4*B/δ)/c by ring]
      exact div_le_div_of_nonneg_right (le_max_right _ _) hc.le
    exact h.trans (mul_le_mul_of_nonneg_right hcoef (norm_nonneg _))
  have h := transfer_log_det_error_bound _ (finiteMonodromy_det_norm_regular n ha ω x hq hz)
    (finiteMonodromy_det_ne_zero_regular n ha ω x hq hz hcircle) (D/c) hK hinv
  rw [transferLogNorm, ← finiteMonodromy_eq_transferProduct]
  have hm := log_comparison_majorant hD hc hc1
  rw [show Real.log c = Real.log (Real.cos (x+n*ω)) from Real.log_abs _] at hm
  exact h.trans hm

end UAMO.CMV

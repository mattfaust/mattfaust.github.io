import UAMO.CMVTransferDetGrowthComparison
import UAMO.CMVSingularLyapunov

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Set
open scoped Matrix.L2OpNorm

def FiniteHoppingRegular (n : ℕ) (r ω x : ℝ) : Prop :=
  ∀ j : ZMod (n+1), physicalHopping r (x+j.val*ω) ≠ 0

theorem finiteHoppingRegular_one_ae (n : ℕ) (ω : ℝ) :
    ∀ᵐ x : ℝ ∂volume, FiniteHoppingRegular n 1 ω x := by
  filter_upwards [cos_orbit_ne_zero_ae ω] with x hx
  intro j
  rw [physicalHopping_one]
  exact Complex.ofReal_ne_zero.mpr (hx j.val)

theorem finiteTransferSystem_mul_stateMatrix_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) :
    finiteTransferSystem n a r ω x z * finiteStateMatrix n r ω x =
      finiteResidualMatrix n a r ω x z *
        (z • finiteEven n a - finiteOdd n r ω x) := by
  have hvec (u : FiniteSite n → ℂ) :
      (finiteTransferSystem n a r ω x z * finiteStateMatrix n r ω x) *ᵥ u =
      (finiteResidualMatrix n a r ω x z * (z • finiteEven n a - finiteOdd n r ω x)) *ᵥ u := by
    ext p
    rcases p with ⟨s, k⟩
    let j := k - 1
    have hj : j + 1 = k := sub_add_cancel k 1
    have h := transfer_residual_identity (coupling a) (complementaryCoupling a)
      (oddAlpha r (x + j.val * ω)) (star (physicalHopping r (x + j.val * ω)))
      (ne_of_gt (coupling_pos ha)) (coupling_square_identity a)
      (star_ne_zero.mpr (hq j))
      (by simpa only [star_star, mul_comm (star (physicalHopping r (x + j.val * ω)))] using
        physicalHopping_normalization r (x + j.val * ω)) hz
      (u (0, j)) ((finiteOdd n r ω x *ᵥ u) (0, j))
      (u (1, j)) ((finiteOdd n r ω x *ᵥ u) (1, j))
      (u (0, j + 1)) ((finiteOdd n r ω x *ᵥ u) (0, j + 1))
      (finiteOdd_mulVec_one n r ω x u j).symm
      (by simpa only [star_star] using (finiteOdd_mulVec_zero_next n r ω x u j).symm)
    have hs := congrFun h s
    rw [← hj, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec,
      finiteTransferSystem_mulVec_next, finiteResidualMatrix_mulVec_next]
    simp only [finiteStateMatrix_mulVec, finiteState, Matrix.cons_val_zero,
      Matrix.cons_val_one, Matrix.cons_val_fin_one, Matrix.sub_mulVec, Matrix.smul_mulVec_assoc,
      Pi.sub_apply, Pi.smul_apply, smul_eq_mul, finiteEven_mulVec_zero, finiteEven_mulVec_one,
      finiteCellTransfer]
    exact hs
  ext i j
  have h := congrFun (hvec (Pi.single j 1)) i
  simpa only [Matrix.mulVec_single_one, Matrix.transpose_apply] using h

theorem finiteResidualMatrix_det_norm_regular (n : ℕ) (a : ℝ) {r : ℝ} (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) (z : ℂ) :
    ‖(finiteResidualMatrix n a r ω x z).det‖ = (|coupling a| * ‖z‖)⁻¹ ^ (n + 1) := by
  rw [finiteResidualMatrix, Matrix.det_mul, norm_mul, permutation_det_norm, one_mul,
    Matrix.det_blockDiagonal, norm_prod]
  have h (j : ZMod (n + 1)) :
      ‖(transferResidualMap (coupling a) (complementaryCoupling a) (oddAlpha r (x + j.val * ω))
        (star (physicalHopping r (x + j.val * ω))) z).det‖ = (|coupling a| * ‖z‖)⁻¹ := by
    apply transferResidualMap_det_norm
    · exact star_ne_zero.mpr (hq j)
    · simpa only [star_star, mul_comm (star (physicalHopping r (x + j.val * ω)))] using
        physicalHopping_normalization r (x + j.val * ω)
  simp only [h, Finset.prod_const, Finset.card_univ, ZMod.card]

theorem finiteCMV_det_norm_normalization_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) :
    ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
      (coupling a * ‖z‖) ^ (n + 1) *
        (∏ j : ZMod (n + 1), ‖physicalHopping r (x + j.val * ω)‖) *
          ‖(1 - finiteMonodromy n a r ω x z).det‖ := by
  have h := congrArg (fun M : FiniteMatrix n => ‖M.det‖)
    (finiteTransferSystem_mul_stateMatrix_regular n ha ω x hq hz)
  simp only [Matrix.det_mul, norm_mul, finiteTransferSystem_det,
    finiteStateMatrix_det_norm, finiteResidualMatrix_det_norm_regular n a ω x hq z,
    abs_of_pos (coupling_pos ha)] at h
  have hp := congrArg norm (finiteCMV_det_pencil n a r ω x z)
  rw [norm_mul, finiteEven_det, norm_pow, norm_neg, norm_one, one_pow, one_mul] at hp
  rw [← hp] at h
  have hb : coupling a * ‖z‖ ≠ 0 := mul_ne_zero (ne_of_gt (coupling_pos ha))
    (norm_ne_zero_iff.mpr hz)
  calc
    ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
        (coupling a * ‖z‖) ^ (n + 1) *
          ((coupling a * ‖z‖)⁻¹ ^ (n + 1) *
            ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖) := by
      rw [← mul_assoc, ← mul_pow, mul_inv_cancel₀ hb, one_pow, one_mul]
    _ = _ := by rw [← h]; ring

theorem finiteMonodromy_det_ne_zero_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    (1 - finiteMonodromy n a r ω x z).det ≠ 0 := by
  intro h
  have hn := finiteCMV_det_norm_normalization_regular n ha ω x hq hz
  rw [h, norm_zero, mul_zero] at hn
  exact finiteCMV_det_ne_zero n a r ω x hcircle (norm_eq_zero.mp hn)

theorem finiteCMV_log_det_normalization_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Real.log ‖(z • (1 : FiniteMatrix n) - finiteCMV n a r ω x).det‖ =
      (n + 1 : ℕ) * (Real.log (coupling a) + Real.log ‖z‖) +
        (∑ j : ZMod (n + 1), Real.log ‖physicalHopping r (x + j.val * ω)‖) +
          Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖ := by
  have hbase : coupling a * ‖z‖ ≠ 0 :=
    mul_ne_zero (ne_of_gt (coupling_pos ha)) (norm_ne_zero_iff.mpr hz)
  have hhop (j : ZMod (n + 1)) : ‖physicalHopping r (x + j.val * ω)‖ ≠ 0 :=
    norm_ne_zero_iff.mpr (hq j)
  have hprod : (∏ j : ZMod (n + 1), ‖physicalHopping r (x + j.val * ω)‖) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun j _ => hhop j)
  have hmono := norm_ne_zero_iff.mpr (finiteMonodromy_det_ne_zero_regular n ha ω x hq hz hcircle)
  rw [finiteCMV_det_norm_normalization_regular n ha ω x hq hz,
    Real.log_mul (mul_ne_zero (pow_ne_zero _ hbase) hprod) hmono,
    Real.log_mul (pow_ne_zero _ hbase) hprod, Real.log_pow,
    Real.log_mul (ne_of_gt (coupling_pos ha)) (norm_ne_zero_iff.mpr hz),
    Real.log_prod _ _ (fun j _ => hhop j)]

theorem finite_monodromy_log_potential_identity_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖ / ((n + 1 : ℕ) : ℝ) =
      2 * (∫ w, Real.log ‖z - w‖ ∂finiteSpectralMeasure n a r ω x) -
        Real.log (coupling a) - Real.log ‖z‖ -
          (∑ j : ZMod (n + 1), Real.log ‖physicalHopping r (x + j.val * ω)‖) /
            ((n + 1 : ℕ) : ℝ) := by
  rw [finiteSpectralMeasure_log_integral n a r ω x hcircle,
    finiteCMV_log_det_normalization_regular n ha ω x hq hz hcircle]
  push_cast
  have hn : (n : ℝ) + 1 ≠ 0 := by positivity
  field_simp
  ring

theorem localResidual_det_ne_zero_regular {a r : ℝ} (ha : 0 < a)
    {z : ℂ} (hz : z ≠ 0) (x : ℝ) (hx : physicalHopping r x ≠ 0) : (localResidual a r z x).det ≠ 0 := by
  rw [localResidual, transferResidualMap_det _ _ _ _ _
    (star_ne_zero.mpr (hx))
    (by simpa only [star_star, mul_comm (star (physicalHopping r x))] using
      physicalHopping_normalization r x)]
  exact mul_ne_zero
    (mul_ne_zero (inv_ne_zero (Complex.ofReal_ne_zero.mpr (coupling_pos ha).ne')) (inv_ne_zero hz))
    (div_ne_zero (by simpa using hx)
      (star_ne_zero.mpr (hx)))

theorem finiteResidualMatrix_source_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) (w : Fin 2 → ℂ) :
    let j : ZMod (n + 1) := n
    let R := localResidual a r z (x + j.val * ω)
    finiteResidualMatrix n a r ω x z *ᵥ cellSource n j (R⁻¹ *ᵥ w) = cellSource n 0 w := by
  intro last R
  have hlast : last + 1 = 0 := by
    change (n : ZMod (n + 1)) + 1 = 0
    simpa only [Nat.cast_add, Nat.cast_one] using (ZMod.natCast_self (n + 1))
  have hR : IsUnit R.det := isUnit_iff_ne_zero.mpr (localResidual_det_ne_zero_regular ha hz _ (hq last))
  ext p
  rcases p with ⟨t,k⟩
  let j := k - 1
  have hj : j + 1 = k := sub_add_cancel k 1
  rw [← hj, finiteResidualMatrix_mulVec_next]
  by_cases hjlast : j = last
  · rw [hjlast]
    simp only [cellSource, if_pos rfl, hlast]
    change (R *ᵥ ![(R⁻¹ *ᵥ w) 0, (R⁻¹ *ᵥ w) 1]) t = w t
    have he : ![(R⁻¹ *ᵥ w) 0, (R⁻¹ *ᵥ w) 1] = R⁻¹ *ᵥ w := by ext q; fin_cases q <;> rfl
    rw [he, Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv R hR, Matrix.one_mulVec]
  · have hj0 : j + 1 ≠ 0 := by intro h0; apply hjlast; exact add_right_cancel (h0.trans hlast.symm)
    simp only [cellSource, if_neg hjlast, if_neg hj0]
    have he : ![(0 : ℂ), 0] = 0 := by ext q; fin_cases q <;> rfl
    rw [he, Matrix.mulVec_zero]
    rfl

theorem finiteMonodromy_inverse_vectorNorm_le_regular (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1)
    (C : ℝ) (hC : ‖(localResidual a r z (x + (n : ZMod (n+1)).val * ω))⁻¹‖ ≤ C) (w : Fin 2 → ℂ) :
    vectorNorm ((1 - finiteMonodromy n a r ω x z)⁻¹ *ᵥ w) ≤
      (4 * C / |‖z‖ - 1|) * vectorNorm w := by
  let last : ZMod (n + 1) := n
  let R := localResidual a r z (x + last.val * ω)
  let p := cellSource n last (R⁻¹ *ᵥ w)
  let P := z • finiteEven n a - finiteOdd n r ω x
  let u := P⁻¹ *ᵥ p
  have hP : IsUnit P.det := isUnit_iff_ne_zero.mpr (finitePencil_det_ne_zero n a r ω x hcircle)
  have hPu : P *ᵥ u = p := by
    dsimp only [u]
    rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv P hP, Matrix.one_mulVec]
  have hB : finiteTransferSystem n a r ω x z *ᵥ (finiteStateMatrix n r ω x *ᵥ u) =
      cellSource n 0 w := by
    rw [Matrix.mulVec_mulVec, finiteTransferSystem_mul_stateMatrix_regular n ha ω x hq hz,
      ← Matrix.mulVec_mulVec, hPu]
    exact finiteResidualMatrix_source_regular n ha ω x hq hz w
  have hs := finiteTransferSystem_solution_initial n a r ω x z
    (finiteStateMatrix n r ω x *ᵥ u) w hB
  simp only [finiteStateMatrix_mulVec, finiteState, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one] at hs
  have hM : IsUnit (1 - finiteMonodromy n a r ω x z).det :=
    isUnit_iff_ne_zero.mpr (finiteMonodromy_det_ne_zero_regular n ha ω x hq hz hcircle)
  have hinv : (1 - finiteMonodromy n a r ω x z)⁻¹ *ᵥ w = finiteState n r ω x u 0 := by
    rw [← hs, Matrix.mulVec_mulVec, Matrix.nonsing_inv_mul _ hM, Matrix.one_mulVec]
    rfl
  have hp : vectorNorm p ≤ 2 * C * vectorNorm w := by
    calc
      vectorNorm p ≤ 2 * vectorNorm (R⁻¹ *ᵥ w) := cellSource_vectorNorm_le n last _
      _ ≤ 2 * (‖R⁻¹‖ * vectorNorm w) := mul_le_mul_of_nonneg_left (Matrix.l2_opNorm_mulVec _ ((EuclideanSpace.equiv (Fin 2) ℂ).symm w)) (by norm_num)
      _ ≤ 2 * (C * vectorNorm w) := mul_le_mul_of_nonneg_left
        (mul_le_mul_of_nonneg_right hC (norm_nonneg ((EuclideanSpace.equiv (Fin 2) ℂ).symm w))) (by norm_num)
      _ = _ := by ring
  have hl := finitePencil_vector_lower n a r ω x z u
  change |‖z‖ - 1| * vectorNorm u ≤ vectorNorm (P *ᵥ u) at hl
  rw [hPu] at hl
  have hd : 0 < |‖z‖ - 1| := abs_pos.mpr (sub_ne_zero.mpr hcircle)
  have hu : vectorNorm u ≤ (2 * C * vectorNorm w) / |‖z‖ - 1| := by
    apply (le_div_iff₀ hd).mpr
    nlinarith
  rw [hinv]
  calc
    vectorNorm (finiteState n r ω x u 0) ≤ 2 * vectorNorm u := finiteState_vectorNorm_le n r ω x u 0
    _ ≤ 2 * ((2 * C * vectorNorm w) / |‖z‖ - 1|) := mul_le_mul_of_nonneg_left hu (by norm_num)
    _ = _ := by ring

end UAMO.CMV

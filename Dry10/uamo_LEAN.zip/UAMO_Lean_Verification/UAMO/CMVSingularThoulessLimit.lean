import UAMO.CMVSingularThoulessBounds
import UAMO.CMVSingularCellConjugacy
import UAMO.CMVFiniteLogLimit
import UAMO.CMVFinitePhaseContinuity

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem log_cos_shift_integrable (t s u : ℝ) :
    IntervalIntegrable (fun x => Real.log (Real.cos (x+t))) volume s u := by
  simpa only [add_sub_cancel_right] using
    (log_cos_intervalIntegrable (s+t) (u+t)).comp_add_right t

theorem integral_log_cos_shift (t : ℝ) :
    (∫ x in (0 : ℝ)..(2*Real.pi), Real.log (Real.cos (x+t))) =
      -(2*Real.pi)*Real.log 2 := by
  have hp : Function.Periodic (fun x => Real.log (Real.cos x)) (2*Real.pi) := by
    intro x
    dsimp only
    rw [Real.cos_add_two_pi]
  rw [intervalIntegral.integral_comp_add_right (fun x => Real.log (Real.cos x)) t]
  have hh := hp.intervalIntegral_add_eq t 0
  simpa only [zero_add, add_comm (2*Real.pi) t, log_cos_integral_zero_two_pi] using hh

theorem singular_finiteHopping_log_integrable (n : ℕ) (ω s t : ℝ) :
    IntervalIntegrable (fun x => ∑ j : ZMod (n+1), Real.log ‖physicalHopping 1 (x+j.val*ω)‖)
      volume s t := by
  simp_rw [physicalHopping_one_log]
  convert IntervalIntegrable.sum (Finset.univ : Finset (ZMod (n+1)))
    (f := fun j x => Real.log (Real.cos (x+j.val*ω)))
    (fun j _ => log_cos_shift_integrable (j.val*ω) s t) using 1
  ext x
  simp only [Finset.sum_apply]

theorem continuous_finiteCMV_logDet (n : ℕ) (a r ω : ℝ) {z : ℂ} (hz : ‖z‖ ≠ 1) :
    Continuous (fun x => Real.log ‖(z • (1 : FiniteMatrix n)-finiteCMV n a r ω x).det‖) := by
  exact ((continuous_const.sub (continuous_finiteCMV n a r ω)).matrix_det.norm).log
    (fun x => norm_ne_zero_iff.mpr (finiteCMV_det_ne_zero n a r ω x hz))

theorem continuous_finiteSpectralLog (n : ℕ) (a r ω : ℝ) {z : ℂ} (hz : ‖z‖ ≠ 1) :
    Continuous (fun x => ∫ w, Real.log ‖z-w‖ ∂finiteSpectralMeasure n a r ω x) := by
  simp_rw [finiteSpectralMeasure_log_integral n a r ω _ hz]
  exact (continuous_finiteCMV_logDet n a r ω hz).div_const _

theorem singular_finiteMonodromy_logDet_integrable (n : ℕ) {a : ℝ} (ha : 0 < a)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖(1-finiteMonodromy n a 1 ω x z).det‖) volume s t := by
  have hi := (((continuous_finiteCMV_logDet n a 1 ω hcircle).intervalIntegrable s t).sub
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ =>
      ((n+1 : ℕ) : ℝ)*(Real.log (coupling a)+Real.log ‖z‖)) volume s t)).sub
      (singular_finiteHopping_log_integrable n ω s t)
  apply hi.congr
  filter_upwards [ae_restrict_of_ae (finiteHoppingRegular_one_ae n ω)] with x hx
  have h := finiteCMV_log_det_normalization_regular n ha ω x hx hz hcircle
  linarith

theorem exists_singular_monodromy_average_error_bound {a : ℝ} (ha : 0 < a)
    {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n ω,
      |finiteLyapunov (uamoGZCell a 1 z) ω (n+1)-finiteMonodromyLogAverage a 1 ω z n| ≤
        C / ((n+1 : ℕ) : ℝ) := by
  obtain ⟨C, hC, hc⟩ := exists_singular_monodromy_log_majorant ha hz hcircle
  refine ⟨C+2*Real.log 2, by positivity, fun n ω => ?_⟩
  have hi := uamoGZCell_one_product_log_integrable ha hz ω (n+1) 0 (2*Real.pi)
  have hj := singular_finiteMonodromy_logDet_integrable n ha ω hz hcircle 0 (2*Real.pi)
  have hperiod : 0 < 2*Real.pi := by positivity
  have heq : finiteLyapunov (uamoGZCell a 1 z) ω (n+1)-finiteMonodromyLogAverage a 1 ω z n =
      ((∫ x in (0 : ℝ)..(2*Real.pi),
        (transferLogNorm (uamoGZCell a 1 z) ω x (n+1)-
          Real.log ‖(1-finiteMonodromy n a 1 ω x z).det‖)) / (2*Real.pi)) / ((n+1 : ℕ) : ℝ) := by
    unfold finiteLyapunov transferLogAverage finiteMonodromyLogAverage
    rw [← sub_div, ← sub_div, ← intervalIntegral.integral_sub hi hj]
  rw [heq, abs_div, abs_div, abs_of_pos hperiod,
    abs_of_pos (by positivity : (0 : ℝ) < ((n+1 : ℕ) : ℝ))]
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
  apply (div_le_iff₀ hperiod).mpr
  have h1 := intervalIntegral.abs_integral_le_integral_abs (μ := volume) (f := fun x =>
    transferLogNorm (uamoGZCell a 1 z) ω x (n+1)-Real.log ‖(1-finiteMonodromy n a 1 ω x z).det‖)
      hperiod.le
  have h2 := intervalIntegral.integral_mono_ae hperiod.le (hi.sub hj).abs
    (intervalIntegrable_const.sub ((log_cos_shift_integrable (n*ω) 0 (2*Real.pi)).const_mul 2))
    (show (fun x => |transferLogNorm (uamoGZCell a 1 z) ω x (n+1)-
        Real.log ‖(1-finiteMonodromy n a 1 ω x z).det‖|) ≤ᵐ[volume]
      (fun x => C-2*Real.log (Real.cos (x+n*ω))) from
      (finiteHoppingRegular_one_ae n ω).mono (fun x hx => hc n ω x hx))
  rw [intervalIntegral.integral_sub intervalIntegrable_const
      ((log_cos_shift_integrable (n*ω) 0 (2*Real.pi)).const_mul 2),
    intervalIntegral.integral_const, intervalIntegral.integral_const_mul,
    integral_log_cos_shift] at h2
  simp only [sub_zero, smul_eq_mul] at h2
  exact h1.trans (by nlinarith)

theorem tendsto_finiteMonodromyLogAverage_one {a : ℝ} (ha : 0 < a)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Tendsto (finiteMonodromyLogAverage a 1 ω z) atTop (𝓝 (uamoLyapunov a 1 ω z)) := by
  obtain ⟨C, _, hC⟩ := exists_singular_monodromy_average_error_bound ha hz hcircle
  have herr : Tendsto (fun n => finiteLyapunov (uamoGZCell a 1 z) ω (n+1)-
      finiteMonodromyLogAverage a 1 ω z n) atTop (𝓝 0) := by
    apply squeeze_zero_norm (a := fun n : ℕ => C / ((n+1 : ℕ) : ℝ))
      (fun n => by simpa only [Real.norm_eq_abs] using hC n ω)
    exact (tendsto_const_div_atTop_nhds_zero_nat C).comp (tendsto_add_atTop_nat 1)
  have hg := (tendsto_gzFiniteLyapunov_one ha ω hz).comp (tendsto_add_atTop_nat 1)
  have h := hg.sub herr
  simpa only [Function.comp_def, sub_sub_cancel, sub_zero] using h

end UAMO.CMV

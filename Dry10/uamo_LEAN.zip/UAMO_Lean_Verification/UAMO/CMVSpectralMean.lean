import UAMO.CMVSpectralMeanFinite
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Polynomial Set CircleDOS
open scoped Topology Matrix.L2OpNorm

theorem continuous_interval_integral_swap (f : ℝ → ℝ → ℝ)
    (hf : Continuous f.uncurry) (T : ℝ) (hT : 0 ≤ T) :
    (∫ x in (0 : ℝ)..T, ∫ t in (0 : ℝ)..1, f x t) =
      ∫ t in (0 : ℝ)..1, ∫ x in (0 : ℝ)..T, f x t := by
  have hi : Integrable f.uncurry
      ((volume.restrict (Icc (0 : ℝ) T)).prod (volume.restrict (Icc (0 : ℝ) 1))) := by
    rw [Measure.prod_restrict]
    exact ContinuousOn.integrableOn_compact (isCompact_Icc.prod isCompact_Icc) hf.continuousOn
  simpa only [intervalIntegral.integral_of_le hT,
    intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1),
    ← integral_Icc_eq_integral_Ioc] using integral_integral_swap hi

theorem continuous_transferLogNorm_spectralCircle_phase {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) (n : ℕ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Continuous (fun p : ℝ × ℝ =>
      transferLogNorm (uamoTransfer a r (c+R*logFourierChar 1 p.2)) ω p.1 n) := by
  have hg : Continuous (fun p : ℝ × ℝ => (nonzeroSpectralCircle c R hR p.2, p.1)) :=
    ((continuous_nonzeroSpectralCircle c R hR).comp continuous_snd).prodMk continuous_fst
  have hh := (continuous_uamoTransferLogNorm_spectral_phase ha hr hr1 ω n).comp hg
  simpa only [Function.comp_def, nonzeroSpectralCircle] using hh

theorem finiteLyapunov_spectral_submean {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) {n : ℕ} (hn : 1 ≤ n)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    finiteLyapunov (uamoTransfer a r c) ω n ≤ Real.log 4 / (n : ℝ) +
      ∫ t in (0 : ℝ)..1,
        finiteLyapunov (uamoTransfer a r (c+R*logFourierChar 1 t)) ω n := by
  have hc : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  let f := fun x t => transferLogNorm (uamoTransfer a r (c+R*logFourierChar 1 t)) ω x n
  have hf : Continuous f.uncurry :=
    continuous_transferLogNorm_spectralCircle_phase ha hr hr1 ω n c R hR
  have hi : Continuous (fun x => ∫ t in (0 : ℝ)..1, f x t) := by
    have hh := continuous_parametric_integral_of_continuous (μ := volume)
      (f := f) hf (isCompact_Icc (a := (0 : ℝ)) (b := 1))
    simpa only [integral_Icc_eq_integral_Ioc,
      ← intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)] using hh
  have havg := intervalIntegral.integral_mono (μ := volume) (by positivity : (0 : ℝ) ≤ 2*Real.pi)
    ((continuous_transferLogNorm _ (continuous_uamoTransfer a hr hr1 c)
      (uamoTransfer_det_norm ha hr hr1 hc) ω n).intervalIntegrable 0 (2*Real.pi))
    ((continuous_const.add hi).intervalIntegrable 0 (2*Real.pi))
    (fun x => transferLogNorm_spectral_submean ha hr hr1 ω x n c R hR)
  rw [intervalIntegral.integral_add intervalIntegrable_const (hi.intervalIntegrable _ _),
    intervalIntegral.integral_const, continuous_interval_integral_swap f hf _ (by positivity)] at havg
  simp only [sub_zero, smul_eq_mul] at havg
  have hd := div_le_div_of_nonneg_right
    (div_le_div_of_nonneg_right havg (by positivity : (0 : ℝ) ≤ 2*Real.pi))
    (Nat.cast_nonneg n)
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt (lt_of_lt_of_le Nat.zero_lt_one hn))
  have hpi : (2 * Real.pi : ℝ) ≠ 0 := by positivity
  have heq : ((2*Real.pi)*Real.log 4 +
      (∫ t in (0 : ℝ)..1, ∫ x in (0 : ℝ)..(2*Real.pi), f x t)) / (2*Real.pi) / (n : ℝ) =
      Real.log 4 / (n : ℝ) + ∫ t in (0 : ℝ)..1,
        finiteLyapunov (uamoTransfer a r (c+R*logFourierChar 1 t)) ω n := by
    simp only [finiteLyapunov, transferLogAverage]
    rw [intervalIntegral.integral_div, intervalIntegral.integral_div]
    dsimp only [f]
    field_simp
    ring
  exact hd.trans_eq heq

@[simp] theorem transferLogAverage_zero (A : ℝ → TransferMatrix) (ω : ℝ) :
    transferLogAverage A ω 0 = 0 := by
  simp [transferLogAverage, transferLogNorm]

theorem finiteLyapunov_le_first (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀ x, ‖(A x).det‖ = 1)
    (ω : ℝ) (n : ℕ) : finiteLyapunov A ω n ≤ finiteLyapunov A ω 1 := by
  by_cases hn : n = 0
  · simp only [hn, finiteLyapunov, transferLogAverage_zero, Nat.cast_zero, div_zero,
      Nat.cast_one, div_one]
    have h := finiteLyapunov_nonneg A hd ω 1
    simpa only [finiteLyapunov, Nat.cast_one, div_one] using h
  have h := (transferLogAverage_subadditive A hc hp hd ω).apply_mul_add_le n 1 0
  simp only [mul_one, add_zero, transferLogAverage_zero] at h
  simp only [finiteLyapunov, Nat.cast_one, div_one]
  exact (div_le_iff₀ (by exact_mod_cast Nat.pos_of_ne_zero hn)).mpr (by simpa only [mul_comm] using h)

theorem continuous_uamoFiniteLyapunov_spectralCircle {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ) (n : ℕ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Continuous (fun t => finiteLyapunov (uamoTransfer a r (c+R*logFourierChar 1 t)) ω n) := by
  have hh := (continuous_uamoFiniteLyapunov_nonzero ha hr hr1 ω n).comp
    (continuous_nonzeroSpectralCircle c R hR)
  simpa only [Function.comp_def, nonzeroSpectralCircle] using hh

theorem tendsto_uamoFiniteLyapunov_spectralMean {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Tendsto (fun n => ∫ t in (0 : ℝ)..1,
      finiteLyapunov (uamoTransfer a r (c+R*logFourierChar 1 t)) ω n) atTop
      (𝓝 (∫ t in (0 : ℝ)..1, uamoLyapunov a r ω (c+R*logFourierChar 1 t))) := by
  let b := fun t => finiteLyapunov (uamoTransfer a r (c+R*logFourierChar 1 t)) ω 1
  apply intervalIntegral.tendsto_integral_filter_of_dominated_convergence b
  · exact Eventually.of_forall (fun n =>
      (continuous_uamoFiniteLyapunov_spectralCircle ha hr hr1 ω n c R hR).aestronglyMeasurable)
  · apply Eventually.of_forall
    intro n
    exact Eventually.of_forall (fun t _ => by
      have hw := CircleDOS.circle_affine_ne_zero c R hR t
      rw [Real.norm_eq_abs, abs_of_nonneg
        (finiteLyapunov_nonneg _ (uamoTransfer_det_norm ha hr hr1 hw) ω n)]
      exact finiteLyapunov_le_first _ (continuous_uamoTransfer a hr hr1 _)
        (uamoTransfer_periodic a r _) (uamoTransfer_det_norm ha hr hr1 hw) ω n)
  · exact (continuous_uamoFiniteLyapunov_spectralCircle ha hr hr1 ω 1 c R hR).intervalIntegrable 0 1
  · exact Eventually.of_forall (fun t _ => tendsto_uamoFiniteLyapunov ha hr hr1 ω
      (CircleDOS.circle_affine_ne_zero c R hR t))

theorem uamoLyapunov_spectral_submean {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω : ℝ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    uamoLyapunov a r ω c ≤ ∫ t in (0 : ℝ)..1,
      uamoLyapunov a r ω (c+R*logFourierChar 1 t) := by
  have hc : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  have ht := (tendsto_const_div_atTop_nhds_zero_nat (Real.log 4)).add
    (tendsto_uamoFiniteLyapunov_spectralMean ha hr hr1 ω c R hR)
  simp only [zero_add] at ht
  apply le_of_tendsto_of_tendsto (tendsto_uamoFiniteLyapunov ha hr hr1 ω hc) ht
  filter_upwards [eventually_ge_atTop (1 : ℕ)] with n hn
  exact finiteLyapunov_spectral_submean ha hr hr1 ω hn c R hR

end UAMO.CMV

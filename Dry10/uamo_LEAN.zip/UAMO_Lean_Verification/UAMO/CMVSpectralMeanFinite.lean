import UAMO.CMVSpectralPolynomial
import UAMO.CMVLyapunovSpectralUSC
import UAMO.CircleLogMeanAt
import Mathlib.MeasureTheory.Integral.Prod

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Polynomial Set CircleDOS
open scoped Topology Matrix.L2OpNorm

theorem polynomial_circle_eval_ne_zero_ae_center (P : Polynomial ℂ) (c R : ℂ)
    (hc : P.eval c ≠ 0) :
    ∀ᵐ t : ℝ ∂volume, P.eval (c + R * logFourierChar 1 t) ≠ 0 := by
  let Q := P.comp (C c + C R * X)
  have hQ : Q ≠ 0 := by
    intro he
    have hv := congrArg (fun F : Polynomial ℂ => F.eval 0) he
    exact hc (by simpa [Q] using hv)
  have hall := ae_all_iff.mpr (fun i : Fin (CircleDOS.polynomialRootList Q).length =>
    CircleDOS.logFourierChar_root_ne_zero_ae ((CircleDOS.polynomialRootList Q).get i))
  filter_upwards [hall] with t ht
  have hv : Q.eval (logFourierChar 1 t) ≠ 0 := by
    rw [CircleDOS.polynomial_eval_root_product]
    exact mul_ne_zero (Polynomial.leadingCoeff_ne_zero.mpr hQ)
      (Finset.prod_ne_zero_iff.mpr (fun i _ => ht i))
  simpa [Q] using hv

theorem exists_transfer_entry_norm_lower (M : TransferMatrix) (hM : 0 < transferNorm M) :
    ∃ i j : Fin 2, M i j ≠ 0 ∧ transferNorm M ≤ 4 * ‖M i j‖ := by
  obtain ⟨ij, _, hij⟩ := (Finset.univ : Finset (Fin 2 × Fin 2)).exists_max_image
    (fun p => ‖M p.1 p.2‖) (by simp)
  have hsum : (∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖) ≤ 4 * ‖M ij.1 ij.2‖ := by
    calc
      _ ≤ ∑ _i : Fin 2, ∑ _j : Fin 2, ‖M ij.1 ij.2‖ :=
        Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => hij (i,j) (by simp)))
      _ = _ := by simp; ring
  have hb := (transferNorm_le_sum_entries M).trans hsum
  refine ⟨ij.1, ij.2, ?_, hb⟩
  intro he
  simp only [he, norm_zero, mul_zero] at hb
  exact (not_lt_of_ge hb) hM

def nonzeroSpectralCircle (c R : ℂ) (hR : ‖R‖ < ‖c‖) (t : ℝ) : NonzeroEnergy :=
  ⟨c + R * logFourierChar 1 t, CircleDOS.circle_affine_ne_zero c R hR t⟩

theorem continuous_nonzeroSpectralCircle (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Continuous (nonzeroSpectralCircle c R hR) := by
  apply Continuous.subtype_mk
  exact continuous_const.add (continuous_const.mul (logFourierChar_continuous 1))

theorem continuous_transferLogNorm_spectralCircle {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) (n : ℕ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    Continuous (fun t => transferLogNorm (uamoTransfer a r (c+R*logFourierChar 1 t)) ω x n) := by
  have hg : Continuous (fun t : ℝ => (nonzeroSpectralCircle c R hR t, x)) :=
    (continuous_nonzeroSpectralCircle c R hR).prodMk continuous_const
  have hh := (continuous_uamoTransferLogNorm_spectral_phase ha hr hr1 ω n).comp hg
  simpa only [Function.comp_def, nonzeroSpectralCircle] using hh

theorem transferLogNorm_spectral_submean {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) (n : ℕ)
    (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    transferLogNorm (uamoTransfer a r c) ω x n ≤ Real.log 4 +
      ∫ t in (0 : ℝ)..1,
        transferLogNorm (uamoTransfer a r (c+R*logFourierChar 1 t)) ω x n := by
  have hc : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  let M := transferProduct (uamoTransfer a r c) ω x n
  obtain ⟨i,j,hij,hM⟩ := exists_transfer_entry_norm_lower M
    (transferProduct_norm_pos _ (uamoTransfer_det_norm ha hr hr1 hc) ω x n)
  let P := spectralTransferPolynomialProduct a r ω x n i j
  have hPc : P.eval c = c^n * M i j := spectralTransferPolynomialProduct_entry a r ω x hc n i j
  have hPcn : P.eval c ≠ 0 := by rw [hPc]; exact mul_ne_zero (pow_ne_zero _ hc) hij
  have hlogM : transferLogNorm (uamoTransfer a r c) ω x n ≤
      Real.log 4 + Real.log ‖P.eval c‖ - (n : ℝ)*Real.log ‖c‖ := by
    have h := Real.log_le_log
      (transferProduct_norm_pos _ (uamoTransfer_det_norm ha hr hr1 hc) ω x n) hM
    rw [Real.log_mul (by norm_num : (4 : ℝ) ≠ 0) (norm_ne_zero_iff.mpr hij)] at h
    have hp : Real.log ‖P.eval c‖ = (n : ℝ)*Real.log ‖c‖ + Real.log ‖M i j‖ := by
      rw [hPc, norm_mul, norm_pow, Real.log_mul (pow_ne_zero _ (norm_ne_zero_iff.mpr hc))
        (norm_ne_zero_iff.mpr hij), Real.log_pow]
    change Real.log (transferNorm M) ≤ _
    linarith
  have hJ := CircleDOS.polynomial_circle_log_ge_center P c R hPcn
  let f := fun t => transferLogNorm (uamoTransfer a r (c+R*logFourierChar 1 t)) ω x n
  let g := fun t => (n : ℝ)*Real.log ‖c+R*logFourierChar 1 t‖
  have hf : Continuous f := continuous_transferLogNorm_spectralCircle ha hr hr1 ω x n c R hR
  have hg : Continuous g := continuous_const.mul
    ((continuous_const.add (continuous_const.mul (logFourierChar_continuous 1))).norm.log
      (fun t => norm_ne_zero_iff.mpr (CircleDOS.circle_affine_ne_zero c R hR t)))
  have hae : (fun t => Real.log ‖P.eval (c+R*logFourierChar 1 t)‖) ≤ᵐ[volume]
      (fun t => g t + f t) := by
    filter_upwards [polynomial_circle_eval_ne_zero_ae_center P c R hPcn] with t ht
    have hw := CircleDOS.circle_affine_ne_zero c R hR t
    have he : P.eval (c+R*logFourierChar 1 t) = (c+R*logFourierChar 1 t)^n *
        (transferProduct (uamoTransfer a r (c+R*logFourierChar 1 t)) ω x n) i j :=
      spectralTransferPolynomialProduct_entry a r ω x hw n i j
    have hentry : (transferProduct (uamoTransfer a r (c+R*logFourierChar 1 t)) ω x n) i j ≠ 0 := by
      intro hz
      rw [he, hz, mul_zero] at ht
      exact ht rfl
    rw [he, norm_mul, norm_pow,
      Real.log_mul (pow_ne_zero _ (norm_ne_zero_iff.mpr hw)) (norm_ne_zero_iff.mpr hentry), Real.log_pow]
    exact add_le_add_left (Real.log_le_log (norm_pos_iff.mpr hentry)
      (transferNorm_entry_le _ i j)) _
  have hmean := intervalIntegral.integral_mono_ae (by norm_num : (0 : ℝ) ≤ 1)
    (CircleDOS.polynomial_circle_log_integrable_center P c R hPcn 0 1)
    ((hg.add hf).intervalIntegrable 0 1) hae
  have hgmean : (∫ t in (0 : ℝ)..1, g t) = (n : ℝ)*Real.log ‖c‖ := by
    dsimp only [g]
    rw [intervalIntegral.integral_const_mul, CircleDOS.integral_circle_log_of_radius_lt c R hR]
  rw [intervalIntegral.integral_add (hg.intervalIntegrable _ _) (hf.intervalIntegrable _ _),
    hgmean] at hmean
  linarith

end UAMO.CMV

import UAMO.CMVTransferDetGrowthComparison
import UAMO.CirclePolynomialJensen

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial

def spectralTransferPolynomial (a r x : ℝ) : Matrix (Fin 2) (Fin 2) (Polynomial ℂ) :=
  C ((star (physicalHopping r x))⁻¹) •
    !![C ((coupling a : ℂ)⁻¹) *
        (1 + C (2*(complementaryCoupling a : ℂ)*(oddAlpha r x : ℂ))*X +
          C ((complementaryCoupling a : ℂ)^2)*X^2),
      C (-(oddAlpha r x : ℂ))*X - C (complementaryCoupling a : ℂ)*X^2;
      C (-(oddAlpha r x : ℂ))*X - C (complementaryCoupling a : ℂ)*X^2,
      C (coupling a : ℂ)*X^2]

def spectralTransferPolynomialProduct (a r ω x : ℝ) :
    ℕ → Matrix (Fin 2) (Fin 2) (Polynomial ℂ)
  | 0 => 1
  | n+1 => spectralTransferPolynomial a r (x+n*ω)*spectralTransferPolynomialProduct a r ω x n

theorem spectralTransferPolynomial_eval (a r x : ℝ) {z : ℂ} (hz : z ≠ 0) :
    (spectralTransferPolynomial a r x).map (Polynomial.eval z) =
      z • uamoTransfer a r z x := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spectralTransferPolynomial, uamoTransfer, physicalTransfer, Matrix.smul_apply,
      Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_pow] <;>
    try ring
  linear_combination -(((starRingEnd ℂ) (physicalHopping r x))⁻¹)*(coupling a : ℂ)⁻¹ *
    (mul_inv_cancel₀ hz)

theorem spectralTransferPolynomialProduct_eval (a r ω x : ℝ) {z : ℂ} (hz : z ≠ 0) (n : ℕ) :
    (spectralTransferPolynomialProduct a r ω x n).map (Polynomial.eval z) =
      z^n • transferProduct (uamoTransfer a r z) ω x n := by
  induction n with
  | zero => simp [spectralTransferPolynomialProduct, Matrix.map_one]
  | succ n ih =>
    rw [spectralTransferPolynomialProduct]
    have he (A B : Matrix (Fin 2) (Fin 2) (Polynomial ℂ)) :
        (A*B).map (Polynomial.eval z) = A.map (Polynomial.eval z)*B.map (Polynomial.eval z) := by
      ext i j
      simp [Matrix.mul_apply]
    rw [he, spectralTransferPolynomial_eval a r _ hz, ih, smul_mul_smul_comm,
      transferProduct_succ, pow_succ']

theorem spectralTransferPolynomialProduct_entry (a r ω x : ℝ) {z : ℂ} (hz : z ≠ 0)
    (n : ℕ) (i j : Fin 2) :
    (spectralTransferPolynomialProduct a r ω x n i j).eval z =
      z^n * (transferProduct (uamoTransfer a r z) ω x n) i j :=
  congrArg (fun M : TransferMatrix => M i j) (spectralTransferPolynomialProduct_eval a r ω x hz n)

end UAMO.CMV

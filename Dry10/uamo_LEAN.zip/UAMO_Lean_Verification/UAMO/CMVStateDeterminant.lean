import UAMO.CMVRowReduction

noncomputable section
namespace UAMO.CMV
open Matrix

def finiteSpinSumEquiv (n : ℕ) :
    (ZMod (n+1) ⊕ ZMod (n+1)) ≃ FiniteSite n where
  toFun := Sum.elim (fun j => (0,j)) (fun j => (1,j))
  invFun p := if p.1 = 0 then Sum.inl p.2 else Sum.inr p.2
  left_inv p := by cases p <;> simp
  right_inv p := by rcases p with ⟨s,j⟩; fin_cases s <;> simp

def cellIndexBackward (n : ℕ) : Equiv.Perm (ZMod (n+1)) where
  toFun j := j-1
  invFun j := j+1
  left_inv j := by simp
  right_inv j := by simp

def finiteHoppingShift (n : ℕ) (r ω x : ℝ) : Matrix (ZMod (n+1)) (ZMod (n+1)) ℂ :=
  (cellIndexBackward n).permMatrix ℂ *
    Matrix.diagonal (fun j => physicalHopping r (x+j.val*ω))

theorem finiteOdd_zero_one_entry (n : ℕ) (r ω x : ℝ) (j k : ZMod (n+1)) :
    finiteOdd n r ω x (0,j) (1,k) = finiteHoppingShift n r ω x j k := by
  have h := finiteOdd_mulVec_zero_next n r ω x (Pi.single (1,k) 1) (j-1)
  simp only [Matrix.mulVec_single_one, Matrix.transpose_apply, sub_add_cancel] at h
  by_cases hj : j-1 = k
  · subst k
    simpa [finiteHoppingShift, Matrix.mul_diagonal, PEquiv.toMatrix_toPEquiv_apply,
      cellIndexBackward, Pi.single_apply] using h
  · simpa [finiteHoppingShift, Matrix.mul_diagonal, PEquiv.toMatrix_toPEquiv_apply,
      cellIndexBackward, Pi.single_apply, hj, Ne.symm hj] using h

theorem finiteStateMatrix_blocks (n : ℕ) (r ω x : ℝ) :
    (finiteStateMatrix n r ω x).submatrix (finiteSpinSumEquiv n) (finiteSpinSumEquiv n) =
      Matrix.fromBlocks 1 0 (fun j k => finiteOdd n r ω x (0,j) (0,k))
        (finiteHoppingShift n r ω x) := by
  ext i j
  cases i with
  | inl i =>
    cases j with
    | inl j => simp [Matrix.submatrix, finiteSpinSumEquiv, finiteStateMatrix, Matrix.one_apply]
    | inr j => simp [Matrix.submatrix, finiteSpinSumEquiv, finiteStateMatrix, Matrix.one_apply]
  | inr i =>
    cases j with
    | inl j => simp [Matrix.submatrix, finiteSpinSumEquiv, finiteStateMatrix]
    | inr j =>
      simpa [Matrix.submatrix, finiteSpinSumEquiv, finiteStateMatrix] using
        finiteOdd_zero_one_entry n r ω x i j

theorem finiteStateMatrix_det (n : ℕ) (r ω x : ℝ) :
    (finiteStateMatrix n r ω x).det =
      ((cellIndexBackward n).permMatrix ℂ).det *
        ∏ j : ZMod (n+1), physicalHopping r (x+j.val*ω) := by
  rw [← Matrix.det_submatrix_equiv_self (finiteSpinSumEquiv n) (finiteStateMatrix n r ω x),
    finiteStateMatrix_blocks, Matrix.det_fromBlocks_zero₁₂, Matrix.det_one, one_mul,
    finiteHoppingShift, Matrix.det_mul, Matrix.det_diagonal]

theorem finiteStateMatrix_det_norm (n : ℕ) (r ω x : ℝ) :
    ‖(finiteStateMatrix n r ω x).det‖ =
      ∏ j : ZMod (n+1), ‖physicalHopping r (x+j.val*ω)‖ := by
  rw [finiteStateMatrix_det, norm_mul, permutation_det_norm, one_mul, norm_prod]

end UAMO.CMV

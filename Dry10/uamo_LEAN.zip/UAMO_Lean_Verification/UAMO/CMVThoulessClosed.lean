import UAMO.CMVSingularThouless
import UAMO.CMVSingularSpectralMean
import UAMO.CircleAffineExceptional
import UAMO.CircleCutoffPotential
import UAMO.CircleRadialPotential
import UAMO.CircleFinitePotential

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter CircleDOS PhysicalDOS
open scoped Topology

set_option maxHeartbeats 1200000
set_option maxRecDepth 4096

theorem uamoLyapunov_circle_mean_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) (c R : ℂ)
    (hR0 : R ≠ 0) (hR : ‖R‖ < ‖c‖) :
    (∫ t in (0 : ℝ)..1, uamoLyapunov a r (2*Real.pi*Φ) (c+R*logFourierChar 1 t)) =
      2*circleCutoffPotential (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) c ‖R‖ -
        Real.log (coupling a) - Real.log ‖c‖ + Real.log (1+r^2) := by
  let ν := physicalUnitaryDOS a r Φ ha.le ha1 hr hr1
  have hc0 : c ≠ 0 := norm_pos_iff.mp ((norm_nonneg R).trans_lt hR)
  have hc := physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1
  have heq : (fun t => uamoLyapunov a r (2*Real.pi*Φ) (c+R*logFourierChar 1 t))
      =ᵐ[angularParameterMeasure] (fun t =>
        2*(∫ w, Real.log ‖c+R*logFourierChar 1 t-w‖ ∂ν) - Real.log (coupling a) -
          Real.log ‖c+R*logFourierChar 1 t‖ + Real.log (1+r^2)) := by
    filter_upwards [circle_affine_off_circle_ae_angular hc0 hR0] with t ht
    exact uamoLyapunov_thouless_off_circle_closed ha ha1 hr hr1 Φ
      (circle_affine_ne_zero c R hR t) ht
  have hp := circle_affine_potential_integrable ν hc c R hR0
  have hg : IntervalIntegrable (fun t => Real.log ‖c+R*logFourierChar 1 t‖)
      volume (0 : ℝ) 1 := by
    simpa only [sub_zero] using circle_affine_log_integrable c R 0 0 1
  have hcongr := integral_congr_ae heq
  rw [integral_angularParameterMeasure, integral_angularParameterMeasure] at hcongr
  rw [hcongr]
  rw [intervalIntegral.integral_add (((hp.const_mul 2).sub intervalIntegrable_const).sub hg)
      intervalIntegrable_const]
  rw [intervalIntegral.integral_sub ((hp.const_mul 2).sub intervalIntegrable_const) hg]
  rw [intervalIntegral.integral_sub (hp.const_mul 2) intervalIntegrable_const,
    intervalIntegral.integral_const_mul, integral_circle_potential_mean ν hc c R hR0,
    integral_circle_log_of_radius_lt c R hR]
  simp only [intervalIntegral.integral_const, sub_zero, one_smul, circleCutoffPotential, ν]

theorem uamoLyapunov_le_circle_cutoff_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) (z : ℂ) (hz : ‖z‖ = 1)
    {δ : ℝ} (hδ : 0 < δ) (hδ1 : δ < 1) :
    (uamoLyapunov a r (2*Real.pi*Φ) z + Real.log (coupling a) - Real.log (1+r^2))/2 ≤
      circleCutoffPotential (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z δ := by
  have hnorm : ‖(δ : ℂ)‖ = δ := by simp [Complex.norm_real, abs_of_pos hδ]
  have hR : ‖(δ : ℂ)‖ < ‖z‖ := by rw [hnorm, hz]; exact hδ1
  have h := uamoLyapunov_spectral_submean_closed ha hr hr1 (2*Real.pi*Φ) z (δ : ℂ) hR
  rw [uamoLyapunov_circle_mean_closed ha ha1 hr hr1 Φ z (δ : ℂ)
    (Complex.ofReal_ne_zero.mpr hδ.ne') hR, hnorm, hz, Real.log_one] at h
  linarith

theorem circleTotalPotential_ge_uamoLyapunov_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) (z : ℂ) (hz : ‖z‖ = 1) :
    (((uamoLyapunov a r (2*Real.pi*Φ) z + Real.log (coupling a) - Real.log (1+r^2))/2 : ℝ) : EReal) ≤
      circleTotalPotential (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z := by
  have hlim := circleCutoffPotential_tendsto _
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1) z
    logRegularizationScale logRegularizationScale_pos logRegularizationScale_tendsto
  apply ge_of_tendsto hlim
  filter_upwards [logRegularizationScale_tendsto.eventually
    (gt_mem_nhds (by norm_num : (0 : ℝ) < 1))] with n hn
  exact EReal.coe_le_coe_iff.mpr
    (uamoLyapunov_le_circle_cutoff_closed ha ha1 hr hr1 Φ z hz (logRegularizationScale_pos n) hn)

theorem circleTotalPotential_le_uamoLyapunov_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) (z : ℂ) (hz : ‖z‖ = 1) :
    circleTotalPotential (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z ≤
      (((uamoLyapunov a r (2*Real.pi*Φ) z + Real.log (coupling a) - Real.log (1+r^2))/2 : ℝ) : EReal) := by
  let ν := physicalUnitaryDOS a r Φ ha.le ha1 hr hr1
  let A := (uamoLyapunov a r (2*Real.pi*Φ) z + Real.log (coupling a) - Real.log (1+r^2))/2
  have hz0 : z ≠ 0 := norm_ne_zero_iff.mp (by rw [hz]; norm_num)
  have hrad := radialPoint_tendsto z logRegularizationScale logRegularizationScale_tendsto
  have hpot := circle_radial_potential_tendsto ν
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1) z hz
    logRegularizationScale logRegularizationScale_pos logRegularizationScale_tendsto
  have hlog : Tendsto (fun n => Real.log ‖radialPoint z (logRegularizationScale n)‖)
      atTop (𝓝 0) := by
    have h := (Real.continuousAt_log (by rw [hz]; norm_num : ‖z‖ ≠ 0)).tendsto.comp hrad.norm
    simpa only [hz, Real.log_one] using h
  change circleTotalPotential ν z ≤ (A : EReal)
  by_contra hn
  obtain ⟨b, hAb, hb⟩ := EReal.exists_between_coe_real (lt_of_not_ge hn)
  have hε : 0 < b-A := sub_pos.mpr (EReal.coe_lt_coe_iff.mp hAb)
  have hL := hrad.eventually ((upperSemicontinuousAt_uamoLyapunov_closed ha hr hr1
    (2*Real.pi*Φ) hz0) (uamoLyapunov a r (2*Real.pi*Φ) z + (b-A)) (by linarith))
  have hg := hlog.eventually (gt_mem_nhds hε)
  have hupper : circleTotalPotential ν z ≤ (b : EReal) := by
    apply le_of_tendsto hpot
    filter_upwards [hL, hg] with n hLn hgn
    apply EReal.coe_le_coe_iff.mpr
    have hnonzero : radialPoint z (logRegularizationScale n) ≠ 0 := by
      apply norm_ne_zero_iff.mp
      rw [radialPoint_norm z hz (logRegularizationScale_pos n).le]
      exact ne_of_gt (by linarith [logRegularizationScale_pos n])
    have hoff := uamoLyapunov_thouless_off_circle_closed ha ha1 hr hr1 Φ hnonzero
      (radialPoint_off_circle z hz (logRegularizationScale_pos n))
    change (∫ w, Real.log ‖radialPoint z (logRegularizationScale n)-w‖ ∂ν) ≤ b
    dsimp only [A, ν] at *
    linarith
  exact (not_le_of_gt hb) hupper

theorem circleTotalPotential_eq_uamoLyapunov_on_circle_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) (z : ℂ) (hz : ‖z‖ = 1) :
    circleTotalPotential (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z =
      (((uamoLyapunov a r (2*Real.pi*Φ) z + Real.log (coupling a) - Real.log (1+r^2))/2 : ℝ) : EReal) :=
  le_antisymm (circleTotalPotential_le_uamoLyapunov_closed ha ha1 hr hr1 Φ z hz)
    (circleTotalPotential_ge_uamoLyapunov_closed ha ha1 hr hr1 Φ z hz)

theorem uamoLyapunov_thouless_on_circle_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) (z : ℂ) (hz : ‖z‖ = 1) :
    uamoLyapunov a r (2*Real.pi*Φ) z =
      2*(∫ w, Real.log ‖z-w‖ ∂physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) -
        Real.log (coupling a) + Real.log (1+r^2) := by
  have hp := circleTotalPotential_eq_uamoLyapunov_on_circle_closed ha ha1 hr hr1 Φ z hz
  have hi := circleTotalPotential_eq_integral_of_finite _
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1) z hp
  rw [hp] at hi
  have hi' := EReal.coe_eq_coe_iff.mp hi
  linarith

theorem uamoLyapunov_thouless_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) {z : ℂ} (hz0 : z ≠ 0) :
    uamoLyapunov a r (2*Real.pi*Φ) z =
      2*(∫ w, Real.log ‖z-w‖ ∂physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) -
        Real.log (coupling a) - Real.log ‖z‖ + Real.log (1+r^2) := by
  by_cases hz : ‖z‖ = 1
  · simpa only [hz, Real.log_one, sub_zero] using
      uamoLyapunov_thouless_on_circle_closed ha ha1 hr hr1 Φ z hz
  · exact uamoLyapunov_thouless_off_circle_closed ha ha1 hr hr1 Φ hz0 hz

theorem physicalUnitaryDOS_noAtoms_closed {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) :
    NoAtoms (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) := by
  apply noAtoms_of_circleTotalPotential_ne_bot _
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1)
  intro z
  by_cases hz : ‖z‖ = 1
  · rw [circleTotalPotential_eq_uamoLyapunov_on_circle_closed ha ha1 hr hr1 Φ z hz]
    exact EReal.coe_ne_bot _
  · rw [circleTotalPotential_eq_integral_off_circle _
      (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1) z hz]
    exact EReal.coe_ne_bot _

end UAMO.CMV

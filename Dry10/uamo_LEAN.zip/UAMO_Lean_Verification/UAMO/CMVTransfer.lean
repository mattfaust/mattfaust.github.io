import UAMO.Basic
import Mathlib.Data.Complex.Exponential
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.Tactic

noncomputable section
namespace UAMO.CMV
open Matrix

abbrev TransferMatrix := Matrix (Fin 2) (Fin 2) ℂ

def szegoNumerator (α z : ℂ) : TransferMatrix :=
  !![z, -star α; -α * z, 1]

def szegoStep (α ρ z : ℂ) : TransferMatrix := ρ⁻¹ • szegoNumerator α z

theorem szegoNumerator_det (α z : ℂ) :
    (szegoNumerator α z).det = z * (1 - α * star α) := by
  simp only [szegoNumerator, det_fin_two_of]
  ring

theorem szegoStep_det (α ρ z : ℂ) :
    (szegoStep α ρ z).det = ρ⁻¹ ^ 2 * z * (1 - α * star α) := by
  rw [szegoStep, det_smul, Fintype.card_fin, szegoNumerator_det]
  ring

def szegoCell (lam t b : ℝ) (q z : ℂ) : TransferMatrix :=
  szegoStep (t : ℂ) (lam : ℂ) z * szegoStep (b : ℂ) q z

def physicalTransfer (lam t b : ℝ) (q z : ℂ) : TransferMatrix :=
  q⁻¹ • !![(lam : ℂ)⁻¹ * (z⁻¹ + 2 * (t : ℂ) * (b : ℂ) + z * (t : ℂ)^2),
    -(b : ℂ) - z * (t : ℂ);
    -(b : ℂ) - z * (t : ℂ), (lam : ℂ) * z]

def physicalConjugator (lam t : ℝ) : TransferMatrix := !![-(t : ℂ), (lam : ℂ); 1, 0]

def physicalConjugatorInv (lam t : ℝ) : TransferMatrix :=
  !![0, 1; (lam : ℂ)⁻¹, (lam : ℂ)⁻¹ * (t : ℂ)]

theorem physicalConjugator_mul_inv (lam t : ℝ) (hlam : lam ≠ 0) :
    physicalConjugator lam t * physicalConjugatorInv lam t = 1 := by
  have hlamc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [physicalConjugator, physicalConjugatorInv, Matrix.mul_apply, Fin.sum_univ_two, hlamc]

theorem physicalConjugator_inv_mul (lam t : ℝ) (hlam : lam ≠ 0) :
    physicalConjugatorInv lam t * physicalConjugator lam t = 1 := by
  have hlamc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [physicalConjugator, physicalConjugatorInv, Matrix.mul_apply, Fin.sum_univ_two, hlamc]

theorem szegoCell_conjugacy (lam t b : ℝ) (q z : ℂ) (hlam : lam ≠ 0) (hz : z ≠ 0)
    (hlamt : lam ^ 2 + t ^ 2 = 1) :
    z⁻¹ • szegoCell lam t b q z =
      physicalConjugator lam t * physicalTransfer lam t b q z * physicalConjugatorInv lam t := by
  have hlamc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hlamtc : (lam : ℂ)^2 + (t : ℂ)^2 = 1 := by exact_mod_cast hlamt
  by_cases hq : q = 0
  · simp [szegoCell, szegoStep, physicalTransfer, hq]
  have hSC : (z⁻¹ • szegoCell lam t b q z) * physicalConjugator lam t =
      physicalConjugator lam t * physicalTransfer lam t b q z := by
    have hz' : z⁻¹ * z = 1 := inv_mul_cancel₀ hz
    have hl' : (lam : ℂ)⁻¹ * (lam : ℂ) = 1 := inv_mul_cancel₀ hlamc
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [szegoCell, szegoStep, szegoNumerator, physicalTransfer,
        physicalConjugator, Matrix.mul_apply, Fin.sum_univ_two]
    · linear_combination
        (q⁻¹ * (lam : ℂ)⁻¹ * ((b : ℂ) + z * (t : ℂ))) * hlamtc -
        (q⁻¹ * (lam : ℂ)⁻¹ * ((t : ℂ) * z + (b : ℂ) + (t : ℂ)^2 * (b : ℂ))) * hz' -
        ((lam : ℂ) * q⁻¹ * ((b : ℂ) + z * (t : ℂ))) * hl'
    · linear_combination
        -(q⁻¹ * z) * hlamtc +
        (q⁻¹ * (lam : ℂ)⁻¹ * (lam : ℂ) * (z + (t : ℂ) * (b : ℂ))) * hz' +
        (q⁻¹ * (z + (t : ℂ) * (b : ℂ))) * hl'
    · linear_combination
        (q⁻¹ * (lam : ℂ)⁻¹ * ((t : ℂ)^2 * z + 2 * (t : ℂ) * (b : ℂ))) * hz'
    · linear_combination
        -(q⁻¹ * (lam : ℂ)⁻¹ * (lam : ℂ) * ((t : ℂ) * z + (b : ℂ))) * hz' -
        (q⁻¹ * ((t : ℂ) * z + (b : ℂ))) * hl'
  calc
    z⁻¹ • szegoCell lam t b q z =
        ((z⁻¹ • szegoCell lam t b q z) * physicalConjugator lam t) *
          physicalConjugatorInv lam t := by
      rw [mul_assoc, physicalConjugator_mul_inv _ _ hlam, mul_one]
    _ = _ := congrArg (· * physicalConjugatorInv lam t) hSC

theorem physicalTransfer_det (lam t b : ℝ) (q z : ℂ) (hlam : lam ≠ 0) (hz : z ≠ 0) :
    (physicalTransfer lam t b q z).det = q⁻¹ ^ 2 * (1 - (b : ℂ)^2) := by
  have hlamc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hz' : z⁻¹ * z = 1 := inv_mul_cancel₀ hz
  have hl' : (lam : ℂ)⁻¹ * (lam : ℂ) = 1 := inv_mul_cancel₀ hlamc
  simp only [physicalTransfer, det_smul, Fintype.card_fin, det_fin_two_of]
  congr 1
  linear_combination (z * (z⁻¹ + 2 * (t : ℂ) * (b : ℂ) + z * (t : ℂ)^2)) * hl' + hz'

def oddAlpha (r x : ℝ) : ℝ := coupling r * Real.sin x

def physicalHopping (r x : ℝ) : ℂ :=
  (coupling r * Real.cos x : ℝ) + Complex.I * (complementaryCoupling r : ℂ)

theorem physicalHopping_normalization (r x : ℝ) :
    (oddAlpha r x : ℂ)^2 + physicalHopping r x * star (physicalHopping r x) = 1 := by
  have hs := congrArg (fun y : ℝ => coupling r ^ 2 * y) (Real.sin_sq_add_cos_sq x)
  dsimp only at hs
  have hsq := coupling_square_identity r
  apply Complex.ext <;>
    simp only [oddAlpha, physicalHopping, pow_two, Complex.mul_re, Complex.mul_im,
      Complex.add_re, Complex.add_im, Complex.ofReal_re, Complex.ofReal_im,
      Complex.I_re, Complex.I_im, Complex.star_def, Complex.conj_re, Complex.conj_im,
      Complex.one_re, Complex.one_im] <;> nlinarith

theorem physicalHopping_ne_zero {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (x : ℝ) :
    physicalHopping r x ≠ 0 := by
  intro h
  have him := congrArg Complex.im h
  have hc : 0 < complementaryCoupling r := by
    unfold complementaryCoupling
    apply div_pos
    · nlinarith
    · positivity
  have hz : complementaryCoupling r = 0 := by simpa [physicalHopping] using him
  exact hc.ne' hz

def uamoTransfer (a r : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  physicalTransfer (coupling a) (complementaryCoupling a) (oddAlpha r x)
    (star (physicalHopping r x)) z

def uamoSzegoCell (a r : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  szegoCell (coupling a) (complementaryCoupling a) (oddAlpha r x)
    (star (physicalHopping r x)) z

theorem uamoTransfer_szego_conjugacy {a : ℝ} (ha : 0 < a) (r : ℝ) {z : ℂ}
    (hz : z ≠ 0) (x : ℝ) :
    z⁻¹ • uamoSzegoCell a r z x =
      physicalConjugator (coupling a) (complementaryCoupling a) * uamoTransfer a r z x *
        physicalConjugatorInv (coupling a) (complementaryCoupling a) :=
  szegoCell_conjugacy _ _ _ _ _ (ne_of_gt (coupling_pos ha)) hz (coupling_square_identity a)

theorem uamoTransfer_det {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (x : ℝ) :
    (uamoTransfer a r z x).det = physicalHopping r x / star (physicalHopping r x) := by
  rw [uamoTransfer, physicalTransfer_det _ _ _ _ _ (ne_of_gt (coupling_pos ha)) hz]
  have hnorm := physicalHopping_normalization r x
  rw [show 1 - (oddAlpha r x : ℂ)^2 =
    physicalHopping r x * star (physicalHopping r x) by linear_combination -hnorm]
  have hq := physicalHopping_ne_zero hr hr1 x
  have hqs : star (physicalHopping r x) ≠ 0 := star_ne_zero.mpr hq
  simp only [Complex.star_def] at hqs ⊢
  field_simp
  ring

theorem uamoTransfer_det_norm {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (x : ℝ) : ‖(uamoTransfer a r z x).det‖ = 1 := by
  rw [uamoTransfer_det ha hr hr1 hz, norm_div, norm_star,
    div_self (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 x))]

theorem uamoTransfer_det_normalized {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (x : ℝ) :
    ((star (physicalHopping r x) / (‖physicalHopping r x‖ : ℂ)) • uamoTransfer a r z x).det = 1 := by
  rw [det_smul, Fintype.card_fin, uamoTransfer_det ha hr hr1 hz]
  have hq := physicalHopping_ne_zero hr hr1 x
  have hqs : star (physicalHopping r x) ≠ 0 := star_ne_zero.mpr hq
  have hn : (‖physicalHopping r x‖ : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (norm_ne_zero_iff.mpr hq)
  have hh : physicalHopping r x * star (physicalHopping r x) =
      (‖physicalHopping r x‖ : ℂ)^2 := by
    simpa only [Complex.star_def, Complex.normSq_eq_norm_sq, Complex.ofReal_pow] using
      Complex.mul_conj (physicalHopping r x)
  simp only [Complex.star_def] at hqs hh ⊢
  field_simp
  linear_combination (starRingEnd ℂ) (physicalHopping r x) * hh

def transferProduct (A : ℝ → TransferMatrix) (ω x : ℝ) : ℕ → TransferMatrix
  | 0 => 1
  | n + 1 => A (x + n * ω) * transferProduct A ω x n

@[simp] theorem transferProduct_zero (A : ℝ → TransferMatrix) (ω x : ℝ) :
    transferProduct A ω x 0 = 1 := rfl

@[simp] theorem transferProduct_succ (A : ℝ → TransferMatrix) (ω x : ℝ) (n : ℕ) :
    transferProduct A ω x (n + 1) = A (x + n * ω) * transferProduct A ω x n := rfl

theorem transferProduct_conjugacy (A B : ℝ → TransferMatrix) (C D : TransferMatrix)
    (hCD : C * D = 1) (hDC : D * C = 1) (h : ∀ x, A x = C * B x * D)
    (ω x : ℝ) (n : ℕ) : transferProduct A ω x n = C * transferProduct B ω x n * D := by
  induction n with
  | zero => simpa only [transferProduct_zero, mul_one] using hCD.symm
  | succ n ih =>
    rw [transferProduct_succ, transferProduct_succ, h, ih]
    simp only [mul_assoc, ← mul_assoc D C, hDC, one_mul]

end UAMO.CMV

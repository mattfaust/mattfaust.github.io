import UAMO.CMVLogAlmostInvariance

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

structure TransferCircleBounds (A : ℝ→TransferMatrix) (K : ℝ) : Prop where
  continuous : Continuous A
  periodic : Function.Periodic A (2*Real.pi)
  determinant : ∀x,‖(A x).det‖=1
  one_le : 1≤K
  forward : ∀x,transferNorm (A x)≤K
  backward : ∀x,transferNorm (A x)⁻¹≤K

theorem TransferCircleBounds.det_isUnit {A : ℝ→TransferMatrix} {K:ℝ}
    (h : TransferCircleBounds A K) (x:ℝ) : IsUnit (A x).det :=
  isUnit_iff_ne_zero.mpr (norm_ne_zero_iff.mp (by rw [h.determinant x]; norm_num))

def transferInverseWord (A : ℝ→TransferMatrix) (ω x:ℝ) : ℕ→TransferMatrix
  | 0 => 1
  | n+1 => transferInverseWord A ω x n*(A (x+(n:ℝ)*ω))⁻¹

theorem transferInverseWord_mul (A : ℝ→TransferMatrix) {K:ℝ}
    (h : TransferCircleBounds A K) (ω x:ℝ) (n:ℕ) :
    transferInverseWord A ω x n*transferProduct A ω x n=1 := by
  induction n with
  | zero => simp [transferInverseWord]
  | succ n ih =>
    rw [transferProduct_succ,transferInverseWord,Matrix.mul_assoc,
      ← Matrix.mul_assoc ((A (x+(n:ℝ)*ω))⁻¹),
      Matrix.nonsing_inv_mul _ (h.det_isUnit _),Matrix.one_mul,ih]

theorem transferProduct_bound_pow (A : ℝ→TransferMatrix) {K:ℝ}
    (h : TransferCircleBounds A K) (ω x:ℝ) (n:ℕ) :
    transferNorm (transferProduct A ω x n)≤K^n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ]
    exact (transferNorm_mul_le _ _).trans
      ((mul_le_mul (h.forward _) ih (norm_nonneg _) (by linarith [h.one_le])).trans_eq
        (by ring))

theorem transferInverseWord_bound_pow (A : ℝ→TransferMatrix) {K:ℝ}
    (h : TransferCircleBounds A K) (ω x:ℝ) (n:ℕ) :
    transferNorm (transferInverseWord A ω x n)≤K^n := by
  induction n with
  | zero => simp [transferInverseWord]
  | succ n ih =>
    rw [transferInverseWord]
    exact (transferNorm_mul_le _ _).trans
      ((mul_le_mul ih (h.backward _) (norm_nonneg _) (pow_nonneg (by linarith [h.one_le]) _)).trans_eq
        (by ring))

theorem transferLogNorm_bound_length (A : ℝ→TransferMatrix) {K:ℝ}
    (h : TransferCircleBounds A K) (ω x:ℝ) (n:ℕ) :
    transferLogNorm A ω x n≤(n:ℝ)*Real.log K := by
  have hh := Real.log_le_log (transferProduct_norm_pos A h.determinant ω x n)
    (transferProduct_bound_pow A h ω x n)
  simpa only [transferLogNorm,Real.log_pow] using hh

theorem transferLogAverage_eq_mul_finite (A : ℝ→TransferMatrix) (ω:ℝ) (n:ℕ) :
    transferLogAverage A ω n=(n:ℝ)*finiteLyapunov A ω n := by
  cases n with
  | zero => simp [transferLogAverage,transferLogNorm]
  | succ n => unfold finiteLyapunov; field_simp

theorem finiteLyapunov_bound_log (A : ℝ→TransferMatrix) {K:ℝ}
    (h : TransferCircleBounds A K) (ω:ℝ) (n:ℕ) :
    finiteLyapunov A ω n≤Real.log K := by
  by_cases hn : n=0
  · subst n
    simpa [finiteLyapunov] using Real.log_nonneg h.one_le
  have hn' : (0:ℝ)<n := by exact_mod_cast Nat.pos_of_ne_zero hn
  have hmean : transferLogAverage A ω n≤(n:ℝ)*Real.log K := by
    unfold transferLogAverage
    apply (div_le_iff₀ (by positivity : 0<2*Real.pi)).mpr
    have hi := intervalIntegral.integral_mono_on (μ:=volume) (by positivity : (0:ℝ)≤2*Real.pi)
      ((continuous_transferLogNorm A h.continuous h.determinant ω n).intervalIntegrable _ _)
      (intervalIntegrable_const (c:=(n:ℝ)*Real.log K))
      (fun x _ => transferLogNorm_bound_length A h ω x n)
    simpa only [intervalIntegral.integral_const,sub_zero,smul_eq_mul,mul_comm] using hi
  unfold finiteLyapunov
  exact (div_le_iff₀ hn').mpr (hmean.trans_eq (by ring))

end UAMO.CMV

import UAMO.CMVTransferDetGrowthComparison

noncomputable section
namespace UAMO.CMV
open Matrix Filter MeasureTheory
open scoped Topology

def finiteMonodromyLogAverage (a r ω : ℝ) (z : ℂ) (n : ℕ) : ℝ :=
  ((∫ x in (0 : ℝ)..(2 * Real.pi),
    Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖) / (2 * Real.pi)) / ((n + 1 : ℕ) : ℝ)

theorem continuous_finiteMonodromy_logDet {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) (n : ℕ) :
    Continuous (fun x => Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖) := by
  have hc : Continuous (fun x => finiteMonodromy n a r ω x z) := by
    simp_rw [finiteMonodromy_eq_transferProduct]
    exact continuous_transferProduct _ (continuous_uamoGZCell a hr hr1 z) ω (n + 1)
  exact ((continuous_const.sub hc).matrix_det.norm).log
    (fun x => norm_ne_zero_iff.mpr (finiteMonodromy_det_ne_zero n ha hr hr1 ω x hz hcircle))

theorem exists_monodromy_average_error_bound {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n ω,
      |finiteLyapunov (uamoGZCell a r z) ω (n + 1) - finiteMonodromyLogAverage a r ω z n| ≤
        C / ((n + 1 : ℕ) : ℝ) := by
  obtain ⟨C, hC, hc⟩ := exists_uniform_monodromy_log_error ha hr hr1 hz hcircle
  refine ⟨C, hC, fun n ω => ?_⟩
  have hnorm := continuous_transferLogNorm (uamoGZCell a r z)
    (continuous_uamoGZCell a hr hr1 z) (uamoGZCell_det_norm ha hr hr1 hz) ω (n + 1)
  have hdet := continuous_finiteMonodromy_logDet ha hr hr1 ω hz hcircle n
  have hperiod : 0 < 2 * Real.pi := by positivity
  have heq : finiteLyapunov (uamoGZCell a r z) ω (n + 1) -
      finiteMonodromyLogAverage a r ω z n =
      ((∫ x in (0 : ℝ)..(2 * Real.pi),
        (transferLogNorm (uamoGZCell a r z) ω x (n + 1) -
          Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖)) / (2 * Real.pi)) /
        ((n + 1 : ℕ) : ℝ) := by
    unfold finiteLyapunov transferLogAverage finiteMonodromyLogAverage
    rw [← sub_div, ← sub_div,
      ← intervalIntegral.integral_sub (hnorm.intervalIntegrable _ _) (hdet.intervalIntegrable _ _)]
  rw [heq, abs_div, abs_div, abs_of_pos hperiod, abs_of_pos (by positivity : (0 : ℝ) < (n + 1 : ℕ))]
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
  apply (div_le_iff₀ hperiod).mpr
  have h1 := intervalIntegral.abs_integral_le_integral_abs (μ := volume) (f := fun x =>
    transferLogNorm (uamoGZCell a r z) ω x (n + 1) -
      Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖) hperiod.le
  have h2 := intervalIntegral.integral_mono hperiod.le
    ((hnorm.sub hdet).abs.intervalIntegrable (μ := volume) 0 (2 * Real.pi))
    (continuous_const.intervalIntegrable (μ := volume) 0 (2 * Real.pi))
    (fun x => hc n ω x)
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at h2
  exact h1.trans (by simpa only [mul_comm] using h2)

theorem tendsto_finiteMonodromyLogAverage {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    Tendsto (finiteMonodromyLogAverage a r ω z) atTop (𝓝 (uamoLyapunov a r ω z)) := by
  obtain ⟨C, _, hC⟩ := exists_monodromy_average_error_bound ha hr hr1 hz hcircle
  have herr : Tendsto (fun n => finiteLyapunov (uamoGZCell a r z) ω (n + 1) -
      finiteMonodromyLogAverage a r ω z n) atTop (𝓝 0) := by
    apply squeeze_zero_norm (a := fun n : ℕ => C / ((n + 1 : ℕ) : ℝ))
      (fun n => by simpa only [Real.norm_eq_abs] using hC n ω)
    exact (tendsto_const_div_atTop_nhds_zero_nat C).comp (tendsto_add_atTop_nat 1)
  have hg := (tendsto_finiteLyapunov (uamoGZCell a r z)
    (continuous_uamoGZCell a hr hr1 z) (uamoGZCell_periodic a r z)
    (uamoGZCell_det_norm ha hr hr1 hz) ω).comp (tendsto_add_atTop_nat 1)
  rw [gzLyapunov_eq_uamo ha hr hr1 ω hz] at hg
  have h := hg.sub herr
  simpa only [Function.comp_def, sub_sub_cancel, sub_zero] using h

end UAMO.CMV

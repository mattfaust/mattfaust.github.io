import UAMO.CMVDeterminantNormalization
import UAMO.CMVCellConjugacy
import Mathlib.Algebra.Field.Periodic

noncomputable section
namespace UAMO.CMV
open Matrix Set
open scoped Matrix.L2OpNorm

def vectorNorm {ι : Type*} [Fintype ι] (v : ι → ℂ) : ℝ :=
  ‖(EuclideanSpace.equiv ι ℂ).symm v‖

theorem vectorNorm_pair_le (v : Fin 2 → ℂ) : vectorNorm v ≤ ‖v 0‖ + ‖v 1‖ := by
  have h : v = Pi.single 0 (v 0) + Pi.single 1 (v 1) := by
    ext i
    fin_cases i <;> simp
  unfold vectorNorm
  conv_lhs => rw [h]
  rw [map_add]
  have hbound := norm_add_le ((EuclideanSpace.equiv (Fin 2) ℂ).symm (Pi.single 0 (v 0)))
    ((EuclideanSpace.equiv (Fin 2) ℂ).symm (Pi.single 1 (v 1)))
  have h0 : ‖(EuclideanSpace.equiv (Fin 2) ℂ).symm (Pi.single 0 (v 0))‖ = ‖v 0‖ :=
    EuclideanSpace.norm_single 0 (v 0)
  have h1 : ‖(EuclideanSpace.equiv (Fin 2) ℂ).symm (Pi.single 1 (v 1))‖ = ‖v 1‖ :=
    EuclideanSpace.norm_single 1 (v 1)
  rwa [h0,h1] at hbound

theorem finiteEven_unitary (n : ℕ) (a : ℝ) : finiteEven n a ∈ unitary (FiniteMatrix n) := by
  apply unitary.mem_iff.mpr
  rw [finiteEven_star]
  exact ⟨finiteEven_square n a, finiteEven_square n a⟩

theorem finiteOdd_unitary (n : ℕ) (r ω x : ℝ) : finiteOdd n r ω x ∈ unitary (FiniteMatrix n) := by
  apply unitary.mem_iff.mpr
  rw [finiteOdd_star]
  exact ⟨finiteOdd_square n r ω x, finiteOdd_square n r ω x⟩

theorem finitePencil_vector_lower (n : ℕ) (a r ω x : ℝ) (z : ℂ) (u : FiniteSite n → ℂ) :
    |‖z‖ - 1| * vectorNorm u ≤
      vectorNorm ((z • finiteEven n a - finiteOdd n r ω x) *ᵥ u) := by
  have h := abs_norm_sub_norm_le
    ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm (z • (finiteEven n a *ᵥ u)))
    ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm (finiteOdd n r ω x *ᵥ u))
  have he : ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm (finiteEven n a *ᵥ u)‖ =
      ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm u‖ :=
    ContinuousLinearMap.norm_map_of_mem_unitary
    (unitary.map_mem (Matrix.toEuclideanCLM (n := FiniteSite n) (𝕜 := ℂ))
      (finiteEven_unitary n a)) ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm u)
  have ho : ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm (finiteOdd n r ω x *ᵥ u)‖ =
      ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm u‖ :=
    ContinuousLinearMap.norm_map_of_mem_unitary
    (unitary.map_mem (Matrix.toEuclideanCLM (n := FiniteSite n) (𝕜 := ℂ))
      (finiteOdd_unitary n r ω x)) ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm u)
  simp only [map_smul, norm_smul, he, ho] at h
  rw [← sub_one_mul, abs_mul, abs_of_nonneg (norm_nonneg _)] at h
  simpa only [Matrix.sub_mulVec, Matrix.smul_mulVec_assoc, vectorNorm, map_smul, map_sub,
    ← sub_mul, abs_mul, abs_of_nonneg (norm_nonneg _), mul_one] using h

theorem finiteState_vectorNorm_le (n : ℕ) (r ω x : ℝ) (u : FiniteSite n → ℂ)
    (j : ZMod (n + 1)) : vectorNorm (finiteState n r ω x u j) ≤ 2 * vectorNorm u := by
  have hu := PiLp.norm_apply_le ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm u) (0,j)
  have hv := PiLp.norm_apply_le ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm (finiteOdd n r ω x *ᵥ u)) (0,j)
  have ho : ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm (finiteOdd n r ω x *ᵥ u)‖ =
      ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm u‖ :=
    ContinuousLinearMap.norm_map_of_mem_unitary
    (unitary.map_mem (Matrix.toEuclideanCLM (n := FiniteSite n) (𝕜 := ℂ))
      (finiteOdd_unitary n r ω x)) ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm u)
  rw [ho] at hv
  change ‖u (0,j)‖ ≤ vectorNorm u at hu
  change ‖(finiteOdd n r ω x *ᵥ u) (0,j)‖ ≤ vectorNorm u at hv
  have h := vectorNorm_pair_le (finiteState n r ω x u j)
  simp only [finiteState, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one] at h
  change vectorNorm ![u (0, j), (finiteOdd n r ω x *ᵥ u) (0, j)] ≤ _
  linarith

def localResidual (a r : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  transferResidualMap (coupling a) (complementaryCoupling a) (oddAlpha r x)
    (star (physicalHopping r x)) z

theorem localResidual_det_ne_zero {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (x : ℝ) : (localResidual a r z x).det ≠ 0 := by
  rw [localResidual, transferResidualMap_det _ _ _ _ _
    (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x))
    (by simpa only [star_star, mul_comm (star (physicalHopping r x))] using
      physicalHopping_normalization r x)]
  exact mul_ne_zero
    (mul_ne_zero (inv_ne_zero (Complex.ofReal_ne_zero.mpr (coupling_pos ha).ne')) (inv_ne_zero hz))
    (div_ne_zero (by simpa using physicalHopping_ne_zero hr hr1 x)
      (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x)))

theorem continuous_localResidual (a : ℝ) {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (z : ℂ) :
    Continuous (localResidual a r z) := by
  have hq : Continuous (fun x => (star (physicalHopping r x))⁻¹) := by
    apply Continuous.inv₀
    · unfold physicalHopping; fun_prop
    · intro x; exact star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x)
  unfold localResidual transferResidualMap gzOdd
  apply Continuous.mul _ continuous_const
  apply hq.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp [oddAlpha] <;> fun_prop

theorem localResidual_periodic (a r : ℝ) (z : ℂ) :
    Function.Periodic (localResidual a r z) (2 * Real.pi) := by
  intro x
  simp only [localResidual, oddAlpha, physicalHopping, Real.sin_add_two_pi, Real.cos_add_two_pi]

theorem exists_uniform_localResidual_inverse_bound {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) {z : ℂ} (hz : z ≠ 0) :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ x, ‖(localResidual a r z x)⁻¹‖ ≤ C := by
  have hc : Continuous (fun x => ‖(localResidual a r z x)⁻¹‖) := by
    apply Continuous.norm
    apply continuous_iff_continuousAt.mpr
    intro x
    apply (continuousAt_matrix_inv _ ?_).comp (continuous_localResidual a hr hr1 z).continuousAt
    rw [show (Ring.inverse : ℂ → ℂ) = Inv.inv from funext Ring.inverse_eq_inv]
    exact continuousAt_inv₀ (localResidual_det_ne_zero ha hr hr1 hz x)
  have hp : Function.Periodic (fun x => ‖(localResidual a r z x)⁻¹‖) (2 * Real.pi) := by
    intro x
    dsimp only
    rw [localResidual_periodic a r z]
  have hb : BddAbove ((fun x => ‖(localResidual a r z x)⁻¹‖) '' Icc 0 (2 * Real.pi)) :=
    isCompact_Icc.bddAbove_image hc.continuousOn
  rw [show (2 * Real.pi : ℝ) = 0 + 2 * Real.pi by ring,
    hp.image_Icc (by positivity) 0] at hb
  obtain ⟨C, hC⟩ := hb
  refine ⟨max 1 C, le_max_left _ _, fun x => ?_⟩
  exact (hC (mem_range_self x)).trans (le_max_right _ _)

end UAMO.CMV

import UAMO.CMVTransferDetGrowthCorner

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

theorem transferNorm_entry_le (M : TransferMatrix) (i j : Fin 2) : ‖M i j‖ ≤ transferNorm M := by
  let v : EuclideanSpace ℂ (Fin 2) := EuclideanSpace.single j 1
  have hentry : (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M v) i = M i j := by
    change (M *ᵥ Pi.single j 1) i = M i j
    rw [Matrix.mulVec_single_one]
    rfl
  calc
    ‖M i j‖ = ‖(Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M v) i‖ := congrArg norm hentry.symm
    _ ≤ ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M v‖ := PiLp.norm_apply_le _ _
    _ ≤ transferNorm M * ‖v‖ := (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M).le_opNorm v
    _ = transferNorm M := by simp [v]

theorem transferNorm_le_sum_entries (M : TransferMatrix) :
    transferNorm M ≤ ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ := by
  unfold transferNorm
  apply ContinuousLinearMap.opNorm_le_bound _ (by positivity)
  intro v
  have h := vectorNorm_pair_le (M *ᵥ v)
  change vectorNorm (M *ᵥ v) ≤ _
  calc
    vectorNorm (M *ᵥ v) ≤ ∑ i : Fin 2, ‖(M *ᵥ v) i‖ := by simpa only [Fin.sum_univ_two] using h
    _ ≤ ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ * ‖v j‖ := by
      apply Finset.sum_le_sum
      intro i _
      simpa only [Matrix.mulVec, dotProduct, norm_mul] using norm_sum_le (Finset.univ : Finset (Fin 2))
        (fun j => M i j * v j)
    _ ≤ ∑ i : Fin 2, ∑ j : Fin 2, ‖M i j‖ * ‖v‖ := by
      apply Finset.sum_le_sum
      intro i _
      exact Finset.sum_le_sum fun j _ => mul_le_mul_of_nonneg_left (PiLp.norm_apply_le v j) (norm_nonneg _)
    _ = _ := by simp only [Finset.sum_mul]

theorem det_norm_le_two_norm_sq (M : TransferMatrix) : ‖M.det‖ ≤ 2 * transferNorm M ^ 2 := by
  rw [Matrix.det_fin_two]
  have h00 := transferNorm_entry_le M 0 0
  have h01 := transferNorm_entry_le M 0 1
  have h10 := transferNorm_entry_le M 1 0
  have h11 := transferNorm_entry_le M 1 1
  have h1 := mul_le_mul h00 h11 (norm_nonneg _) (norm_nonneg _)
  have h2 := mul_le_mul h01 h10 (norm_nonneg _) (norm_nonneg _)
  have h := norm_sub_le (M 0 0 * M 1 1) (M 0 1 * M 1 0)
  rw [norm_mul, norm_mul] at h
  nlinarith

theorem one_sub_det_norm_le_four_norm (G : TransferMatrix) (hG : ‖G.det‖ = 1) :
    ‖(1 - G).det‖ ≤ 4 * transferNorm G := by
  have heq : (1 - G).det = 1 + G.det - G 0 0 - G 1 1 := by
    simp [Matrix.det_fin_two, Matrix.one_apply]
    ring
  have hn := one_le_transferNorm_of_det_norm G hG
  have h00 := transferNorm_entry_le G 0 0
  have h11 := transferNorm_entry_le G 1 1
  rw [heq]
  calc
    ‖1 + G.det - G 0 0 - G 1 1‖ ≤ ‖1 + G.det - G 0 0‖ + ‖G 1 1‖ := norm_sub_le _ _
    _ ≤ (‖1 + G.det‖ + ‖G 0 0‖) + ‖G 1 1‖ := add_le_add_right (norm_sub_le _ _) _
    _ ≤ ((‖(1 : ℂ)‖ + ‖G.det‖) + ‖G 0 0‖) + ‖G 1 1‖ :=
      add_le_add_right (add_le_add_right (norm_add_le _ _) _) _
    _ ≤ 4 * transferNorm G := by rw [norm_one, hG]; linarith

theorem transferNorm_le_det_inverse (H : TransferMatrix) (hd : H.det ≠ 0) :
    transferNorm H ≤ 4 * ‖H.det‖ * transferNorm H⁻¹ := by
  have ha : H.adjugate = H.det • H⁻¹ := by
    rw [Matrix.inv_def, Ring.inverse_eq_inv, smul_smul, mul_inv_cancel₀ hd, one_smul]
  have hb (i j : Fin 2) : ‖H.adjugate i j‖ ≤ ‖H.det‖ * transferNorm H⁻¹ := by
    rw [ha, Matrix.smul_apply, norm_smul]
    exact mul_le_mul_of_nonneg_left (transferNorm_entry_le H⁻¹ i j) (norm_nonneg _)
  have h00 := hb 1 1
  have h01 := hb 0 1
  have h10 := hb 1 0
  have h11 := hb 0 0
  simp only [Matrix.adjugate_fin_two, Matrix.of_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one, norm_neg] at h00 h01 h10 h11
  have h := transferNorm_le_sum_entries H
  simp only [Fin.sum_univ_two] at h
  linarith

theorem transfer_norm_det_comparison (G : TransferMatrix) (hG : ‖G.det‖ = 1)
    (hd : (1 - G).det ≠ 0) (K : ℝ) (hK : 1 ≤ K) (hi : transferNorm (1 - G)⁻¹ ≤ K) :
    transferNorm G ≤ (4 + 2 * K^2 + 4 * K) * ‖(1 - G).det‖ ∧
      ‖(1 - G).det‖ ≤ (4 + 2 * K^2 + 4 * K) * transferNorm G := by
  have hnG : 0 ≤ transferNorm G := norm_nonneg _
  have hnH : 0 ≤ transferNorm (1 - G)⁻¹ := norm_nonneg _
  have hnD : 0 ≤ ‖(1 - G).det‖ := norm_nonneg _
  have hsmall := det_norm_le_two_norm_sq ((1 - G)⁻¹)
  have hprod := congrArg (fun M : TransferMatrix => ‖M.det‖)
    (Matrix.mul_nonsing_inv (1 - G) (isUnit_iff_ne_zero.mpr hd))
  simp only [Matrix.det_mul, norm_mul, Matrix.det_one, norm_one] at hprod
  have hD : 1 ≤ (2 * K^2) * ‖(1 - G).det‖ := by
    have hsq : transferNorm (1 - G)⁻¹ ^ 2 ≤ K^2 := by nlinarith
    have hh := mul_le_mul_of_nonneg_left
      (hsmall.trans (show 2 * transferNorm (1 - G)⁻¹ ^ 2 ≤ 2 * K^2 by linarith)) hnD
    rw [hprod] at hh
    nlinarith
  have hH := transferNorm_le_det_inverse (1 - G) hd
  have hH' : transferNorm (1 - G) ≤ 4 * ‖(1 - G).det‖ * K :=
    hH.trans (mul_le_mul_of_nonneg_left hi (by positivity))
  have htri : transferNorm G ≤ 1 + transferNorm (1 - G) := by
    have h := norm_sub_le (1 : TransferMatrix) (1 - G)
    simpa only [sub_sub_cancel, norm_one] using h
  constructor
  · nlinarith
  · have h := one_sub_det_norm_le_four_norm G hG
    nlinarith [sq_nonneg K]

theorem transfer_log_det_error_bound (G : TransferMatrix) (hG : ‖G.det‖ = 1)
    (hd : (1 - G).det ≠ 0) (K : ℝ) (hK : 1 ≤ K) (hi : transferNorm (1 - G)⁻¹ ≤ K) :
    |Real.log (transferNorm G) - Real.log ‖(1 - G).det‖| ≤
      Real.log (4 + 2 * K^2 + 4 * K) := by
  have hnorm : 0 < transferNorm G := zero_lt_one.trans_le (one_le_transferNorm_of_det_norm G hG)
  have hdet : 0 < ‖(1 - G).det‖ := norm_pos_iff.mpr hd
  have hc : 0 < 4 + 2 * K^2 + 4 * K := by nlinarith [sq_nonneg K]
  have h := transfer_norm_det_comparison G hG hd K hK hi
  have h1 := Real.log_le_log hnorm h.1
  have h2 := Real.log_le_log hdet h.2
  rw [Real.log_mul hc.ne' hdet.ne'] at h1
  rw [Real.log_mul hc.ne' hnorm.ne'] at h2
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem gzEven_det (lam t : ℝ) (hlam : lam ≠ 0) (hlt : lam^2 + t^2 = 1)
    {z : ℂ} (hz : z ≠ 0) : (gzEven lam t z).det = -1 := by
  have hlc : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hltc : (lam : ℂ)^2 + (t : ℂ)^2 = 1 := by exact_mod_cast hlt
  rw [gzEven, Matrix.det_smul, Fintype.card_fin, Matrix.det_fin_two_of]
  simp only [neg_mul_neg, inv_mul_cancel₀ hz]
  rw [show (t : ℂ) * (t : ℂ) - 1 = -(lam : ℂ)^2 by linear_combination hltc]
  field_simp

theorem uamoGZCell_det_norm {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (x : ℝ) : ‖(uamoGZCell a r z x).det‖ = 1 := by
  rw [uamoGZCell, gzCell, Matrix.det_mul,
    gzEven_det _ _ (coupling_pos ha).ne' (coupling_square_identity a) hz,
    gzOdd_det _ _ (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x))
      (by simpa only [star_star, mul_comm (star (physicalHopping r x))] using
        physicalHopping_normalization r x), norm_mul, norm_neg, norm_neg, norm_one, mul_one,
    norm_div, norm_star, norm_star]
  exact div_self (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 x))

theorem continuous_uamoGZCell (a : ℝ) {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (z : ℂ) :
    Continuous (uamoGZCell a r z) := by
  have hq : Continuous (fun x => (star (physicalHopping r x))⁻¹) := by
    apply Continuous.inv₀
    · unfold physicalHopping; fun_prop
    · intro x; exact star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x)
  unfold uamoGZCell gzCell gzOdd
  apply Continuous.mul _ continuous_const
  apply hq.smul
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j <;> simp [oddAlpha] <;> fun_prop

theorem uamoGZCell_periodic (a r : ℝ) (z : ℂ) :
    Function.Periodic (uamoGZCell a r z) (2 * Real.pi) := by
  intro x
  simp only [uamoGZCell, oddAlpha, physicalHopping, Real.sin_add_two_pi, Real.cos_add_two_pi]

theorem finiteMonodromy_eq_transferProduct (n : ℕ) (a r ω x : ℝ) (z : ℂ) :
    finiteMonodromy n a r ω x z = transferProduct (uamoGZCell a r z) ω x (n + 1) := by
  have h (k : ℕ) (hk : k ≤ n + 1) :
      indexedProduct (fun j => finiteCellTransfer n a r ω x z j) k =
        transferProduct (uamoGZCell a r z) ω x k := by
    induction k with
    | zero => rfl
    | succ k ih =>
      rw [indexedProduct, transferProduct_succ, ih (by omega)]
      congr 1
      simp only [finiteCellTransfer, uamoGZCell, ZMod.val_natCast,
        Nat.mod_eq_of_lt (show k < n + 1 by omega)]
  exact h (n + 1) le_rfl

theorem exists_uniform_monodromy_log_error {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1)
    {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n ω x,
      |transferLogNorm (uamoGZCell a r z) ω x (n + 1) -
        Real.log ‖(1 - finiteMonodromy n a r ω x z).det‖| ≤ C := by
  obtain ⟨K, hK, hi⟩ := exists_uniform_finiteMonodromy_inverse_bound ha hr hr1 hz hcircle
  refine ⟨Real.log (4 + 2 * K^2 + 4 * K), Real.log_nonneg (by nlinarith [sq_nonneg K]), ?_⟩
  intro n ω x
  rw [transferLogNorm, ← finiteMonodromy_eq_transferProduct]
  apply transfer_log_det_error_bound _ _ (finiteMonodromy_det_ne_zero n ha hr hr1 ω x hz hcircle) K hK (hi n ω x)
  rw [finiteMonodromy_eq_transferProduct]
  exact transferProduct_det_norm _ (uamoGZCell_det_norm ha hr hr1 hz) ω x (n + 1)

end UAMO.CMV

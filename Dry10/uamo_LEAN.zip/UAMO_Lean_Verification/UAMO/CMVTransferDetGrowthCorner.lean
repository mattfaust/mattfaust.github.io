import UAMO.CMVTransferDetGrowthBounds

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

theorem chainCycle_solution_initial (n : ℕ) (A : ℕ → TransferMatrix)
    (v : ChainSite n → ℂ) (w : Fin 2 → ℂ)
    (h : chainCycle n A *ᵥ v = chainSource n *ᵥ w) :
    (1 - indexedProduct A (n + 1)) *ᵥ (fun s => v (0,s)) = w := by
  rw [chainCycle, Matrix.sub_mulVec, ← Matrix.mulVec_mulVec] at h
  have hD := sub_eq_iff_eq_add.mp h
  rw [← Matrix.mulVec_add] at hD
  let y := w + chainFeedback n A *ᵥ v
  have hDy : chainOpen n A *ᵥ v = chainOpen n A *ᵥ (chainPropagator n A *ᵥ y) := by
    rw [Matrix.mulVec_mulVec, chainOpen_mul_propagator]
    exact hD
  have hunit : IsUnit (chainOpen n A) := by
    apply (Matrix.isUnit_iff_isUnit_det _).mpr
    rw [chainOpen_det]
    exact isUnit_one
  have hv : v = chainPropagator n A *ᵥ y := (Matrix.mulVec_injective_iff_isUnit.mpr hunit) hDy
  have hzero : (fun s => v (0,s)) = y := by
    funext s
    have hh := congrFun hv (0,s)
    fin_cases s <;> simpa [Matrix.mulVec, dotProduct, chainPropagator, indexedProduct] using hh
  have hlast : chainFeedback n A *ᵥ v = indexedProduct A (n + 1) *ᵥ y := by
    rw [hv, Matrix.mulVec_mulVec, chainFeedback_mul_propagator]
  rw [Matrix.sub_mulVec, Matrix.one_mulVec, hzero, ← hlast]
  exact add_sub_cancel_right w _

def cellSource (n : ℕ) (j : ZMod (n + 1)) (w : Fin 2 → ℂ) : FiniteSite n → ℂ :=
  fun p => if p.2 = j then w p.1 else 0

theorem cellSource_vectorNorm_le (n : ℕ) (j : ZMod (n + 1)) (w : Fin 2 → ℂ) :
    vectorNorm (cellSource n j w) ≤ 2 * vectorNorm w := by
  have heq : cellSource n j w = Pi.single (0,j) (w 0) + Pi.single (1,j) (w 1) := by
    ext p
    rcases p with ⟨s,k⟩
    fin_cases s <;> by_cases hk : k = j <;> simp [cellSource, Pi.single_apply, hk]
  rw [heq]
  have h := norm_add_le
    ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm (Pi.single ((0 : Fin 2),j) (w 0)))
    ((EuclideanSpace.equiv (FiniteSite n) ℂ).symm (Pi.single ((1 : Fin 2),j) (w 1)))
  rw [show ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm
      (Pi.single ((0 : Fin 2),j) (w 0))‖ = ‖w 0‖ from EuclideanSpace.norm_single (0,j) (w 0),
    show ‖(EuclideanSpace.equiv (FiniteSite n) ℂ).symm
      (Pi.single ((1 : Fin 2),j) (w 1))‖ = ‖w 1‖ from EuclideanSpace.norm_single (1,j) (w 1)] at h
  have h0 := PiLp.norm_apply_le ((EuclideanSpace.equiv (Fin 2) ℂ).symm w) 0
  have h1 := PiLp.norm_apply_le ((EuclideanSpace.equiv (Fin 2) ℂ).symm w) 1
  change ‖w 0‖ ≤ ‖(EuclideanSpace.equiv (Fin 2) ℂ).symm w‖ at h0
  change ‖w 1‖ ≤ ‖(EuclideanSpace.equiv (Fin 2) ℂ).symm w‖ at h1
  unfold vectorNorm
  rw [map_add]
  linarith

theorem finiteTransferSystem_solution_initial (n : ℕ) (a r ω x : ℝ) (z : ℂ)
    (s : FiniteSite n → ℂ) (w : Fin 2 → ℂ)
    (h : finiteTransferSystem n a r ω x z *ᵥ s = cellSource n 0 w) :
    (1 - finiteMonodromy n a r ω x z) *ᵥ ![s (0,0), s (1,0)] = w := by
  let e := chainSiteEquiv n
  let v := s ∘ e
  have hc : chainCycle n (fun k => finiteCellTransfer n a r ω x z k) *ᵥ v =
      chainSource n *ᵥ w := by
    rw [← finiteTransferSystem_reindex]
    change ((finiteTransferSystem n a r ω x z).submatrix e e *ᵥ v) = _
    rw [Matrix.submatrix_mulVec_equiv]
    have he : v ∘ e.symm = s := by funext p; simp [v]
    rw [he, h]
    ext p
    rcases p with ⟨i,t⟩
    have hi : ((i.val : ZMod (n + 1)) = 0) ↔ i = 0 := by
      constructor
      · intro hh
        apply Fin.ext
        have hh' := congrArg (fun q : ZMod (n + 1) => q.val) hh
        simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt i.isLt, ZMod.val_zero, Fin.val_zero] using hh'
      · rintro rfl; simp
    fin_cases t <;> simp [e, chainSiteEquiv, cellSource, Function.comp_def, chainSource,
      Matrix.mulVec, dotProduct, Matrix.one_apply, hi]
  have hh := chainCycle_solution_initial n (fun k => finiteCellTransfer n a r ω x z k) v w hc
  have hzero : (fun t => v (0,t)) = ![s (0,0),s (1,0)] := by
    ext t
    fin_cases t <;> simp [v, e, Function.comp_def, chainSiteEquiv]
  simpa only [finiteMonodromy, hzero] using hh

theorem finiteResidualMatrix_source (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) (w : Fin 2 → ℂ) :
    let j : ZMod (n + 1) := n
    let R := localResidual a r z (x + j.val * ω)
    finiteResidualMatrix n a r ω x z *ᵥ cellSource n j (R⁻¹ *ᵥ w) = cellSource n 0 w := by
  intro last R
  have hlast : last + 1 = 0 := by
    change (n : ZMod (n + 1)) + 1 = 0
    simpa only [Nat.cast_add, Nat.cast_one] using (ZMod.natCast_self (n + 1))
  have hR : IsUnit R.det := isUnit_iff_ne_zero.mpr (localResidual_det_ne_zero ha hr hr1 hz _)
  ext p
  rcases p with ⟨t,k⟩
  let j := k - 1
  have hj : j + 1 = k := sub_add_cancel k 1
  rw [← hj, finiteResidualMatrix_mulVec_next]
  by_cases hjlast : j = last
  · rw [hjlast]
    simp only [cellSource, if_pos rfl, hlast]
    change (R *ᵥ ![(R⁻¹ *ᵥ w) 0, (R⁻¹ *ᵥ w) 1]) t = w t
    have he : ![(R⁻¹ *ᵥ w) 0, (R⁻¹ *ᵥ w) 1] = R⁻¹ *ᵥ w := by ext q; fin_cases q <;> rfl
    rw [he, Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv R hR, Matrix.one_mulVec]
  · have hj0 : j + 1 ≠ 0 := by intro h0; apply hjlast; exact add_right_cancel (h0.trans hlast.symm)
    simp only [cellSource, if_neg hjlast, if_neg hj0]
    have he : ![(0 : ℂ), 0] = 0 := by ext q; fin_cases q <;> rfl
    rw [he, Matrix.mulVec_zero]
    rfl

theorem finitePencil_det_ne_zero (n : ℕ) (a r ω x : ℝ) {z : ℂ} (hz : ‖z‖ ≠ 1) :
    (z • finiteEven n a - finiteOdd n r ω x).det ≠ 0 := by
  intro h
  have hp := finiteCMV_det_pencil n a r ω x z
  rw [h, mul_zero] at hp
  exact finiteCMV_det_ne_zero n a r ω x hz hp

theorem finiteMonodromy_inverse_vectorNorm_le (n : ℕ) {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (ω x : ℝ) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1)
    (C : ℝ) (hC : ∀ y, ‖(localResidual a r z y)⁻¹‖ ≤ C) (w : Fin 2 → ℂ) :
    vectorNorm ((1 - finiteMonodromy n a r ω x z)⁻¹ *ᵥ w) ≤
      (4 * C / |‖z‖ - 1|) * vectorNorm w := by
  let last : ZMod (n + 1) := n
  let R := localResidual a r z (x + last.val * ω)
  let p := cellSource n last (R⁻¹ *ᵥ w)
  let P := z • finiteEven n a - finiteOdd n r ω x
  let u := P⁻¹ *ᵥ p
  have hP : IsUnit P.det := isUnit_iff_ne_zero.mpr (finitePencil_det_ne_zero n a r ω x hcircle)
  have hPu : P *ᵥ u = p := by
    dsimp only [u]
    rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv P hP, Matrix.one_mulVec]
  have hB : finiteTransferSystem n a r ω x z *ᵥ (finiteStateMatrix n r ω x *ᵥ u) =
      cellSource n 0 w := by
    rw [Matrix.mulVec_mulVec, finiteTransferSystem_mul_stateMatrix n ha hr hr1 ω x hz,
      ← Matrix.mulVec_mulVec, hPu]
    exact finiteResidualMatrix_source n ha hr hr1 ω x hz w
  have hs := finiteTransferSystem_solution_initial n a r ω x z
    (finiteStateMatrix n r ω x *ᵥ u) w hB
  simp only [finiteStateMatrix_mulVec, finiteState, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one] at hs
  have hM : IsUnit (1 - finiteMonodromy n a r ω x z).det :=
    isUnit_iff_ne_zero.mpr (finiteMonodromy_det_ne_zero n ha hr hr1 ω x hz hcircle)
  have hinv : (1 - finiteMonodromy n a r ω x z)⁻¹ *ᵥ w = finiteState n r ω x u 0 := by
    rw [← hs, Matrix.mulVec_mulVec, Matrix.nonsing_inv_mul _ hM, Matrix.one_mulVec]
    rfl
  have hp : vectorNorm p ≤ 2 * C * vectorNorm w := by
    calc
      vectorNorm p ≤ 2 * vectorNorm (R⁻¹ *ᵥ w) := cellSource_vectorNorm_le n last _
      _ ≤ 2 * (‖R⁻¹‖ * vectorNorm w) := mul_le_mul_of_nonneg_left (Matrix.l2_opNorm_mulVec _ ((EuclideanSpace.equiv (Fin 2) ℂ).symm w)) (by norm_num)
      _ ≤ 2 * (C * vectorNorm w) := mul_le_mul_of_nonneg_left
        (mul_le_mul_of_nonneg_right (hC _) (norm_nonneg ((EuclideanSpace.equiv (Fin 2) ℂ).symm w))) (by norm_num)
      _ = _ := by ring
  have hl := finitePencil_vector_lower n a r ω x z u
  change |‖z‖ - 1| * vectorNorm u ≤ vectorNorm (P *ᵥ u) at hl
  rw [hPu] at hl
  have hd : 0 < |‖z‖ - 1| := abs_pos.mpr (sub_ne_zero.mpr hcircle)
  have hu : vectorNorm u ≤ (2 * C * vectorNorm w) / |‖z‖ - 1| := by
    apply (le_div_iff₀ hd).mpr
    nlinarith
  rw [hinv]
  calc
    vectorNorm (finiteState n r ω x u 0) ≤ 2 * vectorNorm u := finiteState_vectorNorm_le n r ω x u 0
    _ ≤ 2 * ((2 * C * vectorNorm w) / |‖z‖ - 1|) := mul_le_mul_of_nonneg_left hu (by norm_num)
    _ = _ := by ring

theorem exists_uniform_finiteMonodromy_inverse_bound {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) {z : ℂ} (hz : z ≠ 0) (hcircle : ‖z‖ ≠ 1) :
    ∃ K : ℝ, 1 ≤ K ∧ ∀ n ω x,
      transferNorm ((1 - finiteMonodromy n a r ω x z)⁻¹) ≤ K := by
  obtain ⟨C, hC1, hC⟩ := exists_uniform_localResidual_inverse_bound ha hr hr1 hz
  let K := 4 * C / |‖z‖ - 1|
  have hK : 0 ≤ K := by dsimp [K]; positivity
  refine ⟨max 1 K, le_max_left _ _, fun n ω x => ?_⟩
  apply le_trans _ (le_max_right 1 K)
  unfold transferNorm
  apply ContinuousLinearMap.opNorm_le_bound _ hK
  intro w
  exact finiteMonodromy_inverse_vectorNorm_le n ha hr hr1 ω x hz hcircle C hC w

end UAMO.CMV

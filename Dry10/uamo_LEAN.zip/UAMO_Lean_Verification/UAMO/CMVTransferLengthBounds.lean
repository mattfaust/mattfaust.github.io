import UAMO.CMVTransferCircleBounds

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory
open scoped Matrix.L2OpNorm

theorem transferProduct_length_norm_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) (θ : ℝ) {n m : ℕ} (hnm : n ≤ m) :
    transferNorm (transferProduct A ω θ m) ≤
      K ^ (m - n) *
        transferNorm (transferProduct A ω θ n) := by
  have heq : (m - n) + n = m := Nat.sub_add_cancel hnm
  calc
    _ = transferNorm
        (transferProduct A ω (θ + (n:ℝ)*ω) (m - n) *
          transferProduct A ω θ n) := by rw [← transferProduct_add, heq]
    _ ≤ transferNorm
        (transferProduct A ω (θ + (n:ℝ)*ω) (m - n)) *
          transferNorm (transferProduct A ω θ n) := transferNorm_mul_le _ _
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (transferProduct_bound_pow A h ω _ _) (norm_nonneg _)

theorem transferProduct_length_norm_reverse_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) (θ : ℝ) {n m : ℕ} (hnm : n ≤ m) :
    transferNorm (transferProduct A ω θ n) ≤
      K ^ (m - n) *
        transferNorm (transferProduct A ω θ m) := by
  have heq : (m - n) + n = m := Nat.sub_add_cancel hnm
  have hinv : transferProduct A ω θ n =
      transferInverseWord A ω (θ + (n:ℝ)*ω) (m - n) *
        transferProduct A ω θ m := by
    calc
      _ = transferInverseWord A ω (θ + (n:ℝ)*ω) (m - n) *
          (transferProduct A ω (θ + (n:ℝ)*ω) (m - n) *
            transferProduct A ω θ n) := by
        rw [← mul_assoc, transferInverseWord_mul A h, one_mul]
      _ = _ := by rw [← transferProduct_add, heq]
  calc
    _ = transferNorm
        (transferInverseWord A ω (θ + (n:ℝ)*ω) (m - n) *
          transferProduct A ω θ m) := congrArg transferNorm hinv
    _ ≤ transferNorm
        (transferInverseWord A ω (θ + (n:ℝ)*ω) (m - n)) *
          transferNorm (transferProduct A ω θ m) := transferNorm_mul_le _ _
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (transferInverseWord_bound_pow A h ω _ _) (norm_nonneg _)

theorem transferLogNorm_length_abs_sub_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) (θ : ℝ) {n m : ℕ} (hnm : n ≤ m) :
    |transferLogNorm A ω θ m - transferLogNorm A ω θ n| ≤
      ((m : ℝ) - (n : ℝ)) * Real.log (K) := by
  have hK := (pow_pos ((zero_lt_one.trans_le h.one_le)) (m - n)).ne'
  have hf := Real.log_le_log (transferProduct_norm_pos A h.determinant ω θ m)
    (transferProduct_length_norm_le A h ω θ hnm)
  have hb := Real.log_le_log (transferProduct_norm_pos A h.determinant ω θ n)
    (transferProduct_length_norm_reverse_le A h ω θ hnm)
  rw [Real.log_mul hK (transferProduct_norm_pos A h.determinant ω θ n).ne',
    Real.log_pow, Nat.cast_sub hnm] at hf
  rw [Real.log_mul hK (transferProduct_norm_pos A h.determinant ω θ m).ne',
    Real.log_pow, Nat.cast_sub hnm] at hb
  unfold transferLogNorm
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem transferLogAverage_length_abs_sub_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m : ℕ} (hnm : n ≤ m) :
    |transferLogAverage A ω m - transferLogAverage A ω n| ≤
      ((m : ℝ) - (n : ℝ)) * Real.log (K) := by
  have hperiod : 0 < 2 * Real.pi := by positivity
  have hi := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0 : ℝ)) (b := 2 * Real.pi)
    (f := fun θ => transferLogNorm A ω θ m - transferLogNorm A ω θ n)
    (C := ((m : ℝ) - (n : ℝ)) * Real.log (K))
    (fun θ _ => by simpa only [Real.norm_eq_abs] using
      transferLogNorm_length_abs_sub_le A h ω θ hnm)
  unfold transferLogAverage
  rw [← sub_div, abs_div, abs_of_pos hperiod]
  apply (div_le_iff₀ hperiod).mpr
  rw [← intervalIntegral.integral_sub
    ((continuous_transferLogNorm A h.continuous h.determinant ω m).intervalIntegrable 0 (2*Real.pi))
    ((continuous_transferLogNorm A h.continuous h.determinant ω n).intervalIntegrable 0 (2*Real.pi))]
  simpa only [Real.norm_eq_abs, sub_zero, abs_of_pos hperiod] using hi

theorem finiteLyapunov_length_abs_sub_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m : ℕ} (hn : 0 < n) (hnm : n ≤ m) :
    |finiteLyapunov A ω m - finiteLyapunov A ω n| ≤
      2 * Real.log (K) * ((m : ℝ) - (n : ℝ)) / (n : ℝ) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hnm' : (n : ℝ) ≤ (m : ℝ) := by exact_mod_cast hnm
  have hgap := transferLogAverage_length_abs_sub_le A h ω hnm
  rw [transferLogAverage_eq_mul_finite, transferLogAverage_eq_mul_finite] at hgap
  have hB := Real.log_nonneg (h.one_le)
  have hL0 := finiteLyapunov_nonneg A h.determinant ω m
  have hL1 := finiteLyapunov_bound_log A h ω m
  have hp0 := mul_nonneg (sub_nonneg.mpr hnm') hL0
  have hp1 := mul_le_mul_of_nonneg_left hL1 (sub_nonneg.mpr hnm')
  have hscaled : |(n : ℝ) *
      (finiteLyapunov A ω m - finiteLyapunov A ω n)| ≤
      2 * Real.log (K) * ((m : ℝ) - (n : ℝ)) := by
    exact abs_le.mpr ⟨by nlinarith [(abs_le.mp hgap).1],
      by nlinarith [(abs_le.mp hgap).2, mul_nonneg (sub_nonneg.mpr hnm') hB]⟩
  apply (le_div_iff₀ hn').mpr
  simpa only [abs_mul, abs_of_pos hn', mul_comm] using hscaled

theorem finiteLyapunov_two_mul_le (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) (n : ℕ) :
    finiteLyapunov A ω (2 * n) ≤ finiteLyapunov A ω n := by
  by_cases hn : n = 0
  · subst n
    simp
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn
  have h := transferLogAverage_subadditive A h.continuous h.periodic h.determinant ω n n
  rw [← two_mul n] at h
  simp only [transferLogAverage_eq_mul_finite, Nat.cast_mul, Nat.cast_ofNat] at h
  nlinarith

theorem finiteLyapunov_dyadicGap_bounds (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) (n : ℕ) :
    0 ≤ finiteLyapunov A ω n - finiteLyapunov A ω (2 * n) ∧
    finiteLyapunov A ω n - finiteLyapunov A ω (2 * n) ≤
      Real.log (K) := by
  exact ⟨sub_nonneg.mpr (finiteLyapunov_two_mul_le A h ω n),
    (sub_le_self _ (finiteLyapunov_nonneg A h.determinant ω (2 * n))).trans
      (finiteLyapunov_bound_log A h ω n)⟩

theorem finiteLyapunov_dyadicGap_length_abs_sub_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m : ℕ} (hn : 0 < n) (hnm : n ≤ m) :
    |(finiteLyapunov A ω m - finiteLyapunov A ω (2 * m)) -
      (finiteLyapunov A ω n - finiteLyapunov A ω (2 * n))| ≤
      4 * Real.log (K) * ((m : ℝ) - (n : ℝ)) / (n : ℝ) := by
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_of_gt hn
  have h1 := finiteLyapunov_length_abs_sub_le A h ω hn hnm
  have h2 := finiteLyapunov_length_abs_sub_le A h ω
    (n := 2 * n) (m := 2 * m) (by omega) (by omega)
  have heq : 2 * Real.log (K) *
      (((2 * m : ℕ) : ℝ) - ((2 * n : ℕ) : ℝ)) / ((2 * n : ℕ) : ℝ) =
      2 * Real.log (K) * ((m : ℝ) - (n : ℝ)) / (n : ℝ) := by
    push_cast
    field_simp
    ring
  rw [heq] at h2
  have ht := (abs_sub
    (finiteLyapunov A ω m - finiteLyapunov A ω n)
    (finiteLyapunov A ω (2 * m) - finiteLyapunov A ω (2 * n))).trans
      (add_le_add h1 h2)
  convert ht using 1 <;> congr 1 <;> ring

theorem finiteLyapunov_rounding_abs_sub_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) :
    |finiteLyapunov A ω m - finiteLyapunov A ω n| ≤
      2 * Real.log (K) * (q : ℝ) / (n : ℝ) := by
  have hδ : (m : ℝ) - (n : ℝ) ≤ (q : ℝ) := by
    have h : (m : ℝ) ≤ (n : ℝ) + (q : ℝ) := by exact_mod_cast hmq
    linarith
  exact (finiteLyapunov_length_abs_sub_le A h ω hn hnm).trans
    (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hδ
        (mul_nonneg (by norm_num) (Real.log_nonneg (h.one_le))))
      (Nat.cast_nonneg n))

theorem finiteLyapunov_rounding_lower
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) :
    finiteLyapunov A ω n -
        2 * Real.log (K) * (q : ℝ) / (n : ℝ) ≤
      finiteLyapunov A ω m := by
  have h := (abs_le.mp (finiteLyapunov_rounding_abs_sub_le A h ω hn hnm hmq)).1
  linarith

theorem finiteLyapunov_dyadicGap_rounding_abs_sub_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) :
    |(finiteLyapunov A ω m - finiteLyapunov A ω (2 * m)) -
      (finiteLyapunov A ω n - finiteLyapunov A ω (2 * n))| ≤
      4 * Real.log (K) * (q : ℝ) / (n : ℝ) := by
  have hδ : (m : ℝ) - (n : ℝ) ≤ (q : ℝ) := by
    have h : (m : ℝ) ≤ (n : ℝ) + (q : ℝ) := by exact_mod_cast hmq
    linarith
  exact (finiteLyapunov_dyadicGap_length_abs_sub_le A h ω hn hnm).trans
    (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hδ
        (mul_nonneg (by norm_num) (Real.log_nonneg (h.one_le))))
      (Nat.cast_nonneg n))

theorem finiteLyapunov_weightedDyadicGap_rounding_le
    (A : ℝ→TransferMatrix) {K:ℝ} (h : TransferCircleBounds A K) (ω:ℝ) {n m q : ℕ}
    (hn : 0 < n) (hnm : n ≤ m) (hmq : m ≤ n + q) (hqn : q ≤ n) :
    (m : ℝ) * (finiteLyapunov A ω m - finiteLyapunov A ω (2 * m)) ≤
      (n : ℝ) * (finiteLyapunov A ω n - finiteLyapunov A ω (2 * n)) +
        9 * Real.log (K) * (q : ℝ) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hnm' : (n : ℝ) ≤ (m : ℝ) := by exact_mod_cast hnm
  have hm2 : (m : ℝ) ≤ 2 * (n : ℝ) := by
    have h : m ≤ 2 * n := by omega
    exact_mod_cast h
  have hδ : (m : ℝ) - (n : ℝ) ≤ (q : ℝ) := by
    have h : (m : ℝ) ≤ (n : ℝ) + (q : ℝ) := by exact_mod_cast hmq
    linarith
  have hB := Real.log_nonneg (h.one_le)
  have hgap := mul_le_mul_of_nonneg_left
    (abs_le.mp (finiteLyapunov_dyadicGap_rounding_abs_sub_le A h ω hn hnm hmq)).2
    (Nat.cast_nonneg m : (0 : ℝ) ≤ (m : ℝ))
  have herr := mul_le_mul_of_nonneg_right hm2
    (show 0 ≤ 4 * Real.log (K) * (q : ℝ) / (n : ℝ) by positivity)
  have hcancel : (2 * (n : ℝ)) *
      (4 * Real.log (K) * (q : ℝ) / (n : ℝ)) =
      8 * Real.log (K) * (q : ℝ) := by
    field_simp
    ring
  rw [hcancel] at herr
  have hd := mul_le_mul_of_nonneg_left (finiteLyapunov_dyadicGap_bounds A h ω n).2
    (sub_nonneg.mpr hnm')
  have hdq := mul_le_mul_of_nonneg_right hδ hB
  nlinarith

end UAMO.CMV

import UAMO.PeriodicRotationAverages
import UAMO.CMVConjugacyGrowth
import UAMO.CMVTransferDetGrowthComparison

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter Set CircleDOS
open scoped Topology Matrix.L2OpNorm

theorem transferNorm_inv_le_four (M : TransferMatrix) (hd : ‖M.det‖=1) :
    transferNorm M⁻¹≤4*transferNorm M := by
  have hne : M.det≠0 := by intro h; simp [h] at hd
  have hdi : ‖M⁻¹.det‖=1 := by
    rw [Matrix.det_nonsing_inv,Ring.inverse_eq_inv,norm_inv,hd,inv_one]
  have hnei : M⁻¹.det≠0 := by intro h; simp [h] at hdi
  have h := transferNorm_le_det_inverse M⁻¹ hnei
  rw [hdi,mul_one,Matrix.nonsing_inv_nonsing_inv M (isUnit_iff_ne_zero.mpr hne)] at h
  exact h

end UAMO.CMV

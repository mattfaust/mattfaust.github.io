import UAMO.UAMONearPeriodicPropagation
import UAMO.CMVTransferCircleBounds

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set CircleDOS BourgainJitomirskaya
open scoped Matrix.L2OpNorm

theorem finiteTransfer_two_badMasses_uniform {D κ:ℝ} (hD:1≤D)
    (hκ:0<κ) (hκ1:κ≤1) :
    ∃C c:ℝ,0<C ∧ 0<c ∧ ∃Q:ℕ,8≤Q ∧
      ∀(A:ℝ→TransferMatrix)(hc:Continuous A)(hp:Function.Periodic A (2*Real.pi))
        (hd:∀x,‖(A x).det‖=1),
      (∀x,transferNorm (A x)≤D) →
      (∀ω:ℝ,∀n:ℕ,0<n → ∀k:ℤ,k≠0 →
        ‖logFourierCoeff (finiteFrobeniusLog A ω n) k‖≤2/|(k:ℝ)|) →
      ∀(α:ℝ)(p:ℤ)(q n:ℕ),Q≤q → IsCoprime p (q:ℤ) →
        |α-(p:ℝ)/(q:ℝ)|<1/(q:ℝ)^2 → C*(q:ℝ)≤n →
        ((volume.restrict (Ioc (0:ℝ) 1)).real
          {t:ℝ | κ < |transferLogNorm A (2*Real.pi*α) (2*Real.pi*t) n/(n:ℝ)-
            finiteLyapunov A (2*Real.pi*α) n| }≤Real.exp (-c*q)) ∧
        AddCircle.haarAddCircle.real (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) n
          (finiteLyapunov A (2*Real.pi*α) n) κ)≤Real.exp (-c*q) := by
  let B := Real.log (4*D^2)+Real.log 2
  have hB : 0<B := by
    have hb : 1≤4*D^2 := by nlinarith
    have hl := Real.log_nonneg hb
    have h2 : 0<Real.log 2 := Real.log_pos (by norm_num)
    dsimp [B]
    linarith
  obtain ⟨C,c,hC,hc',Q,hQ,hldt⟩ := fourier_largeDeviation_two hB (half_pos hκ)
    (by linarith : κ/2≤1)
  let C' := max C (2*Real.log 2/κ+1)
  have hCC : C≤C' := le_max_left _ _
  have hC' : 0<C' := hC.trans_le hCC
  refine ⟨C',c,hC',hc',Q,hQ,?_⟩
  intro A hc hp hd hbound hfourier α p q n hq hcop happrox hn
  have hq1 : (1:ℝ)≤q := by exact_mod_cast (show 1≤q by omega)
  have hnR : (0:ℝ)<n := (mul_pos hC' (by linarith)).trans_le hn
  have hnNat : 0<n := by exact_mod_cast hnR
  have hscale : Real.log 2/(n:ℝ)≤(κ/2) := by
    have hbase : 2*Real.log 2/κ+1≤C' := le_max_right _ _
    have hnC : C'≤n := (le_mul_of_one_le_right hC'.le hq1).trans hn
    have hmul := (div_le_iff₀ hκ).mp (show 2*Real.log 2/κ≤(n:ℝ) by linarith)
    apply (div_le_iff₀ hnR).mpr
    nlinarith
  let f := finiteFrobeniusCircle A hc hp hd (2*Real.pi*α) n
  have hprob := hldt f α p q n hq hcop happrox
    (fun k hk => by rw [fourierCoeff_finiteFrobeniusCircle]; exact hfourier _ n hnNat k hk)
    (fun x => finiteFrobeniusCircle_shift_difference A hc hp hd hbound α hnNat x)
    ((mul_le_mul_of_nonneg_right hCC (Nat.cast_nonneg q)).trans hn)
  have hs : MeasurableSet {x:AddCircle (1:ℝ)|κ/2<‖f x-fourierCoeff f 0‖} :=
    (isOpen_lt continuous_const ((f.continuous.sub continuous_const).norm)).measurableSet
  constructor
  · calc
      _ ≤ (volume.restrict (Ioc (0:ℝ) 1)).real
          ((fun t:ℝ => (t:AddCircle (1:ℝ))) ⁻¹'
            {x:AddCircle (1:ℝ)|κ/2<‖f x-fourierCoeff f 0‖}) :=
        measureReal_mono (operatorDeviation_subset_frobenius_preimage A hc hp hd _ hnNat κ hscale)
      _ = AddCircle.haarAddCircle.real {x:AddCircle (1:ℝ)|κ/2<‖f x-fourierCoeff f 0‖} :=
        unitCircle_measurePreserving_mk.measureReal_preimage hs.nullMeasurableSet
      _ ≤ _ := hprob
  · exact (measureReal_mono (frobeniusDeviation_subset_centered A hc hp hd _ hnNat κ hscale)).trans hprob

theorem uniform_uamo_recordBadMasses {K κ:ℝ} (hK:1≤K) (hκ:0<κ) (hκ1:κ≤1) :
    ∃C c:ℝ,1≤C ∧ 0<c ∧ c/(100*κ)≤C ∧ ∃Q:ℕ,8≤Q ∧
      ∀(a r:ℝ)(z:ℂ)(y:ℝ)(A:ℝ→TransferMatrix)(g:ℝ→ℂ)(hA:TransferCircleBounds A K),
      a≠0 → 0<r → r≤1 → z≠0 → |y|≠ -Real.log r →
      (∀x,g x • A x=complexifiedPhaseTransfer a r z y x) →
      ∀(α:ℝ)(p:ℤ)(q:ℕ),Q≤q → IsCoprime p (q:ℤ) →
        |α-(p:ℝ)/(q:ℝ)|<1/(q:ℝ)^2 →
        RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c q := by
  obtain ⟨C₀,c,_,hc,Q,hQ,hldt⟩ := finiteTransfer_two_badMasses_uniform hK hκ hκ1
  let C := max 1 (max C₀ (c/(100*κ)))
  have hC : 1≤C := le_max_left _ _
  have hCC : C₀≤C := (le_max_left _ _).trans (le_max_right _ _)
  have hcC : c/(100*κ)≤C := (le_max_right _ _).trans (le_max_right _ _)
  refine ⟨C,c,hC,hc,hcC,Q,hQ,?_⟩
  intro a r z y A g hA ha hr hr1 hz hy hrel α p q hq hcop happ N hN
  apply hldt A hA.continuous hA.periodic hA.determinant hA.forward _ α p q N hq hcop happ
    ((mul_le_mul_of_nonneg_right hCC (Nat.cast_nonneg q)).trans hN)
  intro ω n hn k hk
  exact uamo_normalizedTransfer_fourier_bound ha hr hr1 hz hy A g hA.determinant hrel ω hn hk

end UAMO.CMV

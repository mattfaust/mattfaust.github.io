import UAMO.MagneticStationarity
import Mathlib.Analysis.CStarAlgebra.Spectrum
import Mathlib.Analysis.CStarAlgebra.ContinuousLinearMap
import Mathlib.Topology.Algebra.StarSubalgebra

noncomputable section
namespace UAMO
open scoped InnerProductSpace

def rootTrace : MagneticOperator →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun A => A magneticOrigin (0, 0)
      map_add' := by intro A B; simp
      map_smul' := by intro c A; simp }
    1 (fun A => by
      calc
        ‖A magneticOrigin (0, 0)‖ ≤ ‖A magneticOrigin‖ :=
          lp.norm_apply_le_norm (by norm_num) (A magneticOrigin) (0, 0)
        _ ≤ ‖A‖ * ‖magneticOrigin‖ := A.le_opNorm magneticOrigin
        _ = 1 * ‖A‖ := by rw [magneticOrigin_norm]; ring)

@[simp] theorem rootTrace_apply (A : MagneticOperator) :
    rootTrace A = A magneticOrigin (0, 0) := rfl

theorem rootTrace_eq_inner (A : MagneticOperator) :
    rootTrace A = @inner ℂ MagneticSpace _ magneticOrigin (A magneticOrigin) := by
  simp [magneticOrigin, lp.inner_single_left]

@[simp] theorem rootTrace_one : rootTrace (1 : MagneticOperator) = 1 := by
  simp [rootTrace_apply, magneticOrigin, lp.single_apply]

@[simp] theorem rootTrace_magneticShift (φ : ℝ) (ν : MagneticSite) :
    rootTrace (magneticShift φ ν) = if ν = 0 then 1 else 0 := by
  rw [rootTrace_apply, magneticShift_origin]
  simp [lp.single_apply, Pi.single_apply, eq_comm]

theorem rootTrace_shifts_cyclic (φ : ℝ) (ν μ : MagneticSite) :
    rootTrace (magneticShift φ ν * magneticShift φ μ) =
      rootTrace (magneticShift φ μ * magneticShift φ ν) := by
  rw [magneticShift_mul, magneticShift_mul, map_smul, map_smul]
  simp only [rootTrace_magneticShift, smul_eq_mul]
  by_cases h : ν + μ = 0
  · have hμ : μ = -ν := eq_neg_of_add_eq_zero_right h
    subst μ
    have hw : wedge ν (-ν) = 0 := by simp [wedge]; ring
    have hw' : wedge (-ν) ν = 0 := by simp [wedge]; ring
    simp [hw, hw']
  · have h' : μ + ν ≠ 0 := by simpa [add_comm] using h
    simp [h, h']

def magneticPolynomialSpace (α : ℝ) : Submodule ℂ MagneticOperator :=
  Submodule.span ℂ (Set.range (magneticShift α))

theorem magneticShift_mem_polynomialSpace (α : ℝ) (a : MagneticSite) :
    magneticShift α a ∈ magneticPolynomialSpace α :=
  Submodule.subset_span (Set.mem_range_self a)

theorem magneticPolynomialSpace_one_mem (α : ℝ) :
    (1 : MagneticOperator) ∈ magneticPolynomialSpace α := by
  rw [← magneticShift_zero α]
  exact magneticShift_mem_polynomialSpace α 0

theorem magneticPolynomialSpace_mul_mem (α : ℝ) {A B : MagneticOperator}
    (hA : A ∈ magneticPolynomialSpace α) (hB : B ∈ magneticPolynomialSpace α) :
    A * B ∈ magneticPolynomialSpace α := by
  induction hA, hB using Submodule.span_induction₂ with
  | mem_mem A B hA hB =>
    obtain ⟨a, rfl⟩ := hA
    obtain ⟨b, rfl⟩ := hB
    rw [magneticShift_mul]
    exact (magneticPolynomialSpace α).smul_mem _ (magneticShift_mem_polynomialSpace α (a + b))
  | zero_left B hB => simp
  | zero_right A hA => simp
  | add_left A C B hA hC hB ihA ihC =>
    simpa only [add_mul] using (magneticPolynomialSpace α).add_mem ihA ihC
  | add_right A B C hA hB hC ihB ihC =>
    simpa only [mul_add] using (magneticPolynomialSpace α).add_mem ihB ihC
  | smul_left c A B hA hB ih =>
    have heq : (c • A) * B = c • (A * B) := by
      apply ContinuousLinearMap.ext
      intro u
      rfl
    rw [heq]
    exact (magneticPolynomialSpace α).smul_mem c ih
  | smul_right c A B hA hB ih =>
    simpa only [mul_smul_comm] using (magneticPolynomialSpace α).smul_mem c ih

theorem rootTrace_polynomials_cyclic (α : ℝ) {A B : MagneticOperator}
    (hA : A ∈ magneticPolynomialSpace α) (hB : B ∈ magneticPolynomialSpace α) :
    rootTrace (A * B) = rootTrace (B * A) := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    induction hB using Submodule.span_induction with
    | mem B hB =>
      obtain ⟨b, rfl⟩ := hB
      exact rootTrace_shifts_cyclic α a b
    | zero => simp
    | add B C hB hC ihB ihC => simp only [mul_add, add_mul, map_add, ihB, ihC]
    | smul c B hB ihB => simp only [mul_smul_comm, smul_mul_assoc, map_smul, ihB]
  | zero => simp
  | add A C hA hC ihA ihC => simp only [mul_add, add_mul, map_add, ihA, ihC]
  | smul c A hA ihA => simp only [mul_smul_comm, smul_mul_assoc, map_smul, ihA]

def magneticPolynomialClosure (α : ℝ) : Set MagneticOperator :=
  closure (magneticPolynomialSpace α : Set MagneticOperator)

theorem rootTrace_closure_cyclic (α : ℝ) {A B : MagneticOperator}
    (hA : A ∈ magneticPolynomialClosure α) (hB : B ∈ magneticPolynomialClosure α) :
    rootTrace (A * B) = rootTrace (B * A) := by
  have hfirst (B : MagneticOperator) (hB : B ∈ magneticPolynomialSpace α) :
      rootTrace (A * B) = rootTrace (B * A) := by
    apply closure_minimal
      (fun C hC => rootTrace_polynomials_cyclic α hC hB)
      (isClosed_eq
        (rootTrace.continuous.comp (continuous_id.mul continuous_const))
        (rootTrace.continuous.comp (continuous_const.mul continuous_id))) hA
  exact closure_minimal (fun C hC => hfirst C hC)
    (isClosed_eq
      (rootTrace.continuous.comp (continuous_const.mul continuous_id))
      (rootTrace.continuous.comp (continuous_id.mul continuous_const))) hB

theorem magneticPolynomialSpace_star_mem (α : ℝ) {A : MagneticOperator}
    (hA : A ∈ magneticPolynomialSpace α) : star A ∈ magneticPolynomialSpace α := by
  induction hA using Submodule.span_induction with
  | mem A hA =>
    obtain ⟨a, rfl⟩ := hA
    rw [magneticShift_star]
    exact magneticShift_mem_polynomialSpace α (-a)
  | zero => simp
  | add A B hA hB ihA ihB =>
    simpa only [star_add] using (magneticPolynomialSpace α).add_mem ihA ihB
  | smul c A hA ih =>
    simpa only [star_smul] using (magneticPolynomialSpace α).smul_mem (star c) ih

def magneticPolynomialStarAlgebra (α : ℝ) : StarSubalgebra ℂ MagneticOperator where
  carrier := magneticPolynomialSpace α
  zero_mem' := (magneticPolynomialSpace α).zero_mem
  one_mem' := magneticPolynomialSpace_one_mem α
  add_mem' := (magneticPolynomialSpace α).add_mem
  mul_mem' := magneticPolynomialSpace_mul_mem α
  algebraMap_mem' := by
    intro c
    rw [Algebra.algebraMap_eq_smul_one]
    exact (magneticPolynomialSpace α).smul_mem c (magneticPolynomialSpace_one_mem α)
  star_mem' := magneticPolynomialSpace_star_mem α

def magneticAlgebra (α : ℝ) : StarSubalgebra ℂ MagneticOperator :=
  (magneticPolynomialStarAlgebra α).topologicalClosure

instance magneticAlgebra_isClosed (α : ℝ) :
    IsClosed (magneticAlgebra α : Set MagneticOperator) :=
  StarSubalgebra.isClosed_topologicalClosure _

theorem polynomialSpace_subset_magneticAlgebra (α : ℝ) {A : MagneticOperator}
    (hA : A ∈ magneticPolynomialSpace α) : A ∈ magneticAlgebra α :=
  subset_closure hA

theorem rootTrace_magneticAlgebra_cyclic (φ : ℝ) {A B : MagneticOperator}
    (hA : A ∈ magneticAlgebra φ) (hB : B ∈ magneticAlgebra φ) :
    rootTrace (A * B) = rootTrace (B * A) :=
  rootTrace_closure_cyclic φ hA hB

instance magneticAlgebra_realNormedAlgebra (φ : ℝ) :
    NormedAlgebra ℝ (magneticAlgebra φ) :=
  NormedAlgebra.restrictScalars ℝ ℂ (magneticAlgebra φ)

local instance (φ : ℝ) : NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)

local instance (φ : ℝ) : Module ℝ (magneticAlgebra φ) :=
  @Algebra.toModule ℝ (magneticAlgebra φ) _ _
    (magneticAlgebra_realNormedAlgebra φ).toAlgebra

def rootTraceReal : MagneticOperator →L[ℝ] ℝ :=
  Complex.reCLM.comp (rootTrace.restrictScalars ℝ)

@[simp] theorem rootTraceReal_apply (A : MagneticOperator) :
    rootTraceReal A = (rootTrace A).re := rfl

def magneticTraceReal (φ : ℝ) : magneticAlgebra φ →L[ℝ] ℝ :=
  Complex.reCLM.comp ((rootTrace.comp
    (magneticAlgebra φ).toSubalgebra.toSubmodule.subtypeL).restrictScalars ℝ)

@[simp] theorem magneticTraceReal_apply (φ : ℝ) (A : magneticAlgebra φ) :
    magneticTraceReal φ A = (rootTrace (A : MagneticOperator)).re := rfl

theorem magneticTraceReal_cyclic (φ : ℝ) (A B : magneticAlgebra φ) :
    magneticTraceReal φ (A * B) = magneticTraceReal φ (B * A) :=
  congrArg Complex.re (rootTrace_magneticAlgebra_cyclic φ A.property B.property)

@[simp] theorem magneticTraceReal_one (φ : ℝ) : magneticTraceReal φ 1 = 1 := by
  change (rootTrace (1 : MagneticOperator)).re = 1
  rw [rootTrace_one]
  rfl

theorem magneticTraceReal_star_mul_self (φ : ℝ) (A : magneticAlgebra φ) :
    magneticTraceReal φ (star A * A) = ‖(A : MagneticOperator) magneticOrigin‖ ^ 2 := by
  rw [magneticTraceReal_apply, rootTrace_eq_inner]
  change (⟪magneticOrigin,
    star (A : MagneticOperator) ((A : MagneticOperator) magneticOrigin)⟫_ℂ).re = _
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  exact inner_self_eq_norm_sq (𝕜 := ℂ) _

theorem magneticTraceReal_star_mul_self_nonneg (φ : ℝ) (A : magneticAlgebra φ) :
    0 ≤ magneticTraceReal φ (star A * A) := by
  rw [magneticTraceReal_star_mul_self]
  positivity

set_option maxHeartbeats 800000 in

theorem magneticTraceReal_faithful (φ : ℝ) (A : magneticAlgebra φ)
    (h : magneticTraceReal φ (star A * A) = 0) : A = 0 := by
  have horbit (ν : MagneticSite) :
      (A : MagneticOperator) (magneticShift φ ν magneticOrigin) = 0 := by
    let W : magneticAlgebra φ := ⟨magneticShift φ ν,
      polynomialSpace_subset_magneticAlgebra φ (magneticShift_mem_polynomialSpace φ ν)⟩
    have hW : W * star W = 1 := by
      apply Subtype.ext
      change magneticShift φ ν * star (magneticShift φ ν) = 1
      rw [magneticShift_star, magneticShift_inverse]
    have hz : magneticTraceReal φ (star (A * W) * (A * W)) = 0 := by
      calc
        magneticTraceReal φ (star (A * W) * (A * W)) =
            magneticTraceReal φ (star W * (star A * A * W)) := by
          rw [star_mul]; congr 1
        _ = magneticTraceReal φ ((star A * A * W) * star W) :=
          magneticTraceReal_cyclic φ _ _
        _ = magneticTraceReal φ (star A * A) := by rw [mul_assoc, hW, mul_one]
        _ = 0 := h
    rw [magneticTraceReal_star_mul_self] at hz
    exact norm_eq_zero.mp ((sq_eq_zero_iff).mp hz)
  apply Subtype.ext
  apply lp.ext_continuousLinearMap (by norm_num : (2 : ENNReal) ≠ ⊤)
  intro s
  apply ContinuousLinearMap.ext
  intro z
  have hz : (lp.single 2 s z : MagneticSpace) = z • lp.single 2 s (1 : ℂ) := by
    simp [← lp.single_smul]
  change (A : MagneticOperator) (lp.single 2 s z) = 0
  rw [hz, map_smul, ← magneticShift_origin φ s, horbit s, smul_zero]

theorem magneticPair_mem_magneticAlgebra (φ : ℝ) (ν : MagneticSite) (c : ℂ) :
    magneticPair φ ν c ∈ magneticAlgebra φ := by
  apply polynomialSpace_subset_magneticAlgebra
  exact (magneticPolynomialSpace φ).add_mem
    ((magneticPolynomialSpace φ).smul_mem c (magneticShift_mem_polynomialSpace φ ν))
    ((magneticPolynomialSpace φ).smul_mem (star c) (magneticShift_mem_polynomialSpace φ (-ν)))

def algebraMagneticPair (φ : ℝ) (ν : MagneticSite) (c : ℂ) : magneticAlgebra φ :=
  ⟨magneticPair φ ν c, magneticPair_mem_magneticAlgebra φ ν c⟩

def scalarAlgebraHamiltonian (a r φ : ℝ) : magneticAlgebra φ :=
  algebraMagneticPair φ (1, 0) 1 +
    r • algebraMagneticPair φ (1, 1) (diagonalHopping a φ) +
      r ^ 2 • algebraMagneticPair φ (1, 2) (-1)

@[simp] theorem scalarAlgebraHamiltonian_coe (a r φ : ℝ) :
    (scalarAlgebraHamiltonian a r φ : MagneticOperator) = scalarHamiltonian a r φ := by
  exact (scalarHamiltonian_polynomial a r φ).symm

theorem scalarAlgebraHamiltonian_isSelfAdjoint (a r φ : ℝ) :
    IsSelfAdjoint (scalarAlgebraHamiltonian a r φ) := by
  apply Subtype.ext
  change star (scalarAlgebraHamiltonian a r φ : MagneticOperator) = _
  rw [scalarAlgebraHamiltonian_coe]
  exact scalarHamiltonian_selfAdjoint a r φ

def scalarAlgebraHamiltonianDerivative (a r φ : ℝ) : magneticAlgebra φ :=
  algebraMagneticPair φ (1, 1) (diagonalHopping a φ) +
    (2 * r) • algebraMagneticPair φ (1, 2) (-1)

@[simp] theorem scalarAlgebraHamiltonianDerivative_coe (a r φ : ℝ) :
    (scalarAlgebraHamiltonianDerivative a r φ : MagneticOperator) =
      scalarHamiltonianDerivative a r φ := rfl

theorem scalarAlgebraHamiltonian_hasDerivAt (a r φ : ℝ) :
    HasDerivAt (fun t : ℝ => scalarAlgebraHamiltonian a t φ)
      (scalarAlgebraHamiltonianDerivative a r φ) r := by
  have h0 := hasDerivAt_const r (algebraMagneticPair φ (1, 0) 1)
  have h1 := (hasDerivAt_id r).smul_const (algebraMagneticPair φ (1, 1) (diagonalHopping a φ))
  have h2 := ((hasDerivAt_id r).pow 2).smul_const (algebraMagneticPair φ (1, 2) (-1))
  simpa [scalarAlgebraHamiltonian, scalarAlgebraHamiltonianDerivative] using (h0.add h1).add h2

def scalarAlgebraPencil (a r φ E : ℝ) : magneticAlgebra φ :=
  E • (1 : magneticAlgebra φ) - scalarAlgebraHamiltonian a r φ

@[simp] theorem scalarAlgebraPencil_coe (a r φ E : ℝ) :
    (scalarAlgebraPencil a r φ E : MagneticOperator) =
      algebraMap ℂ MagneticOperator (E : ℂ) - scalarHamiltonian a r φ := by
  change E • (1 : MagneticOperator) - (scalarAlgebraHamiltonian a r φ : MagneticOperator) = _
  rw [scalarAlgebraHamiltonian_coe, Algebra.algebraMap_eq_smul_one, Complex.coe_smul]

theorem scalarAlgebraPencil_isSelfAdjoint (a r φ E : ℝ) :
    IsSelfAdjoint (scalarAlgebraPencil a r φ E) := by
  apply Subtype.ext
  change star (scalarAlgebraPencil a r φ E : MagneticOperator) = _
  rw [scalarAlgebraPencil_coe, Algebra.algebraMap_eq_smul_one]
  exact ((show IsSelfAdjoint (E : ℂ) from Complex.conj_ofReal E).smul
    (IsSelfAdjoint.one MagneticOperator)).sub (scalarHamiltonian_selfAdjoint a r φ)

theorem scalarAlgebraPencil_isUnit (a r φ E : ℝ)
    (hz : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    IsUnit (scalarAlgebraPencil a r φ E) := by
  apply (magneticAlgebra φ).coe_isUnit.mp
  rw [scalarAlgebraPencil_coe]
  exact hz

theorem scalarAlgebraPencil_inverse_coe (a r φ E : ℝ)
    (hz : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    ((Ring.inverse (scalarAlgebraPencil a r φ E) : magneticAlgebra φ) : MagneticOperator) =
      resolvent (scalarHamiltonian a r φ) (E : ℂ) := by
  have hleft := congrArg (fun A : magneticAlgebra φ => (A : MagneticOperator))
    (Ring.inverse_mul_cancel _ (scalarAlgebraPencil_isUnit a r φ E hz))
  change ((Ring.inverse (scalarAlgebraPencil a r φ E) : magneticAlgebra φ) : MagneticOperator) *
    (scalarAlgebraPencil a r φ E : MagneticOperator) = 1 at hleft
  rw [scalarAlgebraPencil_coe] at hleft
  exact left_inv_eq_right_inv hleft (Ring.mul_inverse_cancel _ hz)

theorem scalarRealSpectrum_eq_algebraSpectrum (a r φ : ℝ) :
    {E : ℝ | (E : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)} =
      spectrum ℝ (scalarAlgebraHamiltonian a r φ) := by
  ext E
  change (E : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ↔
    E ∈ spectrum ℝ (scalarAlgebraHamiltonian a r φ)
  rw [spectrum.mem_iff, spectrum.mem_iff]
  have hunit : IsUnit (algebraMap ℂ MagneticOperator (E : ℂ) - scalarHamiltonian a r φ) ↔
      IsUnit (scalarAlgebraPencil a r φ E) := by
    rw [← scalarAlgebraPencil_coe]
    exact (magneticAlgebra φ).coe_isUnit
  simpa only [scalarAlgebraPencil, Algebra.algebraMap_eq_smul_one] using not_congr hunit

end UAMO

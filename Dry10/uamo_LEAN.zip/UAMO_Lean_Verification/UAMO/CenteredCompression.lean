import UAMO.HeightTheorem
import Mathlib.Analysis.InnerProductSpace.LinearMap

noncomputable section
namespace UAMO
open scoped InnerProductSpace

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

def centerProjection (Ω : E) : E →L[ℂ] E :=
  1 - (innerSL ℂ Ω).smulRight Ω

@[simp] theorem centerProjection_apply (Ω v : E) :
    centerProjection Ω v = v - ⟪Ω, v⟫_ℂ • Ω := rfl

theorem centerProjection_symmetric (Ω : E) :
    (centerProjection Ω).toLinearMap.IsSymmetric := by
  intro u v
  simp only [ContinuousLinearMap.coe_coe, centerProjection_apply,
    inner_sub_left, inner_sub_right, inner_smul_left, inner_smul_right]
  rw [inner_conj_symm]
  congr 1
  ring

theorem centerProjection_origin (Ω : E) (hΩ : ‖Ω‖ = 1) :
    centerProjection Ω Ω = 0 := by
  simp [inner_self_eq_norm_sq_to_K, hΩ]

theorem centerProjection_kernel (Ω v : E) (hv : centerProjection Ω v = 0) :
    ∃ c : ℂ, v = c • Ω := by
  exact ⟨⟪Ω, v⟫_ℂ, sub_eq_zero.mp hv⟩

theorem centerProjection_inner (Ω v : E) (hΩ : ‖Ω‖ = 1) :
    ⟪Ω, centerProjection Ω v⟫_ℂ = 0 := by
  simp [inner_sub_right, inner_smul_right, inner_self_eq_norm_sq_to_K, hΩ]

theorem centerProjection_fixed (Ω v : E) (hv : ⟪Ω, v⟫_ℂ = 0) :
    centerProjection Ω v = v := by simp [hv]

theorem centerProjection_idempotent (Ω v : E) (hΩ : ‖Ω‖ = 1) :
    centerProjection Ω (centerProjection Ω v) = centerProjection Ω v :=
  centerProjection_fixed Ω _ (centerProjection_inner Ω v hΩ)

theorem centerProjection_observable (Ω : E) (L : E →L[ℂ] E)
    (hL : L.toLinearMap.IsSymmetric) (hLΩ : L Ω = 0) (v : E) :
    centerProjection Ω (L v) = L v := by
  apply centerProjection_fixed
  rw [← hL.apply_clm, hLΩ, inner_zero_left]

theorem observable_centerProjection (Ω : E) (L : E →L[ℂ] E)
    (hLΩ : L Ω = 0) (v : E) : L (centerProjection Ω v) = L v := by
  simp [map_sub, map_smul, hLΩ]

theorem centered_commute_from_balance
    (Ω : E) (hΩ : ‖Ω‖ = 1) (H L : E →L[ℂ] E)
    (hL : L.toLinearMap.IsSymmetric) (hLΩ : L Ω = 0)
    (hbalance : ∀ v w : E,
      ⟪v, L (H w) - H (L w)⟫_ℂ =
        ⟪v, L (H Ω)⟫_ℂ * ⟪Ω, w⟫_ℂ -
          ⟪v, Ω⟫_ℂ * ⟪L (H Ω), w⟫_ℂ) (v : E) :
    compressedMap (centerProjection Ω).toLinearMap L.toLinearMap
        (compressedMap (centerProjection Ω).toLinearMap H.toLinearMap v) =
      compressedMap (centerProjection Ω).toLinearMap H.toLinearMap
        (compressedMap (centerProjection Ω).toLinearMap L.toLinearMap v) := by
  let P := centerProjection Ω
  have hP : P.toLinearMap.IsSymmetric := centerProjection_symmetric Ω
  simp only [compressedMap_apply, ContinuousLinearMap.coe_coe,
    centerProjection_idempotent Ω _ hΩ,
    centerProjection_observable Ω L hL hLΩ,
    observable_centerProjection Ω L hLΩ]
  apply ext_inner_left ℂ
  intro w
  have hleft : ⟪P w, Ω⟫_ℂ = 0 := by
    exact inner_eq_zero_symm.mpr (centerProjection_inner Ω w hΩ)
  have hb := hbalance (P w) (P v)
  rw [centerProjection_inner Ω v hΩ, hleft] at hb
  simp only [mul_zero, zero_mul, sub_zero, inner_sub_right, sub_eq_zero] at hb
  calc
    ⟪w, L (H (P v))⟫_ℂ = ⟪P w, L (H (P v))⟫_ℂ := by
      rw [hP.apply_clm, centerProjection_observable Ω L hL hLΩ]
    _ = ⟪P w, H (L (P v))⟫_ℂ := hb
    _ = ⟪w, P (H (L v))⟫_ℂ := by
      rw [hP.apply_clm, observable_centerProjection Ω L hLΩ]

end UAMO

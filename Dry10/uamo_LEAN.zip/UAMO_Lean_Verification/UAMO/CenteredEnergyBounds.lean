import UAMO.ResolventCalculus

noncomputable section
namespace UAMO
open scoped InnerProductSpace

section General
variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X]

theorem centered_resolvent_energy_identity (H : X →L[ℂ] X) (root : X) (E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ H)
    (hcenter : ⟪root, resolvent H (E : ℂ) root⟫_ℂ = 0) :
    E * ‖resolvent H (E : ℂ) root‖ ^ 2 =
      (⟪resolvent H (E : ℂ) root, H (resolvent H (E : ℂ) root)⟫_ℂ).re := by
  let q := resolvent H (E : ℂ) root
  have hqroot : ⟪q, root⟫_ℂ = 0 := inner_eq_zero_symm.mp hcenter
  have hid := congrArg (fun v : X => ⟪q, v⟫_ℂ)
    (cyclic_resolvent_left_identity H (E : ℂ) hE root)
  change ⟪q, (E : ℂ) • q - H q⟫_ℂ = ⟪q, root⟫_ℂ at hid
  rw [inner_sub_right, inner_smul_right, inner_self_eq_norm_sq_to_K, hqroot] at hid
  have hre := congrArg Complex.re (sub_eq_zero.mp hid)
  change ((E : ℂ) * (‖q‖ : ℂ) ^ 2).re = (⟪q, H q⟫_ℂ).re at hre
  rw [← Complex.ofReal_pow, ← Complex.ofReal_mul, Complex.ofReal_re] at hre
  exact hre

theorem centered_resolvent_energy_norm_bound (H : X →L[ℂ] X) (root : X)
    (hroot : root ≠ 0) (E : ℝ) (hE : (E : ℂ) ∈ resolventSet ℂ H)
    (hcenter : ⟪root, resolvent H (E : ℂ) root⟫_ℂ = 0) : |E| ≤ ‖H‖ := by
  let q := resolvent H (E : ℂ) root
  have hq : 0 < ‖q‖ := norm_pos_iff.mpr
    (actual_resolvent_column_ne_zero H root hroot (E : ℂ) hE)
  have hid := centered_resolvent_energy_identity H root E hE hcenter
  change E * ‖q‖ ^ 2 = (⟪q, H q⟫_ℂ).re at hid
  have hb : |E| * ‖q‖ ^ 2 ≤ ‖H‖ * ‖q‖ ^ 2 := by
    calc
      |E| * ‖q‖ ^ 2 = |(⟪q, H q⟫_ℂ).re| := by
        rw [← hid, abs_mul, abs_pow, abs_of_nonneg (norm_nonneg q)]
      _ ≤ ‖⟪q, H q⟫_ℂ‖ := Complex.abs_re_le_norm _
      _ ≤ ‖q‖ * ‖H q‖ := norm_inner_le_norm _ _
      _ ≤ ‖q‖ * (‖H‖ * ‖q‖) :=
        mul_le_mul_of_nonneg_left (H.le_opNorm q) (norm_nonneg _)
      _ = ‖H‖ * ‖q‖ ^ 2 := by ring
  exact (mul_le_mul_right (sq_pos_of_pos hq)).mp hb

end General

theorem magneticShift_opNorm_le_one (φ : ℝ) (ν : MagneticSite) :
    ‖magneticShift φ ν‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ (by norm_num)
  intro u
  simp [magneticShift_norm]

theorem magneticPair_opNorm_le (φ : ℝ) (ν : MagneticSite) (c : ℂ) :
    ‖magneticPair φ ν c‖ ≤ 2 * ‖c‖ := by
  unfold magneticPair
  calc
    ‖c • magneticShift φ ν + star c • magneticShift φ (-ν)‖ ≤
        ‖c • magneticShift φ ν‖ + ‖star c • magneticShift φ (-ν)‖ := norm_add_le _ _
    _ ≤ ‖c‖ * 1 + ‖c‖ * 1 := by
      rw [norm_smul c (magneticShift φ ν), norm_smul (star c) (magneticShift φ (-ν)),
        norm_star]
      exact add_le_add
        (mul_le_mul_of_nonneg_left (magneticShift_opNorm_le_one φ ν) (norm_nonneg c))
        (mul_le_mul_of_nonneg_left (magneticShift_opNorm_le_one φ (-ν)) (norm_nonneg c))
    _ = 2 * ‖c‖ := by ring

theorem diagonalHopping_norm_le (a φ : ℝ) :
    ‖diagonalHopping a φ‖ ≤ |a|⁻¹ + |a| := by
  calc
    ‖diagonalHopping a φ‖ ≤
        ‖(a : ℂ)⁻¹ * latticePhase φ 1‖ + ‖(a : ℂ) * latticePhase φ (-1)‖ :=
      norm_sub_le _ _
    _ = |a|⁻¹ + |a| := by simp [norm_mul, latticePhase_norm, Complex.norm_real,
      Real.norm_eq_abs]

theorem scalarHamiltonian_norm_le (a r φ : ℝ) :
    ‖scalarHamiltonian a r φ‖ ≤ 2 + 2 * |r| * ‖diagonalHopping a φ‖ + 2 * r ^ 2 := by
  rw [scalarHamiltonian_polynomial]
  calc
    ‖magneticPair φ (1, 0) 1 + r • magneticPair φ (1, 1) (diagonalHopping a φ) +
        r ^ 2 • magneticPair φ (1, 2) (-1)‖ ≤
        ‖magneticPair φ (1, 0) 1‖ + ‖r • magneticPair φ (1, 1) (diagonalHopping a φ)‖ +
          ‖r ^ 2 • magneticPair φ (1, 2) (-1)‖ := norm_add₃_le
    _ ≤ 2 + |r| * (2 * ‖diagonalHopping a φ‖) + r ^ 2 * 2 := by
      have h0 : ‖magneticPair φ (1, 0) 1‖ ≤ 2 := by
        simpa using magneticPair_opNorm_le φ (1, 0) 1
      have h2 : ‖magneticPair φ (1, 2) (-1)‖ ≤ 2 := by
        simpa using magneticPair_opNorm_le φ (1, 2) (-1)
      rw [norm_smul r (magneticPair φ (1, 1) (diagonalHopping a φ)),
        norm_smul (r ^ 2) (magneticPair φ (1, 2) (-1)), Real.norm_eq_abs,
        Real.norm_eq_abs, abs_of_nonneg (sq_nonneg r)]
      exact
        add_le_add (add_le_add h0 (mul_le_mul_of_nonneg_left
          (magneticPair_opNorm_le φ (1, 1) (diagonalHopping a φ)) (abs_nonneg r)))
          (mul_le_mul_of_nonneg_left h2 (sq_nonneg r))
    _ = 2 + 2 * |r| * ‖diagonalHopping a φ‖ + 2 * r ^ 2 := by ring

theorem scalarHamiltonian_norm_le_uniform (a r φ : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    ‖scalarHamiltonian a r φ‖ ≤ 4 + 2 * (|a|⁻¹ + |a|) := by
  have hd := diagonalHopping_norm_le a φ
  have hr2 : r ^ 2 ≤ 1 := by nlinarith
  have hrd : r * ‖diagonalHopping a φ‖ ≤ ‖diagonalHopping a φ‖ := by
    simpa using mul_le_mul_of_nonneg_right hr1 (norm_nonneg (diagonalHopping a φ))
  have hb := scalarHamiltonian_norm_le a r φ
  rw [abs_of_nonneg hr0] at hb
  nlinarith

theorem scalarGreen_zero_energy_bound (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hzero : scalarGreen a r φ E = 0) : |E| ≤ ‖scalarHamiltonian a r φ‖ := by
  apply centered_resolvent_energy_norm_bound _ magneticOrigin _ E hE
    ((scalarGreen_eq_zero_iff a r φ E).mp hzero)
  intro h
  have hn := magneticOrigin_norm
  rw [h, norm_zero] at hn
  norm_num at hn

theorem scalarGreen_zero_energy_uniform_bound (a r φ E : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hzero : scalarGreen a r φ E = 0) : |E| ≤ 4 + 2 * (|a|⁻¹ + |a|) :=
  (scalarGreen_zero_energy_bound a r φ E hE hzero).trans
    (scalarHamiltonian_norm_le_uniform a r φ hr0 hr1)

theorem scalarGreen_zero_energy_mem_Icc (a r φ E : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hzero : scalarGreen a r φ E = 0) :
    E ∈ Set.Icc (-(4 + 2 * (|a|⁻¹ + |a|))) (4 + 2 * (|a|⁻¹ + |a|)) :=
  abs_le.mp (scalarGreen_zero_energy_uniform_bound a r φ E hr0 hr1 hE hzero)

end UAMO

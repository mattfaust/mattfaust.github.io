import UAMO.CirclePotentialMean

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Polynomial

theorem polynomial_logFourierChar_ne_zero_ae (P : Polynomial ℂ) (hP : P ≠ 0) :
    ∀ᵐ t : ℝ ∂volume, P.eval (logFourierChar 1 t) ≠ 0 := by
  have hall := ae_all_iff.mpr (fun i : Fin (polynomialRootList P).length =>
    logFourierChar_root_ne_zero_ae ((polynomialRootList P).get i))
  filter_upwards [hall] with t ht
  rw [polynomial_eval_root_product]
  exact mul_ne_zero (Polynomial.leadingCoeff_ne_zero.mpr hP)
    (Finset.prod_ne_zero_iff.mpr (fun i _ => ht i))

def circleIntersectionPolynomial (c R : ℂ) : Polynomial ℂ :=
  C (R*star c)*X^2 + C ((Complex.normSq c : ℂ)+(Complex.normSq R : ℂ)-1)*X + C (c*star R)

theorem circleIntersectionPolynomial_ne_zero {c R : ℂ} (hc : c ≠ 0) (hR : R ≠ 0) :
    circleIntersectionPolynomial c R ≠ 0 := by
  have hcoeff : (circleIntersectionPolynomial c R).coeff 2 = R*star c := by
    simp only [circleIntersectionPolynomial, Polynomial.coeff_add,
      Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C_mul_X, Polynomial.coeff_C]
    norm_num
  intro h
  rw [h, Polynomial.coeff_zero] at hcoeff
  exact mul_ne_zero hR (star_ne_zero.mpr hc) hcoeff.symm

theorem circleIntersectionPolynomial_eval_zero (c R e : ℂ)
    (he : ‖e‖ = 1) (hz : ‖c+R*e‖ = 1) :
    (circleIntersectionPolynomial c R).eval e = 0 := by
  have he' : e*star e = 1 := by
    rw [Complex.star_def, Complex.mul_conj, Complex.normSq_eq_norm_sq, he]
    norm_num
  have hz' : (c+R*e)*star (c+R*e) = 1 := by
    rw [Complex.star_def, Complex.mul_conj, Complex.normSq_eq_norm_sq, hz]
    norm_num
  have hc : (Complex.normSq c : ℂ) = c*star c := (Complex.mul_conj c).symm
  have hR : (Complex.normSq R : ℂ) = R*star R := (Complex.mul_conj R).symm
  simp only [circleIntersectionPolynomial, Polynomial.eval_add, Polynomial.eval_mul,
    Polynomial.eval_C, Polynomial.eval_pow, Polynomial.eval_X, hc, hR]
  simp only [star_add, star_mul] at hz'
  linear_combination e * hz' - (c*star R+R*star R*e)*he'

theorem circle_affine_off_circle_ae {c R : ℂ} (hc : c ≠ 0) (hR : R ≠ 0) :
    ∀ᵐ t : ℝ ∂volume, ‖c+R*logFourierChar 1 t‖ ≠ 1 := by
  filter_upwards [polynomial_logFourierChar_ne_zero_ae
    (circleIntersectionPolynomial c R) (circleIntersectionPolynomial_ne_zero hc hR)] with t ht
  intro he
  exact ht (circleIntersectionPolynomial_eval_zero c R _ (logFourierChar_norm 1 t) he)

theorem circle_affine_off_circle_ae_angular {c R : ℂ} (hc : c ≠ 0) (hR : R ≠ 0) :
    ∀ᵐ t ∂angularParameterMeasure, ‖c+R*logFourierChar 1 t‖ ≠ 1 :=
  ae_restrict_of_ae (circle_affine_off_circle_ae hc hR)

end UAMO.CircleDOS

import UAMO.CircleNoAtomsProjection

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set
open scoped ENNReal

def upperArc (x : ℝ) : Set ℂ := {z | 0 < z.im ∧ x ≤ z.re}

def lowerArc (x : ℝ) : Set ℂ := {z | 0 < z.im ∨ (z.im < 0 ∧ z.re < x)}

theorem measurableSet_upperArc (x : ℝ) : MeasurableSet (upperArc x) :=
  (isOpen_lt continuous_const Complex.continuous_im).measurableSet.inter
    (isClosed_le continuous_const Complex.continuous_re).measurableSet

theorem measurableSet_lowerArc (x : ℝ) : MeasurableSet (lowerArc x) :=
  (isOpen_lt continuous_const Complex.continuous_im).measurableSet.union
    ((isOpen_lt Complex.continuous_im continuous_const).measurableSet.inter
      (isOpen_lt Complex.continuous_re continuous_const).measurableSet)

theorem realPart_ae_Ioo (ν : Measure ℂ) [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) :
    ∀ᵐ x ∂ν.map Complex.re, x ∈ Ioo (-1 : ℝ) 1 := by
  letI := noAtoms_realPart ν hc
  have hcc : ∀ᵐ x ∂ν.map Complex.re, x ∈ Icc (-1 : ℝ) 1 := by
    apply (ae_map_iff Complex.continuous_re.measurable.aemeasurable measurableSet_Icc).mpr
    filter_upwards [hc] with z hz
    exact abs_le.mp ((Complex.abs_re_le_norm z).trans_eq hz)
  filter_upwards [hcc, (countable_singleton (-1 : ℝ)).ae_not_mem (ν.map Complex.re),
    (countable_singleton (1 : ℝ)).ae_not_mem (ν.map Complex.re)] with x hx hm hp
  exact ⟨lt_of_le_of_ne hx.1 (Ne.symm hm), lt_of_le_of_ne hx.2 hp⟩

theorem sqrt_circle_height_pos {y : ℝ} (hy : y ∈ Ioo (-1 : ℝ) 1) :
    0 < Real.sqrt (1-y^2) := Real.sqrt_pos.mpr (by nlinarith [hy.1, hy.2])

private theorem half_measure_ne_top (μ : Measure ℂ) [IsFiniteMeasure μ] (s : Set ℂ) :
    ((1/2 : ℝ≥0∞) • μ) s ≠ ⊤ := by
  rw [Measure.smul_apply, smul_eq_mul]
  exact ENNReal.mul_ne_top (by norm_num) (measure_ne_top μ s)

theorem circle_upperArc_mass (ν : Measure ℂ) [IsProbabilityMeasure ν] [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) (hconj : ν.map star = ν) (x : ℝ) :
    ν.real (upperArc x) = (1-(ν.map Complex.re).real (Iio x))/2 := by
  let ρ := ν.map Complex.re
  letI : IsProbabilityMeasure ρ := isProbabilityMeasure_map Complex.continuous_re.measurable.aemeasurable
  letI : IsProbabilityMeasure (ρ.map upperLift) := isProbabilityMeasure_map continuous_upperLift.measurable.aemeasurable
  letI : IsProbabilityMeasure (ρ.map lowerLift) := isProbabilityMeasure_map continuous_lowerLift.measurable.aemeasurable
  have hu : upperLift ⁻¹' upperArc x =ᵐ[ρ] Ici x := by
    filter_upwards [realPart_ae_Ioo ν hc] with y hy
    have hs := sqrt_circle_height_pos hy
    apply propext
    change (0 < Real.sqrt (1-y^2) ∧ x ≤ y) ↔ x ≤ y
    simp only [hs, true_and]
  have hl : lowerLift ⁻¹' upperArc x =ᵐ[ρ] (∅ : Set ℝ) := by
    filter_upwards [realPart_ae_Ioo ν hc] with y hy
    have hs := sqrt_circle_height_pos hy
    apply propext
    change (0 < -Real.sqrt (1-y^2) ∧ x ≤ y) ↔ False
    rw [iff_false]
    exact fun h => (not_lt_of_ge (neg_nonpos.mpr hs.le)) h.1
  have hp : ρ.real (Ici x) = 1-ρ.real (Iio x) := by
    rw [← compl_Iio, measureReal_compl measurableSet_Iio]
    simp only [measureReal_def, measure_univ, ENNReal.toReal_one]
  have he := congrArg (fun μ : Measure ℂ => μ.real (upperArc x))
    (circle_measure_reconstruction ν hc hconj)
  dsimp only at he
  rw [measureReal_add_apply (half_measure_ne_top (ρ.map upperLift) _)
    (half_measure_ne_top (ρ.map lowerLift) _),
    measureReal_ennreal_smul_apply, measureReal_ennreal_smul_apply,
    map_measureReal_apply continuous_upperLift.measurable (measurableSet_upperArc x),
    map_measureReal_apply continuous_lowerLift.measurable (measurableSet_upperArc x)] at he
  change ν.real (upperArc x) = (1/2 : ℝ≥0∞).toReal * ρ.real (upperLift ⁻¹' upperArc x) +
    (1/2 : ℝ≥0∞).toReal * ρ.real (lowerLift ⁻¹' upperArc x) at he
  rw [measureReal_congr hu, measureReal_congr hl, measureReal_empty, mul_zero, add_zero, hp] at he
  norm_num at he
  linarith

theorem circle_lowerArc_mass (ν : Measure ℂ) [IsProbabilityMeasure ν] [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) (hconj : ν.map star = ν) (x : ℝ) :
    ν.real (lowerArc x) = (1+(ν.map Complex.re).real (Iio x))/2 := by
  let ρ := ν.map Complex.re
  letI : IsProbabilityMeasure ρ := isProbabilityMeasure_map Complex.continuous_re.measurable.aemeasurable
  letI : IsProbabilityMeasure (ρ.map upperLift) := isProbabilityMeasure_map continuous_upperLift.measurable.aemeasurable
  letI : IsProbabilityMeasure (ρ.map lowerLift) := isProbabilityMeasure_map continuous_lowerLift.measurable.aemeasurable
  have hu : upperLift ⁻¹' lowerArc x =ᵐ[ρ] (univ : Set ℝ) := by
    filter_upwards [realPart_ae_Ioo ν hc] with y hy
    have hs := sqrt_circle_height_pos hy
    apply propext
    change (0 < Real.sqrt (1-y^2) ∨ Real.sqrt (1-y^2) < 0 ∧ y < x) ↔ True
    rw [iff_true]
    exact Or.inl hs
  have hl : lowerLift ⁻¹' lowerArc x =ᵐ[ρ] Iio x := by
    filter_upwards [realPart_ae_Ioo ν hc] with y hy
    have hs := sqrt_circle_height_pos hy
    apply propext
    change (0 < -Real.sqrt (1-y^2) ∨ -Real.sqrt (1-y^2) < 0 ∧ y < x) ↔ y < x
    simp only [not_lt_of_ge (neg_nonpos.mpr hs.le), false_or, neg_lt_zero.mpr hs, true_and]
  have he := congrArg (fun μ : Measure ℂ => μ.real (lowerArc x))
    (circle_measure_reconstruction ν hc hconj)
  dsimp only at he
  rw [measureReal_add_apply (half_measure_ne_top (ρ.map upperLift) _)
    (half_measure_ne_top (ρ.map lowerLift) _),
    measureReal_ennreal_smul_apply, measureReal_ennreal_smul_apply,
    map_measureReal_apply continuous_upperLift.measurable (measurableSet_lowerArc x),
    map_measureReal_apply continuous_lowerLift.measurable (measurableSet_lowerArc x)] at he
  change ν.real (lowerArc x) = (1/2 : ℝ≥0∞).toReal * ρ.real (upperLift ⁻¹' lowerArc x) +
    (1/2 : ℝ≥0∞).toReal * ρ.real (lowerLift ⁻¹' lowerArc x) at he
  rw [measureReal_congr hu, measureReal_congr hl] at he
  have hone : ρ.real univ = 1 := by simp [measureReal_def, ρ]
  rw [hone] at he
  norm_num at he
  linarith

end UAMO.CircleDOS

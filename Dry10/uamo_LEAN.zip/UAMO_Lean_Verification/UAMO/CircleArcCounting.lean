import UAMO.CircleArcParameterization

noncomputable section
namespace UAMO.CircleDOS
open Set
attribute [local instance] Classical.propDecidable

theorem injective_fiber_card_le_one {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → ℝ) (hp : Function.Injective p) (t : ℝ) :
    (Finset.univ.filter (fun i => p i=t)).card≤1 := by
  classical
  refine Finset.card_le_one.mpr ?_
  intro i hi j hj
  exact hp ((Finset.mem_filter.mp hi).2.trans (Finset.mem_filter.mp hj).2.symm)

theorem directedArc_filter_eq_initial_upper {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → ℝ) (hp : ∀i, p i∈Ico 0 (2*Real.pi)) (hp0 : ∀i, p i≠0)
    {t : ℝ} (ht0 : 0<t) (htπ : t<Real.pi) :
    Finset.univ.filter (fun i => anglePoint (p i)∈directedArc (anglePoint t)) =
      Finset.univ.filter (fun i => p i≤t) := by
  classical
  ext i
  simp only [Finset.mem_filter,Finset.mem_univ,true_and,
    anglePoint_mem_directedArc_upper (hp i) ht0 htπ]
  exact and_iff_right (lt_of_le_of_ne (hp i).1 (hp0 i).symm)

theorem directedArc_filter_card_lower {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → ℝ) (hinj : Function.Injective p)
    (hp : ∀i, p i∈Ico 0 (2*Real.pi)) (hp0 : ∀i, p i≠0)
    {t : ℝ} (htπ : Real.pi≤t) (ht2π : t<2*Real.pi) :
    let a := Finset.univ.filter (fun i => anglePoint (p i)∈directedArc (anglePoint t))
    let b := Finset.univ.filter (fun i => p i≤t)
    a.card≤b.card ∧ b.card≤a.card+2 := by
  classical
  intro a b
  let eπ := Finset.univ.filter (fun i => p i=Real.pi)
  let et := Finset.univ.filter (fun i => p i=t)
  have hab : a⊆b := by
    intro i hi
    have ha := (anglePoint_mem_directedArc_lower (hp i) htπ ht2π).mp
      (Finset.mem_filter.mp hi).2
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha.2.1.le⟩
  have hba : b⊆a∪eπ∪et := by
    intro i hi
    have hit := (Finset.mem_filter.mp hi).2
    by_cases hiπ : p i=Real.pi
    · exact Finset.mem_union_left _ (Finset.mem_union_right _
        (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hiπ⟩))
    by_cases hie : p i=t
    · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hie⟩)
    · apply Finset.mem_union_left _
      apply Finset.mem_union_left _
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_univ _,(anglePoint_mem_directedArc_lower (hp i) htπ ht2π).mpr ?_⟩
      exact ⟨lt_of_le_of_ne (hp i).1 (hp0 i).symm,lt_of_le_of_ne hit hie,hiπ⟩
  have hπ : eπ.card≤1 := injective_fiber_card_le_one p hinj Real.pi
  have ht : et.card≤1 := injective_fiber_card_le_one p hinj t
  refine ⟨Finset.card_le_card hab,?_⟩
  have h1 := Finset.card_le_card hba
  have h2 := Finset.card_union_le (a∪eπ) et
  have h3 := Finset.card_union_le a eπ
  omega

theorem directedArc_count_discrepancy {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → ℝ) (hinj : Function.Injective p)
    (hp : ∀i, p i∈Ico 0 (2*Real.pi)) (hp0 : ∀i, p i≠0)
    {t : ℝ} (ht0 : 0<t) (ht2π : t<2*Real.pi) :
    |((Finset.univ.filter (fun i => anglePoint (p i)∈directedArc (anglePoint t))).card:ℝ)-
      ((Finset.univ.filter (fun i => p i≤t)).card:ℝ)|≤2 := by
  classical
  by_cases htπ : t<Real.pi
  · rw [directedArc_filter_eq_initial_upper p hp hp0 ht0 htπ,sub_self,abs_zero]
    norm_num
  · obtain ⟨hab,hba⟩ := directedArc_filter_card_lower p hinj hp hp0
      (le_of_not_gt htπ) ht2π
    have hab' : ((Finset.univ.filter (fun i => anglePoint (p i)∈directedArc (anglePoint t))).card:ℝ)≤
        ((Finset.univ.filter (fun i => p i≤t)).card:ℝ) := by exact_mod_cast hab
    have hba' : ((Finset.univ.filter (fun i => p i≤t)).card:ℝ)≤
        ((Finset.univ.filter (fun i => anglePoint (p i)∈directedArc (anglePoint t))).card:ℝ)+2 := by
      exact_mod_cast hba
    rw [abs_of_nonpos (sub_nonpos.mpr hab')]
    linarith

end UAMO.CircleDOS

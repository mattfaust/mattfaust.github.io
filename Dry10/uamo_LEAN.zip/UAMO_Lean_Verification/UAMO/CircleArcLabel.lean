import UAMO.PhysicalDOSLabels
import UAMO.UnitCircleScalarCorrespondence

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set

def directedArc (z : ℂ) : Set ℂ :=
  if 0 < z.im then upperArc z.re else lowerArc z.re

def arcLabel (ν : Measure ℂ) (z : ℂ) : ℝ := ν.real (directedArc z)

theorem measurableSet_directedArc (z : ℂ) : MeasurableSet (directedArc z) := by
  unfold directedArc
  split <;> first | exact measurableSet_upperArc _ | exact measurableSet_lowerArc _

theorem arcLabel_of_im_pos (ν : Measure ℂ) {z : ℂ} (hz : 0 < z.im) :
    arcLabel ν z = ν.real (upperArc z.re) := by simp [arcLabel, directedArc, hz]

theorem arcLabel_of_im_neg (ν : Measure ℂ) {z : ℂ} (hz : z.im < 0) :
    arcLabel ν z = ν.real (lowerArc z.re) := by
  simp [arcLabel, directedArc, not_lt_of_ge hz.le]

theorem arcLabel_of_im_nonpos (ν : Measure ℂ) {z : ℂ} (hz : z.im ≤ 0) :
    arcLabel ν z = ν.real (lowerArc z.re) := by
  simp [arcLabel, directedArc, not_lt_of_ge hz]

theorem arcLabel_conj (ν : Measure ℂ) [IsProbabilityMeasure ν] [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) (hconj : ν.map star = ν)
    {z : ℂ} (hz : z.im ≠ 0) :
    arcLabel ν (star z) = 1 - arcLabel ν z := by
  have hre : (star z).re = z.re := rfl
  have him : (star z).im = -z.im := rfl
  rcases lt_or_gt_of_ne hz with hneg | hpos
  · rw [arcLabel_of_im_pos ν (by rw [him]; linarith), arcLabel_of_im_neg ν hneg,
      hre, circle_upperArc_mass ν hc hconj, circle_lowerArc_mass ν hc hconj]
    ring
  · rw [arcLabel_of_im_neg ν (by rw [him]; linarith), arcLabel_of_im_pos ν hpos,
      hre, circle_upperArc_mass ν hc hconj, circle_lowerArc_mass ν hc hconj]
    ring

end UAMO.CircleDOS

namespace UAMO
open MeasureTheory CircleDOS PhysicalDOS CMV

theorem physical_arcLabel_upper {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) {z : ℂ} (hz : 0 < z.im) :
    arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z =
      (1 - scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r z))/2 := by
  rw [arcLabel_of_im_pos _ hz, scalarEnergyOfCircle_normalization ha.ne' r z]
  exact physicalUnitaryDOS_upper_label ha ha1 hr hr1 Φ _

theorem physical_arcLabel_lower {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) {z : ℂ} (hz : z.im < 0) :
    arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z =
      (1 + scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r z))/2 := by
  rw [arcLabel_of_im_neg _ hz, scalarEnergyOfCircle_normalization ha.ne' r z]
  exact physicalUnitaryDOS_lower_label ha ha1 hr hr1 Φ _

theorem physical_arcLabel_conj {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) {z : ℂ} (hz : z.im ≠ 0) :
    arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) (star z) =
      1 - arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z := by
  letI := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 Φ
  exact arcLabel_conj _ (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1)
    (physicalUnitaryDOS_conj_invariant a r Φ ha.le ha1 hr hr1) hz

theorem physical_arcLabel_lower_nonpos {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) {z : ℂ} (hz : z.im ≤ 0) :
    arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z =
      (1 + scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r z))/2 := by
  rw [arcLabel_of_im_nonpos _ hz, scalarEnergyOfCircle_normalization ha.ne' r z]
  exact physicalUnitaryDOS_lower_label ha ha1 hr hr1 Φ _

end UAMO

import UAMO.CircleArcLabel
import Mathlib.Analysis.SpecialFunctions.Complex.Circle

noncomputable section
namespace UAMO.CircleDOS
open Set

def anglePoint (t : ℝ) : ℂ := Complex.exp ((t:ℂ)*Complex.I)

@[simp] theorem anglePoint_re (t : ℝ) : (anglePoint t).re=Real.cos t := by
  simp [anglePoint,Complex.exp_mul_I,← Complex.ofReal_cos,← Complex.ofReal_sin]

@[simp] theorem anglePoint_im (t : ℝ) : (anglePoint t).im=Real.sin t := by
  simp [anglePoint,Complex.exp_mul_I,← Complex.ofReal_cos,← Complex.ofReal_sin]

theorem sin_nonpos_second_turn {s : ℝ} (hsπ : Real.pi≤s) (hs2π : s≤2*Real.pi) :
    Real.sin s≤0 := by
  have h := Real.sin_nonneg_of_nonneg_of_le_pi (sub_nonneg.mpr hsπ)
    (by linarith : s-Real.pi≤Real.pi)
  have he : s=(s-Real.pi)+Real.pi := by ring
  rw [he,Real.sin_add_pi]
  linarith

theorem sin_pos_iff_mem_first_half {s : ℝ} (hs : s∈Ico 0 (2*Real.pi)) :
    0<Real.sin s ↔ 0<s ∧ s<Real.pi := by
  constructor
  · intro h
    have hs0 : 0<s := by
      by_contra hn
      have he : s=0 := le_antisymm (le_of_not_gt hn) hs.1
      simp [he] at h
    refine ⟨hs0,?_⟩
    by_cases hp : s<Real.pi
    · exact hp
    · exact False.elim ((not_lt_of_ge (sin_nonpos_second_turn (le_of_not_gt hp) hs.2.le)) h)
  · rintro ⟨hs0,hsπ⟩
    exact Real.sin_pos_of_pos_of_lt_pi hs0 hsπ

theorem sin_neg_iff_mem_second_half {s : ℝ} (hs : s∈Ico 0 (2*Real.pi)) :
    Real.sin s<0 ↔ Real.pi<s := by
  constructor
  · intro h
    by_contra hn
    exact (not_lt_of_ge (Real.sin_nonneg_of_nonneg_of_le_pi hs.1 (le_of_not_gt hn))) h
  · intro hsπ
    have h := Real.sin_pos_of_pos_of_lt_pi (sub_pos.mpr hsπ)
      (by linarith [hs.2] : s-Real.pi<Real.pi)
    have he : s=(s-Real.pi)+Real.pi := by ring
    rw [he,Real.sin_add_pi]
    linarith

theorem cos_lt_cos_second_half_iff {s t : ℝ}
    (hs : s∈Icc Real.pi (2*Real.pi)) (ht : t∈Icc Real.pi (2*Real.pi)) :
    Real.cos s<Real.cos t ↔ s<t := by
  have hs' : 2*Real.pi-s∈Icc 0 Real.pi := ⟨by linarith [hs.2],by linarith [hs.1]⟩
  have ht' : 2*Real.pi-t∈Icc 0 Real.pi := ⟨by linarith [ht.2],by linarith [ht.1]⟩
  have h := Real.strictAntiOn_cos.lt_iff_lt hs' ht'
  rw [Real.cos_two_pi_sub,Real.cos_two_pi_sub] at h
  exact h.trans (by constructor <;> intro h <;> linarith)

theorem anglePoint_mem_directedArc_upper {s t : ℝ} (hs : s∈Ico 0 (2*Real.pi))
    (ht0 : 0<t) (htπ : t<Real.pi) :
    anglePoint s∈directedArc (anglePoint t) ↔ 0<s ∧ s≤t := by
  rw [directedArc,anglePoint_im,if_pos (Real.sin_pos_of_pos_of_lt_pi ht0 htπ)]
  simp only [upperArc,Set.mem_setOf_eq,anglePoint_im,anglePoint_re]
  rw [sin_pos_iff_mem_first_half hs]
  constructor
  · rintro ⟨⟨hs0,hsπ⟩,hc⟩
    exact ⟨hs0,(Real.strictAntiOn_cos.le_iff_le ⟨ht0.le,htπ.le⟩ ⟨hs0.le,hsπ.le⟩).mp hc⟩
  · rintro ⟨hs0,hst⟩
    exact ⟨⟨hs0,hst.trans_lt htπ⟩,
      Real.cos_le_cos_of_nonneg_of_le_pi hs0.le htπ.le hst⟩

theorem anglePoint_mem_directedArc_lower {s t : ℝ} (hs : s∈Ico 0 (2*Real.pi))
    (htπ : Real.pi≤t) (ht2π : t<2*Real.pi) :
    anglePoint s∈directedArc (anglePoint t) ↔ 0<s ∧ s<t ∧ s≠Real.pi := by
  rw [directedArc,anglePoint_im,if_neg (not_lt_of_ge (sin_nonpos_second_turn htπ ht2π.le))]
  simp only [lowerArc,Set.mem_setOf_eq,anglePoint_im,anglePoint_re]
  rw [sin_pos_iff_mem_first_half hs,sin_neg_iff_mem_second_half hs]
  constructor
  · rintro (⟨hs0,hsπ⟩ | ⟨hsπ,hcos⟩)
    · exact ⟨hs0,hsπ.trans_le htπ,ne_of_lt hsπ⟩
    · exact ⟨Real.pi_pos.trans hsπ,
        (cos_lt_cos_second_half_iff ⟨hsπ.le,hs.2.le⟩ ⟨htπ,ht2π.le⟩).mp hcos,
        ne_of_gt hsπ⟩
  · rintro ⟨hs0,hst,hsne⟩
    by_cases hsπ : s<Real.pi
    · exact Or.inl ⟨hs0,hsπ⟩
    · have hsπ' : Real.pi<s := lt_of_le_of_ne (le_of_not_gt hsπ) hsne.symm
      exact Or.inr ⟨hsπ',(cos_lt_cos_second_half_iff ⟨hsπ'.le,hs.2.le⟩ ⟨htπ,ht2π.le⟩).mpr hst⟩

theorem anglePoint_injOn_turn : Set.InjOn anglePoint (Ico 0 (2*Real.pi)) := by
  intro s hs t ht he
  have hc : Circle.exp s=Circle.exp t := Subtype.ext he
  obtain ⟨m,hm⟩ := Circle.exp_eq_exp.mp hc
  have hmlo : (-1:ℝ)<(m:ℝ) := by
    by_contra h
    have hmul := mul_le_mul_of_nonneg_right (le_of_not_gt h) (by positivity : 0≤2*Real.pi)
    linarith [hs.1,ht.2]
  have hmhi : (m:ℝ)<1 := by
    by_contra h
    have hmul := mul_le_mul_of_nonneg_right (le_of_not_gt h) (by positivity : 0≤2*Real.pi)
    linarith [ht.1,hs.2]
  have hmi : (-1:ℤ)<m := by exact_mod_cast hmlo
  have hma : m<(1:ℤ) := by exact_mod_cast hmhi
  have hm0 : m=0 := by omega
  simpa [hm0] using hm

end UAMO.CircleDOS

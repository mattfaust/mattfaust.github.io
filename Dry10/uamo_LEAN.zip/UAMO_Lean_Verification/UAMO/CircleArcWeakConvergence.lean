import UAMO.CircleArcLabel
import UAMO.CircleNoAtomsProjection
import UAMO.CircleMomentConvergence
import Mathlib.MeasureTheory.Measure.Portmanteau

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set Filter
open scoped Topology

theorem circle_measure_im_zero (ν : Measure ℂ) [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν,‖z‖=1) : ν {z:ℂ | z.im=0}=0 := by
  have h : ν {z:ℂ | z.im=0}≤ν {(1:ℂ),-1} := by
    apply measure_mono_ae
    filter_upwards [hc] with z hz
    intro hi
    have hs := Complex.sq_norm z
    rw [hz] at hs
    simp only [one_pow,Complex.normSq_apply] at hs
    change z.im=0 at hi
    by_cases hp : 0≤z.re
    · left
      apply Complex.ext
      · change z.re=1
        nlinarith
      · exact hi
    · right
      apply Complex.ext
      · change z.re= -1
        nlinarith
      · simpa using hi
  exact le_zero_iff.mp (((Set.toFinite {(1:ℂ),-1}).measure_zero ν) ▸ h)

theorem circle_measure_re_eq (ν : Measure ℂ) [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν,‖z‖=1) (x : ℝ) : ν {z:ℂ | z.re=x}=0 := by
  letI := noAtoms_realPart ν hc
  have h := measure_singleton (μ:=ν.map Complex.re) x
  rw [Measure.map_apply Complex.continuous_re.measurable (measurableSet_singleton x)] at h
  exact h

theorem frontier_upperArc_subset (x : ℝ) :
    frontier (upperArc x)⊆{z:ℂ | z.im=0}∪{z:ℂ | z.re=x} := by
  intro z hz
  rcases frontier_inter_subset {w:ℂ | 0<w.im} {w:ℂ | x≤w.re} hz with h | h
  · exact Or.inl ((frontier_lt_subset_eq continuous_const Complex.continuous_im h.1).symm)
  · exact Or.inr ((frontier_le_subset_eq continuous_const Complex.continuous_re h.2).symm)

theorem frontier_lowerArc_subset (x : ℝ) :
    frontier (lowerArc x)⊆{z:ℂ | z.im=0}∪{z:ℂ | z.re=x} := by
  intro z hz
  rcases frontier_union_subset {w:ℂ | 0<w.im}
      ({w:ℂ | w.im<0}∩{w:ℂ | w.re<x}) hz with h | h
  · exact Or.inl ((frontier_lt_subset_eq continuous_const Complex.continuous_im h.1).symm)
  · rcases frontier_inter_subset {w:ℂ | w.im<0} {w:ℂ | w.re<x} h.2 with h | h
    · exact Or.inl (frontier_lt_subset_eq Complex.continuous_im continuous_const h.1)
    · exact Or.inr (frontier_lt_subset_eq Complex.continuous_re continuous_const h.2)

theorem circle_directedArc_frontier_null (ν : Measure ℂ) [NoAtoms ν]
    (hc : ∀ᵐ w ∂ν,‖w‖=1) (z : ℂ) : ν (frontier (directedArc z))=0 := by
  have hz := measure_union_null (circle_measure_im_zero ν hc) (circle_measure_re_eq ν hc z.re)
  apply measure_mono_null _ hz
  unfold directedArc
  split
  · exact frontier_upperArc_subset z.re
  · exact frontier_lowerArc_subset z.re

theorem arcLabel_tendsto_of_weak {ι : Type*} {L : Filter ι}
    (νs : ι→ProbabilityMeasure ℂ) (ν : ProbabilityMeasure ℂ)
    [NoAtoms (ν:Measure ℂ)] (hc : ∀ᵐ w ∂(ν:Measure ℂ),‖w‖=1)
    (hweak : Tendsto νs L (𝓝 ν)) (z : ℂ) :
    Tendsto (fun i => arcLabel (νs i:Measure ℂ) z) L (𝓝 (arcLabel (ν:Measure ℂ) z)) := by
  have h := ProbabilityMeasure.tendsto_measure_of_null_frontier_of_tendsto' hweak
    (circle_directedArc_frontier_null (ν:Measure ℂ) hc z)
  exact (ENNReal.tendsto_toReal (measure_ne_top _ _)).comp h

theorem circleProbability_weak_tendsto_of_moments
    (νs : ℕ→ProbabilityMeasure ℂ) (ν : ProbabilityMeasure ℂ)
    (hνs : ∀n,∀ᵐ z ∂(νs n:Measure ℂ),‖z‖=1)
    (hν : ∀ᵐ z ∂(ν:Measure ℂ),‖z‖=1)
    (hm : ∀k:ℕ,Tendsto (fun n => ∫z:ℂ,z^k ∂(νs n:Measure ℂ)) atTop
      (𝓝 (∫z:ℂ,z^k ∂(ν:Measure ℂ)))) : Tendsto νs atTop (𝓝 ν) := by
  apply (ProbabilityMeasure.tendsto_iff_forall_integral_rclike_tendsto ℂ).mpr
  intro f
  exact circleProbability_integral_tendsto_of_moments (fun n => (νs n:Measure ℂ))
    (ν:Measure ℂ) hνs hν hm f (f.continuous.comp continuous_subtype_val)

end UAMO.CircleDOS

namespace UAMO
open MeasureTheory CircleDOS PhysicalDOS CMV Filter
open scoped Topology

theorem physical_arcLabel_tendsto_of_weak {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (α : ℝ) (νs : ℕ→ProbabilityMeasure ℂ)
    (hweak : Tendsto νs atTop
      (𝓝 (⟨physicalUnitaryDOS a r α ha.le ha1 hr hr1,inferInstance⟩:ProbabilityMeasure ℂ)))
    (z : ℂ) :
    Tendsto (fun n => arcLabel (νs n:Measure ℂ) z) atTop
      (𝓝 (arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1) z)) := by
  let ν : ProbabilityMeasure ℂ :=
    ⟨physicalUnitaryDOS a r α ha.le ha1 hr hr1,inferInstance⟩
  letI : NoAtoms (ν:Measure ℂ) := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 α
  exact arcLabel_tendsto_of_weak νs ν
    (physicalUnitaryDOS_ae_circle a r α ha.le ha1 hr hr1) hweak z

end UAMO

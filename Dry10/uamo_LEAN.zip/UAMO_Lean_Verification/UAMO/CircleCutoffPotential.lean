import UAMO.CircleLogOffCircle

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology

def circleCutoffPotential (ν : Measure ℂ) (z : ℂ) (δ : ℝ) : ℝ :=
  ∫ w, Real.log (max δ ‖z-w‖) ∂ν

theorem circleCutoffLog_continuous (z : ℂ) {δ : ℝ} (hδ : 0 < δ) :
    Continuous (fun w : ℂ => Real.log (max δ ‖z-w‖)) :=
  (continuous_const.max (continuous_const.sub continuous_id).norm).log
    (fun w => (hδ.trans_le (le_max_left δ ‖z-w‖)).ne')

theorem circleCutoffLog_integrable (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) {δ : ℝ} (hδ : 0 < δ) :
    Integrable (fun w => Real.log (max δ ‖z-w‖)) ν :=
  integrable_continuous_of_ae_circle ν hc _ (circleCutoffLog_continuous z hδ)

theorem circleCutoffPotential_bounds (ν : Measure ℂ) [IsProbabilityMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) {δ : ℝ} (hδ : 0 < δ) :
    circleRegularizedPotential ν z (δ^2) - Real.log (1+δ) ≤ circleCutoffPotential ν z δ ∧
      circleCutoffPotential ν z δ ≤ circleRegularizedPotential ν z δ := by
  have hcint := circleCutoffLog_integrable ν hc z hδ
  have hl : circleRegularizedPotential ν z (δ^2) ≤
      Real.log (1+δ) + circleCutoffPotential ν z δ := by
    have h := integral_mono (regularized_circle_integrable ν hc z (sq_pos_of_pos hδ))
      ((integrable_const (Real.log (1+δ))).add hcint) (fun w => ?_)
    · dsimp only [Pi.add_apply] at h
      simpa only [integral_add (integrable_const _) hcint, integral_const, measureReal_def,
        measure_univ, ENNReal.toReal_one, one_smul, circleRegularizedPotential,
        circleCutoffPotential] using h
    · change Real.log (‖z-w‖+δ^2) ≤ Real.log (1+δ)+Real.log (max δ ‖z-w‖)
      rw [← Real.log_mul (by positivity : 1+δ ≠ 0)
        ((hδ.trans_le (le_max_left δ ‖z-w‖)).ne')]
      apply Real.log_le_log (by positivity)
      have h1 := le_max_right δ ‖z-w‖
      have h2 := mul_le_mul_of_nonneg_left (le_max_left δ ‖z-w‖) hδ.le
      nlinarith
  refine ⟨by linarith, ?_⟩
  apply integral_mono hcint (regularized_circle_integrable ν hc z hδ)
  intro w
  apply Real.log_le_log (hδ.trans_le (le_max_left δ ‖z-w‖))
  exact max_le (le_add_of_nonneg_left (norm_nonneg _)) (le_add_of_nonneg_right hδ.le)

theorem circleCutoffPotential_tendsto (ν : Measure ℂ) [IsProbabilityMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ)
    (δ : ℕ → ℝ) (hδ : ∀ n, 0 < δ n) (hlim : Tendsto δ atTop (𝓝 0)) :
    Tendsto (fun n => (circleCutoffPotential ν z (δ n) : EReal)) atTop
      (𝓝 (circleTotalPotential ν z)) := by
  have hF := circleRegularizedPotential_monotone ν hc z
  have hU := tendsto_regularization_inf _ hF δ hδ hlim
  have hL := tendsto_regularization_inf _ hF (fun n => δ n^2)
    (fun n => sq_pos_of_pos (hδ n)) (by simpa using hlim.pow 2)
  have he : Tendsto (fun n => -Real.log (1+δ n)) atTop (𝓝 0) := by
    simpa only [add_zero, Real.log_one, neg_zero] using
      ((Real.continuousAt_log (by norm_num : (1 : ℝ) ≠ 0)).tendsto.comp
        (by simpa using hlim.const_add 1)).neg
  have he' := continuous_coe_real_ereal.continuousAt.tendsto.comp he
  have hadd := (EReal.continuousAt_add (p := (((0 : ℝ) : EReal), circleTotalPotential ν z))
    (Or.inl (EReal.coe_ne_top 0)) (Or.inl (EReal.coe_ne_bot 0))).tendsto.comp
      (he'.prodMk_nhds hL)
  have hlo : Tendsto (fun n =>
      ((circleRegularizedPotential ν z (δ n^2)-Real.log (1+δ n) : ℝ) : EReal)) atTop
        (𝓝 (circleTotalPotential ν z)) := by
    simpa only [Function.comp_def, ← EReal.coe_add, EReal.coe_zero, zero_add,
      neg_add_eq_sub] using hadd
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le hlo hU
  · intro n
    exact EReal.coe_le_coe_iff.mpr (circleCutoffPotential_bounds ν hc z (hδ n)).1
  · intro n
    exact EReal.coe_le_coe_iff.mpr (circleCutoffPotential_bounds ν hc z (hδ n)).2

end UAMO.CircleDOS

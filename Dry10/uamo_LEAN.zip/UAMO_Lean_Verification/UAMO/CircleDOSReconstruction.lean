import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.MeasureTheory.Integral.Lebesgue.Map
import Mathlib.MeasureTheory.Integral.Lebesgue.Add
import Mathlib.MeasureTheory.Measure.Map
import Mathlib.Tactic

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set
open scoped ENNReal

def upperLift (x : ℝ) : ℂ := ⟨x, Real.sqrt (1 - x ^ 2)⟩
def lowerLift (x : ℝ) : ℂ := ⟨x, -Real.sqrt (1 - x ^ 2)⟩

theorem continuous_upperLift : Continuous upperLift := by
  have h : upperLift = fun x : ℝ => (x : ℂ) + (Real.sqrt (1 - x ^ 2) : ℂ) * Complex.I := by
    funext x
    apply Complex.ext <;> simp [upperLift]
  rw [h]
  exact Complex.continuous_ofReal.add ((Complex.continuous_ofReal.comp
    (Real.continuous_sqrt.comp (continuous_const.sub (continuous_id.pow 2)))).mul continuous_const)

theorem continuous_lowerLift : Continuous lowerLift := by
  have h : lowerLift = fun x : ℝ => star (upperLift x) := rfl
  rw [h]
  exact continuous_upperLift.star

@[simp] theorem upperLift_re (x : ℝ) : (upperLift x).re = x := rfl

@[simp] theorem conj_upperLift (x : ℝ) : star (upperLift x) = lowerLift x := rfl

theorem circle_lifts_pair (z : ℂ) (hz : ‖z‖ = 1) :
    (upperLift z.re = z ∧ lowerLift z.re = star z) ∨
      (upperLift z.re = star z ∧ lowerLift z.re = z) := by
  have hn : z.re ^ 2 + z.im ^ 2 = 1 := by
    have h := Complex.normSq_eq_norm_sq z
    rw [hz, one_pow] at h
    simpa only [Complex.normSq_apply, pow_two] using h
  have hs : Real.sqrt (1 - z.re ^ 2) = |z.im| := by
    rw [show 1 - z.re ^ 2 = z.im ^ 2 by linarith, Real.sqrt_sq_eq_abs]
  by_cases hi : 0 ≤ z.im
  · left
    rw [abs_of_nonneg hi] at hs
    constructor <;> apply Complex.ext <;> simp [upperLift, lowerLift, hs]
  · right
    rw [abs_of_neg (lt_of_not_ge hi)] at hs
    constructor <;> apply Complex.ext <;> simp [upperLift, lowerLift, hs]

theorem map_pair_eq_of_ae_pairing {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (ν : Measure X) (f g h k : X → Y)
    (hf : Measurable f) (hg : Measurable g) (hh : Measurable h) (hk : Measurable k)
    (hp : ∀ᵐ x ∂ν, (f x = h x ∧ g x = k x) ∨ (f x = k x ∧ g x = h x)) :
    Measure.map f ν + Measure.map g ν = Measure.map h ν + Measure.map k ν := by
  apply Measure.ext_of_lintegral
  intro v hv
  rw [lintegral_add_measure, lintegral_add_measure,
    lintegral_map hv hf, lintegral_map hv hg, lintegral_map hv hh, lintegral_map hv hk]
  rw [← lintegral_add_left (show Measurable (fun x => v (f x)) from hv.comp hf),
    ← lintegral_add_left (show Measurable (fun x => v (h x)) from hv.comp hh)]
  apply lintegral_congr_ae
  filter_upwards [hp] with x hx
  rcases hx with ⟨hx,hy⟩ | ⟨hx,hy⟩
  · rw [hx,hy]
  · rw [hx,hy,add_comm]

theorem circle_lifts_map_pair (ν : Measure ℂ) (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) :
    Measure.map upperLift (Measure.map Complex.re ν) +
      Measure.map lowerLift (Measure.map Complex.re ν) = ν + Measure.map star ν := by
  rw [Measure.map_map continuous_upperLift.measurable Complex.continuous_re.measurable,
    Measure.map_map continuous_lowerLift.measurable Complex.continuous_re.measurable]
  have h := map_pair_eq_of_ae_pairing ν (upperLift ∘ Complex.re) (lowerLift ∘ Complex.re)
    id star (continuous_upperLift.comp Complex.continuous_re).measurable
    (continuous_lowerLift.comp Complex.continuous_re).measurable measurable_id
    (continuous_star.measurable) (hc.mono fun z hz => circle_lifts_pair z hz)
  simpa only [Measure.map_id] using h

theorem circle_measure_reconstruction (ν : Measure ℂ)
    (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) (hconj : Measure.map star ν = ν) :
    ν = (1 / 2 : ℝ≥0∞) • Measure.map upperLift (Measure.map Complex.re ν) +
      (1 / 2 : ℝ≥0∞) • Measure.map lowerLift (Measure.map Complex.re ν) := by
  rw [← smul_add, circle_lifts_map_pair ν hc, hconj, smul_add, ← add_smul]
  have hh : (1 / 2 : ℝ≥0∞) + 1 / 2 = 1 := by
    simpa only [one_div] using ENNReal.inv_two_add_inv_two
  rw [hh, one_smul]

end UAMO.CircleDOS

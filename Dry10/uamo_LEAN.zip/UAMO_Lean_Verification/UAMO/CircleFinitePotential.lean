import UAMO.CirclePotentialAtoms
import Mathlib.MeasureTheory.Integral.Lebesgue.Add

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology

theorem log_distance_ne_zero_ae_of_finite_potential
    (ν : Measure ℂ) [IsProbabilityMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (z : ℂ) {b : ℝ} (hb : circleTotalPotential ν z = (b : EReal)) :
    ∀ᵐ w ∂ν, ‖z-w‖ ≠ 0 := by
  have hs := measure_singleton_eq_zero_of_circleTotalPotential_ne_bot ν hc z
    (by rw [hb]; exact EReal.coe_ne_bot b)
  apply ae_iff.mpr
  have he : {w : ℂ | ¬ ‖z-w‖ ≠ 0} = {z} := by ext w; simp [sub_eq_zero, eq_comm]
  rw [he]
  exact hs

theorem cutoffLog_tendsto_log (z w : ℂ) (hw : ‖z-w‖ ≠ 0) :
    Tendsto (fun n => Real.log (max (logRegularizationScale n) ‖z-w‖)) atTop
      (𝓝 (Real.log ‖z-w‖)) := by
  apply (Real.continuousAt_log hw).tendsto.comp
  simpa only [max_eq_right (norm_nonneg _)] using
    logRegularizationScale_tendsto.max (tendsto_const_nhds (x := ‖z-w‖))

theorem circle_log_integrable_of_finite_potential
    (ν : Measure ℂ) [IsProbabilityMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (z : ℂ) {b : ℝ} (hb : circleTotalPotential ν z = (b : EReal)) :
    Integrable (fun w => Real.log ‖z-w‖) ν := by
  let C := Real.log (‖z‖+2)
  let f : ℕ → ℂ → ℝ := fun n w => C-Real.log (max (logRegularizationScale n) ‖z-w‖)
  let F : ℂ → ℝ := fun w => C-Real.log ‖z-w‖
  have hs (n : ℕ) : logRegularizationScale n ≤ 1 := by
    simpa only [logRegularizationScale, Nat.cast_zero, zero_add, div_one] using
      logRegularizationScale_antitone (Nat.zero_le n)
  have hfi (n : ℕ) : Integrable (f n) ν :=
    (integrable_const C).sub (circleCutoffLog_integrable ν hc z (logRegularizationScale_pos n))
  have hfn (n : ℕ) : 0 ≤ᵐ[ν] f n := by
    filter_upwards [hc] with w hw
    apply sub_nonneg.mpr
    apply Real.log_le_log ((logRegularizationScale_pos n).trans_le (le_max_left _ _))
    apply max_le
    · linarith [hs n, norm_nonneg z]
    · have h := norm_sub_le z w
      rw [hw] at h
      linarith
  have hne := log_distance_ne_zero_ae_of_finite_potential ν hc z hb
  have hFt : ∀ᵐ w ∂ν, Tendsto (fun n => f n w) atTop (𝓝 (F w)) := by
    filter_upwards [hne] with w hw
    exact tendsto_const_nhds.sub (cutoffLog_tendsto_log z w hw)
  have hFn : 0 ≤ᵐ[ν] F := by
    filter_upwards [hFt, ae_all_iff.mpr hfn] with w hw hnon
    exact le_of_tendsto_of_tendsto' tendsto_const_nhds hw hnon
  have hbound (n : ℕ) : (∫ w, f n w ∂ν) ≤ C-b+Real.log 2 := by
    have hl : b ≤ circleRegularizedPotential ν z (logRegularizationScale n^2) := by
      apply EReal.coe_le_coe_iff.mp
      rw [← hb]
      exact regularization_inf_le _ (circleRegularizedPotential_monotone ν hc z) _
        (sq_pos_of_pos (logRegularizationScale_pos n))
    have hc := (circleCutoffPotential_bounds ν hc z (logRegularizationScale_pos n)).1
    have hlog : Real.log (1+logRegularizationScale n) ≤ Real.log 2 :=
      Real.log_le_log (by linarith [logRegularizationScale_pos n]) (by linarith [hs n])
    change (∫ w, C-Real.log (max (logRegularizationScale n) ‖z-w‖) ∂ν) ≤ _
    rw [integral_sub (integrable_const C)
      (circleCutoffLog_integrable ν ‹∀ᵐ w ∂ν, ‖w‖ = 1› z (logRegularizationScale_pos n))]
    simp only [integral_const, measureReal_def, measure_univ, ENNReal.toReal_one, one_smul]
    change C-circleCutoffPotential ν z (logRegularizationScale n) ≤ _
    linarith
  have hfl (n : ℕ) : (∫⁻ w, ENNReal.ofReal (f n w) ∂ν) ≤ ENNReal.ofReal (C-b+Real.log 2) := by
    rw [← ofReal_integral_eq_lintegral_ofReal (hfi n) (hfn n)]
    exact ENNReal.ofReal_le_ofReal (hbound n)
  have hfatou : (∫⁻ w, ENNReal.ofReal (F w) ∂ν) ≤ ENNReal.ofReal (C-b+Real.log 2) := by
    calc
      _ = ∫⁻ w, liminf (fun n => ENNReal.ofReal (f n w)) atTop ∂ν := by
        apply lintegral_congr_ae
        filter_upwards [hFt] with w hw
        exact ((ENNReal.continuous_ofReal.tendsto _).comp hw).liminf_eq.symm
      _ ≤ liminf (fun n => ∫⁻ w, ENNReal.ofReal (f n w) ∂ν) atTop :=
        lintegral_liminf_le' (fun n => (hfi n).aemeasurable.ennreal_ofReal)
      _ ≤ ENNReal.ofReal (C-b+Real.log 2) := by
        simpa only [liminf_const] using liminf_le_liminf (f := atTop) (Eventually.of_forall hfl)
  have hFm : AEStronglyMeasurable F ν :=
    (measurable_const.sub (Real.measurable_log.comp
      (continuous_const.sub continuous_id).norm.measurable)).aestronglyMeasurable
  have hFI : Integrable F ν := ⟨hFm, (hasFiniteIntegral_iff_ofReal hFn).mpr
    (hfatou.trans_lt ENNReal.ofReal_lt_top)⟩
  have h := (integrable_const C).sub hFI
  change Integrable (fun w => C-(C-Real.log ‖z-w‖)) ν at h
  simpa only [sub_sub_cancel] using h

theorem circleTotalPotential_eq_integral_of_finite
    (ν : Measure ℂ) [IsProbabilityMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (z : ℂ) {b : ℝ} (hb : circleTotalPotential ν z = (b : EReal)) :
    circleTotalPotential ν z = ((∫ w, Real.log ‖z-w‖ ∂ν : ℝ) : EReal) := by
  have hm : ∀ᵐ w ∂ν, Antitone
      (fun n => Real.log (max (logRegularizationScale n) ‖z-w‖)) := by
    apply Eventually.of_forall
    intro w n m hnm
    exact Real.log_le_log ((logRegularizationScale_pos m).trans_le (le_max_left _ _))
      (max_le_max_right _ (logRegularizationScale_antitone hnm))
  have ht : ∀ᵐ w ∂ν, Tendsto
      (fun n => Real.log (max (logRegularizationScale n) ‖z-w‖)) atTop
      (𝓝 (Real.log ‖z-w‖)) := by
    filter_upwards [log_distance_ne_zero_ae_of_finite_potential ν hc z hb] with w hw
    exact cutoffLog_tendsto_log z w hw
  have h := integral_tendsto_of_tendsto_of_antitone
    (fun n => circleCutoffLog_integrable ν hc z (logRegularizationScale_pos n))
    (circle_log_integrable_of_finite_potential ν hc z hb) hm ht
  exact tendsto_nhds_unique
    (circleCutoffPotential_tendsto ν hc z logRegularizationScale
      logRegularizationScale_pos logRegularizationScale_tendsto)
    (continuous_coe_real_ereal.continuousAt.tendsto.comp h)

end UAMO.CircleDOS

import UAMO.CircleDOSReconstruction
import Mathlib.Analysis.SpecialFunctions.Log.ENNRealLog
import Mathlib.MeasureTheory.Integral.Bochner.Basic

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set
open scoped ENNReal

theorem circle_mul_star_self (z : ℂ) (hz : ‖z‖ = 1) : z * star z = 1 := by
  rw [Complex.star_def, Complex.mul_conj, Complex.normSq_eq_norm_sq, hz]
  norm_num

theorem circle_distance_product (z w : ℂ) (hz : ‖z‖ = 1) (hw : ‖w‖ = 1) :
    ‖z - w‖ * ‖z - star w‖ = 2 * |z.re - w.re| := by
  have hp : (z - w) * (z - star w) = z * ((2 * (z.re - w.re) : ℝ) : ℂ) := by
    calc
      (z-w)*(z-star w) = z*(z + star z - (w + star w)) +
          (w*star w-z*star z) := by ring
      _ = z*(z + star z - (w + star w)) := by
        rw [circle_mul_star_self z hz, circle_mul_star_self w hw, sub_self, add_zero]
      _ = z * ((2 * (z.re - w.re) : ℝ) : ℂ) := by
        rw [Complex.star_def, Complex.add_conj, Complex.add_conj]
        push_cast
        ring
  rw [← norm_mul, hp, norm_mul, hz, one_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]

theorem circle_distance_le_two (z w : ℂ) (hz : ‖z‖ = 1) (hw : ‖w‖ = 1) :
    ‖z-w‖ ≤ 2 := by
  calc ‖z-w‖ ≤ ‖z‖+‖w‖ := norm_sub_le _ _
    _ = 2 := by rw [hz,hw]; norm_num

def regularizedCircleLog (ε : ℝ) (z w : ℂ) : ℝ := Real.log (‖z-w‖+ε)

theorem regularizedCircleLog_continuous (ε : ℝ) (hε : 0 < ε) (z : ℂ) :
    Continuous (regularizedCircleLog ε z) :=
  ((continuous_const.sub continuous_id).norm.add continuous_const).log
    (fun w => (add_pos_of_nonneg_of_pos (norm_nonneg (z-w)) hε).ne')

theorem regularized_circle_log_pair_bounds (z w : ℂ)
    (hz : ‖z‖ = 1) (hw : ‖w‖ = 1) (ε : ℝ) (hε : 0 < ε) :
    Real.log (2*|z.re-w.re|+ε^2) ≤
        regularizedCircleLog ε z w + regularizedCircleLog ε z (star w) ∧
    regularizedCircleLog ε z w + regularizedCircleLog ε z (star w) ≤
        Real.log (2*|z.re-w.re|+4*ε+ε^2) := by
  have hprod := circle_distance_product z w hz hw
  have hw' : ‖star w‖ = 1 := by simpa only [norm_star] using hw
  have hd := circle_distance_le_two z w hz hw
  have he := circle_distance_le_two z (star w) hz hw'
  have hd0 := norm_nonneg (z-w)
  have he0 := norm_nonneg (z-star w)
  unfold regularizedCircleLog
  rw [← Real.log_mul (by positivity : ‖z-w‖+ε ≠ 0)
    (by positivity : ‖z-star w‖+ε ≠ 0)]
  constructor
  · apply Real.log_le_log (by positivity)
    nlinarith [mul_nonneg hε.le hd0, mul_nonneg hε.le he0]
  · apply Real.log_le_log (by positivity)
    nlinarith [mul_le_mul_of_nonneg_left hd hε.le, mul_le_mul_of_nonneg_left he hε.le]

end UAMO.CircleDOS

import Mathlib.Analysis.SpecialFunctions.Complex.LogBounds
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section

namespace UAMO.CircleDOS

open MeasureTheory
open scoped ComplexConjugate

def logFourierChar (k : ℤ) (t : ℝ) : ℂ :=
  Complex.exp ((k : ℂ) * (2 * (Real.pi : ℂ) * Complex.I) * t)

@[simp] theorem logFourierChar_zero (t : ℝ) : logFourierChar 0 t = 1 := by
  simp [logFourierChar]

@[simp] theorem logFourierChar_norm (k : ℤ) (t : ℝ) : ‖logFourierChar k t‖ = 1 := by
  simp [logFourierChar, Complex.norm_exp]

theorem logFourierChar_continuous (k : ℤ) : Continuous (logFourierChar k) := by
  unfold logFourierChar
  fun_prop

theorem logFourierChar_add (j k : ℤ) (t : ℝ) :
    logFourierChar (j + k) t = logFourierChar j t * logFourierChar k t := by
  simp only [logFourierChar, Int.cast_add, add_mul, Complex.exp_add]

@[simp] theorem logFourierChar_conj (k : ℤ) (t : ℝ) :
    conj (logFourierChar k t) = logFourierChar (-k) t := by
  simp [logFourierChar, ← Complex.exp_conj, map_ofNat]

theorem logFourierChar_pow (k : ℤ) (n : ℕ) (t : ℝ) :
    logFourierChar k t ^ n = logFourierChar (k * n) t := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ, ih, ← logFourierChar_add]
    congr 1
    push_cast
    ring

theorem integral_logFourierChar (k : ℤ) :
    (∫ t in (0 : ℝ)..1, logFourierChar k t) = if k = 0 then 1 else 0 := by
  by_cases hk : k = 0
  · simp [hk]
  · have hc : (k : ℂ) * (2 * (Real.pi : ℂ) * Complex.I) ≠ 0 := by
      simp [hk, Real.pi_ne_zero]
    unfold logFourierChar
    rw [integral_exp_mul_complex hc]
    simp [hk]

def logFourierCoeff (f : ℝ → ℝ) (k : ℤ) : ℂ :=
  ∫ t in (0 : ℝ)..1, (f t : ℂ) * logFourierChar (-k) t

@[simp] theorem logFourierCoeff_const (c : ℝ) {k : ℤ} (hk : k ≠ 0) :
    logFourierCoeff (fun _ => c) k = 0 := by
  simp [logFourierCoeff, intervalIntegral.integral_const_mul, integral_logFourierChar, hk]

theorem logFourierCoeff_neg_frequency (f : ℝ → ℝ) (k : ℤ) :
    logFourierCoeff f (-k) = conj (logFourierCoeff f k) := by
  simp only [logFourierCoeff, intervalIntegral, ← integral_conj, map_sub]
  congr 1 <;> apply integral_congr_ae <;> filter_upwards with t <;>
    simp [logFourierChar_conj]

theorem hasSum_neg_log_norm {z : ℂ} (hz : ‖z‖ < 1) :
    HasSum (fun n : ℕ => (((z ^ n / n).re : ℝ) : ℂ))
      (-(Real.log ‖1 - z‖ : ℂ)) := by
  have h := Complex.hasSum_ofReal.mpr
    (Complex.hasSum_re (Complex.hasSum_taylorSeries_neg_log hz))
  simpa only [Complex.neg_re, Complex.log_re, Complex.ofReal_neg] using h

private theorem logFourier_term_bound (a : ℂ) (n : ℕ) (k : ℤ) (t : ℝ) :
    ‖((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
      logFourierChar (-k) t‖ ≤ ‖a‖ ^ n := by
  rw [norm_mul, logFourierChar_norm, mul_one, Complex.norm_real,
    Real.norm_eq_abs]
  calc
    |((a * logFourierChar 1 t) ^ n / n).re| ≤
        ‖(a * logFourierChar 1 t) ^ n / n‖ := Complex.abs_re_le_norm _
    _ ≤ ‖a‖ ^ n := by
      simp only [norm_div, norm_pow, norm_mul, logFourierChar_norm,
        mul_one, Complex.norm_natCast]
      rcases n.eq_zero_or_pos with rfl | hn
      · simp
      · exact div_le_self (pow_nonneg (norm_nonneg a) n) (by exact_mod_cast hn)

theorem hasSum_logFourier_integrals {a : ℂ} (ha : ‖a‖ < 1) (k : ℤ) :
    HasSum (fun n : ℕ => ∫ t in (0 : ℝ)..1,
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t)
      (-logFourierCoeff (fun t => Real.log ‖1 - a * logFourierChar 1 t‖) k) := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence
    (a := (0 : ℝ)) (b := 1) (μ := volume)
    (F := fun (n : ℕ) t => ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
      logFourierChar (-k) t)
    (f := fun t => -(Real.log ‖1 - a * logFourierChar 1 t‖ : ℂ) *
      logFourierChar (-k) t)
    (fun n _ => ‖a‖ ^ n)
    (fun n => (show Continuous (fun t : ℝ =>
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
        logFourierChar (-k) t) by
      unfold logFourierChar
      fun_prop).aestronglyMeasurable)
    (fun n => ae_of_all _ (fun t _ => logFourier_term_bound a n k t))
    (ae_of_all _ (fun _ _ => summable_geometric_of_lt_one (norm_nonneg a) ha))
    intervalIntegrable_const
    (ae_of_all _ (fun t _ =>
      (hasSum_neg_log_norm (by simpa using ha : ‖a * logFourierChar 1 t‖ < 1)).mul_right
        (logFourierChar (-k) t)))
  simpa only [neg_mul, intervalIntegral.integral_neg, logFourierCoeff] using h

private theorem integral_logFourier_term (a : ℂ) (n : ℕ) (k : ℤ) :
    (∫ t in (0 : ℝ)..1,
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t) =
      (a ^ n * (if (n : ℤ) - k = 0 then 1 else 0) +
        conj a ^ n * (if -(n : ℤ) - k = 0 then 1 else 0)) / (2 * n) := by
  have hterm (t : ℝ) :
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t =
        (a ^ n * logFourierChar ((n : ℤ) - k) t +
          conj a ^ n * logFourierChar (-(n : ℤ) - k) t) / (2 * n) := by
    rw [Complex.re_eq_add_conj]
    simp only [map_div₀, map_pow, map_mul, map_natCast, logFourierChar_conj,
      mul_pow, logFourierChar_pow, one_mul, neg_one_mul]
    rw [sub_eq_add_neg, sub_eq_add_neg, logFourierChar_add, logFourierChar_add]
    ring
  simp_rw [hterm]
  rw [intervalIntegral.integral_div, intervalIntegral.integral_add]
  · simp only [intervalIntegral.integral_const_mul, integral_logFourierChar]
  · exact (continuous_const.mul (logFourierChar_continuous _)).intervalIntegrable _ _
  · exact (continuous_const.mul (logFourierChar_continuous _)).intervalIntegrable _ _

theorem integral_log_norm_one_sub {a : ℂ} (ha : ‖a‖ < 1) :
    (∫ t in (0 : ℝ)..1, Real.log ‖1-a*logFourierChar 1 t‖) = 0 := by
  have h := hasSum_logFourier_integrals ha 0
  have hterm (n : ℕ) : (∫ t in (0 : ℝ)..1,
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-(0 : ℤ)) t) = 0 := by
    rw [integral_logFourier_term]
    by_cases hn : n = 0
    · simp [hn]
    · have hnz : (n : ℤ) ≠ 0 := by exact_mod_cast hn
      simp [hnz, hn]
  simp_rw [hterm] at h
  have heq := h.unique (hasSum_zero : HasSum (fun _ : ℕ => (0 : ℂ)) 0)
  have hz : logFourierCoeff (fun t => Real.log ‖1-a*logFourierChar 1 t‖) 0 = 0 := neg_eq_zero.mp heq
  simpa only [logFourierCoeff, neg_zero, logFourierChar_zero, mul_one,
    intervalIntegral.integral_ofReal, Complex.ofReal_eq_zero] using hz

end UAMO.CircleDOS

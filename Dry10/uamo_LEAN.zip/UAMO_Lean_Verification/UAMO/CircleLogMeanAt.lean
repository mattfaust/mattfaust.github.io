import UAMO.CirclePolynomialJensen

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory

theorem circle_affine_distance_factor (c R w : ℂ) (hR : R ≠ 0) (t : ℝ) :
    c+R*logFourierChar 1 t-w = R*(logFourierChar 1 t-(w-c)/R) := by
  field_simp
  ring

theorem circle_affine_log_ae (c R w : ℂ) (hR : R ≠ 0) :
    (fun t => Real.log ‖c+R*logFourierChar 1 t-w‖) =ᵐ[volume]
      (fun t => Real.log ‖R‖ + Real.log ‖logFourierChar 1 t-(w-c)/R‖) := by
  filter_upwards [logFourierChar_root_ne_zero_ae ((w-c)/R)] with t ht
  rw [circle_affine_distance_factor c R w hR t, norm_mul,
    Real.log_mul (norm_ne_zero_iff.mpr hR) (norm_ne_zero_iff.mpr ht)]

theorem circle_affine_log_integrable (c R w : ℂ) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖c+R*logFourierChar 1 x-w‖) volume s t := by
  by_cases hR : R = 0
  · simp only [hR, zero_mul, add_zero]
    exact intervalIntegrable_const
  · exact (intervalIntegrable_const.add (logFourierChar_root_integrable ((w-c)/R) s t)).congr
      (ae_restrict_of_ae (circle_affine_log_ae c R w hR).symm)

theorem integral_circle_affine_log (c R w : ℂ) :
    (∫ t in (0 : ℝ)..1, Real.log ‖c+R*logFourierChar 1 t-w‖) =
      Real.log (max ‖R‖ ‖c-w‖) := by
  by_cases hR : R = 0
  · simp [hR, max_eq_right (norm_nonneg (c-w))]
  have hRp : 0 < ‖R‖ := norm_pos_iff.mpr hR
  rw [intervalIntegral.integral_congr_ae_restrict
    (ae_restrict_of_ae (circle_affine_log_ae c R w hR)),
    intervalIntegral.integral_add intervalIntegrable_const
      (logFourierChar_root_integrable ((w-c)/R) 0 1),
    integral_logFourierChar_root]
  simp only [intervalIntegral.integral_const, sub_zero, one_smul, norm_div, norm_sub_rev w c]
  rw [← Real.log_mul hRp.ne' (ne_of_gt (lt_of_lt_of_le zero_lt_one (le_max_left _ _)))]
  congr 1
  rw [mul_max_of_nonneg _ _ hRp.le, mul_one, mul_div_cancel₀ _ hRp.ne']

theorem circle_affine_ne_zero (c R : ℂ) (hR : ‖R‖ < ‖c‖) (t : ℝ) :
    c+R*logFourierChar 1 t ≠ 0 := by
  intro h
  have he : c = -(R*logFourierChar 1 t) := eq_neg_of_add_eq_zero_left h
  have hn := congrArg norm he
  simp only [norm_neg, norm_mul, logFourierChar_norm, mul_one] at hn
  exact (ne_of_gt hR) hn

theorem integral_circle_log_of_radius_lt (c R : ℂ) (hR : ‖R‖ < ‖c‖) :
    (∫ t in (0 : ℝ)..1, Real.log ‖c+R*logFourierChar 1 t‖) = Real.log ‖c‖ := by
  simpa only [sub_zero, max_eq_right hR.le] using integral_circle_affine_log c R 0

end UAMO.CircleDOS

import UAMO.CircleLogPotential
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter
open scoped Topology

def offCircleLogBound (z : ℂ) : ℝ :=
  |Real.log (|‖z‖-1|)| + |Real.log (‖z‖+2)|

theorem log_distance_bound (z w : ℂ) (hz : ‖z‖ ≠ 1) (hw : ‖w‖ = 1)
    (δ : ℝ) (hδ : 0 ≤ δ) (hδ1 : δ ≤ 1) :
    |Real.log (‖z-w‖+δ)| ≤ offCircleLogBound z := by
  have hd : 0 < |‖z‖-1| := abs_pos.mpr (sub_ne_zero.mpr hz)
  have hlo : |‖z‖-1| ≤ ‖z-w‖+δ := by
    have h := abs_norm_sub_norm_le z w
    rw [hw] at h
    linarith
  have hhi : ‖z-w‖+δ ≤ ‖z‖+2 := by
    have h := norm_sub_le z w
    rw [hw] at h
    linarith
  have hloglo := Real.log_le_log hd hlo
  have hloghi := Real.log_le_log (hd.trans_le hlo) hhi
  unfold offCircleLogBound
  apply abs_le.mpr
  constructor
  · linarith [neg_abs_le (Real.log |‖z‖-1|), abs_nonneg (Real.log (‖z‖+2))]
  · linarith [le_abs_self (Real.log (‖z‖+2)), abs_nonneg (Real.log |‖z‖-1|)]

theorem circle_log_distance_integrable (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) (hz : ‖z‖ ≠ 1) :
    Integrable (fun w => Real.log ‖z-w‖) ν := by
  apply (integrable_const (offCircleLogBound z)).mono'
    (Real.measurable_log.comp (continuous_const.sub continuous_id).norm.measurable).aestronglyMeasurable
  filter_upwards [hc] with w hw
  simpa only [add_zero, Real.norm_eq_abs] using log_distance_bound z w hz hw 0 le_rfl zero_le_one

theorem circleRegularizedPotential_tendsto_off_circle
    (ν : Measure ℂ) [IsFiniteMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (z : ℂ) (hz : ‖z‖ ≠ 1) :
    Tendsto (fun n => circleRegularizedPotential ν z (logRegularizationScale n))
      atTop (𝓝 (∫ w, Real.log ‖z-w‖ ∂ν)) := by
  apply tendsto_integral_of_dominated_convergence (fun _ => offCircleLogBound z)
  · intro n
    exact (regularizedCircleLog_continuous _ (logRegularizationScale_pos n) z).aestronglyMeasurable
  · exact integrable_const _
  · intro n
    filter_upwards [hc] with w hw
    have hs : logRegularizationScale n ≤ 1 := by
      simpa only [logRegularizationScale, Nat.cast_zero, zero_add, div_one] using
        logRegularizationScale_antitone (Nat.zero_le n)
    exact log_distance_bound z w hz hw _ (logRegularizationScale_pos n).le hs
  · filter_upwards [hc] with w hw
    have hn : ‖z-w‖ ≠ 0 := by
      intro h
      have hzw : z = w := sub_eq_zero.mp (norm_eq_zero.mp h)
      exact hz (hzw ▸ hw)
    exact (Real.continuousAt_log hn).tendsto.comp
      (by simpa using logRegularizationScale_tendsto.const_add ‖z-w‖)

theorem circleTotalPotential_eq_integral_off_circle
    (ν : Measure ℂ) [IsFiniteMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (z : ℂ) (hz : ‖z‖ ≠ 1) :
    circleTotalPotential ν z = ((∫ w, Real.log ‖z-w‖ ∂ν : ℝ) : EReal) := by
  apply tendsto_nhds_unique
    (tendsto_regularization_inf _ (circleRegularizedPotential_monotone ν hc z)
      logRegularizationScale logRegularizationScale_pos logRegularizationScale_tendsto)
  exact continuous_coe_real_ereal.continuousAt.tendsto.comp
    (circleRegularizedPotential_tendsto_off_circle ν hc z hz)

end UAMO.CircleDOS

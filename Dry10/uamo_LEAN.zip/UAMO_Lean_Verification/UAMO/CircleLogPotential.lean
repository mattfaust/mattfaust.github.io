import UAMO.CircleLogKernel
import UAMO.LogRegularizationLimits
import Mathlib.MeasureTheory.Function.LocallyIntegrable

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set Filter
open scoped ENNReal Topology

theorem integrable_continuous_of_ae_circle (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (f : ℂ → ℝ) (hf : Continuous f) : Integrable f ν := by
  have ha : ∀ᵐ w ∂ν, w ∈ Metric.sphere (0 : ℂ) 1 := by
    simpa only [Metric.mem_sphere, dist_zero_right] using hc
  have hi : IntegrableOn f (Metric.sphere (0 : ℂ) 1) ν :=
    hf.continuousOn.integrableOn_compact (isCompact_sphere (0 : ℂ) 1)
  simpa only [IntegrableOn, Measure.restrict_eq_self_of_ae_mem ha] using hi

def circleRegularizedPotential (ν : Measure ℂ) (z : ℂ) (δ : ℝ) : ℝ :=
  ∫ w, regularizedCircleLog δ z w ∂ν

def realProjectionRegularizedPotential (ν : Measure ℂ) (t δ : ℝ) : ℝ :=
  ∫ w, Real.log (|t-w.re|+δ) ∂ν

def circleTotalPotential (ν : Measure ℂ) (z : ℂ) : EReal :=
  ⨅ n : ℕ, (circleRegularizedPotential ν z (logRegularizationScale n) : EReal)

def realProjectionTotalPotential (ν : Measure ℂ) (t : ℝ) : EReal :=
  ⨅ n : ℕ, (realProjectionRegularizedPotential ν t (logRegularizationScale n) : EReal)

theorem regularized_circle_integrable (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) {δ : ℝ} (hδ : 0 < δ) :
    Integrable (regularizedCircleLog δ z) ν :=
  integrable_continuous_of_ae_circle ν hc _ (regularizedCircleLog_continuous δ hδ z)

theorem regularized_realProjection_continuous (t δ : ℝ) (hδ : 0 < δ) :
    Continuous (fun w : ℂ => Real.log (|t-w.re|+δ)) :=
  ((continuous_const.sub Complex.continuous_re).abs.add continuous_const).log
    (fun w => (add_pos_of_nonneg_of_pos (abs_nonneg (t-w.re)) hδ).ne')

theorem regularized_realProjection_integrable (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (t : ℝ) {δ : ℝ} (hδ : 0 < δ) :
    Integrable (fun w : ℂ => Real.log (|t-w.re|+δ)) ν :=
  integrable_continuous_of_ae_circle ν hc _ (regularized_realProjection_continuous t δ hδ)

theorem circleRegularizedPotential_monotone (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) :
    MonotoneOn (circleRegularizedPotential ν z) (Ioi 0) := by
  intro δ hδ ε hε hδε
  change 0 < δ at hδ
  change 0 < ε at hε
  apply integral_mono (regularized_circle_integrable ν hc z hδ)
    (regularized_circle_integrable ν hc z hε)
  intro w
  exact Real.log_le_log (by positivity) (add_le_add_left hδε _)

theorem realProjectionRegularizedPotential_monotone (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (t : ℝ) :
    MonotoneOn (realProjectionRegularizedPotential ν t) (Ioi 0) := by
  intro δ hδ ε hε hδε
  change 0 < δ at hδ
  change 0 < ε at hε
  apply integral_mono (regularized_realProjection_integrable ν hc t hδ)
    (regularized_realProjection_integrable ν hc t hε)
  intro w
  exact Real.log_le_log (by positivity) (add_le_add_left hδε _)

theorem circleRegularizedPotential_pair_integral (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (hconj : Measure.map star ν = ν)
    (z : ℂ) (ε : ℝ) (hε : 0 < ε) :
    2 * circleRegularizedPotential ν z ε =
      ∫ w, regularizedCircleLog ε z w + regularizedCircleLog ε z (star w) ∂ν := by
  have hf := regularizedCircleLog_continuous ε hε z
  have hi := regularized_circle_integrable ν hc z hε
  have hi' : Integrable (fun w => regularizedCircleLog ε z (star w)) ν :=
    integrable_continuous_of_ae_circle ν hc _ (hf.comp continuous_star)
  have hm : (∫ w, regularizedCircleLog ε z w ∂Measure.map star ν) =
      ∫ w, regularizedCircleLog ε z (star w) ∂ν :=
    integral_map continuous_star.measurable.aemeasurable hf.aestronglyMeasurable
  rw [hconj] at hm
  rw [integral_add hi hi', ← hm, circleRegularizedPotential, two_mul]

theorem circleRegularizedPotential_bounds (ν : Measure ℂ) [IsProbabilityMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (hconj : Measure.map star ν = ν)
    (z : ℂ) (hz : ‖z‖ = 1) (ε : ℝ) (hε : 0 < ε) :
    Real.log 2 + realProjectionRegularizedPotential ν z.re (ε^2/2) ≤
        2*circleRegularizedPotential ν z ε ∧
    2*circleRegularizedPotential ν z ε ≤
        Real.log 2 + realProjectionRegularizedPotential ν z.re (2*ε+ε^2/2) := by
  have hlo : 0 < ε^2/2 := by positivity
  have hhi : 0 < 2*ε+ε^2/2 := by positivity
  have hipair := (regularized_circle_integrable ν hc z hε).add
    (integrable_continuous_of_ae_circle ν hc _
      ((regularizedCircleLog_continuous ε hε z).comp continuous_star))
  have hil := (integrable_const (Real.log 2)).add
    (regularized_realProjection_integrable ν hc z.re hlo)
  have hiu := (integrable_const (Real.log 2)).add
    (regularized_realProjection_integrable ν hc z.re hhi)
  have hsplit (t δ : ℝ) (hδ : 0 < δ) :
      Real.log (2*|t|+2*δ) = Real.log 2 + Real.log (|t|+δ) := by
    rw [show 2*|t|+2*δ = 2*(|t|+δ) by ring, Real.log_mul (by norm_num) (by positivity)]
  have hlower := integral_mono_ae hil hipair (hc.mono fun w hw => by
    have h := (regularized_circle_log_pair_bounds z w hz hw ε hε).1
    rw [show 2*|z.re-w.re|+ε^2 = 2*|z.re-w.re|+2*(ε^2/2) by ring,
      hsplit _ _ hlo] at h
    exact h)
  have hupper := integral_mono_ae hipair hiu (hc.mono fun w hw => by
    have h := (regularized_circle_log_pair_bounds z w hz hw ε hε).2
    rw [show 2*|z.re-w.re|+4*ε+ε^2 = 2*|z.re-w.re|+2*(2*ε+ε^2/2) by ring,
      hsplit _ _ hhi] at h
    exact h)
  dsimp only [Pi.add_apply, Function.comp_apply] at hlower hupper
  rw [← circleRegularizedPotential_pair_integral ν hc hconj z ε hε] at hlower hupper
  simpa only [integral_add (integrable_const _) (regularized_realProjection_integrable ν hc z.re hlo),
    integral_add (integrable_const _) (regularized_realProjection_integrable ν hc z.re hhi),
    integral_const, measureReal_def, measure_univ, ENNReal.toReal_one, one_smul,
    realProjectionRegularizedPotential] using
    And.intro hlower hupper

theorem circle_total_log_identity (ν : Measure ℂ) [IsProbabilityMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (hconj : Measure.map star ν = ν)
    (z : ℂ) (hz : ‖z‖ = 1) :
    (2 : EReal) * circleTotalPotential ν z =
      (Real.log 2 : EReal) + realProjectionTotalPotential ν z.re := by
  let δ : ℕ → ℝ := fun n => logRegularizationScale n ^ 2 / 2
  let ε : ℕ → ℝ := fun n => 2*logRegularizationScale n + logRegularizationScale n ^ 2/2
  have hδpos : ∀ n, 0 < δ n := fun n => by dsimp [δ]; exact div_pos (sq_pos_of_pos (logRegularizationScale_pos n)) (by norm_num)
  have hεpos : ∀ n, 0 < ε n := fun n => by
    dsimp [ε]
    have h := logRegularizationScale_pos n
    positivity
  have hδlim : Tendsto δ atTop (𝓝 0) := by
    simpa only [δ, zero_pow (by decide : (2 : ℕ) ≠ 0), zero_div] using
      (logRegularizationScale_tendsto.pow 2).div_const 2
  have hεlim : Tendsto ε atTop (𝓝 0) := by
    simpa only [ε, mul_zero, zero_add] using
      (logRegularizationScale_tendsto.const_mul 2).add hδlim
  have hF := realProjectionRegularizedPotential_monotone ν hc z.re
  have hL := tendsto_ereal_add_real (tendsto_regularization_inf _ hF δ hδpos hδlim) (Real.log 2)
  have hU := tendsto_ereal_add_real (tendsto_regularization_inf _ hF ε hεpos hεlim) (Real.log 2)
  have hC := tendsto_ereal_mul_real
    (tendsto_regularization_inf _ (circleRegularizedPotential_monotone ν hc z)
      logRegularizationScale logRegularizationScale_pos logRegularizationScale_tendsto)
    2 (by norm_num)
  have hmid : Tendsto (fun n => ((2*circleRegularizedPotential ν z (logRegularizationScale n) : ℝ) : EReal))
      atTop (𝓝 ((Real.log 2 : EReal) + realProjectionTotalPotential ν z.re)) := by
    apply tendsto_of_tendsto_of_tendsto_of_le_of_le hL hU
    · intro n
      exact EReal.coe_le_coe_iff.mpr (circleRegularizedPotential_bounds ν hc hconj z hz _
        (logRegularizationScale_pos n)).1
    · intro n
      exact EReal.coe_le_coe_iff.mpr (circleRegularizedPotential_bounds ν hc hconj z hz _
        (logRegularizationScale_pos n)).2
  apply tendsto_nhds_unique _ hmid
  simpa [EReal.coe_mul, circleTotalPotential] using hC

end UAMO.CircleDOS

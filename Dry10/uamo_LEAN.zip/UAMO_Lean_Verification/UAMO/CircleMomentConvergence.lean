import UAMO.CircleMomentDeterminacy
import UAMO.CircleLogOffCircle
import Mathlib.Topology.MetricSpace.Equicontinuity

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology ComplexConjugate

local instance : MeasurableSpace Circle := borel Circle
local instance : BorelSpace Circle := ⟨rfl⟩

theorem circleIntegralCLM_bound (μ : Measure Circle) [IsProbabilityMeasure μ]
    (f : C(Circle, ℂ)) : ‖circleIntegralCLM μ f‖ ≤ ‖f‖ := by
  have h := norm_integral_le_of_norm_le_const (μ := μ)
    (ae_of_all μ (fun z => ContinuousMap.norm_coe_le_norm f z))
  simpa only [circleIntegralCLM, LinearMap.mkContinuous_apply, measureReal_def,
    measure_univ, ENNReal.toReal_one, mul_one] using h

theorem circleFunctional_tendsto_of_characters_filter
    {ι : Type*} (l : Filter ι) (L : ι → C(Circle, ℂ) →L[ℂ] ℂ) (L₀ : C(Circle, ℂ) →L[ℂ] ℂ)
    (hLn : ∀ n f, ‖L n f‖ ≤ ‖f‖) (hL₀ : ∀ f, ‖L₀ f‖ ≤ ‖f‖)
    (hm : ∀ k : ℤ, Tendsto (fun n => L n (circleCharacter k))
      l (𝓝 (L₀ (circleCharacter k)))) (f : C(Circle, ℂ)) :
    Tendsto (fun n => L n f) l (𝓝 (L₀ f)) := by
  have hspan (g : C(Circle, ℂ)) (hg : g ∈ Submodule.span ℂ (range circleCharacter)) :
      Tendsto (fun n => L n g) l (𝓝 (L₀ g)) := by
    induction hg using Submodule.span_induction with
    | mem g hg => obtain ⟨k, rfl⟩ := hg; exact hm k
    | zero => simpa only [map_zero] using
        (tendsto_const_nhds : Tendsto (fun _ : ι => (0 : ℂ)) l (𝓝 0))
    | add g h _ _ ihg ihh => simpa only [map_add] using ihg.add ihh
    | smul c g _ ih => simpa only [map_smul] using ih.const_smul c
  have hEq : Equicontinuous (fun n f => L n f) :=
    Metric.equicontinuous_of_continuity_modulus id tendsto_id _ (fun g h n => by
      simpa only [id_eq, dist_eq_norm, ← map_sub] using hLn n (g - h))
  have hcont := AddMonoidHomClass.continuous_of_bound L₀ 1
    (by simpa only [one_mul] using hL₀)
  apply (hEq f).tendsto_of_mem_closure hcont.continuousAt.continuousWithinAt hspan
  change f ∈ (Submodule.span ℂ (range circleCharacter)).topologicalClosure
  rw [circleCharacter_span_dense]
  trivial

theorem circleFunctional_tendsto_of_nat_characters_filter
    {ι : Type*} (l : Filter ι) (L : ι → C(Circle, ℂ) →L[ℂ] ℂ) (L₀ : C(Circle, ℂ) →L[ℂ] ℂ)
    (hLn : ∀ n f, ‖L n f‖ ≤ ‖f‖) (hL₀ : ∀ f, ‖L₀ f‖ ≤ ‖f‖)
    (hsn : ∀ n f, L n (star f) = star (L n f))
    (hs₀ : ∀ f, L₀ (star f) = star (L₀ f))
    (hm : ∀ k : ℕ, Tendsto (fun n => L n (circleCharacter k))
      l (𝓝 (L₀ (circleCharacter k)))) (f : C(Circle, ℂ)) :
    Tendsto (fun n => L n f) l (𝓝 (L₀ f)) := by
  apply circleFunctional_tendsto_of_characters_filter l L L₀ hLn hL₀ _ f
  intro k
  cases k with
  | ofNat k => exact hm k
  | negSucc k =>
    simp only [Int.negSucc_eq, circleCharacter_neg, hsn, hs₀, Complex.star_def]
    exact Complex.continuous_conj.continuousAt.tendsto.comp (hm (k+1))

theorem circleFunctional_tendsto_of_nat_characters
    (L : ℕ → C(Circle, ℂ) →L[ℂ] ℂ) (L₀ : C(Circle, ℂ) →L[ℂ] ℂ)
    (hLn : ∀ n f, ‖L n f‖ ≤ ‖f‖) (hL₀ : ∀ f, ‖L₀ f‖ ≤ ‖f‖)
    (hsn : ∀ n f, L n (star f) = star (L n f))
    (hs₀ : ∀ f, L₀ (star f) = star (L₀ f))
    (hm : ∀ k : ℕ, Tendsto (fun n => L n (circleCharacter k))
      atTop (𝓝 (L₀ (circleCharacter k)))) (f : C(Circle, ℂ)) :
    Tendsto (fun n => L n f) atTop (𝓝 (L₀ f)) :=
  circleFunctional_tendsto_of_nat_characters_filter atTop L L₀ hLn hL₀ hsn hs₀ hm f

theorem circle_integral_tendsto_of_moments
    (μ : ℕ → Measure Circle) (ν : Measure Circle)
    [∀ n, IsProbabilityMeasure (μ n)] [IsProbabilityMeasure ν]
    (hm : ∀ k : ℕ, Tendsto (fun n => ∫ z : Circle, (z : ℂ)^k ∂μ n)
      atTop (𝓝 (∫ z : Circle, (z : ℂ)^k ∂ν))) (f : C(Circle, ℂ)) :
    Tendsto (fun n => ∫ z, f z ∂μ n) atTop (𝓝 (∫ z, f z ∂ν)) := by
  exact circleFunctional_tendsto_of_nat_characters (fun n => circleIntegralCLM (μ n))
    (circleIntegralCLM ν) (fun n => circleIntegralCLM_bound (μ n))
    (circleIntegralCLM_bound ν) (fun _ _ => integral_conj) (fun _ => integral_conj)
    (fun k => by simpa only [circleIntegralCLM, LinearMap.mkContinuous_apply,
      circleCharacter, ContinuousMap.coe_mk, zpow_natCast] using hm k) f

theorem circleComap_integral (μ : Measure ℂ) (hc : ∀ᵐ z ∂μ, ‖z‖ = 1) (f : ℂ → ℂ) :
    (∫ z : Circle, f z ∂circleComap μ) = ∫ z : ℂ, f z ∂μ := by
  calc
    _ = ∫ z, f z ∂(circleComap μ).map (fun z : Circle => (z : ℂ)) :=
      (circle_coe_measurableEmbedding.integral_map f).symm
    _ = _ := by rw [circleComap_map μ hc]

theorem circleProbability_integral_tendsto_of_moments
    (μ : ℕ → Measure ℂ) (ν : Measure ℂ)
    [∀ n, IsProbabilityMeasure (μ n)] [IsProbabilityMeasure ν]
    (hμ : ∀ n, ∀ᵐ z ∂μ n, ‖z‖ = 1) (hν : ∀ᵐ z ∂ν, ‖z‖ = 1)
    (hm : ∀ k : ℕ, Tendsto (fun n => ∫ z : ℂ, z^k ∂μ n) atTop (𝓝 (∫ z : ℂ, z^k ∂ν)))
    (f : ℂ → ℂ) (hf : Continuous (fun z : Circle => f z)) :
    Tendsto (fun n => ∫ z, f z ∂μ n) atTop (𝓝 (∫ z, f z ∂ν)) := by
  letI (n : ℕ) : IsProbabilityMeasure (circleComap (μ n)) := circleComap_probability _ (hμ n)
  letI : IsProbabilityMeasure (circleComap ν) := circleComap_probability _ hν
  have hm' (k : ℕ) : Tendsto
      (fun n => ∫ z : Circle, (z : ℂ)^k ∂circleComap (μ n)) atTop
      (𝓝 (∫ z : Circle, (z : ℂ)^k ∂circleComap ν)) := by
    simpa only [circleComap_integral _ (hμ _) (fun z => z^k),
      circleComap_integral ν hν (fun z => z^k)] using hm k
  have h := circle_integral_tendsto_of_moments (fun n => circleComap (μ n)) (circleComap ν)
    hm' ⟨fun z => f z, hf⟩
  simpa only [ContinuousMap.coe_mk, circleComap_integral _ (hμ _) f,
    circleComap_integral ν hν f] using h

end UAMO.CircleDOS

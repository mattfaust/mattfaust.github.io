import UAMO.CircleLogPotential
import Mathlib.Analysis.Complex.Circle
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.MeasureTheory.Measure.HasOuterApproxClosed

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set Algebra
open scoped Topology ComplexConjugate

local instance : MeasurableSpace Circle := borel Circle
local instance : BorelSpace Circle := ⟨rfl⟩

def circleCharacter (k : ℤ) : C(Circle, ℂ) :=
  ⟨fun z => (z : ℂ)^k, continuous_subtype_val.zpow₀ k (fun z : Circle => Or.inl (Circle.coe_ne_zero z))⟩

theorem circleCharacter_zero : circleCharacter 0 = 1 := by ext z; simp [circleCharacter]

theorem circleCharacter_add (m n : ℤ) :
    circleCharacter (m+n) = circleCharacter m * circleCharacter n := by
  ext z
  exact zpow_add₀ z.coe_ne_zero m n

theorem circleCharacter_neg (n : ℤ) :
    circleCharacter (-n) = star (circleCharacter n) := by
  ext z
  change (z : ℂ)^(-n) = star ((z : ℂ)^n)
  rw [star_zpow₀, zpow_neg, ← inv_zpow]
  congr 1
  exact z.coe_inv_eq_conj

def circleCharacterAlgebra : StarSubalgebra ℂ C(Circle, ℂ) where
  toSubalgebra := Algebra.adjoin ℂ (range circleCharacter)
  star_mem' := by
    show Algebra.adjoin ℂ (range circleCharacter) ≤ star (Algebra.adjoin ℂ (range circleCharacter))
    refine adjoin_le ?_
    rintro _ ⟨n, rfl⟩
    exact subset_adjoin ⟨-n, circleCharacter_neg n⟩

theorem circleCharacterAlgebra_span :
    circleCharacterAlgebra.toSubalgebra.toSubmodule = Submodule.span ℂ (range circleCharacter) := by
  apply adjoin_eq_span_of_subset
  refine Subset.trans ?_ Submodule.subset_span
  intro x hx
  refine Submonoid.closure_induction (fun _ => id) ⟨0, circleCharacter_zero⟩ ?_ hx
  rintro _ _ _ _ ⟨m, rfl⟩ ⟨n, rfl⟩
  exact ⟨m+n, circleCharacter_add m n⟩

theorem circleCharacterAlgebra_separates : circleCharacterAlgebra.SeparatesPoints := by
  intro x y hxy
  refine ⟨_, ⟨circleCharacter 1, subset_adjoin ⟨1, rfl⟩, rfl⟩, ?_⟩
  change (x : ℂ)^(1 : ℤ) ≠ (y : ℂ)^(1 : ℤ)
  simpa only [zpow_one] using fun h => hxy (Circle.ext h)

theorem circleCharacter_span_dense :
    (Submodule.span ℂ (range circleCharacter)).topologicalClosure = ⊤ := by
  rw [← circleCharacterAlgebra_span]
  exact congrArg (fun S : StarSubalgebra ℂ C(Circle, ℂ) => S.toSubalgebra.toSubmodule)
    (ContinuousMap.starSubalgebra_topologicalClosure_eq_top_of_separatesPoints
      circleCharacterAlgebra circleCharacterAlgebra_separates)

def circleIntegralCLM (μ : Measure Circle) [IsProbabilityMeasure μ] : C(Circle, ℂ) →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun f => ∫ z, f z ∂μ
      map_add' := fun f g => integral_add
        (f.continuous.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _))
        (g.continuous.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _))
      map_smul' := fun c f => integral_smul c f }
    1 (fun f => by
      have h := norm_integral_le_of_norm_le_const (μ := μ)
        (ae_of_all μ (fun z => ContinuousMap.norm_coe_le_norm f z))
      simpa using h)

theorem circleMeasure_eq_of_zpow_moments (μ ν : Measure Circle)
    [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hm : ∀ k : ℤ, (∫ z : Circle, (z : ℂ)^k ∂μ) = ∫ z : Circle, (z : ℂ)^k ∂ν) :
    μ = ν := by
  let L := circleIntegralCLM μ - circleIntegralCLM ν
  have hspan : Submodule.span ℂ (range circleCharacter) ≤ LinearMap.ker L.toLinearMap := by
    apply Submodule.span_le.mpr
    rintro _ ⟨k, rfl⟩
    change (∫ z : Circle, (z : ℂ)^k ∂μ) - (∫ z : Circle, (z : ℂ)^k ∂ν) = 0
    exact sub_eq_zero.mpr (hm k)
  have htop := (Submodule.span ℂ (range circleCharacter)).topologicalClosure_minimal
    hspan (ContinuousLinearMap.isClosed_ker L)
  rw [circleCharacter_span_dense] at htop
  have hall (f : C(Circle, ℂ)) : (∫ z, f z ∂μ) = ∫ z, f z ∂ν := by
    exact sub_eq_zero.mp (htop (Submodule.mem_top (x := f)))
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  have h := hall ⟨fun z => (f z : ℂ), Complex.continuous_ofReal.comp f.continuous⟩
  simpa only [ContinuousMap.coe_mk, integral_complex_ofReal, Complex.ofReal_inj] using h

theorem circleMeasure_eq_of_moments (μ ν : Measure Circle)
    [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hm : ∀ k : ℕ, (∫ z : Circle, (z : ℂ)^k ∂μ) = ∫ z : Circle, (z : ℂ)^k ∂ν) :
    μ = ν := by
  apply circleMeasure_eq_of_zpow_moments μ ν
  intro k
  cases k with
  | ofNat n => simpa using hm n
  | negSucc n =>
    have heq (z : Circle) : (z : ℂ)^(Int.negSucc n) = star ((z : ℂ)^(n+1)) := by
      have h := congrArg (fun f : C(Circle, ℂ) => f z) (circleCharacter_neg (n+1))
      simpa only [circleCharacter, ContinuousMap.coe_mk, ContinuousMap.star_apply,
        Int.negSucc_eq, zpow_natCast] using h
    simp_rw [heq]
    rw [Complex.star_def, integral_conj, integral_conj, hm]

theorem circle_coe_measurableEmbedding : MeasurableEmbedding (fun z : Circle => (z : ℂ)) := by
  have he : Topology.IsClosedEmbedding (fun z : Circle => (z : ℂ)) :=
    (show IsClosed (Metric.sphere (0 : ℂ) 1) from Metric.isClosed_sphere).isClosedEmbedding_subtypeVal
  exact he.measurableEmbedding

def circleComap (μ : Measure ℂ) : Measure Circle :=
  μ.comap (fun z : Circle => (z : ℂ))

theorem circleComap_ae_range (μ : Measure ℂ) (hc : ∀ᵐ z ∂μ, ‖z‖ = 1) :
    ∀ᵐ z ∂μ, z ∈ range (fun w : Circle => (w : ℂ)) := by
  filter_upwards [hc] with z hz
  refine ⟨⟨z, ?_⟩, rfl⟩
  change z ∈ Metric.sphere (0 : ℂ) 1
  simpa only [Metric.mem_sphere, dist_zero_right] using hz

theorem circleComap_map (μ : Measure ℂ) (hc : ∀ᵐ z ∂μ, ‖z‖ = 1) :
    (circleComap μ).map (fun z : Circle => (z : ℂ)) = μ := by
  rw [circleComap, circle_coe_measurableEmbedding.map_comap]
  exact Measure.restrict_eq_self_of_ae_mem (circleComap_ae_range μ hc)

theorem circleComap_probability (μ : Measure ℂ) [IsProbabilityMeasure μ]
    (hc : ∀ᵐ z ∂μ, ‖z‖ = 1) : IsProbabilityMeasure (circleComap μ) := by
  constructor
  rw [circleComap, circle_coe_measurableEmbedding.comap_apply, image_univ]
  exact (mem_ae_iff_prob_eq_one circle_coe_measurableEmbedding.measurableSet_range).mp
    (circleComap_ae_range μ hc)

theorem circleProbabilityMeasure_eq_of_moments (μ ν : Measure ℂ)
    [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hμ : ∀ᵐ z ∂μ, ‖z‖ = 1) (hν : ∀ᵐ z ∂ν, ‖z‖ = 1)
    (hm : ∀ n : ℕ, (∫ z : ℂ, z^n ∂μ) = ∫ z : ℂ, z^n ∂ν) : μ = ν := by
  letI := circleComap_probability μ hμ
  letI := circleComap_probability ν hν
  have heq : circleComap μ = circleComap ν := by
    apply circleMeasure_eq_of_moments
    intro n
    have h := hm n
    have hf : Continuous (fun z : ℂ => z^n) := continuous_id.pow n
    rw [← circleComap_map μ hμ, ← circleComap_map ν hν,
      integral_map circle_coe_measurableEmbedding.measurable.aemeasurable
        hf.aestronglyMeasurable,
      integral_map circle_coe_measurableEmbedding.measurable.aemeasurable
        hf.aestronglyMeasurable] at h
    exact h
  rw [← circleComap_map μ hμ, ← circleComap_map ν hν, heq]

end UAMO.CircleDOS

import UAMO.CirclePotentialAtoms

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set

theorem noAtoms_realPart (ν : Measure ℂ) [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν, ‖z‖ = 1) : NoAtoms (ν.map Complex.re) := by
  constructor
  intro x
  rw [Measure.map_apply Complex.continuous_re.measurable (measurableSet_singleton x)]
  have h : ν (Complex.re ⁻¹' {x}) ≤ ν {upperLift x, lowerLift x} := by
    apply measure_mono_ae
    filter_upwards [hc] with z hz
    intro hx
    have hx' : z.re = x := hx
    rcases circle_lifts_pair z hz with ⟨hu, _⟩ | ⟨_, hl⟩
    · simp only [hx'] at hu
      exact Or.inl hu.symm
    · simp only [hx'] at hl
      exact Or.inr hl.symm
  have hn : ν {upperLift x, lowerLift x} = 0 :=
    (Set.toFinite {upperLift x, lowerLift x}).measure_zero ν
  exact le_zero_iff.mp (hn ▸ h)

theorem noAtoms_of_map {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    [MeasurableSingletonClass X] [MeasurableSingletonClass Y]
    (μ : Measure X) (f : X → Y) (hf : Measurable f) [NoAtoms (μ.map f)] : NoAtoms μ := by
  constructor
  intro x
  have hz : μ (f ⁻¹' {f x}) = 0 := by
    rw [← Measure.map_apply hf (measurableSet_singleton (f x))]
    exact measure_singleton (f x)
  apply measure_mono_null _ hz
  intro y hy
  have hy' : y = x := hy
  subst y
  rfl

end UAMO.CircleDOS

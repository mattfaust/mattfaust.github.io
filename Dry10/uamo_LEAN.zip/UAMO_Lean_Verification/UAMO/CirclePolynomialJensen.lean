import UAMO.CircleRootLogMean

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Polynomial

def polynomialRootList (P : Polynomial ℂ) : List ℂ := P.roots.toList

theorem polynomial_eval_root_product (P : Polynomial ℂ) (z : ℂ) :
    P.eval z = P.leadingCoeff *
      ∏ i : Fin (polynomialRootList P).length, (z-(polynomialRootList P).get i) := by
  rw [Polynomial.eval_eq_prod_roots_sub_of_splits_id (IsAlgClosed.splits P) z]
  congr 1
  have hc : (↑(polynomialRootList P) : Multiset ℂ) = P.roots := Multiset.coe_toList _
  rw [← hc, Multiset.map_coe, Multiset.prod_coe]
  conv_lhs => rw [← List.ofFn_get (polynomialRootList P)]
  rw [List.map_ofFn, List.prod_ofFn]
  rfl

theorem polynomial_log_root_product (P : Polynomial ℂ) (hP : P ≠ 0) (z : ℂ)
    (hz : ∀ i : Fin (polynomialRootList P).length, z-(polynomialRootList P).get i ≠ 0) :
    Real.log ‖P.eval z‖ = Real.log ‖P.leadingCoeff‖ +
      ∑ i : Fin (polynomialRootList P).length, Real.log ‖z-(polynomialRootList P).get i‖ := by
  rw [polynomial_eval_root_product, norm_mul,
    Real.log_mul (norm_ne_zero_iff.mpr (Polynomial.leadingCoeff_ne_zero.mpr hP))
      (norm_ne_zero_iff.mpr (Finset.prod_ne_zero_iff.mpr (fun i _ => hz i))),
    norm_prod, Real.log_prod]
  exact fun i _ => norm_ne_zero_iff.mpr (hz i)

theorem polynomial_log_root_product_ae (P : Polynomial ℂ) (hP : P ≠ 0) :
    (fun t => Real.log ‖P.eval (logFourierChar 1 t)‖) =ᵐ[volume]
      (fun t => Real.log ‖P.leadingCoeff‖ +
        ∑ i : Fin (polynomialRootList P).length,
          Real.log ‖logFourierChar 1 t-(polynomialRootList P).get i‖) := by
  have hall := ae_all_iff.mpr
    (fun i : Fin (polynomialRootList P).length =>
      logFourierChar_root_ne_zero_ae ((polynomialRootList P).get i))
  filter_upwards [hall] with t ht
  exact polynomial_log_root_product P hP _ ht

theorem polynomial_circle_log_integrable (P : Polynomial ℂ) (hP : P ≠ 0) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖P.eval (logFourierChar 1 x)‖) volume s t := by
  have hi : IntervalIntegrable
      (fun x => ∑ i : Fin (polynomialRootList P).length,
        Real.log ‖logFourierChar 1 x-(polynomialRootList P).get i‖) volume s t := by
    convert IntervalIntegrable.sum
      (Finset.univ : Finset (Fin (polynomialRootList P).length))
      (f := fun i x => Real.log ‖logFourierChar 1 x-(polynomialRootList P).get i‖)
      (fun i _ => logFourierChar_root_integrable ((polynomialRootList P).get i) s t) using 1
    ext x
    simp only [Finset.sum_apply]
  exact (intervalIntegrable_const.add hi).congr
    (ae_restrict_of_ae (polynomial_log_root_product_ae P hP).symm)

theorem polynomial_circle_log_mean (P : Polynomial ℂ) (hP : P ≠ 0) :
    (∫ t in (0 : ℝ)..1, Real.log ‖P.eval (logFourierChar 1 t)‖) =
      Real.log ‖P.leadingCoeff‖ +
        ∑ i : Fin (polynomialRootList P).length,
          Real.log (max 1 ‖(polynomialRootList P).get i‖) := by
  have hi : IntervalIntegrable
      (fun x => ∑ i : Fin (polynomialRootList P).length,
        Real.log ‖logFourierChar 1 x-(polynomialRootList P).get i‖) volume 0 1 := by
    convert IntervalIntegrable.sum
      (Finset.univ : Finset (Fin (polynomialRootList P).length))
      (f := fun i x => Real.log ‖logFourierChar 1 x-(polynomialRootList P).get i‖)
      (fun i _ => logFourierChar_root_integrable ((polynomialRootList P).get i) 0 1) using 1
    ext x
    simp only [Finset.sum_apply]
  rw [intervalIntegral.integral_congr_ae_restrict
    (ae_restrict_of_ae (polynomial_log_root_product_ae P hP)),
    intervalIntegral.integral_add intervalIntegrable_const hi,
    intervalIntegral.integral_finset_sum (fun i _ => logFourierChar_root_integrable ((polynomialRootList P).get i) 0 1)]
  simp only [integral_logFourierChar_root, intervalIntegral.integral_const,
    sub_zero, one_smul]

theorem polynomial_circle_log_ge_zero_value (P : Polynomial ℂ) (hP0 : P.eval 0 ≠ 0) :
    Real.log ‖P.eval 0‖ ≤ ∫ t in (0 : ℝ)..1, Real.log ‖P.eval (logFourierChar 1 t)‖ := by
  have hP : P ≠ 0 := by intro h; simp [h] at hP0
  have hz : ∀ i : Fin (polynomialRootList P).length, (0 : ℂ)-(polynomialRootList P).get i ≠ 0 := by
    intro i hi
    have hp := polynomial_eval_root_product P 0
    have hprod : (∏ j : Fin (polynomialRootList P).length,
        ((0 : ℂ)-(polynomialRootList P).get j)) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ i) hi
    rw [hprod, mul_zero] at hp
    exact hP0 hp
  rw [polynomial_log_root_product P hP 0 hz, polynomial_circle_log_mean P hP]
  apply add_le_add_left
  apply Finset.sum_le_sum
  intro i _
  have hn := norm_pos_iff.mpr (hz i)
  simp only [zero_sub, norm_neg] at hn ⊢
  exact Real.log_le_log hn (le_max_right _ _)

theorem polynomial_circle_log_ge_center (P : Polynomial ℂ) (center radius : ℂ)
    (hc : P.eval center ≠ 0) :
    Real.log ‖P.eval center‖ ≤
      ∫ t in (0 : ℝ)..1, Real.log ‖P.eval (center+radius*logFourierChar 1 t)‖ := by
  let Q := P.comp (C center + C radius*X)
  have hq : Q.eval 0 ≠ 0 := by simpa [Q] using hc
  simpa [Q] using polynomial_circle_log_ge_zero_value Q hq

theorem polynomial_circle_log_integrable_center (P : Polynomial ℂ) (center radius : ℂ)
    (hc : P.eval center ≠ 0) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖P.eval (center+radius*logFourierChar 1 x)‖)
      volume s t := by
  let Q := P.comp (C center + C radius*X)
  have hq : Q ≠ 0 := by
    intro h
    have hv := congrArg (fun R : Polynomial ℂ => R.eval 0) h
    simp only [Q, Polynomial.eval_comp, Polynomial.eval_add, Polynomial.eval_mul,
      Polynomial.eval_C, Polynomial.eval_X, mul_zero, add_zero, Polynomial.eval_zero] at hv
    exact hc hv
  simpa [Q] using polynomial_circle_log_integrable Q hq s t

end UAMO.CircleDOS

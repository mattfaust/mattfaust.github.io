import UAMO.CircleCutoffPotential

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology

theorem circleCutoffPotential_atom_bound (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) {δ : ℝ} (hδ : 0 < δ) (hδ1 : δ ≤ 1) :
    circleCutoffPotential ν z δ ≤ ν.real {z} * Real.log δ +
      ν.real {z}ᶜ * Real.log (‖z‖+2) := by
  have hi := circleCutoffLog_integrable ν hc z hδ
  unfold circleCutoffPotential
  rw [← integral_add_compl (measurableSet_singleton z) hi, integral_singleton]
  simp only [sub_self, norm_zero, max_eq_left hδ.le, smul_eq_mul]
  apply add_le_add_left
  have h := integral_mono_ae (μ := ν.restrict {z}ᶜ)
    hi.integrableOn (integrable_const (Real.log (‖z‖+2))) ?_
  · simpa only [integral_const, measureReal_restrict_apply_univ, smul_eq_mul] using h
  · filter_upwards [ae_restrict_of_ae hc] with w hw
    apply Real.log_le_log (hδ.trans_le (le_max_left δ ‖z-w‖))
    apply max_le
    · linarith [norm_nonneg z]
    · have hn := norm_sub_le z w
      rw [hw] at hn
      linarith

theorem circleTotalPotential_eq_bot_of_atom (ν : Measure ℂ) [IsProbabilityMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) (ha : ν {z} ≠ 0) :
    circleTotalPotential ν z = ⊥ := by
  have hm : 0 < ν.real {z} := ENNReal.toReal_pos ha (measure_ne_top ν {z})
  have hlog : Tendsto (fun n => Real.log (logRegularizationScale n)) atTop atBot := by
    apply Real.tendsto_log_nhdsGT_zero.comp
    exact tendsto_nhdsWithin_iff.mpr ⟨logRegularizationScale_tendsto,
      Eventually.of_forall logRegularizationScale_pos⟩
  have hbot : Tendsto (fun n => (circleCutoffPotential ν z (logRegularizationScale n) : EReal))
      atTop (𝓝 ⊥) := by
    apply EReal.tendsto_nhds_bot_iff_real.mpr
    intro B
    let C := ν.real {z}ᶜ * Real.log (‖z‖+2)
    filter_upwards [hlog.eventually (eventually_lt_atBot ((B-C)/ν.real {z}))] with n hn
    have hn' : ν.real {z} * Real.log (logRegularizationScale n) + C < B := by
      have h := (lt_div_iff₀ hm).mp hn
      nlinarith
    have hs : logRegularizationScale n ≤ 1 := by
      simpa only [logRegularizationScale, Nat.cast_zero, zero_add, div_one] using
        logRegularizationScale_antitone (Nat.zero_le n)
    exact EReal.coe_lt_coe_iff.mpr
      ((circleCutoffPotential_atom_bound ν hc z (logRegularizationScale_pos n) hs).trans_lt hn')
  exact tendsto_nhds_unique
    (circleCutoffPotential_tendsto ν hc z logRegularizationScale
      logRegularizationScale_pos logRegularizationScale_tendsto) hbot

theorem measure_singleton_eq_zero_of_circleTotalPotential_ne_bot
    (ν : Measure ℂ) [IsProbabilityMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (z : ℂ) (hfinite : circleTotalPotential ν z ≠ ⊥) : ν {z} = 0 := by
  by_contra h
  exact hfinite (circleTotalPotential_eq_bot_of_atom ν hc z h)

theorem noAtoms_of_circleTotalPotential_ne_bot
    (ν : Measure ℂ) [IsProbabilityMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (hfinite : ∀ z, circleTotalPotential ν z ≠ ⊥) : NoAtoms ν := by
  constructor
  intro z
  exact measure_singleton_eq_zero_of_circleTotalPotential_ne_bot ν hc z (hfinite z)

end UAMO.CircleDOS

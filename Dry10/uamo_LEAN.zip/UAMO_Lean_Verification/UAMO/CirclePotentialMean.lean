import UAMO.CircleLogMeanAt
import Mathlib.MeasureTheory.Integral.Prod

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set

def angularParameterMeasure : Measure ℝ := volume.restrict (Ioc (0 : ℝ) 1)

instance angularParameterMeasure_probability : IsProbabilityMeasure angularParameterMeasure := by
  constructor
  simp [angularParameterMeasure, Real.volume_Ioc]

theorem integral_angularParameterMeasure (f : ℝ → ℝ) :
    (∫ t, f t ∂angularParameterMeasure) = ∫ t in (0 : ℝ)..1, f t := by
  rw [intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)]
  rfl

theorem circle_affine_log_integrable_angular (c R w : ℂ) :
    Integrable (fun t => Real.log ‖c+R*logFourierChar 1 t-w‖) angularParameterMeasure :=
  (circle_affine_log_integrable c R w 0 1).1

theorem circle_affine_log_upper (c R w : ℂ) (hw : ‖w‖ = 1) (t : ℝ) :
    Real.log ‖c+R*logFourierChar 1 t-w‖ ≤ Real.log (‖c‖+‖R‖+2) := by
  have hB : 0 ≤ Real.log (‖c‖+‖R‖+2) := Real.log_nonneg (by
    have := norm_nonneg c
    have := norm_nonneg R
    linarith)
  by_cases hzero : c+R*logFourierChar 1 t-w = 0
  · simpa only [hzero, norm_zero, Real.log_zero] using hB
  apply Real.log_le_log (norm_pos_iff.mpr hzero)
  calc
    ‖c+R*logFourierChar 1 t-w‖ ≤ ‖c+R*logFourierChar 1 t‖+‖w‖ := norm_sub_le _ _
    _ ≤ (‖c‖+‖R*logFourierChar 1 t‖)+‖w‖ := add_le_add_right (norm_add_le _ _) _
    _ ≤ ‖c‖+‖R‖+2 := by rw [norm_mul, logFourierChar_norm, mul_one, hw]; linarith

theorem circle_affine_log_L1_bound (c R w : ℂ) (hR : R ≠ 0) (hw : ‖w‖ = 1) :
    (∫ t, ‖Real.log ‖c+R*logFourierChar 1 t-w‖‖ ∂angularParameterMeasure) ≤
      2*Real.log (‖c‖+‖R‖+2)+|Real.log ‖R‖| := by
  let B := Real.log (‖c‖+‖R‖+2)
  let f := fun t => Real.log ‖c+R*logFourierChar 1 t-w‖
  have hB : 0 ≤ B := Real.log_nonneg (by
    have := norm_nonneg c
    have := norm_nonneg R
    linarith)
  have hfi : Integrable f angularParameterMeasure := circle_affine_log_integrable_angular c R w
  have hpoint (t : ℝ) : ‖f t‖ ≤ 2*B-f t := by
    rw [Real.norm_eq_abs]
    have hu : f t ≤ B := circle_affine_log_upper c R w hw t
    apply abs_le.mpr
    constructor <;> linarith
  calc
    _ ≤ ∫ t, (2*B-f t) ∂angularParameterMeasure :=
      integral_mono hfi.norm ((integrable_const _).sub hfi) hpoint
    _ = 2*B-Real.log (max ‖R‖ ‖c-w‖) := by
      rw [integral_sub (integrable_const _) hfi, integral_const, integral_angularParameterMeasure,
        integral_circle_affine_log]
      simp
    _ ≤ 2*B+|Real.log ‖R‖| := by
      have hlow := Real.log_le_log (norm_pos_iff.mpr hR) (le_max_left ‖R‖ ‖c-w‖)
      have habs := neg_abs_le (Real.log ‖R‖)
      linarith

theorem circle_affine_log_measurable (c R : ℂ) :
    Measurable (fun p : ℂ × ℝ => Real.log ‖c+R*logFourierChar 1 p.2-p.1‖) :=
  Real.measurable_log.comp
    (((continuous_const.add (continuous_const.mul
      ((logFourierChar_continuous 1).comp continuous_snd))).sub continuous_fst).norm.measurable)

theorem circle_affine_log_prod_integrable (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (c R : ℂ) (hR : R ≠ 0) :
    Integrable (fun p : ℂ × ℝ => Real.log ‖c+R*logFourierChar 1 p.2-p.1‖)
      (ν.prod angularParameterMeasure) := by
  have hm := (circle_affine_log_measurable c R).aestronglyMeasurable
    (μ := ν.prod angularParameterMeasure)
  apply (integrable_prod_iff hm).mpr
  constructor
  · exact Filter.Eventually.of_forall (circle_affine_log_integrable_angular c R)
  · apply (integrable_const (2*Real.log (‖c‖+‖R‖+2)+|Real.log ‖R‖|)).mono'
      hm.norm.integral_prod_right'
    filter_upwards [hc] with w hw
    rw [Real.norm_eq_abs, abs_of_nonneg (integral_nonneg (fun t => norm_nonneg _))]
    exact circle_affine_log_L1_bound c R w hR hw

theorem circle_affine_potential_integrable (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (c R : ℂ) (hR : R ≠ 0) :
    IntervalIntegrable (fun t => ∫ w, Real.log ‖c+R*logFourierChar 1 t-w‖ ∂ν)
      volume (0 : ℝ) 1 := by
  apply (intervalIntegrable_iff_integrableOn_Ioc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mpr
  exact (circle_affine_log_prod_integrable ν hc c R hR).integral_prod_right

theorem integral_circle_potential_mean (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (c R : ℂ) (hR : R ≠ 0) :
    (∫ t in (0 : ℝ)..1, ∫ w, Real.log ‖c+R*logFourierChar 1 t-w‖ ∂ν) =
      ∫ w, Real.log (max ‖R‖ ‖c-w‖) ∂ν := by
  rw [← integral_angularParameterMeasure]
  rw [← integral_integral_swap (circle_affine_log_prod_integrable ν hc c R hR)]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall fun w =>
    (integral_angularParameterMeasure (fun t => Real.log ‖c+R*logFourierChar 1 t-w‖)).trans
      (integral_circle_affine_log c R w)

end UAMO.CircleDOS

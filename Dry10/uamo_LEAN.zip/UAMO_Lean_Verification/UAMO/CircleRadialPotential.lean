import UAMO.CircleLogOffCircle

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology

def radialPoint (z : ℂ) (δ : ℝ) : ℂ := ((1+δ : ℝ) : ℂ)*z

theorem radialPoint_norm (z : ℂ) (hz : ‖z‖ = 1) {δ : ℝ} (hδ : 0 ≤ δ) :
    ‖radialPoint z δ‖ = 1+δ := by
  simp only [radialPoint, norm_mul, Complex.norm_real, Real.norm_eq_abs, hz, mul_one]
  exact abs_of_nonneg (by linarith)

theorem radialPoint_off_circle (z : ℂ) (hz : ‖z‖ = 1) {δ : ℝ} (hδ : 0 < δ) :
    ‖radialPoint z δ‖ ≠ 1 := by
  rw [radialPoint_norm z hz hδ.le]
  linarith

theorem circle_radial_distance_sq (z w : ℂ) (hz : ‖z‖ = 1) (hw : ‖w‖ = 1) (δ : ℝ) :
    ‖radialPoint z δ-w‖^2 = δ^2+(1+δ)*‖z-w‖^2 := by
  have hz' : z.re^2+z.im^2 = 1 := by
    calc
      _ = Complex.normSq z := by simp [Complex.normSq_apply, pow_two]
      _ = ‖z‖^2 := Complex.normSq_eq_norm_sq z
      _ = 1 := by rw [hz]; norm_num
  have hw' : w.re^2+w.im^2 = 1 := by
    calc
      _ = Complex.normSq w := by simp [Complex.normSq_apply, pow_two]
      _ = ‖w‖^2 := Complex.normSq_eq_norm_sq w
      _ = 1 := by rw [hw]; norm_num
  simp only [← Complex.normSq_eq_norm_sq, Complex.normSq_apply, radialPoint,
    Complex.sub_re, Complex.sub_im, Complex.mul_re, Complex.mul_im, Complex.ofReal_re,
    Complex.ofReal_im, zero_mul, sub_zero, zero_add]
  linear_combination (δ+δ^2)*hz' - δ*hw'

theorem circle_radial_distance_bounds (z w : ℂ) (hz : ‖z‖ = 1) (hw : ‖w‖ = 1)
    {δ : ℝ} (hδ : 0 < δ) (hδ1 : δ ≤ 1/2) :
    ‖z-w‖+δ^2 ≤ ‖radialPoint z δ-w‖ ∧ ‖radialPoint z δ-w‖ ≤ ‖z-w‖+δ := by
  have he := circle_radial_distance_sq z w hz hw δ
  have hd := norm_nonneg (z-w)
  have hr := norm_nonneg (radialPoint z δ-w)
  have hsmall : 0 ≤ 1-δ-δ^2 := by nlinarith
  have hsq : 0 ≤ δ*(‖z-w‖-δ)^2 + δ^2*(1-δ-δ^2) :=
    add_nonneg (mul_nonneg hδ.le (sq_nonneg _)) (mul_nonneg (sq_nonneg _) hsmall)
  have hl : (‖z-w‖+δ^2)^2 ≤ ‖radialPoint z δ-w‖^2 := by nlinarith
  refine ⟨by nlinarith [sq_nonneg (‖z-w‖+δ^2-‖radialPoint z δ-w‖)], ?_⟩
  have heq : radialPoint z δ-w = (z-w)+(δ : ℂ)*z := by unfold radialPoint; push_cast; ring
  rw [heq]
  have hn := norm_add_le (z-w) ((δ : ℂ)*z)
  simpa only [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hδ, hz, mul_one] using hn

theorem circle_radial_potential_bounds (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) (hz : ‖z‖ = 1)
    {δ : ℝ} (hδ : 0 < δ) (hδ1 : δ ≤ 1/2) :
    circleRegularizedPotential ν z (δ^2) ≤ (∫ w, Real.log ‖radialPoint z δ-w‖ ∂ν) ∧
      (∫ w, Real.log ‖radialPoint z δ-w‖ ∂ν) ≤ circleRegularizedPotential ν z δ := by
  have hi := circle_log_distance_integrable ν hc (radialPoint z δ) (radialPoint_off_circle z hz hδ)
  constructor
  · apply integral_mono_ae (regularized_circle_integrable ν hc z (sq_pos_of_pos hδ)) hi
    filter_upwards [hc] with w hw
    exact Real.log_le_log (by positivity) (circle_radial_distance_bounds z w hz hw hδ hδ1).1
  · apply integral_mono_ae hi (regularized_circle_integrable ν hc z hδ)
    filter_upwards [hc] with w hw
    have hb := circle_radial_distance_bounds z w hz hw hδ hδ1
    exact Real.log_le_log ((by positivity : 0 < ‖z-w‖+δ^2).trans_le hb.1) hb.2

theorem circle_radial_potential_tendsto (ν : Measure ℂ) [IsFiniteMeasure ν]
    (hc : ∀ᵐ w ∂ν, ‖w‖ = 1) (z : ℂ) (hz : ‖z‖ = 1)
    (δ : ℕ → ℝ) (hδ : ∀ n, 0 < δ n) (hlim : Tendsto δ atTop (𝓝 0)) :
    Tendsto (fun n => ((∫ w, Real.log ‖radialPoint z (δ n)-w‖ ∂ν : ℝ) : EReal))
      atTop (𝓝 (circleTotalPotential ν z)) := by
  have hF := circleRegularizedPotential_monotone ν hc z
  have hU := tendsto_regularization_inf _ hF δ hδ hlim
  have hL := tendsto_regularization_inf _ hF (fun n => δ n^2)
    (fun n => sq_pos_of_pos (hδ n)) (by simpa using hlim.pow 2)
  have he : ∀ᶠ n in atTop, δ n ≤ 1/2 :=
    (hlim.eventually (gt_mem_nhds (by norm_num : (0 : ℝ) < 1/2))).mono (fun n hn => hn.le)
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hL hU
  · filter_upwards [he] with n hn
    exact EReal.coe_le_coe_iff.mpr (circle_radial_potential_bounds ν hc z hz (hδ n) hn).1
  · filter_upwards [he] with n hn
    exact EReal.coe_le_coe_iff.mpr (circle_radial_potential_bounds ν hc z hz (hδ n) hn).2

theorem radialPoint_tendsto (z : ℂ) (δ : ℕ → ℝ) (hlim : Tendsto δ atTop (𝓝 0)) :
    Tendsto (fun n => radialPoint z (δ n)) atTop (𝓝 z) := by
  have h := (Complex.continuous_ofReal.continuousAt.tendsto.comp
    (hlim.const_add 1)).mul_const z
  simpa only [radialPoint, add_zero, Complex.ofReal_one, one_mul] using h

end UAMO.CircleDOS

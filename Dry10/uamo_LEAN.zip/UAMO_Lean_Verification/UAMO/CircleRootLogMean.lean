import UAMO.CMVSingularHopping
import Mathlib.Analysis.Complex.Polynomial.Basic

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set
open scoped ComplexConjugate

theorem logFourierChar_one_add (s t : ℝ) :
    logFourierChar 1 (s+t) = logFourierChar 1 s * logFourierChar 1 t := by
  simp [logFourierChar, mul_add, Complex.exp_add]

theorem logFourierChar_one_periodic : Function.Periodic (logFourierChar 1) 1 := by
  intro t
  rw [logFourierChar_one_add]
  simp [logFourierChar]

theorem logFourierChar_one_sub_one_norm (t : ℝ) :
    ‖logFourierChar 1 t - 1‖ = 2*|Real.sin (Real.pi*t)| := by
  apply (sq_eq_sq₀ (norm_nonneg _) (by positivity)).mp
  rw [CMV.logFourierChar_one_trig, Complex.sq_norm]
  simp only [Complex.normSq_apply, Complex.sub_re, Complex.sub_im, Complex.add_re,
    Complex.add_im, Complex.mul_re, Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im,
    Complex.I_re, Complex.I_im, Complex.one_re, Complex.one_im]
  simp only [mul_zero, zero_mul, add_zero, zero_add, sub_zero, mul_one, mul_pow,
    sq_abs]
  have hc := Real.cos_two_mul (Real.pi*t)
  have hs := Real.sin_sq_add_cos_sq (2*Real.pi*t)
  rw [show 2*(Real.pi*t) = 2*Real.pi*t by ring] at hc
  nlinarith [Real.sin_sq_add_cos_sq (Real.pi*t)]

theorem sin_pi_mul_ne_zero_ae : ∀ᵐ t : ℝ ∂volume, Real.sin (Real.pi*t) ≠ 0 := by
  filter_upwards [(countable_range (fun k : ℤ => (k : ℝ))).ae_not_mem volume] with t ht
  intro h
  obtain ⟨k,hk⟩ := Real.sin_eq_zero_iff.mp h
  apply ht
  refine ⟨k, ?_⟩
  nlinarith [Real.pi_pos]

theorem logFourierChar_one_sub_one_log_ae :
    (fun t => Real.log ‖logFourierChar 1 t - 1‖) =ᵐ[volume]
      (fun t => Real.log 2 + Real.log (Real.sin (Real.pi*t))) := by
  filter_upwards [sin_pi_mul_ne_zero_ae] with t ht
  rw [logFourierChar_one_sub_one_norm, Real.log_mul (by norm_num) (abs_ne_zero.mpr ht),
    Real.log_abs]

theorem logFourierChar_one_sub_one_integrable (a b : ℝ) :
    IntervalIntegrable (fun t => Real.log ‖logFourierChar 1 t - 1‖) volume a b := by
  have hi : IntervalIntegrable (fun t => Real.log (Real.sin (Real.pi*t))) volume a b := by
    simpa only [mul_div_cancel_left₀ _ Real.pi_ne_zero] using
      (CMV.log_sin_intervalIntegrable (Real.pi*a) (Real.pi*b)).comp_mul_left Real.pi
  exact (intervalIntegrable_const.add hi).congr (ae_restrict_of_ae logFourierChar_one_sub_one_log_ae.symm)

theorem integral_logFourierChar_one_sub_one :
    (∫ t in (0 : ℝ)..1, Real.log ‖logFourierChar 1 t - 1‖) = 0 := by
  have hi : IntervalIntegrable (fun t => Real.log (Real.sin (Real.pi*t))) volume 0 1 := by
    simpa only [zero_div, div_self Real.pi_ne_zero] using
      (CMV.log_sin_intervalIntegrable 0 Real.pi).comp_mul_left Real.pi
  rw [intervalIntegral.integral_congr_ae_restrict (ae_restrict_of_ae logFourierChar_one_sub_one_log_ae),
    intervalIntegral.integral_add intervalIntegrable_const hi,
    intervalIntegral.integral_const,
    intervalIntegral.integral_comp_mul_left (fun x => Real.log (Real.sin x)) Real.pi_ne_zero]
  simp only [mul_zero, mul_one, sub_zero, smul_eq_mul, one_mul, CMV.log_sin_integral_zero_pi]
  field_simp
  ring

theorem exists_logFourierChar_eq {a : ℂ} (ha : ‖a‖ = 1) :
    ∃ t : ℝ, logFourierChar 1 t = a := by
  obtain ⟨θ,hθ⟩ := (Complex.norm_eq_one_iff a).mp ha
  refine ⟨θ/(2*Real.pi), ?_⟩
  rw [← hθ]
  unfold logFourierChar
  congr 1
  push_cast
  field_simp [Real.pi_ne_zero]
  ring

theorem logFourierChar_distance_shift (s t : ℝ) :
    ‖logFourierChar 1 t - logFourierChar 1 s‖ = ‖logFourierChar 1 (t-s)-1‖ := by
  have h : logFourierChar 1 t - logFourierChar 1 s =
      logFourierChar 1 s * (logFourierChar 1 (t-s)-1) := by
    rw [mul_sub, ← logFourierChar_one_add]
    simp
  rw [h, norm_mul, logFourierChar_norm, one_mul]

theorem logFourierChar_root_boundary_integrable {a : ℂ} (ha : ‖a‖ = 1) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖logFourierChar 1 x - a‖) volume s t := by
  obtain ⟨u,rfl⟩ := exists_logFourierChar_eq ha
  simp_rw [logFourierChar_distance_shift]
  simpa only [sub_add_cancel] using
    (logFourierChar_one_sub_one_integrable (s-u) (t-u)).comp_sub_right u

theorem integral_logFourierChar_root_boundary {a : ℂ} (ha : ‖a‖ = 1) :
    (∫ t in (0 : ℝ)..1, Real.log ‖logFourierChar 1 t-a‖) = 0 := by
  obtain ⟨s,rfl⟩ := exists_logFourierChar_eq ha
  simp_rw [logFourierChar_distance_shift]
  rw [intervalIntegral.integral_comp_sub_right (fun t => Real.log ‖logFourierChar 1 t-1‖) s]
  have hp : Function.Periodic (fun t => Real.log ‖logFourierChar 1 t-1‖) 1 := by
    intro t
    dsimp only
    rw [logFourierChar_one_periodic]
  have he := hp.intervalIntegral_add_eq (-s) 0
  simp only [zero_add] at he
  rw [zero_sub, show 1-s = -s+1 by ring, he, integral_logFourierChar_one_sub_one]

theorem logFourierChar_root_ne_zero {a : ℂ} (ha : ‖a‖ ≠ 1) (t : ℝ) :
    logFourierChar 1 t-a ≠ 0 := by
  intro h
  apply ha
  have hn := congrArg norm (sub_eq_zero.mp h)
  simpa only [logFourierChar_norm] using hn.symm

theorem logFourierChar_root_ne_zero_ae (a : ℂ) :
    ∀ᵐ t : ℝ ∂volume, logFourierChar 1 t-a ≠ 0 := by
  by_cases ha : ‖a‖ = 1
  · obtain ⟨s,rfl⟩ := exists_logFourierChar_eq ha
    filter_upwards [(quasiMeasurePreserving_add_right volume (-s)).ae
      sin_pi_mul_ne_zero_ae] with t ht
    apply norm_ne_zero_iff.mp
    rw [logFourierChar_distance_shift, logFourierChar_one_sub_one_norm]
    exact mul_ne_zero (by norm_num) (abs_ne_zero.mpr (by simpa only [sub_eq_add_neg] using ht))
  · exact Filter.Eventually.of_forall (logFourierChar_root_ne_zero ha)

theorem logFourierChar_root_inside_norm (a : ℂ) (t : ℝ) :
    ‖logFourierChar 1 t-a‖ = ‖1-conj a*logFourierChar 1 t‖ := by
  have hm : logFourierChar 1 t * logFourierChar (-1) t = 1 := by
    rw [← logFourierChar_add]
    simp
  calc
    _ = ‖conj (logFourierChar 1 t-a)‖ := (Complex.norm_conj _).symm
    _ = ‖logFourierChar 1 t*conj (logFourierChar 1 t-a)‖ := by
      rw [norm_mul, logFourierChar_norm, one_mul]
    _ = _ := by
      congr 1
      simp only [map_sub, logFourierChar_conj, mul_sub, hm]
      ring

theorem logFourierChar_root_integrable (a : ℂ) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖logFourierChar 1 x-a‖) volume s t := by
  by_cases ha : ‖a‖ = 1
  · exact logFourierChar_root_boundary_integrable ha s t
  · exact (((logFourierChar_continuous 1).sub continuous_const).norm.log
      (fun t => norm_ne_zero_iff.mpr (logFourierChar_root_ne_zero ha t))).intervalIntegrable
        (μ := volume) s t

theorem integral_logFourierChar_root (a : ℂ) :
    (∫ t in (0 : ℝ)..1, Real.log ‖logFourierChar 1 t-a‖) = Real.log (max 1 ‖a‖) := by
  rcases lt_trichotomy ‖a‖ 1 with ha | ha | ha
  · simp_rw [logFourierChar_root_inside_norm]
    rw [integral_log_norm_one_sub (by simpa using ha), max_eq_left ha.le, Real.log_one]
  · rw [integral_logFourierChar_root_boundary ha, ha, max_self, Real.log_one]
  · have ha0 : a ≠ 0 := by intro h; norm_num [h] at ha
    have hi : ‖a⁻¹‖ < 1 := by rw [norm_inv]; exact inv_lt_one_of_one_lt₀ ha
    have hc := CMV.continuous_log_norm_one_sub hi
    have he (t : ℝ) : Real.log ‖logFourierChar 1 t-a‖ =
        Real.log ‖a‖ + Real.log ‖1-a⁻¹*logFourierChar 1 t‖ := by
      have hf : logFourierChar 1 t-a = -a*(1-a⁻¹*logFourierChar 1 t) := by field_simp; ring
      rw [hf, norm_mul, norm_neg, Real.log_mul (norm_ne_zero_iff.mpr ha0)
        (norm_ne_zero_iff.mpr (CMV.one_sub_logFourierChar_ne_zero hi t))]
    simp_rw [he]
    rw [intervalIntegral.integral_add intervalIntegrable_const
      (hc.intervalIntegrable (μ := volume) 0 1), integral_log_norm_one_sub hi,
      max_eq_right ha.le]
    simp

end UAMO.CircleDOS

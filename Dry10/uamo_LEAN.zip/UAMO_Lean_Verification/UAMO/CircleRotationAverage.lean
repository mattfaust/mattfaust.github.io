import UAMO.CircleMomentConvergence
import UAMO.FreePhysicalDOS
import UAMO.SeedCoefficient
import Mathlib.Algebra.GeomSum

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology

local instance rotationMeasurableCircle : MeasurableSpace Circle := borel Circle
local instance rotationBorelCircle : BorelSpace Circle := ⟨rfl⟩

def circleRotationAverage (q : Circle) (n : ℕ) (x : Circle) : C(Circle, ℂ) →L[ℂ] ℂ :=
  (n : ℂ)⁻¹ • ∑ j ∈ Finset.range n, ContinuousMap.evalCLM ℂ (q^j * x)

theorem circleRotationAverage_apply (q : Circle) (n : ℕ) (x : Circle)
    (f : C(Circle, ℂ)) :
    circleRotationAverage q n x f = (n : ℂ)⁻¹ * ∑ j ∈ Finset.range n, f (q^j * x) := by
  simp [circleRotationAverage]

theorem circleRotationAverage_bound (q : Circle) (n : ℕ) (x : Circle)
    (f : C(Circle, ℂ)) : ‖circleRotationAverage q n x f‖ ≤ ‖f‖ := by
  by_cases hn : n = 0
  · simp [hn, circleRotationAverage_apply]
  rw [circleRotationAverage_apply, norm_mul, norm_inv, Complex.norm_natCast]
  calc
    (n : ℝ)⁻¹ * ‖∑ j ∈ Finset.range n, f (q^j * x)‖ ≤
        (n : ℝ)⁻¹ * ∑ j ∈ Finset.range n, ‖f (q^j * x)‖ := by
      gcongr
      exact norm_sum_le _ _
    _ ≤ (n : ℝ)⁻¹ * ∑ _j ∈ Finset.range n, ‖f‖ := by
      gcongr with j _
      exact ContinuousMap.norm_coe_le_norm f _
    _ = ‖f‖ := by simp [hn, Nat.cast_ne_zero]

theorem circleRotationAverage_star (q : Circle) (n : ℕ) (x : Circle)
    (f : C(Circle, ℂ)) :
    circleRotationAverage q n x (star f) = star (circleRotationAverage q n x f) := by
  simp [circleRotationAverage_apply]

theorem circleRotationAverage_character (q : Circle) (n k : ℕ) (x : Circle) :
    circleRotationAverage q n x (circleCharacter k) =
      (n : ℂ)⁻¹ * (∑ j ∈ Finset.range n, ((q : ℂ)^k)^j) * (x : ℂ)^k := by
  rw [circleRotationAverage_apply]
  simp only [circleCharacter, ContinuousMap.coe_mk, zpow_natCast, Circle.coe_mul,
    SubmonoidClass.coe_pow, mul_pow, ← Finset.sum_mul, mul_assoc]
  congr 2
  apply Finset.sum_congr rfl
  intro j _
  rw [show ((q^j : Circle) : ℂ) = (q : ℂ)^j from map_pow Circle.coeHom q j]
  rw [← pow_mul, ← pow_mul, Nat.mul_comm j k]

theorem norm_geometric_sum_unit_le {z : ℂ} (hz : ‖z‖ = 1) (hz1 : z ≠ 1) (n : ℕ) :
    ‖∑ j ∈ Finset.range n, z^j‖ ≤ 2 / ‖z - 1‖ := by
  rw [geom_sum_eq hz1, norm_div]
  apply div_le_div_of_nonneg_right _ (norm_nonneg _)
  calc
    ‖z^n - 1‖ ≤ ‖z^n‖ + ‖(1 : ℂ)‖ := norm_sub_le _ _
    _ = 2 := by rw [norm_pow, hz, one_pow, norm_one]; norm_num

theorem circleRotationAverage_character_tendsto (q : Circle)
    (hq : ∀ k : ℕ, k ≠ 0 → (q : ℂ)^k ≠ 1) (k : ℕ) :
    Tendsto (fun p : ℕ × Circle => circleRotationAverage q p.1 p.2 (circleCharacter k))
      (atTop ×ˢ (⊤ : Filter Circle)) (𝓝 (if k = 0 then 1 else 0)) := by
  by_cases hk : k = 0
  · subst k
    apply tendsto_const_nhds.congr'
    filter_upwards [tendsto_fst.eventually (eventually_ne_atTop 0)] with p hp
    simp [circleRotationAverage_apply, circleCharacter, hp, Nat.cast_ne_zero]
  rw [if_neg hk]
  have hlim : Tendsto (fun p : ℕ × Circle =>
      (2 / ‖(q : ℂ)^k - 1‖) / (p.1 : ℝ))
      (atTop ×ˢ (⊤ : Filter Circle)) (𝓝 0) :=
    (tendsto_const_nhds.div_atTop tendsto_natCast_atTop_atTop).comp tendsto_fst
  apply squeeze_zero_norm (fun p => ?_) hlim
  rw [circleRotationAverage_character, norm_mul, norm_mul, norm_inv,
    Complex.norm_natCast, norm_pow, p.2.norm_coe, one_pow, mul_one]
  rw [div_eq_inv_mul]
  gcongr
  exact norm_geometric_sum_unit_le (by rw [norm_pow, q.norm_coe, one_pow]) (hq k hk) p.1

def circleRotationMean : C(Circle, ℂ) →L[ℂ] ℂ :=
  @circleIntegralCLM (circleComap uniformCircleMeasure)
    (circleComap_probability _ uniformCircleMeasure_ae_circle)

theorem circleRotationMean_bound (f : C(Circle, ℂ)) : ‖circleRotationMean f‖ ≤ ‖f‖ := by
  letI := circleComap_probability _ uniformCircleMeasure_ae_circle
  exact circleIntegralCLM_bound _ f

theorem circleRotationMean_character (k : ℕ) :
    circleRotationMean (circleCharacter k) = if k = 0 then 1 else 0 := by
  change (∫ z : Circle, (z : ℂ)^(k : ℤ) ∂circleComap uniformCircleMeasure) = _
  simp only [zpow_natCast]
  rw [circleComap_integral _ uniformCircleMeasure_ae_circle (fun z : ℂ => z^k),
    uniformCircleMeasure_moments]

theorem circleRotationMean_star (f : C(Circle, ℂ)) :
    circleRotationMean (star f) = star (circleRotationMean f) := by
  change (∫ z, star (f z) ∂circleComap uniformCircleMeasure) =
    star (∫ z, f z ∂circleComap uniformCircleMeasure)
  simpa only [Complex.star_def] using (integral_conj (f := fun z : Circle => f z)
    (μ := circleComap uniformCircleMeasure))

theorem circleRotationAverage_tendsto (q : Circle)
    (hq : ∀ k : ℕ, k ≠ 0 → (q : ℂ)^k ≠ 1) (f : C(Circle, ℂ)) :
    Tendsto (fun p : ℕ × Circle => circleRotationAverage q p.1 p.2 f)
      (atTop ×ˢ (⊤ : Filter Circle)) (𝓝 (circleRotationMean f)) := by
  apply circleFunctional_tendsto_of_nat_characters_filter _
    (fun p : ℕ × Circle => circleRotationAverage q p.1 p.2) circleRotationMean
    (fun p => circleRotationAverage_bound q p.1 p.2) circleRotationMean_bound
    (fun p => circleRotationAverage_star q p.1 p.2) circleRotationMean_star _ f
  intro k
  rw [circleRotationMean_character]
  exact circleRotationAverage_character_tendsto q hq k

theorem circleRotationAverage_irrational_tendsto {α : ℝ} (hα : Irrational α)
    (f : C(Circle, ℂ)) :
    Tendsto (fun p : ℕ × Circle => circleRotationAverage (Circle.exp (2 * Real.pi * α))
      p.1 p.2 f) (atTop ×ˢ (⊤ : Filter Circle)) (𝓝 (circleRotationMean f)) := by
  apply circleRotationAverage_tendsto _ _ f
  intro k hk
  have h := weylPhase_noIntegerResonance hα (k : ℤ) (by exact_mod_cast hk)
  simpa only [weylPhase, Circle.coe_exp, zpow_natCast] using h

end UAMO.CircleDOS

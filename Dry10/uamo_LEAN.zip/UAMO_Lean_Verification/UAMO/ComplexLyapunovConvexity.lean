import UAMO.PhaseQuadrature
import UAMO.UAMOSpectralFiniteThreeLines
import UAMO.UAMOSpectralComplexAsymptotic
import Mathlib.Analysis.Convex.Function

noncomputable section
namespace UAMO.CMV
open Matrix Set Filter MeasureTheory UAMO.ComplexGrowth
open scoped Topology BigOperators Matrix.L2OpNorm

theorem continuous_complexifiedTransferLogNorm_of_nonzero (a r : ℝ) (z : ℂ)
    (ω y : ℝ) (n : ℕ)
    (hne : ∀x, transferProduct (complexifiedPhaseTransfer a r z y) ω x n ≠ 0) :
    Continuous (fun x => transferLogNorm (complexifiedPhaseTransfer a r z y) ω x n) := by
  exact (continuous_transferNorm.comp (continuous_transferProduct _
    (continuous_complexifiedPhaseTransfer a r z y) ω n)).log
      (fun x => by
        change ‖transferProduct (complexifiedPhaseTransfer a r z y) ω x n‖≠0
        exact norm_ne_zero_iff.mpr (hne x))

theorem complexifiedTransferLogNorm_periodic (a r : ℝ) (z : ℂ) (ω y : ℝ) (n : ℕ) :
    Function.Periodic (fun x => transferLogNorm (complexifiedPhaseTransfer a r z y) ω x n)
      (2*Real.pi) := by
  intro x
  unfold transferLogNorm
  exact congrArg (fun M => Real.log (transferNorm M))
    (transferProduct_periodic _ (complexifiedPhaseTransfer_periodic a r z y) ω n x)

theorem complexifiedTransferLogAverage_interpolate (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ)
    {l u y : ℝ} (hul : l<u) (hy : y∈Icc l u)
    (hl : ∀x, transferProduct (complexifiedPhaseTransfer a r z l) ω x n ≠ 0)
    (hu : ∀x, transferProduct (complexifiedPhaseTransfer a r z u) ω x n ≠ 0)
    (hc : ∀x, transferProduct (complexifiedPhaseTransfer a r z y) ω x n ≠ 0) :
    transferLogAverage (complexifiedPhaseTransfer a r z y) ω n ≤
      (1-(y-l)/(u-l))*transferLogAverage (complexifiedPhaseTransfer a r z l) ω n +
      ((y-l)/(u-l))*transferLogAverage (complexifiedPhaseTransfer a r z u) ω n := by
  let f : ℝ→ℝ→ℝ := fun h x => transferLogNorm (complexifiedPhaseTransfer a r z h) ω x n
  have hcl := continuous_complexifiedTransferLogNorm_of_nonzero a r z ω l n hl
  have hcu := continuous_complexifiedTransferLogNorm_of_nonzero a r z ω u n hu
  have hcc := continuous_complexifiedTransferLogNorm_of_nonzero a r z ω y n hc
  have hpl := complexifiedTransferLogNorm_periodic a r z ω l n
  have hpu := complexifiedTransferLogNorm_periodic a r z ω u n
  have hpc := complexifiedTransferLogNorm_periodic a r z ω y n
  have hT : 0<2*Real.pi := by positivity
  apply le_of_forall_pos_le_add
  intro ε hε
  have hlq := phaseSampleMean_eventually_uniform hcl hT hpl hε
  have huq := phaseSampleMean_eventually_uniform hcu hT hpu hε
  have hlim := phaseSampleMean_tendsto hcc hT hpc 0
  apply le_of_tendsto hlim
  filter_upwards [hlq,huq,eventually_ge_atTop (1:ℕ)] with N hlN huN hN
  have hNr : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  let phase : ℕ→ℝ := fun j => (j:ℝ)*((2*Real.pi)/N)
  have hleft : ∀x : ℝ, ∑j∈Finset.range N, f l (phase j+x) ≤
      (N:ℝ)*(transferLogAverage (complexifiedPhaseTransfer a r z l) ω n+ε) := by
    intro x
    have h := (abs_lt.mp (hlN x)).2
    have he : (∑j∈Finset.range N, f l (phase j+x))/(N:ℝ) ≤
        transferLogAverage (complexifiedPhaseTransfer a r z l) ω n+ε := by
      change (∑j∈Finset.range N, f l (phase j+x))/(N:ℝ) ≤ _
      simpa only [phaseSampleMean,phaseIntegralMean,transferLogAverage,phase,f,add_comm] using
        (show phaseSampleMean (f l) (2*Real.pi) N x ≤
          phaseIntegralMean (f l) (2*Real.pi)+ε by linarith)
    simpa only [mul_comm] using (div_le_iff₀ hNr).mp he
  have hright : ∀x : ℝ, ∑j∈Finset.range N, f u (phase j+x) ≤
      (N:ℝ)*(transferLogAverage (complexifiedPhaseTransfer a r z u) ω n+ε) := by
    intro x
    have h := (abs_lt.mp (huN x)).2
    have he : (∑j∈Finset.range N, f u (phase j+x))/(N:ℝ) ≤
        transferLogAverage (complexifiedPhaseTransfer a r z u) ω n+ε := by
      simpa only [phaseSampleMean,phaseIntegralMean,transferLogAverage,phase,f,add_comm] using
        (show phaseSampleMean (f u) (2*Real.pi) N x ≤
          phaseIntegralMean (f u) (2*Real.pi)+ε by linarith)
    simpa only [mul_comm] using (div_le_iff₀ hNr).mp he
  have h := complexifiedTransfer_finite_log_three_lines (Finset.range N) phase a r z ω n
    hul hy (fun j _ => hc (phase j)) hleft hright
  change phaseSampleMean (f y) (2*Real.pi) N 0 ≤ _
  simp only [phaseSampleMean,zero_add]
  apply (div_le_iff₀ hNr).mpr
  change (∑j∈Finset.range N, f y (phase j)) ≤ _
  nlinarith [h]

theorem convexOn_complexifiedTransferLogAverage (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ)
    {S : Set ℝ} (hS : Convex ℝ S)
    (hne : ∀y∈S, ∀x, transferProduct (complexifiedPhaseTransfer a r z y) ω x n ≠ 0) :
    ConvexOn ℝ S (fun y => transferLogAverage (complexifiedPhaseTransfer a r z y) ω n) := by
  apply LinearOrder.convexOn_of_lt hS
  intro l hl u hu hlu b c hb hc hbc
  have hy : b*l+c*u∈Icc l u := by
    simpa only [smul_eq_mul] using (convex_Icc l u)
      (show l∈Icc l u from ⟨le_rfl,hlu.le⟩)
      (show u∈Icc l u from ⟨hlu.le,le_rfl⟩) hb.le hc.le hbc
  have hmem : b*l+c*u∈S := by simpa only [smul_eq_mul] using hS hl hu hb.le hc.le hbc
  have h := complexifiedTransferLogAverage_interpolate a r z ω n hlu hy
    (hne l hl) (hne u hu) (hne _ hmem)
  have he : (b*l+c*u-l)/(u-l)=c := by
    apply (div_eq_iff (sub_ne_zero.mpr hlu.ne')).mpr
    nlinarith [congrArg (fun t : ℝ => t*l) hbc]
  rw [he,show 1-c=b by linarith] at h
  simpa only [smul_eq_mul] using h

theorem convexOn_complexifiedFiniteLyapunov (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ)
    {S : Set ℝ} (hS : Convex ℝ S)
    (hne : ∀y∈S, ∀x, transferProduct (complexifiedPhaseTransfer a r z y) ω x n ≠ 0) :
    ConvexOn ℝ S (fun y => finiteLyapunov (complexifiedPhaseTransfer a r z y) ω n) := by
  have h := (convexOn_complexifiedTransferLogAverage a r z ω n hS hne).smul
    (by positivity : 0≤(n:ℝ)⁻¹)
  simpa only [smul_eq_mul,finiteLyapunov,div_eq_mul_inv,mul_comm] using h

end UAMO.CMV

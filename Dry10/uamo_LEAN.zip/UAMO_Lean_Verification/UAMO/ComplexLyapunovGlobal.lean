import UAMO.ComplexTransferNonvanishing

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem complexifiedTransferLogAverage_subadditive_of_nonzero (a r : ℝ) (z : ℂ)
    (ω y : ℝ)
    (hne : ∀x n, transferProduct (complexifiedPhaseTransfer a r z y) ω x n≠0) :
    Subadditive (transferLogAverage (complexifiedPhaseTransfer a r z y) ω) := by
  let A := complexifiedPhaseTransfer a r z y
  have hpos (x : ℝ) (n : ℕ) : 0<transferNorm (transferProduct A ω x n) :=
    (show 0<‖transferProduct A ω x n‖ from norm_pos_iff.mpr (hne x n))
  have hc (n : ℕ) : Continuous (fun x => transferLogNorm A ω x n) :=
    continuous_complexifiedTransferLogNorm_of_nonzero a r z ω y n (fun x => hne x n)
  have hpoint (x : ℝ) (m n : ℕ) : transferLogNorm A ω x (m+n) ≤
      transferLogNorm A ω (x+n*ω) m+transferLogNorm A ω x n := by
    unfold transferLogNorm
    calc
      _ ≤ Real.log (transferNorm (transferProduct A ω (x+n*ω) m)*
          transferNorm (transferProduct A ω x n)) := by
        apply Real.log_le_log (hpos x (m+n))
        rw [transferProduct_add]
        exact transferNorm_mul_le _ _
      _ = _ := Real.log_mul (hpos _ m).ne' (hpos x n).ne'
  intro m n
  unfold transferLogAverage
  rw [← add_div]
  apply div_le_div_of_nonneg_right _ (by positivity)
  have hm : IntervalIntegrable (fun x => transferLogNorm A ω (x+n*ω) m)
      volume 0 (2*Real.pi) := ((hc m).comp (continuous_id.add continuous_const)).intervalIntegrable _ _
  have hn := (hc n).intervalIntegrable (μ:=volume) 0 (2*Real.pi)
  calc
    _ ≤ ∫x in (0:ℝ)..2*Real.pi, (transferLogNorm A ω (x+n*ω) m+transferLogNorm A ω x n) :=
      intervalIntegral.integral_mono (by positivity) ((hc (m+n)).intervalIntegrable _ _)
        (hm.add hn) (fun x => hpoint x m n)
    _ = (∫x in (0:ℝ)..2*Real.pi, transferLogNorm A ω (x+n*ω) m)+
        ∫x in (0:ℝ)..2*Real.pi, transferLogNorm A ω x n := intervalIntegral.integral_add hm hn
    _ = _ := by rw [transferLogNorm_integral_shift A (complexifiedPhaseTransfer_periodic a r z y)]

theorem complexifiedTransfer_even_average_lower_of_nonzero {a r : ℝ} (ha : 0<a) (hr : 0<r)
    (ω : ℝ) (z : ℂ) (y : ℝ)
    (hne : ∀x n, transferProduct (complexifiedPhaseTransfer a r z y) ω x n≠0) (n : ℕ) :
    (2*n : ℕ)*(y+Real.log (r/a)) ≤
      Real.log 2 + transferLogAverage (complexifiedPhaseTransfer a r z y) ω (2*n) := by
  let P := clearedTracePolynomial a r z ω (2*n)
  let Q := P.comp (C (Real.exp (-y) : ℂ)*X)
  have hQ0 : Q.eval 0 = P.eval 0 := by simp [Q]
  have hP0 : P.eval 0 ≠ 0 := clearedTracePolynomial_even_zero_ne ha hr z ω n
  have hQne : Q ≠ 0 := by intro h; have := hQ0; rw [h] at this; simp at this; exact hP0 this.symm
  have hQ0ne : Q.eval 0 ≠ 0 := hQ0.trans_ne hP0
  have hlow : (2*n : ℕ)*Real.log (r/a) ≤ Real.log ‖Q.eval 0‖ := by
    rw [hQ0]
    have h := Real.log_le_log (pow_pos (div_pos hr ha) (2*n))
      (clearedTracePolynomial_even_zero_lower ha hr z ω n)
    simpa only [Real.log_pow] using h
  have hJ := polynomial_phase_log_jensen Q hQ0ne
  have hqi := polynomial_phase_log_integrable Q hQne 0 (2*Real.pi)
  have hai := (continuous_complexifiedTransferLogNorm_of_nonzero a r z ω y (2*n) (fun x => hne x (2*n))).intervalIntegrable (μ := volume) 0 (2*Real.pi)
  have hle : (fun x => Real.log ‖Q.eval (spectralPhase x)‖) ≤ᵐ[volume]
      (fun x => -(2*n : ℕ)*y+Real.log 2+
        transferLogNorm (complexifiedPhaseTransfer a r z y) ω x (2*n)) := by
    filter_upwards [polynomial_eval_phase_ne_zero_ae Q hQne] with x hx
    have he : Q.eval (spectralPhase x) =
        Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I)^(2*n) *
          (transferProduct (complexifiedPhaseTransfer a r z y) ω x (2*n)).trace := by
      simpa only [Q, Polynomial.eval_comp, Polynomial.eval_mul, Polynomial.eval_C,
        Polynomial.eval_X, ← complexified_phase_eq_scaled, P, complexifiedPhaseTransfer]
        using clearedTracePolynomial_eval_vertical a r z ω x y (2*n)
    have hn : 0<transferNorm (transferProduct (complexifiedPhaseTransfer a r z y) ω x (2*n)) :=
      (show 0<‖transferProduct (complexifiedPhaseTransfer a r z y) ω x (2*n)‖ from norm_pos_iff.mpr (hne x (2*n)))
    have hb : ‖Q.eval (spectralPhase x)‖ ≤
        (Real.exp (-y))^(2*n)*(2*transferNorm (transferProduct
          (complexifiedPhaseTransfer a r z y) ω x (2*n))) := by
      rw [he,norm_mul,norm_pow,complexified_phase_norm]
      exact mul_le_mul_of_nonneg_left (transfer_trace_norm_le _) (by positivity)
    have hl := Real.log_le_log (norm_pos_iff.mpr hx) hb
    rw [Real.log_mul (pow_pos (Real.exp_pos _) _).ne' (mul_pos (by norm_num) hn).ne',
      Real.log_pow, Real.log_exp, Real.log_mul (by norm_num) hn.ne'] at hl
    unfold transferLogNorm
    nlinarith
  have hint := intervalIntegral.integral_mono_ae (by positivity : (0 : ℝ) ≤ 2*Real.pi)
    hqi (intervalIntegrable_const.add hai) hle
  rw [intervalIntegral.integral_add intervalIntegrable_const hai,intervalIntegral.integral_const] at hint
  simp only [sub_zero,smul_eq_mul] at hint
  have hdiv := div_le_div_of_nonneg_right hint (by positivity : 0 ≤ 2*Real.pi)
  rw [add_div,mul_div_cancel_left₀ _ (show 2*Real.pi ≠ 0 by positivity)] at hdiv
  have hh := hlow.trans (hJ.trans hdiv)
  change _ ≤ -(2*n : ℕ)*y+Real.log 2+
    transferLogAverage (complexifiedPhaseTransfer a r z y) ω (2*n) at hh
  nlinarith

theorem complexifiedFiniteLyapunov_lower_of_nonzero {a r : ℝ} (ha : 0<a) (hr : 0<r)
    (ω : ℝ) (z : ℂ) (y : ℝ)
    (hne : ∀x n, transferProduct (complexifiedPhaseTransfer a r z y) ω x n≠0)
    {n : ℕ} (hn : 1≤n) :
    y+Real.log (r/a)-Real.log 2/2 ≤ finiteLyapunov (complexifiedPhaseTransfer a r z y) ω n := by
  have h := complexifiedTransfer_even_average_lower_of_nonzero ha hr ω z y hne n
  have hs := complexifiedTransferLogAverage_subadditive_of_nonzero a r z ω y hne n n
  rw [show n+n=2*n by omega] at hs
  have hnr : (1:ℝ)≤n := by exact_mod_cast hn
  have hnpos : (0:ℝ)<n := by linarith
  unfold finiteLyapunov
  apply (le_div_iff₀ hnpos).mpr
  norm_num only [Nat.cast_mul,Nat.cast_ofNat] at h
  have hlog : 0≤Real.log 2 := Real.log_nonneg (by norm_num)
  nlinarith

theorem tendsto_complexifiedFiniteLyapunov_global {a r : ℝ} (ha : 0<a) (hr : 0<r)
    {α : ℝ} (hα : Irrational α) {z : ℂ} (hz : z≠0) (y : ℝ) :
    Tendsto (finiteLyapunov (complexifiedPhaseTransfer a r z y) (2*Real.pi*α)) atTop
      (𝓝 (complexifiedLyapunov a r (2*Real.pi*α) z y)) := by
  have hne := complexifiedTransferProduct_ne_zero ha.ne' r hz hα y
  have hs := complexifiedTransferLogAverage_subadditive_of_nonzero a r z (2*Real.pi*α) y hne
  have hb : BddBelow (range (finiteLyapunov (complexifiedPhaseTransfer a r z y) (2*Real.pi*α))) := by
    refine ⟨min 0 (y+Real.log (r/a)-Real.log 2/2),?_⟩
    rintro _ ⟨n,rfl⟩
    rcases Nat.eq_zero_or_pos n with rfl|hn
    · simp [finiteLyapunov]
    · exact (min_le_right _ _).trans
        (complexifiedFiniteLyapunov_lower_of_nonzero ha hr (2*Real.pi*α) z y hne (by omega))
  simpa only [Subadditive.lim,complexifiedLyapunov,lyapunov,finiteLyapunov] using hs.tendsto_lim hb

theorem convexOn_complexifiedLyapunov_univ {a r : ℝ} (ha : 0<a) (hr : 0<r)
    {α : ℝ} (hα : Irrational α) {z : ℂ} (hz : z≠0) :
    ConvexOn ℝ univ (complexifiedLyapunov a r (2*Real.pi*α) z) := by
  refine ⟨convex_univ,?_⟩
  intro l _ u _ b c hb hc hbc
  have hy := tendsto_complexifiedFiniteLyapunov_global ha hr hα hz (b • l+c • u)
  have hl := tendsto_complexifiedFiniteLyapunov_global ha hr hα hz l
  have hu := tendsto_complexifiedFiniteLyapunov_global ha hr hα hz u
  apply le_of_tendsto_of_tendsto hy ((hl.const_mul b).add (hu.const_mul c))
  exact Filter.Eventually.of_forall (fun n =>
    (convexOn_complexifiedFiniteLyapunov_univ ha.ne' r hz hα n).2
      (mem_univ l) (mem_univ u) hb hc hbc)

end UAMO.CMV

import UAMO.ComplexLyapunovConvexity
import UAMO.SeedEigenpolynomial

noncomputable section
namespace UAMO.CMV
open Matrix Set Filter
open scoped Topology Matrix.L2OpNorm

theorem complexifiedPhaseTransfer_ne_zero {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) (y x : ℝ) : complexifiedPhaseTransfer a r z y x ≠ 0 := by
  have hl : coupling a≠0 := by
    unfold coupling
    exact div_ne_zero (mul_ne_zero (by norm_num) ha) (by positivity)
  have he : complexifiedPhaseTransfer a r z y x 1 1 =
      ((1+r^2 : ℝ) : ℂ)*(coupling a : ℂ)*z := by
    simp [complexifiedPhaseTransfer,complexifiedRegularizedTransfer,regularizedConstant,
      regularizedTransfer,physicalTransfer,spectralLeadingMatrix]
    ring
  intro h
  have hh := congrArg (fun M : TransferMatrix => M 1 1) h
  dsimp only at hh
  rw [he] at hh
  exact mul_ne_zero (mul_ne_zero (Complex.ofReal_ne_zero.mpr (by positivity))
    (Complex.ofReal_ne_zero.mpr hl)) hz hh

theorem complexifiedPhaseTransfer_det_factor {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) (y x : ℝ) :
    (complexifiedPhaseTransfer a r z y x).det =
      (1+((r^2*Real.exp (-2*y) : ℝ) : ℂ)*spectralPhase (2*x))*
      (1+((r^2*Real.exp (2*y) : ℝ) : ℂ)*spectralPhase (-2*x)) := by
  have he : (Real.exp (-2*y) : ℂ)*(Real.exp (2*y) : ℂ)=1 := by
    rw [← Complex.ofReal_mul,← Real.exp_add]
    simp
  have hp : spectralPhase (2*x)*spectralPhase (-2*x)=1 := by
    rw [← spectralPhase_add]
    simp [spectralPhase]
  have hc : (((r^2*Real.exp (-2*y) : ℝ) : ℂ)*spectralPhase (2*x))*
      (((r^2*Real.exp (2*y) : ℝ) : ℂ)*spectralPhase (-2*x)) = (r:ℂ)^4 := by
    simp only [Complex.ofReal_mul,Complex.ofReal_pow]
    calc
      _ = (r:ℂ)^4*((Real.exp (-2*y):ℂ)*(Real.exp (2*y):ℂ))*
          (spectralPhase (2*x)*spectralPhase (-2*x)) := by ring
      _ = _ := by rw [he,hp]; ring
  rw [complexifiedPhaseTransfer,complexifiedRegularizedTransfer_det_vertical ha r hz]
  simp only [Complex.ofReal_mul,Complex.ofReal_pow] at hc ⊢
  linear_combination -hc

private theorem phase_eq_neg_one_of_scaled {c : ℝ} (hc : 0≤c) {p : ℂ} (hp : ‖p‖=1)
    (h : 1+(c:ℂ)*p=0) : p = -1 := by
  have he : (c:ℂ)*p = -1 := by linear_combination h
  have hn := congrArg norm he
  have hc1 : c=1 := by simpa [norm_mul,hp,abs_of_nonneg hc] using hn
  simpa [hc1] using he

theorem complexifiedPhaseTransfer_det_zero_phase {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) (y x : ℝ)
    (h : (complexifiedPhaseTransfer a r z y x).det=0) : spectralPhase (2*x) = -1 := by
  rw [complexifiedPhaseTransfer_det_factor ha r hz] at h
  rcases mul_eq_zero.mp h with h|h
  · exact phase_eq_neg_one_of_scaled (by positivity) (spectralPhase_norm _) h
  · have hh := phase_eq_neg_one_of_scaled (by positivity) (spectralPhase_norm _) h
    have hp : spectralPhase (2*x)*spectralPhase (-2*x)=1 := by
      rw [← spectralPhase_add]
      simp [spectralPhase]
    rw [hh] at hp
    linear_combination -hp

theorem spectralPhase_orbit_formula (α x : ℝ) (j : ℕ) :
    spectralPhase (2*(x+j*(2*Real.pi*α))) =
      spectralPhase (2*x)*(weylPhase α)^(2*(j:ℤ)) := by
  unfold spectralPhase
  rw [weylPhase_zpow,← Complex.exp_add]
  congr 1
  push_cast
  ring

theorem complexifiedPhaseTransfer_singular_unique {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) {α : ℝ} (hα : Irrational α) (y x : ℝ) {j k : ℕ}
    (hj : (complexifiedPhaseTransfer a r z y (x+j*(2*Real.pi*α))).det=0)
    (hk : (complexifiedPhaseTransfer a r z y (x+k*(2*Real.pi*α))).det=0) : j=k := by
  have he := (complexifiedPhaseTransfer_det_zero_phase ha r hz y _ hj).trans
    (complexifiedPhaseTransfer_det_zero_phase ha r hz y _ hk).symm
  rw [spectralPhase_orbit_formula,spectralPhase_orbit_formula] at he
  have hp := mul_left_cancel₀ (spectralPhase_ne_zero (2*x)) he
  have hi := (weylPhase_noIntegerResonance hα).zpow_injective (Complex.exp_ne_zero _) hp
  omega

theorem transferProduct_ne_zero_of_unique_singular (A : ℝ→TransferMatrix) (ω x : ℝ)
    (hne : ∀j : ℕ, A (x+j*ω)≠0)
    (hunique : ∀j k : ℕ, (A (x+j*ω)).det=0 → (A (x+k*ω)).det=0 → j=k) (n : ℕ) :
    transferProduct A ω x n≠0 := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ]
    by_cases hd : (A (x+n*ω)).det=0
    · have hprev : ∀j<n, (A (x+j*ω)).det≠0 := by
        intro j hj hj0
        have := hunique j n hj0 hd
        omega
      have hdet : (transferProduct A ω x n).det≠0 := by
        have haux : ∀k≤n, (transferProduct A ω x k).det≠0 := by
          intro k hk
          induction k with
          | zero => simp
          | succ k ihk =>
            rw [transferProduct_succ,Matrix.det_mul]
            exact mul_ne_zero (hprev k (by omega)) (ihk (by omega))
        exact haux n le_rfl
      intro hzero
      have hh := congrArg (fun M : TransferMatrix => M*(transferProduct A ω x n)⁻¹) hzero
      dsimp only at hh
      rw [Matrix.mul_nonsing_inv_cancel_right _ _ (isUnit_iff_ne_zero.mpr hdet),zero_mul] at hh
      exact hne n hh
    · intro hzero
      have hh := congrArg (fun M : TransferMatrix => (A (x+n*ω))⁻¹*M) hzero
      dsimp only at hh
      rw [Matrix.nonsing_inv_mul_cancel_left _ _ (isUnit_iff_ne_zero.mpr hd),mul_zero] at hh
      exact ih hh

theorem complexifiedTransferProduct_ne_zero {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) {α : ℝ} (hα : Irrational α) (y x : ℝ) (n : ℕ) :
    transferProduct (complexifiedPhaseTransfer a r z y) (2*Real.pi*α) x n≠0 := by
  apply transferProduct_ne_zero_of_unique_singular
  · intro j
    exact complexifiedPhaseTransfer_ne_zero ha r hz y _
  · intro j k hj hk
    exact complexifiedPhaseTransfer_singular_unique ha r hz hα y x hj hk

theorem convexOn_complexifiedFiniteLyapunov_univ {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) {α : ℝ} (hα : Irrational α) (n : ℕ) :
    ConvexOn ℝ univ (fun y => finiteLyapunov (complexifiedPhaseTransfer a r z y) (2*Real.pi*α) n) :=
  convexOn_complexifiedFiniteLyapunov a r z (2*Real.pi*α) n convex_univ
    (fun y _ x => complexifiedTransferProduct_ne_zero ha r hz hα y x n)

end UAMO.CMV

import Mathlib.LinearAlgebra.Eigenspace.Basic

namespace UAMO

section CompressedEigenline

variable {𝕜 V : Type*} [Field 𝕜] [AddCommGroup V] [Module 𝕜 V]

def compressedMap (P A : V →ₗ[𝕜] V) : V →ₗ[𝕜] V :=
  P.comp (A.comp P)

@[simp] theorem compressedMap_apply (P A : V →ₗ[𝕜] V) (v : V) :
    compressedMap P A v = P (A (P v)) := rfl

theorem resolvent_column_ne_zero
    (H R : V →ₗ[𝕜] V) (E : 𝕜) (Ω : V)
    (hres : ∀ v, E • R v - H (R v) = v) (hΩ : Ω ≠ 0) :
    R Ω ≠ 0 := by
  intro hzero
  have h := hres Ω
  rw [hzero, smul_zero, map_zero, sub_self] at h
  exact hΩ h.symm

theorem centered_resolvent_eigenvector
    (P H R : V →ₗ[𝕜] V) (E : 𝕜) (Ω : V)
    (hres : ∀ v, E • R v - H (R v) = v)
    (hcenter : P (R Ω) = R Ω) (hroot : P Ω = 0) :
    P (H (R Ω)) = E • R Ω := by
  have h := congrArg P (hres Ω)
  rw [map_sub, map_smul, hcenter, hroot] at h
  exact (sub_eq_zero.mp h).symm

theorem centered_eigenspace_iff
    (P H R : V →ₗ[𝕜] V) (E : 𝕜) (Ω : V)
    (hres : ∀ v, E • R v - H (R v) = v)
    (hinverse : ∀ v, R (E • v - H v) = v)
    (hcenter : P (R Ω) = R Ω) (hroot : P Ω = 0)
    (hkernel : ∀ v, P v = 0 → ∃ c : 𝕜, v = c • Ω)
    (v : V) :
    (P v = v ∧ P (H v) = E • v) ↔ ∃ c : 𝕜, v = c • R Ω := by
  have hq := centered_resolvent_eigenvector P H R E Ω hres hcenter hroot
  constructor
  · rintro ⟨hv, he⟩
    have hz : P (E • v - H v) = 0 := by
      rw [map_sub, map_smul, hv, he, sub_self]
    obtain ⟨c, hc⟩ := hkernel _ hz
    refine ⟨c, ?_⟩
    calc
      v = R (E • v - H v) := (hinverse v).symm
      _ = R (c • Ω) := congrArg R hc
      _ = c • R Ω := map_smul R c Ω
  · rintro ⟨c, rfl⟩
    constructor
    · rw [map_smul, hcenter]
    · rw [map_smul, map_smul, hq, smul_comm]

theorem compressed_observable_preserves_resolvent_line
    (P H R L : V →ₗ[𝕜] V) (E : 𝕜) (Ω : V)
    (hres : ∀ v, E • R v - H (R v) = v)
    (hinverse : ∀ v, R (E • v - H v) = v)
    (hcenter : P (R Ω) = R Ω) (hroot : P Ω = 0)
    (hkernel : ∀ v, P v = 0 → ∃ c : 𝕜, v = c • Ω)
    (hprojection : ∀ v, P (P v) = P v)
    (hcommute : ∀ v,
      compressedMap P L (compressedMap P H v) =
        compressedMap P H (compressedMap P L v)) :
    ∃ c : 𝕜, compressedMap P L (R Ω) = c • R Ω := by
  have hq := centered_resolvent_eigenvector P H R E Ω hres hcenter hroot
  have hcompressed : compressedMap P H (R Ω) = E • R Ω := by
    rw [compressedMap_apply, hcenter, hq]
  have hfixed : P (compressedMap P L (R Ω)) = compressedMap P L (R Ω) :=
    hprojection _
  have heigen :
      compressedMap P H (compressedMap P L (R Ω)) =
        E • compressedMap P L (R Ω) := by
    rw [← hcommute, hcompressed, map_smul]
  apply (centered_eigenspace_iff P H R E Ω hres hinverse
    hcenter hroot hkernel (compressedMap P L (R Ω))).mp
  refine ⟨hfixed, ?_⟩
  simpa only [compressedMap_apply, hprojection] using heigen

end CompressedEigenline

end UAMO

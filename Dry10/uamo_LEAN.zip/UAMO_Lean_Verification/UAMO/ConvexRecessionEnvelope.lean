import Mathlib.Analysis.Convex.Slope
import Mathlib.Topology.Algebra.Order.Field
import Mathlib.Topology.MetricSpace.Lipschitz
import Mathlib.Tactic

noncomputable section
namespace UAMO.ConvexAsymptote
open Filter Set
open scoped Topology

theorem secant_limit {f : ℝ→ℝ} {c : ℝ}
    (htop : Tendsto (fun y => f y-y) atTop (𝓝 c)) (x : ℝ) :
    Tendsto (fun y => (f y-f x)/(y-x)) atTop (𝓝 1) := by
  have hden : Tendsto (fun y : ℝ => y-x) atTop atTop := by
    simpa only [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-x) tendsto_id
  have hzero := (htop.add_const (x-f x)).div_atTop hden
  have hone : Tendsto (fun y => 1+((f y-y)+(x-f x))/(y-x)) atTop (𝓝 1) := by
    simpa only [add_zero] using (tendsto_const_nhds.add hzero)
  apply hone.congr'
  filter_upwards [eventually_gt_atTop x] with y hy
  have hne : y-x≠0 := sub_ne_zero.mpr hy.ne'
  field_simp
  ring

theorem increment_le {f : ℝ→ℝ} {c : ℝ} (hf : ConvexOn ℝ univ f)
    (htop : Tendsto (fun y => f y-y) atTop (𝓝 c)) {x y : ℝ} (hxy : x≤y) :
    f y-f x≤y-x := by
  rcases hxy.eq_or_lt with rfl|hxy
  · simp
  have hle : (f y-f x)/(y-x)≤1 :=
    ge_of_tendsto (secant_limit htop x) (by
      filter_upwards [eventually_gt_atTop y] with z hz
      exact hf.secant_mono_aux2 (mem_univ x) (mem_univ z) hxy hz)
  simpa only [one_mul] using (div_le_iff₀ (sub_pos.mpr hxy)).mp hle

theorem abs_increment_le {f : ℝ→ℝ} {c : ℝ} (hf : ConvexOn ℝ univ f)
    (heven : ∀y,f (-y)=f y) (htop : Tendsto (fun y => f y-y) atTop (𝓝 c))
    (x y : ℝ) : |f x-f y|≤|x-y| := by
  have hordered {u v : ℝ} (huv : u≤v) : |f v-f u|≤v-u := by
    have hup := increment_le hf htop huv
    have hdown := increment_le hf htop (neg_le_neg huv)
    rw [heven u,heven v] at hdown
    apply abs_le.mpr
    constructor <;> linarith
  rcases le_total x y with hxy|hyx
  · calc
      |f x-f y|=|f y-f x| := abs_sub_comm _ _
      _ ≤ y-x := hordered hxy
      _ = |x-y| := by rw [abs_of_nonpos (sub_nonpos.mpr hxy)]; ring
  · exact (hordered hyx).trans_eq (abs_of_nonneg (sub_nonneg.mpr hyx)).symm

theorem asymptote_le {f : ℝ→ℝ} {c : ℝ} (hf : ConvexOn ℝ univ f)
    (htop : Tendsto (fun y => f y-y) atTop (𝓝 c)) (x : ℝ) : x+c≤f x := by
  have h : c≤f x-x := le_of_tendsto htop (by
    filter_upwards [eventually_ge_atTop x] with y hy
    have hh := increment_le hf htop hy
    linarith)
  linarith

theorem zero_le_value {f : ℝ→ℝ} (hf : ConvexOn ℝ univ f)
    (heven : ∀y,f (-y)=f y) (x : ℝ) : f 0≤f x := by
  have h := hf.2 (mem_univ x) (mem_univ (-x)) (by norm_num : (0:ℝ)≤1/2)
    (by norm_num : (0:ℝ)≤1/2) (by norm_num : (1/2:ℝ)+1/2=1)
  have hmid : (1/2:ℝ) • x+(1/2:ℝ) • (-x)=0 := by simp only [smul_eq_mul]; ring
  rw [hmid,heven x] at h
  change f 0≤(1/2)*f x+(1/2)*f x at h
  linarith

theorem envelope {f : ℝ→ℝ} {c : ℝ} (hf : ConvexOn ℝ univ f)
    (heven : ∀y,f (-y)=f y) (htop : Tendsto (fun y => f y-y) atTop (𝓝 c))
    (y : ℝ) : max (f 0) (|y|+c)≤f y ∧ f y≤f 0+|y| := by
  have hline : |y|+c≤f y := by
    rcases le_total 0 y with hy|hy
    · rw [abs_of_nonneg hy]
      exact asymptote_le hf htop y
    · rw [abs_of_nonpos hy]
      simpa only [heven y] using asymptote_le hf htop (-y)
  refine ⟨max_le (zero_le_value hf heven y) hline,?_⟩
  have h := abs_increment_le hf heven htop y 0
  rw [sub_zero] at h
  have hh := (le_abs_self (f y-f 0)).trans h
  linarith

end UAMO.ConvexAsymptote

import UAMO.CircleArcLabel
import UAMO.GapProjectionTrace
import UAMO.UAMOGapLabels

noncomputable section
namespace UAMO
open Set Filter MeasureTheory CircleDOS PhysicalDOS
open scoped Topology

theorem scalar_circle_cut_eventually_resolvent_and_IDS (a r₀ Φ : ℝ) (z : ℂ)
    (ha : a≠0)
    (hE : (scalarEnergyOfCircle a r₀ z:ℂ)∈
      resolventSet ℂ (scalarHamiltonian a r₀ (-Real.pi*Φ))) :
    ∀ᶠ r in 𝓝 r₀,
      (scalarEnergyOfCircle a r z:ℂ)∈resolventSet ℂ (scalarHamiltonian a r (-Real.pi*Φ)) ∧
      scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r z)=
        scalarIDS a r₀ (-Real.pi*Φ) (scalarEnergyOfCircle a r₀ z) := by
  have henergy : Continuous (fun r:ℝ => scalarEnergyOfCircle a r z) := by
    unfold scalarEnergyOfCircle
    fun_prop
  have hpath : Continuous (fun r:ℝ => ((a,r),scalarEnergyOfCircle a r z)) :=
    (continuous_const.prodMk continuous_id).prodMk henergy
  have hnear := hpath.continuousAt.eventually
    (scalarGapProjection_trace_eventually_eq a r₀ (-Real.pi*Φ) _ ha hE)
  filter_upwards [hnear] with r hr
  obtain ⟨hres,htrace⟩ := hr
  refine ⟨hres,?_⟩
  simpa only [scalarGapProjection_trace_eq_realSpectralMass] using htrace

theorem physical_circle_gap_local_persistence {a r₀ Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr₀ : 0≤r₀) (hr₁ : r₀≤1)
    (hΦ : Irrational Φ) (θ : ℝ) (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r₀) Φ θ)) :
    ∃δ>0,∀(r:ℝ)(hr:0≤r)(hr1:r≤1),dist r r₀<δ →
      z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ∧
      arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z=
        arcLabel (physicalUnitaryDOS a r₀ Φ ha.le ha1 hr₀ hr₁) z := by
  have hE := (physical_circle_resolvent_scalar ha ha1 hr₀ hr₁ hΦ θ z hz).mp hres
  obtain ⟨δ,hδ,hnear⟩ := Metric.eventually_nhds_iff.mp
    (scalar_circle_cut_eventually_resolvent_and_IDS a r₀ Φ z ha.ne' hE)
  refine ⟨δ,hδ,?_⟩
  intro r hr hr1 hdist
  obtain ⟨hEr,hIDS⟩ := hnear hdist
  refine ⟨(physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ θ z hz).mpr hEr,?_⟩
  by_cases him : 0<z.im
  · rw [physical_arcLabel_upper ha ha1 hr hr1 Φ him,
      physical_arcLabel_upper ha ha1 hr₀ hr₁ Φ him,hIDS]
  · rw [physical_arcLabel_lower_nonpos ha ha1 hr hr1 Φ (le_of_not_gt him),
      physical_arcLabel_lower_nonpos ha ha1 hr₀ hr₁ Φ (le_of_not_gt him),hIDS]

theorem corner_gap_same_label_edge_witness {Φ : ℝ} (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ (PhysicalRepresentation.walk 1 1 Φ θ)) :
    ∃(r:ℝ)(hr:0<r)(hr1:r<1),
      z∈resolventSet ℂ (PhysicalRepresentation.walk 1 (coupling r) Φ θ) ∧
      arcLabel (physicalUnitaryDOS 1 r Φ (by norm_num) (by norm_num) hr.le hr1.le) z=
        arcLabel (physicalUnitaryDOS 1 1 Φ (by norm_num) (by norm_num) (by norm_num) (by norm_num)) z := by
  have h1 : coupling 1=1 := by norm_num [coupling]
  have hres' : z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling 1) (coupling 1) Φ θ) := by
    simpa only [h1] using hres
  obtain ⟨δ,hδ,hnear⟩ := physical_circle_gap_local_persistence
    (by norm_num : (0:ℝ)<1) (by norm_num) (by norm_num : (0:ℝ)≤1) (by norm_num)
    hΦ θ z hz hres'
  let d := min (δ/2) (1/2:ℝ)
  have hd : 0<d := lt_min (half_pos hδ) (by norm_num)
  have hdhalf : d≤1/2 := min_le_right _ _
  have hdδ : d<δ := (min_le_left _ _).trans_lt (half_lt_self hδ)
  have hr : 0<1-d := by linarith
  have hr1 : 1-d<1 := by linarith
  have hdist : dist (1-d) (1:ℝ)<δ := by
    simpa only [Real.dist_eq,sub_sub_cancel_left,abs_neg,abs_of_pos hd] using hdδ
  obtain ⟨hEr,hlabel⟩ := hnear (1-d) hr.le hr1.le hdist
  refine ⟨1-d,hr,hr1,?_,hlabel⟩
  simpa only [h1] using hEr

theorem corner_gap_has_odd_label_of_edge {Φ : ℝ} (hΦ : Irrational Φ) (θ : ℝ)
    (hodd : ∀(r:ℝ)(hr:0<r)(hr1:r<1)(z:ℂ),‖z‖=1 →
      z∈resolventSet ℂ (PhysicalRepresentation.walk 1 (coupling r) Φ θ) →
      ∃m ell:ℤ,Odd m ∧
        ((arcLabel (physicalUnitaryDOS 1 r Φ (by norm_num) (by norm_num) hr.le hr1.le) z:ℝ):
          AddCircle (1:ℝ))=uamoGapLabel Φ m ell)
    (z:ℂ) (hz:‖z‖=1)
    (hres:z∈resolventSet ℂ (PhysicalRepresentation.walk 1 1 Φ θ)) :
    ∃m ell:ℤ,Odd m ∧
      ((arcLabel (physicalUnitaryDOS 1 1 Φ (by norm_num) (by norm_num) (by norm_num) (by norm_num)) z:ℝ):
        AddCircle (1:ℝ))=uamoGapLabel Φ m ell := by
  obtain ⟨r,hr,hr1,hEr,hlabel⟩ := corner_gap_same_label_edge_witness hΦ θ z hz hres
  obtain ⟨m,ell,hm,hnum⟩ := hodd r hr hr1 z hz hEr
  exact ⟨m,ell,hm,by rwa [hlabel] at hnum⟩

end UAMO

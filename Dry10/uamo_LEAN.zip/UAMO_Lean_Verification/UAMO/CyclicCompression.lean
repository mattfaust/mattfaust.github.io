import UAMO.MagneticStationarity
import UAMO.MagneticSector
import UAMO.CenteredCompression

noncomputable section
namespace UAMO
open scoped InnerProductSpace

section Compression
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
variable (S : Submodule ℂ E) [CompleteSpace S]

def sourceCompression (T : E →L[ℂ] E) : S →L[ℂ] S :=
  S.orthogonalProjection.comp (T.comp S.subtypeL)

theorem sourceCompression_inner (T : E →L[ℂ] E) (u v : S) :
    ⟪u, sourceCompression S T v⟫_ℂ = ⟪(u : E), T v⟫_ℂ := by
  exact S.inner_orthogonalProjection_eq_of_mem_left u (T v)

theorem sourceCompression_symmetric (T : E →L[ℂ] E)
    (hT : T.toLinearMap.IsSymmetric) :
    (sourceCompression S T).toLinearMap.IsSymmetric := by
  intro u v
  change ⟪sourceCompression S T u, v⟫_ℂ = ⟪u, sourceCompression S T v⟫_ℂ
  rw [sourceCompression_inner]
  change ⟪S.orthogonalProjection (T u), v⟫_ℂ = ⟪(u : E), T v⟫_ℂ
  rw [S.inner_orthogonalProjection_eq_of_mem_right v (T u)]
  exact hT u v

theorem sourceCompression_contraction (T : E →L[ℂ] E)
    (hT : ∀ u, ‖T u‖ ≤ ‖u‖) (v : S) : ‖sourceCompression S T v‖ ≤ ‖v‖ := by
  calc
    _ ≤ ‖T (v : E)‖ := by
      simpa [sourceCompression] using
        S.orthogonalProjection.le_of_opNorm_le (S.orthogonalProjection_norm_le) (T v)
    _ ≤ ‖(v : E)‖ := hT v
    _ = ‖v‖ := rfl

theorem sourceCompression_apply_of_mem (T : E →L[ℂ] E) (u : S) (hu : T u ∈ S) :
    (sourceCompression S T u : E) = T u :=
  Submodule.orthogonalProjection_eq_self_iff.mpr hu

end Compression

instance scalarCyclicSpace_completeSpace (a r φ : ℝ) :
    CompleteSpace (scalarCyclicSpace a r φ) := by
  unfold scalarCyclicSpace
  infer_instance

def cyclicOrigin (a r φ : ℝ) : scalarCyclicSpace a r φ :=
  ⟨magneticOrigin, magneticOrigin_mem_scalarCyclicSpace a r φ⟩

def cyclicHamiltonian (a r φ : ℝ) :
    scalarCyclicSpace a r φ →L[ℂ] scalarCyclicSpace a r φ :=
  sourceCompression _ (scalarHamiltonian a r φ)

def cyclicSector (a r φ : ℝ) :
    scalarCyclicSpace a r φ →L[ℂ] scalarCyclicSpace a r φ :=
  sourceCompression _ sectorOperator

def cyclicRadialColumn (a r φ : ℝ) : scalarCyclicSpace a r φ :=
  (scalarCyclicSpace a r φ).orthogonalProjection
    (radialHamiltonian a r φ magneticOrigin)

theorem cyclicOrigin_norm (a r φ : ℝ) : ‖cyclicOrigin a r φ‖ = 1 :=
  magneticOrigin_norm

theorem cyclicHamiltonian_apply (a r φ : ℝ) (v : scalarCyclicSpace a r φ) :
    (cyclicHamiltonian a r φ v : MagneticSpace) = scalarHamiltonian a r φ v :=
  sourceCompression_apply_of_mem _ _ v (scalarCyclicSpace_invariant a r φ v v.property)

theorem cyclicHamiltonian_symmetric (a r φ : ℝ) :
    (cyclicHamiltonian a r φ).toLinearMap.IsSymmetric :=
  sourceCompression_symmetric _ _ (scalarHamiltonian_selfAdjoint a r φ).isSymmetric

theorem cyclicSector_symmetric (a r φ : ℝ) :
    (cyclicSector a r φ).toLinearMap.IsSymmetric :=
  sourceCompression_symmetric _ _ sectorOperator_selfAdjoint.isSymmetric

theorem cyclicSector_contraction (a r φ : ℝ) (v : scalarCyclicSpace a r φ) :
    ‖cyclicSector a r φ v‖ ≤ ‖v‖ :=
  sourceCompression_contraction _ _ sectorOperator_norm_le v

theorem cyclicSector_origin (a r φ : ℝ) :
    cyclicSector a r φ (cyclicOrigin a r φ) = 0 := by
  change (scalarCyclicSpace a r φ).orthogonalProjection (sectorOperator magneticOrigin) = 0
  rw [sectorOperator_origin, map_zero]

theorem cyclicHamiltonian_origin_centered (a r φ : ℝ) :
    ⟪cyclicOrigin a r φ, cyclicHamiltonian a r φ (cyclicOrigin a r φ)⟫_ℂ = 0 := by
  rw [cyclicHamiltonian, sourceCompression_inner]
  exact magneticHamiltonianWith_trace_zero _ _ _

theorem cyclicRadialColumn_identity (a r φ : ℝ) :
    cyclicRadialColumn a r φ =
      cyclicHamiltonian a r φ (cyclicOrigin a r φ) -
        cyclicSector a r φ (cyclicHamiltonian a r φ (cyclicOrigin a r φ)) := by
  unfold cyclicRadialColumn
  rw [radialHamiltonian_origin]
  simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.one_apply, map_sub]
  congr 1
  change _ = (scalarCyclicSpace a r φ).orthogonalProjection
    (sectorOperator (cyclicHamiltonian a r φ (cyclicOrigin a r φ)))
  rw [cyclicHamiltonian_apply]
  rfl

theorem cyclicCommutator_inner (a r φ : ℝ) (v w : scalarCyclicSpace a r φ) :
    ⟪v, cyclicSector a r φ (cyclicHamiltonian a r φ w) -
      cyclicHamiltonian a r φ (cyclicSector a r φ w)⟫_ℂ =
      ⟪(v : MagneticSpace), sectorOperator (scalarHamiltonian a r φ w) -
        scalarHamiltonian a r φ (sectorOperator w)⟫_ℂ := by
  rw [inner_sub_right, inner_sub_right]
  congr 1
  · rw [cyclicSector, sourceCompression_inner, cyclicHamiltonian_apply]
  · rw [← (cyclicHamiltonian_symmetric a r φ).apply_clm,
      cyclicSector, sourceCompression_inner, cyclicHamiltonian_apply]
    exact (scalarHamiltonian_selfAdjoint a r φ).isSymmetric.apply_clm _ _

theorem cyclicSector_source_inner (a r φ : ℝ) (v : scalarCyclicSpace a r φ) :
    ⟪v, cyclicSector a r φ (cyclicHamiltonian a r φ (cyclicOrigin a r φ))⟫_ℂ =
      ⟪(v : MagneticSpace), sectorOperator (scalarHamiltonian a r φ magneticOrigin)⟫_ℂ := by
  rw [cyclicSector, sourceCompression_inner, cyclicHamiltonian_apply]
  rfl

theorem cyclicSector_source_inner_left (a r φ : ℝ) (v : scalarCyclicSpace a r φ) :
    ⟪cyclicSector a r φ (cyclicHamiltonian a r φ (cyclicOrigin a r φ)), v⟫_ℂ =
      ⟪sectorOperator (scalarHamiltonian a r φ magneticOrigin), (v : MagneticSpace)⟫_ℂ := by
  have h := congrArg (starRingEnd ℂ) (cyclicSector_source_inner a r φ v)
  simpa only [inner_conj_symm] using h

end UAMO

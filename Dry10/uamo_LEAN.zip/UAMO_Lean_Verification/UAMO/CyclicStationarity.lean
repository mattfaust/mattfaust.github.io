import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.InnerProductSpace.Projection
import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.Topology.Algebra.Module.LinearMap

namespace UAMO
noncomputable section
open scoped InnerProductSpace

section Normed
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]

def closedCyclicSpace (H : E →L[ℂ] E) (Ω : E) : Submodule ℂ E :=
  (Submodule.span ℂ (Set.range fun n : ℕ => (H ^ n) Ω)).topologicalClosure

theorem power_mem_closedCyclicSpace (H : E →L[ℂ] E) (Ω : E) (n : ℕ) :
    (H ^ n) Ω ∈ closedCyclicSpace H Ω :=
  Submodule.le_topologicalClosure _ (Submodule.subset_span ⟨n, rfl⟩)

theorem source_mem_closedCyclicSpace (H : E →L[ℂ] E) (Ω : E) :
    Ω ∈ closedCyclicSpace H Ω := by
  simpa using power_mem_closedCyclicSpace H Ω 0

theorem closedCyclicSpace_invariant (H : E →L[ℂ] E) (Ω : E) (u : E)
    (hu : u ∈ closedCyclicSpace H Ω) : H u ∈ closedCyclicSpace H Ω := by
  let S := Submodule.span ℂ (Set.range fun n : ℕ => (H ^ n) Ω)
  have hspan : Set.MapsTo H (S : Set E) S := by
    intro v hv
    induction hv using Submodule.span_induction with
    | mem v hv =>
        obtain ⟨n, rfl⟩ := hv
        exact Submodule.subset_span ⟨n + 1, by simp [pow_succ']⟩
    | zero => simp
    | add v w _ _ hv hw => simpa using S.add_mem hv hw
    | smul c v _ hv => simpa using S.smul_mem c hv
  exact hspan.closure H.continuous hu

theorem commuting_action_eq_on_source_power (H K : E →L[ℂ] E) (Ω : E)
    (hcomm : Commute K H) (hsource : K Ω = H Ω) (n : ℕ) :
    K ((H ^ n) Ω) = H ((H ^ n) Ω) := by
  have hc (u : E) : K (H u) = H (K u) :=
    congrArg (fun T : E →L[ℂ] E => T u) hcomm.eq
  induction n with
  | zero => simpa using hsource
  | succ n hn =>
      simp only [pow_succ', ContinuousLinearMap.mul_apply]
      rw [hc, hn]

theorem commuting_action_eq_on_closedCyclicSpace (H K : E →L[ℂ] E) (Ω : E)
    (hcomm : Commute K H) (hsource : K Ω = H Ω) (u : E)
    (hu : u ∈ closedCyclicSpace H Ω) : K u = H u := by
  apply ContinuousLinearMap.eqOn_closure_span (s := Set.range fun n : ℕ => (H ^ n) Ω) _ hu
  rintro v ⟨n, rfl⟩
  exact commuting_action_eq_on_source_power H K Ω hcomm hsource n

theorem cyclic_resolvent_left_identity (H : E →L[ℂ] E) (z : ℂ)
    (hz : z ∈ resolventSet ℂ H) (u : E) :
    z • resolvent H z u - H (resolvent H z u) = u := by
  have h := congrArg (fun A : E →L[ℂ] E => A u)
    (Ring.mul_inverse_cancel (algebraMap ℂ (E →L[ℂ] E) z - H) hz)
  change (algebraMap ℂ (E →L[ℂ] E) z - H) (resolvent H z u) = u
  simpa only [resolvent, ContinuousLinearMap.mul_apply, ContinuousLinearMap.one_apply] using h

theorem cyclic_resolvent_right_identity (H : E →L[ℂ] E) (z : ℂ)
    (hz : z ∈ resolventSet ℂ H) (u : E) :
    resolvent H z (z • u - H u) = u := by
  have h := congrArg (fun A : E →L[ℂ] E => A u)
    (Ring.inverse_mul_cancel (algebraMap ℂ (E →L[ℂ] E) z - H) hz)
  change resolvent H z ((algebraMap ℂ (E →L[ℂ] E) z - H) u) = u
  simpa only [resolvent, ContinuousLinearMap.mul_apply, ContinuousLinearMap.one_apply] using h

end Normed

section Hilbert
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]

instance closedCyclicSpace_completeSpace (H : E →L[ℂ] E) (Ω : E) :
    CompleteSpace (closedCyclicSpace H Ω) := by
  unfold closedCyclicSpace
  infer_instance

theorem closedCyclicSpace_orthogonal_invariant (H : E →L[ℂ] E) (Ω : E)
    (hH : IsSelfAdjoint H) (u : E) (hu : u ∈ (closedCyclicSpace H Ω)ᗮ) :
    H u ∈ (closedCyclicSpace H Ω)ᗮ := by
  intro v hv
  rw [← hH.isSymmetric.apply_clm]
  exact hu _ (closedCyclicSpace_invariant H Ω v hv)

theorem closedCyclicSpace_projection_commutes (H : E →L[ℂ] E) (Ω : E)
    (hH : IsSelfAdjoint H) (u : E) :
    ((closedCyclicSpace H Ω).orthogonalProjection (H u) : E) =
      H ((closedCyclicSpace H Ω).orthogonalProjection u) := by
  apply Submodule.eq_orthogonalProjection_of_mem_orthogonal
  · exact closedCyclicSpace_invariant H Ω _
      ((closedCyclicSpace H Ω).orthogonalProjection u).property
  · rw [← map_sub]
    exact closedCyclicSpace_orthogonal_invariant H Ω hH _
      ((closedCyclicSpace H Ω).sub_orthogonalProjection_mem_orthogonal u)

theorem closedCyclicSpace_resolvent_invariant (H : E →L[ℂ] E) (Ω : E)
    (hH : IsSelfAdjoint H) (z : ℂ) (hz : z ∈ resolventSet ℂ H)
    (u : E) (hu : u ∈ closedCyclicSpace H Ω) :
    resolvent H z u ∈ closedCyclicSpace H Ω := by
  let R := resolvent H z
  let S := closedCyclicSpace H Ω
  let P : E →L[ℂ] E := S.subtypeL.comp S.orthogonalProjection
  have hcomm (v : E) : P (H v) = H (P v) :=
    closedCyclicSpace_projection_commutes H Ω hH v
  have hPu : P u = u := Submodule.orthogonalProjection_eq_self_iff.mpr hu
  have heq : z • P (R u) - H (P (R u)) = u := by
    calc
      _ = P (z • R u - H (R u)) := by rw [map_sub, map_smul, hcomm]
      _ = P u := congrArg P (cyclic_resolvent_left_identity H z hz u)
      _ = u := hPu
  have hback := congrArg R heq
  rw [cyclic_resolvent_right_identity H z hz] at hback
  exact hback ▸ (S.orthogonalProjection (R u)).property

end Hilbert
end
end UAMO

import UAMO.FiniteAngularSpectralFlow
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.SetTheory.Cardinal.Finite

noncomputable section
namespace UAMO.ProjectiveAngle
open Set

def angularCrossingSet (f : ℝ → ℝ) (t₀ L δ : ℝ) : Set ℝ :=
  {t | t∈Ico t₀ (t₀+L) ∧ ∃ j : ℤ, f t=f t₀+δ+(j:ℝ)*Real.pi}

theorem angularCrossing_existsUnique (f : ℝ → ℝ) (hf : Continuous f)
    (hmono : StrictMono f) (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (j : Fin N) :
    ∃! t : ℝ, t∈Ico t₀ (t₀+L) ∧ f t=f t₀+δ+(j.val:ℝ)*Real.pi := by
  have hj : (j.val:ℝ)+1≤(N:ℝ) := by exact_mod_cast Nat.succ_le_of_lt j.isLt
  have htarget : f t₀+δ+(j.val:ℝ)*Real.pi∈Ico (f t₀) (f (t₀+L)) := by
    rw [hturn]
    constructor
    · have hp : 0≤(j.val:ℝ)*Real.pi := mul_nonneg (Nat.cast_nonneg _) Real.pi_pos.le
      linarith
    · have h := mul_le_mul_of_nonneg_right hj Real.pi_pos.le
      nlinarith [Real.pi_pos]
  obtain ⟨t,ht,hft⟩ := intermediate_value_Ico (by linarith : t₀≤t₀+L) hf.continuousOn htarget
  refine ⟨t,⟨ht,hft⟩,fun u hu => hmono.injective ?_⟩
  exact hu.2.trans hft.symm

theorem angularCrossing_index_bounds (f : ℝ → ℝ) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi)
    {t : ℝ} (ht : t∈Ico t₀ (t₀+L)) {j : ℤ}
    (hj : f t=f t₀+δ+(j:ℝ)*Real.pi) : 0≤j ∧ j<(N:ℤ) := by
  have hl := hmono.monotone ht.1
  have hu := hmono ht.2
  rw [hj] at hl
  rw [hj,hturn] at hu
  constructor
  · by_contra h
    have hjneg : j≤-1 := by omega
    have hjneg' : (j:ℝ)≤-1 := by exact_mod_cast hjneg
    have hmul := mul_le_mul_of_nonneg_right hjneg' Real.pi_pos.le
    linarith
  · by_contra h
    have hjbig : (N:ℤ)≤j := by omega
    have hjbig' : (N:ℝ)≤(j:ℝ) := by exact_mod_cast hjbig
    have hmul := mul_le_mul_of_nonneg_right hjbig' Real.pi_pos.le
    linarith

def angularCrossingRoot (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (j : Fin N) : ℝ :=
  Classical.choose (angularCrossing_existsUnique f hf hmono t₀ L δ hL hδ hδπ N hturn j)

theorem angularCrossingRoot_spec (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (j : Fin N) :
    angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn j∈Ico t₀ (t₀+L) ∧
      f (angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn j)=
        f t₀+δ+(j.val:ℝ)*Real.pi :=
  (Classical.choose_spec (angularCrossing_existsUnique f hf hmono t₀ L δ hL hδ hδπ N hturn j)).1

def angularCrossingMap (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) (j : Fin N) :
    angularCrossingSet f t₀ L δ :=
  ⟨angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn j,
    (angularCrossingRoot_spec f hf hmono t₀ L δ hL hδ hδπ N hturn j).1,
    (j.val:ℤ),by simpa using (angularCrossingRoot_spec f hf hmono t₀ L δ hL hδ hδπ N hturn j).2⟩

theorem angularCrossingMap_bijective (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) :
    Function.Bijective (angularCrossingMap f hf hmono t₀ L δ hL hδ hδπ N hturn) := by
  constructor
  · intro i j hij
    have hroot := congrArg Subtype.val hij
    have hfi := (angularCrossingRoot_spec f hf hmono t₀ L δ hL hδ hδπ N hturn i).2
    have hfj := (angularCrossingRoot_spec f hf hmono t₀ L δ hL hδ hδπ N hturn j).2
    change angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn i=
      angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn j at hroot
    rw [hroot,hfj] at hfi
    have he : (i.val:ℝ)=(j.val:ℝ) := by nlinarith [Real.pi_pos]
    apply Fin.ext
    exact_mod_cast he
  · intro t
    obtain ⟨ht,j,hj⟩ := t.property
    obtain ⟨hj0,hjN⟩ := angularCrossing_index_bounds f hmono t₀ L δ hδ hδπ N hturn ht hj
    let i : Fin N := ⟨j.toNat,by omega⟩
    refine ⟨i,Subtype.ext (hmono.injective ?_)⟩
    change f (angularCrossingRoot f hf hmono t₀ L δ hL hδ hδπ N hturn i)=f t.val
    rw [(angularCrossingRoot_spec f hf hmono t₀ L δ hL hδ hδπ N hturn i).2,hj]
    have hi : (i.val:ℝ)=(j:ℝ) := by
      dsimp [i]
      exact_mod_cast Int.toNat_of_nonneg hj0
    rw [hi]

def angularCrossingEquiv (f : ℝ → ℝ) (hf : Continuous f) (hmono : StrictMono f)
    (t₀ L δ : ℝ) (hL : 0<L) (hδ : 0≤δ) (hδπ : δ<Real.pi)
    (N : ℕ) (hturn : f (t₀+L)=f t₀+(N:ℝ)*Real.pi) :
    Fin N ≃ angularCrossingSet f t₀ L δ :=
  Equiv.ofBijective _ (angularCrossingMap_bijective f hf hmono t₀ L δ hL hδ hδπ N hturn)

end UAMO.ProjectiveAngle

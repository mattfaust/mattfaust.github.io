import UAMO.FiniteAngularSpectralFlow
import UAMO.CMVRealMonodromy

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

def complexAngleVector (s : ℝ) : Fin 2→ℂ := fun i => (angleVector s i:ℂ)

theorem angleIterate_direction (A : ℝ→PlaneMatrix) (F : ℝ→ℝ→ℝ)
    (hF : ∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c • (A x*ᵥangleVector s))
    (ω x s : ℝ) (n : ℕ) :
    ∃c:ℝ,0<c ∧ angleVector (angleIterate F ω x s n)=
      c • (forwardProduct A ω x n*ᵥangleVector s) := by
  induction n with
  | zero => exact ⟨1,by norm_num,by simp [forwardProduct]⟩
  | succ n ih =>
    obtain ⟨c,hc,he⟩ := ih
    obtain ⟨d,hd,hdirection⟩ := hF (x+(n:ℝ)*ω) (angleIterate F ω x s n)
    refine ⟨d*c,mul_pos hd hc,?_⟩
    rw [angleIterate_succ,hdirection,he,Matrix.mulVec_smul,smul_smul,
      Matrix.mulVec_mulVec,forwardProduct_succ]

theorem transferProduct_map_real (A : ℝ→PlaneMatrix) (ω x : ℝ) (n : ℕ) :
    CMV.transferProduct (fun y => (A y).map Complex.ofReal) ω x n=
      (forwardProduct A ω x n).map Complex.ofReal := by
  induction n with
  | zero =>
    ext i j
    by_cases h : i=j <;> simp [forwardProduct, Matrix.one_apply,h]
  | succ n ih =>
    rw [CMV.transferProduct_succ,forwardProduct_succ,ih]
    ext i j
    simp [Matrix.mul_apply,Fin.sum_univ_two]

theorem realMonodromy_angleIterate_direction {a r : ℝ} (ha : 0<a)
    (hr : 0≤r) (hr1 : r<1) (t ω x s : ℝ) (n : ℕ) :
    ∃c:ℝ,0<c ∧
      complexAngleVector (angleIterate
        (fun y => realTransferAngleLift a (coupling r) t y) ω x s n)=
      (c:ℂ) • (CMV.realMonodromy a r t ω x n*ᵥcomplexAngleVector s) := by
  obtain ⟨c,hc,he⟩ := angleIterate_direction
    (realTransfer a (coupling r) t) (realTransferAngleLift a (coupling r) t)
    (fun y v => realTransferAngleLift_direction ha (by unfold coupling; positivity)
      (CMV.coupling_lt_one_of_lt_one hr1) t y v) ω x s n
  refine ⟨c,hc,?_⟩
  unfold CMV.realMonodromy CMV.complexRealTransfer
  rw [transferProduct_map_real]
  funext i
  have h := congrFun he i
  simp only [Pi.smul_apply,smul_eq_mul] at h
  simp only [complexAngleVector,Pi.smul_apply,smul_eq_mul]
  rw [h]
  simp [Matrix.mulVec,dotProduct,Fin.sum_univ_two,complexAngleVector]

end UAMO.ProjectiveAngle

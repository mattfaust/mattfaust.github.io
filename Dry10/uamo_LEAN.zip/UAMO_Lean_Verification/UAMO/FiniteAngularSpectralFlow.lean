import UAMO.AngularIteration
import UAMO.RealTransferSpectralTwist
import UAMO.RealTransferAngleNormalization

noncomputable section
namespace UAMO.ProjectiveAngle

def finiteAngularFlow (a lam t α x s : ℝ) (n : ℕ) : ℝ :=
  angleIterate (fun y => realTransferAngleLift a lam t (2*Real.pi*y)) α x s n

@[simp] theorem finiteAngularFlow_zero (a lam t α x s : ℝ) :
    finiteAngularFlow a lam t α x s 0=s := rfl

@[simp] theorem finiteAngularFlow_succ (a lam t α x s : ℝ) (n : ℕ) :
    finiteAngularFlow a lam t α x s (n+1)=
      realTransferAngleLift a lam t (2*Real.pi*(x+(n:ℝ)*α))
        (finiteAngularFlow a lam t α x s n) := rfl

theorem continuous_finiteAngularFlow {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (α : ℝ) (n : ℕ) :
    Continuous (fun p : ℝ×ℝ×ℝ => finiteAngularFlow a lam p.1 α p.2.1 p.2.2 n) := by
  induction n with
  | zero => simpa only [finiteAngularFlow_zero] using continuous_snd.snd
  | succ n ih =>
    simp only [finiteAngularFlow_succ]
    exact (continuous_realTransferAngleLift ha hlam hlam1).comp
      (continuous_fst.prodMk ((show Continuous (fun p : ℝ×ℝ×ℝ =>
        2*Real.pi*(p.2.1+(n:ℝ)*α)) from by fun_prop).prodMk ih))

theorem finiteAngularFlow_direction_strictMono {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (t α x : ℝ) (n : ℕ) :
    StrictMono (fun s => finiteAngularFlow a lam t α x s n) := by
  induction n with
  | zero => exact strictMono_id
  | succ n ih =>
    exact (realTransferAngleLift_strictMono ha hlam hlam1 t (2*Real.pi*(x+(n:ℝ)*α))).comp ih

theorem finiteAngularFlow_spectral_monotone {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (α x s : ℝ) (n : ℕ) :
    Monotone (fun t => finiteAngularFlow a lam t α x s n) := by
  induction n with
  | zero => exact monotone_const
  | succ n ih =>
    intro t u htu
    dsimp only
    rw [finiteAngularFlow_succ,finiteAngularFlow_succ]
    exact ((realTransferAngleLift_spectral_strictMono ha hlam hlam1
      (2*Real.pi*(x+(n:ℝ)*α)) (finiteAngularFlow a lam t α x s n)).monotone htu).trans
      ((realTransferAngleLift_strictMono ha hlam hlam1 u
        (2*Real.pi*(x+(n:ℝ)*α))).monotone (ih htu))

theorem realTransferAngleLift_add_nat_two_pi (a lam t x s : ℝ) (n : ℕ) :
    realTransferAngleLift a lam t x (s+2*Real.pi*(n:ℝ))=
      realTransferAngleLift a lam t x s+2*Real.pi*(n:ℝ) := by
  have h := angleMap_add_int_pi (fun y => realTransferAngleLift a lam t y)
    (fun y u => realTransferAngleLift_add_pi a lam t y u) x s (2*(n:ℤ))
  have he : ((2*(n:ℤ):ℤ):ℝ)*Real.pi=2*Real.pi*(n:ℝ) := by push_cast; ring
  rw [he] at h
  exact h

theorem finiteAngularFlow_spectral_periodic (a lam t α x s : ℝ) (n : ℕ) :
    finiteAngularFlow a lam (t+2*Real.pi) α x s n=
      finiteAngularFlow a lam t α x s n+2*Real.pi*(n:ℝ) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [finiteAngularFlow_succ,ih,realTransferAngleLift_spectral_periodic,
      realTransferAngleLift_add_nat_two_pi,finiteAngularFlow_succ]
    push_cast
    ring

theorem finiteAngularFlow_add_pi (a lam t α x s : ℝ) (n : ℕ) :
    finiteAngularFlow a lam t α x (s+Real.pi) n=
      finiteAngularFlow a lam t α x s n+Real.pi := by
  simpa using angleIterate_add_int_pi (fun y => realTransferAngleLift a lam t (2*Real.pi*y))
    (fun y u => realTransferAngleLift_add_pi a lam t (2*Real.pi*y) u) α x s 1 n

end UAMO.ProjectiveAngle

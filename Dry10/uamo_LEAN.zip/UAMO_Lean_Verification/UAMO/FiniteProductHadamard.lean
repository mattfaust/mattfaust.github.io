import Mathlib.Analysis.Complex.Hadamard
import Mathlib.Analysis.NormedSpace.HahnBanach.Extension

noncomputable section
namespace UAMO.ComplexGrowth
open Set Complex Complex.HadamardThreeLines
open scoped BigOperators

variable {E ι : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]

theorem finite_norm_product_three_lines (s : Finset ι) (f : ι → ℂ → E)
    (hd : ∀i∈s, Differentiable ℂ (f i)) {l u A B : ℝ} (hul : l<u) {z : ℂ}
    (hz : z∈verticalClosedStrip l u)
    (hbound : BddAbove ((fun w => ∏i∈s, ‖f i w‖) '' verticalClosedStrip l u))
    (hleft : ∀w : ℂ, w.re=l → ∏i∈s, ‖f i w‖ ≤ A)
    (hright : ∀w : ℂ, w.re=u → ∏i∈s, ‖f i w‖ ≤ B) :
    (∏i∈s, ‖f i z‖) ≤ A^(1-(z.re-l)/(u-l))*B^((z.re-l)/(u-l)) := by
  classical
  choose g hg hgval using fun i : ι => exists_dual_vector'' ℂ (f i z)
  let F : ℂ → ℂ := fun w => ∏i∈s, g i (f i w)
  have hF : Differentiable ℂ F := by
    apply Differentiable.finset_prod
    intro i hi
    exact (g i).differentiable.comp (hd i hi)
  have hnorm : ∀w, ‖F w‖ ≤ ∏i∈s, ‖f i w‖ := by
    intro w
    simp only [F,norm_prod]
    apply Finset.prod_le_prod (fun i _ => norm_nonneg _)
    intro i _
    exact ((g i).le_opNorm _).trans (by simpa using (mul_le_mul_of_nonneg_right (hg i) (norm_nonneg (f i w))))
  have hFbound : BddAbove ((norm ∘ F) '' verticalClosedStrip l u) := by
    obtain ⟨M,hM⟩ := hbound
    refine ⟨M,?_⟩
    rintro _ ⟨w,hw,rfl⟩
    exact (hnorm w).trans (hM ⟨w,hw,rfl⟩)
  have hinterp := norm_le_interp_of_mem_verticalClosedStrip' hul hz
    hF.diffContOnCl hFbound
    (fun w hw => (hnorm w).trans (hleft w hw))
    (fun w hw => (hnorm w).trans (hright w hw))
  have heq : ‖F z‖ = ∏i∈s, ‖f i z‖ := by
    simp [F,norm_prod,hgval]
  rwa [heq] at hinterp

theorem finite_log_norm_sum_three_lines (s : Finset ι) (f : ι → ℂ → E)
    (hd : ∀i∈s, Differentiable ℂ (f i)) {l u A B : ℝ} (hul : l<u) {z : ℂ}
    (hz : z∈verticalClosedStrip l u)
    (hbound : BddAbove ((fun w => ∏i∈s, ‖f i w‖) '' verticalClosedStrip l u))
    (hne : ∀i∈s, f i z ≠ 0)
    (hleft : ∀w : ℂ, w.re=l → ∑i∈s, Real.log ‖f i w‖ ≤ A)
    (hright : ∀w : ℂ, w.re=u → ∑i∈s, Real.log ‖f i w‖ ≤ B) :
    (∑i∈s, Real.log ‖f i z‖) ≤
      (1-(z.re-l)/(u-l))*A + ((z.re-l)/(u-l))*B := by
  have he : ∀w, (∏i∈s, ‖f i w‖) ≤ Real.exp (∑i∈s, Real.log ‖f i w‖) := by
    intro w
    rw [Real.exp_sum]
    exact Finset.prod_le_prod (fun i _ => norm_nonneg _) (fun i _ => Real.le_exp_log _)
  have h := finite_norm_product_three_lines s f hd hul hz hbound
    (fun w hw => (he w).trans (Real.exp_le_exp.mpr (hleft w hw)))
    (fun w hw => (he w).trans (Real.exp_le_exp.mpr (hright w hw)))
  have hp : 0 < ∏i∈s, ‖f i z‖ := Finset.prod_pos (fun i hi => norm_pos_iff.mpr (hne i hi))
  have hh := Real.log_le_log hp h
  rw [Real.log_prod _ _ (fun i hi => norm_ne_zero_iff.mpr (hne i hi)),
    Real.rpow_def_of_pos (Real.exp_pos A),Real.rpow_def_of_pos (Real.exp_pos B),
    Real.log_exp,Real.log_exp,← Real.exp_add,Real.log_exp] at hh
  nlinarith

end UAMO.ComplexGrowth

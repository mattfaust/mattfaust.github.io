import UAMO.PhysicalDOSReconstruction
import UAMO.CirclePotentialMean

noncomputable section
namespace UAMO
open MeasureTheory Matrix PhysicalRepresentation PhysicalWalk CircleDOS

namespace CircleDOS

def uniformCircleMeasure : Measure ℂ := angularParameterMeasure.map (logFourierChar 1)

instance uniformCircleMeasure_probability : IsProbabilityMeasure uniformCircleMeasure :=
  isProbabilityMeasure_map (logFourierChar_continuous 1).measurable.aemeasurable

theorem uniformCircleMeasure_ae_circle : ∀ᵐ z ∂uniformCircleMeasure,‖z‖=1 := by
  apply (ae_map_iff (logFourierChar_continuous 1).measurable.aemeasurable
    (isClosed_eq continuous_norm continuous_const).measurableSet).mpr
  exact ae_of_all _ (logFourierChar_norm 1)

theorem uniformCircleMeasure_moments (n : ℕ) :
    (∫ z:ℂ,z^n ∂uniformCircleMeasure)=if n=0 then 1 else 0 := by
  rw [uniformCircleMeasure]
  change (∫ z:ℂ,id z^n ∂Measure.map (logFourierChar 1) angularParameterMeasure)=_
  rw [integral_map (logFourierChar_continuous 1).measurable.aemeasurable
    (continuous_id.pow n).aestronglyMeasurable]
  change (∫ t in Set.Ioc (0:ℝ) 1,(logFourierChar 1 t)^n)=_
  rw [← intervalIntegral.integral_of_le (by norm_num : (0:ℝ)≤1)]
  simp only [logFourierChar_pow,one_mul]
  simpa using integral_logFourierChar (n:ℤ)

end CircleDOS

namespace PhysicalDOS

end PhysicalDOS
end UAMO

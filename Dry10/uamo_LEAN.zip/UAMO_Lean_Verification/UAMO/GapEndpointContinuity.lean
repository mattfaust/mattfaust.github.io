import UAMO.LogPotentialExtension
import UAMO.SeedGapMaximum
import Mathlib.Analysis.Convex.SpecificFunctions.Basic

noncomputable section
namespace UAMO
open Set Filter MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

theorem regularizedLogKernel_concaveOn_interval (n : ℕ) {a b x : ℝ}
    (hx : x ≤ a ∨ b ≤ x) :
    ConcaveOn ℝ (Icc a b) (fun E => regularizedLogKernel n (E - x)) := by
  refine ⟨convex_Icc a b, ?_⟩
  intro u hu v hv r s hr hs hrs
  have hw : r * u + s * v ∈ Icc a b := by
    simpa only [smul_eq_mul] using (convex_Icc a b) hu hv hr hs hrs
  have hdist : |r * u + s * v - x| + logRegularizationScale n =
      r * (|u - x| + logRegularizationScale n) +
        s * (|v - x| + logRegularizationScale n) := by
    rcases hx with hx | hx
    · rw [abs_of_nonneg (sub_nonneg.mpr (hx.trans hw.1)),
        abs_of_nonneg (sub_nonneg.mpr (hx.trans hu.1)),
        abs_of_nonneg (sub_nonneg.mpr (hx.trans hv.1))]
      nlinarith [congrArg (fun t : ℝ => t * x) hrs,
        congrArg (fun t : ℝ => t * logRegularizationScale n) hrs]
    · rw [abs_of_nonpos (sub_nonpos.mpr (hw.2.trans hx)),
        abs_of_nonpos (sub_nonpos.mpr (hu.2.trans hx)),
        abs_of_nonpos (sub_nonpos.mpr (hv.2.trans hx))]
      nlinarith [congrArg (fun t : ℝ => t * x) hrs,
        congrArg (fun t : ℝ => t * logRegularizationScale n) hrs]
  have hlog := strictConcaveOn_log_Ioi.concaveOn.2
    (show |u - x| + logRegularizationScale n ∈ Ioi (0 : ℝ) from
      add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n))
    (show |v - x| + logRegularizationScale n ∈ Ioi (0 : ℝ) from
      add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n)) hr hs hrs
  change r * Real.log (|u - x| + logRegularizationScale n) +
    s * Real.log (|v - x| + logRegularizationScale n) ≤
      Real.log (|r * u + s * v - x| + logRegularizationScale n)
  rw [hdist]
  simpa only [smul_eq_mul] using hlog

theorem scalarRegularizedLogPotential_concaveOn_gap
    (c α lam : ℝ) (n : ℕ) {a b : ℝ}
    (hgap : ∀ E ∈ Ioo a b, (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian c lam α)) :
    ConcaveOn ℝ (Icc a b) (fun E => scalarRegularizedLogPotential c α n (lam, E)) := by
  have hside (x : ScalarRealSpectrum c lam α) : (x : ℝ) ≤ a ∨ b ≤ (x : ℝ) := by
    by_cases hxa : (x : ℝ) ≤ a
    · exact Or.inl hxa
    · right
      by_contra hbx
      have hz := hgap (x : ℝ) ⟨lt_of_not_ge hxa, lt_of_not_ge hbx⟩
      have hs : ((x : ℝ) : ℂ) ∈ spectrum ℂ (scalarHamiltonian c lam α) := by
        exact (Set.ext_iff.mp (scalarRealSpectrum_eq_algebraSpectrum c lam α) (x : ℝ)).mpr
          x.property
      exact hs hz
  refine ⟨convex_Icc a b, ?_⟩
  intro u hu v hv r s hr hs hrs
  simp only [smul_eq_mul]
  rw [scalarRegularizedLogPotential_eq_spectralIntegral c α lam u n,
    scalarRegularizedLogPotential_eq_spectralIntegral c α lam v n,
    scalarRegularizedLogPotential_eq_spectralIntegral c α lam (r * u + s * v) n]
  calc
    r * (∫ x : ScalarRealSpectrum c lam α,
        regularizedLogKernel n (u - (x : ℝ)) ∂scalarSpectralMeasure c lam α) +
      s * (∫ x : ScalarRealSpectrum c lam α,
        regularizedLogKernel n (v - (x : ℝ)) ∂scalarSpectralMeasure c lam α) =
      ∫ x : ScalarRealSpectrum c lam α,
        r * regularizedLogKernel n (u - (x : ℝ)) +
          s * regularizedLogKernel n (v - (x : ℝ)) ∂scalarSpectralMeasure c lam α := by
      rw [integral_add
        ((scalar_regularizedLogKernel_integrable c α lam u n).const_mul r)
        ((scalar_regularizedLogKernel_integrable c α lam v n).const_mul s),
        integral_const_mul, integral_const_mul]
    _ ≤ ∫ x : ScalarRealSpectrum c lam α,
        regularizedLogKernel n (r * u + s * v - (x : ℝ))
          ∂scalarSpectralMeasure c lam α := by
      apply integral_mono
        (((scalar_regularizedLogKernel_integrable c α lam u n).const_mul r).add
          ((scalar_regularizedLogKernel_integrable c α lam v n).const_mul s))
        (scalar_regularizedLogKernel_integrable c α lam (r * u + s * v) n)
      intro x
      simpa only [smul_eq_mul] using
        (regularizedLogKernel_concaveOn_interval n (hside x)).2 hu hv hr hs hrs

theorem scalarRegularizedLogPotential_nonneg_on_gap
    (c φ r : ℝ) (n : ℕ) {l u E : ℝ} (hlu : l < u)
    (hgap : ∀ x ∈ Ioo l u, (x : ℂ) ∈ resolventSet ℂ (scalarHamiltonian c r φ))
    (hl : scalarTotalLogPotential c φ (r, l) = 0)
    (hu : scalarTotalLogPotential c φ (r, u) = 0) (hE : E ∈ Icc l u) :
    0 ≤ scalarRegularizedLogPotential c φ n (r, E) := by
  have hs : E ∈ segment ℝ l u := by rwa [segment_eq_Icc hlu.le]
  have h := (scalarRegularizedLogPotential_concaveOn_gap c φ r n hgap).ge_on_segment
    (show l ∈ Icc l u from ⟨le_rfl, hlu.le⟩)
    (show u ∈ Icc l u from ⟨hlu.le, le_rfl⟩) hs
  exact (le_min
    (scalarRegularizedLogPotential_nonneg_of_total_eq_zero c φ (r, l) hl n)
    (scalarRegularizedLogPotential_nonneg_of_total_eq_zero c φ (r, u) hu n)).trans h

theorem scalarLogPotential_nonneg_on_gap
    (a φ r : ℝ) {l u E : ℝ} (hlu : l < u)
    (hgap : ∀ x ∈ Ioo l u, (x : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hl : scalarTotalLogPotential a φ (r, l) = 0)
    (hu : scalarTotalLogPotential a φ (r, u) = 0) (hE : E ∈ Ioo l u) :
    0 ≤ scalarLogPotential a r φ E := by
  exact ge_of_tendsto (scalarRegularizedLogPotential_tendsto a φ r E (hgap E hE))
    (Eventually.of_forall fun n =>
      scalarRegularizedLogPotential_nonneg_on_gap a φ r n hlu hgap hl hu ⟨hE.1.le,hE.2.le⟩)

theorem scalarPositiveLogPotential_continuousAt_of_total_zero
    (a φ : ℝ) (p : ℝ × ℝ) (hp : scalarTotalLogPotential a φ p = 0) :
    ContinuousAt (scalarPositiveLogPotential a φ) p := by
  have hz := scalarPositiveLogPotential_eq_zero_of_total_eq_zero a φ p hp
  apply continuousAt_iff_lower_upperSemicontinuousAt.mpr
  refine ⟨?_, scalarPositiveLogPotential_upperSemicontinuous a φ p⟩
  intro c hc
  have hc0 : c < 0 := by simpa only [hz] using hc
  exact Eventually.of_forall fun q => hc0.trans_le (scalarPositiveLogPotential_nonneg a φ q)

theorem scalarPositiveLogPotential_continuousOn_gap
    (a φ r : ℝ) {l u : ℝ}
    (hgap : ∀ x ∈ Ioo l u, (x : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hl : scalarTotalLogPotential a φ (r, l) = 0)
    (hu : scalarTotalLogPotential a φ (r, u) = 0) :
    ContinuousOn (fun E => scalarPositiveLogPotential a φ (r, E)) (Icc l u) := by
  intro E hE
  by_cases hEl : E = l
  · subst E
    exact ((scalarPositiveLogPotential_continuousAt_of_total_zero a φ (r,l) hl).comp
      (continuousAt_const.prodMk continuousAt_id)).continuousWithinAt
  by_cases hEu : E = u
  · subst E
    exact ((scalarPositiveLogPotential_continuousAt_of_total_zero a φ (r,u) hu).comp
      (continuousAt_const.prodMk continuousAt_id)).continuousWithinAt
  have hEin : E ∈ Ioo l u :=
    ⟨lt_of_le_of_ne hE.1 (Ne.symm hEl), lt_of_le_of_ne hE.2 hEu⟩
  have hc : ContinuousAt (fun F => max 0 (scalarLogPotential a r φ F)) E := continuousAt_const.max
    (scalarLogPotential_energy_hasDerivAt a r φ E (hgap E hEin)).continuousAt
  apply ContinuousAt.continuousWithinAt
  apply hc.congr_of_eventuallyEq
  filter_upwards [isOpen_Ioo.mem_nhds hEin] with F hF
  exact scalarPositiveLogPotential_eq_max a φ r F (hgap F hF)

end UAMO

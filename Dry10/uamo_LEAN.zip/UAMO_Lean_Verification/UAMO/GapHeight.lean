import UAMO.TraceLogDerivative
import UAMO.HeightBounds
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.Analysis.Calculus.ContDiff.RCLike
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Analysis.Calculus.Deriv.Comp

noncomputable section

namespace UAMO.GapHeightTools

open Filter
open scoped Topology

theorem plane_linear_map_coordinates (D : (ℝ × ℝ) →L[ℝ] ℝ) (x y : ℝ) :
    D (x, y) = x * D (1, 0) + y * D (0, 1) := by
  have hp : (x, y) = x • ((1, 0) : ℝ × ℝ) + y • ((0, 1) : ℝ × ℝ) := by
    ext <;> simp
  rw [hp, map_add, map_smul, map_smul]
  rfl

def graphDerivative (D : (ℝ × ℝ) →L[ℝ] ℝ) : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ) :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).prod D

theorem graphDerivative_bijective (D : (ℝ × ℝ) →L[ℝ] ℝ)
    (hD : D (0, 1) ≠ 0) : Function.Bijective (graphDerivative D) := by
  constructor
  · rintro ⟨px, py⟩ ⟨qx, qy⟩ hpq
    change (px, D (px, py)) = (qx, D (qx, qy)) at hpq
    have hfst : px = qx := congrArg Prod.fst hpq
    have hsnd : D (px, py) = D (qx, qy) := congrArg Prod.snd hpq
    apply Prod.ext hfst
    rw [plane_linear_map_coordinates D px py,
      plane_linear_map_coordinates D qx qy, hfst] at hsnd
    exact mul_right_cancel₀ hD (add_left_cancel hsnd)
  · rintro ⟨u, v⟩
    refine ⟨(u, (v - u * D (1, 0)) / D (0, 1)), ?_⟩
    apply Prod.ext
    · rfl
    · change D (u, (v - u * D (1, 0)) / D (0, 1)) = v
      rw [plane_linear_map_coordinates, div_mul_cancel₀ _ hD]
      ring

def graphDerivativeEquiv (D : (ℝ × ℝ) →L[ℝ] ℝ) (hD : D (0, 1) ≠ 0) :
    (ℝ × ℝ) ≃L[ℝ] (ℝ × ℝ) :=
  ContinuousLinearEquiv.ofBijective (graphDerivative D)
    (LinearMap.ker_eq_bot.mpr (graphDerivative_bijective D hD).1)
    (LinearMap.range_eq_top.mpr (graphDerivative_bijective D hD).2)

@[simp] theorem graphDerivativeEquiv_coe (D : (ℝ × ℝ) →L[ℝ] ℝ)
    (hD : D (0, 1) ≠ 0) :
    (graphDerivativeEquiv D hD : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) = graphDerivative D := by
  apply ContinuousLinearEquiv.coe_ofBijective

theorem graphDerivativeEquiv_symm_apply (D : (ℝ × ℝ) →L[ℝ] ℝ)
    (hD : D (0, 1) ≠ 0) (u v : ℝ) :
    (graphDerivativeEquiv D hD).symm (u, v) =
      (u, (v - u * D (1, 0)) / D (0, 1)) := by
  apply (graphDerivativeEquiv D hD).injective
  rw [ContinuousLinearEquiv.apply_symm_apply]
  change (u, v) = (u, D (u, (v - u * D (1, 0)) / D (0, 1)))
  rw [plane_linear_map_coordinates, div_mul_cancel₀ _ hD]
  congr 1
  ring

theorem exists_local_zero_branch_differentiable
    {F : ℝ × ℝ → ℝ} {D : (ℝ × ℝ) → (ℝ × ℝ) →L[ℝ] ℝ} {lam m : ℝ}
    (hF : HasStrictFDerivAt F (D (lam, m)) (lam, m))
    (hzero : F (lam, m) = 0) (hD : D (lam, m) (0, 1) ≠ 0)
    (hnear : ∀ᶠ p in 𝓝 (lam, m),
      HasFDerivAt F (D p) p ∧ D p (0, 1) ≠ 0) :
    ∃ e : ℝ → ℝ,
      e lam = m ∧
      HasDerivAt e (-D (lam, m) (1, 0) / D (lam, m) (0, 1)) lam ∧
      ContinuousAt e lam ∧
      Tendsto (fun t => (t, e t)) (𝓝 lam) (𝓝 (lam, m)) ∧
      (∀ᶠ t in 𝓝 lam, F (t, e t) = 0 ∧
        HasDerivAt e (-D (t, e t) (1, 0) / D (t, e t) (0, 1)) t) ∧
      (∀ᶠ p in 𝓝 (lam, m), F p = 0 → p.2 = e p.1) := by
  let T : ℝ × ℝ → ℝ × ℝ := fun p => (p.1, F p)
  let J := graphDerivativeEquiv (D (lam, m)) hD
  have hT : HasStrictFDerivAt T (J : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) (lam, m) := by
    simpa only [J, graphDerivativeEquiv_coe, graphDerivative] using
      (ContinuousLinearMap.fst ℝ ℝ ℝ).hasStrictFDerivAt.prodMk hF
  let φ := hT.toPartialHomeomorph T
  let G : ℝ × ℝ → ℝ × ℝ := φ.symm
  let e : ℝ → ℝ := fun t => (G (t, 0)).2
  have hbase : T (lam, m) = (lam, 0) := by simp [T, hzero]
  have htarget : (lam, 0) ∈ φ.target := by
    simpa only [φ, hbase] using hT.image_mem_toPartialHomeomorph_target
  have hGbase : G (lam, 0) = (lam, m) := by
    simpa only [G, φ, ← hT.localInverse_def, hbase] using hT.localInverse_apply_image
  have hebase : e lam = m := congrArg Prod.snd hGbase
  have hGcont : ContinuousAt G (lam, 0) := φ.symm.continuousAt htarget
  have hGtend : Tendsto G (𝓝 (lam, 0)) (𝓝 (lam, m)) := by
    simpa only [hGbase] using hGcont.tendsto
  have hin : ContinuousAt (fun t : ℝ => (t, (0 : ℝ))) lam :=
    continuousAt_id.prodMk continuousAt_const
  have hecont : ContinuousAt e lam := by
    have hc : ContinuousAt (fun t : ℝ => G (t, 0)) lam :=
      hGcont.comp (f := fun t : ℝ => (t, 0)) hin
    exact hc.snd
  have hgraph : Tendsto (fun t => (t, e t)) (𝓝 lam) (𝓝 (lam, m)) := by
    simpa only [hebase] using tendsto_id.prodMk_nhds hecont
  have htargetNear : ∀ᶠ t in 𝓝 lam, (t, (0 : ℝ)) ∈ φ.target :=
    hin.eventually (φ.open_target.mem_nhds htarget)
  have hderivNear : ∀ᶠ t in 𝓝 lam,
      HasFDerivAt F (D (G (t, 0))) (G (t, 0)) ∧ D (G (t, 0)) (0, 1) ≠ 0 :=
    hin.eventually (hGtend.eventually hnear)
  have heproperties : ∀ᶠ t in 𝓝 lam, F (t, e t) = 0 ∧
      HasDerivAt e (-D (t, e t) (1, 0) / D (t, e t) (0, 1)) t := by
    filter_upwards [htargetNear, hderivNear] with t ht hd
    have hright : T (G (t, 0)) = (t, 0) := φ.right_inv ht
    have hfst : (G (t, 0)).1 = t := congrArg Prod.fst hright
    have hsnd : F (G (t, 0)) = 0 := congrArg Prod.snd hright
    have heq : (t, e t) = G (t, 0) := Prod.ext hfst.symm rfl
    constructor
    · rw [heq]
      exact hsnd
    · let Jt := graphDerivativeEquiv (D (G (t, 0))) hd.2
      have hTt : HasFDerivAt φ (Jt : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) (G (t, 0)) := by
        simpa only [φ, HasStrictFDerivAt.toPartialHomeomorph_coe, Jt,
          graphDerivativeEquiv_coe, graphDerivative] using
          (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.prodMk hd.1
      have hGt := φ.hasFDerivAt_symm ht hTt
      have hline := (hasDerivAt_id t).prodMk (hasDerivAt_const t (0 : ℝ))
      have hh := (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt t
        (hGt.comp_hasDerivAt t hline)
      change HasDerivAt e ((Jt.symm (1, 0)).2) t at hh
      simpa only [Jt, graphDerivativeEquiv_symm_apply, one_mul, zero_sub, heq] using hh
  have hederiv : HasDerivAt e (-D (lam, m) (1, 0) / D (lam, m) (0, 1)) lam := by
    simpa only [hebase] using heproperties.self_of_nhds.2
  have hunique : ∀ᶠ p in 𝓝 (lam, m), F p = 0 → p.2 = e p.1 := by
    filter_upwards [φ.open_source.mem_nhds hT.mem_toPartialHomeomorph_source] with p hp hz
    have hh : G (p.1, 0) = p := by
      simpa only [G, φ, HasStrictFDerivAt.toPartialHomeomorph_coe, T, hz] using φ.left_inv hp
    exact (congrArg Prod.snd hh).symm
  exact ⟨e, hebase, hederiv, hecont, hgraph, heproperties, hunique⟩

end UAMO.GapHeightTools

namespace UAMO
open Filter Set
open scoped Topology

def scalarJointPencil (a φ : ℝ) (p : ℝ × ℝ) : MagneticOperator :=
  p.2 • (1 : MagneticOperator) - scalarHamiltonian a p.1 φ

theorem scalarJointPencil_eq (a φ : ℝ) (p : ℝ × ℝ) :
    scalarJointPencil a φ p =
      algebraMap ℂ MagneticOperator (p.2 : ℂ) - scalarHamiltonian a p.1 φ := by
  simp only [scalarJointPencil, Algebra.algebraMap_eq_smul_one, Complex.coe_smul]

theorem scalarJointPencil_contDiff (a φ : ℝ) :
    ContDiff ℝ ⊤ (scalarJointPencil a φ) := by
  unfold scalarJointPencil
  simp_rw [scalarHamiltonian_polynomial]
  fun_prop

def scalarJointResolventDomain (a φ : ℝ) : Set (ℝ × ℝ) :=
  {p | (p.2 : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a p.1 φ)}

theorem scalarJointResolventDomain_isOpen (a φ : ℝ) :
    IsOpen (scalarJointResolventDomain a φ) := by
  have heq : scalarJointResolventDomain a φ =
      (scalarJointPencil a φ) ⁻¹' {A | IsUnit A} := by
    ext p
    simp only [scalarJointResolventDomain, mem_setOf_eq, mem_preimage,
      scalarJointPencil_eq, resolventSet]
  rw [heq]
  exact Units.isOpen.preimage (scalarJointPencil_contDiff a φ).continuous

def scalarJointGreen (a φ : ℝ) (p : ℝ × ℝ) : ℝ := scalarGreen a p.1 φ p.2

theorem scalarJointGreen_eq_trace (a φ : ℝ) (p : ℝ × ℝ) :
    scalarJointGreen a φ p = rootTraceReal (Ring.inverse (scalarJointPencil a φ p)) := by
  rw [scalarJointPencil_eq, rootTraceReal_apply, rootTrace_eq_inner]
  rfl

theorem scalarJointGreen_contDiffAt (a φ : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ scalarJointResolventDomain a φ) :
    ContDiffAt ℝ ⊤ (scalarJointGreen a φ) p := by
  have hu : IsUnit (scalarJointPencil a φ p) := by
    rw [scalarJointPencil_eq]
    exact hp
  have hi := contDiffAt_ringInverse ℝ (n := (⊤ : WithTop ℕ∞)) hu.unit
  rw [hu.unit_spec] at hi
  have h := rootTraceReal.contDiff.contDiffAt.comp p
    (hi.comp p (scalarJointPencil_contDiff a φ).contDiffAt)
  simpa only [Function.comp_def, ← scalarJointGreen_eq_trace] using h

def scalarJointGreenDifferential (a φ : ℝ) (p : ℝ × ℝ) : (ℝ × ℝ) →L[ℝ] ℝ :=
  fderiv ℝ (scalarJointGreen a φ) p

theorem scalarJointGreen_hasStrictFDerivAt (a φ : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ scalarJointResolventDomain a φ) :
    HasStrictFDerivAt (scalarJointGreen a φ) (scalarJointGreenDifferential a φ p) p :=
  (scalarJointGreen_contDiffAt a φ p hp).hasStrictFDerivAt (by simp)

theorem scalarJointGreen_energy_partial (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    scalarJointGreenDifferential a φ (r,E) (0,1) =
      deriv (scalarGreen a r φ) E := by
  have h := (scalarJointGreen_hasStrictFDerivAt a φ (r,E) hE).hasFDerivAt.comp_hasDerivAt E
    ((hasDerivAt_const E r).prodMk (hasDerivAt_id E))
  exact h.deriv.symm

theorem scalarJointGreen_energy_partial_ne_zero (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    scalarJointGreenDifferential a φ (r,E) (0,1) ≠ 0 := by
  rw [scalarJointGreen_energy_partial a r φ E hE]
  exact ne_of_lt (scalarGreen_energy_deriv_neg a r φ E hE)

theorem scalarJointGreenDifferential_continuousAt (a φ : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ scalarJointResolventDomain a φ) :
    ContinuousAt (scalarJointGreenDifferential a φ) p := by
  have hc : ContDiffOn ℝ ⊤ (scalarJointGreen a φ) (scalarJointResolventDomain a φ) := by
    intro q hq
    exact (scalarJointGreen_contDiffAt a φ q hq).contDiffWithinAt
  exact (hc.continuousOn_fderiv_of_isOpen (scalarJointResolventDomain_isOpen a φ)
    (by simp)).continuousAt ((scalarJointResolventDomain_isOpen a φ).mem_nhds hp)

def scalarBranchSlope (a φ : ℝ) (p : ℝ × ℝ) : ℝ :=
  -scalarJointGreenDifferential a φ p (1,0) / scalarJointGreenDifferential a φ p (0,1)

theorem scalarBranchSlope_continuousAt (a φ : ℝ) (p : ℝ × ℝ)
    (hp : p ∈ scalarJointResolventDomain a φ) :
    ContinuousAt (scalarBranchSlope a φ) p := by
  have hc := scalarJointGreenDifferential_continuousAt a φ p hp
  exact ((ContinuousLinearMap.apply ℝ ℝ (1,0)).continuous.continuousAt.comp hc).neg.div
    ((ContinuousLinearMap.apply ℝ ℝ (0,1)).continuous.continuousAt.comp hc)
    (scalarJointGreen_energy_partial_ne_zero a p.1 φ p.2 hp)

theorem scalarGreen_local_zero_branch (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hzero : scalarGreen a r φ E = 0) :
    ∃ e : ℝ → ℝ,
      e r = E ∧ HasDerivAt e (scalarBranchSlope a φ (r,E)) r ∧
      ContinuousAt e r ∧ Tendsto (fun t => (t,e t)) (𝓝 r) (𝓝 (r,E)) ∧
      (∀ᶠ t in 𝓝 r,
        (e t : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t φ) ∧
        scalarGreen a t φ (e t) = 0 ∧ HasDerivAt e (scalarBranchSlope a φ (t,e t)) t) ∧
      (∀ᶠ p in 𝓝 (r,E), scalarGreen a p.1 φ p.2 = 0 → p.2 = e p.1) := by
  have hdomain : ∀ᶠ p in 𝓝 (r,E), p ∈ scalarJointResolventDomain a φ :=
    (scalarJointResolventDomain_isOpen a φ).mem_nhds hE
  have hnear : ∀ᶠ p in 𝓝 (r,E),
      HasFDerivAt (scalarJointGreen a φ) (scalarJointGreenDifferential a φ p) p ∧
        scalarJointGreenDifferential a φ p (0,1) ≠ 0 := by
    filter_upwards [hdomain] with p hp
    exact ⟨(scalarJointGreen_hasStrictFDerivAt a φ p hp).hasFDerivAt,
      scalarJointGreen_energy_partial_ne_zero a p.1 φ p.2 hp⟩
  obtain ⟨e, he, hd, hc, hg, hn, hu⟩ :=
    GapHeightTools.exists_local_zero_branch_differentiable
      (scalarJointGreen_hasStrictFDerivAt a φ (r,E) hE) hzero
      (scalarJointGreen_energy_partial_ne_zero a r φ E hE) hnear
  refine ⟨e, he, hd, hc, hg, ?_, hu⟩
  filter_upwards [hn, hg.eventually hdomain] with t ht hres
  exact ⟨hres, ht.1, ht.2⟩

theorem scalarGreen_local_c1_zero_branch (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hzero : scalarGreen a r φ E = 0) :
    ∃ e d : ℝ → ℝ,
      e r = E ∧ ContinuousAt e r ∧ ContinuousAt d r ∧ HasDerivAt e (d r) r ∧
      (∀ᶠ t in 𝓝 r,
        (e t : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t φ) ∧
        scalarGreen a t φ (e t) = 0 ∧ HasDerivAt e (d t) t ∧ ContinuousAt d t) := by
  obtain ⟨e, he, hd, hc, hg, hn, _⟩ := scalarGreen_local_zero_branch a r φ E hE hzero
  refine ⟨e, fun t => scalarBranchSlope a φ (t,e t), he, hc, ?_, ?_, ?_⟩
  · change Tendsto _ _ (𝓝 (scalarBranchSlope a φ (r,e r)))
    rw [he]
    exact Filter.Tendsto.comp (scalarBranchSlope_continuousAt a φ (r,E) hE) hg
  · simpa only [he] using hd
  · filter_upwards [hn] with t ht
    refine ⟨ht.1, ht.2.1, ht.2.2, ?_⟩
    exact ContinuousAt.comp (f := fun s : ℝ => (s,e s))
      (scalarBranchSlope_continuousAt a φ (t,e t) ht.1)
      (continuousAt_id.prodMk ht.2.2.continuousAt)

local instance (φ : ℝ) : NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)

local instance (φ : ℝ) : Module ℝ (magneticAlgebra φ) :=
  @Algebra.toModule ℝ (magneticAlgebra φ) _ _
    (magneticAlgebra_realNormedAlgebra φ).toAlgebra

local instance (φ : ℝ) : Nontrivial (magneticAlgebra φ) := by
  refine ⟨⟨0, 1, ?_⟩⟩
  intro h
  have ht := congrArg (magneticTraceReal φ) h
  have hz : (0 : ℝ) = 1 := by
    simpa only [map_zero, magneticTraceReal_one] using ht
  exact zero_ne_one hz

local instance (φ : ℝ) : ContinuousSMul ℝ (magneticAlgebra φ) := by
  constructor
  apply continuous_induced_rng.mpr
  change Continuous (fun p : ℝ × magneticAlgebra φ => p.1 • (p.2 : MagneticOperator))
  exact continuous_fst.smul (continuous_subtype_val.comp continuous_snd)

set_option maxHeartbeats 1000000 in

theorem scalarLogPotential_branch_hasDerivAt (a φ : ℝ) (e d : ℝ → ℝ) (r : ℝ)
    (hE : (e r : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hd : ∀ᶠ t in 𝓝 r, HasDerivAt e (d t) t) (hc : ContinuousAt d r) :
    HasDerivAt (fun t => scalarLogPotential a t φ (e t))
      (d r * scalarGreen a r φ (e r) +
        deriv (fun t => scalarLogPotential a t φ (e r)) r) r := by
  have hp : ∀ᶠ t in 𝓝 r, HasDerivAt (fun s => scalarAlgebraPencil a s φ (e s))
      (d t • (1 : magneticAlgebra φ) - scalarAlgebraHamiltonianDerivative a t φ) t := by
    filter_upwards [hd] with t ht
    exact (ht.smul_const (1 : magneticAlgebra φ)).sub
      (scalarAlgebraHamiltonian_hasDerivAt a t φ)
  have h := TraceCalculus.half_trace_cfc_log_sq_hasDerivAt (magneticTraceReal φ)
    (magneticTraceReal_cyclic φ) (fun t => scalarAlgebraPencil a t φ (e t))
    (fun t => d t • (1 : magneticAlgebra φ) - scalarAlgebraHamiltonianDerivative a t φ) r
    hp (Filter.Eventually.of_forall (fun t => scalarAlgebraPencil_isSelfAdjoint a t φ (e t)))
    ((hc.smul continuousAt_const).sub
      (scalarAlgebraHamiltonianDerivative_continuous a φ).continuousAt)
    (scalarAlgebraPencil_isUnit a r φ (e r) hE)
  have ht : magneticTraceReal φ (Ring.inverse (scalarAlgebraPencil a r φ (e r)) *
      (d r • (1 : magneticAlgebra φ) - scalarAlgebraHamiltonianDerivative a r φ)) =
      d r * scalarGreen a r φ (e r) +
        deriv (fun t => scalarLogPotential a t φ (e r)) r := by
    change rootTraceReal
      (((Ring.inverse (scalarAlgebraPencil a r φ (e r)) : magneticAlgebra φ) : MagneticOperator) *
        (d r • (1 : MagneticOperator) - scalarHamiltonianDerivative a r φ)) = _
    rw [scalarAlgebraPencil_inverse_coe a r φ (e r) hE,
      mul_sub, mul_smul_comm, mul_one, map_sub, rootTraceReal.map_smul (d r),
      (scalarLogPotential_coupling_hasDerivAt a r φ (e r) hE).deriv]
    have hg : rootTraceReal (resolvent (scalarHamiltonian a r φ) (e r : ℂ)) =
        scalarGreen a r φ (e r) := by
      rw [rootTraceReal_apply, rootTrace_eq_inner]
      rfl
    rw [hg]
    rfl
  simpa only [scalarLogPotential, ht] using h

theorem scalarLogPotential_centered_branch_hasDerivAt (a φ : ℝ) (e d : ℝ → ℝ) (r : ℝ)
    (hE : (e r : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hzero : scalarGreen a r φ (e r) = 0)
    (hd : ∀ᶠ t in 𝓝 r, HasDerivAt e (d t) t) (hc : ContinuousAt d r) :
    HasDerivAt (fun t => scalarLogPotential a t φ (e t))
      (deriv (fun t => scalarLogPotential a t φ (e r)) r) r := by
  simpa only [hzero, mul_zero, zero_add] using
    scalarLogPotential_branch_hasDerivAt a φ e d r hE hd hc

theorem scalarLogPotential_centered_branch_radial_bound (a α : ℝ) (e d : ℝ → ℝ) (r : ℝ)
    (hα : Irrational α)
    (hE : (e r : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r (Real.pi * α)))
    (hzero : scalarGreen a r (Real.pi * α) (e r) = 0)
    (hd : ∀ᶠ t in 𝓝 r, HasDerivAt e (d t) t) (hc : ContinuousAt d r) :
    r * deriv (fun t => scalarLogPotential a t (Real.pi * α) (e t)) r ∈ Set.Icc (0 : ℝ) 2 := by
  rw [(scalarLogPotential_centered_branch_hasDerivAt a (Real.pi * α) e d r hE hzero hd hc).deriv]
  exact actual_scalarLogPotential_radial_derivative_bound a r α (e r) hα hE hzero

theorem scalar_local_gap_height_branch (a r α E : ℝ) (hα : Irrational α)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r (Real.pi * α)))
    (hzero : scalarGreen a r (Real.pi * α) E = 0) :
    ∃ (s : Set ℝ) (e d : ℝ → ℝ), IsOpen s ∧ r ∈ s ∧ e r = E ∧
      ∀ t ∈ s,
        (e t : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t (Real.pi * α)) ∧
        scalarGreen a t (Real.pi * α) (e t) = 0 ∧
        HasDerivAt e (d t) t ∧ ContinuousAt d t ∧
        HasDerivAt (fun v => scalarLogPotential a v (Real.pi * α) (e v))
          (deriv (fun v => scalarLogPotential a v (Real.pi * α) (e t)) t) t ∧
        t * deriv (fun v => scalarLogPotential a v (Real.pi * α) (e v)) t ∈ Set.Icc (0 : ℝ) 2 := by
  obtain ⟨e,d,he,_,_,_,hn⟩ := scalarGreen_local_c1_zero_branch a r (Real.pi * α) E hE hzero
  obtain ⟨s,hs,hopen,hr⟩ := mem_nhds_iff.mp hn
  refine ⟨s,e,d,hopen,hr,he,?_⟩
  intro t ht
  have h := hs ht
  have hd : ∀ᶠ v in 𝓝 t, HasDerivAt e (d v) v := by
    filter_upwards [hopen.mem_nhds ht] with v hv
    exact (hs hv).2.2.1
  exact ⟨h.1,h.2.1,h.2.2.1,h.2.2.2,
    scalarLogPotential_centered_branch_hasDerivAt a (Real.pi * α) e d t h.1 h.2.1 hd h.2.2.2,
    scalarLogPotential_centered_branch_radial_bound a α e d t hα h.1 h.2.1 hd h.2.2.2⟩

theorem scalar_gap_height_bounds_on_branch (a α : ℝ) (e d : ℝ → ℝ)
    {s : Set ℝ} (hs : IsOpen s) (hα : Irrational α)
    (he : ∀ t ∈ s, HasDerivAt e (d t) t)
    (hd : ContinuousOn d s)
    (hres : ∀ t ∈ s, (e t : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t (Real.pi * α)))
    (hcenter : ∀ t ∈ s, scalarGreen a t (Real.pi * α) (e t) = 0)
    {r₀ r₁ : ℝ} (hr₀ : 0 < r₀) (hr : r₀ ≤ r₁) (hI : Icc r₀ r₁ ⊆ s) :
    scalarLogPotential a r₀ (Real.pi * α) (e r₀) ≤
      scalarLogPotential a r₁ (Real.pi * α) (e r₁) ∧
    scalarLogPotential a r₁ (Real.pi * α) (e r₁) ≤
      scalarLogPotential a r₀ (Real.pi * α) (e r₀) + 2 * Real.log (r₁ / r₀) := by
  let h : ℝ → ℝ := fun t => scalarLogPotential a t (Real.pi * α) (e t)
  have hdiff (t : ℝ) (ht : t ∈ s) : HasDerivAt h (deriv h t) t := by
    have he' : ∀ᶠ v in 𝓝 t, HasDerivAt e (d v) v := by
      filter_upwards [hs.mem_nhds ht] with v hv
      exact he v hv
    exact (scalarLogPotential_centered_branch_hasDerivAt a (Real.pi * α) e d t
      (hres t ht) (hcenter t ht) he' (hd.continuousAt (hs.mem_nhds ht))).differentiableAt.hasDerivAt
  apply height_bounds_of_radial_derivative h (deriv h) hr₀ hr
  · intro t ht
    exact (hdiff t (hI ht)).continuousAt.continuousWithinAt
  · intro t ht
    exact hdiff t (hI (Ioo_subset_Icc_self ht))
  · intro t ht
    have hts := hI (Ioo_subset_Icc_self ht)
    have he' : ∀ᶠ v in 𝓝 t, HasDerivAt e (d v) v := by
      filter_upwards [hs.mem_nhds hts] with v hv
      exact he v hv
    exact scalarLogPotential_centered_branch_radial_bound a α e d t hα
      (hres t hts) (hcenter t hts) he' (hd.continuousAt (hs.mem_nhds hts))

end UAMO

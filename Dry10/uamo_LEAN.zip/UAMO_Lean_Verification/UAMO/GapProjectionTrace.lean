import UAMO.CFCParameterContinuity
import UAMO.ScalarSpectralMeasure
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.Normed.Ring.Units
import Mathlib.Topology.LocallyConstant.Algebra

noncomputable section
namespace UAMO
open Filter Set MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

section NearbyProjections
variable {A : Type*} [NormedRing A] [StarRing A] [CStarRing A]
  [CompleteSpace A] [NormedAlgebra ℝ A]

def gapProjectionIntertwiner (P Q : A) : A := Q*P+(1-Q)*(1-P)

omit [CStarRing A] [CompleteSpace A] [NormedAlgebra ℝ A] in
theorem gapProjectionReflection_unitary (P : A) (hs : IsSelfAdjoint P) (hp : P*P=P) :
    P+P-1 ∈ unitary A := by
  have hstar : star (P+P-1) = P+P-1 := by simp only [star_sub, star_add, hs.star_eq, star_one]
  have hsq : (P+P-1)*(P+P-1) = 1 := by
    simp only [sub_mul, mul_sub, add_mul, mul_add, hp, one_mul, mul_one]
    abel
  exact unitary.mem_iff.mpr ⟨by rw [hstar,hsq], by rw [hstar,hsq]⟩

omit [StarRing A] [CStarRing A] [CompleteSpace A] [NormedAlgebra ℝ A] in
theorem gapProjectionIntertwiner_sub_one (P Q : A) (hp : P*P=P) :
    gapProjectionIntertwiner P Q-1 = (Q-P)*(P+P-1) := by
  simp only [gapProjectionIntertwiner, sub_mul, mul_sub, mul_add, hp, one_mul, mul_one]
  abel

omit [NormedAlgebra ℝ A] in
theorem gapProjectionIntertwiner_isUnit (P Q : A) (hs : IsSelfAdjoint P)
    (hp : P*P=P) (hclose : ‖P-Q‖ < 1) : IsUnit (gapProjectionIntertwiner P Q) := by
  have hn : ‖1-gapProjectionIntertwiner P Q‖ < 1 := by
    rw [norm_sub_rev, gapProjectionIntertwiner_sub_one P Q hp,
      CStarRing.norm_mul_mem_unitary _ (gapProjectionReflection_unitary P hs hp), norm_sub_rev]
    exact hclose
  simpa only [sub_sub_cancel] using isUnit_one_sub_of_norm_lt_one hn

omit [StarRing A] [CStarRing A] [CompleteSpace A] [NormedAlgebra ℝ A] in
theorem gapProjectionIntertwiner_intertwines (P Q : A) (hp : P*P=P) (hq : Q*Q=Q) :
    Q*gapProjectionIntertwiner P Q = gapProjectionIntertwiner P Q*P := by
  have hq0 : Q*(1-Q)=0 := by rw [mul_sub,mul_one,hq,sub_self]
  have hp0 : (1-P)*P=0 := by rw [sub_mul,one_mul,hp,sub_self]
  calc
    _ = Q*P := by simp only [gapProjectionIntertwiner,mul_add,← mul_assoc,hq,hq0,zero_mul,add_zero]
    _ = _ := by simp only [gapProjectionIntertwiner,add_mul,mul_assoc,hp,hp0,mul_zero,add_zero]

theorem trace_eq_of_nearby_projections (trace : A →L[ℝ] ℝ)
    (hcyclic : ∀ X Y, trace (X*Y)=trace (Y*X))
    (P Q : A) (hs : IsSelfAdjoint P) (hp : P*P=P) (hq : Q*Q=Q)
    (hclose : ‖P-Q‖ < 1) : trace P=trace Q := by
  let T := gapProjectionIntertwiner P Q
  have ht : IsUnit T := gapProjectionIntertwiner_isUnit P Q hs hp hclose
  have hinter : Q*T=T*P := gapProjectionIntertwiner_intertwines P Q hp hq
  symm
  calc
    trace Q = trace ((Q*T)*Ring.inverse T) := by rw [mul_assoc,Ring.mul_inverse_cancel T ht,mul_one]
    _ = trace ((T*P)*Ring.inverse T) := by rw [hinter]
    _ = trace (Ring.inverse T*(T*P)) := hcyclic _ _
    _ = trace P := by rw [← mul_assoc,Ring.inverse_mul_cancel T ht,one_mul]

theorem trace_projection_eventually_eq {X : Type*} [TopologicalSpace X]
    (trace : A →L[ℝ] ℝ) (hcyclic : ∀ X Y, trace (X*Y)=trace (Y*X))
    (P : X → A) (x : X) (hc : ContinuousAt P x)
    (hs : IsSelfAdjoint (P x)) (hp : ∀ᶠ y in 𝓝 x, P y*P y=P y) :
    ∀ᶠ y in 𝓝 x, trace (P y)=trace (P x) := by
  have hnear : ∀ᶠ y in 𝓝 x, ‖P x-P y‖ < 1 := by
    have hcont : ContinuousAt (fun y => ‖P x-P y‖) x := (continuousAt_const.sub hc).norm
    simpa only [sub_self,norm_zero] using hcont.eventually (gt_mem_nhds (by simp : ‖P x-P x‖ < 1))
  filter_upwards [hp,hnear] with y hy hclose
  exact (trace_eq_of_nearby_projections trace hcyclic (P x) (P y) hs hp.self_of_nhds hy hclose).symm
end NearbyProjections

local instance gapTrace_realNormedSpace (φ : ℝ) : NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)
local instance gapTrace_realModule (φ : ℝ) : Module ℝ (magneticAlgebra φ) :=
  @Algebra.toModule ℝ (magneticAlgebra φ) _ _ (magneticAlgebra_realNormedAlgebra φ).toAlgebra

local instance gapTrace_continuousSMul (φ : ℝ) : ContinuousSMul ℝ (magneticAlgebra φ) := by
  constructor
  apply continuous_induced_rng.mpr
  change Continuous (fun p : ℝ × magneticAlgebra φ => p.1 • (p.2 : MagneticOperator))
  exact continuous_fst.smul (continuous_subtype_val.comp continuous_snd)
local instance gapTrace_nontrivial (φ : ℝ) : Nontrivial (magneticAlgebra φ) := by
  apply nontrivial_of_ne (0 : magneticAlgebra φ) 1
  intro h
  have hh := congrArg (magneticTraceReal φ) h
  exact zero_ne_one (by simpa only [map_zero,magneticTraceReal_one] using hh)

def scalarLowerSpectrum (a r φ energy : ℝ) : Set (ScalarRealSpectrum a r φ) :=
  {x | (x : ℝ) < energy}

theorem resolvent_energy_not_mem_scalarRealSpectrum (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    energy ∉ spectrum ℝ (scalarAlgebraHamiltonian a r φ) := by
  apply spectrum.not_mem_iff.mpr
  simpa only [scalarAlgebraPencil, Algebra.algebraMap_eq_smul_one] using
    scalarAlgebraPencil_isUnit a r φ energy hm

theorem scalarLowerSpectrum_isClopen (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    IsClopen (scalarLowerSpectrum a r φ energy) := by
  have hne (x : ScalarRealSpectrum a r φ) : (x : ℝ) ≠ energy := by
    intro h
    exact resolvent_energy_not_mem_scalarRealSpectrum a r φ energy hm (h ▸ x.property)
  have hset : scalarLowerSpectrum a r φ energy =
      {x : ScalarRealSpectrum a r φ | (x : ℝ) ≤ energy} := by
    ext x
    change ((x : ℝ) < energy) ↔ (x : ℝ) ≤ energy
    exact ⟨fun h => h.le, fun h => lt_of_le_of_ne h (hne x)⟩
  refine ⟨?_, isOpen_lt continuous_subtype_val continuous_const⟩
  rw [hset]
  exact isClosed_le continuous_subtype_val continuous_const

def scalarLowerSpectrumIndicator (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    C(ScalarRealSpectrum a r φ, ℝ) :=
  (LocallyConstant.charFn ℝ (scalarLowerSpectrum_isClopen a r φ energy hm)).toContinuousMap

@[simp] theorem scalarLowerSpectrumIndicator_apply (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (x : ScalarRealSpectrum a r φ) :
    scalarLowerSpectrumIndicator a r φ energy hm x = if (x : ℝ) < energy then 1 else 0 := by
  rfl

def scalarGapProjection (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    magneticAlgebra φ :=
  cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)
    (scalarLowerSpectrumIndicator a r φ energy hm)

theorem scalarGapProjection_idempotent (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    scalarGapProjection a r φ energy hm * scalarGapProjection a r φ energy hm =
      scalarGapProjection a r φ energy hm := by
  unfold scalarGapProjection
  rw [← map_mul]
  congr 1
  ext x
  simp only [ContinuousMap.mul_apply, scalarLowerSpectrumIndicator_apply]
  split_ifs <;> norm_num

theorem scalarGapProjection_trace_eq_spectralMass (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    magneticTraceReal φ (scalarGapProjection a r φ energy hm) =
      (scalarSpectralMeasure a r φ (scalarLowerSpectrum a r φ energy)).toReal := by
  rw [scalarGapProjection, ← scalarSpectralMeasure_integral]
  change (∫ x, (scalarLowerSpectrum a r φ energy).indicator 1 x
    ∂scalarSpectralMeasure a r φ) = _
  simpa only [measureReal_def] using
    (integral_indicator_one (μ := scalarSpectralMeasure a r φ)
      (scalarLowerSpectrum_isClopen a r φ energy hm).isClosed.measurableSet)

theorem scalarGapProjection_trace_eq_realSpectralMass (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    magneticTraceReal φ (scalarGapProjection a r φ energy hm) =
      (scalarRealSpectralMeasure a r φ (Iio energy)).toReal := by
  rw [scalarGapProjection_trace_eq_spectralMass a r φ energy hm,
    scalarRealSpectralMeasure, Measure.map_apply continuous_subtype_val.measurable measurableSet_Iio]
  rfl

def scalarGapCutoff (l u x : ℝ) : ℝ := max 0 (min 1 ((u-x)/(u-l)))

theorem continuous_scalarGapCutoff (l u : ℝ) : Continuous (scalarGapCutoff l u) :=
  continuous_const.max (continuous_const.min
    ((continuous_const.sub continuous_id).div_const (u-l)))

theorem scalarGapCutoff_eq_one {l u x : ℝ} (hlu : l<u) (hx : x≤l) :
    scalarGapCutoff l u x=1 := by
  have hd : 1≤(u-x)/(u-l) := (le_div_iff₀ (sub_pos.mpr hlu)).mpr (by linarith)
  simp [scalarGapCutoff,min_eq_left hd]

theorem scalarGapCutoff_eq_zero {l u x : ℝ} (hlu : l<u) (hx : u≤x) :
    scalarGapCutoff l u x=0 := by
  have hd : (u-x)/(u-l)≤0 := div_nonpos_of_nonpos_of_nonneg
    (sub_nonpos.mpr hx) (sub_pos.mpr hlu).le
  rw [scalarGapCutoff,min_eq_right (hd.trans zero_le_one),max_eq_left hd]

theorem scalarGapProjection_eq_cutoff (a r φ E l u : ℝ)
    (hz : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hE : E∈Ioo l u)
    (hgap : ∀ x∈Ioo l u, (x : ℂ)∈resolventSet ℂ (scalarHamiltonian a r φ)) :
    scalarGapProjection a r φ E hz=cfc (scalarGapCutoff l u) (scalarAlgebraHamiltonian a r φ) := by
  have hlu : l<u := hE.1.trans hE.2
  have havoid (x : ScalarRealSpectrum a r φ) : (x : ℝ)≤l ∨ u≤(x : ℝ) := by
    by_cases hx : (x : ℝ)≤l
    · exact Or.inl hx
    · right
      by_contra hu
      exact resolvent_energy_not_mem_scalarRealSpectrum a r φ x
        (hgap x ⟨lt_of_not_ge hx,lt_of_not_ge hu⟩) x.property
  rw [scalarGapProjection,cfc_apply (scalarGapCutoff l u)
    (scalarAlgebraHamiltonian a r φ) (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)
    (continuous_scalarGapCutoff l u).continuousOn]
  congr 1
  ext x
  change scalarLowerSpectrumIndicator a r φ E hz x=scalarGapCutoff l u x
  rcases havoid x with hx|hx
  · rw [scalarLowerSpectrumIndicator_apply,if_pos (hx.trans_lt hE.1),scalarGapCutoff_eq_one hlu hx]
  · rw [scalarLowerSpectrumIndicator_apply,if_neg (not_lt_of_ge (hE.2.le.trans hx)),scalarGapCutoff_eq_zero hlu hx]

theorem continuous_algebraMagneticPair (φ : ℝ) (ν : MagneticSite) :
    Continuous (algebraMagneticPair φ ν) := by
  unfold algebraMagneticPair
  apply Continuous.subtype_mk
  unfold magneticPair
  fun_prop

theorem continuousAt_scalarAlgebraHamiltonian_joint (φ : ℝ) (p : ℝ×ℝ) (ha : p.1≠0) :
    ContinuousAt (fun q : ℝ×ℝ => scalarAlgebraHamiltonian q.1 q.2 φ) p := by
  have hdiag : ContinuousAt (fun q : ℝ×ℝ => diagonalHopping q.1 φ) p := by
    have hc : ContinuousAt (fun q : ℝ×ℝ => (q.1 : ℂ)) p := by fun_prop
    have hi := hc.inv₀ (Complex.ofReal_ne_zero.mpr ha)
    unfold diagonalHopping
    exact (hi.mul continuousAt_const).sub (hc.mul continuousAt_const)
  unfold scalarAlgebraHamiltonian
  exact (continuousAt_const.add (continuous_snd.continuousAt.smul
    ((continuous_algebraMagneticPair φ (1,1)).continuousAt.comp hdiag))).add
      ((continuous_snd.continuousAt.pow 2).smul continuousAt_const)

def scalarParameterResolventDomain (φ : ℝ) : Set ((ℝ×ℝ)×ℝ) :=
  {p | p.1.1≠0 ∧ (p.2 : ℂ)∈resolventSet ℂ (scalarHamiltonian p.1.1 p.1.2 φ)}

theorem scalarParameterResolventDomain_isOpen (φ : ℝ) :
    IsOpen (scalarParameterResolventDomain φ) := by
  apply isOpen_iff_mem_nhds.mpr
  intro p hp
  have hH := (continuousAt_scalarAlgebraHamiltonian_joint φ p.1 hp.1).comp continuous_fst.continuousAt
  have hP : ContinuousAt (fun q : (ℝ×ℝ)×ℝ => scalarAlgebraPencil q.1.1 q.1.2 φ q.2) p :=
    (continuous_snd.continuousAt.smul continuousAt_const).sub hH
  have hunit := hP.eventually (Units.isOpen.mem_nhds
    (scalarAlgebraPencil_isUnit p.1.1 p.1.2 φ p.2 hp.2))
  have hne : ∀ᶠ q : (ℝ×ℝ)×ℝ in 𝓝 p, q.1.1≠0 :=
    (continuous_fst.comp continuous_fst).continuousAt.eventually (isOpen_ne.mem_nhds hp.1)
  filter_upwards [hne,hunit] with q hq hu
  refine ⟨hq,?_⟩
  have hh := (magneticAlgebra φ).coe_isUnit.mpr hu
  simpa only [scalarAlgebraPencil_coe] using hh

theorem scalar_common_gap_neighborhood (φ : ℝ) (p : (ℝ×ℝ)×ℝ)
    (hp : p∈scalarParameterResolventDomain φ) :
    ∃ l u : ℝ, p.2∈Ioo l u ∧ ∀ᶠ q in 𝓝 p, q.2∈Ioo l u ∧
      ∀ x∈Ioo l u, (x : ℂ)∈resolventSet ℂ (scalarHamiltonian q.1.1 q.1.2 φ) := by
  obtain ⟨s,hs,t,ht,hst⟩ := mem_nhds_prod_iff.mp ((scalarParameterResolventDomain_isOpen φ).mem_nhds hp)
  obtain ⟨l,u,hpI,hIt⟩ := mem_nhds_iff_exists_Ioo_subset.mp ht
  refine ⟨l,u,hpI,?_⟩
  have hs' : ∀ᶠ q : (ℝ×ℝ)×ℝ in 𝓝 p, q.1∈s := continuous_fst.continuousAt.eventually hs
  have ht' : ∀ᶠ q : (ℝ×ℝ)×ℝ in 𝓝 p, q.2∈Ioo l u :=
    continuous_snd.continuousAt.eventually (isOpen_Ioo.mem_nhds hpI)
  filter_upwards [hs',ht'] with q hqs hqt
  refine ⟨hqt,?_⟩
  intro x hx
  have hh : (q.1,x) ∈ scalarParameterResolventDomain φ := hst ⟨hqs,hIt hx⟩
  exact hh.2

theorem scalarGapProjection_trace_eventually_eq (a r φ E : ℝ) (ha : a≠0)
    (hz : (E : ℂ)∈resolventSet ℂ (scalarHamiltonian a r φ)) :
    ∀ᶠ q : (ℝ×ℝ)×ℝ in 𝓝 ((a,r),E),
      ∃ hq : (q.2 : ℂ)∈resolventSet ℂ (scalarHamiltonian q.1.1 q.1.2 φ),
        magneticTraceReal φ (scalarGapProjection q.1.1 q.1.2 φ q.2 hq)=
          magneticTraceReal φ (scalarGapProjection a r φ E hz) := by
  let p : (ℝ×ℝ)×ℝ := ((a,r),E)
  obtain ⟨l,u,hpI,hnear⟩ := scalar_common_gap_neighborhood φ p ⟨ha,hz⟩
  let P := fun q : (ℝ×ℝ)×ℝ => cfc (scalarGapCutoff l u) (scalarAlgebraHamiltonian q.1.1 q.1.2 φ)
  have hH : ContinuousAt (fun q : (ℝ×ℝ)×ℝ => scalarAlgebraHamiltonian q.1.1 q.1.2 φ) p :=
    (continuousAt_scalarAlgebraHamiltonian_joint φ p.1 ha).comp continuous_fst.continuousAt
  have hc : ContinuousAt P p := continuousAt_cfc_of_continuous
    (fun q : (ℝ×ℝ)×ℝ => scalarAlgebraHamiltonian q.1.1 q.1.2 φ) p
    hH
    (scalarGapCutoff l u) (continuous_scalarGapCutoff l u)
    (Eventually.of_forall (fun q => scalarAlgebraHamiltonian_isSelfAdjoint q.1.1 q.1.2 φ))
  have hproj : ∀ᶠ q in 𝓝 p, P q*P q=P q := by
    filter_upwards [hnear] with q hq
    have hzq := hq.2 q.2 hq.1
    rw [show P q=scalarGapProjection q.1.1 q.1.2 φ q.2 hzq from
      (scalarGapProjection_eq_cutoff _ _ _ _ l u hzq hq.1 hq.2).symm]
    exact scalarGapProjection_idempotent _ _ _ _ hzq
  have hconst := trace_projection_eventually_eq (magneticTraceReal φ) (magneticTraceReal_cyclic φ)
    P p hc (cfc_predicate _ _) hproj
  have heq : scalarGapProjection a r φ E hz=P p :=
    scalarGapProjection_eq_cutoff a r φ E l u hz hpI hnear.self_of_nhds.2
  filter_upwards [hnear,hconst] with q hq ht
  refine ⟨hq.2 q.2 hq.1,?_⟩
  rw [scalarGapProjection_eq_cutoff _ _ _ _ l u _ hq.1 hq.2,heq]
  exact ht

theorem scalarLowerSpectralMass_eventually_eq (a r φ E : ℝ) (ha : a≠0)
    (hz : (E : ℂ)∈resolventSet ℂ (scalarHamiltonian a r φ)) :
    ∀ᶠ q : (ℝ×ℝ)×ℝ in 𝓝 ((a,r),E),
      (scalarRealSpectralMeasure q.1.1 q.1.2 φ (Iio q.2)).toReal=
        (scalarRealSpectralMeasure a r φ (Iio E)).toReal := by
  filter_upwards [scalarGapProjection_trace_eventually_eq a r φ E ha hz] with q hq
  obtain ⟨hzq,heq⟩ := hq
  simpa only [scalarGapProjection_trace_eq_realSpectralMass] using heq

end UAMO

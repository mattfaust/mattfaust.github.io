import UAMO.LatticePhaseContinuity
import UAMO.GreenStableProjection
import UAMO.RealGreenProjection
import Mathlib.Analysis.Normed.Ring.Units

noncomputable section
namespace UAMO.CMV
open PhysicalRepresentation PhysicalRealPart PhysicalWalk
open scoped Topology

theorem continuous_lattice_operator_evaluation (ψ : Hilbert) (n : ℤ) :
    Continuous (fun T : Operator => T ψ n) := by
  exact ((continuous_apply n).comp lp.uniformContinuous_coe.continuous).comp
    (continuous_id.clm_apply continuous_const)

theorem continuousAt_greenStableMatrix {X : Type*} [TopologicalSpace X]
    (D : X → TwoByTwo Operator) (x : X)
    (hD : ContinuousAt (fun y => CStarMatrix.ofMatrix (D y)) x)
    (hunit : IsUnit (D x)) (n : ℤ) :
    ContinuousAt (fun y => greenStableMatrix (D y) n) x := by
  have hu : IsUnit (CStarMatrix.ofMatrix (D x)) := hunit.map
    (CStarMatrix.ofMatrixStarAlgEquiv : TwoByTwo Operator ≃⋆ₐ[ℂ]
      CStarMatrix (Fin 2) (Fin 2) Operator).toMonoidHom
  obtain ⟨u,hu⟩ := hu
  have hinv : ContinuousAt (Ring.inverse : CStarMatrix (Fin 2) (Fin 2) Operator →
      CStarMatrix (Fin 2) (Fin 2) Operator) (CStarMatrix.ofMatrix (D x)) := by
    rw [← hu]
    exact NormedRing.inverse_continuousAt u
  have hi : ContinuousAt (fun y => Ring.inverse (CStarMatrix.ofMatrix (D y))) x :=
    ContinuousAt.comp (f := fun y : X => CStarMatrix.ofMatrix (D y)) (x := x) hinv hD
  apply continuousAt_pi.mpr
  intro i
  apply continuousAt_pi.mpr
  intro j
  have he (k : Fin 2) : ContinuousAt (fun y =>
      (Ring.inverse (CStarMatrix.ofMatrix (D y))) i k) x :=
    (continuous_apply k).continuousAt.comp ((continuous_apply i).continuousAt.comp hi)
  have h0 := (continuous_lattice_operator_evaluation
    (siteImpulse (n-1) (fun j' : Fin 2 => if j'=j then 1 else 0) 0) n).continuousAt.comp (he 0)
  have h1 := (continuous_lattice_operator_evaluation
    (siteImpulse (n-1) (fun j' : Fin 2 => if j'=j then 1 else 0) 1) n).continuousAt.comp (he 1)
  simpa [greenStableMatrix, LinearMap.toMatrix'_apply, greenStableLinear,
    siteEvaluationLinear, spinLinearMap, siteImpulseLinear, spinAction,
    Function.comp_def] using h0.add h1

theorem continuousAt_greenStableRealMatrix {X : Type*} [TopologicalSpace X]
    (D : X → TwoByTwo Operator) (x : X)
    (hD : ContinuousAt (fun y => CStarMatrix.ofMatrix (D y)) x)
    (hunit : IsUnit (D x)) (n : ℤ) :
    ContinuousAt (fun y => greenStableRealMatrix (D y) n) x := by
  have hp := continuousAt_greenStableMatrix D x hD hunit n
  apply continuousAt_pi.mpr
  intro i
  apply continuousAt_pi.mpr
  intro j
  exact Complex.continuous_re.continuousAt.comp ((continuous_apply j).continuousAt.comp
    ((continuous_apply i).continuousAt.comp hp))

end UAMO.CMV

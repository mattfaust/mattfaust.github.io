import UAMO.GreenStableRank
import UAMO.RealGreenProjection
import UAMO.StablePlane

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart Filter
open scoped Topology

theorem transferProduct_greenStableMatrix_eq (A : ℝ → TransferMatrix) (ω x C : ℝ)
    (hC : 0 ≤ C) (hA : ∀ k : ℤ, ∀ i j, ‖A (x+(k:ℝ)*ω) i j‖ ≤ C)
    (hD : IsUnit (latticeDifference (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA))
    (v : TransferVector) (n : ℕ) :
    transferProduct A ω x n *ᵥ
        (greenStableMatrix (latticeDifference (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA) 0 *ᵥ v) =
      siteVector (greenColumn
        (latticeDifference (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA) (-1) v) (n:ℤ) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ, ← mulVec_mulVec, ih]
    have h := greenColumn_recurrence (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA hD (-1) n v
    rw [if_neg (by omega : (n:ℤ) ≠ -1)] at h
    simpa only [Int.cast_natCast, Nat.cast_add, Nat.cast_one] using (sub_eq_zero.mp h).symm

theorem transferProduct_greenStableMatrix_tendsto_zero (A : ℝ → TransferMatrix) (ω x C : ℝ)
    (hC : 0 ≤ C) (hA : ∀ k : ℤ, ∀ i j, ‖A (x+(k:ℝ)*ω) i j‖ ≤ C)
    (hD : IsUnit (latticeDifference (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA))
    (v : TransferVector) :
    Tendsto (fun n : ℕ => transferProduct A ω x n *ᵥ
      (greenStableMatrix (latticeDifference (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA) 0 *ᵥ v))
      atTop (𝓝 0) := by
  simp only [transferProduct_greenStableMatrix_eq A ω x C hC hA hD]
  apply tendsto_pi_nhds.mpr
  intro i
  have hi : Function.Injective (fun n : ℕ => (n:ℤ)) := Int.ofNat_injective
  have ht : Tendsto (fun n : ℕ => (n:ℤ)) atTop cofinite := by
    simpa only [Nat.cofinite_eq_atTop] using hi.tendsto_cofinite
  simpa only [Function.comp_def, siteVector_apply, Pi.zero_apply] using
    (hilbert_coordinate_tendsto_cofinite (greenColumn
      (latticeDifference (fun k : ℤ => A (x+(k:ℝ)*ω)) C hC hA) (-1) v i)).comp ht

theorem green_forwardProduct_complexification (A : ℝ → StablePlane.PlaneMatrix)
    (ω x : ℝ) (n : ℕ) :
    (StablePlane.forwardProduct A ω x n).map Complex.ofReal =
      transferProduct (fun y => (A y).map Complex.ofReal) ω x n := by
  induction n with
  | zero => ext i j; simp [StablePlane.forwardProduct, Matrix.one_apply]; split_ifs <;> simp
  | succ n ih =>
    rw [StablePlane.forwardProduct_succ, transferProduct_succ]
    change ((A (x+n*ω)*StablePlane.forwardProduct A ω x n).map Complex.ofRealHom)=_
    rw [Matrix.map_mul]
    exact congrArg (fun M => (A (x+n*ω)).map Complex.ofReal*M) ih

theorem realPart_complexified_mulVec (M : StablePlane.PlaneMatrix) (v : TransferVector) :
    (fun i => (((M.map Complex.ofReal)*ᵥv) i).re) = M *ᵥ (fun j => (v j).re) := by
  ext i
  simp [Matrix.mulVec, dotProduct, Fin.sum_univ_two, Complex.mul_re]

theorem realPart_mulVec_real (M : TransferMatrix) (v : StablePlane.Plane) :
    (fun i => ((M *ᵥ (fun j => (v j : ℂ))) i).re) = (M.map Complex.re) *ᵥ v := by
  ext i
  simp [Matrix.mulVec, dotProduct, Fin.sum_univ_two, Complex.mul_re]

theorem greenStableMatrix_realPart_image_isStable (A : ℝ → StablePlane.PlaneMatrix)
    (ω x C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ k : ℤ, ∀ i j, ‖((A (x+(k:ℝ)*ω)).map Complex.ofReal) i j‖ ≤ C)
    (hD : IsUnit (latticeDifference
      (fun k : ℤ => (A (x+(k:ℝ)*ω)).map Complex.ofReal) C hC hA))
    (v : StablePlane.Plane) :
    StablePlane.IsStable A ω x
      ((greenStableMatrix (latticeDifference
        (fun k : ℤ => (A (x+(k:ℝ)*ω)).map Complex.ofReal) C hC hA) 0).map Complex.re *ᵥ v) := by
  have h := transferProduct_greenStableMatrix_tendsto_zero
    (fun y => (A y).map Complex.ofReal) ω x C hC hA hD (fun j => (v j : ℂ))
  apply tendsto_pi_nhds.mpr
  intro i
  have hi := Complex.continuous_re.continuousAt.tendsto.comp ((tendsto_pi_nhds.mp h) i)
  simp only [← green_forwardProduct_complexification] at hi
  have he (n : ℕ) := congrFun (realPart_complexified_mulVec (StablePlane.forwardProduct A ω x n)
    (greenStableMatrix (latticeDifference
      (fun k : ℤ => (A (x+(k:ℝ)*ω)).map Complex.ofReal) C hC hA) 0 *ᵥ (fun j => (v j : ℂ)))) i
  simp only [realPart_mulVec_real] at he
  simpa only [Function.comp_def, he, Pi.zero_apply, Complex.zero_re] using hi

theorem greenStableRealMatrix_image_isStable (A : ℝ → StablePlane.PlaneMatrix)
    (ω x C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ k : ℤ, ∀ i j, ‖((A (x+(k:ℝ)*ω)).map Complex.ofReal) i j‖ ≤ C)
    (hD : IsUnit (latticeDifference
      (fun k : ℤ => (A (x+(k:ℝ)*ω)).map Complex.ofReal) C hC hA))
    (v : StablePlane.Plane) :
    StablePlane.IsStable A ω x
      (greenStableRealMatrix (latticeDifference
        (fun k : ℤ => (A (x+(k:ℝ)*ω)).map Complex.ofReal) C hC hA) 0 *ᵥ v) :=
  greenStableMatrix_realPart_image_isStable A ω x C hC hA hD v

end UAMO.CMV

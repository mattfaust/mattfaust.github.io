import UAMO.LatticeMatrixMultiplier
import Mathlib.LinearAlgebra.Matrix.ToLin

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart

def siteImpulse (n : ℤ) (v : TransferVector) : SpinHilbert :=
  fun i => lp.single 2 n (v i)

@[simp] theorem siteImpulse_apply (n : ℤ) (v : TransferVector) (i : Fin 2) (k : ℤ) :
    siteImpulse n v i k = if k = n then v i else 0 := by
  simp [siteImpulse, lp.single_apply, Pi.single_apply]

@[simp] theorem siteVector_siteImpulse (n k : ℤ) (v : TransferVector) :
    siteVector (siteImpulse n v) k = if k = n then v else 0 := by
  ext i
  by_cases hk : k = n <;> simp [hk]

theorem spin_eq_of_siteVector_eq {ψ χ : SpinHilbert}
    (h : ∀ n : ℤ, siteVector ψ n = siteVector χ n) : ψ = χ := by
  apply PiLp.ext
  intro i
  apply lp.ext
  funext n
  simpa only [siteVector_apply] using congrFun (h n) i

def siteImpulseLinear (n : ℤ) : TransferVector →ₗ[ℂ] SpinHilbert where
  toFun := siteImpulse n
  map_add' v w := by
    apply PiLp.ext
    intro i
    exact lp.single_add (E := fun _ : ℤ => ℂ) 2 n (v i) (w i)
  map_smul' c v := by
    apply PiLp.ext
    intro i
    exact lp.single_smul (E := fun _ : ℤ => ℂ) 2 n c (v i)

def siteEvaluationLinear (n : ℤ) : SpinHilbert →ₗ[ℂ] TransferVector where
  toFun := fun ψ => siteVector ψ n
  map_add' ψ χ := by ext i; simp
  map_smul' c ψ := by ext i; simp

def spinLinearMap (D : TwoByTwo Operator) : SpinHilbert →ₗ[ℂ] SpinHilbert where
  toFun := spinAction D
  map_add' := spinAction_add D
  map_smul' := spinAction_smul D

def greenColumn (D : TwoByTwo Operator) (m : ℤ) (v : TransferVector) : SpinHilbert :=
  spinAction (Ring.inverse D) (siteImpulse m v)

def greenStableLinear (D : TwoByTwo Operator) (n : ℤ) : TransferVector →ₗ[ℂ] TransferVector :=
  (siteEvaluationLinear n).comp ((spinLinearMap (Ring.inverse D)).comp (siteImpulseLinear (n-1)))

def greenStableMatrix (D : TwoByTwo Operator) (n : ℤ) : TransferMatrix :=
  LinearMap.toMatrix' (greenStableLinear D n)

@[simp] theorem greenStableMatrix_mulVec (D : TwoByTwo Operator) (n : ℤ) (v : TransferVector) :
    greenStableMatrix D n *ᵥ v = siteVector (greenColumn D (n-1) v) n := by
  rw [← Matrix.toLin'_apply, greenStableMatrix, Matrix.toLin'_toMatrix']
  rfl

theorem greenColumn_solution {D : TwoByTwo Operator} (hD : IsUnit D)
    (m : ℤ) (v : TransferVector) :
    spinAction D (greenColumn D m v) = siteImpulse m v := by
  rw [greenColumn, ← spinAction_mul, Ring.mul_inverse_cancel _ hD, spinAction_one]

theorem greenColumn_unique {D : TwoByTwo Operator} (hD : IsUnit D)
    (m : ℤ) (v : TransferVector) (ψ : SpinHilbert)
    (hψ : spinAction D ψ = siteImpulse m v) : ψ = greenColumn D m v := by
  have h := congrArg (spinAction (Ring.inverse D)) hψ
  rw [← spinAction_mul, Ring.inverse_mul_cancel _ hD, spinAction_one] at h
  exact h

theorem greenColumn_recurrence (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (m k : ℤ) (v : TransferVector) :
    siteVector (greenColumn (latticeDifference A C hC hA) m v) (k+1) -
      A k *ᵥ siteVector (greenColumn (latticeDifference A C hC hA) m v) k =
      if k = m then v else 0 := by
  rw [← latticeDifference_apply, greenColumn_solution hD, siteVector_siteImpulse]

def forwardTail (n : ℤ) (ψ : SpinHilbert) : SpinHilbert :=
  fun i => latticeMultiplier (fun k : ℤ => if n ≤ k then 1 else 0) 1 (by norm_num)
    (fun k => by dsimp; split_ifs <;> norm_num) (ψ i)

end UAMO.CMV

import UAMO.GreenStableProjection
import Mathlib.Analysis.SpecialFunctions.Sqrt

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart Filter
open scoped Topology

theorem hilbert_coordinate_tendsto_cofinite (ψ : Hilbert) :
    Tendsto (fun k : ℤ => ψ k) cofinite (𝓝 0) := by
  have hs : Summable (fun k : ℤ => ‖ψ k‖ ^ (2 : ℕ)) := by
    simpa using (lp.memℓp ψ).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  have hsq := hs.tendsto_cofinite_zero
  have hn := Real.continuous_sqrt.continuousAt.tendsto.comp hsq
  apply tendsto_zero_iff_norm_tendsto_zero.mpr
  simpa only [Function.comp_def, Real.sqrt_sq_eq_abs, abs_norm, Real.sqrt_zero] using hn

def greenKernelLinear (D : TwoByTwo Operator) (k m : ℤ) : TransferVector →ₗ[ℂ] TransferVector :=
  (siteEvaluationLinear k).comp ((spinLinearMap (Ring.inverse D)).comp (siteImpulseLinear m))

def greenKernelMatrix (D : TwoByTwo Operator) (k m : ℤ) : TransferMatrix :=
  LinearMap.toMatrix' (greenKernelLinear D k m)

@[simp] theorem greenKernelMatrix_mulVec (D : TwoByTwo Operator) (k m : ℤ) (v : TransferVector) :
    greenKernelMatrix D k m *ᵥ v = siteVector (greenColumn D m v) k := by
  rw [← Matrix.toLin'_apply, greenKernelMatrix, Matrix.toLin'_toMatrix']
  rfl

theorem greenStableMatrix_eq_kernel (D : TwoByTwo Operator) (n : ℤ) :
    greenStableMatrix D n = greenKernelMatrix D n (n-1) := rfl

theorem greenKernelMatrix_apply (D : TwoByTwo Operator) (k m : ℤ) (i j : Fin 2) :
    greenKernelMatrix D k m i j = greenColumn D m (Pi.single j 1) i k := by
  rw [greenKernelMatrix, LinearMap.toMatrix'_apply]
  change siteVector (greenColumn D m (fun j' => if j' = j then 1 else 0)) k i = _
  rw [siteVector_apply]
  have he : (fun l : Fin 2 => if l = j then (1 : ℂ) else 0) = Pi.single j 1 := by
    funext l
    simp [Pi.single_apply]
  rw [he]

theorem greenKernel_det_tendsto_cofinite (D : TwoByTwo Operator) (m : ℤ) :
    Tendsto (fun k : ℤ => (greenKernelMatrix D k m).det) cofinite (𝓝 0) := by
  have h00 := hilbert_coordinate_tendsto_cofinite (greenColumn D m (Pi.single 0 1) 0)
  have h01 := hilbert_coordinate_tendsto_cofinite (greenColumn D m (Pi.single 1 1) 0)
  have h10 := hilbert_coordinate_tendsto_cofinite (greenColumn D m (Pi.single 0 1) 1)
  have h11 := hilbert_coordinate_tendsto_cofinite (greenColumn D m (Pi.single 1 1) 1)
  simpa only [Matrix.det_fin_two, greenKernelMatrix_apply, zero_mul, sub_zero] using
    (h00.mul h11).sub (h01.mul h10)

theorem greenKernelMatrix_jump (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (k m : ℤ) :
    greenKernelMatrix (latticeDifference A C hC hA) (k+1) m -
      A k * greenKernelMatrix (latticeDifference A C hC hA) k m =
      if k = m then 1 else 0 := by
  apply Matrix.toLin'.injective
  apply LinearMap.ext
  intro v
  change (_ - _) *ᵥ v = _ *ᵥ v
  rw [Matrix.sub_mulVec, ← mulVec_mulVec, greenKernelMatrix_mulVec, greenKernelMatrix_mulVec]
  rw [greenColumn_recurrence A C hC hA hD]
  split_ifs <;> simp

theorem greenKernelMatrix_homogeneous (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (k m : ℤ) (hne : k ≠ m) :
    greenKernelMatrix (latticeDifference A C hC hA) (k+1) m =
      A k * greenKernelMatrix (latticeDifference A C hC hA) k m := by
  have h := greenKernelMatrix_jump A C hC hA hD k m
  rw [if_neg hne] at h
  exact sub_eq_zero.mp h

theorem greenStableMatrix_det_zero (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (hdet : ∀ n, (A n).det = 1) (n : ℤ) :
    (greenStableMatrix (latticeDifference A C hC hA) n).det = 0 := by
  let D := latticeDifference A C hC hA
  have hconst (j : ℕ) : (greenKernelMatrix D (n + (j : ℤ)) (n-1)).det =
      (greenStableMatrix D n).det := by
    induction j with
    | zero => simp [greenStableMatrix_eq_kernel]
    | succ j ih =>
      have he : n + ((j+1 : ℕ) : ℤ) = (n + (j : ℤ)) + 1 := by omega
      rw [he, greenKernelMatrix_homogeneous A C hC hA hD _ _ (by omega), det_mul, hdet, one_mul]
      exact ih
  have hi : Function.Injective (fun j : ℕ => n + (j : ℤ)) := by
    intro i j hij
    dsimp only at hij
    exact_mod_cast add_left_cancel hij
  have ht : Tendsto (fun j : ℕ => n + (j : ℤ)) atTop cofinite := by
    simpa only [Nat.cofinite_eq_atTop] using hi.tendsto_cofinite
  have hz : Tendsto (fun j : ℕ => (greenKernelMatrix D (n + (j : ℤ)) (n-1)).det)
      atTop (𝓝 0) := (greenKernel_det_tendsto_cofinite D (n-1)).comp ht
  simp only [hconst] at hz
  exact tendsto_nhds_unique tendsto_const_nhds hz

theorem greenKernel_source_det_zero (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (hdet : ∀ n, (A n).det = 1) (m : ℤ) :
    (greenKernelMatrix (latticeDifference A C hC hA) m m).det = 0 := by
  let D := latticeDifference A C hC hA
  have hconst (j : ℕ) : (greenKernelMatrix D (m - (j : ℤ)) m).det =
      (greenKernelMatrix D m m).det := by
    induction j with
    | zero => simp
    | succ j ih =>
      have he : m - ((j+1 : ℕ) : ℤ) + 1 = m - (j : ℤ) := by omega
      have h := congrArg Matrix.det (greenKernelMatrix_homogeneous A C hC hA hD
        (m - ((j+1 : ℕ) : ℤ)) m (by omega))
      rw [he, det_mul, hdet, one_mul] at h
      exact h.symm.trans ih
  have hi : Function.Injective (fun j : ℕ => m - (j : ℤ)) := by
    intro i j hij
    dsimp only at hij
    exact_mod_cast sub_right_injective hij
  have ht : Tendsto (fun j : ℕ => m - (j : ℤ)) atTop cofinite := by
    simpa only [Nat.cofinite_eq_atTop] using hi.tendsto_cofinite
  have hz : Tendsto (fun j : ℕ => (greenKernelMatrix D (m - (j : ℤ)) m).det)
      atTop (𝓝 0) := (greenKernel_det_tendsto_cofinite D m).comp ht
  simp only [hconst] at hz
  exact tendsto_nhds_unique tendsto_const_nhds hz

theorem one_sub_greenStableMatrix_det_zero (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (hdet : ∀ n, (A n).det = 1) (n : ℤ) :
    (1 - greenStableMatrix (latticeDifference A C hC hA) n).det = 0 := by
  let D := latticeDifference A C hC hA
  have h := greenKernelMatrix_jump A C hC hA hD (n-1) (n-1)
  simp only [sub_add_cancel, if_true, ← greenStableMatrix_eq_kernel] at h
  have he : 1 - greenStableMatrix D n = -(A (n-1) * greenKernelMatrix D (n-1) (n-1)) := by
    rw [← h]
    abel
  rw [he, det_neg, det_mul, hdet, greenKernel_source_det_zero A C hC hA hD hdet,
    mul_zero, mul_zero]

theorem greenStableMatrix_ne_zero (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hD : IsUnit (latticeDifference A C hC hA))
    (hdet : ∀ n, (A n).det = 1) (n : ℤ) :
    greenStableMatrix (latticeDifference A C hC hA) n ≠ 0 := by
  intro hzero
  have h := one_sub_greenStableMatrix_det_zero A C hC hA hD hdet n
  rw [hzero, sub_zero, det_one] at h
  exact one_ne_zero h

end UAMO.CMV

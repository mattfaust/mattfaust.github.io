import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

namespace UAMO
open Set

theorem height_bounds_of_radial_derivative
    (h h' : ℝ → ℝ) {r₀ r₁ : ℝ} (hr₀ : 0 < r₀) (hr : r₀ ≤ r₁)
    (hc : ContinuousOn h (Icc r₀ r₁))
    (hd : ∀ x ∈ Ioo r₀ r₁, HasDerivAt h (h' x) x)
    (hb : ∀ x ∈ Ioo r₀ r₁, 0 ≤ x * h' x ∧ x * h' x ≤ 2) :
    h r₀ ≤ h r₁ ∧ h r₁ ≤ h r₀ + 2 * Real.log (r₁ / r₀) := by
  have pos (x : ℝ) (hx : x ∈ Ioo r₀ r₁) : 0 < x := lt_trans hr₀ hx.1
  have hm : MonotoneOn h (Icc r₀ r₁) := by
    apply monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc r₀ r₁) hc
    · intro x hx
      rw [interior_Icc] at hx
      exact (hd x hx).hasDerivWithinAt
    · intro x hx
      rw [interior_Icc] at hx
      exact nonneg_of_mul_nonneg_right (hb x hx).1 (pos x hx)
  have hlog : ContinuousOn (fun x : ℝ => 2 * Real.log x) (Icc r₀ r₁) := by
    apply continuousOn_const.mul
    apply Real.continuousOn_log.mono
    intro x hx
    exact ne_of_gt (lt_of_lt_of_le hr₀ hx.1)
  have ha : AntitoneOn (fun x => h x - 2 * Real.log x) (Icc r₀ r₁) := by
    apply antitoneOn_of_hasDerivWithinAt_nonpos (convex_Icc r₀ r₁) (hc.sub hlog)
      (f' := fun x => h' x - 2 * x⁻¹)
    · intro x hx
      rw [interior_Icc] at hx
      exact ((hd x hx).sub ((Real.hasDerivAt_log (ne_of_gt (pos x hx))).const_mul 2)).hasDerivWithinAt
    · intro x hx
      rw [interior_Icc] at hx
      have he : x * x⁻¹ = 1 := mul_inv_cancel₀ (ne_of_gt (pos x hx))
      have hu := (hb x hx).2
      have : x * (h' x - 2 * x⁻¹) ≤ 0 := by nlinarith
      exact nonpos_of_mul_nonpos_right this (pos x hx)
  have hlower := hm (left_mem_Icc.mpr hr) (right_mem_Icc.mpr hr) hr
  have hupper := ha (left_mem_Icc.mpr hr) (right_mem_Icc.mpr hr) hr
  change h r₁ - 2 * Real.log r₁ ≤ h r₀ - 2 * Real.log r₀ at hupper
  rw [Real.log_div (ne_of_gt (lt_of_lt_of_le hr₀ hr)) (ne_of_gt hr₀)]
  exact ⟨hlower, by linarith⟩

end UAMO

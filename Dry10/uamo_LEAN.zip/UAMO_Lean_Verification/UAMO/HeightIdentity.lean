import Mathlib.Analysis.InnerProductSpace.Symmetric
import Mathlib.Tactic

namespace UAMO

open scoped InnerProductSpace

section HeightIdentity

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V]

theorem sector_quadratic_ratio_mem_Icc
    (L : V →L[ℂ] V) (q : V) (hq : q ≠ 0)
    (hcontract : ∀ v, ‖L v‖ ≤ ‖v‖) :
    (⟪q, L q⟫_ℂ).re / ‖q‖ ^ 2 ∈ Set.Icc (-1 : ℝ) 1 := by
  have hden : 0 < ‖q‖ ^ 2 := sq_pos_of_pos (norm_pos_iff.mpr hq)
  have hb : |(⟪q, L q⟫_ℂ).re| ≤ ‖q‖ ^ 2 := by
    calc
      |(⟪q, L q⟫_ℂ).re| ≤ ‖⟪q, L q⟫_ℂ‖ := Complex.abs_re_le_norm _
      _ ≤ ‖q‖ * ‖L q‖ := norm_inner_le_norm _ _
      _ ≤ ‖q‖ * ‖q‖ := mul_le_mul_of_nonneg_left (hcontract q) (norm_nonneg q)
      _ = ‖q‖ ^ 2 := (pow_two _).symm
  constructor
  · apply (le_div_iff₀ hden).2
    linarith [(abs_le.mp hb).1]
  · apply (div_le_iff₀ hden).2
    linarith [(abs_le.mp hb).2]

theorem compressed_eigenvalue_real_part
    (P L : V →L[ℂ] V) (hP : P.toLinearMap.IsSymmetric)
    (q : V) (hq : q ≠ 0) (hcenter : P q = q) (c : ℂ)
    (heigen : P (L q) = c • q) :
    (⟪q, L q⟫_ℂ).re / ‖q‖ ^ 2 = c.re := by
  have hform : ⟪q, L q⟫_ℂ = c * ⟪q, q⟫_ℂ := by
    calc
      ⟪q, L q⟫_ℂ = ⟪P q, L q⟫_ℂ := by rw [hcenter]
      _ = ⟪q, P (L q)⟫_ℂ := hP q (L q)
      _ = c * ⟪q, q⟫_ℂ := by rw [heigen, inner_smul_right]
  have hden : ‖q‖ ^ 2 ≠ 0 := pow_ne_zero 2 (norm_ne_zero_iff.mpr hq)
  rw [hform, inner_self_eq_norm_sq_to_K]
  change (c * ((‖q‖ : ℂ) ^ 2)).re / ‖q‖ ^ 2 = c.re
  rw [← Complex.ofReal_pow, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    mul_zero, sub_zero, mul_div_assoc, div_self hden, mul_one]

theorem compressed_sector_eigenvalue_im_zero
    (P L : V →L[ℂ] V) (hP : P.toLinearMap.IsSymmetric)
    (hL : L.toLinearMap.IsSymmetric)
    (q : V) (hq : q ≠ 0) (hcenter : P q = q) (c : ℂ)
    (heigen : P (L q) = c • q) : c.im = 0 := by
  have hsym : (starRingEnd ℂ) c * ⟪q, q⟫_ℂ = c * ⟪q, q⟫_ℂ := by
    calc
      (starRingEnd ℂ) c * ⟪q, q⟫_ℂ = ⟪P (L q), q⟫_ℂ := by
        rw [heigen, inner_smul_left]
      _ = ⟪L q, P q⟫_ℂ := hP (L q) q
      _ = ⟪L q, q⟫_ℂ := by rw [hcenter]
      _ = ⟪q, L q⟫_ℂ := hL q q
      _ = ⟪P q, L q⟫_ℂ := by rw [hcenter]
      _ = ⟪q, P (L q)⟫_ℂ := hP q (L q)
      _ = c * ⟪q, q⟫_ℂ := by rw [heigen, inner_smul_right]
  have hc : (starRingEnd ℂ) c = c :=
    mul_right_cancel₀ (inner_self_ne_zero.mpr hq) hsym
  have hi := congrArg Complex.im hc
  simp only [Complex.conj_im] at hi
  linarith

theorem radial_column_pairing
    (P L : V →L[ℂ] V) (hP : P.toLinearMap.IsSymmetric)
    (hL : L.toLinearMap.IsSymmetric)
    (q h d : V) (hsource_centered : P h = h) (c : ℂ)
    (heigen : P (L q) = c • q)
    (hsource : ⟪q, h⟫_ℂ = -1) (hcolumn : d = h - L h) :
    -(⟪q, d⟫_ℂ).re = 1 - c.re := by
  have hsector : ⟪q, L h⟫_ℂ = -(starRingEnd ℂ) c := by
    calc
      ⟪q, L h⟫_ℂ = ⟪L q, h⟫_ℂ := (hL q h).symm
      _ = ⟪L q, P h⟫_ℂ := by rw [hsource_centered]
      _ = ⟪P (L q), h⟫_ℂ := (hP (L q) h).symm
      _ = -(starRingEnd ℂ) c := by
        rw [heigen, inner_smul_left, hsource, mul_neg_one]
  rw [hcolumn, inner_sub_right, hsource, hsector]
  simp only [Complex.sub_re, Complex.neg_re, Complex.one_re, Complex.conj_re]
  ring

theorem magnetic_height_identity_of_compressed_eigenline
    (P L : V →L[ℂ] V) (hP : P.toLinearMap.IsSymmetric)
    (hL : L.toLinearMap.IsSymmetric)
    (hcontract : ∀ v, ‖L v‖ ≤ ‖v‖)
    (q h d : V) (hq : q ≠ 0) (hcenter : P q = q)
    (hsource_centered : P h = h) (c : ℂ)
    (heigen : P (L q) = c • q)
    (hsource : ⟪q, h⟫_ℂ = -1) (hcolumn : d = h - L h)
    (radialHeight : ℝ) (htrace : radialHeight = -(⟪q, d⟫_ℂ).re) :
    c.im = 0 ∧ c.re ∈ Set.Icc (-1 : ℝ) 1 ∧
      radialHeight = 1 - (⟪q, L q⟫_ℂ).re / ‖q‖ ^ 2 ∧
      radialHeight ∈ Set.Icc (0 : ℝ) 2 := by
  have hratio := compressed_eigenvalue_real_part P L hP q hq hcenter c heigen
  have hbound := sector_quadratic_ratio_mem_Icc L q hq hcontract
  rw [hratio] at hbound
  have hheight : radialHeight = 1 - c.re := by
    rw [htrace]
    exact radial_column_pairing P L hP hL q h d hsource_centered c
      heigen hsource hcolumn
  refine ⟨compressed_sector_eigenvalue_im_zero P L hP hL q hq hcenter c heigen,
    hbound, ?_, ?_⟩
  · rw [hratio, hheight]
  · rw [hheight]
    constructor <;> linarith [hbound.1, hbound.2]

end HeightIdentity

end UAMO

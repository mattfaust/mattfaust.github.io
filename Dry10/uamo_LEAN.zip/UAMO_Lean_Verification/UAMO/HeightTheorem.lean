import UAMO.CompressedEigenline
import UAMO.HeightIdentity

namespace UAMO

open scoped InnerProductSpace

section HeightTheorem

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V]

theorem source_pairing_from_centered_resolvent
    (H R : V →L[ℂ] V) (hH : H.toLinearMap.IsSymmetric)
    (E : ℝ) (Ω : V) (hunit : ‖Ω‖ = 1)
    (hres : ∀ v, (E : ℂ) • R v - H (R v) = v)
    (horthogonal : ⟪R Ω, Ω⟫_ℂ = 0) :
    ⟪R Ω, H Ω⟫_ℂ = -1 := by
  have hHq : H (R Ω) = (E : ℂ) • R Ω - Ω := by
    apply eq_sub_iff_add_eq.mpr
    calc
      H (R Ω) + Ω = Ω + H (R Ω) := add_comm _ _
      _ = (E : ℂ) • R Ω := (sub_eq_iff_eq_add.mp (hres Ω)).symm
  rw [← hH.apply_clm, hHq, inner_sub_left, inner_smul_left, horthogonal,
    mul_zero, inner_self_eq_norm_sq_to_K, hunit]
  norm_num

theorem magnetic_height_identity_from_resolvent
    (P H R L : V →L[ℂ] V)
    (hP : P.toLinearMap.IsSymmetric)
    (hH : H.toLinearMap.IsSymmetric)
    (hL : L.toLinearMap.IsSymmetric)
    (hcontract : ∀ v, ‖L v‖ ≤ ‖v‖)
    (E : ℝ) (Ω : V) (hunit : ‖Ω‖ = 1)
    (hres : ∀ v, (E : ℂ) • R v - H (R v) = v)
    (hinverse : ∀ v, R ((E : ℂ) • v - H v) = v)
    (hcenter : P (R Ω) = R Ω) (hroot : P Ω = 0)
    (hkernel : ∀ v, P v = 0 → ∃ c : ℂ, v = c • Ω)
    (hprojection : ∀ v, P (P v) = P v)
    (hcommute : ∀ v,
      compressedMap P.toLinearMap L.toLinearMap
          (compressedMap P.toLinearMap H.toLinearMap v) =
        compressedMap P.toLinearMap H.toLinearMap
          (compressedMap P.toLinearMap L.toLinearMap v))
    (hsource_centered : P (H Ω) = H Ω)
    (horthogonal : ⟪R Ω, Ω⟫_ℂ = 0)
    (d : V) (hcolumn : d = H Ω - L (H Ω))
    (radialHeight : ℝ) (htrace : radialHeight = -(⟪R Ω, d⟫_ℂ).re) :
    radialHeight = 1 - (⟪R Ω, L (R Ω)⟫_ℂ).re / ‖R Ω‖ ^ 2 ∧
      radialHeight ∈ Set.Icc (0 : ℝ) 2 := by
  have hΩ : Ω ≠ 0 := by
    intro hz
    rw [hz, norm_zero] at hunit
    exact zero_ne_one hunit
  have hq : R Ω ≠ 0 :=
    resolvent_column_ne_zero H.toLinearMap R.toLinearMap (E : ℂ) Ω hres hΩ
  obtain ⟨c, hc⟩ := compressed_observable_preserves_resolvent_line
    P.toLinearMap H.toLinearMap R.toLinearMap L.toLinearMap (E : ℂ) Ω
    hres hinverse hcenter hroot hkernel hprojection hcommute
  have heigen : P (L (R Ω)) = c • R Ω := by
    simpa only [compressedMap_apply, ContinuousLinearMap.coe_coe, hcenter] using hc
  have hsource := source_pairing_from_centered_resolvent H R hH E Ω
    hunit hres horthogonal
  have hheight := magnetic_height_identity_of_compressed_eigenline
    P L hP hL hcontract (R Ω) (H Ω) d hq hcenter hsource_centered c
    heigen hsource hcolumn radialHeight htrace
  exact hheight.2.2

end HeightTheorem

end UAMO

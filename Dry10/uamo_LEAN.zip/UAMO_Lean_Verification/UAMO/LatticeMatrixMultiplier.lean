import UAMO.PhysicalTransferOperator

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart
open scoped Matrix

@[simp] theorem siteVector_apply (ψ : SpinHilbert) (n : ℤ) (i : Fin 2) :
    siteVector ψ n i = ψ i n := by fin_cases i <;> rfl

theorem siteVector_sub (ψ χ : SpinHilbert) (n : ℤ) :
    siteVector (ψ-χ) n = siteVector ψ n - siteVector χ n := by
  ext i
  simp

def latticeMatrixMultiplier (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) : TwoByTwo Operator :=
  Matrix.of (fun i j => latticeMultiplier (fun n => A n i j) C hC (fun n => hA n i j))

@[simp] theorem latticeMatrixMultiplier_entry (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (i j : Fin 2) (ψ : Hilbert) (n : ℤ) :
    latticeMatrixMultiplier A C hC hA i j ψ n = A n i j * ψ n := rfl

theorem latticeMatrixMultiplier_apply (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction (latticeMatrixMultiplier A C hC hA) ψ) n = A n *ᵥ siteVector ψ n := by
  ext i
  fin_cases i <;> simp [siteVector, spinAction, Matrix.mulVec, dotProduct, Fin.sum_univ_two]

theorem latticeMatrixMultiplier_mul_eq_one
    (A B : ℤ → TransferMatrix) (C D : ℝ) (hC : 0 ≤ C) (hD : 0 ≤ D)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hB : ∀ n i j, ‖B n i j‖ ≤ D)
    (hinv : ∀ n, A n * B n = 1) :
    latticeMatrixMultiplier A C hC hA * latticeMatrixMultiplier B D hD hB = 1 := by
  ext i j ψ n
  simp only [Matrix.mul_apply, Fin.sum_univ_two, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.mul_apply, lp.coeFn_add, Pi.add_apply, latticeMatrixMultiplier_entry]
  have h := congrFun (congrFun (hinv n) i) j
  simp only [Matrix.mul_apply, Fin.sum_univ_two] at h
  fin_cases i <;> fin_cases j <;>
    simp only [Matrix.one_apply, Fin.zero_eta, Fin.mk_one, Fin.isValue, ite_true,
      Fin.reduceEq, ite_false, ContinuousLinearMap.one_apply, ContinuousLinearMap.zero_apply,
      lp.coeFn_zero, Pi.zero_apply] at h ⊢ <;> linear_combination ψ n * h

theorem latticeMatrixMultiplier_isUnit
    (A B : ℤ → TransferMatrix) (C D : ℝ) (hC : 0 ≤ C) (hD : 0 ≤ D)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (hB : ∀ n i j, ‖B n i j‖ ≤ D)
    (hinv : ∀ n, A n * B n = 1) : IsUnit (latticeMatrixMultiplier A C hC hA) := by
  refine ⟨⟨_, latticeMatrixMultiplier B D hD hB,
    latticeMatrixMultiplier_mul_eq_one A B C D hC hD hA hB hinv, ?_⟩, rfl⟩
  exact latticeMatrixMultiplier_mul_eq_one B A D C hD hC hB hA
    (fun n => Matrix.mul_eq_one_comm.mp (hinv n))

def latticeForwardShift : TwoByTwo Operator := Matrix.diagonal (fun _ => star shift)

theorem latticeForwardShift_apply (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction latticeForwardShift ψ) n = siteVector ψ (n+1) := by
  ext i
  fin_cases i <;> simp [siteVector, spinAction, latticeForwardShift, Matrix.diagonal]

def latticeDifference (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) : TwoByTwo Operator :=
  latticeForwardShift - latticeMatrixMultiplier A C hC hA

theorem latticeDifference_apply (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C) (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction (latticeDifference A C hC hA) ψ) n =
      siteVector ψ (n+1) - A n *ᵥ siteVector ψ n := by
  rw [latticeDifference, spinAction_matrix_sub]
  rw [siteVector_sub, latticeForwardShift_apply, latticeMatrixMultiplier_apply]

theorem latticeDifference_frame_identity
    (A B F : ℤ → TransferMatrix) (CA CB CF : ℝ)
    (hCA : 0 ≤ CA) (hCB : 0 ≤ CB) (hCF : 0 ≤ CF)
    (hA : ∀ n i j, ‖A n i j‖ ≤ CA) (hB : ∀ n i j, ‖B n i j‖ ≤ CB)
    (hF : ∀ n i j, ‖F n i j‖ ≤ CF)
    (hconj : ∀ n, A n * F n = F (n+1) * B n) :
    latticeDifference A CA hCA hA * latticeMatrixMultiplier F CF hCF hF =
      latticeMatrixMultiplier (fun n => F (n+1)) CF hCF (fun n => hF (n+1)) *
        latticeDifference B CB hCB hB := by
  apply spinAction_injective
  intro ψ
  apply PiLp.ext
  intro i
  apply lp.ext
  funext n
  have h : siteVector (spinAction
      (latticeDifference A CA hCA hA * latticeMatrixMultiplier F CF hCF hF) ψ) n =
    siteVector (spinAction
      (latticeMatrixMultiplier (fun n => F (n+1)) CF hCF (fun n => hF (n+1)) *
        latticeDifference B CB hCB hB) ψ) n := by
    simp only [spinAction_mul, latticeDifference_apply, latticeMatrixMultiplier_apply,
      mulVec_sub, mulVec_mulVec, hconj]
  have hi := congrFun h i
  fin_cases i <;> exact hi

theorem latticeDifference_isUnit_iff_frame
    (A B F G : ℤ → TransferMatrix) (CA CB CF CG : ℝ)
    (hCA : 0 ≤ CA) (hCB : 0 ≤ CB) (hCF : 0 ≤ CF) (hCG : 0 ≤ CG)
    (hA : ∀ n i j, ‖A n i j‖ ≤ CA) (hB : ∀ n i j, ‖B n i j‖ ≤ CB)
    (hF : ∀ n i j, ‖F n i j‖ ≤ CF) (hG : ∀ n i j, ‖G n i j‖ ≤ CG)
    (hinv : ∀ n, F n * G n = 1)
    (hconj : ∀ n, A n * F n = F (n+1) * B n) :
    IsUnit (latticeDifference A CA hCA hA) ↔ IsUnit (latticeDifference B CB hCB hB) := by
  have hU := latticeMatrixMultiplier_isUnit F G CF CG hCF hCG hF hG hinv
  have hV := latticeMatrixMultiplier_isUnit (fun n => F (n+1)) (fun n => G (n+1))
    CF CG hCF hCG (fun n => hF (n+1)) (fun n => hG (n+1)) (fun n => hinv (n+1))
  have he := latticeDifference_frame_identity A B F CA CB CF hCA hCB hCF hA hB hF hconj
  constructor
  · intro h
    have hh := h.mul hU
    rw [he] at hh
    have hh' := hV.unit⁻¹.isUnit.mul hh
    simpa only [← mul_assoc, hV.val_inv_mul, one_mul] using hh'
  · intro h
    have hh := hV.mul h
    rw [← he] at hh
    have hh' := hh.mul hU.unit⁻¹.isUnit
    simpa only [mul_assoc, hU.mul_val_inv, mul_one] using hh'

theorem eq_latticeDifference_of_apply (D : TwoByTwo Operator)
    (A : ℤ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖A n i j‖ ≤ C)
    (hD : ∀ ψ : SpinHilbert, ∀ n : ℤ, siteVector (spinAction D ψ) n =
      siteVector ψ (n+1) - A n *ᵥ siteVector ψ n) :
    D = latticeDifference A C hC hA := by
  apply spinAction_injective
  intro ψ
  apply PiLp.ext
  intro i
  apply lp.ext
  funext n
  have hh := (hD ψ n).trans (latticeDifference_apply A C hC hA ψ n).symm
  simpa only [siteVector_apply] using congrFun hh i

theorem physicalDifferenceOperator_eq_latticeDifference
    (a r Φ θ : ℝ) (z : ℂ) (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (hz : z ≠ 0)
    (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ n i j, ‖uamoTransfer a r z (phaseAngle Φ θ n) i j‖ ≤ C) :
    physicalDifferenceOperator a r Φ θ z ha hr hr1 hz =
      latticeDifference (fun n => uamoTransfer a r z (phaseAngle Φ θ n)) C hC hA :=
  eq_latticeDifference_of_apply _ _ C hC hA
    (physicalDifferenceOperator_apply a r Φ θ z ha hr hr1 hz)

end UAMO.CMV

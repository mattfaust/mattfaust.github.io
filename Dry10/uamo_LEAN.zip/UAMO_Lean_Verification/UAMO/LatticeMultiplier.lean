import UAMO.PhysicalRepresentation
import Mathlib.Tactic

noncomputable section
namespace UAMO.PhysicalRepresentation

private theorem lattice_summable_sq (ψ : Hilbert) :
    Summable (fun n => ‖ψ n‖ ^ (2 : ℕ)) := by
  simpa using (lp.memℓp ψ).summable (show 0 < (2 : ENNReal).toReal by norm_num)

private theorem lattice_norm_sq (ψ : Hilbert) :
    ‖ψ‖ ^ 2 = ∑' n, ‖ψ n‖ ^ (2 : ℕ) := by
  simpa using lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) ψ

def multiplierVector (c : ℤ → ℂ) (C : ℝ) (_hC : 0 ≤ C)
    (hc : ∀ n, ‖c n‖ ≤ C) (ψ : Hilbert) : Hilbert :=
  ⟨fun n => c n * ψ n, by
    apply memℓp_gen
    have hs := (lattice_summable_sq ψ).mul_left (C^2)
    have hb (n : ℤ) : ‖c n * ψ n‖^2 ≤ C^2 * ‖ψ n‖^2 := by
      rw [norm_mul, mul_pow]
      exact mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (norm_nonneg _) (hc n) 2)
        (sq_nonneg _)
    simpa using Summable.of_nonneg_of_le (fun n => sq_nonneg ‖c n * ψ n‖) hb hs⟩

@[simp] theorem multiplierVector_apply (c : ℤ → ℂ) (C : ℝ) (hC : 0 ≤ C)
    (hc : ∀ n, ‖c n‖ ≤ C) (ψ : Hilbert) (n : ℤ) :
    multiplierVector c C hC hc ψ n = c n * ψ n := rfl

theorem multiplierVector_norm_le (c : ℤ → ℂ) (C : ℝ) (hC : 0 ≤ C)
    (hc : ∀ n, ‖c n‖ ≤ C) (ψ : Hilbert) :
    ‖multiplierVector c C hC hc ψ‖ ≤ C * ‖ψ‖ := by
  have hb (n : ℤ) : ‖multiplierVector c C hC hc ψ n‖^2 ≤ C^2 * ‖ψ n‖^2 := by
    simp only [multiplierVector_apply, norm_mul, mul_pow]
    exact mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (norm_nonneg _) (hc n) 2)
      (sq_nonneg _)
  have ht := (lattice_summable_sq (multiplierVector c C hC hc ψ)).tsum_le_tsum hb
    ((lattice_summable_sq ψ).mul_left (C^2))
  rw [← lattice_norm_sq, tsum_mul_left, ← lattice_norm_sq] at ht
  rw [← mul_pow] at ht
  exact (sq_le_sq₀ (norm_nonneg _) (mul_nonneg hC (norm_nonneg ψ))).mp ht

def latticeMultiplier (c : ℤ → ℂ) (C : ℝ) (hC : 0 ≤ C)
    (hc : ∀ n, ‖c n‖ ≤ C) : Operator :=
  LinearMap.mkContinuous
    { toFun := multiplierVector c C hC hc
      map_add' := by
        intro ψ χ
        apply lp.ext
        funext n
        simp [mul_add]
      map_smul' := by
        intro a ψ
        apply lp.ext
        funext n
        simp [mul_left_comm] }
    C (multiplierVector_norm_le c C hC hc)

@[simp] theorem latticeMultiplier_apply (c : ℤ → ℂ) (C : ℝ) (hC : 0 ≤ C)
    (hc : ∀ n, ‖c n‖ ≤ C) (ψ : Hilbert) (n : ℤ) :
    latticeMultiplier c C hC hc ψ n = c n * ψ n := rfl

theorem latticeMultiplier_norm_le (c : ℤ → ℂ) (C : ℝ) (hC : 0 ≤ C)
    (hc : ∀ n, ‖c n‖ ≤ C) : ‖latticeMultiplier c C hC hc‖ ≤ C :=
  LinearMap.mkContinuous_norm_le _ hC _

theorem latticeMultiplier_mul_eq_one (c d : ℤ → ℂ) (C D : ℝ)
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hc : ∀ n, ‖c n‖ ≤ C) (hd : ∀ n, ‖d n‖ ≤ D)
    (hinv : ∀ n, c n * d n = 1) :
    latticeMultiplier c C hC hc * latticeMultiplier d D hD hd = 1 := by
  ext ψ n
  simp [← mul_assoc, hinv]

theorem latticeMultiplier_isUnit (c d : ℤ → ℂ) (C D : ℝ)
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hc : ∀ n, ‖c n‖ ≤ C) (hd : ∀ n, ‖d n‖ ≤ D)
    (hinv : ∀ n, c n * d n = 1) :
    IsUnit (latticeMultiplier c C hC hc) := by
  refine ⟨⟨latticeMultiplier c C hC hc, latticeMultiplier d D hD hd,
    latticeMultiplier_mul_eq_one c d C D hC hD hc hd hinv, ?_⟩, rfl⟩
  exact latticeMultiplier_mul_eq_one d c D C hD hC hd hc (fun n => by rw [mul_comm, hinv])

end UAMO.PhysicalRepresentation

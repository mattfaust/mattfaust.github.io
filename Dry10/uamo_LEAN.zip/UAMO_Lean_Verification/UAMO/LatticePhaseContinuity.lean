import UAMO.LatticeMatrixMultiplier
import UAMO.RealCocycleConjugacy
import UAMO.PhaseQuadrature
import Mathlib.Analysis.CStarAlgebra.CStarMatrix
import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Topology.Instances.Real.Lemmas

noncomputable section
namespace UAMO.CMV
open Set PhysicalRepresentation PhysicalRealPart PhysicalWalk

theorem periodic_uniformContinuous_complex {f : ℝ → ℂ} (hf : Continuous f)
    {T : ℝ} (hT : 0 < T) (hp : Function.Periodic f T) : UniformContinuous f := by
  have hu := isCompact_Icc.uniformContinuousOn_of_continuous
    (s:=Icc (-T) (2*T)) hf.continuousOn
  apply Metric.uniformContinuous_iff.mpr
  intro ε hε
  obtain ⟨δ,hδ,hh⟩ := Metric.uniformContinuousOn_iff.mp hu ε hε
  refine ⟨min δ T,lt_min hδ hT,?_⟩
  intro x y hxy
  obtain ⟨n,hn,_⟩ := existsUnique_sub_zsmul_mem_Ico hT x 0
  simp only [zero_add] at hn
  have hd : dist (x-n • T) (y-n • T)<δ := by
    simpa only [dist_sub_right] using lt_of_lt_of_le hxy (min_le_left _ _)
  have hsmall : |x-y|<T := by
    simpa only [Real.dist_eq] using lt_of_lt_of_le hxy (min_le_right _ _)
  have hx : x-n • T∈Icc (-T) (2*T) := ⟨by linarith [hn.1],by linarith [hn.2]⟩
  have hy : y-n • T∈Icc (-T) (2*T) := by
    obtain ⟨hl,hr⟩ := abs_lt.mp hsmall
    constructor <;> linarith [hn.1,hn.2]
  simpa only [hp.sub_zsmul_eq n] using hh (x-n • T) hx (y-n • T) hy hd

theorem latticeMultiplier_norm_sub_le (c d : ℤ → ℂ) (C D : ℝ)
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hc : ∀ n, ‖c n‖ ≤ C) (hd : ∀ n, ‖d n‖ ≤ D)
    (ε : ℝ) (hε : 0 ≤ ε) (hcd : ∀ n, ‖c n-d n‖ ≤ ε) :
    ‖latticeMultiplier c C hC hc-latticeMultiplier d D hD hd‖ ≤ ε := by
  have he : latticeMultiplier c C hC hc-latticeMultiplier d D hD hd =
      latticeMultiplier (fun n => c n-d n) ε hε hcd := by
    ext ψ n
    simp [sub_mul]
  rw [he]
  exact latticeMultiplier_norm_le _ _ _ _

theorem continuous_sampled_latticeMultiplier (f : ℝ → ℂ) (hf : UniformContinuous f)
    (C : ℝ) (hC : 0 ≤ C) (hb : ∀ x, ‖f x‖ ≤ C) (ω : ℝ) :
    Continuous (fun θ : ℝ => latticeMultiplier (fun n => f (θ+(n:ℝ)*ω))
      C hC (fun n => hb (θ+(n:ℝ)*ω))) := by
  apply Metric.continuous_iff.mpr
  intro θ ε hε
  obtain ⟨δ,hδ,hh⟩ := Metric.uniformContinuous_iff.mp hf (ε/2) (by positivity)
  refine ⟨δ,hδ,?_⟩
  intro θ' hθ
  rw [dist_eq_norm]
  apply lt_of_le_of_lt (latticeMultiplier_norm_sub_le _ _ C C hC hC _ _ (ε/2)
    (by positivity) (fun n => ?_)) (by linarith)
  rw [← dist_eq_norm]
  exact (hh (by simpa only [dist_add_right] using hθ)).le

def phaseLatticeDifference (A : ℝ → TransferMatrix) (C : ℝ) (hC : 0 ≤ C)
    (hA : ∀ x i j, ‖A x i j‖ ≤ C) (ω θ : ℝ) : TwoByTwo Operator :=
  latticeDifference (fun n => A (θ+(n:ℝ)*ω)) C hC (fun n => hA (θ+(n:ℝ)*ω))

theorem continuous_phaseLatticeDifference (A : ℝ → TransferMatrix) (hA : Continuous A)
    {T : ℝ} (hT : 0 < T) (hp : Function.Periodic A T)
    (C : ℝ) (hC : 0 ≤ C) (hb : ∀ x i j, ‖A x i j‖ ≤ C) (ω : ℝ) :
    Continuous (phaseLatticeDifference A C hC hb ω) := by
  apply continuous_const.sub
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  exact continuous_sampled_latticeMultiplier (fun x => A x i j)
    (periodic_uniformContinuous_complex ((continuous_apply j).comp ((continuous_apply i).comp hA)) hT
      (fun x => congrFun (congrFun (hp x) i) j)) C hC (fun x => hb x i j) ω

theorem complexRealTransfer_bounded (a : ℝ) {lam : ℝ} (hlam : 0 ≤ lam)
    (hlam1 : lam < 1) (t : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ x i j, ‖complexRealTransfer a lam t x i j‖ ≤ C := by
  have he (i j : Fin 2) : ∃ C : ℝ, 0 ≤ C ∧ ∀ x, ‖complexRealTransfer a lam t x i j‖ ≤ C := by
    have hc := (continuous_apply j).comp
      ((continuous_apply i).comp (continuous_complexRealTransfer a hlam hlam1 t))
    have hp : Function.Periodic (fun x => complexRealTransfer a lam t x i j) (2*Real.pi) :=
      fun x => congrFun (congrFun (complexRealTransfer_periodic a lam t x) i) j
    obtain ⟨C,hC,hb⟩ := (hp.isBounded_of_continuous (by positivity) hc).exists_pos_norm_le
    exact ⟨C,hC.le,fun x => hb _ ⟨x,rfl⟩⟩
  choose C hC hb using he
  refine ⟨∑ i, ∑ j, C i j, Finset.sum_nonneg (fun i _ =>
    Finset.sum_nonneg (fun j _ => hC i j)), fun x i j => ?_⟩
  exact (hb i j x).trans ((Finset.single_le_sum (fun k _ => hC i k)
    (Finset.mem_univ j)).trans (Finset.single_le_sum
      (fun k _ => Finset.sum_nonneg (fun l _ => hC k l)) (Finset.mem_univ i)))

theorem continuous_real_latticeDifference (a : ℝ) {lam : ℝ} (hlam : 0 ≤ lam)
    (hlam1 : lam < 1) (t Φ C : ℝ) (hC : 0 ≤ C)
    (hb : ∀ x i j, ‖complexRealTransfer a lam t x i j‖ ≤ C) :
    Continuous (fun θ => latticeDifference
      (fun n => complexRealTransfer a lam t (phaseAngle Φ θ n)) C hC
      (fun n => hb (phaseAngle Φ θ n))) := by
  have hc := (continuous_phaseLatticeDifference (complexRealTransfer a lam t)
    (continuous_complexRealTransfer a hlam hlam1 t) (by positivity : 0<2*Real.pi)
    (complexRealTransfer_periodic a lam t) C hC hb (2*Real.pi*Φ)).comp
    (continuous_const.mul continuous_id : Continuous (fun θ : ℝ => (2*Real.pi)*θ))
  convert hc using 1
  funext θ
  have he (n : ℤ) : phaseAngle Φ θ n=2*Real.pi*θ+(n:ℝ)*(2*Real.pi*Φ) := by
    simp only [phaseAngle]
    ring
  ext i j ψ n
  simp [Function.comp_def, phaseLatticeDifference, latticeDifference, latticeMatrixMultiplier, he]

end UAMO.CMV

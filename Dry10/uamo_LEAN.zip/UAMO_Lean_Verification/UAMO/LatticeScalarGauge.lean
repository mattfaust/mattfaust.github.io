import UAMO.LatticeMultiplier
import UAMO.CMVTransfer

noncomputable section
namespace UAMO.PhysicalRepresentation
open Matrix
open scoped BigOperators

def orbitGauge (η : ℤ→ℂ) : ℤ→ℂ
  | Int.ofNat n => ∏ k∈Finset.range n,η (k:ℤ)
  | Int.negSucc n => (∏ k∈Finset.range (n+1),η (-((k:ℤ)+1)))⁻¹

theorem orbitGauge_norm (η : ℤ→ℂ) (hη : ∀ n,‖η n‖=1) (n : ℤ) : ‖orbitGauge η n‖=1 := by
  cases n <;> simp [orbitGauge,norm_prod,hη]

theorem orbitGauge_succ (η : ℤ→ℂ) (hη : ∀ n,‖η n‖=1) (n : ℤ) :
    orbitGauge η (n+1)=η n*orbitGauge η n := by
  have hne (k : ℤ) : η k≠0 := norm_ne_zero_iff.mp (by rw [hη]; norm_num)
  cases n with
  | ofNat n =>
    change (∏k∈Finset.range (n+1),η (k:ℤ))=η (n:ℤ)*(∏k∈Finset.range n,η (k:ℤ))
    rw [Finset.prod_range_succ,mul_comm]
  | negSucc n =>
    cases n with
    | zero =>
      change (1:ℂ)=η (-1)*(∏k∈Finset.range 1,η (-((k:ℤ)+1)))⁻¹
      simp [hne]
    | succ n =>
      have hn : Int.negSucc (n+1)+1=Int.negSucc n := by omega
      rw [hn]
      change (∏k∈Finset.range (n+1),η (-((k:ℤ)+1)))⁻¹=
        η (Int.negSucc (n+1))*(∏k∈Finset.range ((n+1)+1),η (-((k:ℤ)+1)))⁻¹
      conv_rhs => rw [Finset.prod_range_succ,_root_.mul_inv_rev]
      have hi : -(((n+1:ℕ):ℤ)+1)=Int.negSucc (n+1) := by omega
      rw [hi,← mul_assoc,mul_inv_cancel₀ (hne _),one_mul]

end UAMO.PhysicalRepresentation

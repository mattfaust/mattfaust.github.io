import UAMO.CircleLogMean

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory
open scoped ComplexConjugate

private theorem integral_logFourier_term (a : ℂ) (n : ℕ) (k : ℤ) :
    (∫ t in (0 : ℝ)..1,
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t) =
      (a ^ n * (if (n : ℤ) - k = 0 then 1 else 0) +
        conj a ^ n * (if -(n : ℤ) - k = 0 then 1 else 0)) / (2 * n) := by
  have hterm (t : ℝ) :
      ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) * logFourierChar (-k) t =
        (a ^ n * logFourierChar ((n : ℤ) - k) t +
          conj a ^ n * logFourierChar (-(n : ℤ) - k) t) / (2 * n) := by
    rw [Complex.re_eq_add_conj]
    simp only [map_div₀, map_pow, map_mul, map_natCast, logFourierChar_conj,
      mul_pow, logFourierChar_pow, one_mul, neg_one_mul]
    rw [sub_eq_add_neg, sub_eq_add_neg, logFourierChar_add, logFourierChar_add]
    ring
  simp_rw [hterm]
  rw [intervalIntegral.integral_div, intervalIntegral.integral_add]
  · simp only [intervalIntegral.integral_const_mul, integral_logFourierChar]
  · exact (continuous_const.mul (logFourierChar_continuous _)).intervalIntegrable _ _
  · exact (continuous_const.mul (logFourierChar_continuous _)).intervalIntegrable _ _

theorem logFourierCoeff_one_sub {a : ℂ} (ha : ‖a‖ < 1) {k : ℕ} (hk : 0 < k) :
    logFourierCoeff (fun t => Real.log ‖1 - a * logFourierChar 1 t‖) k =
      -(a ^ k / (2 * k)) := by
  have hterm (n : ℕ) :
      (∫ t in (0 : ℝ)..1,
        ((((a * logFourierChar 1 t) ^ n / n).re : ℝ) : ℂ) *
          logFourierChar (-(k : ℤ)) t) = if n = k then a ^ k / (2 * k) else 0 := by
    rw [integral_logFourier_term]
    have hneg : -(n : ℤ) - k ≠ 0 := by omega
    by_cases hn : n = k
    · subst n
      simp [hneg]
    · have hne : (n : ℤ) - k ≠ 0 := by omega
      simp [hn, hne, hneg]
  have h := hasSum_logFourier_integrals ha (k : ℤ)
  simp_rw [hterm] at h
  have heq := h.unique (hasSum_ite_eq k (a ^ k / (2 * k)))
  exact neg_eq_iff_eq_neg.mp heq

theorem logFourierCoeff_add {f g : ℝ → ℝ} (hf : Continuous f) (hg : Continuous g)
    (k : ℤ) :
    logFourierCoeff (fun t => f t + g t) k = logFourierCoeff f k + logFourierCoeff g k := by
  simp only [logFourierCoeff, Complex.ofReal_add, add_mul]
  apply intervalIntegral.integral_add
  · exact ((Complex.continuous_ofReal.comp hf).mul (logFourierChar_continuous _)).intervalIntegrable _ _
  · exact ((Complex.continuous_ofReal.comp hg).mul (logFourierChar_continuous _)).intervalIntegrable _ _

theorem logFourierChar_sub_ne_zero {a : ℂ} (ha : ‖a‖ ≠ 1) (t : ℝ) :
    logFourierChar 1 t - a ≠ 0 := by
  intro h
  apply ha
  have := congrArg norm (sub_eq_zero.mp h)
  simpa using this.symm

theorem continuous_logFourier_root {a : ℂ} (ha : ‖a‖ ≠ 1) :
    Continuous (fun t => Real.log ‖logFourierChar 1 t - a‖) := by
  exact ((logFourierChar_continuous 1).sub continuous_const).norm.log
    (fun t => norm_ne_zero_iff.mpr (logFourierChar_sub_ne_zero ha t))

private theorem logFourier_root_inside_norm (a : ℂ) (t : ℝ) :
    ‖logFourierChar 1 t - a‖ = ‖1 - conj a * logFourierChar 1 t‖ := by
  have hm : logFourierChar 1 t * logFourierChar (-1) t = 1 := by
    rw [← logFourierChar_add]
    simp
  calc
    ‖logFourierChar 1 t - a‖ = ‖conj (logFourierChar 1 t - a)‖ := (Complex.norm_conj _).symm
    _ = ‖logFourierChar 1 t * conj (logFourierChar 1 t - a)‖ := by
      rw [norm_mul, logFourierChar_norm, one_mul]
    _ = ‖1 - conj a * logFourierChar 1 t‖ := by
      congr 1
      simp only [map_sub, logFourierChar_conj, mul_sub, hm]
      ring

theorem logFourierCoeff_root_inside {a : ℂ} (ha : ‖a‖ < 1) {k : ℕ} (hk : 0 < k) :
    logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k =
      -(conj a ^ k / (2 * k)) := by
  simp_rw [logFourier_root_inside_norm]
  exact logFourierCoeff_one_sub (by simpa using ha) hk

theorem logFourierCoeff_root_outside {a : ℂ} (ha : 1 < ‖a‖) {k : ℕ} (hk : 0 < k) :
    logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k =
      -(a⁻¹ ^ k / (2 * k)) := by
  have ha0 : a ≠ 0 := by intro h; norm_num [h] at ha
  have hi : ‖a⁻¹‖ < 1 := by rw [norm_inv]; exact inv_lt_one_of_one_lt₀ ha
  have hn (t : ℝ) : 1 - a⁻¹ * logFourierChar 1 t ≠ 0 := by
    intro h
    have hh := congrArg norm (sub_eq_zero.mp h)
    have hh' : ‖a⁻¹‖ = 1 := by simpa [norm_mul] using hh.symm
    exact (ne_of_lt hi) hh'
  have hc : Continuous (fun t => Real.log ‖1 - a⁻¹ * logFourierChar 1 t‖) :=
    (continuous_const.sub (continuous_const.mul (logFourierChar_continuous 1))).norm.log
      (fun t => norm_ne_zero_iff.mpr (hn t))
  have heq (t : ℝ) : Real.log ‖logFourierChar 1 t - a‖ =
      Real.log ‖a‖ + Real.log ‖1 - a⁻¹ * logFourierChar 1 t‖ := by
    have hfactor : logFourierChar 1 t - a = -a * (1 - a⁻¹ * logFourierChar 1 t) := by
      field_simp
      ring
    rw [hfactor, norm_mul, norm_neg, Real.log_mul (norm_ne_zero_iff.mpr ha0)
      (norm_ne_zero_iff.mpr (hn t))]
  simp_rw [heq]
  rw [logFourierCoeff_add continuous_const hc, logFourierCoeff_const _ (by omega), zero_add]
  exact logFourierCoeff_one_sub hi hk

theorem norm_logFourierCoeff_root {a : ℂ} (ha : ‖a‖ ≠ 1) {k : ℤ} (hk : k ≠ 0) :
    ‖logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k‖ ≤
      1 / (2 * |(k : ℝ)|) := by
  have hpos (m : ℕ) (hm : 0 < m) :
      ‖logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) m‖ ≤
        1 / (2 * (m : ℝ)) := by
    rcases lt_or_gt_of_ne ha with h | h
    · rw [logFourierCoeff_root_inside h hm, norm_neg, norm_div, norm_pow, Complex.norm_conj]
      simp only [norm_mul, Complex.norm_ofNat, Complex.norm_natCast]
      exact div_le_div_of_nonneg_right (pow_le_one₀ (norm_nonneg a) h.le) (by positivity)
    · rw [logFourierCoeff_root_outside h hm, norm_neg, norm_div, norm_pow, norm_inv]
      simp only [norm_mul, Complex.norm_ofNat, Complex.norm_natCast]
      exact div_le_div_of_nonneg_right
        (pow_le_one₀ (inv_nonneg.mpr (norm_nonneg a)) (inv_le_one_of_one_le₀ h.le))
        (by positivity)
  rcases k with m | m
  · have hm : 0 < m := Nat.pos_of_ne_zero (by intro h; subst m; exact hk rfl)
    simpa using hpos m hm
  · have heq : Int.negSucc m = -((m + 1 : ℕ) : ℤ) := by omega
    rw [heq, logFourierCoeff_neg_frequency, Complex.norm_conj]
    simpa only [Int.cast_neg, Int.cast_natCast, abs_neg,
      abs_of_nonneg (Nat.cast_nonneg (m + 1) : (0 : ℝ) ≤ (m + 1 : ℕ))]
      using hpos (m + 1) (by omega)

end UAMO.CircleDOS

import UAMO.LogFourierDecay
import Mathlib.Analysis.Complex.Polynomial.Basic

noncomputable section

namespace UAMO.CircleDOS

open MeasureTheory
open scoped ComplexConjugate

private theorem logFourier_multiset_prod_ne_zero (s : Multiset ℂ)
    (hs : ∀ a ∈ s, ‖a‖ ≠ 1) (t : ℝ) :
    (s.map (fun a => logFourierChar 1 t - a)).prod ≠ 0 := by
  apply Multiset.prod_ne_zero
  intro h
  obtain ⟨a, ha, heq⟩ := Multiset.mem_map.mp h
  exact logFourierChar_sub_ne_zero (hs a ha) t heq

private theorem continuous_logFourier_multiset (s : Multiset ℂ)
    (hs : ∀ a ∈ s, ‖a‖ ≠ 1) :
    Continuous (fun t => Real.log ‖(s.map (fun a => logFourierChar 1 t - a)).prod‖) := by
  apply (continuous_multiset_prod s (fun _ _ =>
    (logFourierChar_continuous 1).sub continuous_const)).norm.log
  exact fun t => norm_ne_zero_iff.mpr (logFourier_multiset_prod_ne_zero s hs t)

theorem norm_logFourierCoeff_multiset (s : Multiset ℂ)
    (hs : ∀ a ∈ s, ‖a‖ ≠ 1) {k : ℤ} (hk : k ≠ 0) :
    ‖logFourierCoeff (fun t =>
      Real.log ‖(s.map (fun a => logFourierChar 1 t - a)).prod‖) k‖ ≤
      (s.card : ℝ) / (2 * |(k : ℝ)|) := by
  induction s using Multiset.induction_on with
  | empty => simp [logFourierCoeff]
  | @cons a s ih =>
    have ha : ‖a‖ ≠ 1 := hs a (by simp)
    have hs' : ∀ b ∈ s, ‖b‖ ≠ 1 := fun b hb => hs b (by simp [hb])
    have heq (t : ℝ) :
        Real.log ‖((a ::ₘ s).map (fun b => logFourierChar 1 t - b)).prod‖ =
          Real.log ‖logFourierChar 1 t - a‖ +
          Real.log ‖(s.map (fun b => logFourierChar 1 t - b)).prod‖ := by
      simp only [Multiset.map_cons, Multiset.prod_cons, norm_mul]
      exact Real.log_mul (norm_ne_zero_iff.mpr (logFourierChar_sub_ne_zero ha t))
        (norm_ne_zero_iff.mpr (logFourier_multiset_prod_ne_zero s hs' t))
    simp_rw [heq]
    rw [logFourierCoeff_add (continuous_logFourier_root ha)
      (continuous_logFourier_multiset s hs')]
    calc
      _ ≤ ‖logFourierCoeff (fun t => Real.log ‖logFourierChar 1 t - a‖) k‖ +
          ‖logFourierCoeff (fun t =>
            Real.log ‖(s.map (fun b => logFourierChar 1 t - b)).prod‖) k‖ := norm_add_le _ _
      _ ≤ 1 / (2 * |(k : ℝ)|) + (s.card : ℝ) / (2 * |(k : ℝ)|) :=
        add_le_add (norm_logFourierCoeff_root ha hk) (ih hs')
      _ = ((a ::ₘ s).card : ℝ) / (2 * |(k : ℝ)|) := by
        simp only [Multiset.card_cons, Nat.cast_add, Nat.cast_one]
        ring

theorem exists_logFourierChar_eq {a : ℂ} (ha : ‖a‖ = 1) :
    ∃ t : ℝ, logFourierChar 1 t = a := by
  obtain ⟨θ, hθ⟩ := (Complex.norm_eq_one_iff a).mp ha
  refine ⟨θ / (2 * Real.pi), ?_⟩
  rw [← hθ]
  unfold logFourierChar
  congr 1
  push_cast
  field_simp [Real.pi_ne_zero]
  ring

theorem continuous_logPolynomial_boundary (P : Polynomial ℂ)
    (hP : ∀ t : ℝ, P.eval (logFourierChar 1 t) ≠ 0) :
    Continuous (fun t => Real.log ‖P.eval (logFourierChar 1 t)‖) := by
  exact (P.continuous.comp (logFourierChar_continuous 1)).norm.log
    (fun t => norm_ne_zero_iff.mpr (hP t))

theorem norm_logPolynomialFourierCoeff (P : Polynomial ℂ) (hP0 : P ≠ 0)
    (hP : ∀ t : ℝ, P.eval (logFourierChar 1 t) ≠ 0) {k : ℤ} (hk : k ≠ 0) :
    ‖logFourierCoeff (fun t => Real.log ‖P.eval (logFourierChar 1 t)‖) k‖ ≤
      (P.natDegree : ℝ) / (2 * |(k : ℝ)|) := by
  have hs : ∀ a ∈ P.roots, ‖a‖ ≠ 1 := by
    intro a ha hnorm
    obtain ⟨t, ht⟩ := exists_logFourierChar_eq hnorm
    apply hP t
    rw [ht]
    exact Polynomial.isRoot_of_mem_roots ha
  have hlc : ‖P.leadingCoeff‖ ≠ 0 :=
    norm_ne_zero_iff.mpr (Polynomial.leadingCoeff_ne_zero.mpr hP0)
  have heq (t : ℝ) : Real.log ‖P.eval (logFourierChar 1 t)‖ =
      Real.log ‖P.leadingCoeff‖ +
      Real.log ‖(P.roots.map (fun a => logFourierChar 1 t - a)).prod‖ := by
    rw [Polynomial.eval_eq_prod_roots_sub_of_splits_id (IsAlgClosed.splits P), norm_mul]
    exact Real.log_mul hlc (norm_ne_zero_iff.mpr (logFourier_multiset_prod_ne_zero P.roots hs t))
  simp_rw [heq]
  rw [logFourierCoeff_add continuous_const (continuous_logFourier_multiset P.roots hs),
    logFourierCoeff_const _ hk, zero_add]
  have hcard : P.natDegree = P.roots.card := by
    simpa using Polynomial.natDegree_eq_card_roots (IsAlgClosed.splits P)
  rw [hcard]
  exact norm_logFourierCoeff_multiset P.roots hs hk

end UAMO.CircleDOS

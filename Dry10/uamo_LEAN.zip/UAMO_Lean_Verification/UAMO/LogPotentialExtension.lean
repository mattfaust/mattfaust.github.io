import UAMO.TraceLogDerivative
import UAMO.CFCParameterContinuity
import Mathlib.Topology.Instances.EReal.Lemmas
import Mathlib.Topology.Semicontinuous
import Mathlib.Topology.Order.MonotoneConvergence
import Mathlib.Analysis.SpecificLimits.Basic

noncomputable section

namespace UAMO

open Set Filter MeasureTheory
open scoped Topology ContinuousFunctionalCalculus

local instance logExtension_realNormedSpace (φ : ℝ) : NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)

local instance logExtension_realModule (φ : ℝ) : Module ℝ (magneticAlgebra φ) :=
  @Algebra.toModule ℝ (magneticAlgebra φ) _ _
    (magneticAlgebra_realNormedAlgebra φ).toAlgebra

local instance logExtension_continuousSMul (φ : ℝ) : ContinuousSMul ℝ (magneticAlgebra φ) := by
  constructor
  apply continuous_induced_rng.mpr
  change Continuous (fun p : ℝ × magneticAlgebra φ => p.1 • (p.2 : MagneticOperator))
  exact continuous_fst.smul (continuous_subtype_val.comp continuous_snd)

local instance logExtension_nontrivial (φ : ℝ) : Nontrivial (magneticAlgebra φ) := by
  apply nontrivial_of_ne (0 : magneticAlgebra φ) 1
  intro h
  have hh := congrArg (magneticTraceReal φ) h
  exact zero_ne_one (by simpa only [map_zero, magneticTraceReal_one] using hh)

def logRegularizationScale (n : ℕ) : ℝ := 1 / ((n : ℝ) + 1)

theorem logRegularizationScale_pos (n : ℕ) : 0 < logRegularizationScale n := by
  unfold logRegularizationScale
  positivity

theorem logRegularizationScale_antitone : Antitone logRegularizationScale := by
  intro n m hnm
  apply one_div_le_one_div_of_le
  · positivity
  · exact add_le_add_right (Nat.cast_le.mpr hnm) 1

theorem logRegularizationScale_tendsto :
    Tendsto logRegularizationScale atTop (𝓝 0) :=
  tendsto_one_div_add_atTop_nhds_zero_nat

def regularizedLogKernel (n : ℕ) (x : ℝ) : ℝ :=
  Real.log (|x| + logRegularizationScale n)

theorem regularizedLogKernel_continuous (n : ℕ) :
    Continuous (regularizedLogKernel n) :=
  (continuous_abs.add continuous_const).log fun x =>
    (add_pos_of_nonneg_of_pos (abs_nonneg x) (logRegularizationScale_pos n)).ne'

theorem regularizedLogKernel_antitone (x : ℝ) :
    Antitone (fun n => regularizedLogKernel n x) := by
  intro n m hnm
  exact Real.log_le_log
    (add_pos_of_nonneg_of_pos (abs_nonneg x) (logRegularizationScale_pos m))
    (add_le_add_left (logRegularizationScale_antitone hnm) |x|)

def scalarRegularizedLogPotential (a α : ℝ) (n : ℕ) (p : ℝ × ℝ) : ℝ :=
  magneticTraceReal α
    (cfc (regularizedLogKernel n) (scalarAlgebraPencil a p.1 α p.2))

theorem scalarAlgebraPencil_joint_continuous (a α : ℝ) :
    Continuous (fun p : ℝ × ℝ => scalarAlgebraPencil a p.1 α p.2) := by
  change Continuous (fun p : ℝ × ℝ => p.2 • (1 : magneticAlgebra α) -
    (algebraMagneticPair α (1, 0) 1 +
      p.1 • algebraMagneticPair α (1, 1) (diagonalHopping a α) +
        p.1 ^ 2 • algebraMagneticPair α (1, 2) (-1)))
  fun_prop

theorem scalarRegularizedLogPotential_continuous (a α : ℝ) (n : ℕ) :
    Continuous (scalarRegularizedLogPotential a α n) := by
  apply continuous_iff_continuousAt.mpr
  intro p
  exact (magneticTraceReal α).continuous.continuousAt.comp
    (continuousAt_cfc_of_continuous
      (fun q : ℝ × ℝ => scalarAlgebraPencil a q.1 α q.2) p
      (scalarAlgebraPencil_joint_continuous a α).continuousAt
      (regularizedLogKernel n) (regularizedLogKernel_continuous n)
      (Eventually.of_forall fun q => scalarAlgebraPencil_isSelfAdjoint a q.1 α q.2))

theorem scalarRegularizedLogPotential_eq_spectralIntegral
    (a α lam energy : ℝ) (n : ℕ) :
    scalarRegularizedLogPotential a α n (lam, energy) =
      ∫ x : ScalarRealSpectrum a lam α,
        regularizedLogKernel n (energy - (x : ℝ)) ∂scalarSpectralMeasure a lam α := by
  have hshift : Continuous (fun x : ℝ => energy - x) := continuous_const.sub continuous_id
  have hkernel : ContinuousOn (fun x : ℝ => regularizedLogKernel n (energy - x))
      (spectrum ℝ (scalarAlgebraHamiltonian a lam α)) :=
    ((regularizedLogKernel_continuous n).comp hshift).continuousOn
  rw [scalarSpectralMeasure_integral_cfc_of_continuousOn a lam α
    (fun x : ℝ => regularizedLogKernel n (energy - x)) hkernel,
    cfc_comp' (regularizedLogKernel n) (fun x : ℝ => energy - x)
      (scalarAlgebraHamiltonian a lam α)
      (regularizedLogKernel_continuous n).continuousOn hshift.continuousOn
      (scalarAlgebraHamiltonian_isSelfAdjoint a lam α),
    cfc_real_pencil _ (scalarAlgebraHamiltonian_isSelfAdjoint a lam α) energy]
  rfl

theorem scalarRegularizedLogPotential_eq_realSpectralIntegral
    (a α lam energy : ℝ) (n : ℕ) :
    scalarRegularizedLogPotential a α n (lam, energy) =
      ∫ x : ℝ, regularizedLogKernel n (energy - x)
        ∂scalarRealSpectralMeasure a lam α := by
  rw [scalarRealSpectralMeasure_integral_eq_subtype]
  exact scalarRegularizedLogPotential_eq_spectralIntegral a α lam energy n

theorem scalar_regularizedLogKernel_integrable (a α lam energy : ℝ) (n : ℕ) :
    Integrable (fun x : ScalarRealSpectrum a lam α =>
      regularizedLogKernel n (energy - (x : ℝ))) (scalarSpectralMeasure a lam α) :=
  ((regularizedLogKernel_continuous n).comp
    (continuous_const.sub continuous_subtype_val)).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)

theorem scalarRegularizedLogPotential_antitone (a α : ℝ) (p : ℝ × ℝ) :
    Antitone (fun n => scalarRegularizedLogPotential a α n p) := by
  intro n m hnm
  change scalarRegularizedLogPotential a α m (p.1, p.2) ≤
    scalarRegularizedLogPotential a α n (p.1, p.2)
  rw [scalarRegularizedLogPotential_eq_spectralIntegral a α p.1 p.2 m,
    scalarRegularizedLogPotential_eq_spectralIntegral a α p.1 p.2 n]
  exact integral_mono
    (scalar_regularizedLogKernel_integrable a α p.1 p.2 m)
    (scalar_regularizedLogKernel_integrable a α p.1 p.2 n)
    (fun x => regularizedLogKernel_antitone (p.2 - (x : ℝ)) hnm)

def scalarTotalLogPotential (a α : ℝ) (p : ℝ × ℝ) : EReal :=
  ⨅ n : ℕ, (scalarRegularizedLogPotential a α n p : EReal)

def scalarPositiveLogPotential (a α : ℝ) (p : ℝ × ℝ) : ℝ :=
  ⨅ n : ℕ, max 0 (scalarRegularizedLogPotential a α n p)

theorem scalarPositiveLogPotential_bddBelow (a α : ℝ) (p : ℝ × ℝ) :
    BddBelow (range fun n : ℕ => max 0 (scalarRegularizedLogPotential a α n p)) :=
  ⟨0, by rintro _ ⟨n, rfl⟩; exact le_max_left _ _⟩

theorem scalarPositiveLogPotential_nonneg (a α : ℝ) (p : ℝ × ℝ) :
    0 ≤ scalarPositiveLogPotential a α p :=
  le_ciInf fun _ => le_max_left _ _

theorem scalarPositiveLogPotential_upperSemicontinuous (a α : ℝ) :
    UpperSemicontinuous (scalarPositiveLogPotential a α) :=
  upperSemicontinuous_ciInf (scalarPositiveLogPotential_bddBelow a α) fun n =>
    (continuous_const.max (scalarRegularizedLogPotential_continuous a α n)).upperSemicontinuous

theorem scalarRegularizedLogPotential_tendsto (a α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a lam α)) :
    Tendsto (fun n : ℕ => scalarRegularizedLogPotential a α n (lam, energy))
      atTop (𝓝 (scalarLogPotential a lam α energy)) := by
  let K : ℝ → C(ScalarRealSpectrum a lam α, ℝ) := fun t =>
    ⟨fun x => Real.log (|energy - (x : ℝ)| + |t|),
      ((continuous_const.sub continuous_subtype_val).abs.add continuous_const).log
        (fun x => (add_pos_of_pos_of_nonneg
          (abs_pos.mpr (scalar_spectral_shift_ne_zero a lam α energy hm x))
          (abs_nonneg t)).ne')⟩
  have hK : Continuous K := by
    apply ContinuousMap.continuous_of_continuous_uncurry
    exact (((continuous_const.sub
      (continuous_subtype_val.comp continuous_snd)).abs).add continuous_fst.abs).log
      (fun p => (add_pos_of_pos_of_nonneg
        (abs_pos.mpr (scalar_spectral_shift_ne_zero a lam α energy hm p.2))
        (abs_nonneg p.1)).ne')
  have htrace : Continuous (fun t => magneticTraceReal α
      (cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a lam α) (K t))) :=
    (magneticTraceReal α).continuous.comp
      ((cfcHom_continuous (scalarAlgebraHamiltonian_isSelfAdjoint a lam α)).comp hK)
  have hlimit := htrace.continuousAt.tendsto.comp logRegularizationScale_tendsto
  have hn (n : ℕ) : magneticTraceReal α
      (cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a lam α)
        (K (logRegularizationScale n))) =
      scalarRegularizedLogPotential a α n (lam, energy) := by
    rw [← scalarSpectralMeasure_integral,
      scalarRegularizedLogPotential_eq_spectralIntegral a α lam energy n]
    apply integral_congr_ae
    exact Eventually.of_forall fun x => by
      simp only [K, ContinuousMap.coe_mk, regularizedLogKernel,
        abs_of_pos (logRegularizationScale_pos n)]
  have hzero : magneticTraceReal α
      (cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a lam α) (K 0)) =
      scalarLogPotential a lam α energy := by
    rw [← scalarSpectralMeasure_integral, scalarLogPotential,
      scalarTraceLog_eq_spectralIntegral a lam α energy hm]
    apply integral_congr_ae
    exact Eventually.of_forall fun x => by simp only [K, ContinuousMap.coe_mk, abs_zero, add_zero]
  simpa only [Function.comp_def, hn, hzero] using hlimit

theorem scalarTotalLogPotential_eq_magneticLogPotential (a α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a lam α)) :
    scalarTotalLogPotential a α (lam, energy) =
      (scalarLogPotential a lam α energy : EReal) := by
  apply iInf_eq_of_tendsto
  · intro n m hnm
    exact EReal.coe_le_coe_iff.mpr
      (scalarRegularizedLogPotential_antitone a α (lam, energy) hnm)
  · exact continuous_coe_real_ereal.continuousAt.tendsto.comp
      (scalarRegularizedLogPotential_tendsto a α lam energy hm)

theorem scalarPositiveLogPotential_eq_max (a α lam energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a lam α)) :
    scalarPositiveLogPotential a α (lam, energy) =
      max 0 (scalarLogPotential a lam α energy) := by
  have hanti : Antitone (fun n : ℕ => max 0
      (scalarRegularizedLogPotential a α n (lam, energy))) := by
    intro n m hnm
    exact max_le_max_left 0 (scalarRegularizedLogPotential_antitone a α (lam, energy) hnm)
  exact tendsto_nhds_unique
    (tendsto_atTop_ciInf hanti (scalarPositiveLogPotential_bddBelow a α (lam, energy)))
    (tendsto_const_nhds.max (scalarRegularizedLogPotential_tendsto a α lam energy hm))

theorem scalarRegularizedLogPotential_nonneg_of_total_eq_zero
    (a α : ℝ) (p : ℝ × ℝ) (hzero : scalarTotalLogPotential a α p = 0) (n : ℕ) :
    0 ≤ scalarRegularizedLogPotential a α n p := by
  have h : (0 : EReal) ≤ (scalarRegularizedLogPotential a α n p : EReal) :=
    hzero ▸ iInf_le (fun n : ℕ => (scalarRegularizedLogPotential a α n p : EReal)) n
  exact EReal.coe_le_coe_iff.mp h

theorem scalarPositiveLogPotential_eq_zero_of_total_eq_zero
    (a α : ℝ) (p : ℝ × ℝ) (hzero : scalarTotalLogPotential a α p = 0) :
    scalarPositiveLogPotential a α p = 0 := by
  apply le_antisymm _ (scalarPositiveLogPotential_nonneg a α p)
  by_contra h
  have hpos : 0 < scalarPositiveLogPotential a α p := lt_of_not_ge h
  have hlt : scalarTotalLogPotential a α p < (scalarPositiveLogPotential a α p : EReal) := by
    rw [hzero]
    exact EReal.coe_lt_coe_iff.mpr hpos
  obtain ⟨n, hn⟩ := iInf_lt_iff.mp hlt
  have hn' : scalarRegularizedLogPotential a α n p < scalarPositiveLogPotential a α p :=
    EReal.coe_lt_coe_iff.mp hn
  have hle : scalarPositiveLogPotential a α p ≤ max 0 (scalarRegularizedLogPotential a α n p) :=
    ciInf_le (scalarPositiveLogPotential_bddBelow a α p) n
  exact (not_lt_of_ge hle) (max_lt hpos hn')

end UAMO

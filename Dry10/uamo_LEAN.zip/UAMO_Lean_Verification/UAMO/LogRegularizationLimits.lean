import UAMO.LogPotentialExtension

noncomputable section
namespace UAMO
open Filter Set
open scoped Topology

theorem regularization_inf_le (F : ℝ → ℝ) (hF : MonotoneOn F (Ioi 0))
    (δ : ℝ) (hδ : 0 < δ) :
    (⨅ n : ℕ, (F (logRegularizationScale n) : EReal)) ≤ (F δ : EReal) := by
  obtain ⟨n, hn⟩ := (logRegularizationScale_tendsto.eventually (gt_mem_nhds hδ)).exists
  exact (iInf_le (fun n : ℕ => (F (logRegularizationScale n) : EReal)) n).trans
    (EReal.coe_le_coe_iff.mpr (hF (logRegularizationScale_pos n) hδ hn.le))

theorem tendsto_regularization_inf (F : ℝ → ℝ) (hF : MonotoneOn F (Ioi 0))
    (δ : ℕ → ℝ) (hδ : ∀ n, 0 < δ n) (hlim : Tendsto δ atTop (𝓝 0)) :
    Tendsto (fun n => (F (δ n) : EReal)) atTop
      (𝓝 (⨅ n : ℕ, (F (logRegularizationScale n) : EReal))) := by
  apply tendsto_order.mpr
  constructor
  · intro b hb
    exact Eventually.of_forall fun n => hb.trans_le (regularization_inf_le F hF (δ n) (hδ n))
  · intro b hb
    obtain ⟨m, hm⟩ := iInf_lt_iff.mp hb
    filter_upwards [hlim.eventually (gt_mem_nhds (logRegularizationScale_pos m))] with n hn
    exact (EReal.coe_le_coe_iff.mpr
      (hF (hδ n) (logRegularizationScale_pos m) hn.le)).trans_lt hm

theorem tendsto_ereal_add_real {s : ℕ → EReal} {L : EReal}
    (hs : Tendsto s atTop (𝓝 L)) (c : ℝ) :
    Tendsto (fun n => (c : EReal) + s n) atTop (𝓝 ((c : EReal)+L)) := by
  exact (EReal.continuousAt_add (p := ((c : EReal), L))
    (Or.inl (EReal.coe_ne_top c)) (Or.inl (EReal.coe_ne_bot c))).tendsto.comp
      (tendsto_const_nhds.prodMk_nhds hs)

theorem tendsto_ereal_mul_real {s : ℕ → EReal} {L : EReal}
    (hs : Tendsto s atTop (𝓝 L)) (c : ℝ) (hc : c ≠ 0) :
    Tendsto (fun n => (c : EReal) * s n) atTop (𝓝 ((c : EReal)*L)) := by
  have hce : (c : EReal) ≠ 0 := by exact_mod_cast hc
  exact (EReal.continuousAt_mul (p := ((c : EReal), L))
    (Or.inl hce) (Or.inl hce) (Or.inl (EReal.coe_ne_bot c))
    (Or.inl (EReal.coe_ne_top c))).tendsto.comp (tendsto_const_nhds.prodMk_nhds hs)

end UAMO

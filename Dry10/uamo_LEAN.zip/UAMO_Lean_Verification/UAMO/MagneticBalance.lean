import UAMO.MagneticStationarity
import Mathlib.Analysis.InnerProductSpace.LinearMap

noncomputable section
namespace UAMO
open scoped InnerProductSpace

def magneticHPlus (a r φ : ℝ) : MagneticOperator :=
  (1/2 : ℂ) • (scalarHamiltonian a r φ + scalarRightHamiltonian a r φ)

def magneticHMinus (a r φ : ℝ) : MagneticOperator :=
  (1/2 : ℂ) • (scalarHamiltonian a r φ - scalarRightHamiltonian a r φ)

theorem magneticHPlus_selfAdjoint (a r φ : ℝ) : IsSelfAdjoint (magneticHPlus a r φ) := by
  simp [IsSelfAdjoint, magneticHPlus, star_smul, star_add,
    (scalarHamiltonian_selfAdjoint a r φ).star_eq,
    (scalarRightHamiltonian_selfAdjoint a r φ).star_eq]

theorem magneticHMinus_selfAdjoint (a r φ : ℝ) : IsSelfAdjoint (magneticHMinus a r φ) := by
  simp [IsSelfAdjoint, magneticHMinus, star_smul, star_sub,
    (scalarHamiltonian_selfAdjoint a r φ).star_eq,
    (scalarRightHamiltonian_selfAdjoint a r φ).star_eq]

theorem magneticHMinus_vanishes_on_cyclic (a r φ : ℝ) (u : MagneticSpace)
    (hu : u ∈ scalarCyclicSpace a r φ) : magneticHMinus a r φ u = 0 :=
  scalarAntisymmetric_vanishes_on_cyclic a r φ u hu

theorem magneticHPlus_eq_on_cyclic (a r φ : ℝ) (u : MagneticSpace)
    (hu : u ∈ scalarCyclicSpace a r φ) :
    magneticHPlus a r φ u = scalarHamiltonian a r φ u := by
  simp only [magneticHPlus, ContinuousLinearMap.smul_apply, ContinuousLinearMap.add_apply,
    scalarRightHamiltonian_eq_on_cyclic a r φ u hu]
  module

theorem magneticHPlus_origin (a r φ : ℝ) :
    magneticHPlus a r φ magneticOrigin = scalarHamiltonian a r φ magneticOrigin :=
  magneticHPlus_eq_on_cyclic a r φ _ (magneticOrigin_mem_scalarCyclicSpace a r φ)

theorem boundary_pairing_from_columns
    (L Hp Hm D F : MagneticOperator) (Ω A : MagneticSpace)
    (c : MagneticSite → ℂ)
    (hHm : Hm.toLinearMap.IsSymmetric)
    (hcolumns : ∀ s : MagneticSite,
      L (Hp (D (lp.single 2 s 1))) =
        c s • Hm (lp.single 2 s 1) + F (lp.single 2 s 1) +
          ⟪Ω, lp.single 2 s 1⟫_ℂ • A)
    (v : MagneticSpace) (hv : Hm v = 0) (w : MagneticSpace) :
    ⟪v, L (Hp (D w))⟫_ℂ = ⟪v, F w⟫_ℂ + ⟪v, A⟫_ℂ * ⟪Ω, w⟫_ℂ := by
  let f : MagneticSpace →L[ℂ] ℂ :=
    (innerSL ℂ v).comp (L.comp (Hp.comp D))
  let g : MagneticSpace →L[ℂ] ℂ :=
    (innerSL ℂ v).comp F + ⟪v, A⟫_ℂ • innerSL ℂ Ω
  have hsingle (s : MagneticSite) : f (lp.single 2 s 1) = g (lp.single 2 s 1) := by
    change ⟪v, L (Hp (D (lp.single 2 s 1)))⟫_ℂ =
      ⟪v, F (lp.single 2 s 1)⟫_ℂ + ⟪v, A⟫_ℂ * ⟪Ω, lp.single 2 s 1⟫_ℂ
    have hz : ⟪v, Hm (lp.single 2 s 1)⟫_ℂ = 0 := by
      rw [← hHm.apply_clm v (lp.single 2 s 1), hv, inner_zero_left]
    rw [hcolumns, inner_add_right, inner_add_right, inner_smul_right,
      hz, mul_zero, zero_add, inner_smul_right]
    ring
  have hfg : f = g := by
    apply lp.ext_continuousLinearMap (by norm_num : (2 : ENNReal) ≠ ⊤)
    intro s
    apply ContinuousLinearMap.ext
    intro z
    change f (lp.single 2 s z) = g (lp.single 2 s z)
    have hscalar : (lp.single 2 s z : MagneticSpace) = z • lp.single 2 s (1 : ℂ) := by
      simp [← lp.single_smul]
    rw [hscalar, map_smul, map_smul, hsingle]
  exact congrArg (fun T : MagneticSpace →L[ℂ] ℂ => T w) hfg

theorem magnetic_balance_from_columns
    (L Hp Hm D F : MagneticOperator) (Ω : MagneticSpace)
    (c : MagneticSite → ℂ)
    (hL : L.toLinearMap.IsSymmetric) (hHp : Hp.toLinearMap.IsSymmetric)
    (hHm : Hm.toLinearMap.IsSymmetric) (hD : D.toLinearMap.IsSymmetric)
    (hF : F.toLinearMap.IsSymmetric)
    (hcolumns : ∀ s : MagneticSite,
      L (Hp (D (lp.single 2 s 1))) =
        c s • Hm (lp.single 2 s 1) + F (lp.single 2 s 1) +
          ⟪Ω, lp.single 2 s 1⟫_ℂ • L (Hp Ω))
    (hgeometry : ∀ w, L (Hp w) - Hp (L w) = L (Hp (D w)) - D (Hp (L w)))
    (v w : MagneticSpace) (hv : Hm v = 0) (hw : Hm w = 0) :
    ⟪v, L (Hp w) - Hp (L w)⟫_ℂ =
      ⟪v, L (Hp Ω)⟫_ℂ * ⟪Ω, w⟫_ℂ -
        ⟪v, Ω⟫_ℂ * ⟪L (Hp Ω), w⟫_ℂ := by
  have hpv := boundary_pairing_from_columns L Hp Hm D F Ω (L (Hp Ω))
    c hHm hcolumns v hv w
  have hpw := boundary_pairing_from_columns L Hp Hm D F Ω (L (Hp Ω))
    c hHm hcolumns w hw v
  have hpw' := congrArg (starRingEnd ℂ) hpw
  simp only [map_add, map_mul, inner_conj_symm] at hpw'
  have hdual : ⟪v, D (Hp (L w))⟫_ℂ = ⟪L (Hp (D v)), w⟫_ℂ := by
    calc
      ⟪v, D (Hp (L w))⟫_ℂ = ⟪D v, Hp (L w)⟫_ℂ := (hD v _).symm
      _ = ⟪Hp (D v), L w⟫_ℂ := (hHp (D v) _).symm
      _ = ⟪L (Hp (D v)), w⟫_ℂ := (hL (Hp (D v)) w).symm
  rw [hgeometry, inner_sub_right, hpv, hdual, hpw', hF.apply_clm v w]
  ring

end UAMO

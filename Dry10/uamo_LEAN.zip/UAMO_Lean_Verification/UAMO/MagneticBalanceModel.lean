import UAMO.MagneticSector
import UAMO.MagneticBalance

noncomputable section
namespace UAMO
open MagneticBoundary
open scoped InnerProductSpace

local instance : DecidablePred onBoundary := fun s =>
  inferInstanceAs (Decidable (s.1 = 0 ∨ s.1 = s.2))

def boundaryVector (u : MagneticSpace) : MagneticSpace := by
  classical
  exact ⟨fun s => if onBoundary s then u s else 0, by
    apply memℓp_gen
    have h : Summable (fun s => ‖if onBoundary s then u s else 0‖ ^ (2 : ℕ)) :=
      Summable.of_nonneg_of_le (fun s => sq_nonneg _)
        (fun s => by split_ifs <;> simp) (magneticSpace_summable_sq u)
    simpa using h⟩

@[simp] theorem boundaryVector_apply (u : MagneticSpace) (s : MagneticSite) :
    boundaryVector u s = if onBoundary s then u s else 0 := by
  classical
  rfl

theorem boundaryVector_norm_le (u : MagneticSpace) : ‖boundaryVector u‖ ≤ ‖u‖ := by
  apply (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [magneticSpace_norm_sq, magneticSpace_norm_sq]
  exact Summable.tsum_le_tsum
    (fun s => by simp only [boundaryVector_apply]; split_ifs <;> simp)
    (magneticSpace_summable_sq (boundaryVector u)) (magneticSpace_summable_sq u)

def magneticBoundaryProjection : MagneticOperator :=
  LinearMap.mkContinuous
    { toFun := boundaryVector
      map_add' := by
        intro u v
        apply lp.ext
        funext s
        simp only [boundaryVector_apply, lp.coeFn_add, Pi.add_apply]
        split_ifs <;> simp
      map_smul' := by
        intro c u
        apply lp.ext
        funext s
        simp only [boundaryVector_apply, lp.coeFn_smul, Pi.smul_apply]
        split_ifs <;> simp }
    1 (fun u => by simpa using boundaryVector_norm_le u)

@[simp] theorem magneticBoundaryProjection_apply (u : MagneticSpace) (s : MagneticSite) :
    magneticBoundaryProjection u s = if onBoundary s then u s else 0 := by
  classical
  rfl

theorem magneticBoundaryProjection_selfAdjoint : IsSelfAdjoint magneticBoundaryProjection := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro u v
  rw [lp.inner_eq_tsum, lp.inner_eq_tsum]
  apply tsum_congr
  intro s
  change ⟪(if onBoundary s then u s else 0), v s⟫_ℂ =
    ⟪u s, (if onBoundary s then v s else 0)⟫_ℂ
  split_ifs <;> simp

theorem magneticBoundaryProjection_single (s : MagneticSite) (z : ℂ) :
    magneticBoundaryProjection (lp.single 2 s z) =
      if onBoundary s then (lp.single 2 s z : MagneticSpace) else 0 := by
  classical
  apply lp.ext
  funext t
  by_cases ht : t = s
  · subst t
    simp only [magneticBoundaryProjection_apply]
    split_ifs <;> simp
  · by_cases hs : onBoundary s <;>
      simp [lp.single_apply, Pi.single_apply, magneticBoundaryProjection_apply,
        hs, ht, Ne.symm ht]

theorem magneticBoundaryProjection_origin :
    magneticBoundaryProjection magneticOrigin = magneticOrigin := by
  simp [magneticOrigin, magneticBoundaryProjection_single, onBoundary]

def latticeRankOne (t s : MagneticSite) : MagneticOperator :=
  (innerSL ℂ (lp.single 2 s 1)).smulRight (lp.single 2 t 1)

@[simp] theorem latticeRankOne_apply (t s : MagneticSite) (u : MagneticSpace) :
    latticeRankOne t s u = u s • lp.single 2 t 1 := by
  simp [latticeRankOne, lp.inner_single_left]

def latticeSymmetricPair (s t : MagneticSite) : MagneticOperator :=
  latticeRankOne s t + latticeRankOne t s

theorem latticeSymmetricPair_selfAdjoint (s t : MagneticSite) :
    IsSelfAdjoint (latticeSymmetricPair s t) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro u v
  simp [latticeSymmetricPair, inner_add_left, inner_add_right, inner_smul_left,
    inner_smul_right, lp.inner_single_left, lp.inner_single_right]
  ring

def magneticBoundaryCorrection (r φ : ℝ) : MagneticOperator :=
  (Real.cos φ : ℂ) •
    (latticeSymmetricPair (1,1) (0,1) + latticeSymmetricPair (-1,-1) (0,-1) +
      (r : ℂ)^2 •
        (latticeSymmetricPair (1,1) (0,-1) + latticeSymmetricPair (-1,-1) (0,1)))

theorem magneticBoundaryCorrection_selfAdjoint (r φ : ℝ) :
    IsSelfAdjoint (magneticBoundaryCorrection r φ) := by
  simp [IsSelfAdjoint, magneticBoundaryCorrection, star_smul, star_add,
    (latticeSymmetricPair_selfAdjoint _ _).star_eq, ← Complex.ofReal_cos]

theorem magneticBoundaryCorrection_origin (r φ : ℝ) :
    magneticBoundaryCorrection r φ magneticOrigin = 0 := by
  simp [magneticBoundaryCorrection, latticeSymmetricPair, magneticOrigin,
    lp.single_apply, Pi.single_apply, Prod.ext_iff]

theorem magneticShift_single (φ : ℝ) (ν s : MagneticSite) :
    magneticShift φ ν (lp.single 2 s 1) =
      latticePhase φ (wedge ν s) • lp.single 2 (s+ν) 1 := by
  apply lp.ext
  funext t
  by_cases ht : t = s+ν
  · subst t
    have hw : wedge ν (s+ν) = wedge ν s := by simp [wedge]; ring
    simp [magneticShift_apply, hw]
  · have hsub : t-ν ≠ s := by
      intro h
      exact ht (sub_eq_iff_eq_add.mp h)
    simp [magneticShift_apply, lp.single_apply, Pi.single_apply,
      hsub, ht, Ne.symm hsub, Ne.symm ht]

theorem latticePhase_cos_sin (φ : ℝ) (n : ℤ) :
    latticePhase φ n = (Real.cos (φ*(n : ℝ)) : ℂ) +
      Complex.I * (Real.sin (φ*(n : ℝ)) : ℂ) := by
  rw [latticePhase, Complex.exp_mul_I]
  simp only [Complex.ofReal_cos, Complex.ofReal_sin]
  ring

def hopVector (s : MagneticSite) (c : Fin 6 → ℂ) : MagneticSpace :=
  ∑ i, c i • lp.single 2 (receivingSite s i) 1

theorem magneticHPlus_single (a r φ : ℝ) (s : MagneticSite) :
    magneticHPlus a r φ (lp.single 2 s 1) =
      hopVector s (plusColumn r φ ((r : ℂ)*diagonalHopping a φ) s) := by
  rcases s with ⟨j,k⟩
  simp [magneticHPlus, scalarHamiltonian, scalarRightHamiltonian,
    magneticHamiltonianWith, magneticPair, magneticShift_single, hopVector,
    Fin.sum_univ_succ, plusColumn, coefficient, phase, displacement,
    receivingSite, latticePhase_cos_sin, wedge, mul_neg, neg_mul]
  module

theorem magneticHMinus_single (a r φ : ℝ) (s : MagneticSite) :
    magneticHMinus a r φ (lp.single 2 s 1) =
      hopVector s (minusColumn r φ ((r : ℂ)*diagonalHopping a φ) s) := by
  rcases s with ⟨j,k⟩
  simp [magneticHMinus, scalarHamiltonian, scalarRightHamiltonian,
    magneticHamiltonianWith, magneticPair, magneticShift_single, hopVector,
    Fin.sum_univ_succ, minusColumn, coefficient, phase, displacement,
    receivingSite, latticePhase_cos_sin, wedge, mul_neg, neg_mul]
  module

theorem hopVector_add (s : MagneticSite) (c d : Fin 6 → ℂ) :
    hopVector s (c+d) = hopVector s c + hopVector s d := by
  simp [hopVector, add_smul, Finset.sum_add_distrib]

theorem hopVector_sub (s : MagneticSite) (c d : Fin 6 → ℂ) :
    hopVector s (c-d) = hopVector s c - hopVector s d := by
  simp [hopVector, sub_smul, Finset.sum_sub_distrib]

theorem hopVector_smul (s : MagneticSite) (z : ℂ) (c : Fin 6 → ℂ) :
    hopVector s (z • c) = z • hopVector s c := by
  simp [hopVector, Finset.smul_sum, smul_smul]

theorem sectorOperator_hopVector (s : MagneticSite) (c : Fin 6 → ℂ) :
    sectorOperator (hopVector s c) =
      hopVector s (fun i => (sector (receivingSite s i) : ℂ) * c i) := by
  simp only [hopVector, map_sum, map_smul, sectorOperator_single, smul_smul]
  apply Finset.sum_congr rfl
  intro i hi
  congr 1
  ring

theorem magneticBoundaryProjection_single_indicator (s : MagneticSite) (z : ℂ) :
    magneticBoundaryProjection (lp.single 2 s z) =
      (boundaryIndicator s : ℂ) • lp.single 2 s z := by
  rw [magneticBoundaryProjection_single]
  by_cases h : onBoundary s <;> simp [boundaryIndicator, h]

theorem magneticBoundaryProjection_hopVector (s : MagneticSite) (c : Fin 6 → ℂ) :
    magneticBoundaryProjection (hopVector s c) =
      hopVector s (fun i => (boundaryIndicator (receivingSite s i) : ℂ) * c i) := by
  simp only [hopVector, map_sum, map_smul, magneticBoundaryProjection_single_indicator, smul_smul]
  apply Finset.sum_congr rfl
  intro i hi
  congr 1
  ring

theorem magneticBoundaryCorrection_vertical (r φ : ℝ) (k : ℤ) :
    magneticBoundaryCorrection r φ (lp.single 2 (0,k) 1) =
      hopVector (0,k) (verticalCorrection r φ k) := by
  by_cases h1 : k = 1
  · subst k
    simp [magneticBoundaryCorrection, latticeSymmetricPair, hopVector,
      verticalCorrection, receivingSite, displacement, Fin.sum_univ_succ,
      lp.single_apply, Pi.single_apply, Prod.ext_iff]
    module
  · by_cases hn1 : k = -1
    · subst k
      simp [magneticBoundaryCorrection, latticeSymmetricPair, hopVector,
        verticalCorrection, receivingSite, displacement, Fin.sum_univ_succ,
        lp.single_apply, Pi.single_apply, Prod.ext_iff]
      module
    · simp [magneticBoundaryCorrection, latticeSymmetricPair, hopVector,
        verticalCorrection, receivingSite, displacement, Fin.sum_univ_succ,
        lp.single_apply, Pi.single_apply, Prod.ext_iff, h1, hn1, eq_comm]

theorem magneticBoundaryCorrection_diagonal (r φ : ℝ) (j : ℤ) :
    magneticBoundaryCorrection r φ (lp.single 2 (j,j) 1) =
      hopVector (j,j) (diagonalCorrection r φ j) := by
  by_cases h1 : j = 1
  · subst j
    simp [magneticBoundaryCorrection, latticeSymmetricPair, hopVector,
      diagonalCorrection, receivingSite, displacement, Fin.sum_univ_succ,
      lp.single_apply, Pi.single_apply, Prod.ext_iff]
    module
  · by_cases hn1 : j = -1
    · subst j
      simp [magneticBoundaryCorrection, latticeSymmetricPair, hopVector,
        diagonalCorrection, receivingSite, displacement, Fin.sum_univ_succ,
        lp.single_apply, Pi.single_apply, Prod.ext_iff]
      module
    · have h01 : (j,j) ≠ (0,1) := by intro h; cases Prod.mk.inj h; omega
      have h0n1 : (j,j) ≠ (0,-1) := by intro h; cases Prod.mk.inj h; omega
      have ha : (j,j) ≠ (1,1) := by simp [h1]
      have hb : (j,j) ≠ (-1,-1) := by simp [hn1]
      have ha' : (j,j) ≠ (1 : MagneticSite) := ha
      simp [magneticBoundaryCorrection, latticeSymmetricPair, hopVector,
        diagonalCorrection, receivingSite, displacement, Fin.sum_univ_succ,
        lp.single_apply, Pi.single_apply, h1, hn1, h01, h0n1, ha, ha', hb, eq_comm]

theorem magneticBoundaryCorrection_off_boundary (r φ : ℝ) (s : MagneticSite)
    (hs : ¬onBoundary s) : magneticBoundaryCorrection r φ (lp.single 2 s 1) = 0 := by
  have hnot (t : MagneticSite) (ht : onBoundary t) : s ≠ t := by
    rintro rfl
    exact hs ht
  have ha := hnot (1,1) (by simp [onBoundary])
  have ha' : s ≠ (1 : MagneticSite) := ha
  have hb := hnot (-1,-1) (by simp [onBoundary])
  have hc := hnot (0,1) (by simp [onBoundary])
  have hd := hnot (0,-1) (by simp [onBoundary])
  simp [magneticBoundaryCorrection, latticeSymmetricPair, lp.single_apply,
    Pi.single_apply, ha, ha', hb, hc, hd, eq_comm]

theorem actual_vertical_boundary_column (a r α : ℝ) (hα : Irrational α)
    {k : ℤ} (hk : k ≠ 0) :
    sectorOperator (magneticHPlus a r (Real.pi*α) (lp.single 2 (0,k) 1)) =
      (-Complex.I * (intSign k : ℂ) *
        ((Real.cos ((Real.pi*α)*(k : ℝ)) /
          Real.sin ((Real.pi*α)*(k : ℝ)) : ℝ) : ℂ)) •
        magneticHMinus a r (Real.pi*α) (lp.single 2 (0,k) 1) +
        magneticBoundaryCorrection r (Real.pi*α) (lp.single 2 (0,k) 1) := by
  rw [magneticHPlus_single, sectorOperator_hopVector]
  change hopVector (0,k) (sectorColumn r (Real.pi*α)
    ((r : ℂ)*diagonalHopping a (Real.pi*α)) (0,k)) = _
  rw [vertical_boundary_column r (Real.pi*α) _ hk (sine_ne_zero_of_irrational hα hk)]
  change hopVector (0,k)
    ((-Complex.I * (intSign k : ℂ) *
      ((Real.cos ((Real.pi*α)*(k : ℝ)) / Real.sin ((Real.pi*α)*(k : ℝ)) : ℝ) : ℂ)) •
        minusColumn r (Real.pi*α) ((r : ℂ)*diagonalHopping a (Real.pi*α)) (0,k) +
      verticalCorrection r (Real.pi*α) k) = _
  rw [hopVector_add, hopVector_smul, ← magneticHMinus_single,
    ← magneticBoundaryCorrection_vertical]

theorem actual_diagonal_boundary_column (a r α : ℝ) (hα : Irrational α)
    {j : ℤ} (hj : j ≠ 0) :
    sectorOperator (magneticHPlus a r (Real.pi*α) (lp.single 2 (j,j) 1)) =
      (Complex.I * (intSign j : ℂ) *
        ((Real.cos ((Real.pi*α)*(j : ℝ)) /
          Real.sin ((Real.pi*α)*(j : ℝ)) : ℝ) : ℂ)) •
        magneticHMinus a r (Real.pi*α) (lp.single 2 (j,j) 1) +
        magneticBoundaryCorrection r (Real.pi*α) (lp.single 2 (j,j) 1) := by
  rw [magneticHPlus_single, sectorOperator_hopVector]
  change hopVector (j,j) (sectorColumn r (Real.pi*α)
    ((r : ℂ)*diagonalHopping a (Real.pi*α)) (j,j)) = _
  rw [diagonal_boundary_column r (Real.pi*α) _ hj (sine_ne_zero_of_irrational hα hj)]
  change hopVector (j,j)
    ((Complex.I * (intSign j : ℂ) *
      ((Real.cos ((Real.pi*α)*(j : ℝ)) / Real.sin ((Real.pi*α)*(j : ℝ)) : ℝ) : ℂ)) •
        minusColumn r (Real.pi*α) ((r : ℂ)*diagonalHopping a (Real.pi*α)) (j,j) +
      diagonalCorrection r (Real.pi*α) j) = _
  rw [hopVector_add, hopVector_smul, ← magneticHMinus_single,
    ← magneticBoundaryCorrection_diagonal]

theorem actual_commutator_geometry_single (a r φ : ℝ) (s : MagneticSite) :
    sectorOperator (magneticHPlus a r φ (lp.single 2 s 1)) -
        magneticHPlus a r φ (sectorOperator (lp.single 2 s 1)) =
      sectorOperator (magneticHPlus a r φ
        (magneticBoundaryProjection (lp.single 2 s 1))) -
        magneticBoundaryProjection (magneticHPlus a r φ
          (sectorOperator (lp.single 2 s 1))) := by
  simp only [sectorOperator_single, magneticBoundaryProjection_single_indicator,
    map_smul, magneticHPlus_single, sectorOperator_hopVector,
    magneticBoundaryProjection_hopVector]
  simp only [← hopVector_smul, ← hopVector_sub]
  congr 1
  ext i
  simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
  linear_combination commutator_entry_supported_on_boundary r φ
    ((r : ℂ)*diagonalHopping a φ) s i

theorem actual_commutator_geometry (a r φ : ℝ) (w : MagneticSpace) :
    sectorOperator (magneticHPlus a r φ w) - magneticHPlus a r φ (sectorOperator w) =
      sectorOperator (magneticHPlus a r φ (magneticBoundaryProjection w)) -
        magneticBoundaryProjection (magneticHPlus a r φ (sectorOperator w)) := by
  let f : MagneticOperator := sectorOperator * magneticHPlus a r φ -
    magneticHPlus a r φ * sectorOperator
  let g : MagneticOperator := sectorOperator * magneticHPlus a r φ * magneticBoundaryProjection -
    magneticBoundaryProjection * magneticHPlus a r φ * sectorOperator
  have hfg : f = g := by
    apply lp.ext_continuousLinearMap (by norm_num : (2 : ENNReal) ≠ ⊤)
    intro s
    apply ContinuousLinearMap.ext
    intro z
    change f (lp.single 2 s z) = g (lp.single 2 s z)
    have hz : (lp.single 2 s z : MagneticSpace) = z • lp.single 2 s (1 : ℂ) := by
      simp [← lp.single_smul]
    rw [hz, map_smul, map_smul]
    congr 1
    exact actual_commutator_geometry_single a r φ s
  exact congrArg (fun T : MagneticOperator => T w) hfg

def boundaryCotangent (φ : ℝ) (s : MagneticSite) : ℂ :=
  if s.1 = 0 then
    -Complex.I * (intSign s.2 : ℂ) *
      ((Real.cos (φ*(s.2 : ℝ)) / Real.sin (φ*(s.2 : ℝ)) : ℝ) : ℂ)
  else if s.1 = s.2 then
    Complex.I * (intSign s.1 : ℂ) *
      ((Real.cos (φ*(s.1 : ℝ)) / Real.sin (φ*(s.1 : ℝ)) : ℝ) : ℂ)
  else 0

theorem actual_boundary_columns (a r α : ℝ) (hα : Irrational α) (s : MagneticSite) :
    sectorOperator (magneticHPlus a r (Real.pi*α)
      (magneticBoundaryProjection (lp.single 2 s 1))) =
      boundaryCotangent (Real.pi*α) s •
          magneticHMinus a r (Real.pi*α) (lp.single 2 s 1) +
        magneticBoundaryCorrection r (Real.pi*α) (lp.single 2 s 1) +
        ⟪magneticOrigin, lp.single 2 s 1⟫_ℂ •
          sectorOperator (magneticHPlus a r (Real.pi*α) magneticOrigin) := by
  rcases s with ⟨j,k⟩
  by_cases hj : j = 0
  · subst j
    by_cases hk : k = 0
    · subst k
      change sectorOperator (magneticHPlus a r (Real.pi*α)
        (magneticBoundaryProjection magneticOrigin)) = _
      rw [magneticBoundaryProjection_origin]
      have hF : magneticBoundaryCorrection r (Real.pi*α)
          (lp.single 2 (0,0) 1) = 0 := magneticBoundaryCorrection_origin r (Real.pi*α)
      simp [boundaryCotangent, intSign, hF, magneticOrigin, lp.inner_single_left]
      exact hF
    · rw [magneticBoundaryProjection_single]
      simp only [onBoundary, true_or, ite_true]
      have h := actual_vertical_boundary_column a r α hα hk
      simpa [boundaryCotangent, magneticOrigin, lp.inner_single_left,
        lp.single_apply, Pi.single_apply, Prod.ext_iff, hk, Ne.symm hk] using h
  · by_cases hjk : j = k
    · subst k
      rw [magneticBoundaryProjection_single]
      simp only [onBoundary, or_true, ite_true]
      have h := actual_diagonal_boundary_column a r α hα hj
      simpa [boundaryCotangent, hj, magneticOrigin, lp.inner_single_left,
        lp.single_apply, Pi.single_apply, Prod.ext_iff, Ne.symm hj] using h
    · have hb : ¬onBoundary (j,k) := by simp [onBoundary, hj, hjk]
      simp [magneticBoundaryProjection_single, hb,
        magneticBoundaryCorrection_off_boundary r (Real.pi*α) (j,k) hb,
        boundaryCotangent, hj, hjk, magneticOrigin, lp.inner_single_left,
        lp.single_apply, Pi.single_apply, Prod.ext_iff, Ne.symm hj]

theorem actual_magnetic_balance (a r α : ℝ) (hα : Irrational α)
    (v w : MagneticSpace)
    (hv : v ∈ scalarCyclicSpace a r (Real.pi*α))
    (hw : w ∈ scalarCyclicSpace a r (Real.pi*α)) :
    ⟪v, sectorOperator (magneticHPlus a r (Real.pi*α) w) -
      magneticHPlus a r (Real.pi*α) (sectorOperator w)⟫_ℂ =
      ⟪v, sectorOperator (magneticHPlus a r (Real.pi*α) magneticOrigin)⟫_ℂ *
        ⟪magneticOrigin, w⟫_ℂ -
      ⟪v, magneticOrigin⟫_ℂ *
        ⟪sectorOperator (magneticHPlus a r (Real.pi*α) magneticOrigin), w⟫_ℂ := by
  apply magnetic_balance_from_columns sectorOperator
    (magneticHPlus a r (Real.pi*α)) (magneticHMinus a r (Real.pi*α))
    magneticBoundaryProjection (magneticBoundaryCorrection r (Real.pi*α))
    magneticOrigin (boundaryCotangent (Real.pi*α))
  · exact ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp sectorOperator_selfAdjoint
  · exact ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp
      (magneticHPlus_selfAdjoint a r (Real.pi*α))
  · exact ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp
      (magneticHMinus_selfAdjoint a r (Real.pi*α))
  · exact ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp magneticBoundaryProjection_selfAdjoint
  · exact ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp
      (magneticBoundaryCorrection_selfAdjoint r (Real.pi*α))
  · exact actual_boundary_columns a r α hα
  · exact actual_commutator_geometry a r (Real.pi*α)
  · exact magneticHMinus_vanishes_on_cyclic a r (Real.pi*α) v hv
  · exact magneticHMinus_vanishes_on_cyclic a r (Real.pi*α) w hw

end UAMO

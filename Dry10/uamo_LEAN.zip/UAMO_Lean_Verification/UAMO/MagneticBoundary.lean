import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Irrational
import Mathlib.Data.Matrix.Notation
import Mathlib.Tactic

namespace UAMO.MagneticBoundary

noncomputable section

def intSign (k : ℤ) : ℝ := if 0 < k then 1 else if k < 0 then -1 else 0

@[simp] theorem intSign_neg (k : ℤ) : intSign (-k) = -intSign k := by
  unfold intSign
  split_ifs <;> norm_num at * <;> omega

@[simp] theorem intSign_zero : intSign 0 = 0 := by norm_num [intSign]

theorem intSign_add_one {k : ℤ} (hk : k ≠ 0) :
    intSign (k + 1) = intSign k + if k = -1 then 1 else 0 := by
  by_cases he : k = -1
  · subst k
    norm_num [intSign]
  · by_cases hp : 0 < k
    · have hp' : 0 < k + 1 := by omega
      simp [intSign, hp, hp', he]
    · have hn : k < 0 := by omega
      have hn' : k + 1 < 0 := by omega
      simp [intSign, not_lt_of_ge (le_of_lt hn), hn,
        not_lt_of_ge (le_of_lt hn'), hn', he]

theorem intSign_sub_one {k : ℤ} (hk : k ≠ 0) :
    intSign (k - 1) = intSign k - if k = 1 then 1 else 0 := by
  have h := intSign_add_one (neg_ne_zero.mpr hk)
  have he : (-k : ℤ) = -1 ↔ k = 1 := by omega
  have ht : (-k : ℤ) + 1 = -(k - 1) := by omega
  simp only [ht, intSign_neg, he] at h
  linarith

def displacement : Fin 6 → ℤ × ℤ :=
  ![(1,0), (1,1), (1,2), (-1,0), (-1,-1), (-1,-2)]

def coefficient (r : ℝ) (b : ℂ) : Fin 6 → ℂ :=
  ![1, b, -(r : ℂ)^2, 1, star b, -(r : ℂ)^2]

def receivingSite (s : ℤ × ℤ) (i : Fin 6) : ℤ × ℤ :=
  (s.1 + (displacement i).1, s.2 + (displacement i).2)

def sector (s : ℤ × ℤ) : ℝ := intSign (s.1 * (s.1 - s.2))

def phase (φ : ℝ) (s : ℤ × ℤ) (i : Fin 6) : ℝ :=
  φ * (((displacement i).2 * s.1 - (displacement i).1 * s.2 : ℤ) : ℝ)

def plusColumn (r φ : ℝ) (b : ℂ) (s : ℤ × ℤ) (i : Fin 6) : ℂ :=
  coefficient r b i * (Real.cos (phase φ s i) : ℂ)

def minusColumn (r φ : ℝ) (b : ℂ) (s : ℤ × ℤ) (i : Fin 6) : ℂ :=
  Complex.I * coefficient r b i * (Real.sin (phase φ s i) : ℂ)

def sectorColumn (r φ : ℝ) (b : ℂ) (s : ℤ × ℤ) (i : Fin 6) : ℂ :=
  (sector (receivingSite s i) : ℂ) * plusColumn r φ b s i

def verticalCorrection (r φ : ℝ) (k : ℤ) : Fin 6 → ℂ :=
  ![if k = 1 then (Real.cos φ : ℂ) else 0,
    0,
    if k = -1 then (r : ℂ)^2 * (Real.cos φ : ℂ) else 0,
    if k = -1 then (Real.cos φ : ℂ) else 0,
    0,
    if k = 1 then (r : ℂ)^2 * (Real.cos φ : ℂ) else 0]

def diagonalCorrection (r φ : ℝ) (j : ℤ) : Fin 6 → ℂ :=
  ![if j = -1 then (Real.cos φ : ℂ) else 0,
    0,
    if j = -1 then (r : ℂ)^2 * (Real.cos φ : ℂ) else 0,
    if j = 1 then (Real.cos φ : ℂ) else 0,
    0,
    if j = 1 then (r : ℂ)^2 * (Real.cos φ : ℂ) else 0]

theorem vertical_sector_values (k : ℤ) :
    (fun i => sector (receivingSite (0,k) i)) =
      ![intSign (1-k), intSign (-k), intSign (-1-k),
        intSign (1+k), intSign k, intSign (k-1)] := by
  ext i
  fin_cases i <;> simp [sector, receivingSite, displacement]
  all_goals (congr 1; omega)

theorem diagonal_sector_values (j : ℤ) :
    (fun i => sector (receivingSite (j,j) i)) =
      ![intSign (j+1), 0, -intSign (j+1),
        -intSign (j-1), 0, intSign (j-1)] := by
  ext i
  fin_cases i <;> simp [sector, receivingSite, displacement]
  all_goals first | (rw [← intSign_neg]; congr 1; omega) | congr 1

theorem vertical_boundary_column (r φ : ℝ) (b : ℂ) {k : ℤ}
    (hk : k ≠ 0) (hsin : Real.sin (φ * (k : ℝ)) ≠ 0) :
    sectorColumn r φ b (0,k) =
      fun i => (-Complex.I * (intSign k : ℂ) *
          ((Real.cos (φ * (k : ℝ)) / Real.sin (φ * (k : ℝ)) : ℝ) : ℂ)) *
        minusColumn r φ b (0,k) i + verticalCorrection r φ k i := by
  have hs : (Real.sin (φ * (k : ℝ)) : ℂ) ≠ 0 := by exact_mod_cast hsin
  simp only [Complex.ofReal_sin, Complex.ofReal_mul, Complex.ofReal_intCast] at hs
  have hplus := intSign_add_one hk
  have hminus := intSign_sub_one hk
  have hnegplus : intSign (-1-k) = -intSign (k+1) := by
    rw [← intSign_neg]
    congr 1
    omega
  have hnegminus : intSign (1-k) = -intSign (k-1) := by
    rw [← intSign_neg]
    congr 1
    omega
  funext i
  unfold sectorColumn
  rw [show sector (receivingSite (0,k) i) =
      ![intSign (1-k), intSign (-k), intSign (-1-k),
        intSign (1+k), intSign k, intSign (k-1)] i from
      congrFun (vertical_sector_values k) i]
  by_cases h1 : k = 1
  · subst k
    fin_cases i <;>
      simp [plusColumn, minusColumn, coefficient, phase, displacement,
        verticalCorrection, intSign, Complex.ofReal_div] at *
    all_goals (field_simp; ring_nf; simp [Complex.I_sq, mul_assoc, hs])
  · by_cases hn1 : k = -1
    · subst k
      fin_cases i <;>
        simp [plusColumn, minusColumn, coefficient, phase, displacement,
          verticalCorrection, intSign, Complex.ofReal_div] at *
      all_goals (field_simp; ring_nf; simp [Complex.I_sq, mul_assoc, hs])
    · fin_cases i <;>
        simp [plusColumn, minusColumn, coefficient, phase, displacement,
          verticalCorrection, h1, hn1, hnegplus, hnegminus, hplus, hminus,
          add_comm 1 k, mul_neg, Complex.ofReal_div]
      all_goals (field_simp; ring_nf; simp [Complex.I_sq, mul_assoc, hs])

theorem diagonal_boundary_column (r φ : ℝ) (b : ℂ) {j : ℤ}
    (hj : j ≠ 0) (hsin : Real.sin (φ * (j : ℝ)) ≠ 0) :
    sectorColumn r φ b (j,j) =
      fun i => (Complex.I * (intSign j : ℂ) *
          ((Real.cos (φ * (j : ℝ)) / Real.sin (φ * (j : ℝ)) : ℝ) : ℂ)) *
        minusColumn r φ b (j,j) i + diagonalCorrection r φ j i := by
  have hs : (Real.sin (φ * (j : ℝ)) : ℂ) ≠ 0 := by exact_mod_cast hsin
  simp only [Complex.ofReal_sin, Complex.ofReal_mul, Complex.ofReal_intCast] at hs
  have hplus := intSign_add_one hj
  have hminus := intSign_sub_one hj
  funext i
  unfold sectorColumn
  rw [show sector (receivingSite (j,j) i) =
      ![intSign (j+1), 0, -intSign (j+1),
        -intSign (j-1), 0, intSign (j-1)] i from
      congrFun (diagonal_sector_values j) i]
  by_cases h1 : j = 1
  · subst j
    fin_cases i <;>
      simp [plusColumn, minusColumn, coefficient, phase, displacement,
        diagonalCorrection, intSign, Complex.ofReal_div] at *
    all_goals (field_simp; ring_nf; simp [Complex.I_sq, mul_assoc, hs])
  · by_cases hn1 : j = -1
    · subst j
      fin_cases i <;>
        simp [plusColumn, minusColumn, coefficient, phase, displacement,
          diagonalCorrection, intSign, Complex.ofReal_div] at *
      all_goals (field_simp; ring_nf; simp [Complex.I_sq, mul_assoc, hs])
    · fin_cases i <;>
        simp [plusColumn, minusColumn, coefficient, phase, displacement,
          diagonalCorrection, h1, hn1, hplus, hminus,
          mul_neg, Complex.ofReal_div]
      all_goals (field_simp; ring_nf; simp [Complex.I_sq, mul_assoc, hs])

theorem abs_intSign_le_one (k : ℤ) : |intSign k| ≤ 1 := by
  unfold intSign
  split_ifs <;> norm_num

theorem abs_sector_le_one (s : ℤ × ℤ) : |sector s| ≤ 1 :=
  abs_intSign_le_one _

theorem sine_ne_zero_of_irrational {α : ℝ} (hα : Irrational α)
    {k : ℤ} (hk : k ≠ 0) : Real.sin ((Real.pi * α) * (k : ℝ)) ≠ 0 := by
  apply Real.sin_ne_zero_iff.mpr
  intro n hn
  apply (hα.mul_intCast hk).ne_int n
  apply mul_right_cancel₀ Real.pi_ne_zero
  calc
    (α * (k : ℝ)) * Real.pi = (Real.pi * α) * (k : ℝ) := by ring
    _ = (n : ℝ) * Real.pi := hn.symm

theorem intSign_mul (a b : ℤ) : intSign (a*b) = intSign a * intSign b := by
  unfold intSign
  split_ifs <;> norm_num at * <;> nlinarith

@[simp] theorem intSign_eq_zero_iff (k : ℤ) : intSign k = 0 ↔ k = 0 := by
  unfold intSign
  split_ifs <;> norm_num at * <;> omega

def onBoundary (s : ℤ × ℤ) : Prop := s.1 = 0 ∨ s.1 = s.2

@[simp] theorem sector_eq_zero_iff (s : ℤ × ℤ) :
    sector s = 0 ↔ onBoundary s := by
  simp [sector, onBoundary, mul_eq_zero, sub_eq_zero]

theorem intSign_step (a d : ℤ) (hd : d = -1 ∨ d = 0 ∨ d = 1)
    (ha : a ≠ 0) (had : a+d ≠ 0) : intSign (a+d) = intSign a := by
  rcases hd with rfl | rfl | rfl
  · have he : a ≠ 1 := by omega
    simpa [sub_eq_add_neg, he] using intSign_sub_one ha
  · simp
  · have he : a ≠ -1 := by omega
    simpa [he] using intSign_add_one ha

theorem sector_unchanged_off_boundaries (s : ℤ × ℤ) (i : Fin 6)
    (hs : ¬onBoundary s) (ht : ¬onBoundary (receivingSite s i)) :
    sector (receivingSite s i) = sector s := by
  simp only [onBoundary, not_or] at hs ht
  have hs0 : s.1 ≠ 0 := by tauto
  have hsd : s.1-s.2 ≠ 0 := by
    have h : s.1 ≠ s.2 := by tauto
    omega
  have ht0 : s.1+(displacement i).1 ≠ 0 := by
    have h : (receivingSite s i).1 ≠ 0 := by tauto
    exact h
  have htd : (s.1-s.2)+((displacement i).1-(displacement i).2) ≠ 0 := by
    have h : (receivingSite s i).1 ≠ (receivingSite s i).2 := by tauto
    unfold receivingSite at h
    simp only at h
    omega
  have hd1 : (displacement i).1 = -1 ∨ (displacement i).1 = 0 ∨
      (displacement i).1 = 1 := by
    fin_cases i <;> simp [displacement]
  have hd2 : (displacement i).1-(displacement i).2 = -1 ∨
      (displacement i).1-(displacement i).2 = 0 ∨
      (displacement i).1-(displacement i).2 = 1 := by
    fin_cases i <;> simp [displacement]
  have h1 := intSign_step s.1 (displacement i).1 hd1 hs0 ht0
  have h2 := intSign_step (s.1-s.2)
    ((displacement i).1-(displacement i).2) hd2 hsd htd
  unfold sector receivingSite
  simp only [intSign_mul]
  rw [h1]
  have he : s.1+(displacement i).1-(s.2+(displacement i).2) =
      (s.1-s.2)+((displacement i).1-(displacement i).2) := by ring
  rw [he, h2]

def boundaryIndicator (s : ℤ × ℤ) : ℝ := by
  classical
  exact if onBoundary s then 1 else 0

theorem commutator_entry_supported_on_boundary (r φ : ℝ) (b : ℂ)
    (s : ℤ × ℤ) (i : Fin 6) :
    ((sector (receivingSite s i) : ℂ) - (sector s : ℂ)) *
        plusColumn r φ b s i =
      (sector (receivingSite s i) : ℂ) * plusColumn r φ b s i *
          (boundaryIndicator s : ℂ) -
        (boundaryIndicator (receivingSite s i) : ℂ) *
          plusColumn r φ b s i * (sector s : ℂ) := by
  by_cases hs : onBoundary s
  · have hz := (sector_eq_zero_iff s).mpr hs
    simp [boundaryIndicator, hs, hz]
  · by_cases ht : onBoundary (receivingSite s i)
    · have hz := (sector_eq_zero_iff (receivingSite s i)).mpr ht
      simp [boundaryIndicator, hs, ht, hz, mul_comm]
    · have he := sector_unchanged_off_boundaries s i hs ht
      simp [boundaryIndicator, hs, ht, he]

end
end UAMO.MagneticBoundary

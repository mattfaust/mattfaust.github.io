import UAMO.MagneticUnitaryDOS

noncomputable section
namespace UAMO.UnitarySpectral
open SpectralMoments MeasureTheory Set
open scoped ContinuousFunctionalCalculus Topology

section FaithfulSupport
variable {A : Type*} [CStarAlgebra A]
variable (τ : FaithfulTracialState A) (U : A) (hU : IsStarNormal U)

theorem complexSpectralMeasure_ball_pos_of_mem (z : ℂ) (hz : z ∈ spectrum ℂ U)
    {ε : ℝ} (hε : 0<ε) :
    0 < complexSpectralMeasure τ U hU (Metric.ball z ε) := by
  by_contra hpos
  have hmass : complexSpectralMeasure τ U hU (Metric.ball z ε)=0 :=
    le_antisymm (le_of_not_gt hpos) (zero_le _)
  have hout : ∀ᵐ w ∂complexSpectralMeasure τ U hU, w ∉ Metric.ball z ε := by
    apply ae_iff.mpr
    simpa only [not_not,Set.setOf_mem_eq] using hmass
  let f : ℂ→ℝ := fun w => max 0 (ε-‖w-z‖)
  have hf : Continuous f := by dsimp only [f]; fun_prop
  have hfc : Continuous (fun w => (f w : ℂ)) := Complex.continuous_ofReal.comp hf
  have hzero : (fun w => f w*f w) =ᵐ[complexSpectralMeasure τ U hU] (fun _ => (0 : ℝ)) := by
    filter_upwards [hout] with w hw
    have hd : ε≤‖w-z‖ := by simpa only [Metric.mem_ball,dist_eq_norm,not_lt] using hw
    simp only [f,max_eq_left (sub_nonpos.mpr hd),zero_mul]
  have hi := complexSpectralMeasure_integral_cfc τ U hU (fun w => f w*f w) (hf.mul hf)
  rw [integral_congr_ae hzero,integral_zero] at hi
  have hcast : (fun w => ((f w*f w : ℝ) : ℂ)) =
      (fun w => (f w : ℂ)*(f w : ℂ)) := by funext w; exact Complex.ofReal_mul _ _
  rw [hcast,cfc_mul _ _ U hfc.continuousOn hfc.continuousOn] at hi
  have hstar : star (cfc (fun w => (f w : ℂ)) U)=cfc (fun w => (f w : ℂ)) U := by
    rw [← cfc_star]
    congr 1
    funext w
    simp only [Pi.star_apply,Complex.star_def,Complex.conj_ofReal]
  have hF : cfc (fun w => (f w : ℂ)) U=0 :=
    τ.faithful _ (by rw [hstar]; exact hi.symm)
  have heq : cfc (fun w => (f w : ℂ)) U=cfc (0 : ℂ→ℂ) U := by rw [cfc_zero,hF]
  have hvalue := eqOn_of_cfc_eq_cfc heq hfc.continuousOn continuous_const.continuousOn hU hz
  have hh : ε=0 := by
    exact_mod_cast (show (ε : ℂ)=0 by
      simpa only [f,sub_self,norm_zero,sub_zero,max_eq_right hε.le,Pi.zero_apply] using hvalue)
  exact hε.ne' hh

def complexMeasureSupport : Set ℂ :=
  {z | ∀ ε>0,0 < complexSpectralMeasure τ U hU (Metric.ball z ε)}

theorem complexMeasureSupport_eq_spectrum : complexMeasureSupport τ U hU=spectrum ℂ U := by
  apply Set.Subset.antisymm
  · intro z hz
    by_contra hnot
    obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp (spectrum.isClosed (𝕜 := ℂ) U).isOpen_compl z hnot
    have hcompl : complexSpectralMeasure τ U hU (spectrum ℂ U)ᶜ=0 := by
      exact ae_iff.mp (complexSpectralMeasure_ae_mem_spectrum τ U hU)
    have hzero : complexSpectralMeasure τ U hU (Metric.ball z ε)=0 :=
      le_antisymm ((measure_mono hball).trans_eq hcompl) (zero_le _)
    exact (ne_of_gt (hz ε hε)) hzero
  · intro z hz ε hε
    exact complexSpectralMeasure_ball_pos_of_mem τ U hU z hz hε

end FaithfulSupport
end UAMO.UnitarySpectral

namespace UAMO
open MeasureTheory UnitarySpectral

local instance magneticSupport_matrixNormedSpace (φ : ℝ) : NormedSpace ℝ (MagneticMatrixAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (MagneticMatrixAlgebra φ)

local instance magneticSupport_matrixModule (φ : ℝ) : Module ℝ (MagneticMatrixAlgebra φ) :=
  @Algebra.toModule ℝ (MagneticMatrixAlgebra φ) _ _ (magneticMatrixAlgebra_realNormedAlgebra φ).toAlgebra

local instance magneticSupport_matrixComplexModule (φ : ℝ) : Module ℂ (MagneticMatrixAlgebra φ) :=
  @Algebra.toModule ℂ (MagneticMatrixAlgebra φ) _ _ inferInstance

def magneticDOSSpectralSupport (a r φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) : Set ℂ :=
  {z | ∀ ε>0,0 < magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1 (Metric.ball z ε)}

theorem magneticDOSSpectralSupport_eq_spectrum (a r φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) :
    magneticDOSSpectralSupport a r φ ha0 ha1 hr0 hr1=spectrum ℂ (cstarMagneticWalk a r φ) :=
  complexMeasureSupport_eq_spectrum (magneticMatrixFaithfulState φ)
    (cstarMagneticWalk a r φ)
    (isStarNormal_of_mem_unitary (cstarMagneticWalk_unitary a r φ ha0 ha1 hr0 hr1))

end UAMO

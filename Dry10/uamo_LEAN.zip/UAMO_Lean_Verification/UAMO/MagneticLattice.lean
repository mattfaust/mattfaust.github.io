import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Tactic

noncomputable section
namespace UAMO

abbrev MagneticSite := ℤ × ℤ
abbrev MagneticSpace := ℓ²(MagneticSite, ℂ)
abbrev MagneticOperator := MagneticSpace →L[ℂ] MagneticSpace

def wedge (ν s : MagneticSite) : ℤ := ν.2 * s.1 - ν.1 * s.2

def latticePhase (φ : ℝ) (n : ℤ) : ℂ :=
  Complex.exp (((φ * (n : ℝ) : ℝ) : ℂ) * Complex.I)

@[simp] theorem latticePhase_zero (φ : ℝ) : latticePhase φ 0 = 1 := by
  simp [latticePhase]

theorem latticePhase_add (φ : ℝ) (m n : ℤ) :
    latticePhase φ (m + n) = latticePhase φ m * latticePhase φ n := by
  simp [latticePhase, Int.cast_add, mul_add, add_mul, Complex.exp_add]

theorem latticePhase_norm (φ : ℝ) (n : ℤ) : ‖latticePhase φ n‖ = 1 :=
  Complex.norm_exp_ofReal_mul_I _

theorem latticePhase_neg_parameter (φ : ℝ) (n : ℤ) :
    latticePhase (-φ) n = latticePhase φ (-n) := by
  simp [latticePhase]

def latticeTranslate (ν : MagneticSite) : MagneticSite ≃ MagneticSite where
  toFun s := s - ν
  invFun s := s + ν
  left_inv s := sub_add_cancel s ν
  right_inv s := add_sub_cancel_right s ν

theorem magneticSpace_summable_sq (u : MagneticSpace) :
    Summable (fun s => ‖u s‖ ^ (2 : ℕ)) := by
  have h := (lp.memℓp u).summable (show 0 < (2 : ENNReal).toReal by norm_num)
  simpa using h

theorem magneticSpace_norm_sq (u : MagneticSpace) :
    ‖u‖ ^ (2 : ℕ) = ∑' s, ‖u s‖ ^ (2 : ℕ) := by
  have h := lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) u
  simpa using h

def magneticShiftVector (φ : ℝ) (ν : MagneticSite) (u : MagneticSpace) : MagneticSpace :=
  ⟨fun s => latticePhase φ (wedge ν s) * u (s - ν), by
    apply memℓp_gen
    have h := (latticeTranslate ν).summable_iff.mpr (magneticSpace_summable_sq u)
    simpa [Function.comp_def, latticeTranslate, norm_mul, latticePhase_norm] using h⟩

@[simp] theorem magneticShiftVector_apply (φ : ℝ) (ν : MagneticSite)
    (u : MagneticSpace) (s : MagneticSite) :
    magneticShiftVector φ ν u s = latticePhase φ (wedge ν s) * u (s - ν) := rfl

theorem magneticShiftVector_norm (φ : ℝ) (ν : MagneticSite) (u : MagneticSpace) :
    ‖magneticShiftVector φ ν u‖ = ‖u‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [magneticSpace_norm_sq, magneticSpace_norm_sq]
  simp only [magneticShiftVector_apply, norm_mul, latticePhase_norm, one_mul]
  exact (latticeTranslate ν).tsum_eq (fun s => ‖u s‖ ^ (2 : ℕ))

def magneticShift (φ : ℝ) (ν : MagneticSite) : MagneticOperator :=
  LinearMap.mkContinuous
    { toFun := magneticShiftVector φ ν
      map_add' := by
        intro u v
        apply lp.ext
        funext s
        simp [mul_add]
      map_smul' := by
        intro c u
        apply lp.ext
        funext s
        simp [mul_left_comm] }
    1 (fun u => by simp [magneticShiftVector_norm])

@[simp] theorem magneticShift_apply (φ : ℝ) (ν : MagneticSite)
    (u : MagneticSpace) (s : MagneticSite) :
    magneticShift φ ν u s = latticePhase φ (wedge ν s) * u (s - ν) := rfl

theorem magneticShift_norm (φ : ℝ) (ν : MagneticSite) (u : MagneticSpace) :
    ‖magneticShift φ ν u‖ = ‖u‖ := magneticShiftVector_norm φ ν u

theorem magneticShift_mul (φ : ℝ) (ν μ : MagneticSite) :
    magneticShift φ ν * magneticShift φ μ =
      latticePhase φ (wedge ν μ) • magneticShift φ (ν + μ) := by
  ext u s
  simp only [ContinuousLinearMap.mul_apply, magneticShift_apply,
    ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  have hs : s - ν - μ = s - (ν + μ) := by abel
  rw [hs, ← mul_assoc, ← latticePhase_add, ← mul_assoc, ← latticePhase_add]
  congr 2
  simp only [wedge, Prod.fst_sub, Prod.snd_sub, Prod.fst_add, Prod.snd_add]
  ring

@[simp] theorem magneticShift_zero (φ : ℝ) : magneticShift φ 0 = 1 := by
  ext u s
  simp [magneticShift_apply, wedge]

theorem magneticShift_inverse (φ : ℝ) (ν : MagneticSite) :
    magneticShift φ ν * magneticShift φ (-ν) = 1 := by
  rw [magneticShift_mul]
  have hw : wedge ν (-ν) = 0 := by simp [wedge]; ring
  simp [hw]

theorem magneticShift_opposite_commute (φ : ℝ) (ν μ : MagneticSite) :
    magneticShift φ ν * magneticShift (-φ) μ =
      magneticShift (-φ) μ * magneticShift φ ν := by
  ext u s
  simp only [ContinuousLinearMap.mul_apply, magneticShift_apply,
    latticePhase_neg_parameter]
  have hs : s - ν - μ = s - μ - ν := by abel
  rw [hs, ← mul_assoc, ← latticePhase_add, ← mul_assoc, ← latticePhase_add]
  congr 2
  simp only [wedge, Prod.fst_sub, Prod.snd_sub]
  ring

theorem magneticShift_star (φ : ℝ) (ν : MagneticSite) :
    star (magneticShift φ ν) = magneticShift φ (-ν) := by
  let A := magneticShift φ ν
  let B := magneticShift φ (-ν)
  let Ai : MagneticSpace →ₗᵢ[ℂ] MagneticSpace :=
    { toLinearMap := A.toLinearMap, norm_map' := magneticShift_norm φ ν }
  have hp : ∀ u v, @inner ℂ MagneticSpace _ (A u) v = @inner ℂ MagneticSpace _ u (B v) := by
    intro u v
    have hv : A (B v) = v := by
      have h := congrArg (fun T : MagneticOperator => T v) (magneticShift_inverse φ ν)
      simpa only [ContinuousLinearMap.mul_apply, ContinuousLinearMap.one_apply] using h
    calc
      @inner ℂ MagneticSpace _ (A u) v = @inner ℂ MagneticSpace _ (A u) (A (B v)) := by rw [hv]
      _ = @inner ℂ MagneticSpace _ u (B v) := Ai.inner_map_map u (B v)
  have hA : A = ContinuousLinearMap.adjoint B :=
    (ContinuousLinearMap.eq_adjoint_iff A B).mpr hp
  change star A = B
  rw [ContinuousLinearMap.star_eq_adjoint, hA, ContinuousLinearMap.adjoint_adjoint]

def magneticPair (φ : ℝ) (ν : MagneticSite) (c : ℂ) : MagneticOperator :=
  c • magneticShift φ ν + star c • magneticShift φ (-ν)

theorem magneticPair_selfAdjoint (φ : ℝ) (ν : MagneticSite) (c : ℂ) :
    IsSelfAdjoint (magneticPair φ ν c) := by
  simp [IsSelfAdjoint, magneticPair, star_add, star_smul, magneticShift_star, add_comm]

def magneticHamiltonianWith (φ : ℝ) (b c : ℂ) : MagneticOperator :=
  magneticPair φ (1, 0) 1 + magneticPair φ (1, 1) b + magneticPair φ (1, 2) c

theorem magneticHamiltonianWith_selfAdjoint (φ : ℝ) (b c : ℂ) :
    IsSelfAdjoint (magneticHamiltonianWith φ b c) :=
  ((magneticPair_selfAdjoint φ (1, 0) 1).add
    (magneticPair_selfAdjoint φ (1, 1) b)).add (magneticPair_selfAdjoint φ (1, 2) c)

theorem magneticPair_opposite_commute (φ : ℝ) (ν μ : MagneticSite) (b c : ℂ) :
    Commute (magneticPair φ ν b) (magneticPair (-φ) μ c) := by
  have h (v w : MagneticSite) (z t : ℂ) :
      Commute (z • magneticShift φ v) (t • magneticShift (-φ) w) :=
    ((show Commute (magneticShift φ v) (magneticShift (-φ) w) from
      magneticShift_opposite_commute φ v w).smul_left z).smul_right t
  exact ((h ν μ b c).add_right (h ν (-μ) b (star c))).add_left
    ((h (-ν) μ (star b) c).add_right (h (-ν) (-μ) (star b) (star c)))

theorem magneticHamiltonianWith_opposite_commute (φ : ℝ) (b c : ℂ) :
    Commute (magneticHamiltonianWith φ b c) (magneticHamiltonianWith (-φ) b c) := by
  have h (ν : MagneticSite) (z : ℂ) :
      Commute (magneticPair φ ν z) (magneticHamiltonianWith (-φ) b c) :=
    ((magneticPair_opposite_commute φ ν (1, 0) z 1).add_right
      (magneticPair_opposite_commute φ ν (1, 1) z b)).add_right
      (magneticPair_opposite_commute φ ν (1, 2) z c)
  exact ((h (1, 0) 1).add_left (h (1, 1) b)).add_left (h (1, 2) c)

def diagonalHopping (a φ : ℝ) : ℂ :=
  (a : ℂ)⁻¹ * latticePhase φ 1 - (a : ℂ) * latticePhase φ (-1)

def scalarHamiltonian (a r φ : ℝ) : MagneticOperator :=
  magneticHamiltonianWith φ ((r : ℂ) * diagonalHopping a φ) (-(r : ℂ) ^ 2)

theorem scalarHamiltonian_selfAdjoint (a r φ : ℝ) :
    IsSelfAdjoint (scalarHamiltonian a r φ) := magneticHamiltonianWith_selfAdjoint _ _ _

def magneticOrigin : MagneticSpace := lp.single 2 (0, 0) 1

theorem magneticOrigin_norm : ‖magneticOrigin‖ = 1 := by
  simp [magneticOrigin, lp.norm_single]

theorem magneticShift_origin (φ : ℝ) (ν : MagneticSite) :
    magneticShift φ ν magneticOrigin = lp.single 2 ν 1 := by
  apply lp.ext
  funext s
  by_cases hs : s = ν
  · subst s
    have hw : wedge ν ν = 0 := by simp [wedge, mul_comm]
    simp [magneticOrigin, magneticShift_apply, hw]
  · have hsub : s - ν ≠ (0, 0) := by simpa using sub_ne_zero.mpr hs
    rw [magneticShift_apply, magneticOrigin,
      lp.single_apply_ne 2 (0, 0) 1 hsub, mul_zero, lp.single_apply_ne 2 ν 1 hs]

theorem magneticPair_origin (φ : ℝ) (ν : MagneticSite) (c : ℂ) :
    magneticPair φ ν c magneticOrigin =
      c • lp.single 2 ν 1 + star c • lp.single 2 (-ν) 1 := by
  simp [magneticPair, magneticShift_origin]

theorem magneticHamiltonianWith_origin (φ : ℝ) (b c : ℂ) :
    magneticHamiltonianWith φ b c magneticOrigin =
      lp.single 2 (1, 0) 1 + lp.single 2 (-1, 0) 1 +
      (b • lp.single 2 (1, 1) 1 + star b • lp.single 2 (-1, -1) 1) +
      (c • lp.single 2 (1, 2) 1 + star c • lp.single 2 (-1, -2) 1) := by
  simp [magneticHamiltonianWith, magneticPair_origin]
  rfl

theorem magneticHamiltonianWith_origin_agree (φ : ℝ) (b c : ℂ) :
    magneticHamiltonianWith φ b c magneticOrigin =
      magneticHamiltonianWith (-φ) b c magneticOrigin := by
  rw [magneticHamiltonianWith_origin, magneticHamiltonianWith_origin]

theorem magneticHamiltonianWith_trace_zero (φ : ℝ) (b c : ℂ) :
    @inner ℂ MagneticSpace _ magneticOrigin
      (magneticHamiltonianWith φ b c magneticOrigin) = 0 := by
  rw [magneticHamiltonianWith_origin]
  simp [magneticOrigin, lp.inner_single_left, lp.single_apply, Pi.single_apply]

end UAMO

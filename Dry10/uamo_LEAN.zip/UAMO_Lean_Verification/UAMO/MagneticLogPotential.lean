import UAMO.MagneticUnitaryDOS
import UAMO.ScaledLogPotential

noncomputable section
namespace UAMO
open MeasureTheory

theorem magneticUnitaryDOS_total_log_identity {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (φ E : ℝ) (z : ℂ) (hz : ‖z‖ = 1)
    (hzre : z.re = (a / ((1+a^2)*(1+r^2))) * E) :
    (2 : EReal) * CircleDOS.circleTotalPotential
      (magneticUnitaryDOS a r φ ha.le ha1 hr0 hr1) z =
      (Real.log (2*a/((1+a^2)*(1+r^2))) : EReal) +
        scalarTotalLogPotential a φ (r,E) := by
  have hκ : 0 < a/((1+a^2)*(1+r^2)) := by positivity
  simpa only [mul_div_assoc] using circle_total_log_scalar_identity
    (magneticUnitaryDOS a r φ ha.le ha1 hr0 hr1)
    (magneticUnitaryDOS_ae_circle a r φ ha.le ha1 hr0 hr1)
    (magneticUnitaryDOS_conj_invariant a r φ ha.le ha1 hr0 hr1)
    a r φ E (a/((1+a^2)*(1+r^2))) hκ
    (magneticUnitaryDOS_realPart ha ha1 hr0 hr1 φ) z hz hzre

end UAMO

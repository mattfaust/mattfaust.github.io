import UAMO.CyclicCompression
import UAMO.MagneticBalance
import UAMO.MagneticBalanceModel

noncomputable section
namespace UAMO
open scoped InnerProductSpace

def cyclicResolvent (a r φ : ℝ) (z : ℂ) :
    scalarCyclicSpace a r φ →L[ℂ] scalarCyclicSpace a r φ :=
  sourceCompression _ (resolvent (scalarHamiltonian a r φ) z)

theorem cyclicResolvent_apply (a r φ : ℝ) (z : ℂ)
    (hz : z ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (u : scalarCyclicSpace a r φ) :
    (cyclicResolvent a r φ z u : MagneticSpace) =
      resolvent (scalarHamiltonian a r φ) z u := by
  apply sourceCompression_apply_of_mem
  exact closedCyclicSpace_resolvent_invariant _ _
    (scalarHamiltonian_selfAdjoint a r φ) z hz u u.property

theorem cyclicResolvent_left_identity (a r φ : ℝ) (z : ℂ)
    (hz : z ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (u : scalarCyclicSpace a r φ) :
    z • cyclicResolvent a r φ z u -
      cyclicHamiltonian a r φ (cyclicResolvent a r φ z u) = u := by
  apply Subtype.ext
  change z • (cyclicResolvent a r φ z u : MagneticSpace) -
    (cyclicHamiltonian a r φ (cyclicResolvent a r φ z u) : MagneticSpace) = u
  rw [cyclicHamiltonian_apply, cyclicResolvent_apply a r φ z hz]
  exact cyclic_resolvent_left_identity _ z hz u

theorem cyclicResolvent_right_identity (a r φ : ℝ) (z : ℂ)
    (hz : z ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (u : scalarCyclicSpace a r φ) :
    cyclicResolvent a r φ z (z • u - cyclicHamiltonian a r φ u) = u := by
  apply Subtype.ext
  rw [cyclicResolvent_apply a r φ z hz]
  change resolvent (scalarHamiltonian a r φ) z
    (z • (u : MagneticSpace) - (cyclicHamiltonian a r φ u : MagneticSpace)) = u
  rw [cyclicHamiltonian_apply]
  exact cyclic_resolvent_right_identity _ z hz u

def scalarRadialResponse (a r φ E : ℝ) : ℝ :=
  -(⟪cyclicResolvent a r φ (E : ℂ) (cyclicOrigin a r φ),
      cyclicRadialColumn a r φ⟫_ℂ).re

theorem scalarRadialResponse_lattice_pairing (a r φ E : ℝ)
    (hz : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    scalarRadialResponse a r φ E =
      -(⟪resolvent (scalarHamiltonian a r φ) (E : ℂ) magneticOrigin,
        (r • scalarHamiltonianDerivative a r φ) magneticOrigin⟫_ℂ).re := by
  unfold scalarRadialResponse cyclicRadialColumn
  rw [Submodule.inner_orthogonalProjection_eq_of_mem_left,
    cyclicResolvent_apply a r φ (E : ℂ) hz, scalarHamiltonian_radial_derivative]
  rfl

theorem scalar_radial_response_from_balance (a r φ E : ℝ)
    (hz : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hcenter : ⟪cyclicOrigin a r φ,
      cyclicResolvent a r φ (E : ℂ) (cyclicOrigin a r φ)⟫_ℂ = 0)
    (hbalance : ∀ v w : scalarCyclicSpace a r φ,
      ⟪v, cyclicSector a r φ (cyclicHamiltonian a r φ w) -
        cyclicHamiltonian a r φ (cyclicSector a r φ w)⟫_ℂ =
      ⟪v, cyclicSector a r φ (cyclicHamiltonian a r φ (cyclicOrigin a r φ))⟫_ℂ *
        ⟪cyclicOrigin a r φ, w⟫_ℂ -
      ⟪v, cyclicOrigin a r φ⟫_ℂ *
        ⟪cyclicSector a r φ (cyclicHamiltonian a r φ (cyclicOrigin a r φ)), w⟫_ℂ) :
    scalarRadialResponse a r φ E =
      1 - (⟪cyclicResolvent a r φ (E : ℂ) (cyclicOrigin a r φ),
        cyclicSector a r φ
          (cyclicResolvent a r φ (E : ℂ) (cyclicOrigin a r φ))⟫_ℂ).re /
        ‖cyclicResolvent a r φ (E : ℂ) (cyclicOrigin a r φ)‖ ^ 2 ∧
      scalarRadialResponse a r φ E ∈ Set.Icc (0 : ℝ) 2 := by
  exact magnetic_height_identity_from_resolvent
    (centerProjection (cyclicOrigin a r φ)) (cyclicHamiltonian a r φ)
    (cyclicResolvent a r φ (E : ℂ)) (cyclicSector a r φ)
    (centerProjection_symmetric _) (cyclicHamiltonian_symmetric a r φ)
    (cyclicSector_symmetric a r φ) (cyclicSector_contraction a r φ)
    E (cyclicOrigin a r φ) (cyclicOrigin_norm a r φ)
    (cyclicResolvent_left_identity a r φ (E : ℂ) hz)
    (cyclicResolvent_right_identity a r φ (E : ℂ) hz)
    (centerProjection_fixed _ _ hcenter)
    (centerProjection_origin _ (cyclicOrigin_norm a r φ))
    (fun v hv => centerProjection_kernel _ v hv)
    (fun v => centerProjection_idempotent _ v (cyclicOrigin_norm a r φ))
    (centered_commute_from_balance _ (cyclicOrigin_norm a r φ) _ _
      (cyclicSector_symmetric a r φ) (cyclicSector_origin a r φ) hbalance)
    (centerProjection_fixed _ _ (cyclicHamiltonian_origin_centered a r φ))
    (inner_eq_zero_symm.mpr hcenter) (cyclicRadialColumn a r φ)
    (cyclicRadialColumn_identity a r φ) (scalarRadialResponse a r φ E) rfl

theorem magneticHPlus_commutator_pairing (a r φ : ℝ) (v w : MagneticSpace)
    (hv : v ∈ scalarCyclicSpace a r φ) (hw : w ∈ scalarCyclicSpace a r φ) :
    ⟪v, sectorOperator (magneticHPlus a r φ w) -
      magneticHPlus a r φ (sectorOperator w)⟫_ℂ =
    ⟪v, sectorOperator (scalarHamiltonian a r φ w) -
      scalarHamiltonian a r φ (sectorOperator w)⟫_ℂ := by
  rw [magneticHPlus_eq_on_cyclic a r φ w hw, inner_sub_right, inner_sub_right]
  congr 1
  rw [← (magneticHPlus_selfAdjoint a r φ).isSymmetric.apply_clm,
    magneticHPlus_eq_on_cyclic a r φ v hv]
  exact (scalarHamiltonian_selfAdjoint a r φ).isSymmetric.apply_clm _ _

theorem actual_cyclic_balance (a r α : ℝ) (hα : Irrational α)
    (v w : scalarCyclicSpace a r (Real.pi * α)) :
    ⟪v, cyclicSector a r (Real.pi * α) (cyclicHamiltonian a r (Real.pi * α) w) -
      cyclicHamiltonian a r (Real.pi * α) (cyclicSector a r (Real.pi * α) w)⟫_ℂ =
    ⟪v, cyclicSector a r (Real.pi * α)
      (cyclicHamiltonian a r (Real.pi * α) (cyclicOrigin a r (Real.pi * α)))⟫_ℂ *
      ⟪cyclicOrigin a r (Real.pi * α), w⟫_ℂ -
    ⟪v, cyclicOrigin a r (Real.pi * α)⟫_ℂ *
      ⟪cyclicSector a r (Real.pi * α)
        (cyclicHamiltonian a r (Real.pi * α) (cyclicOrigin a r (Real.pi * α))), w⟫_ℂ := by
  rw [cyclicCommutator_inner, cyclicSector_source_inner, cyclicSector_source_inner_left]
  have h := actual_magnetic_balance a r α hα v w v.property w.property
  rw [magneticHPlus_commutator_pairing a r (Real.pi * α) v w v.property w.property,
    magneticHPlus_origin] at h
  exact h

theorem actual_scalar_radial_response (a r α E : ℝ) (hα : Irrational α)
    (hz : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r (Real.pi * α)))
    (hcenter : ⟪magneticOrigin,
      resolvent (scalarHamiltonian a r (Real.pi * α)) (E : ℂ) magneticOrigin⟫_ℂ = 0) :
    scalarRadialResponse a r (Real.pi * α) E =
      1 - (⟪cyclicResolvent a r (Real.pi * α) (E : ℂ) (cyclicOrigin a r (Real.pi * α)),
        cyclicSector a r (Real.pi * α)
          (cyclicResolvent a r (Real.pi * α) (E : ℂ) (cyclicOrigin a r (Real.pi * α)))⟫_ℂ).re /
        ‖cyclicResolvent a r (Real.pi * α) (E : ℂ) (cyclicOrigin a r (Real.pi * α))‖ ^ 2 ∧
      scalarRadialResponse a r (Real.pi * α) E ∈ Set.Icc (0 : ℝ) 2 := by
  apply scalar_radial_response_from_balance a r (Real.pi * α) E hz ?_
    (actual_cyclic_balance a r α hα)
  change ⟪magneticOrigin,
    (cyclicResolvent a r (Real.pi * α) (E : ℂ)
      (cyclicOrigin a r (Real.pi * α)) : MagneticSpace)⟫_ℂ = 0
  rw [cyclicResolvent_apply a r (Real.pi * α) (E : ℂ) hz]
  exact hcenter

end UAMO

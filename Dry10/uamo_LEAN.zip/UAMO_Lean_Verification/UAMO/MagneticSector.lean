import UAMO.MagneticLattice
import UAMO.MagneticBoundary

noncomputable section
namespace UAMO
open MagneticBoundary

theorem sector_coordinate_norm_le (u : MagneticSpace) (s : MagneticSite) :
    ‖(sector s : ℂ) * u s‖ ≤ ‖u s‖ := by
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
  simpa using mul_le_mul_of_nonneg_right (abs_sector_le_one s) (norm_nonneg (u s))

def sectorVector (u : MagneticSpace) : MagneticSpace :=
  ⟨fun s => (sector s : ℂ) * u s, by
    apply memℓp_gen
    have h : Summable (fun s => ‖(sector s : ℂ) * u s‖ ^ (2 : ℕ)) :=
      Summable.of_nonneg_of_le (fun s => sq_nonneg _)
        (fun s => (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).2
          (sector_coordinate_norm_le u s)) (magneticSpace_summable_sq u)
    simpa using h⟩

theorem sectorVector_norm_le (u : MagneticSpace) : ‖sectorVector u‖ ≤ ‖u‖ := by
  apply (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [magneticSpace_norm_sq, magneticSpace_norm_sq]
  exact Summable.tsum_le_tsum
    (fun s => (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).2
      (sector_coordinate_norm_le u s))
    (magneticSpace_summable_sq (sectorVector u)) (magneticSpace_summable_sq u)

def sectorOperator : MagneticOperator :=
  LinearMap.mkContinuous
    { toFun := sectorVector
      map_add' := by
        intro u v
        apply lp.ext
        funext s
        simp [sectorVector, mul_add]
      map_smul' := by
        intro c u
        apply lp.ext
        funext s
        simp [sectorVector, mul_left_comm] }
    1 (fun u => by simpa using sectorVector_norm_le u)

@[simp] theorem sectorOperator_apply (u : MagneticSpace) (s : MagneticSite) :
    sectorOperator u s = (sector s : ℂ) * u s := rfl

theorem sectorOperator_norm_le (u : MagneticSpace) : ‖sectorOperator u‖ ≤ ‖u‖ :=
  sectorVector_norm_le u

theorem sectorOperator_selfAdjoint : IsSelfAdjoint sectorOperator := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro u v
  rw [lp.inner_eq_tsum, lp.inner_eq_tsum]
  apply tsum_congr
  intro s
  change @inner ℂ _ _ ((sector s : ℂ) • u s) (v s) =
    @inner ℂ _ _ (u s) ((sector s : ℂ) • v s)
  simp only [inner_smul_left, inner_smul_right, Complex.conj_ofReal]

theorem sectorOperator_single (s : MagneticSite) (c : ℂ) :
    sectorOperator (lp.single 2 s c) = (sector s : ℂ) • lp.single 2 s c := by
  apply lp.ext
  funext t
  simp only [sectorOperator_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  by_cases h : t = s
  · subst t
    simp
  · rw [lp.single_apply_ne (E := fun _ : MagneticSite => ℂ) 2 s c h]
    simp

theorem sectorOperator_origin : sectorOperator magneticOrigin = 0 := by
  rw [magneticOrigin, sectorOperator_single]
  norm_num [sector, intSign]

def radialHamiltonian (a r φ : ℝ) : MagneticOperator :=
  magneticPair φ (1, 1) ((r : ℂ) * diagonalHopping a φ) +
    magneticPair φ (1, 2) (-2 * (r : ℂ) ^ 2)

theorem radialHamiltonian_origin (a r φ : ℝ) :
    radialHamiltonian a r φ magneticOrigin =
      (1 - sectorOperator) (scalarHamiltonian a r φ magneticOrigin) := by
  rw [scalarHamiltonian, magneticHamiltonianWith_origin]
  simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.one_apply,
    map_add, map_smul, sectorOperator_single]
  norm_num [sector, intSign, radialHamiltonian, magneticPair_origin,
    map_add, map_mul, map_neg, map_pow]
  module

end UAMO

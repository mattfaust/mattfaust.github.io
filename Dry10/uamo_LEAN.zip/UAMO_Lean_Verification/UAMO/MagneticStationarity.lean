import UAMO.MagneticLattice
import UAMO.CyclicStationarity
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Pow

noncomputable section
namespace UAMO

def scalarRightHamiltonian (a r φ : ℝ) : MagneticOperator :=
  magneticHamiltonianWith (-φ) ((r : ℂ) * diagonalHopping a φ) (-(r : ℂ) ^ 2)

def scalarCyclicSpace (a r φ : ℝ) : Submodule ℂ MagneticSpace :=
  closedCyclicSpace (scalarHamiltonian a r φ) magneticOrigin

theorem scalarRightHamiltonian_selfAdjoint (a r φ : ℝ) :
    IsSelfAdjoint (scalarRightHamiltonian a r φ) :=
  magneticHamiltonianWith_selfAdjoint _ _ _

theorem scalarRightHamiltonian_commutes (a r φ : ℝ) :
    Commute (scalarRightHamiltonian a r φ) (scalarHamiltonian a r φ) :=
  (magneticHamiltonianWith_opposite_commute φ
    ((r : ℂ) * diagonalHopping a φ) (-(r : ℂ) ^ 2)).symm

theorem scalarRightHamiltonian_origin_agree (a r φ : ℝ) :
    scalarRightHamiltonian a r φ magneticOrigin = scalarHamiltonian a r φ magneticOrigin :=
  (magneticHamiltonianWith_origin_agree φ
    ((r : ℂ) * diagonalHopping a φ) (-(r : ℂ) ^ 2)).symm

theorem magneticOrigin_mem_scalarCyclicSpace (a r φ : ℝ) :
    magneticOrigin ∈ scalarCyclicSpace a r φ :=
  source_mem_closedCyclicSpace _ _

theorem scalarCyclicSpace_invariant (a r φ : ℝ) (u : MagneticSpace)
    (hu : u ∈ scalarCyclicSpace a r φ) :
    scalarHamiltonian a r φ u ∈ scalarCyclicSpace a r φ :=
  closedCyclicSpace_invariant _ _ u hu

theorem scalarRightHamiltonian_eq_on_cyclic (a r φ : ℝ) (u : MagneticSpace)
    (hu : u ∈ scalarCyclicSpace a r φ) :
    scalarRightHamiltonian a r φ u = scalarHamiltonian a r φ u :=
  commuting_action_eq_on_closedCyclicSpace _ _ _
    (scalarRightHamiltonian_commutes a r φ)
    (scalarRightHamiltonian_origin_agree a r φ) u hu

theorem scalarAntisymmetric_vanishes_on_cyclic (a r φ : ℝ) (u : MagneticSpace)
    (hu : u ∈ scalarCyclicSpace a r φ) :
    ((1 / 2 : ℂ) • (scalarHamiltonian a r φ - scalarRightHamiltonian a r φ)) u = 0 := by
  simp only [ContinuousLinearMap.smul_apply, ContinuousLinearMap.sub_apply,
    scalarRightHamiltonian_eq_on_cyclic a r φ u hu, sub_self, smul_zero]

theorem magneticPair_ofReal_mul (φ : ℝ) (ν : MagneticSite) (t : ℝ) (c : ℂ) :
    magneticPair φ ν ((t : ℂ) * c) = t • magneticPair φ ν c := by
  rw [RCLike.real_smul_eq_coe_smul (K := ℂ)]
  simp [magneticPair, star_mul, smul_add, smul_smul, mul_comm]

theorem scalarHamiltonian_polynomial (a r φ : ℝ) :
    scalarHamiltonian a r φ = magneticPair φ (1, 0) 1 +
      r • magneticPair φ (1, 1) (diagonalHopping a φ) +
      r ^ 2 • magneticPair φ (1, 2) (-1) := by
  unfold scalarHamiltonian magneticHamiltonianWith
  rw [magneticPair_ofReal_mul]
  congr 1
  rw [← magneticPair_ofReal_mul]
  congr 1
  simp

def scalarHamiltonianDerivative (a r φ : ℝ) : MagneticOperator :=
  magneticPair φ (1, 1) (diagonalHopping a φ) +
    (2 * r) • magneticPair φ (1, 2) (-1)

theorem scalarHamiltonian_radial_derivative (a r φ : ℝ) :
    r • scalarHamiltonianDerivative a r φ =
      magneticPair φ (1, 1) ((r : ℂ) * diagonalHopping a φ) +
        magneticPair φ (1, 2) (-2 * (r : ℂ) ^ 2) := by
  rw [scalarHamiltonianDerivative, smul_add, magneticPair_ofReal_mul, smul_smul]
  congr 1
  rw [← magneticPair_ofReal_mul]
  congr 1
  push_cast
  ring

end UAMO

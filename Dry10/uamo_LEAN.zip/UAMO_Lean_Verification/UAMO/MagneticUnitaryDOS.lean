import UAMO.UnitarySpectralMeasure
import UAMO.MagneticWalkMeasure
import UAMO.ScalarSpectralMeasure
import UAMO.CircleDOSReconstruction

noncomputable section
namespace UAMO
open MeasureTheory SpectralMoments UnitarySpectral PhysicalWalk
open scoped Matrix ContinuousFunctionalCalculus ENNReal

local instance magneticDOS_scalarNormedSpace (φ : ℝ) : NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)

local instance magneticDOS_scalarModule (φ : ℝ) : Module ℝ (magneticAlgebra φ) :=
  @Algebra.toModule ℝ (magneticAlgebra φ) _ _ (magneticAlgebra_realNormedAlgebra φ).toAlgebra

local instance magneticDOS_scalarComplexModule (φ : ℝ) : Module ℂ (magneticAlgebra φ) :=
  @Algebra.toModule ℂ (magneticAlgebra φ) _ _ (magneticAlgebra φ).algebra

local instance magneticDOS_scalarRealStarModule (φ : ℝ) : StarModule ℝ (magneticAlgebra φ) where
  star_smul c B := by
    apply Subtype.ext
    change star ((c : ℂ) • (B : MagneticOperator)) = (c : ℂ) • star (B : MagneticOperator)
    rw [star_smul, Complex.star_def, Complex.conj_ofReal]

local instance magneticDOS_matrixNormedSpace (φ : ℝ) : NormedSpace ℝ (MagneticMatrixAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (MagneticMatrixAlgebra φ)

local instance magneticDOS_matrixModule (φ : ℝ) : Module ℝ (MagneticMatrixAlgebra φ) :=
  @Algebra.toModule ℝ (MagneticMatrixAlgebra φ) _ _ (magneticMatrixAlgebra_realNormedAlgebra φ).toAlgebra

local instance magneticDOS_matrixComplexModule (φ : ℝ) : Module ℂ (MagneticMatrixAlgebra φ) :=
  @Algebra.toModule ℂ (MagneticMatrixAlgebra φ) _ _ inferInstance

local instance magneticDOS_matrixRealStarModule (φ : ℝ) : StarModule ℝ (MagneticMatrixAlgebra φ) :=
  CStarMatrix.instStarModule

def cstarMagneticWalk (a r φ : ℝ) : MagneticMatrixAlgebra φ :=
  CStarMatrix.ofMatrix (magneticWalk a r φ)

theorem cstarMagneticWalk_unitary (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    cstarMagneticWalk a r φ ∈ unitary (MagneticMatrixAlgebra φ) :=
  unitary.map_mem CStarMatrix.ofMatrixStarAlgEquiv
    (magneticWalk_unitary a r φ ha0 ha1 hr0 hr1)

def magneticFirstReflection (a φ : ℝ) : unitary (MagneticMatrixAlgebra φ) :=
  ⟨CStarMatrix.ofMatrix (reflection (firstColumn a (magneticWalkU φ))),
    unitary.map_mem CStarMatrix.ofMatrixStarAlgEquiv
      (reflection_unitary _ (firstColumn_isometry a _ (magneticWalkU_unitary φ)))⟩

def magneticSecondReflection (r φ : ℝ) : unitary (MagneticMatrixAlgebra φ) :=
  ⟨CStarMatrix.ofMatrix (reflection (secondColumn r (magneticWalkV φ))),
    unitary.map_mem CStarMatrix.ofMatrixStarAlgEquiv
      (reflection_unitary _ (secondColumn_isometry r _ (magneticWalkV_unitary φ)))⟩

theorem magneticFirstReflection_selfAdjoint (a φ : ℝ) :
    IsSelfAdjoint (magneticFirstReflection a φ : MagneticMatrixAlgebra φ) := by
  change star (reflection (firstColumn a (magneticWalkU φ))) = _
  exact reflection_selfAdjoint _

theorem magneticSecondReflection_selfAdjoint (r φ : ℝ) :
    IsSelfAdjoint (magneticSecondReflection r φ : MagneticMatrixAlgebra φ) := by
  change star (reflection (secondColumn r (magneticWalkV φ))) = _
  exact reflection_selfAdjoint _

set_option maxRecDepth 4096 in
theorem cstarMagneticWalk_eq_reflections (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    cstarMagneticWalk a r φ =
      (magneticFirstReflection a φ : MagneticMatrixAlgebra φ) *
        (magneticSecondReflection r φ : MagneticMatrixAlgebra φ) := by
  exact congrArg (fun B : TwoByTwo (magneticAlgebra φ) => CStarMatrix.ofMatrix B)
    (walk_eq_reflection_product a r ha0 ha1 hr0 hr1 _ _
      (magneticWalkU_unitary φ) (magneticWalkV_unitary φ))

def magneticUnitaryDOS (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) : Measure ℂ :=
  complexSpectralMeasure (magneticMatrixFaithfulState φ) (cstarMagneticWalk a r φ)
    (isStarNormal_of_mem_unitary (cstarMagneticWalk_unitary a r φ ha0 ha1 hr0 hr1))

instance magneticUnitaryDOS_isProbabilityMeasure (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    IsProbabilityMeasure (magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1) := by
  unfold magneticUnitaryDOS
  infer_instance

theorem magneticUnitaryDOS_ae_circle (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    ∀ᵐ z ∂magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1, ‖z‖ = 1 :=
  complexSpectralMeasure_ae_circle _ _ _ (cstarMagneticWalk_unitary a r φ ha0 ha1 hr0 hr1)

theorem magneticUnitaryDOS_conj_invariant (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1).map (star : ℂ → ℂ) =
      magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1 := by
  unfold magneticUnitaryDOS
  apply complexSpectralMeasure_conj_invariant_of_conjugacy _ _ _ (magneticFirstReflection a φ)
  rw [cstarMagneticWalk_eq_reflections a r φ ha0 ha1 hr0 hr1]
  change (magneticFirstReflection a φ : MagneticMatrixAlgebra φ) *
    ((magneticFirstReflection a φ : MagneticMatrixAlgebra φ) *
      (magneticSecondReflection r φ : MagneticMatrixAlgebra φ)) *
      star (magneticFirstReflection a φ : MagneticMatrixAlgebra φ) = _
  rw [star_mul, (magneticFirstReflection_selfAdjoint a φ).star_eq,
    (magneticSecondReflection_selfAdjoint r φ).star_eq, ← mul_assoc]
  have hRR := unitary.star_mul_self_of_mem (magneticFirstReflection a φ).property
  rw [(magneticFirstReflection_selfAdjoint a φ).star_eq] at hRR
  rw [hRR, one_mul]

section MeasureCalculus
variable {A : Type*} [CStarAlgebra A]

theorem realSpectralMeasure_congr (τ : FaithfulTracialState A) (H K : A)
    (hH : IsSelfAdjoint H) (hK : IsSelfAdjoint K) (hHK : H = K) :
    realSpectralMeasure τ H hH = realSpectralMeasure τ K hK := by
  subst K
  rfl

theorem realSpectralMeasure_map_scale (τ : FaithfulTracialState A) (H : A)
    (hH : IsSelfAdjoint H) (c : ℝ) :
    (realSpectralMeasure τ H hH).map (fun x : ℝ => c * x) =
      realSpectralMeasure τ (c • H) ((IsSelfAdjoint.all c).smul hH) := by
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  rw [integral_map (φ := fun x : ℝ => c * x)
    (show Measurable (fun x : ℝ => c * x) from (continuous_const.mul continuous_id).measurable).aemeasurable
    f.continuous.aestronglyMeasurable,
    realSpectralMeasure_integral_cfc τ H hH (fun x : ℝ => f (c * x))
      (f.continuous.comp (continuous_const.mul continuous_id)),
    realSpectralMeasure_integral_cfc τ (c • H) ((IsSelfAdjoint.all c).smul hH) f f.continuous,
    cfc_comp_const_mul c f H (by fun_prop) hH]

end MeasureCalculus

section ReflectionRealPart
variable {A : Type*} [CStarAlgebra A] [PartialOrder A] [StarOrderedRing A]

theorem operatorRealPart_ofMatrix (B : TwoByTwo A) :
    operatorRealPart (CStarMatrix.ofMatrix B) =
      (1 / 2 : ℝ) • CStarMatrix.ofMatrix (B + star B) := rfl

end ReflectionRealPart

theorem magneticState_realSpectralMeasure_eq_scalar (a r φ : ℝ) :
    realSpectralMeasure (magneticFaithfulState φ) (scalarAlgebraHamiltonian a r φ)
      (scalarAlgebraHamiltonian_isSelfAdjoint a r φ) = scalarRealSpectralMeasure a r φ := by
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  rw [realSpectralMeasure_integral_cfc _ _ _ f f.continuous,
    scalarRealSpectralMeasure_integral_cfc a r φ f f.continuous]
  rfl

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 4096 in
theorem operatorRealPart_cstarMagneticWalk (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    operatorRealPart (cstarMagneticWalk a r φ) =
      (1 / 2 : ℝ) • matrixReflectionDiscriminant
        (firstColumn a (magneticWalkU φ)) (secondColumn r (magneticWalkV φ)) := by
  let C := firstColumn a (magneticWalkU φ)
  let D := secondColumn r (magneticWalkV φ)
  have hw : magneticWalk a r φ = reflection C * reflection D :=
    walk_eq_reflection_product a r ha0 ha1 hr0 hr1 _ _
      (magneticWalkU_unitary φ) (magneticWalkV_unitary φ)
  have hd : magneticWalk a r φ + star (magneticWalk a r φ) =
      reflection C * reflection D + reflection D * reflection C := by
    rw [hw, star_mul, reflection_selfAdjoint, reflection_selfAdjoint]
  rw [cstarMagneticWalk, operatorRealPart_ofMatrix]
  exact congrArg (fun B : TwoByTwo (magneticAlgebra φ) => (1 / 2 : ℝ) • CStarMatrix.ofMatrix B) hd

theorem half_scaledScalarAlgebraHamiltonian (a r φ : ℝ) :
    (1 / 2 : ℝ) • scaledScalarAlgebraHamiltonian a r φ =
      (a / ((1 + a ^ 2) * (1 + r ^ 2))) • scalarAlgebraHamiltonian a r φ := by
  have hscaled : scaledScalarAlgebraHamiltonian a r φ =
      (2 * a / ((1 + a ^ 2) * (1 + r ^ 2)) : ℝ) • scalarAlgebraHamiltonian a r φ := by
    apply Subtype.ext
    rfl
  rw [hscaled, smul_smul]
  congr 1
  ring

set_option maxRecDepth 4096 in

theorem magneticUnitaryDOS_realPart {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    (magneticUnitaryDOS a r φ ha.le ha1 hr0 hr1).map Complex.re =
      (scalarRealSpectralMeasure a r φ).map
        (fun x : ℝ => (a / ((1 + a ^ 2) * (1 + r ^ 2))) * x) := by
  let D := matrixReflectionDiscriminant
    (firstColumn a (magneticWalkU φ)) (secondColumn r (magneticWalkV φ))
  let hD : IsSelfAdjoint D := matrixReflectionDiscriminant_selfAdjoint _ _
  let hH := scalarAlgebraHamiltonian_isSelfAdjoint a r φ
  let hB := scaledScalarAlgebraHamiltonian_selfAdjoint a r φ
  let κ : ℝ := a / ((1 + a ^ 2) * (1 + r ^ 2))
  calc
    _ = realSpectralMeasure (magneticMatrixFaithfulState φ)
        (operatorRealPart (cstarMagneticWalk a r φ))
        (operatorRealPart_selfAdjoint (cstarMagneticWalk a r φ)) :=
      complexSpectralMeasure_map_re _ _ _
    _ = realSpectralMeasure (magneticMatrixFaithfulState φ)
        ((1 / 2 : ℝ) • D) ((IsSelfAdjoint.all (1 / 2 : ℝ)).smul hD) :=
      realSpectralMeasure_congr _ _ _ _ _
        (operatorRealPart_cstarMagneticWalk a r φ ha.le ha1 hr0 hr1)
    _ = (realSpectralMeasure (magneticMatrixFaithfulState φ) D hD).map
        (fun x : ℝ => (1 / 2 : ℝ) * x) :=
      (realSpectralMeasure_map_scale _ D hD (1 / 2)).symm
    _ = (realSpectralMeasure (magneticFaithfulState φ)
        (scaledScalarAlgebraHamiltonian a r φ) hB).map (fun x : ℝ => (1 / 2 : ℝ) * x) := by
      rw [show realSpectralMeasure (magneticMatrixFaithfulState φ) D hD =
        realSpectralMeasure (magneticFaithfulState φ) (scaledScalarAlgebraHamiltonian a r φ) hB
          from magneticWalk_discriminant_scalar_measure ha.ne' hr0 hr1 φ]
    _ = realSpectralMeasure (magneticFaithfulState φ)
        ((1 / 2 : ℝ) • scaledScalarAlgebraHamiltonian a r φ)
        ((IsSelfAdjoint.all (1 / 2 : ℝ)).smul hB) :=
      realSpectralMeasure_map_scale _ _ hB (1 / 2)
    _ = realSpectralMeasure (magneticFaithfulState φ) (κ • scalarAlgebraHamiltonian a r φ)
        ((IsSelfAdjoint.all κ).smul hH) :=
      realSpectralMeasure_congr _ _ _ _ _ (half_scaledScalarAlgebraHamiltonian a r φ)
    _ = (realSpectralMeasure (magneticFaithfulState φ) (scalarAlgebraHamiltonian a r φ) hH).map
        (fun x : ℝ => κ * x) := (realSpectralMeasure_map_scale _ _ hH κ).symm
    _ = _ := by rw [magneticState_realSpectralMeasure_eq_scalar]

theorem scalarRealSpectralMeasure_scaled_ae_Icc {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    ∀ᵐ x ∂scalarRealSpectralMeasure a r φ,
      (a / ((1 + a ^ 2) * (1 + r ^ 2))) * x ∈ Set.Icc (-1 : ℝ) 1 := by
  have hproj : ∀ᵐ y ∂(magneticUnitaryDOS a r φ ha.le ha1 hr0 hr1).map Complex.re,
      y ∈ Set.Icc (-1 : ℝ) 1 := by
    apply (ae_map_iff Complex.continuous_re.measurable.aemeasurable measurableSet_Icc).mpr
    filter_upwards [magneticUnitaryDOS_ae_circle a r φ ha.le ha1 hr0 hr1] with z hz
    exact abs_le.mp ((Complex.abs_re_le_norm z).trans_eq hz)
  rw [magneticUnitaryDOS_realPart ha ha1 hr0 hr1 φ] at hproj
  exact (ae_map_iff
    (show Measurable (fun x : ℝ => (a / ((1 + a ^ 2) * (1 + r ^ 2))) * x) from
      (continuous_const.mul continuous_id).measurable).aemeasurable measurableSet_Icc).mp hproj

end UAMO

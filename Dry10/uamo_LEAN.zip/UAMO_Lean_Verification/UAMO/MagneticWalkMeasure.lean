import UAMO.MagneticWalkSpectrum

noncomputable section
namespace UAMO
open OverlapGauge PhysicalWalk SpectralMoments
open scoped InnerProductSpace Matrix

local instance walkMeasure_magneticAlgebra_nontrivial (φ : ℝ) :
    Nontrivial (magneticAlgebra φ) := by
  apply nontrivial_of_ne (0 : magneticAlgebra φ) 1
  intro h
  have hh := congrArg (magneticTrace φ) h
  exact zero_ne_one (by simpa only [map_zero, magneticTrace_one] using hh)

def scaledScalarAlgebraHamiltonian (a r φ : ℝ) : magneticAlgebra φ :=
  ((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) • scalarAlgebraHamiltonian a r φ

@[simp] theorem scaledScalarAlgebraHamiltonian_coe (a r φ : ℝ) :
    (scaledScalarAlgebraHamiltonian a r φ : MagneticOperator) =
      ((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) • scalarHamiltonian a r φ := by
  change ((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) •
    (scalarAlgebraHamiltonian a r φ : MagneticOperator) = _
  rw [scalarAlgebraHamiltonian_coe]

theorem scaledScalarAlgebraHamiltonian_selfAdjoint (a r φ : ℝ) :
    IsSelfAdjoint (scaledScalarAlgebraHamiltonian a r φ) :=
  (show IsSelfAdjoint (((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ)) from
    Complex.conj_ofReal _).smul (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)

theorem magneticScalarDiscriminant_selfAdjoint (a r φ : ℝ) :
    IsSelfAdjoint (magneticScalarDiscriminant a r φ) :=
  scalarOverlapDiscriminant_selfAdjoint _ _

theorem magneticScalarDiscriminant_scaled_moments {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) (n : ℕ) :
    magneticTraceReal φ (magneticScalarDiscriminant a r φ ^ n) =
      magneticTraceReal φ (scaledScalarAlgebraHamiltonian a r φ ^ n) := by
  have hc : conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ)
      (magneticScalarDiscriminant a r φ : MagneticOperator) =
      (scaledScalarAlgebraHamiltonian a r φ : MagneticOperator) := by
    rw [scaledScalarAlgebraHamiltonian_coe]
    exact magneticScalarDiscriminant_conjugacy ha hr0 hr1 φ
  have hm := overlapGauge_source_expectation hr0 hr1 φ
    ((magneticScalarDiscriminant a r φ : MagneticOperator)^n)
  rw [map_pow,hc] at hm
  simpa only [magneticTraceReal_apply, rootTrace_eq_inner]
    using congrArg Complex.re hm.symm

theorem magneticScalarDiscriminant_scaled_measure {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    realSpectralMeasure (magneticFaithfulState φ)
      (magneticScalarDiscriminant a r φ) (magneticScalarDiscriminant_selfAdjoint a r φ) =
    realSpectralMeasure (magneticFaithfulState φ)
      (scaledScalarAlgebraHamiltonian a r φ) (scaledScalarAlgebraHamiltonian_selfAdjoint a r φ) :=
  realSpectralMeasure_eq_of_moments _ _ _ _ _ _
    (magneticScalarDiscriminant_scaled_moments ha hr0 hr1 φ)

theorem magneticWalk_discriminant_scalar_measure {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    realSpectralMeasure (magneticMatrixFaithfulState φ)
      (matrixReflectionDiscriminant
        (firstColumn a (magneticWalkU φ)) (secondColumn r (magneticWalkV φ)))
      (matrixReflectionDiscriminant_selfAdjoint _ _) =
    realSpectralMeasure (magneticFaithfulState φ)
      (scaledScalarAlgebraHamiltonian a r φ) (scaledScalarAlgebraHamiltonian_selfAdjoint a r φ) := by
  exact (magnetic_reflection_overlap_measure φ _ _
    (firstColumn_isometry a _ (magneticWalkU_unitary φ))
    (secondColumn_isometry r _ (magneticWalkV_unitary φ))).trans
      (magneticScalarDiscriminant_scaled_measure ha hr0 hr1 φ)

end UAMO

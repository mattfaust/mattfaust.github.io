import UAMO.OverlapGaugeSquare
import UAMO.ReflectionSpectralCorrespondence
import UAMO.OverlapNormalization

noncomputable section
namespace UAMO
open PhysicalWalk OverlapGauge
open scoped Matrix

def magneticAlgebraU (φ : ℝ) : magneticAlgebra φ :=
  ⟨magneticU φ, polynomialSpace_subset_magneticAlgebra φ
    (magneticShift_mem_polynomialSpace φ (-1,0))⟩

def magneticAlgebraV (φ : ℝ) : magneticAlgebra φ :=
  ⟨magneticV φ, polynomialSpace_subset_magneticAlgebra φ
    ((magneticPolynomialSpace φ).smul_mem (latticePhase φ 1)
      (magneticShift_mem_polynomialSpace φ (1,1)))⟩

theorem magneticAlgebraU_unitary (φ : ℝ) : magneticAlgebraU φ ∈ unitary (magneticAlgebra φ) := by
  constructor <;> apply Subtype.ext
  · exact magneticU_star_mul φ
  · exact magneticU_mul_star φ

theorem magneticAlgebraV_unitary (φ : ℝ) : magneticAlgebraV φ ∈ unitary (magneticAlgebra φ) := by
  constructor <;> apply Subtype.ext
  · exact magneticV_star_mul φ
  · exact magneticV_mul_star φ

section Algebra
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

theorem neg_I_smul_unitary (u : A) (hu : u ∈ unitary A) :
    (-Complex.I) • u ∈ unitary A := by
  apply unitary.mem_iff.mpr
  simp only [star_smul, star_neg, Complex.star_def, Complex.conj_I, neg_neg,
    smul_mul_assoc, mul_smul_comm, smul_smul, mul_neg, neg_mul, Complex.I_mul_I,
    neg_neg, one_smul, unitary.star_mul_self_of_mem hu, unitary.mul_star_self_of_mem hu,
    and_self]

end Algebra

def magneticWalkU (φ : ℝ) : magneticAlgebra φ := (-Complex.I) • magneticAlgebraU φ

def magneticWalkV (φ : ℝ) : magneticAlgebra φ := (-Complex.I) • magneticAlgebraV φ

theorem magneticWalkU_unitary (φ : ℝ) : magneticWalkU φ ∈ unitary (magneticAlgebra φ) :=
  neg_I_smul_unitary _ (magneticAlgebraU_unitary φ)

theorem magneticWalkV_unitary (φ : ℝ) : magneticWalkV φ ∈ unitary (magneticAlgebra φ) :=
  neg_I_smul_unitary _ (magneticAlgebraV_unitary φ)

def magneticWalk (a r φ : ℝ) : TwoByTwo (magneticAlgebra φ) :=
  walk (coupling a) (coupling r) (magneticWalkU φ) (magneticWalkV φ)

def magneticScalarDiscriminant (a r φ : ℝ) : magneticAlgebra φ :=
  scalarOverlapDiscriminant (firstColumn a (magneticWalkU φ))
    (secondColumn r (magneticWalkV φ))

theorem magneticScalarDiscriminant_coe (a r φ : ℝ) :
    (magneticScalarDiscriminant a r φ : MagneticOperator) =
      ((2 / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) •
        (star (overlapPolynomial a r (magneticU φ) (magneticV φ)) *
          overlapPolynomial a r (magneticU φ) (magneticV φ)) -
      (2 : ℂ) • (1 : MagneticOperator) := by
  rw [magneticScalarDiscriminant, scalarOverlapDiscriminant_eq_polynomial]
  have hu : Complex.I • magneticWalkU φ = magneticAlgebraU φ := by
    apply Subtype.ext
    change Complex.I • ((-Complex.I) • magneticU φ) = magneticU φ
    simp only [smul_smul, mul_neg, Complex.I_mul_I, neg_neg, one_smul]
  have hv : Complex.I • magneticWalkV φ = magneticAlgebraV φ := by
    apply Subtype.ext
    change Complex.I • ((-Complex.I) • magneticV φ) = magneticV φ
    simp only [smul_smul, mul_neg, Complex.I_mul_I, neg_neg, one_smul]
  rw [hu,hv]
  rfl

theorem magneticAlgebra_spectrum_coe (φ : ℝ) (A : magneticAlgebra φ) :
    spectrum ℂ (A : MagneticOperator) = spectrum ℂ A := by
  ext z
  rw [spectrum.mem_iff, spectrum.mem_iff]
  exact not_congr ((magneticAlgebra φ).coe_isUnit
    (a := algebraMap ℂ (magneticAlgebra φ) z - A))

theorem magneticScalarDiscriminant_conjugacy {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ * (magneticScalarDiscriminant a r φ : MagneticOperator) *
        star (overlapGauge hr0 hr1 φ) =
      ((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) • scalarHamiltonian a r φ := by
  change conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ) _ = _
  rw [magneticScalarDiscriminant_coe, map_sub, map_smul, map_smul, map_one]
  have hsq := magnetic_overlap_square_conjugacy ha hr0 hr1 φ
  change conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ) _ = _ at hsq
  rw [hsq]
  ext u s
  simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.add_apply, ContinuousLinearMap.one_apply,
    lp.coeFn_sub, lp.coeFn_smul, lp.coeFn_add, Pi.sub_apply, Pi.smul_apply,
    Pi.add_apply, smul_eq_mul, RCLike.real_smul_eq_coe_smul (K := ℂ)]
  push_cast
  have hM : (1+(a : ℂ)^2)*(1+(r : ℂ)^2) ≠ 0 := by
    norm_cast
    positivity
  field_simp
  ring

theorem magneticScalarDiscriminant_spectrum {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    spectrum ℂ (magneticScalarDiscriminant a r φ) =
      spectrum ℂ (((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) • scalarHamiltonian a r φ) := by
  rw [← magneticAlgebra_spectrum_coe,
    ← magneticScalarDiscriminant_conjugacy ha hr0 hr1 φ]
  exact (unitary.spectrum.unitary_conjugate (R := ℂ)
    (u := overlapGaugeUnitary hr0 hr1 φ)).symm

theorem magneticWalk_unitary (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    magneticWalk a r φ ∈ unitary (TwoByTwo (magneticAlgebra φ)) :=
  walk_unitary_stereographic a r ha0 ha1 hr0 hr1 _ _
    (magneticWalkU_unitary φ) (magneticWalkV_unitary φ)

theorem magnetic_scaled_energy_spectrum {a : ℝ} (ha : a ≠ 0) (r φ t : ℝ) :
    ((2 * Real.cos t : ℝ) : ℂ) ∈ spectrum ℂ
      (((2*a / ((1+a^2)*(1+r^2)) : ℝ) : ℂ) • scalarHamiltonian a r φ) ↔
    ((((1+a^2)*(1+r^2))/a * Real.cos t : ℝ) : ℂ) ∈
      spectrum ℂ (scalarHamiltonian a r φ) := by
  let M : ℝ := (1+a^2)*(1+r^2)
  have hM : M ≠ 0 := by dsimp [M]; positivity
  have hc : ((2*a/M : ℝ) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (div_ne_zero (mul_ne_zero (by norm_num) ha) hM)
  let c : ℂˣ := Units.mk0 ((2*a/M : ℝ) : ℂ) hc
  have he : ((2 * Real.cos t : ℝ) : ℂ) = c • (((M/a) * Real.cos t : ℝ) : ℂ) := by
    change ((2 * Real.cos t : ℝ) : ℂ) =
      ((2*a/M : ℝ) : ℂ) * (((M/a) * Real.cos t : ℝ) : ℂ)
    norm_cast
    field_simp
    ring
  rw [he]
  change c • (((M/a) * Real.cos t : ℝ) : ℂ) ∈
    spectrum ℂ (c • scalarHamiltonian a r φ) ↔ _
  exact spectrum.smul_mem_smul_iff

theorem magneticWalk_spectrum_scalar {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ t : ℝ) :
    Complex.exp ((t : ℂ) * Complex.I) ∈ spectrum ℂ (magneticWalk a r φ) ↔
      ((((1+a^2)*(1+r^2))/a * Real.cos t : ℝ) : ℂ) ∈
        spectrum ℂ (scalarHamiltonian a r φ) := by
  rw [magneticWalk, walk_eq_reflection_product a r ha.le ha1 hr0 hr1 _ _
    (magneticWalkU_unitary φ) (magneticWalkV_unitary φ),
    magnetic_reflection_product_overlap_spectrum φ _ _
      (firstColumn_isometry a _ (magneticWalkU_unitary φ))
      (secondColumn_isometry r _ (magneticWalkV_unitary φ)) t]
  change ((2 * Real.cos t : ℝ) : ℂ) ∈ spectrum ℂ (magneticScalarDiscriminant a r φ) ↔ _
  rw [magneticScalarDiscriminant_spectrum ha.ne' hr0 hr1]
  exact magnetic_scaled_energy_spectrum ha.ne' r φ t

end UAMO

import UAMO.MagneticLattice
import UAMO.SquareReduction

noncomputable section
namespace UAMO

theorem latticePhase_star (φ : ℝ) (n : ℤ) :
    star (latticePhase φ n) = latticePhase φ (-n) := by
  simp [latticePhase, Complex.star_def, ← Complex.exp_conj]

def magneticU (φ : ℝ) : MagneticOperator := magneticShift φ (-1, 0)

def magneticV (φ : ℝ) : MagneticOperator :=
  latticePhase φ 1 • magneticShift φ (1, 1)

theorem magneticU_star_mul (φ : ℝ) : star (magneticU φ) * magneticU φ = 1 := by
  simp only [magneticU, magneticShift_star]
  convert magneticShift_inverse φ (1, 0) using 1

theorem magneticU_mul_star (φ : ℝ) : magneticU φ * star (magneticU φ) = 1 := by
  rw [magneticU, magneticShift_star, magneticShift_inverse]

theorem magneticV_star_mul (φ : ℝ) : star (magneticV φ) * magneticV φ = 1 := by
  simp only [magneticV, star_smul, latticePhase_star, magneticShift_star,
    smul_mul_assoc, mul_smul_comm, smul_smul, magneticShift_mul]
  norm_num [wedge, ← latticePhase_add]

theorem magneticV_mul_star (φ : ℝ) : magneticV φ * star (magneticV φ) = 1 := by
  simp only [magneticV, star_smul, latticePhase_star, magneticShift_star,
    smul_mul_assoc, mul_smul_comm, smul_smul, magneticShift_mul]
  norm_num [wedge, ← latticePhase_add]

theorem magneticU_mul_V (φ : ℝ) :
    magneticU φ * magneticV φ = latticePhase φ 2 • (magneticV φ * magneticU φ) := by
  simp only [magneticU, magneticV, smul_mul_assoc, mul_smul_comm,
    magneticShift_mul, smul_smul]
  norm_num [wedge, ← latticePhase_add]
  congr 2

theorem magneticV_sq_mul_U (φ : ℝ) :
    magneticV φ ^ 2 * magneticU φ = magneticShift φ (1, 2) := by
  simp only [pow_two, magneticV, magneticU, smul_mul_assoc, mul_smul_comm,
    magneticShift_mul, smul_smul]
  norm_num [wedge, ← latticePhase_add]
  congr 1

theorem magneticU_star_mul_V_star_sq (φ : ℝ) :
    star (magneticU φ) * star (magneticV φ) ^ 2 = magneticShift φ (-1, -2) := by
  have h := congrArg star (magneticV_sq_mul_U φ)
  simpa only [star_mul, star_pow, magneticShift_star] using h

theorem magneticU_conjugates_V (φ : ℝ) :
    star (magneticU φ) * magneticV φ * magneticU φ =
      latticePhase φ (-2) • magneticV φ := by
  simp only [magneticU, magneticV, magneticShift_star, smul_mul_assoc,
    mul_smul_comm, magneticShift_mul, smul_smul]
  norm_num [wedge, ← latticePhase_add]
  congr 1

theorem magneticU_conjugates_V_star (φ : ℝ) :
    star (magneticU φ) * star (magneticV φ) * magneticU φ =
      latticePhase φ 2 • star (magneticV φ) := by
  have h := congrArg star (magneticU_conjugates_V φ)
  simpa only [star_mul, star_star, star_smul, latticePhase_star, neg_neg, mul_assoc] using h

theorem magneticV_middle_pair (a φ : ℝ) :
    ((a : ℂ)⁻¹ - (a : ℂ) * latticePhase φ (-2)) • magneticV φ +
      ((a : ℂ)⁻¹ - (a : ℂ) * latticePhase φ 2) • star (magneticV φ) =
        magneticPair φ (1, 1) (diagonalHopping a φ) := by
  simp [magneticV, magneticPair, diagonalHopping, star_smul, star_sub, star_mul,
    star_inv₀, latticePhase_star, magneticShift_star, smul_smul, sub_mul, mul_sub, mul_left_comm,
    mul_assoc, ← latticePhase_add, mul_comm]

def weylEffectiveHamiltonian (a r φ : ℝ) : MagneticOperator :=
  magneticU φ + star (magneticU φ) +
    r • (((a : ℂ)⁻¹ - (a : ℂ) * latticePhase φ (-2)) • magneticV φ +
      ((a : ℂ)⁻¹ - (a : ℂ) * latticePhase φ 2) • star (magneticV φ)) -
    r ^ 2 • (magneticV φ ^ 2 * magneticU φ + star (magneticU φ) * star (magneticV φ) ^ 2)

theorem weylEffectiveHamiltonian_eq_scalarHamiltonian (a r φ : ℝ) :
    weylEffectiveHamiltonian a r φ = scalarHamiltonian a r φ := by
  unfold weylEffectiveHamiltonian
  rw [magneticV_middle_pair, magneticV_sq_mul_U, magneticU_star_mul_V_star_sq]
  simp only [scalarHamiltonian, magneticHamiltonianWith, magneticPair, magneticU,
    magneticShift_star, star_one, one_smul, star_mul, star_neg, star_pow,
    RCLike.real_smul_eq_coe_smul (K := ℂ), smul_add, smul_smul]
  simp only [Complex.star_def, Complex.conj_ofReal]
  norm_num
  module

theorem magnetic_overlap_cross_term {a : ℝ} (ha : a ≠ 0) (r φ : ℝ) :
    star (overlapCore a r (magneticU φ) (magneticV φ)) *
        overlapLinear a r (magneticU φ) (magneticV φ) +
      star (overlapLinear a r (magneticU φ) (magneticV φ)) *
        overlapCore a r (magneticU φ) (magneticV φ) =
      a • scalarHamiltonian a r φ := by
  rw [overlap_cross_term, magneticU_conjugates_V, magneticU_conjugates_V_star,
    ← weylEffectiveHamiltonian_eq_scalarHamiltonian]
  unfold weylEffectiveHamiltonian
  have ha' : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  simp only [RCLike.real_smul_eq_coe_smul (K := ℂ), Complex.ofReal_mul,
    Complex.ofReal_pow]
  match_scalars <;> field_simp <;> ring

def magneticCPlus (a r φ : ℝ) : MagneticOperator :=
  overlapCore a r (magneticU φ) (magneticV φ) +
    overlapLinear a r (magneticU φ) (magneticV φ)

theorem magnetic_completed_square_plus {a : ℝ} (ha : a ≠ 0) (r φ : ℝ) :
    star (magneticCPlus a r φ) * magneticCPlus a r φ =
      ((1 + a ^ 2) * (1 + r ^ 2)) • (1 : MagneticOperator) + a • scalarHamiltonian a r φ := by
  unfold magneticCPlus
  rw [completed_square_plus a r (magneticU φ) (magneticV φ)
    (magneticU_star_mul φ) (magneticV_star_mul φ) (magneticV_mul_star φ),
    magnetic_overlap_cross_term ha]

end UAMO

import UAMO.CanonicalTrace
import Mathlib.Analysis.CStarAlgebra.CStarMatrix

noncomputable section
namespace UAMO
open scoped InnerProductSpace ComplexOrder

section Amplification
variable {A : Type*} [CStarAlgebra A] [PartialOrder A] [StarOrderedRing A]

def cstarMatrixEntry (i j : Fin 2) : CStarMatrix (Fin 2) (Fin 2) A →L[ℂ] A :=
  LinearMap.mkContinuous
    { toFun := fun M => M i j
      map_add' := fun _ _ => rfl
      map_smul' := fun _ _ => rfl }
    1 (fun M => by simpa using (CStarMatrix.norm_entry_le_norm (M := M) (i := i) (j := j)))

def normalizedMatrixTrace₂ (τ : A →L[ℂ] ℂ) : CStarMatrix (Fin 2) (Fin 2) A →L[ℂ] ℂ :=
  (1 / 2 : ℂ) • (τ.comp (cstarMatrixEntry 0 0) + τ.comp (cstarMatrixEntry 1 1))

@[simp] theorem normalizedMatrixTrace₂_apply (τ : A →L[ℂ] ℂ)
    (M : CStarMatrix (Fin 2) (Fin 2) A) :
    normalizedMatrixTrace₂ τ M = (τ (M 0 0) + τ (M 1 1)) / 2 := by
  change (1 / 2 : ℂ) * (τ (M 0 0) + τ (M 1 1)) = _
  ring

theorem normalizedMatrixTrace₂_one (τ : A →L[ℂ] ℂ) (hτ : τ 1 = 1) :
    normalizedMatrixTrace₂ τ 1 = 1 := by
  simp [hτ]

theorem normalizedMatrixTrace₂_cyclic (τ : A →L[ℂ] ℂ)
    (hτ : ∀ a b : A, τ (a * b) = τ (b * a))
    (M N : CStarMatrix (Fin 2) (Fin 2) A) :
    normalizedMatrixTrace₂ τ (M * N) = normalizedMatrixTrace₂ τ (N * M) := by
  simp only [normalizedMatrixTrace₂_apply, CStarMatrix.mul_apply, Fin.sum_univ_two, map_add]
  rw [hτ (M 0 0) (N 0 0), hτ (M 0 1) (N 1 0),
    hτ (M 1 0) (N 0 1), hτ (M 1 1) (N 1 1)]
  ring

omit [PartialOrder A] [StarOrderedRing A] in
@[simp] theorem cstarMatrix_star_apply (M : CStarMatrix (Fin 2) (Fin 2) A) (i j : Fin 2) :
    (star M) i j = star (M j i) := rfl

theorem normalizedMatrixTrace₂_re (τ : A →L[ℂ] ℂ)
    (M : CStarMatrix (Fin 2) (Fin 2) A) :
    (normalizedMatrixTrace₂ τ M).re = ((τ (M 0 0)).re + (τ (M 1 1)).re) / 2 := by
  rw [normalizedMatrixTrace₂_apply]
  simp [Complex.div_re]

theorem normalizedMatrixTrace₂_star_mul_self_re (τ : A →L[ℂ] ℂ)
    (M : CStarMatrix (Fin 2) (Fin 2) A) :
    (normalizedMatrixTrace₂ τ (star M * M)).re =
      ((τ (star (M 0 0) * M 0 0)).re + (τ (star (M 1 0) * M 1 0)).re +
        (τ (star (M 0 1) * M 0 1)).re + (τ (star (M 1 1) * M 1 1)).re) / 2 := by
  rw [normalizedMatrixTrace₂_re]
  simp only [CStarMatrix.mul_apply, Fin.sum_univ_two, cstarMatrix_star_apply,
    map_add, Complex.add_re]
  ring

theorem normalizedMatrixTrace₂_nonneg (τ : A →L[ℂ] ℂ)
    (hpos : ∀ a : A, 0 ≤ (τ (star a * a)).re)
    (M : CStarMatrix (Fin 2) (Fin 2) A) :
    0 ≤ (normalizedMatrixTrace₂ τ (star M * M)).re := by
  rw [normalizedMatrixTrace₂_star_mul_self_re]
  exact div_nonneg (add_nonneg (add_nonneg (add_nonneg (hpos _) (hpos _)) (hpos _)) (hpos _))
    (by norm_num)

theorem normalizedMatrixTrace₂_faithful (τ : A →L[ℂ] ℂ)
    (hpos : ∀ a : A, 0 ≤ (τ (star a * a)).re)
    (hfaithful : ∀ a : A, (τ (star a * a)).re = 0 → a = 0)
    (M : CStarMatrix (Fin 2) (Fin 2) A)
    (hzero : (normalizedMatrixTrace₂ τ (star M * M)).re = 0) : M = 0 := by
  rw [normalizedMatrixTrace₂_star_mul_self_re] at hzero
  have h00 := hpos (M 0 0)
  have h10 := hpos (M 1 0)
  have h01 := hpos (M 0 1)
  have h11 := hpos (M 1 1)
  have hz00 : M 0 0 = 0 := hfaithful _ (by linarith)
  have hz10 : M 1 0 = 0 := hfaithful _ (by linarith)
  have hz01 : M 0 1 = 0 := hfaithful _ (by linarith)
  have hz11 : M 1 1 = 0 := hfaithful _ (by linarith)
  apply CStarMatrix.ext
  intro i j
  fin_cases i <;> fin_cases j
  all_goals first | exact hz00 | exact hz10 | exact hz01 | exact hz11

end Amplification

def magneticTrace (φ : ℝ) : magneticAlgebra φ →L[ℂ] ℂ :=
  rootTrace.comp (magneticAlgebra φ).toSubalgebra.toSubmodule.subtypeL

@[simp] theorem magneticTrace_apply (φ : ℝ) (A : magneticAlgebra φ) :
    magneticTrace φ A = rootTrace (A : MagneticOperator) := rfl

theorem magneticTrace_cyclic (φ : ℝ) (A B : magneticAlgebra φ) :
    magneticTrace φ (A * B) = magneticTrace φ (B * A) :=
  rootTrace_magneticAlgebra_cyclic φ A.property B.property

@[simp] theorem magneticTrace_one (φ : ℝ) : magneticTrace φ 1 = 1 := by
  change rootTrace (1 : MagneticOperator) = 1
  exact rootTrace_one

instance magneticAlgebra_partialOrder (φ : ℝ) : PartialOrder (magneticAlgebra φ) :=
  CStarAlgebra.spectralOrder _

instance magneticAlgebra_starOrderedRing (φ : ℝ) : StarOrderedRing (magneticAlgebra φ) :=
  CStarAlgebra.spectralOrderedRing _

theorem magneticTrace_star (φ : ℝ) (A : magneticAlgebra φ) :
    magneticTrace φ (star A) = star (magneticTrace φ A) := by
  rw [magneticTrace_apply, magneticTrace_apply, rootTrace_eq_inner, rootTrace_eq_inner]
  change ⟪magneticOrigin, star (A : MagneticOperator) magneticOrigin⟫_ℂ =
    star (⟪magneticOrigin, (A : MagneticOperator) magneticOrigin⟫_ℂ)
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  exact (inner_conj_symm _ _).symm

abbrev MagneticMatrixAlgebra (φ : ℝ) := CStarMatrix (Fin 2) (Fin 2) (magneticAlgebra φ)

def magneticMatrixTrace (φ : ℝ) : MagneticMatrixAlgebra φ →L[ℂ] ℂ :=
  normalizedMatrixTrace₂ (magneticTrace φ)

@[simp] theorem magneticMatrixTrace_apply (φ : ℝ) (M : MagneticMatrixAlgebra φ) :
    magneticMatrixTrace φ M = (magneticTrace φ (M 0 0) + magneticTrace φ (M 1 1)) / 2 :=
  normalizedMatrixTrace₂_apply _ _

@[simp] theorem magneticMatrixTrace_one (φ : ℝ) : magneticMatrixTrace φ 1 = 1 :=
  normalizedMatrixTrace₂_one _ (magneticTrace_one φ)

theorem magneticMatrixTrace_cyclic (φ : ℝ) (M N : MagneticMatrixAlgebra φ) :
    magneticMatrixTrace φ (M * N) = magneticMatrixTrace φ (N * M) :=
  normalizedMatrixTrace₂_cyclic _ (magneticTrace_cyclic φ) M N

instance magneticMatrixAlgebra_realNormedAlgebra (φ : ℝ) :
    NormedAlgebra ℝ (MagneticMatrixAlgebra φ) :=
  NormedAlgebra.restrictScalars ℝ ℂ (MagneticMatrixAlgebra φ)

local instance (φ : ℝ) : NormedSpace ℝ (MagneticMatrixAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (MagneticMatrixAlgebra φ)

def magneticMatrixTraceReal (φ : ℝ) : MagneticMatrixAlgebra φ →L[ℝ] ℝ :=
  Complex.reCLM.comp ((magneticMatrixTrace φ).restrictScalars ℝ)

@[simp] theorem magneticMatrixTraceReal_apply (φ : ℝ) (M : MagneticMatrixAlgebra φ) :
    magneticMatrixTraceReal φ M = (magneticMatrixTrace φ M).re := rfl

@[simp] theorem magneticMatrixTraceReal_one (φ : ℝ) : magneticMatrixTraceReal φ 1 = 1 := by
  rw [magneticMatrixTraceReal_apply, magneticMatrixTrace_one]
  rfl

theorem magneticMatrixTraceReal_cyclic (φ : ℝ) (M N : MagneticMatrixAlgebra φ) :
    magneticMatrixTraceReal φ (M * N) = magneticMatrixTraceReal φ (N * M) :=
  congrArg Complex.re (magneticMatrixTrace_cyclic φ M N)

theorem magneticMatrixTraceReal_star_mul_self_nonneg (φ : ℝ) (M : MagneticMatrixAlgebra φ) :
    0 ≤ magneticMatrixTraceReal φ (star M * M) :=
  normalizedMatrixTrace₂_nonneg _ (magneticTraceReal_star_mul_self_nonneg φ) M

theorem magneticMatrixTraceReal_faithful (φ : ℝ) (M : MagneticMatrixAlgebra φ)
    (h : magneticMatrixTraceReal φ (star M * M) = 0) : M = 0 :=
  normalizedMatrixTrace₂_faithful _ (magneticTraceReal_star_mul_self_nonneg φ)
    (magneticTraceReal_faithful φ) M h

theorem magneticMatrixTrace_star (φ : ℝ) (M : MagneticMatrixAlgebra φ) :
    magneticMatrixTrace φ (star M) = star (magneticMatrixTrace φ M) := by
  simp only [magneticMatrixTrace_apply, cstarMatrix_star_apply, magneticTrace_star,
    star_div₀, star_add, star_ofNat]

end UAMO

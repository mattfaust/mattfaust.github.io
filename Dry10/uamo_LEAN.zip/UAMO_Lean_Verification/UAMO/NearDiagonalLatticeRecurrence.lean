import UAMO.NearDiagonalRecurrence

noncomputable section
namespace UAMO.PhysicalRepresentation
open Matrix

def scalarSignedDiagonal (s δ : ℝ) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![((s*(1+δ):ℝ):ℂ),0;0,((s*(1-δ):ℝ):ℂ)]

theorem signedDiagonalCoefficient_entry (s δ : ℝ) (i j : Fin 2) :
    signedDiagonalCoefficient s δ i j=scalarSignedDiagonal s δ i j • (1:Operator) := by
  fin_cases i <;> fin_cases j <;> simp [signedDiagonalCoefficient,scalarSignedDiagonal]

theorem near_signed_diagonal_lattice_recurrence_isUnit
    (A : ℤ→Matrix (Fin 2) (Fin 2) ℂ) (B : PhysicalWalk.TwoByTwo Operator)
    (hB : ∀i j (ψ : Hilbert) n,B i j ψ n=A n i j*ψ n)
    {s δ : ℝ} (hs : |s|=1) (hδ : 0<δ) (hδ1 : δ≤1)
    (herror : ∀n i j,‖A n i j-scalarSignedDiagonal s δ i j‖≤δ/16) :
    IsUnit (Matrix.diagonal (fun _ : Fin 2 => star shift)-B) := by
  apply near_signed_diagonal_bilateral_recurrence_isUnit B hs hδ hδ1
  intro i j
  let c := fun n => A n i j-scalarSignedDiagonal s δ i j
  have hc : ∀n,‖c n‖≤δ/16 := fun n => herror n i j
  have heq : B i j-signedDiagonalCoefficient s δ i j=
      latticeMultiplier c (δ/16) (by positivity) hc := by
    rw [signedDiagonalCoefficient_entry]
    ext ψ n
    simp only [ContinuousLinearMap.sub_apply,lp.coeFn_sub,Pi.sub_apply,
      ContinuousLinearMap.smul_apply,lp.coeFn_smul,Pi.smul_apply,smul_eq_mul,
      ContinuousLinearMap.one_apply,latticeMultiplier_apply,hB,c]
    ring
  rw [heq]
  exact latticeMultiplier_norm_le c (δ/16) (by positivity) hc

end UAMO.PhysicalRepresentation

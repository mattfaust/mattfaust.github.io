import UAMO.UnitaryRecurrenceInverse
import UAMO.PhysicalPhaseSpectrum

noncomputable section
namespace UAMO.PhysicalRepresentation
open Matrix
open scoped WithCStarModule

theorem operatorMatrix_norm_le_sum (M : CStarMatrix (Fin 2) (Fin 2) Operator) :
    ‖M‖≤∑j : Fin 2,∑i : Fin 2,‖M i j‖ := by
  rw [CStarMatrix.norm_def]
  refine (CStarMatrix.toCLM M).opNorm_le_bound (by positivity) fun v => ?_
  simp only [CStarMatrix.toCLM_apply_eq_sum,WithCStarModule.equiv_symm_pi_apply,
    Finset.sum_mul]
  apply WithCStarModule.pi_norm_le_sum_norm _ |>.trans
  gcongr with j _
  change ‖∑i : Fin 2,v i*M i j‖≤∑i : Fin 2,‖M i j‖*‖v‖
  apply norm_sum_le _ _ |>.trans
  gcongr with i _
  apply norm_mul_le _ _ |>.trans
  rw [mul_comm]
  gcongr
  exact WithCStarModule.norm_apply_le_norm v i

def signedDiagonalCoefficient (s δ : ℝ) : PhysicalWalk.TwoByTwo Operator :=
  !![((s*(1+δ):ℝ):ℂ) • (1:Operator),0;
    0,((s*(1-δ):ℝ):ℂ) • (1:Operator)]

set_option maxHeartbeats 800000 in

theorem near_signed_diagonal_recurrence_isUnit
    (S : Operator) (hS : S∈unitary Operator)
    (B : PhysicalWalk.TwoByTwo Operator) {s δ : ℝ}
    (hs : |s|=1) (hδ : 0<δ) (hδ1 : δ≤1)
    (herror : ∀i j,‖B i j-signedDiagonalCoefficient s δ i j‖≤δ/16) :
    IsUnit (Matrix.diagonal (fun _ : Fin 2 => S)-B) := by
  obtain ⟨Rp,Rm,hpR,hRp,hmR,hRm,hpbound,hmbound⟩ :=
    signed_diagonal_recurrence_inverses S hS hs hδ hδ1
  push_cast at hpR hRp hmR hRm
  let D₀ : PhysicalWalk.TwoByTwo Operator :=
    !![S-((s*(1+δ):ℝ):ℂ) • (1:Operator),0;
      0,S-((s*(1-δ):ℝ):ℂ) • (1:Operator)]
  let R : PhysicalWalk.TwoByTwo Operator := !![Rp,0;0,Rm]
  let D := Matrix.diagonal (fun _ : Fin 2 => S)-B
  have hDR : D₀*R=1 := by
    apply Matrix.ext
    intro i j
    fin_cases i <;> fin_cases j <;>
      simp [D₀,R,Matrix.mul_apply,Fin.sum_univ_two,hpR,hmR]
  have hRD : R*D₀=1 := by
    apply Matrix.ext
    intro i j
    fin_cases i <;> fin_cases j <;>
      simp [D₀,R,Matrix.mul_apply,Fin.sum_univ_two,hRp,hRm]
  have hD₀ : D₀=Matrix.diagonal (fun _ : Fin 2 => S)-signedDiagonalCoefficient s δ := by
    apply Matrix.ext
    intro i j
    fin_cases i <;> fin_cases j <;> simp [D₀,signedDiagonalCoefficient]
  let e : PhysicalWalk.TwoByTwo Operator ≃⋆ₐ[ℂ]
      CStarMatrix (Fin 2) (Fin 2) Operator := CStarMatrix.ofMatrixStarAlgEquiv
  have hnormR : ‖e R‖≤2*δ⁻¹ := by
    have h := operatorMatrix_norm_le_sum (e R)
    simp only [Fin.sum_univ_two] at h
    change ‖e R‖≤‖Rp‖+‖(0:Operator)‖+(‖(0:Operator)‖+‖Rm‖) at h
    simp only [norm_zero,add_zero,zero_add] at h
    linarith
  have hnormE : ‖e (D-D₀)‖≤δ/4 := by
    have he (i j : Fin 2) : ‖(e (D-D₀)) i j‖≤δ/16 := by
      change ‖(D-D₀) i j‖≤δ/16
      rw [hD₀]
      change ‖((Matrix.diagonal (fun _ : Fin 2 => S)-B)-
        (Matrix.diagonal (fun _ : Fin 2 => S)-signedDiagonalCoefficient s δ)) i j‖≤δ/16
      rw [sub_sub_sub_cancel_left]
      simpa only [Matrix.sub_apply,norm_sub_rev] using herror i j
    have h := operatorMatrix_norm_le_sum (e (D-D₀))
    simp only [Fin.sum_univ_two] at h
    linarith [he 0 0,he 0 1,he 1 0,he 1 1]
  have hsmall : ‖e R*e (D-D₀)‖<1 := by
    calc
      _ ≤ ‖e R‖*‖e (D-D₀)‖ := norm_mul_le _ _
      _ ≤ (2*δ⁻¹)*(δ/4) := mul_le_mul hnormR hnormE (norm_nonneg _) (by positivity)
      _ = 1/2 := by field_simp; norm_num
      _ < 1 := by norm_num
  have hu : IsUnit (1+e R*e (D-D₀)) := by
    simpa only [sub_neg_eq_add] using
      (isUnit_one_sub_of_norm_lt_one (show ‖-(e R*e (D-D₀))‖<1 by simpa using hsmall))
  have hu₀ : IsUnit (e D₀) :=
    (show IsUnit D₀ from ⟨⟨D₀,R,hDR,hRD⟩,rfl⟩).map e.toMonoidHom
  have hprod : e D₀*e R=1 := by
    change CStarMatrix.ofMatrix (D₀*R)=CStarMatrix.ofMatrix 1
    exact congrArg CStarMatrix.ofMatrix hDR
  have heq : e D₀*(1+e R*e (D-D₀))=e D := by
    rw [mul_add,mul_one,← mul_assoc,hprod,one_mul]
    change CStarMatrix.ofMatrix (D₀+(D-D₀))=CStarMatrix.ofMatrix D
    congr 1
    abel
  have hunit := hu₀.mul hu
  rw [heq] at hunit
  have hback : IsUnit (e.symm (e D)) := hunit.map e.symm.toMonoidHom
  simpa only [e.symm_apply_apply] using hback

theorem near_signed_diagonal_bilateral_recurrence_isUnit
    (B : PhysicalWalk.TwoByTwo Operator) {s δ : ℝ}
    (hs : |s|=1) (hδ : 0<δ) (hδ1 : δ≤1)
    (herror : ∀i j,‖B i j-signedDiagonalCoefficient s δ i j‖≤δ/16) :
    IsUnit (Matrix.diagonal (fun _ : Fin 2 => star shift)-B) :=
  near_signed_diagonal_recurrence_isUnit (star shift)
    (unitary.star_mem shift_unitary) B hs hδ hδ1 herror

end UAMO.PhysicalRepresentation

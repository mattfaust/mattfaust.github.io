import UAMO.PhysicalWalk
import UAMO.MagneticWeyl
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.CStarAlgebra.Basic
import Mathlib.Algebra.GroupWithZero.Commute

noncomputable section
namespace UAMO.OverlapGauge

section Algebra
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

def denominator (r : ℝ) (V : A) : A := 1 + (r : ℂ) • star V

def numerator (r : ℝ) (V : A) : A := 1 + (r : ℂ) • V

@[simp] theorem denominator_star (r : ℝ) (V : A) :
    star (denominator r V) = numerator r V := by
  simp [denominator, numerator, star_add, star_smul]

omit [StarRing A] [Algebra ℂ A] [StarModule ℂ A] in
theorem commute_inverse_of_isUnit (X B : A) (h : Commute X B) (hB : IsUnit B) :
    Commute X (Ring.inverse B) := by
  rcases hB with ⟨u, rfl⟩
  simpa only [Ring.inverse_unit] using h.units_inv_right

omit [Algebra ℂ A] [StarModule ℂ A] in

theorem normal_ratio_unitary (B : A) (hB : IsUnit B) (hn : Commute B (star B)) :
    star B * Ring.inverse B ∈ unitary A := by
  have hBs : IsUnit (star B) := hB.star
  apply unitary.mem_iff.mpr
  simp only [star_mul, star_star, ← Ring.inverse_star]
  constructor
  · calc
      Ring.inverse (star B) * B * (star B * Ring.inverse B) =
          Ring.inverse (star B) * (B * star B) * Ring.inverse B := by noncomm_ring
      _ = Ring.inverse (star B) * (star B * B) * Ring.inverse B := by rw [hn.eq]
      _ = (Ring.inverse (star B) * star B) * (B * Ring.inverse B) := by noncomm_ring
      _ = 1 := by rw [Ring.inverse_mul_cancel _ hBs, Ring.mul_inverse_cancel _ hB, one_mul]
  · calc
      star B * Ring.inverse B * (Ring.inverse (star B) * B) =
          star B * (Ring.inverse B * Ring.inverse (star B)) * B := by noncomm_ring
      _ = star B * (Ring.inverse (star B) * Ring.inverse B) * B := by
        rw [hn.ringInverse_ringInverse.eq]
      _ = (star B * Ring.inverse (star B)) * (Ring.inverse B * B) := by noncomm_ring
      _ = 1 := by rw [Ring.mul_inverse_cancel _ hBs, Ring.inverse_mul_cancel _ hB, one_mul]

omit [Algebra ℂ A] [StarModule ℂ A] in
theorem unitary_commute_star (V : A) (hV : V ∈ unitary A) : Commute V (star V) := by
  change V * star V = star V * V
  rw [unitary.mul_star_self_of_mem hV, unitary.star_mul_self_of_mem hV]

theorem denominator_normal (r : ℝ) (V : A) (hV : V ∈ unitary A) :
    Commute (denominator r V) (star (denominator r V)) := by
  rw [denominator_star]
  have hc : Commute (star V) V := (unitary_commute_star V hV).symm
  exact ((Commute.one_left (numerator r V)).add_left
    (((Commute.one_right (star V)).add_right (hc.smul_right (r : ℂ))).smul_left (r : ℂ)))

def omega (r : ℝ) (V : A) : A := by
  classical
  exact if r = 1 then V else numerator r V * Ring.inverse (denominator r V)

omit [StarModule ℂ A] in
@[simp] theorem omega_one (V : A) : omega 1 V = V := by simp [omega]

omit [StarModule ℂ A] in
theorem omega_of_ne_one {r : ℝ} (hr : r ≠ 1) (V : A) :
    omega r V = numerator r V * Ring.inverse (denominator r V) := by
  simp [omega, hr]

omit [StarModule ℂ A] in

theorem omega_denominator (r : ℝ) (V : A) (hV : V ∈ unitary A)
    (hInv : r ≠ 1 → IsUnit (denominator r V)) :
    omega r V * denominator r V = numerator r V := by
  by_cases hr : r = 1
  · subst r
    simp [denominator, numerator, mul_add, unitary.mul_star_self_of_mem hV, add_comm]
  · rw [omega_of_ne_one hr, mul_assoc, Ring.inverse_mul_cancel _ (hInv hr), mul_one]

theorem omega_unitary (r : ℝ) (V : A) (hV : V ∈ unitary A)
    (hInv : r ≠ 1 → IsUnit (denominator r V)) : omega r V ∈ unitary A := by
  by_cases hr : r = 1
  · subst r
    simpa only [omega_one] using hV
  · rw [omega_of_ne_one hr, ← denominator_star]
    exact normal_ratio_unitary _ (hInv hr) (denominator_normal r V hV)

omit [StarModule ℂ A] in
theorem omega_commute (r : ℝ) (V : A) (hV : V ∈ unitary A)
    (hInv : r ≠ 1 → IsUnit (denominator r V)) : Commute (omega r V) V := by
  by_cases hr : r = 1
  · subst r
    simpa only [omega_one] using Commute.refl V
  · rw [omega_of_ne_one hr]
    have hnum : Commute V (numerator r V) :=
      (Commute.one_right V).add_right ((Commute.refl V).smul_right (r : ℂ))
    have hden : Commute V (denominator r V) :=
      (Commute.one_right V).add_right ((unitary_commute_star V hV).smul_right (r : ℂ))
    exact (hnum.mul_right (commute_inverse_of_isUnit V _ hden (hInv hr))).symm

omit [StarModule ℂ A] in

theorem omega_weyl (r : ℝ) (U V : A) (ξ : ℂ)
    (hV : V ∈ unitary A) (hInv : r ≠ 1 → IsUnit (denominator r V))
    (hW : U * V = ξ • (V * U)) :
    (omega r V * U) * V = ξ • (V * (omega r V * U)) := by
  calc
    (omega r V * U) * V = omega r V * (U * V) := mul_assoc _ _ _
    _ = ξ • (omega r V * (V * U)) := by rw [hW, mul_smul_comm]
    _ = ξ • (V * (omega r V * U)) := by
      rw [← mul_assoc, (omega_commute r V hV hInv).eq, mul_assoc]

def completedPlus (a r : ℝ) (U V : A) : A :=
  1 - ((a*r : ℝ) : ℂ) • (V*U) + ((a : ℂ) • U + (r : ℂ) • star V)

omit [StarModule ℂ A] in
theorem completedPlus_factor (a r : ℝ) (U V : A) :
    completedPlus a r U V = denominator r V +
      (a : ℂ) • ((1-(r : ℂ) • V)*U) := by
  simp only [completedPlus, denominator, sub_mul, one_mul, smul_sub,
    smul_mul_assoc, smul_smul, Complex.ofReal_mul]
  module

omit [StarModule ℂ A] in

theorem overlap_after_gauge (a r : ℝ) (U V : A)
    (hV : V ∈ unitary A) (hInv : r ≠ 1 → IsUnit (denominator r V)) :
    PhysicalWalk.overlapPolynomial a r (omega r V * U) V =
      (-Complex.I) • (omega r V * completedPlus a r U V) := by
  have hc := (omega_commute r V hV hInv).eq
  rw [completedPlus_factor, mul_add, omega_denominator r V hV hInv]
  simp only [PhysicalWalk.overlapPolynomial, numerator, mul_smul_comm,
    sub_mul, mul_sub, one_mul, mul_one, smul_sub, smul_mul_assoc, smul_smul,
    Complex.ofReal_mul]
  rw [← mul_assoc (omega r V) V U, hc, mul_assoc]
  module

theorem overlap_square_after_gauge (a r : ℝ) (U V : A)
    (hV : V ∈ unitary A) (hInv : r ≠ 1 → IsUnit (denominator r V)) :
    star (PhysicalWalk.overlapPolynomial a r (omega r V * U) V) *
        PhysicalWalk.overlapPolynomial a r (omega r V * U) V =
      star (completedPlus a r U V) * completedPlus a r U V := by
  rw [overlap_after_gauge a r U V hV hInv]
  have hu := unitary.star_mul_self_of_mem (omega_unitary r V hV hInv)
  simp only [star_smul, star_mul, smul_mul_assoc, mul_smul_comm, smul_smul,
    Complex.star_def, map_neg, Complex.conj_I, neg_neg, mul_neg, neg_mul, Complex.I_mul_I,
    neg_neg, one_smul]
  calc
    star (completedPlus a r U V) * star (omega r V) * (omega r V * completedPlus a r U V) =
      star (completedPlus a r U V) * (star (omega r V) * omega r V) *
        completedPlus a r U V := by noncomm_ring
    _ = _ := by rw [hu, mul_one]

end Algebra

section Normed
variable {A : Type*} [NormedRing A] [StarRing A] [CStarRing A]
  [NormedAlgebra ℂ A] [StarModule ℂ A] [CompleteSpace A]

omit [StarModule ℂ A] in

theorem denominator_isUnit {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r < 1)
    (V : A) (hV : V ∈ unitary A) : IsUnit (denominator r V) := by
  nontriviality A
  have hn : ‖-((r : ℂ) • star V)‖ < 1 := by
    rw [norm_neg, norm_smul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg hr0, norm_star, CStarRing.norm_of_mem_unitary hV, mul_one]
    exact hr1
  simpa only [sub_neg_eq_add, denominator] using isUnit_one_sub_of_norm_lt_one hn

theorem omega_unitary_closed {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (V : A) (hV : V ∈ unitary A) : omega r V ∈ unitary A :=
  omega_unitary r V hV (fun hne => denominator_isUnit hr0 (lt_of_le_of_ne hr1 hne) V hV)

omit [StarModule ℂ A] in

theorem denominator_inverse_series [Nontrivial A] {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r < 1)
    (V : A) (hV : V ∈ unitary A) :
    HasSum (fun n : ℕ => (-((r : ℂ) • star V)) ^ n)
      (Ring.inverse (denominator r V)) := by
  nontriviality A
  have hn : ‖-((r : ℂ) • star V)‖ < 1 := by
    rw [norm_neg, norm_smul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg hr0, norm_star, CStarRing.norm_of_mem_unitary hV, mul_one]
    exact hr1
  simpa only [sub_neg_eq_add, denominator] using hasSum_geom_series_inverse _ hn

end Normed

theorem magneticV_unitary (φ : ℝ) : magneticV φ ∈ unitary MagneticOperator :=
  unitary.mem_iff.mpr ⟨magneticV_star_mul φ, magneticV_mul_star φ⟩

theorem magneticU_unitary (φ : ℝ) : magneticU φ ∈ unitary MagneticOperator :=
  unitary.mem_iff.mpr ⟨magneticU_star_mul φ, magneticU_mul_star φ⟩

def magneticOmega (r φ : ℝ) : MagneticOperator := omega r (magneticV φ)

theorem magneticOmega_unitary {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    magneticOmega r φ ∈ unitary MagneticOperator :=
  omega_unitary_closed hr0 hr1 _ (magneticV_unitary φ)

theorem magneticOmega_weyl {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    (magneticOmega r φ * magneticU φ) * magneticV φ =
      latticePhase φ 2 • (magneticV φ * (magneticOmega r φ * magneticU φ)) :=
  omega_weyl r _ _ _ (magneticV_unitary φ)
    (fun hne => denominator_isUnit hr0 (lt_of_le_of_ne hr1 hne) _ (magneticV_unitary φ))
    (magneticU_mul_V φ)

theorem completedPlus_eq_magneticCPlus (a r φ : ℝ) :
    completedPlus a r (magneticU φ) (magneticV φ) = magneticCPlus a r φ := by
  simp only [completedPlus, magneticCPlus, overlapCore, overlapLinear,
    RCLike.real_smul_eq_coe_smul (K := ℂ)]
  rfl

theorem magnetic_transformed_overlap_square {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    star (PhysicalWalk.overlapPolynomial a r
        (magneticOmega r φ * magneticU φ) (magneticV φ)) *
      PhysicalWalk.overlapPolynomial a r
        (magneticOmega r φ * magneticU φ) (magneticV φ) =
      ((1+a^2)*(1+r^2)) • (1 : MagneticOperator) + a • scalarHamiltonian a r φ := by
  rw [magneticOmega, overlap_square_after_gauge a r _ _ (magneticV_unitary φ)
    (fun hne => denominator_isUnit hr0 (lt_of_le_of_ne hr1 hne) _ (magneticV_unitary φ)),
    completedPlus_eq_magneticCPlus, magnetic_completed_square_plus ha]

end UAMO.OverlapGauge

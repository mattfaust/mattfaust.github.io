import UAMO.OverlapGaugeDegree

noncomputable section
namespace UAMO.OverlapGauge
open scoped InnerProductSpace
open Submodule

theorem unitary_zpow_hasDegree (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) (m : ℤ) :
    HasDegree (-m) ((W^m : unitary MagneticOperator) : MagneticOperator) := by
  induction m using Int.induction_on with
  | hz => simpa using hasDegree_one
  | hp n ih =>
      rw [zpow_add_one, Submonoid.coe_mul]
      convert ih.mul hW using 1
      omega
  | hn n ih =>
      rw [zpow_sub_one, Submonoid.coe_mul]
      have hi : HasDegree 1 ((W⁻¹ : unitary MagneticOperator) : MagneticOperator) := by
        simpa only [← unitary.star_eq_inv, unitary.coe_star, neg_neg] using hW.star
      convert ih.mul hi using 1
      omega

def fibreBasis (W : unitary MagneticOperator) (mn : ℤ×ℤ) : MagneticSpace :=
  ((W^mn.1 : unitary MagneticOperator) : MagneticOperator) (lp.single 2 (mn.2,mn.2) 1)

theorem fibreBasis_degree (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) (mn : ℤ×ℤ) :
    fibreBasis W mn ∈ degreeSpace (-mn.1) := by
  have h := unitary_zpow_hasDegree W hW mn.1 0 (lp.single 2 (mn.2,mn.2) 1)
    (by simpa using single_mem_degreeSpace (mn.2,mn.2) 1)
  simpa [fibreBasis] using h

theorem unitary_inner_map (W : unitary MagneticOperator) (u v : MagneticSpace) :
    ⟪(W : MagneticOperator) u, (W : MagneticOperator) v⟫_ℂ = ⟪u,v⟫_ℂ :=
  (unitary.linearIsometryEquiv W).inner_map_map u v

theorem fibreBasis_orthonormal (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) : Orthonormal ℂ (fibreBasis W) := by
  rw [orthonormal_iff_ite]
  rintro ⟨m,n⟩ ⟨p,q⟩
  by_cases h : m = p
  · subst p
    rw [fibreBasis, fibreBasis, unitary_inner_map, lp.inner_single_left]
    simp [lp.single_apply, Pi.single_apply]
  · rw [degreeSpace_inner_zero (by simpa using h)
      (fibreBasis_degree W hW (m,n)) (fibreBasis_degree W hW (p,q))]
    simp [h]

theorem fibreBasis_orthogonal_eq_bot (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) :
    (span ℂ (Set.range (fibreBasis W)))ᗮ = ⊥ := by
  apply eq_bot_iff.mpr
  intro x hx
  change x = 0
  apply lp.ext
  funext s
  let m : ℤ := -latticeDegree s
  let T : unitary MagneticOperator := W^m
  have hdiag (n : ℤ) : (star (T : MagneticOperator) x) (n,n) = 0 := by
    have hi := (span ℂ (Set.range (fibreBasis W))).inner_right_of_mem_orthogonal
      (subset_span (Set.mem_range_self (m,n))) hx
    change ⟪(T : MagneticOperator) (lp.single 2 (n,n) 1),x⟫_ℂ = 0 at hi
    rw [← ContinuousLinearMap.adjoint_inner_right, lp.inner_single_left] at hi
    simpa using hi
  have hz : star (T : MagneticOperator) (lp.single 2 s 1) ∈ degreeSpace 0 := by
    have hd := (unitary_zpow_hasDegree W hW m).star (latticeDegree s)
      (lp.single 2 s 1) (single_mem_degreeSpace s 1)
    have he : latticeDegree s + -(-m) = 0 := by dsimp [m]; omega
    rw [he] at hd
    exact hd
  have hip : ⟪star (T : MagneticOperator) (lp.single 2 s 1),
      star (T : MagneticOperator) x⟫_ℂ = 0 := by
    rw [lp.inner_eq_tsum]
    trans ∑' t : MagneticSite, (0 : ℂ)
    · apply tsum_congr
      intro t
      by_cases ht : latticeDegree t = 0
      · have he : t = (t.2,t.2) := Prod.ext (by dsimp [latticeDegree] at ht; omega) rfl
        rw [he, hdiag, inner_zero_right]
      · rw [hz t ht, inner_zero_left]
    · simp
  have hi := unitary_inner_map (star T) (lp.single 2 s 1) x
  simp only [unitary.coe_star] at hi
  rw [hi, lp.inner_single_left] at hip
  simpa using hip

def fibreHilbertBasis (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) : HilbertBasis (ℤ×ℤ) ℂ MagneticSpace :=
  HilbertBasis.mkOfOrthogonalEqBot (fibreBasis_orthonormal W hW)
    (fibreBasis_orthogonal_eq_bot W hW)

@[simp] theorem fibreHilbertBasis_apply (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) (mn : ℤ×ℤ) :
    fibreHilbertBasis W hW mn = fibreBasis W mn := by
  simp [fibreHilbertBasis]

end UAMO.OverlapGauge

import UAMO.OverlapGauge

noncomputable section
namespace UAMO.OverlapGauge
open scoped InnerProductSpace

abbrev latticeDegree (s : MagneticSite) : ℤ := s.1-s.2

def degreeSpace (d : ℤ) : Submodule ℂ MagneticSpace where
  carrier := {u | ∀ s, latticeDegree s ≠ d → u s = 0}
  zero_mem' := by simp
  add_mem' := by intro u v hu hv s hs; simp [hu s hs, hv s hs]
  smul_mem' := by intro c u hu s hs; simp [hu s hs]

theorem degreeSpace_closed (d : ℤ) : IsClosed (degreeSpace d : Set MagneticSpace) := by
  have hc (s : MagneticSite) : Continuous (fun u : MagneticSpace => u s) :=
    (continuous_apply s).comp lp.uniformContinuous_coe.continuous
  change IsClosed {u : MagneticSpace | ∀ s, latticeDegree s ≠ d → u s = 0}
  simp only [Set.setOf_forall]
  exact isClosed_iInter fun s => isClosed_iInter fun _ => isClosed_eq (hc s) continuous_const

theorem single_mem_degreeSpace (s : MagneticSite) (c : ℂ) :
    lp.single 2 s c ∈ degreeSpace (latticeDegree s) := by
  intro t ht
  exact lp.single_apply_ne (E := fun _ : MagneticSite => ℂ) 2 s c (fun h => ht (congrArg latticeDegree h))

theorem degreeSpace_inner_zero {d e : ℤ} (hne : d ≠ e)
    {u v : MagneticSpace} (hu : u ∈ degreeSpace d) (hv : v ∈ degreeSpace e) :
    ⟪u,v⟫_ℂ = 0 := by
  rw [lp.inner_eq_tsum]
  trans ∑' s : MagneticSite, (0 : ℂ)
  · apply tsum_congr
    intro s
    by_cases hd : latticeDegree s = d
    · rw [hv s (by omega), inner_zero_right]
    · rw [hu s hd, inner_zero_left]
  · simp

def HasDegree (δ : ℤ) (T : MagneticOperator) : Prop :=
  ∀ d u, u ∈ degreeSpace d → T u ∈ degreeSpace (d+δ)

theorem hasDegree_one : HasDegree 0 (1 : MagneticOperator) := by
  intro d u hu
  simpa using hu

theorem HasDegree.add {δ : ℤ} {A B : MagneticOperator}
    (hA : HasDegree δ A) (hB : HasDegree δ B) : HasDegree δ (A+B) := by
  intro d u hu
  exact (degreeSpace (d+δ)).add_mem (hA d u hu) (hB d u hu)

theorem HasDegree.smul {δ : ℤ} {A : MagneticOperator} (hA : HasDegree δ A) (c : ℂ) :
    HasDegree δ (c • A) := by
  intro d u hu
  exact (degreeSpace (d+δ)).smul_mem c (hA d u hu)

theorem HasDegree.mul {δ ε : ℤ} {A B : MagneticOperator}
    (hA : HasDegree δ A) (hB : HasDegree ε B) : HasDegree (δ+ε) (A*B) := by
  intro d u hu
  simpa [add_assoc, add_comm δ ε] using hA (d+ε) (B u) (hB d u hu)

theorem HasDegree.pow_zero {A : MagneticOperator} (hA : HasDegree 0 A) (n : ℕ) :
    HasDegree 0 (A^n) := by
  induction n with
  | zero => simpa using hasDegree_one
  | succ n ih => simpa [pow_succ] using ih.mul hA

theorem HasDegree.star {δ : ℤ} {A : MagneticOperator} (hA : HasDegree δ A) :
    HasDegree (-δ) (star A) := by
  intro d u hu s hs
  have horth : ⟪A (lp.single 2 s (1 : ℂ)),u⟫_ℂ = 0 :=
    degreeSpace_inner_zero (by omega)
      (hA _ _ (single_mem_degreeSpace s 1)) hu
  rw [← ContinuousLinearMap.adjoint_inner_right, lp.inner_single_left] at horth
  simpa using horth

theorem hasDegree_isClosed (δ : ℤ) : IsClosed {T : MagneticOperator | HasDegree δ T} := by
  simp only [HasDegree, Set.setOf_forall]
  exact isClosed_iInter fun d => isClosed_iInter fun u => isClosed_iInter fun _ =>
    (degreeSpace_closed (d+δ)).preimage (ContinuousLinearMap.apply ℂ MagneticSpace u : MagneticOperator →L[ℂ] MagneticSpace).continuous

theorem HasDegree.hasSum {δ : ℤ} {f : ℕ → MagneticOperator} {T : MagneticOperator}
    (hf : ∀ n, HasDegree δ (f n)) (hs : HasSum f T) : HasDegree δ T := by
  apply (hasDegree_isClosed δ).mem_of_tendsto hs
  filter_upwards [] with s
  classical
  induction s using Finset.induction_on with
  | empty =>
      intro d u hu t ht
      simp
  | @insert a s ha ih =>
      simpa [Finset.sum_insert ha] using (hf a).add ih

theorem magneticShift_hasDegree (φ : ℝ) (ν : MagneticSite) :
    HasDegree (latticeDegree ν) (magneticShift φ ν) := by
  intro d u hu s hs
  rw [magneticShift_apply, hu (s-ν) (by simp only [latticeDegree, Prod.fst_sub, Prod.snd_sub] at *; omega)]
  simp

theorem magneticU_hasDegree (φ : ℝ) : HasDegree (-1) (magneticU φ) := by
  simpa [magneticU] using magneticShift_hasDegree φ (-1,0)

theorem magneticV_hasDegree (φ : ℝ) : HasDegree 0 (magneticV φ) := by
  simpa [magneticV] using (magneticShift_hasDegree φ (1,1)).smul (latticePhase φ 1)

theorem magneticOmega_hasDegree {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    HasDegree 0 (magneticOmega r φ) := by
  haveI : Nontrivial MagneticSpace := ⟨⟨magneticOrigin,0, by
    intro h; have hn := magneticOrigin_norm; rw [h, norm_zero] at hn; norm_num at hn⟩⟩
  haveI : Nontrivial MagneticOperator := inferInstance
  by_cases h1 : r = 1
  · subst r
    simpa [magneticOmega] using magneticV_hasDegree φ
  · rw [magneticOmega, omega_of_ne_one h1]
    have hnum : HasDegree 0 (numerator r (magneticV φ)) :=
      hasDegree_one.add ((magneticV_hasDegree φ).smul (r : ℂ))
    have hterm : HasDegree 0 (-((r : ℂ) • star (magneticV φ))) := by
      simpa using ((magneticV_hasDegree φ).star.smul (-(r : ℂ)))
    have hinv : HasDegree 0 (Ring.inverse (denominator r (magneticV φ))) :=
      HasDegree.hasSum (fun n => hterm.pow_zero n)
        (denominator_inverse_series hr0 (lt_of_le_of_ne hr1 h1) _ (magneticV_unitary φ))
    simpa using hnum.mul hinv

end UAMO.OverlapGauge

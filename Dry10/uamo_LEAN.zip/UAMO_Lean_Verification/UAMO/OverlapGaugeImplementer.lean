import UAMO.OverlapGaugeBasis

noncomputable section
namespace UAMO.OverlapGauge
open scoped InnerProductSpace

abbrev magneticUUnitary (φ : ℝ) : unitary MagneticOperator :=
  ⟨magneticU φ, magneticU_unitary φ⟩

def gaugedUUnitary {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    unitary MagneticOperator :=
  ⟨magneticOmega r φ * magneticU φ,
    (unitary MagneticOperator).mul_mem (magneticOmega_unitary hr0 hr1 φ)
      (magneticU_unitary φ)⟩

theorem gaugedU_hasDegree {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    HasDegree (-1) (gaugedUUnitary hr0 hr1 φ : MagneticOperator) := by
  simpa [gaugedUUnitary] using (magneticOmega_hasDegree hr0 hr1 φ).mul (magneticU_hasDegree φ)

def overlapGaugeEquiv {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    MagneticSpace ≃ₗᵢ[ℂ] MagneticSpace :=
  (fibreHilbertBasis (magneticUUnitary φ) (magneticU_hasDegree φ)).repr.trans
    (fibreHilbertBasis (gaugedUUnitary hr0 hr1 φ) (gaugedU_hasDegree hr0 hr1 φ)).repr.symm

def overlapGauge {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) : MagneticOperator :=
  overlapGaugeEquiv hr0 hr1 φ

theorem overlapGauge_unitary {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ ∈ unitary MagneticOperator :=
  (unitary.linearIsometryEquiv.symm (overlapGaugeEquiv hr0 hr1 φ)).property

theorem overlapGauge_fibreBasis {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (φ : ℝ) (mn : ℤ×ℤ) :
    overlapGauge hr0 hr1 φ (fibreBasis (magneticUUnitary φ) mn) =
      fibreBasis (gaugedUUnitary hr0 hr1 φ) mn := by
  change (fibreHilbertBasis (gaugedUUnitary hr0 hr1 φ)
      (gaugedU_hasDegree hr0 hr1 φ)).repr.symm
    ((fibreHilbertBasis (magneticUUnitary φ) (magneticU_hasDegree φ)).repr
      (fibreBasis (magneticUUnitary φ) mn)) = _
  rw [← fibreHilbertBasis_apply _ (magneticU_hasDegree φ), HilbertBasis.repr_self,
    HilbertBasis.repr_symm_single, fibreHilbertBasis_apply]

theorem fibreBasis_zero (W : unitary MagneticOperator) (n : ℤ) :
    fibreBasis W (0,n) = lp.single 2 (n,n) 1 := by simp [fibreBasis]

theorem overlapGauge_origin {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ magneticOrigin = magneticOrigin := by
  have h := overlapGauge_fibreBasis hr0 hr1 φ (0,0)
  simpa [fibreBasis_zero, magneticOrigin] using h

theorem fibreBasis_step (W : unitary MagneticOperator) (m n : ℤ) :
    (W : MagneticOperator) (fibreBasis W (m,n)) = fibreBasis W (m+1,n) := by
  change ((W : MagneticOperator) * ((W^m : unitary MagneticOperator) : MagneticOperator))
    (lp.single 2 (n,n) 1) = _
  have he : W * W^m = W^(m+1) := by rw [zpow_add_one]; exact (Commute.self_zpow W m).eq
  rw [← Submonoid.coe_mul, he]
  rfl

theorem continuousLinearMap_ext_fibre (W : unitary MagneticOperator)
    (hW : HasDegree (-1) (W : MagneticOperator)) {A B : MagneticOperator}
    (h : ∀ mn, A (fibreBasis W mn) = B (fibreBasis W mn)) : A = B := by
  have hd : Dense (Submodule.span ℂ (Set.range (fibreHilbertBasis W hW)) : Set MagneticSpace) := by
    rw [dense_iff_closure_eq]
    change ((Submodule.span ℂ (Set.range (fibreHilbertBasis W hW))).topologicalClosure :
      Set MagneticSpace) = Set.univ
    rw [HilbertBasis.dense_span]
    rfl
  apply ContinuousLinearMap.ext_on hd
  rintro _ ⟨mn,rfl⟩
  simpa using h mn

theorem overlapGauge_intertwines_U {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ * magneticU φ =
      (magneticOmega r φ * magneticU φ) * overlapGauge hr0 hr1 φ := by
  apply continuousLinearMap_ext_fibre (magneticUUnitary φ) (magneticU_hasDegree φ)
  rintro ⟨m,n⟩
  change overlapGauge hr0 hr1 φ ((magneticUUnitary φ : MagneticOperator)
    (fibreBasis (magneticUUnitary φ) (m,n))) =
    (gaugedUUnitary hr0 hr1 φ : MagneticOperator)
      (overlapGauge hr0 hr1 φ (fibreBasis (magneticUUnitary φ) (m,n)))
  rw [fibreBasis_step, overlapGauge_fibreBasis, overlapGauge_fibreBasis, fibreBasis_step]

theorem overlapGauge_conjugates_U {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ * magneticU φ * star (overlapGauge hr0 hr1 φ) =
      magneticOmega r φ * magneticU φ := by
  rw [overlapGauge_intertwines_U, mul_assoc,
    unitary.mul_star_self_of_mem (overlapGauge_unitary hr0 hr1 φ), mul_one]

theorem magneticV_diagonal_single (φ : ℝ) (n : ℤ) :
    magneticV φ (lp.single 2 (n,n) 1) =
      latticePhase φ 1 • lp.single 2 (n+1,n+1) 1 := by
  apply lp.ext
  funext s
  simp only [magneticV, ContinuousLinearMap.smul_apply, lp.coeFn_smul,
    Pi.smul_apply, smul_eq_mul, magneticShift_apply]
  by_cases hs : s = (n+1,n+1)
  · subst s
    have he : (n+1,n+1)-(1,1) = (n,n) := by ext <;> simp
    rw [he]
    simp [wedge]
  · have he : s-(1,1) ≠ (n,n) := by
      intro h
      apply hs
      exact Prod.ext (by have := congrArg Prod.fst h; simp at this; omega)
        (by have := congrArg Prod.snd h; simp at this; omega)
    rw [lp.single_apply_ne (E := fun _ : MagneticSite => ℂ) 2 (n,n) 1 he,
      lp.single_apply_ne (E := fun _ : MagneticSite => ℂ) 2 (n+1,n+1) 1 hs]
    simp

theorem weyl_reverse (W : unitary MagneticOperator) (φ : ℝ)
    (hW : (W : MagneticOperator) * magneticV φ =
      latticePhase φ 2 • (magneticV φ * (W : MagneticOperator))) :
    magneticV φ * (W : MagneticOperator) =
      latticePhase φ (-2) • ((W : MagneticOperator) * magneticV φ) := by
  calc
    _ = latticePhase φ (-2) • (latticePhase φ 2 •
        (magneticV φ * (W : MagneticOperator))) := by
      simp only [smul_smul, ← latticePhase_add]
      norm_num
    _ = _ := by rw [← hW]

theorem weyl_star (W : unitary MagneticOperator) (φ : ℝ)
    (hW : (W : MagneticOperator) * magneticV φ =
      latticePhase φ 2 • (magneticV φ * (W : MagneticOperator))) :
    magneticV φ * star (W : MagneticOperator) =
      latticePhase φ 2 • (star (W : MagneticOperator) * magneticV φ) := by
  calc
    _ = (star (W : MagneticOperator) * (W : MagneticOperator)) *
        (magneticV φ * star (W : MagneticOperator)) := by
      rw [unitary.coe_star_mul_self, one_mul]
    _ = star (W : MagneticOperator) * ((W : MagneticOperator) * magneticV φ) *
        star (W : MagneticOperator) := by noncomm_ring
    _ = latticePhase φ 2 • (star (W : MagneticOperator) * magneticV φ *
        ((W : MagneticOperator) * star (W : MagneticOperator))) := by
      rw [hW]
      simp only [mul_smul_comm, smul_mul_assoc, mul_assoc]
    _ = _ := by rw [unitary.mul_star_self_of_mem W.property, mul_one]

theorem magneticOperator_smul_mul (c : ℂ) (A B : MagneticOperator) :
    (c • A) * B = c • (A*B) := by ext u s; rfl

theorem magneticOperator_mul_smul (c : ℂ) (A B : MagneticOperator) :
    A * (c • B) = c • (A*B) := by
  ext u s
  simp only [ContinuousLinearMap.mul_apply, ContinuousLinearMap.smul_apply, map_smul]

theorem weyl_zpow (W : unitary MagneticOperator) (φ : ℝ)
    (hW : (W : MagneticOperator) * magneticV φ =
      latticePhase φ 2 • (magneticV φ * (W : MagneticOperator))) (m : ℤ) :
    magneticV φ * ((W^m : unitary MagneticOperator) : MagneticOperator) =
      latticePhase φ (-2*m) •
        (((W^m : unitary MagneticOperator) : MagneticOperator) * magneticV φ) := by
  induction m using Int.induction_on with
  | hz => simp
  | hp n ih =>
      rw [zpow_add_one, Submonoid.coe_mul, ← mul_assoc, ih, magneticOperator_smul_mul,
        mul_assoc, weyl_reverse W φ hW, magneticOperator_mul_smul, smul_smul, ← latticePhase_add]
      rw [mul_assoc]
      congr 2
      omega
  | hn n ih =>
      rw [zpow_sub_one, Submonoid.coe_mul]
      change magneticV φ * (((W^(-(n : ℤ)) : unitary MagneticOperator) : MagneticOperator) *
        star (W : MagneticOperator)) = _
      rw [← mul_assoc, ih, magneticOperator_smul_mul, mul_assoc, weyl_star W φ hW,
        magneticOperator_mul_smul, smul_smul, ← latticePhase_add]
      change latticePhase φ (-2 * -(n : ℤ) + 2) •
        (((W^(-(n : ℤ)) : unitary MagneticOperator) : MagneticOperator) *
          (star (W : MagneticOperator) * magneticV φ)) = _
      rw [mul_assoc]
      congr 2
      omega

theorem fibreBasis_V (W : unitary MagneticOperator) (φ : ℝ)
    (hW : (W : MagneticOperator) * magneticV φ =
      latticePhase φ 2 • (magneticV φ * (W : MagneticOperator))) (m n : ℤ) :
    magneticV φ (fibreBasis W (m,n)) =
      latticePhase φ (1-2*m) • fibreBasis W (m,n+1) := by
  change (magneticV φ * ((W^m : unitary MagneticOperator) : MagneticOperator))
    (lp.single 2 (n,n) 1) = _
  rw [weyl_zpow W φ hW, ContinuousLinearMap.smul_apply, ContinuousLinearMap.mul_apply,
    magneticV_diagonal_single, map_smul, smul_smul, ← latticePhase_add]
  change latticePhase φ (-2*m+1) • fibreBasis W (m,n+1) = _
  congr 2
  omega

theorem overlapGauge_commutes_V {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ * magneticV φ = magneticV φ * overlapGauge hr0 hr1 φ := by
  apply continuousLinearMap_ext_fibre (magneticUUnitary φ) (magneticU_hasDegree φ)
  rintro ⟨m,n⟩
  simp only [ContinuousLinearMap.mul_apply]
  rw [fibreBasis_V _ φ (magneticU_mul_V φ), map_smul, overlapGauge_fibreBasis,
    overlapGauge_fibreBasis, fibreBasis_V _ φ (magneticOmega_weyl hr0 hr1 φ)]

theorem overlapGauge_conjugates_V {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ * magneticV φ * star (overlapGauge hr0 hr1 φ) = magneticV φ := by
  rw [overlapGauge_commutes_V, mul_assoc,
    unitary.mul_star_self_of_mem (overlapGauge_unitary hr0 hr1 φ), mul_one]

end UAMO.OverlapGauge

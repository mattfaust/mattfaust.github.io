import UAMO.OverlapGaugeImplementer

noncomputable section
namespace UAMO.OverlapGauge
open scoped InnerProductSpace

def conjugateStarAlgHom (G : unitary MagneticOperator) :
    MagneticOperator →⋆ₐ[ℂ] MagneticOperator where
  toFun A := (G : MagneticOperator) * A * star (G : MagneticOperator)
  map_one' := by simp only [mul_one, unitary.mul_star_self_of_mem G.property]
  map_zero' := by simp
  map_add' := by intro A B; simp only [mul_add, add_mul]
  map_mul' := by
    intro A B
    symm
    calc
      _ = (G : MagneticOperator) * A *
          (star (G : MagneticOperator) * (G : MagneticOperator)) * B *
          star (G : MagneticOperator) := by noncomm_ring
      _ = _ := by rw [unitary.star_mul_self_of_mem G.property]; noncomm_ring
  commutes' := by
    intro c
    rw [Algebra.algebraMap_eq_smul_one]
    rw [magneticOperator_mul_smul, magneticOperator_smul_mul, mul_one,
      unitary.mul_star_self_of_mem G.property]
  map_star' := by intro A; simp only [star_mul, star_star, mul_assoc]

def overlapGaugeUnitary {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    unitary MagneticOperator := ⟨overlapGauge hr0 hr1 φ, overlapGauge_unitary hr0 hr1 φ⟩

theorem overlapGauge_polynomial {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (a φ : ℝ) :
    conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ)
      (PhysicalWalk.overlapPolynomial a r (magneticU φ) (magneticV φ)) =
    PhysicalWalk.overlapPolynomial a r (magneticOmega r φ * magneticU φ) (magneticV φ) := by
  have hU : conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ) (magneticU φ) =
      magneticOmega r φ * magneticU φ := overlapGauge_conjugates_U hr0 hr1 φ
  have hV : conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ) (magneticV φ) =
      magneticV φ := overlapGauge_conjugates_V hr0 hr1 φ
  simp only [PhysicalWalk.overlapPolynomial, map_smul, map_sub, map_add, map_one,
    map_mul, hU, hV]

theorem magnetic_overlap_square_conjugacy {a r : ℝ} (ha : a ≠ 0)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    overlapGauge hr0 hr1 φ *
      (star (PhysicalWalk.overlapPolynomial a r (magneticU φ) (magneticV φ)) *
        PhysicalWalk.overlapPolynomial a r (magneticU φ) (magneticV φ)) *
      star (overlapGauge hr0 hr1 φ) =
    ((1+a^2)*(1+r^2)) • (1 : MagneticOperator) + a • scalarHamiltonian a r φ := by
  change conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ) _ = _
  rw [map_mul, map_star, overlapGauge_polynomial,
    magnetic_transformed_overlap_square ha hr0 hr1]

theorem overlapGauge_source_expectation {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (φ : ℝ) (A : MagneticOperator) :
    ⟪magneticOrigin, conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ) A
      magneticOrigin⟫_ℂ = ⟪magneticOrigin,A magneticOrigin⟫_ℂ := by
  have hs : star (overlapGauge hr0 hr1 φ) magneticOrigin = magneticOrigin := by
    calc
      _ = star (overlapGauge hr0 hr1 φ) (overlapGauge hr0 hr1 φ magneticOrigin) := by
        rw [overlapGauge_origin]
      _ = magneticOrigin := by
        change (star (overlapGauge hr0 hr1 φ) * overlapGauge hr0 hr1 φ) magneticOrigin = _
        rw [unitary.star_mul_self_of_mem (overlapGauge_unitary hr0 hr1 φ)]
        rfl
  change ⟪magneticOrigin, overlapGauge hr0 hr1 φ
    (A (star (overlapGauge hr0 hr1 φ) magneticOrigin))⟫_ℂ = _
  rw [hs, ← ContinuousLinearMap.adjoint_inner_left]
  change ⟪star (overlapGauge hr0 hr1 φ) magneticOrigin,A magneticOrigin⟫_ℂ = _
  rw [hs]

end UAMO.OverlapGauge

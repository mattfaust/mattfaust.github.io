import UAMO.ReflectionMatrix

noncomputable section
namespace UAMO
open scoped Matrix
open PhysicalWalk

section Algebra
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

theorem normalized_overlap_gram (a r : ℝ) (u v : A) :
    star (((secondColumn r v)ᴴ * firstColumn a u) 0 0) *
      (((secondColumn r v)ᴴ * firstColumn a u) 0 0) =
    (((2 * ((1 + a ^ 2) * (1 + r ^ 2)))⁻¹ : ℝ) : ℂ) •
      (star (overlapPolynomial a r (Complex.I • u) (Complex.I • v)) *
        overlapPolynomial a r (Complex.I • u) (Complex.I • v)) := by
  have h := congrArg (fun X : A => star X * X) (reflection_overlap a r u v)
  simp only [star_smul, smul_mul_assoc, mul_smul_comm, smul_smul, star_neg,
    Complex.star_def, Complex.conj_I, neg_neg, mul_neg, Complex.I_mul_I,
    neg_mul, neg_neg, one_smul, Complex.conj_ofReal] at h
  have hs :
      (((Real.sqrt (2 * ((1 + a ^ 2) * (1 + r ^ 2))))⁻¹ : ℝ) : ℂ) *
        (((Real.sqrt (2 * ((1 + a ^ 2) * (1 + r ^ 2))))⁻¹ : ℝ) : ℂ) =
      (((2 * ((1 + a ^ 2) * (1 + r ^ 2)))⁻¹ : ℝ) : ℂ) := by
    norm_cast
    rw [← pow_two, inv_pow, Real.sq_sqrt (by positivity)]
  rwa [hs] at h

end Algebra

section CStar
variable {A : Type*} [CStarAlgebra A]

theorem scalarOverlapDiscriminant_eq_polynomial (a r : ℝ) (u v : A) :
    scalarOverlapDiscriminant (firstColumn a u) (secondColumn r v) =
      ((2 / ((1 + a ^ 2) * (1 + r ^ 2)) : ℝ) : ℂ) •
        (star (overlapPolynomial a r (Complex.I • u) (Complex.I • v)) *
          overlapPolynomial a r (Complex.I • u) (Complex.I • v)) - (2 : ℂ) • (1 : A) := by
  rw [scalarOverlapDiscriminant, overlapDiscriminant_entry, normalized_overlap_gram,
    smul_smul]
  have hs : (4 : ℂ) * (((2 * ((1 + a ^ 2) * (1 + r ^ 2)))⁻¹ : ℝ) : ℂ) =
      ((2 / ((1 + a ^ 2) * (1 + r ^ 2)) : ℝ) : ℂ) := by
    norm_cast
    rw [mul_inv_rev]
    ring
  rw [hs]

end CStar
end UAMO

import UAMO.CircleRotationAverage
import UAMO.AxisUniformGrowth
import Mathlib.Analysis.SpecialFunctions.Complex.Circle

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Filter Set
open scoped Topology

local instance periodicAverageMeasurableCircle : MeasurableSpace Circle := borel Circle
local instance periodicAverageBorelCircle : BorelSpace Circle := ⟨rfl⟩

def periodicCircleTest (f : ℝ → ℂ) (hf : Continuous f) (hp : Function.Periodic f 1) :
    C(Circle,ℂ) :=
  ⟨fun z => hp.lift ((AddCircle.homeomorphCircle (T:=1) (by norm_num)).symm z), by
    have hc : Continuous (hp.lift : AddCircle (1:ℝ) → ℂ) := continuous_coinduced_dom.mpr hf
    exact hc.comp (AddCircle.homeomorphCircle (T:=1) (by norm_num)).symm.continuous⟩

theorem periodicCircleTest_exp (f : ℝ → ℂ) (hf : Continuous f) (hp : Function.Periodic f 1)
    (x : ℝ) : periodicCircleTest f hf hp (Circle.exp (2*Real.pi*x))=f x := by
  have he : AddCircle.homeomorphCircle (T:=1) (by norm_num) (x : AddCircle (1:ℝ))=
      Circle.exp (2*Real.pi*x) := by
    rw [AddCircle.homeomorphCircle_apply,AddCircle.toCircle_apply_mk]
    simp
  simp only [periodicCircleTest,ContinuousMap.coe_mk,← he,Homeomorph.symm_apply_apply,
    Function.Periodic.lift_coe]

theorem circleComap_uniform_eq_exp_map :
    circleComap uniformCircleMeasure=
      angularParameterMeasure.map (fun x : ℝ => Circle.exp (2*Real.pi*x)) := by
  have he : (fun x : ℝ => ((Circle.exp (2*Real.pi*x) : Circle) : ℂ))=logFourierChar 1 := by
    funext x
    simp only [Circle.coe_exp,logFourierChar]
    congr 1
    push_cast
    ring
  have hm : (angularParameterMeasure.map (fun x : ℝ => Circle.exp (2*Real.pi*x))).map
      (fun z : Circle => (z:ℂ))=uniformCircleMeasure := by
    have hx : Continuous (fun x : ℝ => Circle.exp (2*Real.pi*x)) :=
      Circle.exp.continuous.comp (by fun_prop)
    rw [Measure.map_map circle_coe_measurableEmbedding.measurable hx.measurable]
    change angularParameterMeasure.map (fun x : ℝ => ((Circle.exp (2*Real.pi*x) : Circle) : ℂ))=_
    rw [he]
    rfl
  rw [circleComap,← hm,circle_coe_measurableEmbedding.comap_map]

theorem circleRotationMean_eq_integral_exp (f : C(Circle,ℂ)) :
    circleRotationMean f=∫ x in (0:ℝ)..1, f (Circle.exp (2*Real.pi*x)) := by
  change (∫ z : Circle, f z ∂circleComap uniformCircleMeasure)=_
  have hx : Continuous (fun x : ℝ => Circle.exp (2*Real.pi*x)) :=
    Circle.exp.continuous.comp (by fun_prop)
  rw [circleComap_uniform_eq_exp_map,integral_map
    hx.measurable.aemeasurable
    f.continuous.measurable.aestronglyMeasurable]
  change (∫ x in Ioc (0:ℝ) 1, f (Circle.exp (2*Real.pi*x)))=_
  exact (intervalIntegral.integral_of_le (by norm_num : (0:ℝ)≤1)).symm

theorem circleRotationMean_periodicCircleTest (f : ℝ → ℂ) (hf : Continuous f)
    (hp : Function.Periodic f 1) :
    circleRotationMean (periodicCircleTest f hf hp)=∫ x in (0:ℝ)..1, f x := by
  rw [circleRotationMean_eq_integral_exp]
  simp only [periodicCircleTest_exp]

theorem circleRotationAverage_periodicCircleTest (f : ℝ → ℂ) (hf : Continuous f)
    (hp : Function.Periodic f 1) (α θ : ℝ) (n : ℕ) :
    circleRotationAverage (Circle.exp (2*Real.pi*α)) n (Circle.exp (2*Real.pi*θ))
      (periodicCircleTest f hf hp)=
      (∑ j ∈ Finset.range n, f (θ+(j:ℝ)*α))/(n:ℂ) := by
  rw [circleRotationAverage_apply]
  simp_rw [UAMO.circle_exp_pow,← Circle.exp_add]
  have he (j : ℕ) : (j:ℝ)*(2*Real.pi*α)+2*Real.pi*θ=2*Real.pi*(θ+(j:ℝ)*α) := by ring
  simp_rw [he,periodicCircleTest_exp]
  rw [div_eq_inv_mul]

theorem periodic_rotation_average_tendsto {α : ℝ} (hα : Irrational α)
    (f : ℝ → ℂ) (hf : Continuous f) (hp : Function.Periodic f 1) (θ : ℝ) :
    Tendsto (fun n : ℕ => (∑ j ∈ Finset.range n, f (θ+(j:ℝ)*α))/(n:ℂ)) atTop
      (𝓝 (∫ x in (0:ℝ)..1, f x)) := by
  have ht := circleRotationAverage_irrational_tendsto hα (periodicCircleTest f hf hp)
  have hmap : Tendsto (fun n : ℕ => (n,Circle.exp (2*Real.pi*θ))) atTop
      (atTop ×ˢ (⊤ : Filter Circle)) := tendsto_id.prodMk tendsto_top
  have h := ht.comp hmap
  simpa only [Function.comp_def,circleRotationAverage_periodicCircleTest,
    circleRotationMean_periodicCircleTest] using h

end UAMO.CircleDOS

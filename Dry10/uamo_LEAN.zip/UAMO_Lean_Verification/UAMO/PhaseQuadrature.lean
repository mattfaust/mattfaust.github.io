import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.Topology.UniformSpace.HeineCantor
import Mathlib.Analysis.SpecificLimits.Basic

noncomputable section
namespace UAMO.ComplexGrowth
open Set Filter MeasureTheory
open scoped Topology BigOperators

theorem periodic_uniformContinuous {f : ℝ→ℝ} (hf : Continuous f) {T : ℝ}
    (hT : 0<T) (hp : Function.Periodic f T) : UniformContinuous f := by
  have hu := isCompact_Icc.uniformContinuousOn_of_continuous
    (s:=Icc (-T) (2*T)) hf.continuousOn
  apply Metric.uniformContinuous_iff.mpr
  intro ε hε
  obtain ⟨δ,hδ,hh⟩ := Metric.uniformContinuousOn_iff.mp hu ε hε
  refine ⟨min δ T,lt_min hδ hT,?_⟩
  intro x y hxy
  obtain ⟨n,hn,_⟩ := existsUnique_sub_zsmul_mem_Ico hT x 0
  simp only [zero_add] at hn
  have hd : dist (x-n • T) (y-n • T)<δ := by
    simpa only [dist_sub_right] using lt_of_lt_of_le hxy (min_le_left _ _)
  have hsmall : |x-y|<T := by
    simpa only [Real.dist_eq] using lt_of_lt_of_le hxy (min_le_right _ _)
  have hx : x-n • T∈Icc (-T) (2*T) := ⟨by linarith [hn.1],by linarith [hn.2]⟩
  have hy : y-n • T∈Icc (-T) (2*T) := by
    obtain ⟨hl,hr⟩ := abs_lt.mp hsmall
    constructor <;> linarith [hn.1,hn.2]
  simpa only [hp.sub_zsmul_eq n] using hh (x-n • T) hx (y-n • T) hy hd

def phaseSampleMean (f : ℝ→ℝ) (T : ℝ) (N : ℕ) (x : ℝ) : ℝ :=
  (∑j∈Finset.range N, f (x+j*(T/N)))/N

def phaseIntegralMean (f : ℝ→ℝ) (T : ℝ) : ℝ :=
  (∫t in (0:ℝ)..T, f t)/T

theorem phaseSampleMean_error {f : ℝ→ℝ} (hf : Continuous f) {T : ℝ}
    (hT : 0<T) (hp : Function.Periodic f T) {ε δ : ℝ}
    (hmod : ∀x y : ℝ, dist x y<δ → dist (f x) (f y)≤ε)
    {N : ℕ} (hN : 0<N) (hmesh : T/(N:ℝ)<δ) (x : ℝ) :
    |phaseSampleMean f T N x-phaseIntegralMean f T|≤ε := by
  have hNr : (0:ℝ)<N := by exact_mod_cast hN
  let h : ℝ := T/N
  let p : ℕ→ℝ := fun j => x+j*h
  have hh : 0<h := div_pos hT hNr
  have hcell (j : ℕ) :
      |h*f (p j)-(∫t in p j..p (j+1), f t)|≤ε*h := by
    have he : h*f (p j)-(∫t in p j..p (j+1), f t) =
        ∫t in p j..p (j+1), f (p j)-f t := by
      rw [intervalIntegral.integral_sub intervalIntegrable_const (hf.intervalIntegrable _ _),
        intervalIntegral.integral_const]
      simp only [smul_eq_mul,p,Nat.cast_add,Nat.cast_one]
      ring
    rw [he,← Real.norm_eq_abs]
    have hle : p j≤p (j+1) := by dsimp [p]; push_cast; nlinarith
    have hi := intervalIntegral.norm_integral_le_of_norm_le_const
      (a:=p j) (b:=p (j+1)) (f:=fun t => f (p j)-f t) (C:=ε) (fun t ht => by
        have ht' : t∈Ioc (p j) (p (j+1)) := by simpa only [uIoc_of_le hle] using ht
        have hd : dist (p j) t<δ := by
          rw [Real.dist_eq,abs_of_nonpos (by linarith [ht'.1])]
          have hpstep : p (j+1)-p j=h := by dsimp [p]; push_cast; ring
          calc
            -(p j-t)=t-p j := by ring
            _ ≤ p (j+1)-p j := sub_le_sub_right ht'.2 _
            _ = h := hpstep
            _ < δ := hmesh
        simpa only [Real.dist_eq,Real.norm_eq_abs] using hmod (p j) t hd)
    have hstep : p (j+1)-p j=h := by dsimp [p]; push_cast; ring
    simpa only [hstep,abs_of_pos hh] using hi
  have hsum := intervalIntegral.sum_integral_adjacent_intervals
    (a:=p) (n:=N) (fun j _ => hf.intervalIntegrable (μ:=volume) (p j) (p (j+1)))
  have hp0 : p 0=x := by simp [p]
  have hpN : p N=x+T := by dsimp [p,h]; field_simp
  rw [hp0,hpN] at hsum
  have he : h*(∑j∈Finset.range N, f (p j))-(∫t in x..x+T,f t) =
      ∑j∈Finset.range N, (h*f (p j)-(∫t in p j..p (j+1),f t)) := by
    rw [Finset.sum_sub_distrib,← Finset.mul_sum,hsum]
  have hb : |h*(∑j∈Finset.range N, f (p j))-(∫t in x..x+T,f t)|≤ε*T := by
    rw [he]
    calc
      _ ≤ ∑j∈Finset.range N, |h*f (p j)-(∫t in p j..p (j+1),f t)| :=
        Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑j∈Finset.range N, ε*h := Finset.sum_le_sum (fun j _ => hcell j)
      _ = ε*T := by simp [h,hNr.ne']; field_simp
  have hi : (∫t in x..x+T,f t)=(∫t in (0:ℝ)..T,f t) := by
    simpa only [zero_add] using hp.intervalIntegral_add_eq x 0
  rw [hi] at hb
  have heq : phaseSampleMean f T N x-phaseIntegralMean f T =
      (h*(∑j∈Finset.range N, f (p j))-(∫t in (0:ℝ)..T,f t))/T := by
    unfold phaseSampleMean phaseIntegralMean
    dsimp [p,h]
    field_simp
    ring
  rw [heq,abs_div,abs_of_pos hT]
  exact (div_le_iff₀ hT).mpr hb

theorem phaseSampleMean_eventually_uniform {f : ℝ→ℝ} (hf : Continuous f) {T : ℝ}
    (hT : 0<T) (hp : Function.Periodic f T) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ N : ℕ in atTop, ∀x : ℝ,
      |phaseSampleMean f T N x-phaseIntegralMean f T|<ε := by
  obtain ⟨δ,hδ,hh⟩ := Metric.uniformContinuous_iff.mp
    (periodic_uniformContinuous hf hT hp) (ε/2) (by positivity)
  have ht : Tendsto (fun N : ℕ => T/(N:ℝ)) atTop (𝓝 0) := tendsto_const_div_atTop_nhds_zero_nat T
  filter_upwards [ht.eventually (gt_mem_nhds hδ),eventually_ge_atTop (1:ℕ)] with N hmesh hN x
  have h := phaseSampleMean_error hf hT hp
    (fun s t hst => (hh hst).le) (by omega : 0<N) hmesh x
  linarith

theorem phaseSampleMean_tendsto {f : ℝ→ℝ} (hf : Continuous f) {T : ℝ}
    (hT : 0<T) (hp : Function.Periodic f T) (x : ℝ) :
    Tendsto (fun N : ℕ => phaseSampleMean f T N x) atTop (𝓝 (phaseIntegralMean f T)) := by
  apply Metric.tendsto_atTop.mpr
  intro ε hε
  obtain ⟨N,hN⟩ := eventually_atTop.mp (phaseSampleMean_eventually_uniform hf hT hp hε)
  exact ⟨N,fun n hn => by simpa only [Real.dist_eq] using hN n hn x⟩

end UAMO.ComplexGrowth

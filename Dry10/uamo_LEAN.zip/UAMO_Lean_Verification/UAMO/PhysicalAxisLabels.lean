import UAMO.AxisResolvent
import UAMO.CircleArcLabel
import UAMO.UAMOGapLabels

noncomputable section
namespace UAMO.CircleDOS
open MeasureTheory Set

theorem arcLabel_one (ν : Measure ℂ) [IsProbabilityMeasure ν] [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν,‖z‖=1) (hconj : ν.map star=ν) : arcLabel ν 1=1 := by
  letI : IsProbabilityMeasure (ν.map Complex.re) :=
    isProbabilityMeasure_map Complex.continuous_re.measurable.aemeasurable
  have he : Iio (1:ℝ)=ᵐ[ν.map Complex.re] Set.univ := by
    filter_upwards [realPart_ae_Ioo ν hc] with x hx
    apply propext
    exact ⟨fun _ => trivial,fun _ => hx.2⟩
  rw [arcLabel_of_im_nonpos ν (by norm_num),show (1:ℂ).re=1 by rfl,
    circle_lowerArc_mass ν hc hconj,measureReal_congr he]
  norm_num [measureReal_def]

theorem arcLabel_neg_one (ν : Measure ℂ) [IsProbabilityMeasure ν] [NoAtoms ν]
    (hc : ∀ᵐ z ∂ν,‖z‖=1) (hconj : ν.map star=ν) : arcLabel ν (-1)=1/2 := by
  have he : Iio (-1:ℝ)=ᵐ[ν.map Complex.re] (∅:Set ℝ) := by
    filter_upwards [realPart_ae_Ioo ν hc] with x hx
    apply propext
    exact ⟨fun h => (not_lt_of_ge hx.1.le) h,fun h => False.elim h⟩
  rw [arcLabel_of_im_nonpos ν (by norm_num),show (-1:ℂ).re= -1 by rfl,
    circle_lowerArc_mass ν hc hconj,measureReal_congr he,measureReal_empty]
  norm_num

end UAMO.CircleDOS

namespace UAMO
open CircleDOS PhysicalDOS CMV

theorem physical_axis_arcLabels {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (α : ℝ) :
    arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1) 1=1 ∧
      arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1) (-1)=1/2 := by
  letI := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 α
  exact ⟨arcLabel_one _ (physicalUnitaryDOS_ae_circle a r α ha.le ha1 hr hr1)
    (physicalUnitaryDOS_conj_invariant a r α ha.le ha1 hr hr1),
    arcLabel_neg_one _ (physicalUnitaryDOS_ae_circle a r α ha.le ha1 hr hr1)
    (physicalUnitaryDOS_conj_invariant a r α ha.le ha1 hr hr1)⟩

theorem physical_axis_gaps_zero_labels {a r α : ℝ} (ha : 0<a) (ha1 : a<1)
    (hr : 0≤r) (hr1 : r<1) (hα : Irrational α) :
    ((∀θ,(1:ℂ)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α θ)) ∧
      ((arcLabel (physicalUnitaryDOS a r α ha.le ha1.le hr hr1.le) 1 : ℝ) :
        AddCircle (1:ℝ))=uamoGapLabel α 0 0) ∧
    ((∀θ,(-1:ℂ)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α θ)) ∧
      ((arcLabel (physicalUnitaryDOS a r α ha.le ha1.le hr hr1.le) (-1) : ℝ) :
        AddCircle (1:ℝ))=uamoGapLabel α 0 1) := by
  obtain ⟨hpos,hneg⟩ := physical_axis_arcLabels ha ha1.le hr hr1.le α
  refine ⟨⟨physical_one_resolvent ha ha1 hr hr1 hα,?_⟩,
    ⟨physical_neg_one_resolvent ha ha1 hr hr1 hα,?_⟩⟩
  · rw [hpos,AddCircle.coe_period]
    simp [uamoGapLabel]
  · rw [hneg]
    simp [uamoGapLabel]

end UAMO

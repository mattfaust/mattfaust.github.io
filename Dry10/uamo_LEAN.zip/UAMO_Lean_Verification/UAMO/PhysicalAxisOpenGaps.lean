import UAMO.PhysicalOpenGapAllCuts

noncomputable section
namespace UAMO
open CircleDOS PhysicalDOS CMV

theorem physical_axis_openDOS_zero_labels {a r α:ℝ} (ha:0<a) (ha1:a<1)
    (hr:0≤r) (hr1:r<1) (hα:Irrational α) :
    OpenDOSGapLabel a r α ha.le ha1.le hr hr1.le (uamoGapLabel α 0 0) ∧
    OpenDOSGapLabel a r α ha.le ha1.le hr hr1.le (uamoGapLabel α 0 1) := by
  obtain ⟨hpos,hneg⟩ := physical_axis_gaps_zero_labels ha ha1 hr hr1 hα
  constructor
  · exact openDOSGapLabel_of_witness_all_cuts ha ha1.le hr hr1.le hα 0 1
      (by norm_num) (hpos.1 0) _ hpos.2
  · exact openDOSGapLabel_of_witness_all_cuts ha ha1.le hr hr1.le hα 0 (-1)
      (by norm_num) (hneg.1 0) _ hneg.2

theorem physical_axis_openRotation_zero_labels {a r α:ℝ} (ha:0<a) (ha1:a<1)
    (hr:0≤r) (hr1:r<1) (hα:Irrational α) :
    OpenPhysicalRotationGapLabel a r α (uamoGapLabel α 0 0) ∧
    OpenPhysicalRotationGapLabel a r α (uamoGapLabel α 0 1) := by
  obtain ⟨hpos,hneg⟩ := physical_axis_openDOS_zero_labels ha ha1 hr hr1 hα
  exact ⟨(openPhysicalRotationGapLabel_iff_DOS ha ha1.le hr hr1 hα _).mpr hpos,
    (openPhysicalRotationGapLabel_iff_DOS ha ha1.le hr hr1 hα _).mpr hneg⟩

theorem physical_axis_open_zero_winding_label {a r α:ℝ} (ha:0<a) (ha1:a<1)
    (hr:0≤r) (hr1:r<1) (hα:Irrational α) (ell:ℤ) :
    OpenDOSGapLabel a r α ha.le ha1.le hr hr1.le (uamoGapLabel α 0 ell) ∧
    OpenPhysicalRotationGapLabel a r α (uamoGapLabel α 0 ell) := by
  obtain ⟨hD0,hD1⟩ := physical_axis_openDOS_zero_labels ha ha1 hr hr1 hα
  obtain ⟨hR0,hR1⟩ := physical_axis_openRotation_zero_labels ha ha1 hr hr1 hα
  rcases Int.even_or_odd ell with heven|hodd
  · have heq : uamoGapLabel α 0 ell=uamoGapLabel α 0 0 :=
      (uamoGapLabel_eq_iff hα 0 ell 0 0).mpr ⟨rfl,by simpa only [sub_zero] using heven⟩
    rw [heq]
    exact ⟨hD0,hR0⟩
  · obtain ⟨q,hq⟩ := hodd
    have heq : uamoGapLabel α 0 ell=uamoGapLabel α 0 1 :=
      (uamoGapLabel_eq_iff hα 0 ell 0 1).mpr ⟨rfl,q,by omega⟩
    rw [heq]
    exact ⟨hD1,hR1⟩

end UAMO

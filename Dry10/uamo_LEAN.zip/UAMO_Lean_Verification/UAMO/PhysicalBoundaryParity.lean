import UAMO.PhysicalRotationDOS
import UAMO.PhysicalGapRotation
import UAMO.CornerGapPersistence
import UAMO.PhysicalDualityDOS
import UAMO.PhysicalOpenGapLabels

noncomputable section
namespace UAMO
open CircleDOS PhysicalDOS

theorem boundary_physical_gap_has_odd_DOS_label {r α : ℝ}
    (hr : 0≤r) (hr1 : r<1) (hα : Irrational α) (θ : ℝ)
    (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ (PhysicalRepresentation.walk 1 (coupling r) α θ)) :
    ∃m ell:ℤ,Odd m ∧
      ((arcLabel (physicalUnitaryDOS 1 r α (by norm_num) (by norm_num) hr hr1.le) z:ℝ):
        AddCircle (1:ℝ))=uamoGapLabel α m ell := by
  have he : Complex.exp ((z.arg:ℂ)*Complex.I)=z := by
    simpa only [hz,Complex.ofReal_one,one_mul] using Complex.norm_mul_exp_arg_mul_I z
  have hres' : Complex.exp ((z.arg:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk 1 (coupling r) α θ) := by rwa [he]
  obtain ⟨m,ell,hm,_hrot,hlabel⟩ :=
    boundary_physical_gap_has_odd_rotation_label hr hr1 hα z.arg θ hres'
  have hDOS := physicalRotationLabel_DOS_arg (by norm_num : (0:ℝ)<1) (by norm_num)
    hr hr1 α hα hz
  exact ⟨m,ell,hm,physicalRotationLabel_unique hDOS hlabel⟩

theorem corner_physical_gap_has_odd_DOS_label {α : ℝ} (hα : Irrational α)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ (PhysicalRepresentation.walk 1 1 α θ)) :
    ∃m ell:ℤ,Odd m ∧
      ((arcLabel (physicalUnitaryDOS 1 1 α (by norm_num) (by norm_num)
        (by norm_num) (by norm_num)) z:ℝ):AddCircle (1:ℝ))=uamoGapLabel α m ell := by
  apply corner_gap_has_odd_label_of_edge hα θ ?_ z hz hres
  intro r hr hr1 w hw hwres
  exact boundary_physical_gap_has_odd_DOS_label hr.le hr1 hα θ w hw hwres

theorem closed_boundary_physical_gap_has_odd_DOS_label {r α : ℝ}
    (hr : 0≤r) (hr1 : r≤1) (hα : Irrational α) (θ : ℝ)
    (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ (PhysicalRepresentation.walk 1 (coupling r) α θ)) :
    ∃m ell:ℤ,Odd m ∧
      ((arcLabel (physicalUnitaryDOS 1 r α (by norm_num) (by norm_num) hr hr1) z:ℝ):
        AddCircle (1:ℝ))=uamoGapLabel α m ell := by
  rcases lt_or_eq_of_le hr1 with hlt|rfl
  · exact boundary_physical_gap_has_odd_DOS_label hr hlt hα θ z hz hres
  · apply corner_physical_gap_has_odd_DOS_label hα θ z hz
    simpa only [show coupling 1=1 by norm_num [coupling]] using hres

theorem dual_closed_boundary_physical_gap_has_odd_DOS_label {a α : ℝ}
    (ha : 0≤a) (ha1 : a≤1) (hα : Irrational α) (θ : ℝ)
    (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) 1 α θ)) :
    ∃m ell:ℤ,Odd m ∧
      ((arcLabel (physicalUnitaryDOS a 1 α ha ha1 (by norm_num) (by norm_num)) z:ℝ):
        AddCircle (1:ℝ))=uamoGapLabel α m ell := by
  have hs := PhysicalDuality.physical_walk_spectrum_exchange a 1 α ha ha1
    (by norm_num) (by norm_num) hα θ θ
  simp only [show coupling 1=1 by norm_num [coupling]] at hs
  have hdres : z∈resolventSet ℂ (PhysicalRepresentation.walk 1 (coupling a) (-α) θ) := by
    have hnot : z∉spectrum ℂ (PhysicalRepresentation.walk (coupling a) 1 α θ) := by
      simpa only [spectrum,Set.mem_compl_iff,not_not] using hres
    rw [hs] at hnot
    simpa only [spectrum,Set.mem_compl_iff,not_not] using hnot
  obtain ⟨m,ell,hm,hlabel⟩ := closed_boundary_physical_gap_has_odd_DOS_label
    ha ha1 hα.neg θ z hz hdres
  refine ⟨-m,ell,hm.neg,?_⟩
  rw [PhysicalDuality.physicalUnitaryDOS_exchange a 1 α ha ha1 (by norm_num) (by norm_num),
    hlabel,uamoGapLabel_reverse_frequency]

theorem physical_closed_boundary_gap_has_odd_DOS_label {a r α : ℝ}
    (ha : 0≤a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1)
    (hboundary : a=1 ∨ r=1) (hα : Irrational α) (θ : ℝ)
    (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α θ)) :
    ∃m ell:ℤ,Odd m ∧
      ((arcLabel (physicalUnitaryDOS a r α ha ha1 hr hr1) z:ℝ):AddCircle (1:ℝ))=
        uamoGapLabel α m ell := by
  rcases hboundary with rfl|rfl
  · apply closed_boundary_physical_gap_has_odd_DOS_label hr hr1 hα θ z hz
    simpa only [show coupling 1=1 by norm_num [coupling]] using hres
  · apply dual_closed_boundary_physical_gap_has_odd_DOS_label ha ha1 hα θ z hz
    simpa only [show coupling 1=1 by norm_num [coupling]] using hres

theorem physical_closed_boundary_even_DOS_label_mem_spectrum {a r α : ℝ}
    (ha : 0≤a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1)
    (hboundary : a=1 ∨ r=1) (hα : Irrational α) (θ : ℝ)
    (z : ℂ) (hz : ‖z‖=1) (m ell:ℤ) (hm : Even m)
    (hlabel : ((arcLabel (physicalUnitaryDOS a r α ha ha1 hr hr1) z:ℝ):
      AddCircle (1:ℝ))=uamoGapLabel α m ell) :
    z∈spectrum ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) α θ) := by
  by_contra hnot
  have hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α θ) := by
    simpa only [spectrum,Set.mem_compl_iff,not_not] using hnot
  obtain ⟨k,j,hk,hoddlabel⟩ := physical_closed_boundary_gap_has_odd_DOS_label
    ha ha1 hr hr1 hboundary hα θ z hz hres
  have hkm := ((uamoGapLabel_eq_iff hα k j m ell).mp (hoddlabel.symm.trans hlabel)).1
  subst k
  obtain ⟨u,hu⟩ := hm
  obtain ⟨v,hv⟩ := hk
  omega

theorem physical_closed_boundary_not_open_even_DOS_gap {a r α : ℝ}
    (ha : 0≤a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1)
    (hboundary : a=1 ∨ r=1) (hα : Irrational α) (m ell:ℤ) (hm : Even m) :
    ¬OpenDOSGapLabel a r α ha ha1 hr hr1 (uamoGapLabel α m ell) := by
  rintro ⟨t,δ,hδ,hgap⟩
  obtain ⟨hres,hlabel⟩ := hgap t (by simpa only [sub_self,abs_zero] using hδ)
  have hz : ‖Complex.exp ((t:ℂ)*Complex.I)‖=1 := by simp [Complex.norm_exp]
  have hnot : Complex.exp ((t:ℂ)*Complex.I)∉spectrum ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α 0) := by
    simpa only [spectrum,Set.mem_compl_iff,not_not] using hres 0
  exact hnot (physical_closed_boundary_even_DOS_label_mem_spectrum
    ha ha1 hr hr1 hboundary hα 0 _ hz m ell hm hlabel)

end UAMO

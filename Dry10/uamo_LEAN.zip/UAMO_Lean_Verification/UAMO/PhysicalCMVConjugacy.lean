import UAMO.PhysicalRealPartReduction
import UAMO.CMVFiniteVolume

noncomputable section
namespace UAMO.PhysicalCMV
open PhysicalWalk PhysicalRepresentation PhysicalRealPart
open scoped Matrix

section Algebra
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

def pairGauge (u : A) : TwoByTwo A := !![0,u;1,0]

def evenFactor (lam t : ℝ) : TwoByTwo A :=
  !![(t : ℂ) • (1 : A), (lam : ℂ) • (1 : A);
    (lam : ℂ) • (1 : A), -(t : ℂ) • (1 : A)]

def oddFactor (u q b : A) : TwoByTwo A :=
  !![-u*b*star u, u*q; star q*star u, b]

omit [Algebra ℂ A] [StarModule ℂ A] in
theorem pairGauge_unitary (u : A) (hu : u ∈ unitary A) :
    pairGauge u ∈ unitary (TwoByTwo A) := by
  apply unitary.mem_iff.mpr
  constructor <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [pairGauge, Matrix.mul_apply, Fin.sum_univ_two,
      unitary.star_mul_self_of_mem hu, unitary.mul_star_self_of_mem hu]

omit [StarModule ℂ A] in
theorem pairGauge_shift_reflection (lam t : ℝ) (u : A) (hu : u ∈ unitary A) :
    pairGauge u * (shiftFactor lam t u * PhysicalWalk.flip) * star (pairGauge u) =
      evenFactor lam t := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [pairGauge, shiftFactor, PhysicalWalk.flip, evenFactor, Matrix.mul_apply, Fin.sum_univ_two,
      smul_mul_assoc, mul_smul_comm, unitary.star_mul_self_of_mem hu,
      unitary.mul_star_self_of_mem hu, mul_assoc]

omit [Algebra ℂ A] [StarModule ℂ A] in
theorem pairGauge_coin_reflection (u q b : A) :
    pairGauge u * (PhysicalWalk.flip * coinQB q b) * star (pairGauge u) = oddFactor u q b := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [pairGauge, PhysicalWalk.flip, coinQB, oddFactor, Matrix.mul_apply, Fin.sum_univ_two]

omit [StarModule ℂ A] in
theorem pairGauge_walk (lam t : ℝ) (u q b : A) (hu : u ∈ unitary A) :
    pairGauge u * (shiftFactor lam t u * coinQB q b) * star (pairGauge u) =
      evenFactor lam t * oddFactor u q b := by
  have hP := unitary.star_mul_self_of_mem (pairGauge_unitary u hu)
  rw [← pairGauge_shift_reflection lam t u hu, ← pairGauge_coin_reflection u q b]
  calc
    _ = pairGauge u * ((shiftFactor lam t u * PhysicalWalk.flip) * (PhysicalWalk.flip * coinQB q b)) *
        star (pairGauge u) := by rw [mul_assoc (shiftFactor lam t u),
          ← mul_assoc PhysicalWalk.flip PhysicalWalk.flip, flip_square, Matrix.one_mul]
    _ = _ := by
      simp only [mul_assoc, ← mul_assoc (star (pairGauge u)) (pairGauge u), hP, one_mul]

end Algebra

def physicalPairGauge : TwoByTwo Operator := pairGauge shift

theorem physicalPairGauge_unitary : physicalPairGauge ∈ unitary (TwoByTwo Operator) :=
  pairGauge_unitary shift shift_unitary

def infiniteEven (a : ℝ) : TwoByTwo Operator :=
  evenFactor (coupling a) (complementaryCoupling a)

def infiniteOdd (r Φ θ : ℝ) : TwoByTwo Operator :=
  oddFactor shift (physicalQ (coupling r) (complementaryCoupling r) Φ θ)
    (physicalB (coupling r) Φ θ)

def infiniteCMV (a r Φ θ : ℝ) : TwoByTwo Operator :=
  infiniteEven a * infiniteOdd r Φ θ

theorem physical_walk_eq_CMV (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    physicalPairGauge * PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ *
        star physicalPairGauge = infiniteCMV a r Φ θ := by
  rw [PhysicalRepresentation.walk, PhysicalWalk.walk,
    complementaryCoupling_eq_sqrt ha0 ha1, complementaryCoupling_eq_sqrt hr0 hr1,
    coinFactor_eq_coinQB]
  exact pairGauge_walk _ _ shift _ _ shift_unitary

theorem infiniteCMV_unitary (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    infiniteCMV a r Φ θ ∈ unitary (TwoByTwo Operator) := by
  rw [← physical_walk_eq_CMV a r Φ θ ha0 ha1 hr0 hr1]
  exact (unitary _).mul_mem ((unitary _).mul_mem physicalPairGauge_unitary
    (PhysicalWalk.walk_unitary_stereographic a r ha0 ha1 hr0 hr1 shift (phase Φ θ)
      shift_unitary (phase_unitary Φ θ))) (unitary.star_mem physicalPairGauge_unitary)

theorem infiniteEven_zero (a : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (infiniteEven a) ψ 0 n =
      (complementaryCoupling a : ℂ)*ψ 0 n + (coupling a : ℂ)*ψ 1 n := by
  simp [spinAction, infiniteEven, evenFactor]

theorem infiniteEven_one (a : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (infiniteEven a) ψ 1 n =
      (coupling a : ℂ)*ψ 0 n - (complementaryCoupling a : ℂ)*ψ 1 n := by
  simp [spinAction, infiniteEven, evenFactor, sub_eq_add_neg]

theorem infiniteOdd_one (r Φ θ : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (infiniteOdd r Φ θ) ψ 1 n =
      (CMV.oddAlpha r (phaseAngle Φ θ n) : ℂ)*ψ 1 n +
        star (CMV.physicalHopping r (phaseAngle Φ θ n))*ψ 0 (n+1) := by
  simp only [spinAction, infiniteOdd, oddFactor, Matrix.of_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.mul_apply, lp.coeFn_add, Pi.add_apply,
    physicalQ_star_apply, physicalB_apply, shift_star_apply]
  change star (qValue _ _ _)*ψ 0 (n+1) + (bValue _ _ : ℂ)*ψ 1 n = _
  simp only [qValue, bValue, CMV.oddAlpha, CMV.physicalHopping]
  ring

theorem infiniteOdd_zero_next (r Φ θ : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (infiniteOdd r Φ θ) ψ 0 (n+1) =
      CMV.physicalHopping r (phaseAngle Φ θ n)*ψ 1 n -
        (CMV.oddAlpha r (phaseAngle Φ θ n) : ℂ)*ψ 0 (n+1) := by
  simp only [spinAction, infiniteOdd, oddFactor, Matrix.of_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.mul_apply, ContinuousLinearMap.neg_apply,
    lp.coeFn_add, lp.coeFn_neg, Pi.add_apply, Pi.neg_apply, shift_apply,
    physicalQ_apply, physicalB_apply, shift_star_apply, add_sub_cancel_right]
  change -((bValue _ _ : ℂ)*ψ 0 (n+1)) + qValue _ _ _*ψ 1 n = _
  simp only [qValue, bValue, CMV.oddAlpha, CMV.physicalHopping]
  ring

end UAMO.PhysicalCMV

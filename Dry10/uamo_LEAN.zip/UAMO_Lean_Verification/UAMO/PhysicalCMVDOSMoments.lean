import UAMO.PhysicalCMVConjugacy
import UAMO.PhysicalDOSMeasure
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

noncomputable section
namespace UAMO.PhysicalCMV
open PhysicalRepresentation PhysicalDOS PhysicalWalk MeasureTheory

theorem walk_power_phase_covariance (lam₁ lam₂ Φ θ : ℝ) (k : ℤ)
    (n : ℕ) (i j : Fin 2) :
    shiftConjugation k ((PhysicalRepresentation.walk lam₁ lam₂ Φ θ ^ n) i j) =
      (PhysicalRepresentation.walk lam₁ lam₂ Φ (θ+Φ*(k : ℝ)) ^ n) i j := by
  change (((shiftConjugationEquiv k).mapMatrix)
    (PhysicalRepresentation.walk lam₁ lam₂ Φ θ ^ n)) i j = _
  rw [map_pow, walk_phase_covariance]

theorem shift_eq_integerShift : shift = integerShift (-1) := by
  ext ψ m
  simp [sub_eq_add_neg]

theorem shifted_walk_power_entry (lam₁ lam₂ Φ θ : ℝ) (n : ℕ) (i j : Fin 2) :
    shift * (PhysicalRepresentation.walk lam₁ lam₂ Φ θ ^ n) i j * star shift =
      (PhysicalRepresentation.walk lam₁ lam₂ Φ (θ-Φ) ^ n) i j := by
  rw [shift_eq_integerShift]
  simpa only [Int.cast_neg, Int.cast_one, mul_neg_one, ← sub_eq_add_neg] using
    walk_power_phase_covariance lam₁ lam₂ Φ θ (-1) n i j

theorem infiniteCMV_power (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (n : ℕ) :
    infiniteCMV a r Φ θ ^ n = physicalPairGauge *
      PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n * star physicalPairGauge := by
  have hPP := unitary.mul_star_self_of_mem physicalPairGauge_unitary
  have hP := unitary.star_mul_self_of_mem physicalPairGauge_unitary
  induction n with
  | zero => simpa using hPP.symm
  | succ n ih =>
    rw [pow_succ, ih, ← physical_walk_eq_CMV a r Φ θ ha0 ha1 hr0 hr1, pow_succ]
    simp only [mul_assoc, ← mul_assoc (star physicalPairGauge) physicalPairGauge,
      hP, one_mul]

theorem infiniteCMV_power_zero_entry (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (n : ℕ) :
    (infiniteCMV a r Φ θ ^ n) 0 0 =
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ (θ-Φ) ^ n) 1 1 := by
  rw [infiniteCMV_power a r Φ θ ha0 ha1 hr0 hr1]
  simp only [physicalPairGauge, pairGauge, Matrix.mul_apply, Fin.sum_univ_two,
    Matrix.star_apply, Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_fin_one, star_zero, star_one, zero_mul, mul_zero, zero_add, add_zero,
    one_mul, mul_one]
  exact shifted_walk_power_entry _ _ _ _ _ _ _

theorem infiniteCMV_power_one_entry (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (n : ℕ) :
    (infiniteCMV a r Φ θ ^ n) 1 1 =
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) 0 0 := by
  rw [infiniteCMV_power a r Φ θ ha0 ha1 hr0 hr1]
  simp [physicalPairGauge, pairGauge, Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]

theorem continuous_walk_source_entry (a r Φ : ℝ) (n : ℕ) (i j : Fin 2) :
    Continuous (fun θ => physicalOriginTrace
      ((PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) i j)) := by
  have hc : Continuous (fun θ => physicalOriginTrace (physicalEvaluation (-Real.pi*Φ) θ
      ((pairedWalk a r (-Real.pi*Φ)^n) i j))) := physicalOriginTrace.continuous.comp
        (pairedLaurentSpace_continuous (-Real.pi*Φ) ((pairedWalk a r (-Real.pi*Φ)^n) i j).property)
  simpa only [physicalEvaluation_pairedWalk_pow_entry] using hc

theorem walk_source_entry_average_shift (a r Φ t : ℝ) (n : ℕ) (i j : Fin 2) :
    (∫ θ in (0 : ℝ)..1, physicalOriginTrace
      ((PhysicalRepresentation.walk (coupling a) (coupling r) Φ (θ+t) ^ n) i j)) =
      ∫ θ in (0 : ℝ)..1, physicalOriginTrace
        ((PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) i j) := by
  let f : ℝ → ℂ := fun θ => physicalOriginTrace
    ((PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) i j)
  have hp : Function.Periodic f 1 := by
    intro θ
    dsimp [f]
    rw [walk_periodic]
  change (∫ θ in (0 : ℝ)..1, f (θ+t)) = ∫ θ in (0 : ℝ)..1, f θ
  rw [intervalIntegral.integral_comp_add_right f t]
  simpa only [zero_add, add_comm (1 : ℝ) t] using hp.intervalIntegral_add_eq t 0

theorem integerShift_star_delta_zero (j : ℤ) :
    star (integerShift j) (delta 0) = delta j := by
  apply lp.ext
  funext m
  by_cases hm : m = j
  · subst m
    simp [delta]
  · have hm' : m-j ≠ 0 := sub_ne_zero.mpr hm
    simp [delta, lp.single_apply, Pi.single_apply, hm, hm']

theorem physicalOriginTrace_shiftConjugation (j : ℤ) (B : Operator) :
    physicalOriginTrace (shiftConjugation j B) = B (delta j) j := by
  simp only [physicalOriginTrace_apply, shiftConjugation_apply,
    ContinuousLinearMap.mul_apply, integerShift_star_delta_zero, integerShift_apply, zero_add]

theorem walk_power_diagonal_at_site (lam₁ lam₂ Φ θ : ℝ) (j : ℤ)
    (n : ℕ) (s : Fin 2) :
    ((PhysicalRepresentation.walk lam₁ lam₂ Φ θ ^ n) s s (delta j)) j =
      physicalOriginTrace ((PhysicalRepresentation.walk lam₁ lam₂ Φ
        (θ+Φ*(j : ℝ)) ^ n) s s) := by
  rw [← walk_power_phase_covariance lam₁ lam₂ Φ θ j n s s,
    physicalOriginTrace_shiftConjugation]

theorem infiniteCMV_site_phase_averaged_moments (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (n : ℕ) (j : ℤ) :
    (∫ θ in (0 : ℝ)..1,
      (((infiniteCMV a r Φ θ ^ n) 0 0 (delta j)) j +
       ((infiniteCMV a r Φ θ ^ n) 1 1 (delta j)) j) / 2) =
      ∫ z : ℂ, z^n ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 := by
  simp only [infiniteCMV_power_zero_entry a r Φ _ ha0 ha1 hr0 hr1,
    infiniteCMV_power_one_entry a r Φ _ ha0 ha1 hr0 hr1, walk_power_diagonal_at_site]
  have hi (s : Fin 2) (t : ℝ) := ((continuous_walk_source_entry a r Φ n s s).comp
    (show Continuous (fun θ : ℝ => θ+t) from continuous_id.add continuous_const)).intervalIntegrable
      (μ := volume) (0 : ℝ) 1
  dsimp only [Function.comp_def] at hi
  have heq (θ : ℝ) : θ-Φ+Φ*(j : ℝ) = θ+(Φ*(j : ℝ)-Φ) := by ring
  simp_rw [heq]
  rw [intervalIntegral.integral_div, intervalIntegral.integral_add
    (hi 1 (Φ*(j : ℝ)-Φ)) (hi 0 (Φ*(j : ℝ))),
    walk_source_entry_average_shift, walk_source_entry_average_shift,
    physicalUnitaryDOS_moments, ← physical_walk_phase_averaged_moments a r Φ n]
  simp only [physicalMatrixOriginTrace]
  rw [intervalIntegral.integral_div, intervalIntegral.integral_add
    ((continuous_walk_source_entry a r Φ n 0 0).intervalIntegrable _ _)
    ((continuous_walk_source_entry a r Φ n 1 1).intervalIntegrable _ _), add_comm]

end UAMO.PhysicalCMV

import UAMO.UnitCircleScalarCorrespondence

noncomputable section
namespace UAMO

@[simp] theorem scalarEnergyOfCircle_star (a r : ℝ) (z : ℂ) :
    scalarEnergyOfCircle a r (star z)=scalarEnergyOfCircle a r z := by
  simp [scalarEnergyOfCircle,Complex.star_def]

theorem physical_circle_resolvent_star {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) {Φ : ℝ} (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1) :
    star z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ↔
      z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) := by
  rw [physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ θ (star z)
    (by simpa only [norm_star] using hz),
    physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ θ z hz,
    scalarEnergyOfCircle_star]

end UAMO

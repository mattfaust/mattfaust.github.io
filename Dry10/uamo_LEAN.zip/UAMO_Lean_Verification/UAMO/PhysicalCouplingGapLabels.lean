import UAMO.PhysicalOpenRotationLabels
import UAMO.BoundaryCircleContinuation
import UAMO.PhysicalBoundaryParity
import UAMO.ScalarSpectralBaseline
import UAMO.PhysicalOpenGapDuality

noncomputable section
namespace UAMO
open PhysicalWalk PhysicalDOS CircleDOS

def OpenPhysicalCouplingGapLabel (lam₁ lam₂ α : ℝ)
    (h₁ : 0≤lam₁) (h₁1 : lam₁≤1) (h₂ : 0≤lam₂) (h₂1 : lam₂≤1)
    (label : AddCircle (1:ℝ)) : Prop :=
  ∃t δ:ℝ,0<δ ∧ ∀s:ℝ,|s-t|<δ →
    (∀θ:ℝ,Complex.exp ((s:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk lam₁ lam₂ α θ)) ∧
    ((arcLabel (physicalUnitaryDOS (stereographicParameter lam₁)
      (stereographicParameter lam₂) α
      (stereographicParameter_mem_Icc h₁ h₁1).1 (stereographicParameter_mem_Icc h₁ h₁1).2
      (stereographicParameter_mem_Icc h₂ h₂1).1 (stereographicParameter_mem_Icc h₂ h₂1).2)
      (Complex.exp ((s:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ))=label

theorem openPhysicalCouplingGapLabel_iff (lam₁ lam₂ α : ℝ)
    (h₁ : 0≤lam₁) (h₁1 : lam₁≤1) (h₂ : 0≤lam₂) (h₂1 : lam₂≤1)
    (label : AddCircle (1:ℝ)) :
    OpenPhysicalCouplingGapLabel lam₁ lam₂ α h₁ h₁1 h₂ h₂1 label ↔
      OpenDOSGapLabel (stereographicParameter lam₁) (stereographicParameter lam₂) α
        (stereographicParameter_mem_Icc h₁ h₁1).1 (stereographicParameter_mem_Icc h₁ h₁1).2
        (stereographicParameter_mem_Icc h₂ h₂1).1 (stereographicParameter_mem_Icc h₂ h₂1).2
        label := by
  unfold OpenPhysicalCouplingGapLabel OpenDOSGapLabel
  rw [coupling_stereographicParameter h₁ h₁1,coupling_stereographicParameter h₂ h₂1]

end UAMO

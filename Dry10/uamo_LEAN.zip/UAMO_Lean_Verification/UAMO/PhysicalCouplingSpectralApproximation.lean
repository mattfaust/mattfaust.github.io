import UAMO.CMVCouplingDOSMoments
import UAMO.CMVCyclicSpectralApproximation

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter Set PhysicalDOS PhysicalRepresentation CircleDOS
open scoped Topology

theorem physicalUnitaryDOS_coupling_tests_tendsto (a α : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (r : ℕ → Icc (0:ℝ) 1) {r₀ : Icc (0:ℝ) 1}
    (hr : Tendsto r atTop (𝓝 r₀)) (f : ℂ → ℂ)
    (hf : Continuous (fun z : Circle => f z)) :
    Tendsto (fun n => ∫ z : ℂ, f z ∂physicalUnitaryDOS a (r n) α ha0 ha1
      (r n).property.1 (r n).property.2) atTop
      (𝓝 (∫ z : ℂ, f z ∂physicalUnitaryDOS a r₀ α ha0 ha1 r₀.property.1 r₀.property.2)) := by
  apply circleProbability_integral_tendsto_of_moments
    (fun n => physicalUnitaryDOS a (r n) α ha0 ha1 (r n).property.1 (r n).property.2)
    (physicalUnitaryDOS a r₀ α ha0 ha1 r₀.property.1 r₀.property.2)
    (fun n => physicalUnitaryDOS_ae_circle a (r n) α ha0 ha1 (r n).property.1 (r n).property.2)
    (physicalUnitaryDOS_ae_circle a r₀ α ha0 ha1 r₀.property.1 r₀.property.2) _ f hf
  intro k
  exact ((continuous_physicalUnitaryDOS_moment_coupling a α ha0 ha1 k).tendsto r₀).comp hr

theorem physicalUnitaryDOS_coupling_real_tests_tendsto (a α : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (r : ℕ → Icc (0:ℝ) 1) {r₀ : Icc (0:ℝ) 1}
    (hr : Tendsto r atTop (𝓝 r₀)) (f : ℂ → ℝ)
    (hf : Continuous (fun z : Circle => f z)) :
    Tendsto (fun n => ∫ z : ℂ, f z ∂physicalUnitaryDOS a (r n) α ha0 ha1
      (r n).property.1 (r n).property.2) atTop
      (𝓝 (∫ z : ℂ, f z ∂physicalUnitaryDOS a r₀ α ha0 ha1 r₀.property.1 r₀.property.2)) := by
  have h := physicalUnitaryDOS_coupling_tests_tendsto a α ha0 ha1 r hr
    (fun z => (f z:ℂ)) (Complex.continuous_ofReal.comp hf)
  have hre := Complex.continuous_re.continuousAt.tendsto.comp h
  simpa only [integral_complex_ofReal, Complex.ofReal_re, Function.comp_def] using hre

theorem eventually_exists_physical_spectrum_near_coupling (a α : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hα : Irrational α)
    (r : ℕ → Icc (0:ℝ) 1) {r₀ : Icc (0:ℝ) 1}
    (hr : Tendsto r atTop (𝓝 r₀)) (θ : ℝ) {z : ℂ}
    (hz : z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r₀) α θ))
    {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ n in atTop, ∃ w : ℂ,
      w ∈ spectrum ℂ (cstarWalk (coupling a) (coupling (r n)) α θ) ∧ dist w z < ε := by
  let f : ℂ → ℝ := fun w => max 0 (ε-‖w-z‖)
  have hf : Continuous f := by dsimp only [f]; fun_prop
  have hpos := physicalUnitaryDOS_spectral_bump_pos a r₀ α θ ha0 ha1
    r₀.property.1 r₀.property.2 hz hε
  have hlim := physicalUnitaryDOS_coupling_real_tests_tendsto a α ha0 ha1 r hr f
    (hf.comp continuous_subtype_val)
  filter_upwards [hlim.eventually (Ioi_mem_nhds hpos)] with n hn
  by_contra hnone
  push_neg at hnone
  have hzero : (fun w => f w) =ᵐ[physicalUnitaryDOS a (r n) α ha0 ha1
      (r n).property.1 (r n).property.2] (fun _ => (0:ℝ)) := by
    filter_upwards [physicalUnitaryDOS_ae_mem_spectrum a (r n) α ha0 ha1
      (r n).property.1 (r n).property.2 hα θ] with w hw
    have hd := hnone w hw
    rw [dist_eq_norm] at hd
    exact max_eq_left (sub_nonpos.mpr hd)
  have hi : (∫ w, f w ∂physicalUnitaryDOS a (r n) α ha0 ha1
      (r n).property.1 (r n).property.2) = 0 := by
    rw [integral_congr_ae hzero, integral_zero]
  exact (ne_of_gt hn) hi

attribute [local instance] physicalDOSMatrix_nontrivial

theorem exists_physical_circle_spectral_sequence (a α : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hα : Irrational α)
    (r : ℕ→Icc (0:ℝ) 1) {r₀ : Icc (0:ℝ) 1}
    (hr : Tendsto r atTop (𝓝 r₀)) (θ : ℝ) (z : Circle)
    (hz : (z:ℂ)∈spectrum ℂ (cstarWalk (coupling a) (coupling r₀) α θ)) :
    ∃w:ℕ→Circle,
      (∀n,(w n:ℂ)∈spectrum ℂ (cstarWalk (coupling a) (coupling (r n)) α θ)) ∧
      Tendsto w atTop (𝓝 z) := by
  have hclosest (n : ℕ) : ∃v:ℂ,
      v∈spectrum ℂ (cstarWalk (coupling a) (coupling (r n)) α θ) ∧
      ∀u∈spectrum ℂ (cstarWalk (coupling a) (coupling (r n)) α θ),
        dist v (z:ℂ)≤dist u (z:ℂ) := by
    exact (spectrum.isCompact (cstarWalk (coupling a) (coupling (r n)) α θ)).exists_isMinOn
      (spectrum.nonempty _) ((continuous_id.dist continuous_const).continuousOn)
  choose v hv hmin using hclosest
  have hnorm (n : ℕ) : ‖v n‖=1 := by
    have h := spectrum.subset_circle_of_unitary (𝕜:=ℂ)
      (physicalCStarWalk_unitary a (r n) α θ ha0 ha1 (r n).property.1
        (r n).property.2) (hv n)
    simpa only [Metric.mem_sphere,dist_zero_right] using h
  let w : ℕ→Circle := fun n=>⟨v n,mem_sphere_zero_iff_norm.mpr (hnorm n)⟩
  refine ⟨w,hv,?_⟩
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  filter_upwards [eventually_exists_physical_spectrum_near_coupling a α ha0 ha1 hα
    r hr θ hz hε] with n hn
  obtain ⟨u,hu,hud⟩ := hn
  exact (hmin n u hu).trans_lt hud

end UAMO.CMV

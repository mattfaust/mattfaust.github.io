import UAMO.PhysicalDOSMeasure
import Mathlib.Topology.MetricSpace.HausdorffDistance

noncomputable section
namespace UAMO.PhysicalDOS
open MeasureTheory PhysicalRepresentation Set Filter
open scoped ContinuousFunctionalCalculus

attribute [local instance] physicalDOSMatrix_nontrivial

theorem physicalUnitaryDOS_ae_mem_spectrum (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (hΦ : Irrational Φ) (θ : ℝ) :
    ∀ᵐ z ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1,
      z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ) := by
  let S := spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ)
  let f : ℂ → ℝ := fun z => min 1 (Metric.infDist z S)
  have hf : Continuous f := continuous_const.min (Metric.continuous_infDist_pt S)
  have hpos : ∀ z, 0 ≤ f z := fun z => le_min zero_le_one Metric.infDist_nonneg
  have hint : Integrable f (physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1) := by
    apply (integrable_const (1 : ℝ)).mono' hf.aestronglyMeasurable
    exact ae_of_all _ (fun z => by rw [Real.norm_eq_abs, abs_of_nonneg (hpos z)]; exact min_le_left _ _)
  have hcf : Continuous (fun z => (f z : ℂ)) := Complex.continuous_ofReal.comp hf
  have hzero (t : ℝ) :
      cfc (fun z => (f z : ℂ)) (cstarWalk (coupling a) (coupling r) Φ t) = 0 := by
    have hc : cfc (fun z => (f z : ℂ)) (cstarWalk (coupling a) (coupling r) Φ t) =
        cfc (fun _ : ℂ => (0 : ℂ)) (cstarWalk (coupling a) (coupling r) Φ t) := by
      apply cfc_congr
      intro z hz
      have hzS : z ∈ S := by
        change z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ)
        rwa [← cstarWalk_spectrum_phase_independent hΦ (coupling a) (coupling r) t θ]
      simp [f, Metric.infDist_zero_of_mem hzS]
    simpa using hc
  have hi : (∫ z, f z ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1) = 0 := by
    have h := physicalUnitaryDOS_integral a r Φ ha0 ha1 hr0 hr1
      (fun z => (f z : ℂ)) hcf
    simp only [hzero, map_zero, intervalIntegral.integral_zero] at h
    rw [integral_complex_ofReal] at h
    exact_mod_cast h
  have hae := (integral_eq_zero_iff_of_nonneg (fun z => hpos z) hint).mp hi
  filter_upwards [hae] with z hz
  apply (spectrum.isClosed (cstarWalk (coupling a) (coupling r) Φ θ)).mem_iff_infDist_zero
    (spectrum.nonempty _)|>.mpr
  change min 1 (Metric.infDist z S) = 0 at hz
  rcases min_eq_iff.mp hz with h | h
  · norm_num at h
  · exact h.1

end UAMO.PhysicalDOS

import UAMO.PhysicalDOSMeasure
import Mathlib.MeasureTheory.Measure.OpenPos
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

noncomputable section
namespace UAMO.PhysicalDOS
open MeasureTheory PhysicalRepresentation SourceSpectral Set Filter
open scoped Topology InnerProductSpace ContinuousFunctionalCalculus

attribute [local instance] physicalDOSMatrix_nontrivial
local instance physicalFaithPhaseCFC :
    ContinuousFunctionalCalculus ℂ PhysicalPhaseAlgebra IsStarNormal :=
  @IsStarNormal.instContinuousFunctionalCalculus PhysicalPhaseAlgebra inferInstance

def physicalMatrixShiftConjugation (k : ℤ) : PhysicalMatrixAlgebra →⋆ₐ[ℂ] PhysicalMatrixAlgebra where
  toFun B := CStarMatrix.ofMatrix (fun i j => shiftConjugation k (B i j))
  map_one' := by
    apply CStarMatrix.ext
    intro i j
    simp only [CStarMatrix.ofMatrix_apply,CStarMatrix.one_apply]
    split_ifs <;> simp
  map_zero' := by apply CStarMatrix.ext; intro i j; simp
  map_add' := by
    intro B C
    apply CStarMatrix.ext
    intro i j
    exact map_add (shiftConjugation k) (B i j) (C i j)
  map_mul' := by
    intro B C
    apply CStarMatrix.ext
    intro i j
    simp only [CStarMatrix.ofMatrix_apply,CStarMatrix.mul_apply,map_sum,map_mul]
  commutes' := by
    intro c
    apply CStarMatrix.ext
    intro i j
    simp only [Algebra.algebraMap_eq_smul_one, CStarMatrix.ofMatrix_apply]
    change shiftConjugation k (c • ((1 : PhysicalMatrixAlgebra) i j))=
      c • ((1 : PhysicalMatrixAlgebra) i j)
    rw [map_smul]
    congr 1
    simp only [CStarMatrix.one_apply]
    split_ifs <;> simp
  map_star' := by
    intro B
    apply CStarMatrix.ext
    intro i j
    simp only [CStarMatrix.ofMatrix_apply,cstarMatrix_star_apply,map_star]

theorem continuous_physicalMatrixShiftConjugation (k : ℤ) :
    Continuous (physicalMatrixShiftConjugation k) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  change Continuous (fun B : PhysicalMatrixAlgebra => integerShift k * B i j * star (integerShift k))
  exact (continuous_const.mul (cstarMatrixEntry i j).continuous).mul continuous_const

theorem cstarWalk_phase_covariance (lam₁ lam₂ Φ θ : ℝ) (k : ℤ) :
    physicalMatrixShiftConjugation k (cstarWalk lam₁ lam₂ Φ θ)=
      cstarWalk lam₁ lam₂ Φ (θ+Φ*(k : ℝ)) := by
  apply CStarMatrix.ext
  intro i j
  have h := congrArg (fun B => B i j) (walk_phase_covariance lam₁ lam₂ Φ θ k)
  exact h

theorem physicalOriginTrace_square (B : Operator) :
    (physicalOriginTrace (star B*B)).re=‖B (delta 0)‖^2 := by
  rw [physicalOriginTrace_eq_inner]
  change (⟪delta 0,star B (B (delta 0))⟫_ℂ).re=_
  rw [ContinuousLinearMap.star_eq_adjoint,ContinuousLinearMap.adjoint_inner_right]
  exact inner_self_eq_norm_sq (𝕜 := ℂ) _

theorem physicalCStarOriginTrace_square_zero (B : PhysicalMatrixAlgebra)
    (hz : (physicalCStarOriginTrace (star B*B)).re=0) (i j : Fin 2) :
    B i j (delta 0)=0 := by
  change (normalizedMatrixTrace₂ physicalOriginTrace (star B*B)).re=0 at hz
  rw [normalizedMatrixTrace₂_star_mul_self_re] at hz
  simp only [physicalOriginTrace_square] at hz
  have hz00 : ‖B 0 0 (delta 0)‖^2=0 := by nlinarith [sq_nonneg (‖B 0 0 (delta 0)‖), sq_nonneg (‖B 1 0 (delta 0)‖),sq_nonneg (‖B 0 1 (delta 0)‖),sq_nonneg (‖B 1 1 (delta 0)‖)]
  have hz10 : ‖B 1 0 (delta 0)‖^2=0 := by nlinarith [sq_nonneg (‖B 1 0 (delta 0)‖), sq_nonneg (‖B 0 1 (delta 0)‖),sq_nonneg (‖B 1 1 (delta 0)‖)]
  have hz01 : ‖B 0 1 (delta 0)‖^2=0 := by nlinarith [sq_nonneg (‖B 0 1 (delta 0)‖), sq_nonneg (‖B 1 1 (delta 0)‖)]
  have hz11 : ‖B 1 1 (delta 0)‖^2=0 := by nlinarith
  apply norm_eq_zero.mp
  apply sq_eq_zero_iff.mp
  fin_cases i <;> fin_cases j
  all_goals first | exact hz00 | exact hz01 | exact hz10 | exact hz11

theorem continuous_periodic_nonneg_integral_zero (f : ℝ→ℝ) (hc : Continuous f)
    (hp : Function.Periodic f 1) (hn : ∀ x,0≤f x)
    (hi : (∫ x in (0 : ℝ)..1,f x)=0) (x : ℝ) : f x=0 := by
  have hint : (∫ t in (x-1/2)..(x-1/2+1),f t)=0 := by
    rw [hp.intervalIntegral_add_eq (x-1/2) 0]
    simpa only [zero_add] using hi
  have hae := (intervalIntegral.integral_eq_zero_iff_of_le_of_nonneg_ae
    (by linarith : x-1/2≤x-1/2+1) (Eventually.of_forall hn)
    (hc.intervalIntegrable (x-1/2) (x-1/2+1))).mp hint
  exact volume.eqOn_Ioc_of_ae_eq hae hc.continuousOn continuous_const.continuousOn
    (show x∈Ioc (x-1/2) (x-1/2+1) by constructor <;> linarith)

@[simp] theorem integerShift_star_delta_zero (k : ℤ) : star (integerShift k) (delta 0)=delta k := by
  apply lp.ext
  funext n
  simp [integerShift_star_apply,delta,lp.single_apply,Pi.single_apply,sub_eq_zero]

theorem physicalPhaseState_faithful_of_covariance (Φ : ℝ) (F : PhysicalPhaseAlgebra)
    (hp : Function.Periodic (fun θ => F θ) 1)
    (hcov : ∀ θ (k : ℤ) i j, F (θ+Φ*(k : ℝ)) i j=shiftConjugation k (F θ i j))
    (hz : (physicalPhaseState.functional (star F*F)).re=0) : F=0 := by
  let g := fun θ => (physicalCStarOriginTrace (star (F θ)*F θ)).re
  have hc : Continuous g := Complex.continuous_re.comp
    (physicalCStarOriginTrace.continuous.comp (F.continuous.star.mul F.continuous))
  have hgp : Function.Periodic g 1 := by
    intro θ
    change (physicalCStarOriginTrace (star (F (θ+1))*F (θ+1))).re=_
    have hh : F (θ+1)=F θ := hp θ
    rw [hh]
  have hgn (θ : ℝ) : 0≤g θ := physicalOriginSpinState.positive (F θ)
  have hgi : (∫ θ in (0 : ℝ)..1,g θ)=0 := by
    have hi := Complex.reCLM.intervalIntegral_comp_comm (μ := volume)
      (f := fun θ => physicalCStarOriginTrace ((star F*F) θ))
      ((physicalCStarOriginTrace.continuous.comp (star F*F).continuous).intervalIntegrable 0 1)
    change (∫ θ in (0 : ℝ)..1,g θ)=_ at hi
    rw [hi]
    exact hz
  have hg (θ : ℝ) : g θ=0 := continuous_periodic_nonneg_integral_zero g hc hgp hgn hgi θ
  have hsource (θ : ℝ) (i j : Fin 2) : F θ i j (delta 0)=0 :=
    physicalCStarOriginTrace_square_zero (F θ) (hg θ) i j
  have hbasis (θ : ℝ) (i j : Fin 2) (k : ℤ) : F θ i j (delta k)=0 := by
    have h := hsource (θ+Φ*(k : ℝ)) i j
    rw [hcov,shiftConjugation_apply,ContinuousLinearMap.mul_apply,ContinuousLinearMap.mul_apply,
      integerShift_star_delta_zero] at h
    have hh := congrArg (fun ψ : Hilbert => star (integerShift k) ψ) h
    simpa only [← ContinuousLinearMap.mul_apply,← mul_assoc,integerShift_star_mul,one_mul,
      ContinuousLinearMap.one_apply,map_zero] using hh
  apply BoundedContinuousFunction.ext
  intro θ
  apply CStarMatrix.ext
  intro i j
  apply lp.ext_continuousLinearMap (by norm_num : (2 : ENNReal)≠⊤)
  intro k
  apply ContinuousLinearMap.ext
  intro z
  have he : (lp.single 2 k z : Hilbert)=z • delta k := by simp [delta,← lp.single_smul]
  change F θ i j (lp.single 2 k z)=0
  rw [he,map_smul,hbasis,smul_zero]

theorem physicalWalkFamily_cfc_covariance (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (f : ℂ→ℂ) (hf : Continuous f) (θ : ℝ) (k : ℤ) :
    physicalMatrixShiftConjugation k
      (cfc f (cstarWalk (coupling a) (coupling r) Φ θ))=
      cfc f (cstarWalk (coupling a) (coupling r) Φ (θ+Φ*(k : ℝ))) := by
  have h := (physicalMatrixShiftConjugation k).map_cfc f
    (cstarWalk (coupling a) (coupling r) Φ θ) hf.continuousOn
    (continuous_physicalMatrixShiftConjugation k)
    (isStarNormal_of_mem_unitary (physicalCStarWalk_unitary a r Φ θ ha0 ha1 hr0 hr1))
    (by
      rw [cstarWalk_phase_covariance]
      exact isStarNormal_of_mem_unitary
        (physicalCStarWalk_unitary a r Φ (θ+Φ*(k : ℝ)) ha0 ha1 hr0 hr1))
  simpa only [cstarWalk_phase_covariance] using h

theorem physicalWalkFamily_cfc_faithful (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (f : ℂ→ℂ) (hf : Continuous f)
    (hz : (physicalPhaseState.functional
      (star (cfc f (physicalWalkFamily a r Φ ha0 ha1 hr0 hr1))*
        cfc f (physicalWalkFamily a r Φ ha0 ha1 hr0 hr1))).re=0) :
    cfc f (physicalWalkFamily a r Φ ha0 ha1 hr0 hr1)=0 := by
  apply physicalPhaseState_faithful_of_covariance Φ _ _ _ hz
  · intro θ
    dsimp only
    rw [physicalWalkFamily_cfc_apply _ _ _ _ _ _ _ _ hf,physicalWalkFamily_cfc_apply _ _ _ _ _ _ _ _ hf]
    have hw : cstarWalk (coupling a) (coupling r) Φ (θ+1)=cstarWalk (coupling a) (coupling r) Φ θ :=
      congrArg CStarMatrix.ofMatrix (walk_periodic (coupling a) (coupling r) Φ θ)
    rw [hw]
  · intro θ k i j
    rw [physicalWalkFamily_cfc_apply _ _ _ _ _ _ _ _ hf,physicalWalkFamily_cfc_apply _ _ _ _ _ _ _ _ hf]
    exact (congrArg (fun B : PhysicalMatrixAlgebra => B i j)
      (physicalWalkFamily_cfc_covariance a r Φ ha0 ha1 hr0 hr1 f hf θ k)).symm

end UAMO.PhysicalDOS

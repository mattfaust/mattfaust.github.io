import UAMO.ScalarThouless
import UAMO.CircleAngularLabels

noncomputable section
namespace UAMO
open MeasureTheory CircleDOS PhysicalDOS CMV Set

def scalarIDS (a r φ E : ℝ) : ℝ := (scalarRealSpectralMeasure a r φ).real (Iio E)

theorem physicalRealPartIDS_eq_scalarIDS {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ E : ℝ) :
    ((physicalUnitaryDOS a r Φ ha.le ha1 hr hr1).map Complex.re).real
      (Iio ((a/((1+a^2)*(1+r^2)))*E)) = scalarIDS a r (-Real.pi*Φ) E := by
  rw [physicalUnitaryDOS_realPart ha ha1 hr hr1 Φ,
    map_measureReal_apply
      (show Measurable (fun x : ℝ => (a/((1+a^2)*(1+r^2)))*x) from
        (continuous_const.mul continuous_id).measurable) measurableSet_Iio]
  have hκ : 0 < a/((1+a^2)*(1+r^2)) := by positivity
  have he : (fun x : ℝ => (a/((1+a^2)*(1+r^2)))*x) ⁻¹'
      Iio ((a/((1+a^2)*(1+r^2)))*E) = Iio E := by
    ext x
    simp only [mem_preimage, mem_Iio]
    constructor <;> intro h <;> nlinarith
  rw [he]
  rfl

theorem physicalUnitaryDOS_upper_label {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ E : ℝ) :
    (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1).real
      (upperArc ((a/((1+a^2)*(1+r^2)))*E)) =
        (1-scalarIDS a r (-Real.pi*Φ) E)/2 := by
  letI := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 Φ
  rw [circle_upperArc_mass _
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1)
    (physicalUnitaryDOS_conj_invariant a r Φ ha.le ha1 hr hr1),
    physicalRealPartIDS_eq_scalarIDS ha ha1 hr hr1 Φ E]

theorem physicalUnitaryDOS_lower_label {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) (Φ E : ℝ) :
    (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1).real
      (lowerArc ((a/((1+a^2)*(1+r^2)))*E)) =
        (1+scalarIDS a r (-Real.pi*Φ) E)/2 := by
  letI := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 Φ
  rw [circle_lowerArc_mass _
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1)
    (physicalUnitaryDOS_conj_invariant a r Φ ha.le ha1 hr hr1),
    physicalRealPartIDS_eq_scalarIDS ha ha1 hr hr1 Φ E]

end UAMO

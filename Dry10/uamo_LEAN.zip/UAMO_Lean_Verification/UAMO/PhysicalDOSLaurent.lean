import UAMO.PhysicalPhaseSpectrum
import UAMO.CanonicalTrace
import Mathlib.Analysis.SpecialFunctions.Integrals

noncomputable section
namespace UAMO.PhysicalDOS
open PhysicalRepresentation MeasureTheory
open scoped InnerProductSpace

def phaseCharacter (θ : ℝ) (k : ℤ) : ℂ :=
  Complex.exp (((2 * Real.pi * (k : ℝ) * θ : ℝ) : ℂ) * Complex.I)

def translationAngle (φ : ℝ) (ν : MagneticSite) (n : ℤ) : ℝ :=
  Real.pi / 2 * (2 * (ν.2 : ℝ) - (ν.1 : ℝ)) -
    φ * (ν.2 : ℝ) * (1 + 2 * (n : ℝ) - (ν.2 : ℝ) + (ν.1 : ℝ))

def physicalMagneticShift (φ θ : ℝ) (ν : MagneticSite) : Operator :=
  phaseCharacter θ ν.2 •
    ((phaseEquiv (translationAngle φ ν) : Operator) * integerShift (ν.1 - ν.2))

theorem physicalMagneticShift_apply (φ θ : ℝ) (ν : MagneticSite) (ψ : Hilbert) (n : ℤ) :
    physicalMagneticShift φ θ ν ψ n = phaseCharacter θ ν.2 *
      Complex.exp (((translationAngle φ ν n : ℝ) : ℂ) * Complex.I) * ψ (n + (ν.1 - ν.2)) := by
  simp only [physicalMagneticShift, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.mul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  change phaseCharacter θ ν.2 *
    (Complex.exp ((translationAngle φ ν n : ℂ) * Complex.I) * ψ (n + (ν.1 - ν.2))) = _
  rw [mul_assoc]

theorem continuous_physicalMagneticShift (φ : ℝ) (ν : MagneticSite) :
    Continuous (fun θ : ℝ => physicalMagneticShift φ θ ν) := by
  unfold physicalMagneticShift phaseCharacter
  fun_prop

theorem physicalMagneticShift_zero (φ θ : ℝ) : physicalMagneticShift φ θ 0 = 1 := by
  ext ψ n
  simp [physicalMagneticShift_apply, phaseCharacter, translationAngle]

theorem physicalMagneticShift_mul (φ θ : ℝ) (ν μ : MagneticSite) :
    physicalMagneticShift φ θ ν * physicalMagneticShift φ θ μ =
      latticePhase φ (wedge ν μ) • physicalMagneticShift φ θ (ν + μ) := by
  ext ψ n
  simp only [ContinuousLinearMap.mul_apply, physicalMagneticShift_apply,
    ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul,
    Prod.fst_add, Prod.snd_add]
  have hi : n + (ν.1 - ν.2) + (μ.1 - μ.2) = n + (ν.1 + μ.1 - (ν.2 + μ.2)) := by omega
  rw [hi]
  simp only [← mul_assoc]
  congr 1
  unfold phaseCharacter translationAngle latticePhase wedge
  simp only [Prod.fst_add, Prod.snd_add, ← Complex.exp_add]
  congr 1
  push_cast
  ring

theorem physicalMagneticShift_unitary (φ θ : ℝ) (ν : MagneticSite) :
    physicalMagneticShift φ θ ν ∈ unitary Operator := by
  have hp : (phaseEquiv (translationAngle φ ν) : Operator) ∈ unitary Operator :=
    (unitary.linearIsometryEquiv.symm (phaseEquiv (translationAngle φ ν))).property
  have hs : integerShift (ν.1 - ν.2) ∈ unitary Operator :=
    unitary.mem_iff.mpr ⟨integerShift_star_mul _, integerShift_mul_star _⟩
  have hc : star (phaseCharacter θ ν.2) * phaseCharacter θ ν.2 = 1 := by
    change (starRingEnd ℂ) (phaseCharacter θ ν.2) * phaseCharacter θ ν.2 = 1
    rw [← Complex.normSq_eq_conj_mul_self, Complex.normSq_eq_norm_sq]
    have hn : ‖phaseCharacter θ ν.2‖ = 1 := Complex.norm_exp_ofReal_mul_I _
    rw [hn]
    norm_num
  have hcs : phaseCharacter θ ν.2 * star (phaseCharacter θ ν.2) = 1 := by rw [mul_comm]; exact hc
  have hprod := (unitary Operator).mul_mem hp hs
  apply unitary.mem_iff.mpr
  simp only [physicalMagneticShift, star_smul, smul_mul_assoc, mul_smul_comm,
    smul_smul, unitary.star_mul_self_of_mem hprod, unitary.mul_star_self_of_mem hprod,
    hc, hcs, one_smul, and_self]

theorem physicalMagneticShift_star (φ θ : ℝ) (ν : MagneticSite) :
    star (physicalMagneticShift φ θ ν) = physicalMagneticShift φ θ (-ν) := by
  have hinv : physicalMagneticShift φ θ ν * physicalMagneticShift φ θ (-ν) = 1 := by
    rw [physicalMagneticShift_mul]
    have hw : wedge ν (-ν) = 0 := by simp [wedge]; ring
    simp [hw, physicalMagneticShift_zero]
  calc
    _ = star (physicalMagneticShift φ θ ν) *
        (physicalMagneticShift φ θ ν * physicalMagneticShift φ θ (-ν)) := by rw [hinv, mul_one]
    _ = physicalMagneticShift φ θ (-ν) := by
      rw [← mul_assoc, unitary.star_mul_self_of_mem (physicalMagneticShift_unitary φ θ ν), one_mul]

def physicalOriginTrace : Operator →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun B => B (delta 0) 0
      map_add' := by intro B C; simp
      map_smul' := by intro c B; simp }
    1 (fun B => by
      calc
        ‖B (delta 0) 0‖ ≤ ‖B (delta 0)‖ := lp.norm_apply_le_norm (by norm_num) _ _
        _ ≤ ‖B‖ * ‖delta 0‖ := B.le_opNorm _
        _ = 1 * ‖B‖ := by simp [delta, lp.norm_single])

@[simp] theorem physicalOriginTrace_apply (B : Operator) : physicalOriginTrace B = B (delta 0) 0 := rfl

theorem phaseCharacter_integral (k : ℤ) :
    (∫ θ in (0 : ℝ)..1, phaseCharacter θ k) = if k = 0 then 1 else 0 := by
  by_cases hk : k = 0
  · subst k
    simp [phaseCharacter]
  · rw [if_neg hk]
    have hc : (k : ℂ) * (2 * Real.pi * Complex.I) ≠ 0 := by
      exact mul_ne_zero (Int.cast_ne_zero.mpr hk)
        (mul_ne_zero (mul_ne_zero (by norm_num) (Complex.ofReal_ne_zero.mpr Real.pi_ne_zero)) Complex.I_ne_zero)
    have hf : (fun θ : ℝ => phaseCharacter θ k) =
        (fun θ : ℝ => Complex.exp (((k : ℂ) * (2 * Real.pi * Complex.I)) * θ)) := by
      funext θ
      unfold phaseCharacter
      congr 1
      push_cast
      ring
    rw [hf, integral_exp_mul_complex hc]
    simp only [Complex.ofReal_one, mul_one, Complex.ofReal_zero, mul_zero, Complex.exp_zero]
    rw [Complex.exp_int_mul_two_pi_mul_I, sub_self, zero_div]

theorem physicalMagneticShift_average_trace (φ : ℝ) (ν : MagneticSite) :
    (∫ θ in (0 : ℝ)..1, physicalOriginTrace (physicalMagneticShift φ θ ν)) =
      rootTrace (magneticShift φ ν) := by
  rw [rootTrace_magneticShift]
  by_cases hdiag : ν.1 = ν.2
  · have hcoord : ν.1 - ν.2 = 0 := sub_eq_zero.mpr hdiag
    simp only [physicalOriginTrace_apply, physicalMagneticShift_apply, zero_add,
      delta, lp.single_apply, hcoord, Pi.single_eq_same, mul_one]
    rw [intervalIntegral.integral_mul_const, phaseCharacter_integral]
    by_cases hk : ν.2 = 0
    · have hν : ν = 0 := Prod.ext (hdiag.trans hk) hk
      subst ν
      simp [translationAngle]
    · have hν : ν ≠ 0 := fun h => hk (congrArg Prod.snd h)
      simp [hk, hν]
  · have hcoord : ν.1 - ν.2 ≠ 0 := sub_ne_zero.mpr hdiag
    have hν : ν ≠ 0 := by intro h; apply hdiag; simp [h]
    simp [physicalOriginTrace_apply, physicalMagneticShift_apply, delta,
      lp.single_apply, Pi.single_apply, hcoord, hν]

theorem physicalMagneticShift_U (φ θ : ℝ) :
    physicalMagneticShift φ θ (-1, 0) = Complex.I • shift := by
  ext ψ n
  simp [physicalMagneticShift_apply, phaseCharacter, translationAngle,
    Complex.exp_pi_div_two_mul_I, sub_eq_add_neg]

theorem physicalMagneticShift_V (Φ θ : ℝ) :
    latticePhase (-Real.pi * Φ) 1 • physicalMagneticShift (-Real.pi * Φ) θ (1, 1) =
      Complex.I • phase Φ θ := by
  ext ψ n
  simp only [ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul,
    physicalMagneticShift_apply, phase_apply, sub_self, add_zero]
  have he : latticePhase (-Real.pi * Φ) 1 *
      (phaseCharacter θ 1 * Complex.exp ((translationAngle (-Real.pi * Φ) (1, 1) n : ℂ) * Complex.I)) =
      Complex.I * phaseValue Φ θ n := by
    calc
      _ = Complex.exp ((Real.pi : ℂ) / 2 * Complex.I) * phaseValue Φ θ n := by
        unfold latticePhase phaseCharacter translationAngle phaseValue phaseAngle
        simp only [← Complex.exp_add]
        congr 1
        push_cast
        ring
      _ = _ := by rw [Complex.exp_pi_div_two_mul_I]
  simpa only [mul_assoc] using congrArg (fun c : ℂ => c * ψ n) he

end UAMO.PhysicalDOS

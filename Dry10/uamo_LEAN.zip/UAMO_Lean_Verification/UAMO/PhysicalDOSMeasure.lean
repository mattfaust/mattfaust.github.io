import UAMO.PhysicalDOSMeasureState
import UAMO.CircleMomentDeterminacy

noncomputable section
namespace UAMO.PhysicalDOS
open MeasureTheory PhysicalRepresentation SourceSpectral
open scoped ContinuousFunctionalCalculus

attribute [local instance] physicalDOSMatrix_nontrivial

local instance physicalPhaseCFC :
    ContinuousFunctionalCalculus ℂ PhysicalPhaseAlgebra IsStarNormal :=
  @IsStarNormal.instContinuousFunctionalCalculus PhysicalPhaseAlgebra inferInstance

def physicalUnitaryDOS (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) : Measure ℂ :=
  SourceSpectral.complexMeasure physicalPhaseState (physicalWalkFamily a r Φ ha0 ha1 hr0 hr1)
    (isStarNormal_of_mem_unitary (physicalWalkFamily_unitary a r Φ ha0 ha1 hr0 hr1))

instance physicalUnitaryDOS_isProbabilityMeasure (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    IsProbabilityMeasure (physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1) := by
  unfold physicalUnitaryDOS
  infer_instance

theorem physicalUnitaryDOS_ae_circle (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    ∀ᵐ z ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1, ‖z‖ = 1 :=
  SourceSpectral.complexMeasure_ae_circle _ _ _
    (physicalWalkFamily_unitary a r Φ ha0 ha1 hr0 hr1)

def physicalPhaseEvaluation (θ : ℝ) : PhysicalPhaseAlgebra →⋆ₐ[ℂ] PhysicalMatrixAlgebra where
  toFun F := F θ
  map_one' := rfl
  map_zero' := rfl
  map_add' _ _ := rfl
  map_mul' _ _ := rfl
  commutes' _ := rfl
  map_star' _ := rfl

theorem physicalWalkFamily_cfc_apply (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (f : ℂ → ℂ) (hf : Continuous f) (θ : ℝ) :
    cfc f (physicalWalkFamily a r Φ ha0 ha1 hr0 hr1) θ =
      cfc f (cstarWalk (coupling a) (coupling r) Φ θ) := by
  exact (physicalPhaseEvaluation θ).map_cfc f _ hf.continuousOn
    (BoundedContinuousFunction.evalCLM ℂ θ).continuous
    (isStarNormal_of_mem_unitary (physicalWalkFamily_unitary a r Φ ha0 ha1 hr0 hr1))
    (isStarNormal_of_mem_unitary (physicalCStarWalk_unitary a r Φ θ ha0 ha1 hr0 hr1))

theorem physicalUnitaryDOS_integral (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (f : ℂ → ℂ) (hf : Continuous f) :
    ∫ z, f z ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 =
      ∫ θ in (0 : ℝ)..1, physicalCStarOriginTrace
        (cfc f (cstarWalk (coupling a) (coupling r) Φ θ)) := by
  rw [physicalUnitaryDOS, SourceSpectral.complexMeasure_integral_cfc _ _ _ f hf,
    physicalPhaseState_apply]
  apply intervalIntegral.integral_congr
  intro θ _
  exact congrArg physicalCStarOriginTrace
    (physicalWalkFamily_cfc_apply a r Φ ha0 ha1 hr0 hr1 f hf θ)

theorem physicalCStarWalk_power_trace (a r Φ θ : ℝ) (n : ℕ) :
    physicalCStarOriginTrace (cstarWalk (coupling a) (coupling r) Φ θ ^ n) =
      physicalMatrixOriginTrace (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) := by
  have hc : cstarWalk (coupling a) (coupling r) Φ θ ^ n =
      CStarMatrix.ofMatrix (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) :=
    (CStarMatrix.ofMatrixStarAlgEquiv.map_pow
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) n).symm
  rw [hc]
  rw [physicalCStarOriginTrace_apply]
  rfl

theorem physicalUnitaryDOS_moments (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (n : ℕ) :
    (∫ z : ℂ, z ^ n ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1) =
      magneticMatrixTrace (-Real.pi * Φ) (cstarMagneticWalk a r (-Real.pi * Φ) ^ n) := by
  rw [physicalUnitaryDOS, SourceSpectral.complexMeasure_moment, physicalPhaseState_apply]
  simp only [BoundedContinuousFunction.pow_apply, physicalWalkFamily_apply,
    physicalCStarWalk_power_trace]
  exact physical_walk_phase_averaged_moments a r Φ n

def magneticMatrixPositiveState (φ : ℝ) : PositiveState (MagneticMatrixAlgebra φ) where
  functional := magneticMatrixTrace φ
  normalized := magneticMatrixTrace_one φ
  star_preserving := magneticMatrixTrace_star φ
  positive := magneticMatrixTraceReal_star_mul_self_nonneg φ

theorem magneticUnitaryDOS_eq_positiveSource (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1 =
      SourceSpectral.complexMeasure (magneticMatrixPositiveState φ) (cstarMagneticWalk a r φ)
        (isStarNormal_of_mem_unitary (cstarMagneticWalk_unitary a r φ ha0 ha1 hr0 hr1)) := rfl

theorem magneticUnitaryDOS_complex_moments (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (n : ℕ) :
    (∫ z : ℂ, z ^ n ∂magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1) =
      magneticMatrixTrace φ (cstarMagneticWalk a r φ ^ n) := by
  rw [magneticUnitaryDOS_eq_positiveSource, SourceSpectral.complexMeasure_moment]
  rfl

theorem physicalUnitaryDOS_eq_magnetic (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 =
      magneticUnitaryDOS a r (-Real.pi * Φ) ha0 ha1 hr0 hr1 := by
  apply CircleDOS.circleProbabilityMeasure_eq_of_moments
    _ _ (physicalUnitaryDOS_ae_circle a r Φ ha0 ha1 hr0 hr1)
    (magneticUnitaryDOS_ae_circle a r (-Real.pi * Φ) ha0 ha1 hr0 hr1)
  intro n
  rw [physicalUnitaryDOS_moments, magneticUnitaryDOS_complex_moments]

end UAMO.PhysicalDOS

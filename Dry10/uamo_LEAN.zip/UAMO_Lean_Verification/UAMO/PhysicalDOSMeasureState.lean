import UAMO.PositiveSourceSpectralMeasure
import UAMO.PhysicalDOSWalkMoments
import Mathlib.Analysis.CStarAlgebra.ContinuousMap

noncomputable section
namespace UAMO.PhysicalDOS
open MeasureTheory PhysicalRepresentation SourceSpectral
open scoped InnerProductSpace

section PhaseAverage
variable {A : Type*} [CStarAlgebra A]

def phaseAverageFunctional (τ : PositiveState A) : (BoundedContinuousFunction ℝ A) →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun F => ∫ θ in (0 : ℝ)..1, τ.functional (F θ)
      map_add' := by
        intro F G
        simp only [BoundedContinuousFunction.add_apply, map_add]
        exact intervalIntegral.integral_add
          ((τ.functional.continuous.comp F.continuous).intervalIntegrable 0 1)
          ((τ.functional.continuous.comp G.continuous).intervalIntegrable 0 1)
      map_smul' := by
        intro c F
        simp only [BoundedContinuousFunction.smul_apply, map_smul]
        exact intervalIntegral.integral_smul c _ }
    ‖τ.functional‖ (fun F => by
      have hb := intervalIntegral.norm_integral_le_of_norm_le_const
        (a := (0 : ℝ)) (b := 1) (C := ‖τ.functional‖ * ‖F‖)
        (f := fun θ => τ.functional (F θ)) (fun θ _ =>
          (τ.functional.le_opNorm (F θ)).trans
            (mul_le_mul_of_nonneg_left (F.norm_coe_le_norm θ) (norm_nonneg _)))
      simpa using hb)

@[simp] theorem phaseAverageFunctional_apply (τ : PositiveState A) (F : BoundedContinuousFunction ℝ A) :
    phaseAverageFunctional τ F = ∫ θ in (0 : ℝ)..1, τ.functional (F θ) := rfl

theorem phaseAverageFunctional_one (τ : PositiveState A) : phaseAverageFunctional τ 1 = 1 := by
  simp [phaseAverageFunctional_apply, τ.normalized]

theorem phaseAverageFunctional_star (τ : PositiveState A) (F : BoundedContinuousFunction ℝ A) :
    phaseAverageFunctional τ (star F) = star (phaseAverageFunctional τ F) := by
  simp only [phaseAverageFunctional_apply, BoundedContinuousFunction.star_apply, τ.star_preserving]
  exact Complex.conjCLE.toContinuousLinearMap.intervalIntegral_comp_comm
    ((τ.functional.continuous.comp F.continuous).intervalIntegrable 0 1)

theorem phaseAverageFunctional_positive (τ : PositiveState A) (F : BoundedContinuousFunction ℝ A) :
    0 ≤ (phaseAverageFunctional τ (star F * F)).re := by
  rw [phaseAverageFunctional_apply]
  change 0 ≤ Complex.reCLM (∫ θ in (0 : ℝ)..1, τ.functional ((star F * F) θ))
  rw [← Complex.reCLM.intervalIntegral_comp_comm
    (f := fun θ => τ.functional ((star F * F) θ))
    ((τ.functional.continuous.comp (star F * F).continuous).intervalIntegrable 0 1)]
  apply intervalIntegral.integral_nonneg_of_forall (by norm_num)
  intro θ
  exact τ.positive (F θ)

def phaseAverageState (τ : PositiveState A) : PositiveState (BoundedContinuousFunction ℝ A) where
  functional := phaseAverageFunctional τ
  normalized := phaseAverageFunctional_one τ
  star_preserving := phaseAverageFunctional_star τ
  positive := phaseAverageFunctional_positive τ

end PhaseAverage

theorem physicalOriginTrace_eq_inner (B : Operator) :
    physicalOriginTrace B = ⟪delta 0, B (delta 0)⟫_ℂ := by
  simp [physicalOriginTrace_apply, delta, lp.inner_single_left]

theorem physicalOriginTrace_one : physicalOriginTrace (1 : Operator) = 1 := by
  simp [physicalOriginTrace_apply, delta, lp.single_apply]

theorem physicalOriginTrace_star (B : Operator) :
    physicalOriginTrace (star B) = star (physicalOriginTrace B) := by
  rw [physicalOriginTrace_eq_inner, physicalOriginTrace_eq_inner]
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  exact (inner_conj_symm _ _).symm

theorem physicalOriginTrace_positive (B : Operator) :
    0 ≤ (physicalOriginTrace (star B * B)).re := by
  rw [physicalOriginTrace_eq_inner]
  change 0 ≤ (⟪delta 0, star B (B (delta 0))⟫_ℂ).re
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  exact inner_self_nonneg (𝕜 := ℂ)

abbrev PhysicalMatrixAlgebra := CStarMatrix (Fin 2) (Fin 2) Operator

def physicalCStarOriginTrace : PhysicalMatrixAlgebra →L[ℂ] ℂ :=
  normalizedMatrixTrace₂ physicalOriginTrace

theorem physicalCStarOriginTrace_apply (B : PhysicalMatrixAlgebra) :
    physicalCStarOriginTrace B = (physicalOriginTrace (B 0 0) + physicalOriginTrace (B 1 1)) / 2 :=
  normalizedMatrixTrace₂_apply _ _

def physicalOriginSpinState : PositiveState PhysicalMatrixAlgebra where
  functional := physicalCStarOriginTrace
  normalized := normalizedMatrixTrace₂_one _ physicalOriginTrace_one
  star_preserving := by
    intro B
    simp only [physicalCStarOriginTrace_apply, cstarMatrix_star_apply, physicalOriginTrace_star,
      star_div₀, star_add, star_ofNat]
  positive := normalizedMatrixTrace₂_nonneg _ physicalOriginTrace_positive

local instance physicalDOSMatrix_nontrivial : Nontrivial PhysicalMatrixAlgebra := by
  apply nontrivial_of_ne (0 : PhysicalMatrixAlgebra) 1
  intro h
  have hh := congrArg physicalCStarOriginTrace h
  rw [map_zero, show physicalCStarOriginTrace 1 = 1 from physicalOriginSpinState.normalized] at hh
  exact zero_ne_one hh

abbrev PhysicalPhaseAlgebra := BoundedContinuousFunction ℝ PhysicalMatrixAlgebra

def physicalPhaseState : PositiveState PhysicalPhaseAlgebra := phaseAverageState physicalOriginSpinState

theorem physicalPhaseState_apply (F : PhysicalPhaseAlgebra) :
    physicalPhaseState.functional F =
      ∫ θ in (0 : ℝ)..1, physicalCStarOriginTrace (F θ) := rfl

theorem physicalCStarWalk_unitary (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    cstarWalk (coupling a) (coupling r) Φ θ ∈ unitary PhysicalMatrixAlgebra :=
  unitary.map_mem CStarMatrix.ofMatrixStarAlgEquiv
    (PhysicalWalk.walk_unitary_stereographic a r ha0 ha1 hr0 hr1 _ _
      shift_unitary (phase_unitary Φ θ))

def physicalWalkFamily (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) : PhysicalPhaseAlgebra :=
  BoundedContinuousFunction.ofNormedAddCommGroup
    (cstarWalk (coupling a) (coupling r) Φ)
    (continuous_cstarWalk _ _ _) 1
    (fun θ => (CStarRing.norm_of_mem_unitary (physicalCStarWalk_unitary a r Φ θ ha0 ha1 hr0 hr1)).le)

@[simp] theorem physicalWalkFamily_apply (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (θ : ℝ) :
    physicalWalkFamily a r Φ ha0 ha1 hr0 hr1 θ =
      cstarWalk (coupling a) (coupling r) Φ θ := rfl

theorem physicalWalkFamily_unitary (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    physicalWalkFamily a r Φ ha0 ha1 hr0 hr1 ∈ unitary PhysicalPhaseAlgebra := by
  apply unitary.mem_iff.mpr
  constructor
  · apply BoundedContinuousFunction.ext
    intro θ
    exact unitary.star_mul_self_of_mem (physicalCStarWalk_unitary a r Φ θ ha0 ha1 hr0 hr1)
  · apply BoundedContinuousFunction.ext
    intro θ
    exact unitary.mul_star_self_of_mem (physicalCStarWalk_unitary a r Φ θ ha0 ha1 hr0 hr1)

end UAMO.PhysicalDOS

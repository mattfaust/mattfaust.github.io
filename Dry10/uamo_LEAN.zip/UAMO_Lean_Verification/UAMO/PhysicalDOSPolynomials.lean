import UAMO.PhysicalDOSLaurent
import UAMO.MagneticWalkSpectrum

noncomputable section
namespace UAMO.PhysicalDOS
open PhysicalRepresentation MeasureTheory

abbrev PairedOperator := MagneticOperator × (ℝ → Operator)

def pairedShift (φ : ℝ) (ν : MagneticSite) : PairedOperator :=
  (magneticShift φ ν, fun θ => physicalMagneticShift φ θ ν)

theorem pairedShift_zero (φ : ℝ) : pairedShift φ 0 = 1 := by
  apply Prod.ext
  · exact magneticShift_zero φ
  · funext θ
    exact physicalMagneticShift_zero φ θ

theorem pairedShift_mul (φ : ℝ) (ν μ : MagneticSite) :
    pairedShift φ ν * pairedShift φ μ = latticePhase φ (wedge ν μ) • pairedShift φ (ν + μ) := by
  apply Prod.ext
  · exact magneticShift_mul φ ν μ
  · funext θ
    exact physicalMagneticShift_mul φ θ ν μ

theorem pairedShift_star (φ : ℝ) (ν : MagneticSite) :
    star (pairedShift φ ν) = pairedShift φ (-ν) := by
  apply Prod.ext
  · exact magneticShift_star φ ν
  · funext θ
    exact physicalMagneticShift_star φ θ ν

def pairedLaurentSpace (φ : ℝ) : Submodule ℂ PairedOperator :=
  Submodule.span ℂ (Set.range (pairedShift φ))

theorem pairedShift_mem (φ : ℝ) (ν : MagneticSite) : pairedShift φ ν ∈ pairedLaurentSpace φ :=
  Submodule.subset_span (Set.mem_range_self ν)

theorem pairedLaurentSpace_one_mem (φ : ℝ) : (1 : PairedOperator) ∈ pairedLaurentSpace φ := by
  rw [← pairedShift_zero φ]
  exact pairedShift_mem φ 0

theorem pairedLaurentSpace_mul_mem (φ : ℝ) {B C : PairedOperator}
    (hB : B ∈ pairedLaurentSpace φ) (hC : C ∈ pairedLaurentSpace φ) :
    B * C ∈ pairedLaurentSpace φ := by
  induction hB, hC using Submodule.span_induction₂ with
  | mem_mem B C hB hC =>
    obtain ⟨ν, rfl⟩ := hB
    obtain ⟨μ, rfl⟩ := hC
    rw [pairedShift_mul]
    exact (pairedLaurentSpace φ).smul_mem _ (pairedShift_mem φ (ν + μ))
  | zero_left C hC => simp
  | zero_right B hB => simp
  | add_left B D C hB hD hC ihB ihD => simpa only [add_mul] using (pairedLaurentSpace φ).add_mem ihB ihD
  | add_right B C D hB hC hD ihC ihD => simpa only [mul_add] using (pairedLaurentSpace φ).add_mem ihC ihD
  | smul_left c B C hB hC ih => simpa only [smul_mul_assoc] using (pairedLaurentSpace φ).smul_mem c ih
  | smul_right c B C hB hC ih => simpa only [mul_smul_comm] using (pairedLaurentSpace φ).smul_mem c ih

theorem pairedLaurentSpace_star_mem (φ : ℝ) {B : PairedOperator}
    (hB : B ∈ pairedLaurentSpace φ) : star B ∈ pairedLaurentSpace φ := by
  induction hB using Submodule.span_induction with
  | mem B hB =>
    obtain ⟨ν, rfl⟩ := hB
    rw [pairedShift_star]
    exact pairedShift_mem φ (-ν)
  | zero => simp
  | add B C hB hC ihB ihC => simpa only [star_add] using (pairedLaurentSpace φ).add_mem ihB ihC
  | smul c B hB ih => simpa only [star_smul] using (pairedLaurentSpace φ).smul_mem (star c) ih

theorem pairedLaurentSpace_continuous (φ : ℝ) {B : PairedOperator}
    (hB : B ∈ pairedLaurentSpace φ) : Continuous B.2 := by
  induction hB using Submodule.span_induction with
  | mem B hB =>
    obtain ⟨ν, rfl⟩ := hB
    exact continuous_physicalMagneticShift φ ν
  | zero => exact continuous_const
  | add B C hB hC ihB ihC => exact ihB.add ihC
  | smul c B hB ih => exact ih.const_smul c

theorem pairedLaurentSpace_average_trace (φ : ℝ) {B : PairedOperator}
    (hB : B ∈ pairedLaurentSpace φ) :
    (∫ θ in (0 : ℝ)..1, physicalOriginTrace (B.2 θ)) = rootTrace B.1 := by
  induction hB using Submodule.span_induction with
  | mem B hB =>
    obtain ⟨ν, rfl⟩ := hB
    exact physicalMagneticShift_average_trace φ ν
  | zero => simp
  | add B C hB hC ihB ihC =>
    change (∫ θ in (0 : ℝ)..1, physicalOriginTrace (B.2 θ + C.2 θ)) = rootTrace (B.1 + C.1)
    simp_rw [map_add]
    rw [intervalIntegral.integral_add (f := fun θ => physicalOriginTrace (B.2 θ))
      (g := fun θ => physicalOriginTrace (C.2 θ))
      ((physicalOriginTrace.continuous.comp (pairedLaurentSpace_continuous φ hB)).intervalIntegrable 0 1)
      ((physicalOriginTrace.continuous.comp (pairedLaurentSpace_continuous φ hC)).intervalIntegrable 0 1),
      ihB, ihC]
  | smul c B hB ih =>
    change (∫ θ in (0 : ℝ)..1, physicalOriginTrace (c • B.2 θ)) = rootTrace (c • B.1)
    simp only [map_smul]
    rw [intervalIntegral.integral_smul, ih]

def pairedLaurentAlgebra (φ : ℝ) : StarSubalgebra ℂ PairedOperator where
  carrier := pairedLaurentSpace φ
  zero_mem' := (pairedLaurentSpace φ).zero_mem
  one_mem' := pairedLaurentSpace_one_mem φ
  add_mem' := (pairedLaurentSpace φ).add_mem
  mul_mem' := pairedLaurentSpace_mul_mem φ
  algebraMap_mem' := by
    intro c
    rw [Algebra.algebraMap_eq_smul_one]
    exact (pairedLaurentSpace φ).smul_mem c (pairedLaurentSpace_one_mem φ)
  star_mem' := pairedLaurentSpace_star_mem φ

def magneticEvaluation (φ : ℝ) : pairedLaurentAlgebra φ →⋆ₐ[ℂ] MagneticOperator where
  toFun B := B.val.1
  map_one' := rfl
  map_zero' := rfl
  map_mul' _ _ := rfl
  map_add' _ _ := rfl
  commutes' _ := rfl
  map_star' _ := rfl

def physicalEvaluation (φ θ : ℝ) : pairedLaurentAlgebra φ →⋆ₐ[ℂ] Operator where
  toFun B := B.val.2 θ
  map_one' := rfl
  map_zero' := rfl
  map_mul' _ _ := rfl
  map_add' _ _ := rfl
  commutes' _ := rfl
  map_star' _ := rfl

theorem pairedLaurentAlgebra_average_trace (φ : ℝ) (B : pairedLaurentAlgebra φ) :
    (∫ θ in (0 : ℝ)..1, physicalOriginTrace (physicalEvaluation φ θ B)) =
      rootTrace (magneticEvaluation φ B) :=
  pairedLaurentSpace_average_trace φ B.property

def pairedWalkU (φ : ℝ) : pairedLaurentAlgebra φ :=
  ⟨(-Complex.I) • pairedShift φ (-1, 0),
    (pairedLaurentSpace φ).smul_mem _ (pairedShift_mem φ (-1, 0))⟩

def pairedWalkV (φ : ℝ) : pairedLaurentAlgebra φ :=
  ⟨(-Complex.I * latticePhase φ 1) • pairedShift φ (1, 1),
    (pairedLaurentSpace φ).smul_mem _ (pairedShift_mem φ (1, 1))⟩

theorem magneticEvaluation_pairedWalkU (φ : ℝ) :
    magneticEvaluation φ (pairedWalkU φ) = (-Complex.I) • magneticU φ := rfl

theorem magneticEvaluation_pairedWalkV (φ : ℝ) :
    magneticEvaluation φ (pairedWalkV φ) = (-Complex.I) • magneticV φ := by
  change (-Complex.I * latticePhase φ 1) • magneticShift φ (1, 1) =
    (-Complex.I) • (latticePhase φ 1 • magneticShift φ (1, 1))
  rw [smul_smul]

theorem physicalEvaluation_pairedWalkU (φ θ : ℝ) :
    physicalEvaluation φ θ (pairedWalkU φ) = shift := by
  change (-Complex.I) • physicalMagneticShift φ θ (-1, 0) = shift
  rw [physicalMagneticShift_U, smul_smul]
  simp

theorem physicalEvaluation_pairedWalkV (Φ θ : ℝ) :
    physicalEvaluation (-Real.pi * Φ) θ (pairedWalkV (-Real.pi * Φ)) = phase Φ θ := by
  change (-Complex.I * latticePhase (-Real.pi * Φ) 1) •
    physicalMagneticShift (-Real.pi * Φ) θ (1, 1) = phase Φ θ
  rw [← smul_smul, physicalMagneticShift_V, smul_smul]
  simp

end UAMO.PhysicalDOS

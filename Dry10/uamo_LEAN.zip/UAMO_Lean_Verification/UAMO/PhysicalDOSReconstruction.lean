import UAMO.PhysicalDOSMeasure
import UAMO.MagneticLogPotential

noncomputable section
namespace UAMO.PhysicalDOS
open MeasureTheory
open scoped ENNReal

theorem physicalUnitaryDOS_realPart {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (Φ : ℝ) :
    (physicalUnitaryDOS a r Φ ha.le ha1 hr0 hr1).map Complex.re =
      (scalarRealSpectralMeasure a r (-Real.pi*Φ)).map
        (fun E : ℝ => (a/((1+a^2)*(1+r^2)))*E) := by
  rw [physicalUnitaryDOS_eq_magnetic]
  exact magneticUnitaryDOS_realPart ha ha1 hr0 hr1 (-Real.pi*Φ)

theorem physicalUnitaryDOS_conj_invariant (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1).map star =
      physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 := by
  rw [physicalUnitaryDOS_eq_magnetic]
  exact magneticUnitaryDOS_conj_invariant a r (-Real.pi*Φ) ha0 ha1 hr0 hr1

theorem physicalUnitaryDOS_total_log_identity {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (Φ E : ℝ) (z : ℂ) (hz : ‖z‖ = 1)
    (hzre : z.re = (a/((1+a^2)*(1+r^2)))*E) :
    (2 : EReal)*CircleDOS.circleTotalPotential
      (physicalUnitaryDOS a r Φ ha.le ha1 hr0 hr1) z =
      (Real.log (2*a/((1+a^2)*(1+r^2))) : EReal) +
        scalarTotalLogPotential a (-Real.pi*Φ) (r,E) := by
  rw [physicalUnitaryDOS_eq_magnetic]
  exact magneticUnitaryDOS_total_log_identity ha ha1 hr0 hr1 (-Real.pi*Φ) E z hz hzre

end UAMO.PhysicalDOS

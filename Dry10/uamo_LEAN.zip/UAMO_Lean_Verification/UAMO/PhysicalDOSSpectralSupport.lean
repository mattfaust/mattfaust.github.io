import UAMO.PhysicalDOSFaithfulness
import UAMO.PhysicalDOSConcentration

noncomputable section
namespace UAMO.PhysicalDOS
open MeasureTheory PhysicalRepresentation SourceSpectral Set Filter
open scoped Topology ContinuousFunctionalCalculus

attribute [local instance] physicalDOSMatrix_nontrivial
local instance physicalSupportPhaseCFC :
    ContinuousFunctionalCalculus ℂ PhysicalPhaseAlgebra IsStarNormal :=
  @IsStarNormal.instContinuousFunctionalCalculus PhysicalPhaseAlgebra inferInstance

def physicalSpectralBump (z : ℂ) (ε : ℝ) (w : ℂ) : ℂ :=
  (max 0 (ε-‖w-z‖) : ℝ)

theorem continuous_physicalSpectralBump (z : ℂ) (ε : ℝ) :
    Continuous (physicalSpectralBump z ε) := by
  unfold physicalSpectralBump
  fun_prop

theorem physicalUnitaryDOS_ball_pos_of_mem_spectrum (a r Φ θ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    {z : ℂ} (hz : z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ))
    {ε : ℝ} (hε : 0<ε) :
    0 < physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 (Metric.ball z ε) := by
  by_contra hp
  have hmass : physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 (Metric.ball z ε)=0 :=
    le_antisymm (le_of_not_gt hp) (zero_le _)
  have hout : ∀ᵐ w ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1, w ∉ Metric.ball z ε := by
    apply ae_iff.mpr
    simpa only [not_not, setOf_mem_eq] using hmass
  let f := physicalSpectralBump z ε
  have hf : Continuous f := continuous_physicalSpectralBump z ε
  have hzero : (fun w => star (f w)*f w) =ᵐ[physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1]
      (fun _ => (0 : ℂ)) := by
    filter_upwards [hout] with w hw
    have hd : ε≤‖w-z‖ := by simpa only [Metric.mem_ball, dist_eq_norm, not_lt] using hw
    simp only [f,physicalSpectralBump,max_eq_left (sub_nonpos.mpr hd),Complex.ofReal_zero,
      star_zero,mul_zero]
  have hint := SourceSpectral.complexMeasure_integral_cfc physicalPhaseState
    (physicalWalkFamily a r Φ ha0 ha1 hr0 hr1)
    (isStarNormal_of_mem_unitary (physicalWalkFamily_unitary a r Φ ha0 ha1 hr0 hr1))
    (fun w => star (f w)*f w) (hf.star.mul hf)
  change (∫ w, star (f w)*f w ∂physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1)=_ at hint
  rw [integral_congr_ae hzero,integral_zero,cfc_mul _ _ _ hf.star.continuousOn hf.continuousOn,
    cfc_star] at hint
  have hF := physicalWalkFamily_cfc_faithful a r Φ ha0 ha1 hr0 hr1 f hf
    (by rw [← hint]; rfl)
  have hθ : cfc f (cstarWalk (coupling a) (coupling r) Φ θ)=0 := by
    rw [← physicalWalkFamily_cfc_apply a r Φ ha0 ha1 hr0 hr1 f hf θ,hF]
    rfl
  have hnorm := isStarNormal_of_mem_unitary (physicalCStarWalk_unitary a r Φ θ ha0 ha1 hr0 hr1)
  have heq : cfc f (cstarWalk (coupling a) (coupling r) Φ θ)=
      cfc (0 : ℂ→ℂ) (cstarWalk (coupling a) (coupling r) Φ θ) := by
    rw [cfc_zero,hθ]
  have hvalue := eqOn_of_cfc_eq_cfc heq hf.continuousOn continuous_const.continuousOn hnorm hz
  have hh : ε=0 := by
    exact_mod_cast (show (ε : ℂ)=0 by
      simpa only [f,physicalSpectralBump,sub_self,norm_zero,sub_zero,max_eq_right hε.le,
        Pi.zero_apply] using hvalue)
  exact hε.ne' hh

def physicalUnitaryDOSSupport (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) : Set ℂ :=
  {z | ∀ ε>0, 0<physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 (Metric.ball z ε)}

theorem physicalUnitaryDOSSupport_eq_spectrum (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (hΦ : Irrational Φ) (θ : ℝ) :
    physicalUnitaryDOSSupport a r Φ ha0 ha1 hr0 hr1 =
      spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ) := by
  apply Set.Subset.antisymm
  · intro z hz
    by_contra hn
    obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp
      (spectrum.isClosed (cstarWalk (coupling a) (coupling r) Φ θ)).isOpen_compl z hn
    have hnull : physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1
        (spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ))ᶜ = 0 :=
      ae_iff.mp (physicalUnitaryDOS_ae_mem_spectrum a r Φ ha0 ha1 hr0 hr1 hΦ θ)
    have hb : physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 (Metric.ball z ε)=0 :=
      measure_mono_null hball hnull
    exact (ne_of_gt (hz ε hε)) hb
  · intro z hz ε hε
    exact physicalUnitaryDOS_ball_pos_of_mem_spectrum a r Φ θ ha0 ha1 hr0 hr1 hz hε

end UAMO.PhysicalDOS

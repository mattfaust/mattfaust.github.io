import UAMO.PhysicalDOSPolynomials
import UAMO.MagneticUnitaryDOS

noncomputable section
namespace UAMO.PhysicalDOS
open PhysicalRepresentation MeasureTheory PhysicalWalk

def pairedWalk (a r φ : ℝ) : TwoByTwo (pairedLaurentAlgebra φ) :=
  PhysicalWalk.walk (coupling a) (coupling r) (pairedWalkU φ) (pairedWalkV φ)

def ambientMagneticWalk (a r φ : ℝ) : TwoByTwo MagneticOperator :=
  PhysicalWalk.walk (coupling a) (coupling r)
    ((-Complex.I) • magneticU φ) ((-Complex.I) • magneticV φ)

theorem magneticEvaluation_pairedWalk (a r φ : ℝ) :
    (magneticEvaluation φ).toAlgHom.mapMatrix (pairedWalk a r φ) = ambientMagneticWalk a r φ := by
  rw [pairedWalk, PhysicalRepresentation.map_walk, magneticEvaluation_pairedWalkU,
    magneticEvaluation_pairedWalkV]
  rfl

theorem physicalEvaluation_pairedWalk (a r Φ θ : ℝ) :
    (physicalEvaluation (-Real.pi * Φ) θ).toAlgHom.mapMatrix (pairedWalk a r (-Real.pi * Φ)) =
      PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ := by
  rw [pairedWalk, PhysicalRepresentation.map_walk, physicalEvaluation_pairedWalkU,
    physicalEvaluation_pairedWalkV]
  rfl

theorem magneticEvaluation_pairedWalk_pow_entry (a r φ : ℝ) (n : ℕ) (i j : Fin 2) :
    magneticEvaluation φ ((pairedWalk a r φ ^ n) i j) = (ambientMagneticWalk a r φ ^ n) i j := by
  change ((magneticEvaluation φ).toAlgHom.mapMatrix (pairedWalk a r φ ^ n)) i j = _
  rw [map_pow, magneticEvaluation_pairedWalk]

theorem physicalEvaluation_pairedWalk_pow_entry (a r Φ θ : ℝ) (n : ℕ) (i j : Fin 2) :
    physicalEvaluation (-Real.pi * Φ) θ ((pairedWalk a r (-Real.pi * Φ) ^ n) i j) =
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) i j := by
  change ((physicalEvaluation (-Real.pi * Φ) θ).toAlgHom.mapMatrix
    (pairedWalk a r (-Real.pi * Φ) ^ n)) i j = _
  rw [map_pow, physicalEvaluation_pairedWalk]

theorem physical_walk_entry_moments (a r Φ : ℝ) (n : ℕ) (i j : Fin 2) :
    (∫ θ in (0 : ℝ)..1, physicalOriginTrace
      ((PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) i j)) =
      rootTrace ((ambientMagneticWalk a r (-Real.pi * Φ) ^ n) i j) := by
  have h := pairedLaurentAlgebra_average_trace (-Real.pi * Φ)
    ((pairedWalk a r (-Real.pi * Φ) ^ n) i j)
  simpa only [physicalEvaluation_pairedWalk_pow_entry,
    magneticEvaluation_pairedWalk_pow_entry] using h

theorem magneticSubtype_walk (a r φ : ℝ) :
    (magneticAlgebra φ).subtype.toAlgHom.mapMatrix (magneticWalk a r φ) =
      ambientMagneticWalk a r φ := by
  rw [magneticWalk, PhysicalRepresentation.map_walk]
  rfl

theorem cstarMagneticWalk_power_entry_coe (a r φ : ℝ) (n : ℕ) (i j : Fin 2) :
    (((cstarMagneticWalk a r φ ^ n) i j : magneticAlgebra φ) : MagneticOperator) =
      (ambientMagneticWalk a r φ ^ n) i j := by
  have hc : cstarMagneticWalk a r φ ^ n = CStarMatrix.ofMatrix (magneticWalk a r φ ^ n) :=
    (CStarMatrix.ofMatrixStarAlgEquiv.map_pow (magneticWalk a r φ) n).symm
  rw [hc]
  change ((magneticAlgebra φ).subtype.toAlgHom.mapMatrix (magneticWalk a r φ ^ n)) i j = _
  rw [map_pow, magneticSubtype_walk]

theorem magneticMatrixTrace_walk_power (a r φ : ℝ) (n : ℕ) :
    magneticMatrixTrace φ (cstarMagneticWalk a r φ ^ n) =
      (rootTrace ((ambientMagneticWalk a r φ ^ n) 0 0) +
        rootTrace ((ambientMagneticWalk a r φ ^ n) 1 1)) / 2 := by
  rw [magneticMatrixTrace_apply, magneticTrace_apply, magneticTrace_apply,
    cstarMagneticWalk_power_entry_coe, cstarMagneticWalk_power_entry_coe]

def physicalMatrixOriginTrace (B : TwoByTwo Operator) : ℂ :=
  (physicalOriginTrace (B 0 0) + physicalOriginTrace (B 1 1)) / 2

theorem physical_walk_phase_averaged_moments (a r Φ : ℝ) (n : ℕ) :
    (∫ θ in (0 : ℝ)..1, physicalMatrixOriginTrace
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n)) =
      magneticMatrixTrace (-Real.pi * Φ) (cstarMagneticWalk a r (-Real.pi * Φ) ^ n) := by
  have hint (i : Fin 2) : IntervalIntegrable
      (fun θ => physicalOriginTrace
        ((PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ ^ n) i i)) volume 0 1 := by
    have hc : Continuous (fun θ => physicalOriginTrace (physicalEvaluation (-Real.pi * Φ) θ
        ((pairedWalk a r (-Real.pi * Φ) ^ n) i i))) :=
      physicalOriginTrace.continuous.comp (pairedLaurentSpace_continuous (-Real.pi * Φ)
        ((pairedWalk a r (-Real.pi * Φ) ^ n) i i).property)
    simpa only [physicalEvaluation_pairedWalk_pow_entry] using hc.intervalIntegrable 0 1
  simp only [physicalMatrixOriginTrace, div_eq_mul_inv]
  rw [intervalIntegral.integral_mul_const,
    intervalIntegral.integral_add (hint 0) (hint 1),
    physical_walk_entry_moments, physical_walk_entry_moments, magneticMatrixTrace_walk_power]
  rfl

end UAMO.PhysicalDOS

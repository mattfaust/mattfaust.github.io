import UAMO.PhysicalPhaseSpectrum

noncomputable section
namespace UAMO.PhysicalDuality
open Matrix PhysicalWalk
open scoped Matrix

variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

def spinChange : TwoByTwo A := !![1, Complex.I • (1 : A); -Complex.I • (1 : A), -1]

def spinChangeInv : TwoByTwo A := (1/2 : ℂ) • spinChange

omit [StarRing A] [StarModule ℂ A] in
theorem spinChange_square : (spinChange : TwoByTwo A) * spinChange = (2 : ℂ) • 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spinChange, Matrix.mul_apply, Fin.sum_univ_two,
      smul_mul_assoc, mul_smul_comm, smul_smul, Complex.I_sq]
  all_goals module

omit [StarRing A] [StarModule ℂ A] in
theorem spinChange_mul_inv : (spinChange : TwoByTwo A) * spinChangeInv = 1 := by
  rw [spinChangeInv, mul_smul_comm, spinChange_square, smul_smul]
  norm_num

omit [StarRing A] [StarModule ℂ A] in
theorem spinChange_inv_mul : (spinChangeInv : TwoByTwo A) * spinChange = 1 := by
  rw [spinChangeInv, smul_mul_assoc, spinChange_square, smul_smul]
  norm_num

omit [StarModule ℂ A] in
theorem spinChange_shiftFactor (lam co : ℝ) (u : A) :
    spinChange * shiftFactor lam co u * spinChangeInv = coinFactor lam co u := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spinChange, spinChangeInv, shiftFactor, coinFactor, Matrix.mul_apply,
      Fin.sum_univ_two, Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
      Matrix.smul_apply, smul_mul_assoc, mul_smul_comm, smul_smul, one_mul, mul_one,
      neg_mul, mul_neg, add_mul, mul_add, neg_smul, smul_neg, Complex.ofReal_div,
      Complex.ofReal_ofNat, smul_add, smul_sub, sub_mul, mul_sub, neg_add_rev,
      neg_neg, one_smul]
  all_goals match_scalars <;> ring_nf <;> simp [Complex.I_sq] <;> ring

omit [StarModule ℂ A] in
theorem spinChange_coinFactor (lam co : ℝ) (v : A) :
    spinChange * coinFactor lam co v * spinChangeInv = shiftFactor lam co v := by
  rw [← spinChange_shiftFactor]
  have hi : (spinChangeInv : TwoByTwo A) * spinChangeInv = (1/2 : ℂ) • 1 := by
    simp only [spinChangeInv, smul_mul_smul_comm, spinChange_square, smul_smul]
    norm_num
  rw [← mul_assoc, ← mul_assoc, spinChange_square, mul_assoc, hi]
  simp only [smul_mul_assoc, mul_smul_comm, smul_smul, one_mul, mul_one]
  norm_num

def exchangeShift (r : ℝ) (v : A) : TwoByTwo A :=
  shiftFactor (coupling r) (complementaryCoupling r) v

theorem walk_exchange_conjugacy (a r : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (u v : A) (hv : v ∈ unitary A) :
    (exchangeShift r v * spinChange) * walk (coupling a) (coupling r) u v *
      (spinChangeInv * star (exchangeShift r v)) =
        walk (coupling r) (coupling a) v u := by
  have hS := shiftFactor_unitary r v hv
  have hss : exchangeShift r v * star (exchangeShift r v) = 1 :=
    unitary.mul_star_self_of_mem hS
  have hword : walk (coupling a) (coupling r) u v =
      shiftFactor (coupling a) (complementaryCoupling a) u *
        coinFactor (coupling r) (complementaryCoupling r) v := by
    simp only [walk, UAMO.complementaryCoupling_eq_sqrt ha0 ha1,
      UAMO.complementaryCoupling_eq_sqrt hr0 hr1]
  have hword' : walk (coupling r) (coupling a) v u =
      exchangeShift r v * coinFactor (coupling a) (complementaryCoupling a) u := by
    simp only [walk, exchangeShift, UAMO.complementaryCoupling_eq_sqrt ha0 ha1,
      UAMO.complementaryCoupling_eq_sqrt hr0 hr1]
  rw [hword, hword']
  calc
    _ = exchangeShift r v *
        (spinChange * shiftFactor (coupling a) (complementaryCoupling a) u * spinChangeInv) *
        (spinChange * coinFactor (coupling r) (complementaryCoupling r) v * spinChangeInv) *
        star (exchangeShift r v) := by
      simp only [mul_assoc, ← mul_assoc (spinChangeInv : TwoByTwo A),
        spinChange_inv_mul, one_mul]
    _ = _ := by
      rw [spinChange_shiftFactor, spinChange_coinFactor]
      change exchangeShift r v * _ * exchangeShift r v * star (exchangeShift r v) = _
      rw [mul_assoc, hss, mul_one]

theorem walk_exchange_trace_pow (a r : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (u v : A) (hv : v ∈ unitary A) (τ : TwoByTwo A → ℂ)
    (hτ : ∀ B C, τ (B*C) = τ (C*B)) (n : ℕ) :
    τ (walk (coupling r) (coupling a) v u ^ n) =
      τ (walk (coupling a) (coupling r) u v ^ n) := by
  let C : TwoByTwo A := exchangeShift r v * spinChange
  let D : TwoByTwo A := spinChangeInv * star (exchangeShift r v)
  have hS := shiftFactor_unitary r v hv
  have hs : star (exchangeShift r v) * exchangeShift r v = 1 :=
    unitary.star_mul_self_of_mem hS
  have hCD : C*D = 1 := by
    dsimp [C,D]
    rw [mul_assoc, ← mul_assoc (spinChange : TwoByTwo A), spinChange_mul_inv, one_mul]
    exact unitary.mul_star_self_of_mem hS
  have hDC : D*C = 1 := by
    dsimp [C,D]
    rw [mul_assoc, ← mul_assoc (star (exchangeShift r v)),
      hs, one_mul, spinChange_inv_mul]
  have hp (B : TwoByTwo A) : (C*B*D)^n = C*B^n*D := by
    induction n with
    | zero => simp [hCD]
    | succ n ih =>
      rw [pow_succ, ih]
      simp only [mul_assoc, ← mul_assoc D C, hDC, one_mul, pow_succ]
  rw [← walk_exchange_conjugacy a r ha0 ha1 hr0 hr1 u v hv]
  change τ ((C * _ * D)^n) = _
  rw [hp, mul_assoc, hτ, mul_assoc, hDC, mul_one]

end UAMO.PhysicalDuality

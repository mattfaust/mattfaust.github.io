import UAMO.PhysicalDualityAlgebra
import UAMO.PhysicalDualityLattice
import UAMO.PhysicalMagneticSpectrum
import UAMO.CircleAngularLabels

noncomputable section
namespace UAMO.PhysicalDuality
open Matrix PhysicalWalk PhysicalDOS MeasureTheory

theorem exchangeAlgebraMap_walkU (φ : ℝ) :
    exchangeAlgebraMap φ (magneticWalkU φ) = magneticWalkV (-φ) := by
  apply Subtype.ext
  change exchangeConjugation φ ((-Complex.I) • magneticU φ) =
    (-Complex.I) • magneticV (-φ)
  rw [map_smul, exchangeConjugation_U]

theorem exchangeAlgebraMap_walkV (φ : ℝ) :
    exchangeAlgebraMap φ (magneticWalkV φ) = magneticWalkU (-φ) := by
  apply Subtype.ext
  change exchangeConjugation φ ((-Complex.I) • magneticV φ) =
    (-Complex.I) • magneticU (-φ)
  rw [map_smul, exchangeConjugation_V]

def algebraMatrixTrace (φ : ℝ) (B : TwoByTwo (magneticAlgebra φ)) : ℂ :=
  (magneticTrace φ (B 0 0) + magneticTrace φ (B 1 1))/2

theorem algebraMatrixTrace_cyclic (φ : ℝ) (B C : TwoByTwo (magneticAlgebra φ)) :
    algebraMatrixTrace φ (B*C) = algebraMatrixTrace φ (C*B) := by
  simpa only [magneticMatrixTrace_apply, algebraMatrixTrace, CStarMatrix.mul_apply,
    Matrix.mul_apply] using
      magneticMatrixTrace_cyclic φ (CStarMatrix.ofMatrix B) (CStarMatrix.ofMatrix C)

theorem algebraMatrixTrace_exchange (φ : ℝ) (B : TwoByTwo (magneticAlgebra φ)) :
    algebraMatrixTrace (-φ) ((exchangeAlgebraMap φ).toAlgHom.mapMatrix B) =
      algebraMatrixTrace φ B := by
  unfold algebraMatrixTrace
  congr 2
  · exact rootTrace_exchangeConjugation φ (B 0 0)
  · exact rootTrace_exchangeConjugation φ (B 1 1)

theorem algebraMatrixTrace_walk_power (a r φ : ℝ) (n : ℕ) :
    algebraMatrixTrace φ (magneticWalk a r φ ^ n) =
      magneticMatrixTrace φ (cstarMagneticWalk a r φ ^ n) := by
  have hc : cstarMagneticWalk a r φ ^ n = CStarMatrix.ofMatrix (magneticWalk a r φ ^ n) :=
    (CStarMatrix.ofMatrixStarAlgEquiv.map_pow (magneticWalk a r φ) n).symm
  rw [hc, magneticMatrixTrace_apply]
  rfl

theorem magneticWalk_exchange_moments (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (n : ℕ) :
    magneticMatrixTrace φ (cstarMagneticWalk a r φ ^ n) =
      magneticMatrixTrace (-φ) (cstarMagneticWalk r a (-φ) ^ n) := by
  rw [← algebraMatrixTrace_walk_power, ← algebraMatrixTrace_walk_power]
  rw [← algebraMatrixTrace_exchange φ (magneticWalk a r φ ^ n), map_pow]
  have hm : (exchangeAlgebraMap φ).toAlgHom.mapMatrix (magneticWalk a r φ) =
      walk (coupling a) (coupling r) (magneticWalkV (-φ)) (magneticWalkU (-φ)) := by
    rw [magneticWalk, PhysicalRepresentation.map_walk,
      exchangeAlgebraMap_walkU, exchangeAlgebraMap_walkV]
  rw [hm]
  exact (walk_exchange_trace_pow a r ha0 ha1 hr0 hr1
    (magneticWalkV (-φ)) (magneticWalkU (-φ)) (magneticWalkU_unitary (-φ))
    (algebraMatrixTrace (-φ)) (algebraMatrixTrace_cyclic (-φ)) n).symm

theorem magneticUnitaryDOS_exchange (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1 =
      magneticUnitaryDOS r a (-φ) hr0 hr1 ha0 ha1 := by
  apply CircleDOS.circleProbabilityMeasure_eq_of_moments _ _
    (magneticUnitaryDOS_ae_circle a r φ ha0 ha1 hr0 hr1)
    (magneticUnitaryDOS_ae_circle r a (-φ) hr0 hr1 ha0 ha1)
  intro n
  rw [magneticUnitaryDOS_complex_moments, magneticUnitaryDOS_complex_moments]
  exact magneticWalk_exchange_moments a r φ ha0 ha1 hr0 hr1 n

theorem physicalUnitaryDOS_exchange (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    physicalUnitaryDOS a r Φ ha0 ha1 hr0 hr1 =
      physicalUnitaryDOS r a (-Φ) hr0 hr1 ha0 ha1 := by
  rw [physicalUnitaryDOS_eq_magnetic, physicalUnitaryDOS_eq_magnetic]
  rw [show -Real.pi*(-Φ) = -(-Real.pi*Φ) by ring]
  exact magneticUnitaryDOS_exchange a r (-Real.pi*Φ) ha0 ha1 hr0 hr1

theorem physical_cstar_spectrum_exchange (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (hΦ : Irrational Φ) (θ θ' : ℝ) :
    spectrum ℂ (PhysicalRepresentation.cstarWalk (coupling a) (coupling r) Φ θ) =
      spectrum ℂ (PhysicalRepresentation.cstarWalk (coupling r) (coupling a) (-Φ) θ') := by
  rw [← physicalUnitaryDOSSupport_eq_spectrum a r Φ ha0 ha1 hr0 hr1 hΦ θ,
    ← physicalUnitaryDOSSupport_eq_spectrum r a (-Φ) hr0 hr1 ha0 ha1 hΦ.neg θ']
  unfold physicalUnitaryDOSSupport
  rw [physicalUnitaryDOS_exchange]

theorem physical_walk_spectrum_exchange (a r Φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (hΦ : Irrational Φ) (θ θ' : ℝ) :
    spectrum ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) =
      spectrum ℂ (PhysicalRepresentation.walk (coupling r) (coupling a) (-Φ) θ') := by
  rw [← PhysicalRepresentation.cstarWalk_spectrum, ← PhysicalRepresentation.cstarWalk_spectrum]
  exact physical_cstar_spectrum_exchange a r Φ ha0 ha1 hr0 hr1 hΦ θ θ'

end UAMO.PhysicalDuality

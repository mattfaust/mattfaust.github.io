import UAMO.MagneticWeyl
import UAMO.CanonicalTrace

noncomputable section
namespace UAMO.PhysicalDuality
open scoped InnerProductSpace

def exchangeSite : MagneticSite ≃ MagneticSite where
  toFun s := (-s.1, s.2-s.1)
  invFun s := (-s.1, s.2-s.1)
  left_inv s := by ext <;> simp
  right_inv s := by ext <;> simp

def exchangeWeight (s : MagneticSite) : ℤ := s.1-2*s.2

@[simp] theorem exchangeSite_involutive (s : MagneticSite) :
    exchangeSite (exchangeSite s) = s := exchangeSite.left_inv s

@[simp] theorem exchangeWeight_site (s : MagneticSite) :
    exchangeWeight (exchangeSite s) = exchangeWeight s := by
  simp only [exchangeWeight, exchangeSite, Equiv.coe_fn_mk]
  ring

def exchangeVector (φ : ℝ) (ψ : MagneticSpace) : MagneticSpace :=
  ⟨fun s => latticePhase φ (exchangeWeight s) * ψ (exchangeSite s), by
    apply memℓp_gen
    have h := exchangeSite.summable_iff.mpr (magneticSpace_summable_sq ψ)
    simpa [Function.comp_def, norm_mul, latticePhase_norm] using h⟩

@[simp] theorem exchangeVector_apply (φ : ℝ) (ψ : MagneticSpace) (s : MagneticSite) :
    exchangeVector φ ψ s = latticePhase φ (exchangeWeight s) * ψ (exchangeSite s) := rfl

theorem exchangeVector_norm (φ : ℝ) (ψ : MagneticSpace) :
    ‖exchangeVector φ ψ‖ = ‖ψ‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [magneticSpace_norm_sq, magneticSpace_norm_sq]
  simp only [exchangeVector_apply, norm_mul, latticePhase_norm, one_mul]
  exact exchangeSite.tsum_eq (fun s => ‖ψ s‖^2)

theorem exchangeVector_inverse (φ : ℝ) (ψ : MagneticSpace) :
    exchangeVector (-φ) (exchangeVector φ ψ) = ψ := by
  ext s
  simp only [exchangeVector_apply, exchangeWeight_site, exchangeSite_involutive,
    latticePhase_neg_parameter, ← mul_assoc, ← latticePhase_add, neg_add_cancel,
    latticePhase_zero, one_mul]

def exchangeEquiv (φ : ℝ) : MagneticSpace ≃ₗᵢ[ℂ] MagneticSpace where
  toFun := exchangeVector φ
  invFun := exchangeVector (-φ)
  left_inv := exchangeVector_inverse φ
  right_inv := by intro ψ; simpa only [neg_neg] using exchangeVector_inverse (-φ) ψ
  map_add' := by intro ψ χ; ext s; simp [mul_add]
  map_smul' := by intro c ψ; ext s; simp [mul_left_comm]
  norm_map' := exchangeVector_norm φ

def exchangeOperator (φ : ℝ) : MagneticOperator := exchangeEquiv φ

@[simp] theorem exchangeOperator_apply (φ : ℝ) (ψ : MagneticSpace) (s : MagneticSite) :
    exchangeOperator φ ψ s = latticePhase φ (exchangeWeight s) * ψ (exchangeSite s) := rfl

theorem exchangeOperator_unitary (φ : ℝ) : exchangeOperator φ ∈ unitary MagneticOperator :=
  (unitary.linearIsometryEquiv.symm (exchangeEquiv φ)).property

@[simp] theorem exchangeOperator_star_apply (φ : ℝ) (ψ : MagneticSpace) (s : MagneticSite) :
    star (exchangeOperator φ) ψ s =
      latticePhase (-φ) (exchangeWeight s) * ψ (exchangeSite s) := by
  rw [exchangeOperator, LinearIsometryEquiv.star_eq_symm]
  rfl

theorem exchangeOperator_origin (φ : ℝ) : exchangeOperator φ magneticOrigin = magneticOrigin := by
  ext s
  by_cases hs : s = 0
  · subst s
    simp [magneticOrigin, exchangeWeight, exchangeSite]
  · have he : exchangeSite s ≠ 0 := by
      intro h
      apply hs
      have hh := congrArg exchangeSite h
      simpa [exchangeSite] using hh
    simp [magneticOrigin, lp.single_apply, Pi.single_apply, hs, he]

def exchangeConjugation (φ : ℝ) : MagneticOperator →⋆ₐ[ℂ] MagneticOperator where
  toFun B := exchangeOperator φ * B * star (exchangeOperator φ)
  map_one' := by simpa using unitary.mul_star_self_of_mem (exchangeOperator_unitary φ)
  map_mul' := by
    intro B C
    simp only [mul_assoc, ← mul_assoc (star (exchangeOperator φ)),
      unitary.star_mul_self_of_mem (exchangeOperator_unitary φ), one_mul]
  map_zero' := by simp
  map_add' := by intro B C; simp only [mul_add, add_mul]
  commutes' := by
    intro c
    simp only [Algebra.algebraMap_eq_smul_one, mul_smul_comm, mul_one, smul_mul_assoc,
      unitary.mul_star_self_of_mem (exchangeOperator_unitary φ)]
  map_star' := by intro B; simp only [star_mul, star_star, mul_assoc]

@[simp] theorem exchangeConjugation_apply (φ : ℝ) (B : MagneticOperator) :
    exchangeConjugation φ B = exchangeOperator φ * B * star (exchangeOperator φ) := rfl

theorem exchangeConjugation_magneticShift (φ : ℝ) (ν : MagneticSite) :
    exchangeConjugation φ (magneticShift φ ν) =
      latticePhase φ (exchangeWeight ν) • magneticShift (-φ) (exchangeSite ν) := by
  ext ψ s
  simp only [exchangeConjugation_apply, ContinuousLinearMap.mul_apply,
    exchangeOperator_apply, magneticShift_apply, exchangeOperator_star_apply,
    ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul,
    latticePhase_neg_parameter]
  have hi : exchangeSite (exchangeSite s-ν) = s-exchangeSite ν := by
    ext <;> simp [exchangeSite] <;> ring
  rw [hi]
  simp only [← mul_assoc, ← latticePhase_add]
  congr 2
  simp only [exchangeWeight, wedge, exchangeSite, Equiv.coe_fn_mk,
    Prod.fst_sub, Prod.snd_sub]
  ring

theorem exchangeConjugation_U (φ : ℝ) :
    exchangeConjugation φ (magneticU φ) = magneticV (-φ) := by
  rw [magneticU, exchangeConjugation_magneticShift]
  simp [magneticV, exchangeWeight, exchangeSite, latticePhase_neg_parameter]

theorem exchangeConjugation_V (φ : ℝ) :
    exchangeConjugation φ (magneticV φ) = magneticU (-φ) := by
  rw [magneticV, map_smul, exchangeConjugation_magneticShift]
  simp [magneticU, exchangeWeight, exchangeSite, smul_smul, ← latticePhase_add]

theorem rootTrace_exchangeConjugation (φ : ℝ) (B : MagneticOperator) :
    rootTrace (exchangeConjugation φ B) = rootTrace B := by
  rw [rootTrace_eq_inner, rootTrace_eq_inner, exchangeConjugation_apply]
  have hstar : star (exchangeOperator φ) magneticOrigin = magneticOrigin := by
    calc
      _ = star (exchangeOperator φ) (exchangeOperator φ magneticOrigin) := by
        rw [exchangeOperator_origin]
      _ = magneticOrigin := by
        rw [← ContinuousLinearMap.mul_apply,
          unitary.star_mul_self_of_mem (exchangeOperator_unitary φ)]
        rfl
  simp only [ContinuousLinearMap.mul_apply, hstar]
  rw [← ContinuousLinearMap.adjoint_inner_left]
  rw [← ContinuousLinearMap.star_eq_adjoint, hstar]

theorem exchangeConjugation_mem_polynomial (φ : ℝ) {B : MagneticOperator}
    (hB : B ∈ magneticPolynomialSpace φ) :
    exchangeConjugation φ B ∈ magneticPolynomialSpace (-φ) := by
  induction hB using Submodule.span_induction with
  | mem B hB =>
    obtain ⟨ν,rfl⟩ := hB
    rw [exchangeConjugation_magneticShift]
    exact (magneticPolynomialSpace (-φ)).smul_mem _
      (magneticShift_mem_polynomialSpace (-φ) (exchangeSite ν))
  | zero =>
    rw [map_zero]
    exact (magneticPolynomialSpace (-φ)).zero_mem
  | add B C _ _ hB hC =>
    rw [map_add]
    exact (magneticPolynomialSpace (-φ)).add_mem hB hC
  | smul c B _ hB =>
    rw [map_smul]
    exact (magneticPolynomialSpace (-φ)).smul_mem c hB

theorem exchangeConjugation_mem_algebra (φ : ℝ) {B : MagneticOperator}
    (hB : B ∈ magneticAlgebra φ) : exchangeConjugation φ B ∈ magneticAlgebra (-φ) := by
  have hc : Continuous (exchangeConjugation φ) :=
    (continuous_const.mul continuous_id).mul continuous_const
  exact (Set.MapsTo.closure (fun _ h => exchangeConjugation_mem_polynomial φ h) hc) hB

def exchangeAlgebraMap (φ : ℝ) : magneticAlgebra φ →⋆ₐ[ℂ] magneticAlgebra (-φ) where
  toFun B := ⟨exchangeConjugation φ B, exchangeConjugation_mem_algebra φ B.property⟩
  map_one' := by apply Subtype.ext; exact map_one (exchangeConjugation φ)
  map_zero' := by apply Subtype.ext; exact map_zero (exchangeConjugation φ)
  map_add' B C := by apply Subtype.ext; exact map_add (exchangeConjugation φ) (B : MagneticOperator) C
  map_mul' B C := by apply Subtype.ext; exact map_mul (exchangeConjugation φ) (B : MagneticOperator) C
  commutes' c := by apply Subtype.ext; exact (exchangeConjugation φ).commutes c
  map_star' B := by apply Subtype.ext; exact map_star (exchangeConjugation φ) (B : MagneticOperator)

end UAMO.PhysicalDuality

import UAMO.ScalarInternalSeed
import UAMO.ScalarSpectralBaseline
import UAMO.PhysicalOpenRotationLabels

noncomputable section
namespace UAMO
open Set MeasureTheory CircleDOS PhysicalDOS

theorem arcLabel_mem_Icc (ν : Measure ℂ) [IsProbabilityMeasure ν] (z : ℂ) :
    arcLabel ν z∈Icc (0:ℝ) 1 :=
  ⟨measureReal_nonneg,measureReal_le_one⟩

theorem physical_scalarIDS_eq_abs_arcLabel {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (α : ℝ) (z : ℂ) :
    scalarIDS a r (-Real.pi*α) (scalarEnergyOfCircle a r z)=
      |1-2*arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1) z| := by
  have hnonneg : 0≤scalarIDS a r (-Real.pi*α) (scalarEnergyOfCircle a r z) :=
    measureReal_nonneg
  by_cases hz : 0<z.im
  · rw [physical_arcLabel_upper ha ha1 hr hr1 α hz,
      abs_of_nonneg (by linarith)]
    ring
  · rw [physical_arcLabel_lower_nonpos ha ha1 hr hr1 α (le_of_not_gt hz),
      abs_of_nonpos (by linarith)]
    ring

theorem arcLabel_internal_of_nonzero_nonhalf (ν : Measure ℂ) [IsProbabilityMeasure ν]
    (z : ℂ) (label : AddCircle (1:ℝ)) (hzero : label≠0)
    (hhalf : label≠((1/2:ℝ):AddCircle (1:ℝ)))
    (hlabel : ((arcLabel ν z:ℝ):AddCircle (1:ℝ))=label) :
    arcLabel ν z∈Ioo (0:ℝ) 1 ∧ arcLabel ν z≠1/2 := by
  have hb := arcLabel_mem_Icc ν z
  refine ⟨⟨?_,?_⟩,?_⟩
  · by_contra! hle
    have hz : arcLabel ν z=0 := le_antisymm hle hb.1
    apply hzero
    rw [←hlabel,hz]
    rfl
  · by_contra! hle
    have hz : arcLabel ν z=1 := le_antisymm hb.2 hle
    apply hzero
    rw [←hlabel,hz,AddCircle.coe_period]
  · intro hh
    apply hhalf
    rw [←hlabel,hh]

end UAMO

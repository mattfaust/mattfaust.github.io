import UAMO.SpectralStableProjector
import UAMO.StableAngleDynamics
import UAMO.AngularIteration
import UAMO.UAMOGapLabels

noncomputable section
namespace UAMO
open Matrix StablePlane ProjectiveAngle Filter
open scoped Topology

def physicalAngularMean (a lam t α x s : ℝ) (n : ℕ) : ℝ :=
  (angleIterate (fun y => realTransferAngleLift a lam t (2*Real.pi*y)) α x s n-s)/
    (2*Real.pi*(n:ℝ))

def HasPhysicalAngularRotation (a lam t α ρ : ℝ) : Prop :=
  ∀x s:ℝ,Tendsto (physicalAngularMean a lam t α x s) atTop (𝓝 ρ)

def HasPhysicalRotationLabel (a lam t α : ℝ) (label : AddCircle (1:ℝ)) : Prop :=
  ∃ρ:ℝ,HasPhysicalAngularRotation a lam t α ρ ∧ (ρ:AddCircle (1:ℝ))=label

theorem physicalAngularRotation_unique {a lam t α ρ σ : ℝ}
    (hρ : HasPhysicalAngularRotation a lam t α ρ)
    (hσ : HasPhysicalAngularRotation a lam t α σ) : ρ=σ :=
  tendsto_nhds_unique (hρ 0 0) (hσ 0 0)

theorem physicalRotationLabel_unique {a lam t α : ℝ} {u v : AddCircle (1:ℝ)}
    (hu : HasPhysicalRotationLabel a lam t α u)
    (hv : HasPhysicalRotationLabel a lam t α v) : u=v := by
  obtain ⟨ρ,hρ,rfl⟩ := hu
  obtain ⟨σ,hσ,rfl⟩ := hv
  rw [physicalAngularRotation_unique hρ hσ]

theorem boundary_physical_gap_has_odd_rotation_label {r α : ℝ}
    (hr : 0≤r) (hr1 : r<1) (hα : Irrational α) (t θ₀ : ℝ)
    (hres : Complex.exp ((t:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk 1 (coupling r) α θ₀)) :
    ∃m k:ℤ,Odd m ∧
      HasPhysicalAngularRotation 1 (coupling r) t α (((m:ℝ)*α+(k:ℝ))/2) ∧
      HasPhysicalRotationLabel 1 (coupling r) t α (uamoGapLabel α m k) := by
  obtain ⟨θ,hθ,hs,_⟩ := boundary_physical_gap_odd_stable_degree hr hr1 hα t θ₀ hres
  have hlam : 0≤coupling r := by unfold coupling; positivity
  have hlam1 := CMV.coupling_lt_one_of_lt_one hr1
  obtain ⟨m,k,hm,hwind,hstep⟩ := boundary_stable_angle_integer_dynamics
    hlam hlam1 t α θ hθ hs
  have hrot : HasPhysicalAngularRotation 1 (coupling r) t α (((m:ℝ)*α+(k:ℝ))/2) := by
    intro x s
    exact angleIterate_mean_tendsto _ α θ m k hθ hwind hstep
      (fun y => (realTransferAngleLift_strictMono (by norm_num : (0:ℝ)<1)
        hlam hlam1 t (2*Real.pi*y)).monotone)
      (fun y v => realTransferAngleLift_add_pi 1 (coupling r) t (2*Real.pi*y) v) x s
  exact ⟨m,k,hm,hrot,_,hrot,rfl⟩

end UAMO

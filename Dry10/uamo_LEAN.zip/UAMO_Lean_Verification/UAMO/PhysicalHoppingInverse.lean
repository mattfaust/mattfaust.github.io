import UAMO.LatticeMultiplier
import UAMO.CMVTransfer
import UAMO.PhysicalRealPartReduction

noncomputable section
namespace UAMO.CMV
open PhysicalRepresentation PhysicalRealPart

theorem complementaryCoupling_pos_of_lt_one {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) :
    0 < complementaryCoupling r := by
  unfold complementaryCoupling
  apply div_pos
  · nlinarith
  · positivity

theorem physicalHopping_norm_lower (r x : ℝ) :
    complementaryCoupling r ≤ ‖physicalHopping r x‖ := by
  simpa [physicalHopping] using Complex.im_le_norm (physicalHopping r x)

theorem physicalHopping_star_inv_bound {r : ℝ} (hr : 0 ≤ r) (hr1 : r < 1) (x : ℝ) :
    ‖(star (physicalHopping r x))⁻¹‖ ≤ (complementaryCoupling r)⁻¹ := by
  rw [norm_inv, norm_star]
  simpa only [one_div] using one_div_le_one_div_of_le
    (complementaryCoupling_pos_of_lt_one hr hr1) (physicalHopping_norm_lower r x)

def physicalHoppingInverse (r Φ θ : ℝ) (hr : 0 ≤ r) (hr1 : r < 1) : Operator :=
  latticeMultiplier (fun n => (star (physicalHopping r (phaseAngle Φ θ n)))⁻¹)
    (complementaryCoupling r)⁻¹
    (inv_nonneg.mpr (complementaryCoupling_pos_of_lt_one hr hr1).le)
    (fun n => physicalHopping_star_inv_bound hr hr1 (phaseAngle Φ θ n))

@[simp] theorem physicalHoppingInverse_apply (r Φ θ : ℝ)
    (hr : 0 ≤ r) (hr1 : r < 1) (ψ : Hilbert) (n : ℤ) :
    physicalHoppingInverse r Φ θ hr hr1 ψ n =
      (star (physicalHopping r (phaseAngle Φ θ n)))⁻¹ * ψ n := rfl

theorem physicalHoppingInverse_mul (r Φ θ : ℝ) (hr : 0 ≤ r) (hr1 : r < 1) :
    physicalHoppingInverse r Φ θ hr hr1 *
      star (physicalQ (coupling r) (complementaryCoupling r) Φ θ) = 1 := by
  ext ψ n
  simp only [ContinuousLinearMap.mul_apply, physicalHoppingInverse_apply,
    physicalQ_star_apply, ContinuousLinearMap.one_apply]
  change (star (physicalHopping r (phaseAngle Φ θ n)))⁻¹ *
    (star (physicalHopping r (phaseAngle Φ θ n)) * ψ n) = ψ n
  rw [← mul_assoc, inv_mul_cancel₀ (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 _)),
    one_mul]

theorem physicalHoppingInverse_mul_rev (r Φ θ : ℝ) (hr : 0 ≤ r) (hr1 : r < 1) :
    star (physicalQ (coupling r) (complementaryCoupling r) Φ θ) *
      physicalHoppingInverse r Φ θ hr hr1 = 1 := by
  ext ψ n
  simp only [ContinuousLinearMap.mul_apply, physicalHoppingInverse_apply,
    physicalQ_star_apply, ContinuousLinearMap.one_apply]
  change star (physicalHopping r (phaseAngle Φ θ n)) *
    ((star (physicalHopping r (phaseAngle Φ θ n)))⁻¹ * ψ n) = ψ n
  rw [← mul_assoc, mul_inv_cancel₀ (star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 _)),
    one_mul]

theorem physicalQ_star_isUnit (r Φ θ : ℝ) (hr : 0 ≤ r) (hr1 : r < 1) :
    IsUnit (star (physicalQ (coupling r) (complementaryCoupling r) Φ θ)) := by
  refine ⟨⟨_, physicalHoppingInverse r Φ θ hr hr1,
    physicalHoppingInverse_mul_rev r Φ θ hr hr1,
    physicalHoppingInverse_mul r Φ θ hr hr1⟩, rfl⟩

end UAMO.CMV

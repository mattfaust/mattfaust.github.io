import UAMO.PhysicalDOSSpectralSupport
import UAMO.MagneticDOSSpectralSupport

noncomputable section
namespace UAMO
open PhysicalDOS PhysicalRepresentation

theorem cstarMagneticWalk_spectrum (a r φ : ℝ) :
    spectrum ℂ (cstarMagneticWalk a r φ)=spectrum ℂ (magneticWalk a r φ) :=
  AlgEquiv.spectrum_eq (CStarMatrix.ofMatrixStarAlgEquiv :
    PhysicalWalk.TwoByTwo (magneticAlgebra φ) ≃⋆ₐ[ℂ] MagneticMatrixAlgebra φ) _

theorem physical_cstar_spectrum_eq_magnetic (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (hΦ : Irrational Φ) (θ : ℝ) :
    spectrum ℂ (cstarWalk (coupling a) (coupling r) Φ θ)=
      spectrum ℂ (cstarMagneticWalk a r (-Real.pi*Φ)) := by
  rw [← physicalUnitaryDOSSupport_eq_spectrum a r Φ ha0 ha1 hr0 hr1 hΦ θ,
    ← magneticDOSSpectralSupport_eq_spectrum a r (-Real.pi*Φ) ha0 ha1 hr0 hr1]
  unfold physicalUnitaryDOSSupport magneticDOSSpectralSupport
  rw [physicalUnitaryDOS_eq_magnetic]

theorem physical_walk_spectrum_eq_magnetic (a r Φ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (hΦ : Irrational Φ) (θ : ℝ) :
    spectrum ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)=
      spectrum ℂ (magneticWalk a r (-Real.pi*Φ)) := by
  rw [← cstarWalk_spectrum,
    physical_cstar_spectrum_eq_magnetic a r Φ ha0 ha1 hr0 hr1 hΦ θ,
    cstarMagneticWalk_spectrum]

theorem physical_walk_spectrum_scalar {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr0 : 0≤r) (hr1 : r≤1) {Φ : ℝ} (hΦ : Irrational Φ) (θ t : ℝ) :
    Complex.exp ((t : ℂ)*Complex.I) ∈ spectrum ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ↔
    ((((1+a^2)*(1+r^2))/a*Real.cos t : ℝ) : ℂ) ∈
      spectrum ℂ (scalarHamiltonian a r (-Real.pi*Φ)) := by
  rw [physical_walk_spectrum_eq_magnetic a r Φ ha.le ha1 hr0 hr1 hΦ θ]
  exact magneticWalk_spectrum_scalar ha ha1 hr0 hr1 (-Real.pi*Φ) t

theorem physical_walk_resolvent_scalar {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr0 : 0≤r) (hr1 : r≤1) {Φ : ℝ} (hΦ : Irrational Φ) (θ t : ℝ) :
    Complex.exp ((t : ℂ)*Complex.I) ∈ resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ↔
    ((((1+a^2)*(1+r^2))/a*Real.cos t : ℝ) : ℂ) ∈
      resolventSet ℂ (scalarHamiltonian a r (-Real.pi*Φ)) := by
  simpa only [spectrum, Set.mem_compl_iff, not_not] using
    not_congr (physical_walk_spectrum_scalar ha ha1 hr0 hr1 hΦ θ t)

end UAMO

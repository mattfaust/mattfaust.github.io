import UAMO.PhysicalOpenRotationLabels
import UAMO.PhysicalAxisLabels

noncomputable section
namespace UAMO
open Filter Set CircleDOS PhysicalDOS
open scoped Topology

theorem unitCircle_eq_axis_of_im_zero {z : ℂ} (hz : ‖z‖=1) (him : z.im=0) :
    z=1 ∨ z= -1 := by
  have hzreal : z=(z.re:ℂ) := by apply Complex.ext <;> simp [him]
  have habs : |z.re|=1 := by
    have hh := hz
    rw [hzreal,Complex.norm_real,Real.norm_eq_abs] at hh
    exact hh
  by_cases hpos : 0≤z.re
  · have hre : z.re=1 := by simpa only [abs_of_nonneg hpos] using habs
    left
    apply Complex.ext <;> simp [hre,him]
  · have hre : z.re= -1 := by
      rw [abs_of_neg (lt_of_not_ge hpos)] at habs
      linarith
    right
    apply Complex.ext <;> simp [hre,him]

theorem physical_axis_scalarIDS {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (Φ : ℝ) :
    scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r 1)=1 ∧
      scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r (-1))=0 := by
  obtain ⟨hpos,hneg⟩ := physical_axis_arcLabels ha ha1 hr hr1 Φ
  rw [physical_arcLabel_lower_nonpos ha ha1 hr hr1 Φ (by norm_num : (1:ℂ).im≤0)] at hpos
  rw [physical_arcLabel_lower_nonpos ha ha1 hr hr1 Φ (by norm_num : (-1:ℂ).im≤0)] at hneg
  constructor <;> linarith

theorem physical_circle_gap_quotient_label_eventually_const {a r Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)) :
    ∀ᶠ w:ℂ in 𝓝 z,
      (‖w‖=1 → ∀ϑ:ℝ,w∈resolventSet ℂ
        (PhysicalRepresentation.walk (coupling a) (coupling r) Φ ϑ)) ∧
      ((arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) w:ℝ):AddCircle (1:ℝ))=
        ((arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z:ℝ):AddCircle (1:ℝ)) := by
  by_cases him : z.im≠0
  · filter_upwards [physical_circle_gap_label_eventually_const ha ha1 hr hr1 hΦ θ z hz him hres]
      with w hw
    exact ⟨hw.1,congrArg (fun u : ℝ => (u:AddCircle (1:ℝ))) hw.2⟩
  have him0 : z.im=0 := not_ne_iff.mp him
  have hE := (physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ θ z hz).mp hres
  have hnear := scalar_moving_circle_cut_eventually_const a r Φ z ha.ne' hE
  obtain ⟨hIDSpos,hIDSneg⟩ := physical_axis_scalarIDS ha ha1 hr hr1 Φ
  obtain ⟨hArcpos,hArcneg⟩ := physical_axis_arcLabels ha ha1 hr hr1 Φ
  rcases unitCircle_eq_axis_of_im_zero hz him0 with hpos|hneg
  · subst z
    filter_upwards [hnear] with w hw
    refine ⟨fun hwunit ϑ =>
      (physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ ϑ w hwunit).mpr hw.1,?_⟩
    rw [hArcpos]
    by_cases hwi : 0<w.im
    · rw [physical_arcLabel_upper ha ha1 hr hr1 Φ hwi,hw.2,hIDSpos]
      norm_num [AddCircle.coe_period]
    · rw [physical_arcLabel_lower_nonpos ha ha1 hr hr1 Φ (le_of_not_gt hwi),hw.2,hIDSpos]
      norm_num
  · subst z
    filter_upwards [hnear] with w hw
    refine ⟨fun hwunit ϑ =>
      (physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ ϑ w hwunit).mpr hw.1,?_⟩
    rw [hArcneg]
    by_cases hwi : 0<w.im
    · rw [physical_arcLabel_upper ha ha1 hr hr1 Φ hwi,hw.2,hIDSneg]
      norm_num
    · rw [physical_arcLabel_lower_nonpos ha ha1 hr hr1 Φ (le_of_not_gt hwi),hw.2,hIDSneg]
      norm_num

theorem physical_circle_gap_open_interval_all_cuts {a r Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)) :
    ∃t δ:ℝ,0<δ ∧ Complex.exp ((t:ℂ)*Complex.I)=z ∧
      ∀s:ℝ,|s-t|<δ →
        (∀ϑ:ℝ,Complex.exp ((s:ℂ)*Complex.I)∈resolventSet ℂ
          (PhysicalRepresentation.walk (coupling a) (coupling r) Φ ϑ)) ∧
        ((arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1)
          (Complex.exp ((s:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ))=
          ((arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z:ℝ):AddCircle (1:ℝ)) := by
  have ht : Complex.exp ((z.arg:ℂ)*Complex.I)=z := by
    simpa only [hz,Complex.ofReal_one,one_mul] using Complex.norm_mul_exp_arg_mul_I z
  have hcont : Continuous (fun s:ℝ => Complex.exp ((s:ℂ)*Complex.I)) := by fun_prop
  have hc : Tendsto (fun s:ℝ => Complex.exp ((s:ℂ)*Complex.I)) (𝓝 z.arg) (𝓝 z) := by
    simpa only [ht] using hcont.continuousAt.tendsto (x:=z.arg)
  have hnear := hc.eventually
    (physical_circle_gap_quotient_label_eventually_const ha ha1 hr hr1 hΦ θ z hz hres)
  obtain ⟨δ,hδ,hδnear⟩ := Metric.eventually_nhds_iff.mp hnear
  refine ⟨z.arg,δ,hδ,ht,?_⟩
  intro s hs
  have h := hδnear (by simpa only [Real.dist_eq] using hs)
  refine ⟨h.1 ?_,h.2⟩
  simp [Complex.norm_exp]

theorem openDOSGapLabel_of_witness_all_cuts {a r Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ))
    (label : AddCircle (1:ℝ))
    (hlabel : ((arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z:ℝ):
      AddCircle (1:ℝ))=label) :
    OpenDOSGapLabel a r Φ ha.le ha1 hr hr1 label := by
  obtain ⟨t,δ,hδ,_ht,hgap⟩ := physical_circle_gap_open_interval_all_cuts ha ha1 hr hr1 hΦ θ z hz hres
  refine ⟨t,δ,hδ,?_⟩
  intro s hs
  obtain ⟨hres',hlabel'⟩ := hgap s hs
  exact ⟨hres',hlabel'.trans hlabel⟩

end UAMO

import UAMO.PhysicalOpenRotationLabels

noncomputable section
namespace UAMO
open PhysicalDOS PhysicalDuality CircleDOS

theorem openDOSGapLabel_exchange_iff {a r α : ℝ}
    (ha : 0≤a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hα : Irrational α)
    (label : AddCircle (1:ℝ)) :
    OpenDOSGapLabel a r α ha ha1 hr hr1 label ↔
      OpenDOSGapLabel r a (-α) hr hr1 ha ha1 label := by
  constructor
  · exact openDOSGapLabel_exchange ha ha1 hr hr1 hα label
  · intro hgap
    simpa only [neg_neg] using openDOSGapLabel_exchange hr hr1 ha ha1 hα.neg label hgap

end UAMO

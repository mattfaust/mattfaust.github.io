import UAMO.CircleArcLabel
import UAMO.GapProjectionTrace
import UAMO.UnitCircleScalarCorrespondence

noncomputable section
namespace UAMO
open Filter Set MeasureTheory CircleDOS PhysicalDOS
open scoped Topology

def OpenDOSGapLabel (a r Φ : ℝ) (ha0 : 0≤a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (label : AddCircle (1:ℝ)) : Prop :=
  ∃t δ:ℝ,0<δ ∧ ∀s:ℝ,|s-t|<δ →
    (∀θ:ℝ,Complex.exp ((s:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)) ∧
    ((arcLabel (physicalUnitaryDOS a r Φ ha0 ha1 hr hr1)
      (Complex.exp ((s:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ))=label

theorem scalar_moving_circle_cut_eventually_const (a r Φ : ℝ) (z : ℂ)
    (ha : a≠0)
    (hE : (scalarEnergyOfCircle a r z:ℂ)∈
      resolventSet ℂ (scalarHamiltonian a r (-Real.pi*Φ))) :
    ∀ᶠ w:ℂ in 𝓝 z,
      (scalarEnergyOfCircle a r w:ℂ)∈resolventSet ℂ (scalarHamiltonian a r (-Real.pi*Φ)) ∧
      scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r w)=
        scalarIDS a r (-Real.pi*Φ) (scalarEnergyOfCircle a r z) := by
  have henergy : Continuous (fun w:ℂ => scalarEnergyOfCircle a r w) := by
    unfold scalarEnergyOfCircle
    fun_prop
  have hpath : Continuous (fun w:ℂ => ((a,r),scalarEnergyOfCircle a r w)) :=
    continuous_const.prodMk henergy
  have hnear := hpath.continuousAt.eventually
    (scalarGapProjection_trace_eventually_eq a r (-Real.pi*Φ) _ ha hE)
  filter_upwards [hnear] with w hw
  obtain ⟨hres,htrace⟩ := hw
  refine ⟨hres,?_⟩
  simpa only [scalarGapProjection_trace_eq_realSpectralMass] using htrace

theorem physical_circle_gap_label_eventually_const {a r Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1) (him : z.im≠0)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)) :
    ∀ᶠ w:ℂ in 𝓝 z,
      (‖w‖=1 → ∀ϑ:ℝ,w∈resolventSet ℂ
        (PhysicalRepresentation.walk (coupling a) (coupling r) Φ ϑ)) ∧
      arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) w=
        arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z := by
  have hE := (physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ θ z hz).mp hres
  have hnear := scalar_moving_circle_cut_eventually_const a r Φ z ha.ne' hE
  rcases lt_or_gt_of_ne him with hneg|hpos
  · have hsign : ∀ᶠ w:ℂ in 𝓝 z,w.im<0 :=
      Complex.continuous_im.continuousAt.eventually (gt_mem_nhds hneg)
    filter_upwards [hnear,hsign] with w hw hwi
    refine ⟨fun hwunit ϑ =>
      (physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ ϑ w hwunit).mpr hw.1,?_⟩
    rw [physical_arcLabel_lower ha ha1 hr hr1 Φ hwi,
      physical_arcLabel_lower ha ha1 hr hr1 Φ hneg,hw.2]
  · have hsign : ∀ᶠ w:ℂ in 𝓝 z,0<w.im :=
      Complex.continuous_im.continuousAt.eventually (lt_mem_nhds hpos)
    filter_upwards [hnear,hsign] with w hw hwi
    refine ⟨fun hwunit ϑ =>
      (physical_circle_resolvent_scalar ha ha1 hr hr1 hΦ ϑ w hwunit).mpr hw.1,?_⟩
    rw [physical_arcLabel_upper ha ha1 hr hr1 Φ hwi,
      physical_arcLabel_upper ha ha1 hr hr1 Φ hpos,hw.2]

theorem physical_circle_gap_open_interval {a r Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1) (him : z.im≠0)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)) :
    ∃t δ:ℝ,0<δ ∧ Complex.exp ((t:ℂ)*Complex.I)=z ∧
      ∀s:ℝ,|s-t|<δ →
        (∀ϑ:ℝ,Complex.exp ((s:ℂ)*Complex.I)∈resolventSet ℂ
          (PhysicalRepresentation.walk (coupling a) (coupling r) Φ ϑ)) ∧
        arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1)
          (Complex.exp ((s:ℂ)*Complex.I))=
          arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z := by
  have ht : Complex.exp ((z.arg:ℂ)*Complex.I)=z := by
    simpa only [hz,Complex.ofReal_one,one_mul] using Complex.norm_mul_exp_arg_mul_I z
  have hcont : Continuous (fun s:ℝ => Complex.exp ((s:ℂ)*Complex.I)) := by fun_prop
  have hnear : ∀ᶠ s:ℝ in 𝓝 z.arg,
      (‖Complex.exp ((s:ℂ)*Complex.I)‖=1 → ∀ϑ:ℝ,
        Complex.exp ((s:ℂ)*Complex.I)∈resolventSet ℂ
          (PhysicalRepresentation.walk (coupling a) (coupling r) Φ ϑ)) ∧
      arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1)
        (Complex.exp ((s:ℂ)*Complex.I))=
        arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z := by
    have h := physical_circle_gap_label_eventually_const ha ha1 hr hr1 hΦ θ z hz him hres
    have hc : Tendsto (fun s:ℝ => Complex.exp ((s:ℂ)*Complex.I)) (𝓝 z.arg) (𝓝 z) := by
      simpa only [ht] using hcont.continuousAt.tendsto (x:=z.arg)
    exact hc.eventually h
  obtain ⟨δ,hδ,hδnear⟩ := Metric.eventually_nhds_iff.mp hnear
  refine ⟨z.arg,δ,hδ,ht,?_⟩
  intro s hs
  have h := hδnear (by simpa only [Real.dist_eq] using hs)
  refine ⟨h.1 ?_,h.2⟩
  simp [Complex.norm_exp]

theorem openDOSGapLabel_of_witness {a r Φ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖=1) (him : z.im≠0)
    (hres : z∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ))
    (label : AddCircle (1:ℝ))
    (hlabel : ((arcLabel (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1) z:ℝ):
      AddCircle (1:ℝ))=label) :
    OpenDOSGapLabel a r Φ ha.le ha1 hr hr1 label := by
  obtain ⟨t,δ,hδ,_ht,hgap⟩ := physical_circle_gap_open_interval ha ha1 hr hr1 hΦ θ z hz him hres
  refine ⟨t,δ,hδ,?_⟩
  intro s hs
  obtain ⟨hres',hlabel'⟩ := hgap s hs
  exact ⟨hres',by rw [hlabel',hlabel]⟩

end UAMO

import UAMO.PhysicalOpenGapLabels
import UAMO.PhysicalRotationDOS
import UAMO.PhysicalDualityDOS

noncomputable section
namespace UAMO
open CircleDOS PhysicalDOS

def OpenPhysicalRotationGapLabel (a r α : ℝ) (label : AddCircle (1:ℝ)) : Prop :=
  ∃t δ:ℝ,0<δ ∧ ∀s:ℝ,|s-t|<δ →
    (∀θ:ℝ,Complex.exp ((s:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α θ)) ∧
    HasPhysicalRotationLabel a (coupling r) s α label

theorem openPhysicalRotationGapLabel_iff_DOS {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (hα : Irrational α)
    (label : AddCircle (1:ℝ)) :
    OpenPhysicalRotationGapLabel a r α label ↔
      OpenDOSGapLabel a r α ha.le ha1 hr hr1.le label := by
  constructor
  · rintro ⟨t,δ,hδ,hgap⟩
    refine ⟨t,δ,hδ,?_⟩
    intro s hs
    obtain ⟨hres,hrot⟩ := hgap s hs
    exact ⟨hres,((physicalRotationLabel_iff_DOS ha ha1 hr hr1 α hα s label).mp hrot).symm⟩
  · rintro ⟨t,δ,hδ,hgap⟩
    refine ⟨t,δ,hδ,?_⟩
    intro s hs
    obtain ⟨hres,hDOS⟩ := hgap s hs
    exact ⟨hres,(physicalRotationLabel_iff_DOS ha ha1 hr hr1 α hα s label).mpr hDOS.symm⟩

theorem openDOSGapLabel_exchange {a r α : ℝ}
    (ha0 : 0≤a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hα : Irrational α)
    (label : AddCircle (1:ℝ))
    (hgap : OpenDOSGapLabel a r α ha0 ha1 hr hr1 label) :
    OpenDOSGapLabel r a (-α) hr hr1 ha0 ha1 label := by
  obtain ⟨t,δ,hδ,hgap⟩ := hgap
  refine ⟨t,δ,hδ,?_⟩
  intro s hs
  obtain ⟨hres,hlabel⟩ := hgap s hs
  refine ⟨?_,?_⟩
  · intro θ
    have hspec := PhysicalDuality.physical_walk_spectrum_exchange a r α ha0 ha1 hr hr1 hα 0 θ
    have hn : Complex.exp ((s:ℂ)*Complex.I)∉spectrum ℂ
        (PhysicalRepresentation.walk (coupling a) (coupling r) α 0) := by
      simpa only [spectrum,Set.mem_compl_iff,not_not] using hres 0
    rw [hspec] at hn
    simpa only [spectrum,Set.mem_compl_iff,not_not] using hn
  · rw [← PhysicalDuality.physicalUnitaryDOS_exchange a r α ha0 ha1 hr hr1]
    exact hlabel

end UAMO

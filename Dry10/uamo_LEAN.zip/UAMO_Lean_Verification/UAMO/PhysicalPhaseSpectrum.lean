import UAMO.PhysicalRepresentation
import Mathlib.Analysis.CStarAlgebra.CStarMatrix
import Mathlib.Topology.Instances.AddCircle.DenseSubgroup

noncomputable section
namespace UAMO.PhysicalRepresentation
open scoped Matrix

def integerShiftEquiv (k : ℤ) : Hilbert ≃ₗᵢ[ℂ] Hilbert :=
  reindexEquiv
    { toFun := fun n => n + k
      invFun := fun n => n - k
      left_inv := by intro n; simp
      right_inv := by intro n; simp }

def integerShift (k : ℤ) : Operator := integerShiftEquiv k

@[simp] theorem integerShift_apply (k : ℤ) (ψ : Hilbert) (n : ℤ) :
    integerShift k ψ n = ψ (n + k) := rfl

@[simp] theorem integerShift_star_apply (k : ℤ) (ψ : Hilbert) (n : ℤ) :
    star (integerShift k) ψ n = ψ (n - k) := by
  rw [integerShift, LinearIsometryEquiv.star_eq_symm]
  rfl

@[simp] theorem integerShift_mul_star (k : ℤ) :
    integerShift k * star (integerShift k) = 1 := by
  ext ψ n
  simp

@[simp] theorem integerShift_star_mul (k : ℤ) :
    star (integerShift k) * integerShift k = 1 := by
  ext ψ n
  simp

def shiftConjugation (k : ℤ) : Operator →⋆ₐ[ℂ] Operator where
  toFun A := integerShift k * A * star (integerShift k)
  map_one' := by simp
  map_mul' := by
    intro A B
    simp only [mul_assoc, ← mul_assoc (star (integerShift k)), integerShift_star_mul, one_mul]
  map_zero' := by simp
  map_add' := by intro A B; simp only [mul_add, add_mul]
  commutes' := by
    intro c
    simp only [Algebra.algebraMap_eq_smul_one, mul_smul_comm, mul_one,
      smul_mul_assoc, integerShift_mul_star]
  map_star' := by intro A; simp only [star_mul, star_star, mul_assoc]

@[simp] theorem shiftConjugation_apply (k : ℤ) (A : Operator) :
    shiftConjugation k A = integerShift k * A * star (integerShift k) := rfl

def shiftConjugationEquiv (k : ℤ) : Operator ≃ₐ[ℂ] Operator :=
  AlgEquiv.ofBijective (shiftConjugation k).toAlgHom ⟨by
    intro A B h
    have h' := congrArg (fun C : Operator => star (integerShift k) * C * integerShift k) h
    simpa only [StarAlgHom.coe_toAlgHom, shiftConjugation_apply, mul_assoc,
      ← mul_assoc (star (integerShift k)), integerShift_star_mul, one_mul] using h', by
    intro B
    refine ⟨star (integerShift k) * B * integerShift k, ?_⟩
    simp only [StarAlgHom.coe_toAlgHom, shiftConjugation_apply, mul_assoc,
      ← mul_assoc (integerShift k), integerShift_mul_star, one_mul, mul_one]⟩

@[simp] theorem shiftConjugation_shift (k : ℤ) : shiftConjugation k shift = shift := by
  ext ψ n
  simp only [shiftConjugation_apply, ContinuousLinearMap.mul_apply, integerShift_apply,
    shift_apply, integerShift_star_apply]
  exact congrArg (fun m : ℤ => ψ m) (by omega : n + k - 1 - k = n - 1)

@[simp] theorem shiftConjugation_phase (Φ θ : ℝ) (k : ℤ) :
    shiftConjugation k (phase Φ θ) = phase Φ (θ + Φ * (k : ℝ)) := by
  ext ψ n
  simp only [shiftConjugation_apply, ContinuousLinearMap.mul_apply, integerShift_apply,
    phase_apply, integerShift_star_apply, add_sub_cancel_right]
  congr 1
  unfold phaseValue phaseAngle
  congr 2
  push_cast
  ring

theorem map_walk {A B : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]
    [Ring B] [StarRing B] [Algebra ℂ B] [StarModule ℂ B]
    (f : A →⋆ₐ[ℂ] B) (lam₁ lam₂ : ℝ) (u v : A) :
    f.toAlgHom.mapMatrix (PhysicalWalk.walk lam₁ lam₂ u v) =
      PhysicalWalk.walk lam₁ lam₂ (f u) (f v) := by
  unfold PhysicalWalk.walk
  rw [map_mul]
  congr 1
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [AlgHom.mapMatrix, RingHom.mapMatrix, Matrix.map_apply, PhysicalWalk.shiftFactor, map_smul, map_star, ← Complex.coe_smul]
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [AlgHom.mapMatrix, RingHom.mapMatrix, Matrix.map_apply, PhysicalWalk.coinFactor, map_smul, map_star, ← Complex.coe_smul]

theorem walk_phase_covariance (lam₁ lam₂ Φ θ : ℝ) (k : ℤ) :
    (shiftConjugationEquiv k).mapMatrix (walk lam₁ lam₂ Φ θ) =
      walk lam₁ lam₂ Φ (θ + Φ * (k : ℝ)) := by
  change (shiftConjugation k).toAlgHom.mapMatrix
    (PhysicalWalk.walk lam₁ lam₂ shift (phase Φ θ)) = _
  rw [map_walk, shiftConjugation_shift, shiftConjugation_phase]
  rfl

theorem walk_spectrum_phase_shift (lam₁ lam₂ Φ θ : ℝ) (k : ℤ) :
    spectrum ℂ (walk lam₁ lam₂ Φ (θ + Φ * (k : ℝ))) =
      spectrum ℂ (walk lam₁ lam₂ Φ θ) := by
  rw [← walk_phase_covariance]
  exact AlgEquiv.spectrum_eq _ _

theorem phase_periodic (Φ : ℝ) : Function.Periodic (phase Φ) 1 := by
  intro θ
  ext ψ n
  simp only [phase_apply]
  congr 1
  unfold phaseValue phaseAngle
  convert Complex.exp_mul_I_periodic ((2 * Real.pi * ((n : ℝ) * Φ + θ) : ℝ) : ℂ) using 1
  push_cast
  ring

theorem walk_periodic (lam₁ lam₂ Φ : ℝ) : Function.Periodic (walk lam₁ lam₂ Φ) 1 := by
  intro θ
  unfold walk
  rw [phase_periodic Φ θ]

@[simp] theorem walk_phase_add_int (lam₁ lam₂ Φ θ : ℝ) (m : ℤ) :
    walk lam₁ lam₂ Φ (θ + (m : ℝ)) = walk lam₁ lam₂ Φ θ := by
  simpa only [mul_one] using (walk_periodic lam₁ lam₂ Φ).int_mul m θ

theorem phase_eq_scalar_mul (Φ θ : ℝ) :
    phase Φ θ = phaseValue 0 θ 0 • phase Φ 0 := by
  ext ψ n
  simp only [phase_apply, ContinuousLinearMap.smul_apply, lp.coeFn_smul, Pi.smul_apply,
    smul_eq_mul, ← mul_assoc]
  congr 1
  simp only [phaseValue, phaseAngle, ← Complex.exp_add]
  congr 1
  push_cast
  ring

@[fun_prop] theorem continuous_phase (Φ : ℝ) : Continuous (phase Φ) := by
  have h : phase Φ = fun θ => phaseValue 0 θ 0 • phase Φ 0 := funext (phase_eq_scalar_mul Φ)
  rw [h]
  have hc : Continuous (fun θ : ℝ => phaseValue 0 θ 0) := by
    unfold phaseValue phaseAngle
    fun_prop
  exact hc.smul continuous_const

instance physicalOperatorPartialOrder : PartialOrder Operator := CStarAlgebra.spectralOrder _
instance physicalOperatorStarOrderedRing : StarOrderedRing Operator := CStarAlgebra.spectralOrderedRing _

def cstarWalk (lam₁ lam₂ Φ θ : ℝ) : CStarMatrix (Fin 2) (Fin 2) Operator :=
  CStarMatrix.ofMatrix (walk lam₁ lam₂ Φ θ)

theorem cstarWalk_spectrum (lam₁ lam₂ Φ θ : ℝ) :
    spectrum ℂ (cstarWalk lam₁ lam₂ Φ θ) = spectrum ℂ (walk lam₁ lam₂ Φ θ) :=
  AlgEquiv.spectrum_eq (CStarMatrix.ofMatrixStarAlgEquiv :
    PhysicalWalk.TwoByTwo Operator ≃⋆ₐ[ℂ] CStarMatrix (Fin 2) (Fin 2) Operator) _

theorem continuous_cstarWalk (lam₁ lam₂ Φ : ℝ) : Continuous (cstarWalk lam₁ lam₂ Φ) := by
  change Continuous (fun θ =>
    (CStarMatrix.ofMatrix (PhysicalWalk.shiftFactor lam₁ (Real.sqrt (1 - lam₁ ^ 2)) shift)) *
      CStarMatrix.ofMatrix (PhysicalWalk.coinFactor lam₂ (Real.sqrt (1 - lam₂ ^ 2)) (phase Φ θ)))
  apply continuous_const.mul
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  fin_cases i <;> fin_cases j <;>
    norm_num [CStarMatrix.ofMatrix_apply, PhysicalWalk.coinFactor] <;> fun_prop

theorem isOpen_resolvent_phases (lam₁ lam₂ Φ : ℝ) (z : ℂ) :
    IsOpen {θ : ℝ | z ∈ resolventSet ℂ (cstarWalk lam₁ lam₂ Φ θ)} := by
  have h := Units.isOpen.preimage
    ((continuous_const : Continuous
      (fun _ : ℝ => algebraMap ℂ (CStarMatrix (Fin 2) (Fin 2) Operator) z)).sub
        (continuous_cstarWalk lam₁ lam₂ Φ))
  simpa only [Set.preimage_setOf_eq, spectrum.mem_resolventSet_iff] using h

theorem isClosed_spectral_phases (lam₁ lam₂ Φ : ℝ) (z : ℂ) :
    IsClosed {θ : ℝ | z ∈ spectrum ℂ (walk lam₁ lam₂ Φ θ)} := by
  have h := (isOpen_resolvent_phases lam₁ lam₂ Φ z).isClosed_compl
  simpa only [spectrum, cstarWalk_spectrum] using h

theorem phase_shifts_dense {Φ : ℝ} (hΦ : Irrational Φ) :
    Dense (AddSubgroup.closure ({Φ, 1} : Set ℝ) : Set ℝ) := by
  apply dense_addSubgroupClosure_pair_iff.mpr
  simpa only [div_one] using hΦ

private theorem walk_spectrum_phase_subset {Φ : ℝ} (hΦ : Irrational Φ)
    (lam₁ lam₂ θ θ' : ℝ) :
    spectrum ℂ (walk lam₁ lam₂ Φ θ) ⊆ spectrum ℂ (walk lam₁ lam₂ Φ θ') := by
  intro z hz
  have hclosed : IsClosed {t : ℝ | z ∈ spectrum ℂ (walk lam₁ lam₂ Φ (θ + t))} :=
    (isClosed_spectral_phases lam₁ lam₂ Φ z).preimage (continuous_const.add continuous_id)
  have hsubset : (AddSubgroup.closure ({Φ, 1} : Set ℝ) : Set ℝ) ⊆
      {t : ℝ | z ∈ spectrum ℂ (walk lam₁ lam₂ Φ (θ + t))} := by
    intro t ht
    obtain ⟨k, m, rfl⟩ := AddSubgroup.mem_closure_pair.mp ht
    simp only [Set.mem_setOf_eq, zsmul_eq_mul, mul_one]
    rw [← add_assoc, walk_phase_add_int, mul_comm (k : ℝ) Φ, walk_spectrum_phase_shift]
    exact hz
  have hmem := closure_minimal hsubset hclosed (phase_shifts_dense hΦ (θ' - θ))
  simpa only [Set.mem_setOf_eq, add_sub_cancel] using hmem

theorem walk_spectrum_phase_independent {Φ : ℝ} (hΦ : Irrational Φ)
    (lam₁ lam₂ θ θ' : ℝ) :
    spectrum ℂ (walk lam₁ lam₂ Φ θ) = spectrum ℂ (walk lam₁ lam₂ Φ θ') :=
  Set.Subset.antisymm (walk_spectrum_phase_subset hΦ lam₁ lam₂ θ θ')
    (walk_spectrum_phase_subset hΦ lam₁ lam₂ θ' θ)

theorem cstarWalk_spectrum_phase_independent {Φ : ℝ} (hΦ : Irrational Φ)
    (lam₁ lam₂ θ θ' : ℝ) :
    spectrum ℂ (cstarWalk lam₁ lam₂ Φ θ) = spectrum ℂ (cstarWalk lam₁ lam₂ Φ θ') := by
  rw [cstarWalk_spectrum, cstarWalk_spectrum, walk_spectrum_phase_independent hΦ]

end UAMO.PhysicalRepresentation

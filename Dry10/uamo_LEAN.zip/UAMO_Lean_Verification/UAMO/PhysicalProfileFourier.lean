import UAMO.PhysicalSpinSpace
import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.MeasureTheory.Group.Measure

noncomputable section
namespace UAMO.ProfileFourier
open MeasureTheory PhysicalRepresentation PhysicalRealPart
open scoped ENNReal InnerProductSpace ComplexConjugate

local instance unitProfilePeriodPositive : Fact (0<(1:ℝ)) := ⟨zero_lt_one⟩

abbrev ProfileCircle := AddCircle (1:ℝ)
abbrev profileMeasure : Measure ProfileCircle := AddCircle.haarAddCircle
abbrev ScalarProfile := Lp ℂ 2 profileMeasure
abbrev SpinProfile := PiLp 2 (fun _ : Fin 2 => ScalarProfile)

def scalarFourier : ScalarProfile ≃ₗᵢ[ℂ] Hilbert := fourierBasis.repr

theorem scalarFourier_apply (f : ScalarProfile) (n : ℤ) :
    scalarFourier f n=∫x:ProfileCircle,fourier (-n) x*f x ∂profileMeasure :=
  fourierBasis_repr f n

def profileFourier : SpinProfile ≃ₗᵢ[ℂ] SpinHilbert :=
  LinearIsometryEquiv.piLpCongrRight 2 (fun _ => scalarFourier)

@[simp] theorem profileFourier_apply (f : SpinProfile) (i : Fin 2) :
    profileFourier f i=scalarFourier (f i) := rfl

def circleTranslate (b : ProfileCircle) : ScalarProfile →ₗᵢ[ℂ] ScalarProfile :=
  Lp.compMeasurePreservingₗᵢ ℂ (fun x => x+b) (measurePreserving_add_right profileMeasure b)

theorem circleTranslate_ae (b : ProfileCircle) (f : ScalarProfile) :
    circleTranslate b f =ᵐ[profileMeasure] (fun x => f (x+b)) :=
  Lp.coeFn_compMeasurePreserving f (measurePreserving_add_right profileMeasure b)

theorem circleTranslate_add (b c : ProfileCircle) (f : ScalarProfile) :
    circleTranslate b (circleTranslate c f)=circleTranslate (b+c) f := by
  apply Lp.ext
  filter_upwards [circleTranslate_ae b (circleTranslate c f),
    (measurePreserving_add_right profileMeasure b).quasiMeasurePreserving.ae
      (circleTranslate_ae c f),circleTranslate_ae (b+c) f] with x h1 h2 h3
  simpa only [Function.comp_apply,add_assoc] using h1.trans h2
    |>.trans (by simpa only [add_assoc] using h3.symm)

@[simp] theorem circleTranslate_zero (f : ScalarProfile) : circleTranslate 0 f=f := by
  apply Lp.ext
  filter_upwards [circleTranslate_ae 0 f] with x hx
  simpa only [add_zero] using hx

def circleTranslation (b : ProfileCircle) : ScalarProfile ≃ₗᵢ[ℂ] ScalarProfile where
  toLinearEquiv :=
    { toLinearMap := (circleTranslate b).toLinearMap
      invFun := circleTranslate (-b)
      left_inv := by
        intro f
        change circleTranslate (-b) (circleTranslate b f)=f
        rw [circleTranslate_add,neg_add_cancel,circleTranslate_zero]
      right_inv := by
        intro f
        change circleTranslate b (circleTranslate (-b) f)=f
        rw [circleTranslate_add,add_neg_cancel,circleTranslate_zero] }
  norm_map' := (circleTranslate b).norm_map

@[simp] theorem circleTranslation_apply (b : ProfileCircle) (f : ScalarProfile) :
    circleTranslation b f=circleTranslate b f := rfl

def scalarPhaseEquiv (κ : ℂ) (hκ : ‖κ‖=1) : ScalarProfile ≃ₗᵢ[ℂ] ScalarProfile where
  toFun f := κ • f
  invFun f := κ⁻¹ • f
  left_inv := by
    intro f
    have hk : κ≠0 := by intro h; simp [h] at hκ
    simp only [smul_smul,inv_mul_cancel₀ hk,one_smul]
  right_inv := by
    intro f
    have hk : κ≠0 := by intro h; simp [h] at hκ
    simp only [smul_smul,mul_inv_cancel₀ hk,one_smul]
  map_add' := by intro f g; exact smul_add κ f g
  map_smul' := by intro c f; exact smul_comm κ c f
  norm_map' := by intro f; change ‖κ • f‖=‖f‖; rw [norm_smul,hκ,one_mul]

def sameSiteProfile (α : ℝ) (κ : ℂ) (hκ : ‖κ‖=1) : SpinProfile ≃ₗᵢ[ℂ] SpinProfile :=
  LinearIsometryEquiv.piLpCongrRight 2 (fun i : Fin 2 =>
    if i=0 then LinearIsometryEquiv.refl ℂ ScalarProfile else
      (circleTranslation (α:ProfileCircle)).trans (scalarPhaseEquiv κ hκ))

end UAMO.ProfileFourier

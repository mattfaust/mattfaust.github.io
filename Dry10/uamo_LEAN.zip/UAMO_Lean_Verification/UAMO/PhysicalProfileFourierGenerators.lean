import UAMO.PhysicalProfileFourier
import Mathlib.MeasureTheory.Group.Integral

noncomputable section
namespace UAMO.ProfileFourier
open MeasureTheory PhysicalRepresentation
open scoped ENNReal

attribute [local instance] Real.fact_zero_lt_one

theorem profileCharacter_add (n : ℤ) (x b : ProfileCircle) :
    fourier n (x+b)=fourier n x*fourier n b := by
  simp only [fourier_apply,zsmul_add,AddCircle.toCircle_add,Circle.coe_mul]

theorem profileCharacter_neg_cancel (n : ℤ) (b : ProfileCircle) :
    fourier n b*fourier (-n) b=1 := by
  rw [← fourier_add,add_neg_cancel,fourier_zero]

theorem scalarFourier_translate_coefficient (b : ProfileCircle) (f : ScalarProfile) (n : ℤ) :
    scalarFourier (circleTranslate b f) n=fourier n b*scalarFourier f n := by
  rw [scalarFourier_apply,scalarFourier_apply]
  calc
    _ = ∫x:ProfileCircle,fourier (-n) x*f (x+b) ∂profileMeasure := by
      apply integral_congr_ae
      filter_upwards [circleTranslate_ae b f] with x hx
      rw [hx]
    _ = fourier n b * ∫x:ProfileCircle,fourier (-n) (x+b)*f (x+b) ∂profileMeasure := by
      rw [← integral_const_mul]
      apply integral_congr_ae
      exact Filter.Eventually.of_forall (fun x => by
        dsimp only
        rw [profileCharacter_add]
        calc
          _ = (fourier (-n) x*(fourier n b*fourier (-n) b))*f (x+b) := by
            rw [profileCharacter_neg_cancel,mul_one]
          _ = _ := by ring)
    _ = _ := congrArg (fun z : ℂ => fourier n b*z)
      (integral_add_right_eq_self (μ:=profileMeasure)
        (fun x:ProfileCircle => fourier (-n) x*f x) b)

theorem profileCharacter_real (α : ℝ) (n : ℤ) :
    fourier n (α:ProfileCircle)=phaseValue α 0 n := by
  rw [fourier_coe_apply,phaseValue,phaseAngle]
  congr 1
  push_cast
  ring

theorem scalarFourier_translation (α : ℝ) (f : ScalarProfile) :
    scalarFourier (circleTranslation (α:ProfileCircle) f)=phase α 0 (scalarFourier f) := by
  ext n
  rw [circleTranslation_apply,scalarFourier_translate_coefficient,phase_apply,profileCharacter_real]

theorem circleModulate_memLp (m : ℤ) (f : ScalarProfile) :
    MemLp (fun x:ProfileCircle => fourier m x*f x) 2 profileMeasure := by
  apply (Lp.memLp f).of_le
    ((fourier m).continuous.aestronglyMeasurable.mul (Lp.aestronglyMeasurable f))
  exact Filter.Eventually.of_forall (fun x => by
    change ‖fourier m x*f x‖≤‖f x‖
    rw [norm_mul,show ‖fourier m x‖=1 from Circle.norm_coe _,one_mul])

def circleModulate (m : ℤ) (f : ScalarProfile) : ScalarProfile :=
  (circleModulate_memLp m f).toLp (fun x => fourier m x*f x)

theorem circleModulate_ae (m : ℤ) (f : ScalarProfile) :
    circleModulate m f =ᵐ[profileMeasure] (fun x => fourier m x*f x) :=
  (circleModulate_memLp m f).coeFn_toLp

theorem scalarFourier_modulate_coefficient (m : ℤ) (f : ScalarProfile) (n : ℤ) :
    scalarFourier (circleModulate m f) n=scalarFourier f (n-m) := by
  rw [scalarFourier_apply,scalarFourier_apply]
  apply integral_congr_ae
  filter_upwards [circleModulate_ae m f] with x hx
  rw [hx,← mul_assoc,← fourier_add]
  congr 2
  ring

def profileIndexSubtract (m : ℤ) : ℤ ≃ ℤ where
  toFun n := n-m
  invFun n := n+m
  left_inv := by intro n; simp
  right_inv := by intro n; simp

theorem scalarFourier_modulate (m : ℤ) (f : ScalarProfile) :
    scalarFourier (circleModulate m f)=
      reindexEquiv (profileIndexSubtract m) (scalarFourier f) := by
  ext n
  exact scalarFourier_modulate_coefficient m f n

theorem circleModulate_norm (m : ℤ) (f : ScalarProfile) : ‖circleModulate m f‖=‖f‖ := by
  rw [← scalarFourier.norm_map (circleModulate m f),scalarFourier_modulate,
    (reindexEquiv (profileIndexSubtract m)).norm_map,scalarFourier.norm_map]

theorem circleModulate_add (m : ℤ) (f g : ScalarProfile) :
    circleModulate m (f+g)=circleModulate m f+circleModulate m g := by
  apply scalarFourier.injective
  ext n
  simp only [scalarFourier_modulate_coefficient,map_add,lp.coeFn_add,Pi.add_apply]

theorem circleModulate_smul (m : ℤ) (c : ℂ) (f : ScalarProfile) :
    circleModulate m (c • f)=c • circleModulate m f := by
  apply scalarFourier.injective
  ext n
  simp only [scalarFourier_modulate_coefficient,map_smul,lp.coeFn_smul,Pi.smul_apply]

theorem circleModulate_inverse (m : ℤ) (f : ScalarProfile) :
    circleModulate (-m) (circleModulate m f)=f := by
  apply scalarFourier.injective
  ext n
  rw [scalarFourier_modulate_coefficient,scalarFourier_modulate_coefficient,
    show n- -m-m=n by ring]

def circleModulation (m : ℤ) : ScalarProfile ≃ₗᵢ[ℂ] ScalarProfile where
  toFun := circleModulate m
  invFun := circleModulate (-m)
  left_inv := circleModulate_inverse m
  right_inv := by intro f; simpa only [neg_neg] using circleModulate_inverse (-m) f
  map_add' := circleModulate_add m
  map_smul' := circleModulate_smul m
  norm_map' := circleModulate_norm m

theorem scalarFourier_modulation_one (f : ScalarProfile) :
    scalarFourier (circleModulation 1 f)=shift (scalarFourier f) := by
  ext n
  exact scalarFourier_modulate_coefficient 1 f n

end UAMO.ProfileFourier

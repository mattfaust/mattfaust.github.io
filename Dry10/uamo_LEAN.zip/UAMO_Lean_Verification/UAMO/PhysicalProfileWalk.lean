import UAMO.PhysicalProfileFourierGenerators
import UAMO.PhysicalDualityAlgebra

noncomputable section
namespace UAMO.ProfileFourier
open Matrix PhysicalRepresentation PhysicalRealPart PhysicalWalk
open scoped InnerProductSpace

abbrev ProfileOperator := ScalarProfile →L[ℂ] ScalarProfile

def fourierOperatorMap : ProfileOperator →⋆ₐ[ℂ] Operator where
  toFun T := (scalarFourier : ScalarProfile →L[ℂ] Hilbert) ∘L T ∘L
    (scalarFourier.symm : Hilbert →L[ℂ] ScalarProfile)
  map_one' := by ext ψ; simp
  map_zero' := by ext ψ; simp
  map_add' := by intro A B; ext ψ; simp
  map_mul' := by intro A B; ext ψ; simp
  commutes' := by intro c; ext ψ; simp [Algebra.algebraMap_eq_smul_one]
  map_star' := by
    intro T
    simp only [ContinuousLinearMap.star_eq_adjoint,ContinuousLinearMap.adjoint_comp,
      LinearIsometryEquiv.adjoint_eq_symm,LinearIsometryEquiv.symm_symm,
      ContinuousLinearMap.comp_assoc]

@[simp] theorem fourierOperatorMap_apply (T : ProfileOperator) (ψ : Hilbert) :
    fourierOperatorMap T ψ=scalarFourier (T (scalarFourier.symm ψ)) := rfl

theorem fourierOperatorMap_intertwine (T : ProfileOperator) (f : ScalarProfile) :
    fourierOperatorMap T (scalarFourier f)=scalarFourier (T f) := by simp

def blochMultiplier (ξ : ℝ) : ℂ := Complex.exp (((2*Real.pi*ξ:ℝ):ℂ)*Complex.I)

theorem blochMultiplier_norm (ξ : ℝ) : ‖blochMultiplier ξ‖=1 :=
  Complex.norm_exp_ofReal_mul_I _

def profileShift (α ξ : ℝ) : ProfileOperator :=
  (blochMultiplier ξ)⁻¹ • (circleTranslation ((-α:ℝ):ProfileCircle) : ProfileOperator)

def profilePhase : ProfileOperator := circleModulation 1

theorem fourierOperatorMap_profilePhase : fourierOperatorMap profilePhase=shift := by
  ext ψ n
  rw [fourierOperatorMap_apply]
  change scalarFourier (circleModulation 1 (scalarFourier.symm ψ)) n=shift ψ n
  rw [scalarFourier_modulation_one,LinearIsometryEquiv.apply_symm_apply]

def profileAction (M : TwoByTwo ProfileOperator) (f : SpinProfile) : SpinProfile :=
  fun i => M i 0 (f 0)+M i 1 (f 1)

def profileWalk (a r α ξ : ℝ) : TwoByTwo ProfileOperator :=
  PhysicalWalk.walk (coupling a) (coupling r) (profileShift α ξ) profilePhase

end UAMO.ProfileFourier

import UAMO.PhysicalWalk
import Mathlib.Tactic

noncomputable section
namespace UAMO.PhysicalRealPart
open PhysicalWalk
open scoped Matrix

section Algebra
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

def qTerm (lam co : ℝ) (v : A) : A :=
  ((lam/2 : ℝ) : ℂ) • (v+star v) + (Complex.I*(co : ℂ)) • (1 : A)

def bTerm (lam : ℝ) (v : A) : A :=
  (-Complex.I*((lam/2 : ℝ) : ℂ)) • (v-star v)

def coinQB (q b : A) : TwoByTwo A := !![q,-b;b,star q]

theorem coinFactor_eq_coinQB (lam co : ℝ) (v : A) :
    coinFactor lam co v = coinQB (qTerm lam co v) (bTerm lam v) := by
  ext i j
  fin_cases i <;> fin_cases j
  all_goals simp only [coinFactor, coinQB, qTerm, bTerm, Matrix.of_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    Fin.zero_eta, Fin.mk_one, star_add, star_smul, star_star, star_one,
    Complex.star_def, map_mul, Complex.conj_I, Complex.conj_ofReal,
    neg_mul, neg_smul]
  all_goals module

def matrixRealPart (W : TwoByTwo A) : TwoByTwo A := (1/2 : ℂ) • (W+star W)

def upperShift (u : A) : TwoByTwo A := !![star u,0;0,1]

omit [Algebra ℂ A] [StarModule ℂ A] in
theorem upperShift_unitary (u : A) (hu : u ∈ unitary A) :
    upperShift u ∈ unitary (TwoByTwo A) := by
  constructor <;> ext i j <;> fin_cases i <;> fin_cases j
  all_goals simp [upperShift, Matrix.mul_apply, Fin.sum_univ_two,
    Matrix.conjTranspose_apply, unitary.star_mul_self_of_mem hu,
    unitary.mul_star_self_of_mem hu]

def alignedHopping (lam : ℝ) (u q : A) : A :=
  ((lam/2 : ℝ) : ℂ) • (q*u+star u*star q)

def forwardDiagonal (u b : A) : A := star u*b*u

def spinRotationRaw (a : ℝ) : TwoByTwo A :=
  !![(a : ℂ) • (1 : A),-1;1,(a : ℂ) • (1 : A)]

def spinRotation (a : ℝ) : TwoByTwo A :=
  (((Real.sqrt (1+a^2))⁻¹ : ℝ) : ℂ) • spinRotationRaw a

theorem spinRotationRaw_gram (a : ℝ) :
    star (spinRotationRaw a : TwoByTwo A) * spinRotationRaw a =
      ((1+a^2 : ℝ) : ℂ) • (1 : TwoByTwo A) ∧
    (spinRotationRaw a : TwoByTwo A) * star (spinRotationRaw a) =
      ((1+a^2 : ℝ) : ℂ) • (1 : TwoByTwo A) := by
  constructor <;> ext i j <;> fin_cases i <;> fin_cases j
  all_goals simp only [spinRotationRaw, Matrix.mul_apply, Fin.sum_univ_two,
    Matrix.star_apply, Matrix.conjTranspose_apply, Matrix.of_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one, Matrix.smul_apply, Matrix.one_apply,
    Fin.zero_eta, Fin.mk_one, zero_ne_one, one_ne_zero, if_true, if_false,
    star_smul, star_one, star_neg, Complex.star_def, Complex.conj_ofReal,
    smul_mul_assoc, mul_smul_comm, smul_smul, mul_neg, neg_mul, neg_neg,
    one_mul, mul_one, smul_zero, Complex.ofReal_add, Complex.ofReal_one, Complex.ofReal_pow]
  all_goals module

theorem spinRotation_unitary (a : ℝ) : spinRotation a ∈ unitary (TwoByTwo A) := by
  have hn : Real.sqrt (1+a^2) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr (by positivity))
  have hc : (((Real.sqrt (1+a^2))⁻¹ : ℝ) : ℂ) *
      (((Real.sqrt (1+a^2))⁻¹ : ℝ) : ℂ) * ((1+a^2 : ℝ) : ℂ) = 1 := by
    norm_cast
    rw [← Real.sq_sqrt (show 0 ≤ 1+a^2 by positivity)]
    field_simp
  apply unitary.mem_iff.mpr
  simp only [spinRotation, star_smul, Complex.star_def, Complex.conj_ofReal,
    smul_mul_assoc, mul_smul_comm, smul_smul]
  constructor
  · rw [(spinRotationRaw_gram (A := A) a).1, smul_smul, hc, one_smul]
  · rw [(spinRotationRaw_gram (A := A) a).2, smul_smul, hc, one_smul]

def realPartGauge (a : ℝ) (u : A) : TwoByTwo A := star (spinRotation a) * upperShift u

theorem realPartGauge_unitary (a : ℝ) (u : A) (hu : u ∈ unitary A) :
    realPartGauge a u ∈ unitary (TwoByTwo A) :=
  (unitary _).mul_mem (unitary.star_mem (spinRotation_unitary a)) (upperShift_unitary u hu)

def plusChannel (a : ℝ) (u q b : A) : A :=
  alignedHopping (coupling a) u q +
    (((1+a^2)⁻¹ : ℝ) : ℂ) • (((a^2 : ℝ) : ℂ) • forwardDiagonal u b-b)

def minusChannel (a : ℝ) (u q b : A) : A :=
  alignedHopping (coupling a) u q +
    (((1+a^2)⁻¹ : ℝ) : ℂ) • (((a^2 : ℝ) : ℂ) • b-forwardDiagonal u b)

end Algebra
end UAMO.PhysicalRealPart

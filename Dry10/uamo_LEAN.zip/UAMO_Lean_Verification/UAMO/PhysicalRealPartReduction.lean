import UAMO.PhysicalRealPartAlgebra
import UAMO.PhysicalSpinSpace

noncomputable section
namespace UAMO.PhysicalRealPart
open PhysicalRepresentation PhysicalWalk
open scoped Matrix

def physicalQ (lam co Φ θ : ℝ) : Operator := qTerm lam co (phase Φ θ)

def physicalB (lam Φ θ : ℝ) : Operator := bTerm lam (phase Φ θ)

def qValue (lam co x : ℝ) : ℂ := ((lam * Real.cos x : ℝ) : ℂ) + Complex.I * (co : ℂ)

def bValue (lam x : ℝ) : ℝ := lam * Real.sin x

theorem phase_star_apply (Φ θ : ℝ) (ψ : Hilbert) (n : ℤ) :
    star (phase Φ θ) ψ n = star (phaseValue Φ θ n) * ψ n := by
  rw [phase, LinearIsometryEquiv.star_eq_symm]
  change Complex.exp (((-phaseAngle Φ θ n : ℝ) : ℂ)*Complex.I)*ψ n = _
  simp only [phaseValue, Complex.star_def, ← Complex.exp_conj, map_mul,
    Complex.conj_ofReal, Complex.conj_I, Complex.ofReal_neg, neg_mul, mul_neg]

theorem phaseValue_trigonometric (Φ θ : ℝ) (n : ℤ) :
    phaseValue Φ θ n = (Real.cos (phaseAngle Φ θ n) : ℂ) +
      (Real.sin (phaseAngle Φ θ n) : ℂ) * Complex.I := by
  simp [phaseValue, Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]

theorem physicalQ_apply (lam co Φ θ : ℝ) (ψ : Hilbert) (n : ℤ) :
    physicalQ lam co Φ θ ψ n = qValue lam co (phaseAngle Φ θ n) * ψ n := by
  simp only [physicalQ, qTerm, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.smul_apply, ContinuousLinearMap.one_apply,
    lp.coeFn_add, lp.coeFn_smul, Pi.add_apply, Pi.smul_apply, smul_eq_mul,
    phase_apply, phase_star_apply, phaseValue_trigonometric, qValue,
    Complex.star_def, map_add, map_mul, Complex.conj_ofReal, Complex.conj_I,
    Complex.ofReal_mul, Complex.ofReal_div, Complex.ofReal_ofNat]
  ring

theorem physicalB_apply (lam Φ θ : ℝ) (ψ : Hilbert) (n : ℤ) :
    physicalB lam Φ θ ψ n = (bValue lam (phaseAngle Φ θ n) : ℂ) * ψ n := by
  simp only [physicalB, bTerm, ContinuousLinearMap.sub_apply, ContinuousLinearMap.smul_apply,
    lp.coeFn_sub, lp.coeFn_smul, Pi.sub_apply, Pi.smul_apply, smul_eq_mul,
    phase_apply, phase_star_apply, phaseValue_trigonometric, bValue,
    Complex.star_def, map_add, map_mul, Complex.conj_ofReal, Complex.conj_I,
    Complex.ofReal_mul, Complex.ofReal_div, Complex.ofReal_ofNat]
  ring_nf
  simp [Complex.I_sq]

theorem physicalQ_star_apply (lam co Φ θ : ℝ) (ψ : Hilbert) (n : ℤ) :
    star (physicalQ lam co Φ θ) ψ n = star (qValue lam co (phaseAngle Φ θ n)) * ψ n := by
  simp only [physicalQ, qTerm, star_add, star_smul, star_star, star_one,
    Complex.star_def, map_mul, Complex.conj_ofReal, Complex.conj_I,
    ContinuousLinearMap.add_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.one_apply, lp.coeFn_add, lp.coeFn_smul,
    Pi.add_apply, Pi.smul_apply, smul_eq_mul, phase_apply, phase_star_apply,
    phaseValue_trigonometric, qValue, map_add, Complex.ofReal_mul,
    Complex.ofReal_div, Complex.ofReal_ofNat, map_div₀, map_ofNat]
  ring

end UAMO.PhysicalRealPart

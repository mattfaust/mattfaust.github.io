import UAMO.PhysicalWalk
import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.CStarAlgebra.ContinuousLinearMap
import Lean.Elab.Tactic.Omega

namespace UAMO
namespace PhysicalRepresentation

noncomputable section

abbrev Hilbert := ℓ²(ℤ, ℂ)
abbrev Operator := Hilbert →L[ℂ] Hilbert

private theorem summable_norm_sq (ψ : Hilbert) :
    Summable (fun n => ‖ψ n‖ ^ (2 : ℕ)) := by
  simpa using (lp.memℓp ψ).summable (show 0 < (2 : ENNReal).toReal by norm_num)

private theorem norm_sq (ψ : Hilbert) : ‖ψ‖ ^ 2 = ∑' n, ‖ψ n‖ ^ (2 : ℕ) := by
  simpa using lp.norm_rpow_eq_tsum (show 0 < (2 : ENNReal).toReal by norm_num) ψ

def reindexVector (e : ℤ ≃ ℤ) (ψ : Hilbert) : Hilbert :=
  ⟨fun n => ψ (e n), by
    apply memℓp_gen
    simpa [Function.comp_def] using e.summable_iff.mpr (summable_norm_sq ψ)⟩

theorem reindexVector_norm (e : ℤ ≃ ℤ) (ψ : Hilbert) :
    ‖reindexVector e ψ‖ = ‖ψ‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [norm_sq, norm_sq]
  exact e.tsum_eq (fun n => ‖ψ n‖ ^ (2 : ℕ))

def reindexEquiv (e : ℤ ≃ ℤ) : Hilbert ≃ₗᵢ[ℂ] Hilbert where
  toFun := reindexVector e
  invFun := reindexVector e.symm
  left_inv := by
    intro ψ
    apply lp.ext
    funext n
    simp [reindexVector]
  right_inv := by
    intro ψ
    apply lp.ext
    funext n
    simp [reindexVector]
  map_add' := by
    intro ψ χ
    apply lp.ext
    rfl
  map_smul' := by
    intro c ψ
    apply lp.ext
    rfl
  norm_map' := reindexVector_norm e

def predecessor : ℤ ≃ ℤ where
  toFun := fun n => n - 1
  invFun := fun n => n + 1
  left_inv := by intro n; simp
  right_inv := by intro n; simp

def shift : Operator := reindexEquiv predecessor

@[simp] theorem shift_apply (ψ : Hilbert) (n : ℤ) :
    shift ψ n = ψ (n - 1) := rfl

theorem shift_unitary : shift ∈ unitary Operator :=
  (unitary.linearIsometryEquiv.symm (reindexEquiv predecessor)).property

@[simp] theorem shift_star_apply (ψ : Hilbert) (n : ℤ) :
    star shift ψ n = ψ (n + 1) := by
  rw [shift, LinearIsometryEquiv.star_eq_symm]
  rfl

def phaseVector (t : ℤ → ℝ) (ψ : Hilbert) : Hilbert :=
  ⟨fun n => Complex.exp ((t n : ℂ) * Complex.I) * ψ n, by
    apply memℓp_gen
    simpa [norm_mul, Complex.norm_exp_ofReal_mul_I]
      using summable_norm_sq ψ⟩

@[simp] theorem phaseVector_apply (t : ℤ → ℝ) (ψ : Hilbert) (n : ℤ) :
    phaseVector t ψ n = Complex.exp ((t n : ℂ) * Complex.I) * ψ n := rfl

theorem phaseVector_norm (t : ℤ → ℝ) (ψ : Hilbert) : ‖phaseVector t ψ‖ = ‖ψ‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [norm_sq, norm_sq]
  simp only [phaseVector_apply, norm_mul, Complex.norm_exp_ofReal_mul_I, one_mul]

def phaseEquiv (t : ℤ → ℝ) : Hilbert ≃ₗᵢ[ℂ] Hilbert where
  toFun := phaseVector t
  invFun := phaseVector (fun n => -t n)
  left_inv := by
    intro ψ
    apply lp.ext
    funext n
    simp only [phaseVector_apply, Complex.ofReal_neg, neg_mul, Complex.exp_neg,
      ← mul_assoc, inv_mul_cancel₀ (Complex.exp_ne_zero _), one_mul]
  right_inv := by
    intro ψ
    apply lp.ext
    funext n
    simp only [phaseVector_apply, Complex.ofReal_neg, neg_mul, Complex.exp_neg,
      ← mul_assoc, mul_inv_cancel₀ (Complex.exp_ne_zero _), one_mul]
  map_add' := by
    intro ψ χ
    apply lp.ext
    funext n
    simp [mul_add]
  map_smul' := by
    intro c ψ
    apply lp.ext
    funext n
    simp [mul_left_comm]
  norm_map' := phaseVector_norm t

def phaseAngle (Φ θ : ℝ) (n : ℤ) : ℝ := 2 * Real.pi * ((n : ℝ) * Φ + θ)

def phaseValue (Φ θ : ℝ) (n : ℤ) : ℂ :=
  Complex.exp ((phaseAngle Φ θ n : ℂ) * Complex.I)

def phase (Φ θ : ℝ) : Operator := phaseEquiv (phaseAngle Φ θ)

@[simp] theorem phase_apply (Φ θ : ℝ) (ψ : Hilbert) (n : ℤ) :
    phase Φ θ ψ n = phaseValue Φ θ n * ψ n := rfl

theorem phase_unitary (Φ θ : ℝ) : phase Φ θ ∈ unitary Operator :=
  (unitary.linearIsometryEquiv.symm (phaseEquiv (phaseAngle Φ θ))).property

def weylPhase (Φ : ℝ) : ℂ := Complex.exp (((-2 * Real.pi * Φ : ℝ) : ℂ) * Complex.I)

def delta (n : ℤ) : Hilbert := lp.single 2 n (1 : ℂ)

def walk (lam₁ lam₂ Φ θ : ℝ) : PhysicalWalk.TwoByTwo Operator :=
  PhysicalWalk.walk lam₁ lam₂ shift (phase Φ θ)

end
end PhysicalRepresentation
end UAMO

import UAMO.CMVAngularDOS
import UAMO.PhysicalRotationIntegerPeriod
import UAMO.AxisRotationLabels

noncomputable section
namespace UAMO
open CMV CircleDOS PhysicalDOS Set

theorem physicalRotationLabel_DOS {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (α : ℝ)
    (hα : Irrational α) (t : ℝ) :
    HasPhysicalRotationLabel a (coupling r) t α
      ((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le)
        (Complex.exp ((t:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ)) := by
  apply physicalRotationLabel_of_fundamental_turn a (coupling r) α _ _ t
  intro u hu
  rcases eq_or_lt_of_le hu.1 with hu0 | hu0
  · have he : u=0 := hu0.symm
    subst u
    simpa only [Complex.ofReal_zero,zero_mul,Complex.exp_zero] using
      (physical_axis_rotation_DOS_labels ha ha1 hr hr1 α).1
  · exact ⟨_,physicalAngularRotation_eq_DOS_arcLabel ha ha1 hr hr1 α hα hu0 hu.2,rfl⟩

theorem physicalRotationLabel_iff_DOS {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (α : ℝ)
    (hα : Irrational α) (t : ℝ) (label : AddCircle (1:ℝ)) :
    HasPhysicalRotationLabel a (coupling r) t α label ↔
      label=((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le)
        (Complex.exp ((t:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ)) := by
  constructor
  · intro h
    exact physicalRotationLabel_unique h (physicalRotationLabel_DOS ha ha1 hr hr1 α hα t)
  · intro h
    rw [h]
    exact physicalRotationLabel_DOS ha ha1 hr hr1 α hα t

theorem physicalRotationLabel_DOS_arg {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (α : ℝ)
    (hα : Irrational α) {z : ℂ} (hz : ‖z‖=1) :
    HasPhysicalRotationLabel a (coupling r) z.arg α
      ((arcLabel (physicalUnitaryDOS a r α ha.le ha1 hr hr1.le) z:ℝ):AddCircle (1:ℝ)) := by
  have he : Complex.exp ((z.arg:ℂ)*Complex.I)=z := by
    simpa only [hz,Complex.ofReal_one,one_mul] using Complex.norm_mul_exp_arg_mul_I z
  simpa only [he] using physicalRotationLabel_DOS ha ha1 hr hr1 α hα z.arg

end UAMO

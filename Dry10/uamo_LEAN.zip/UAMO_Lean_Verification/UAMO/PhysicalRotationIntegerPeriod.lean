import Mathlib
import UAMO.CircleArcLabel
import UAMO.FiniteAngularSpectralFlow
import UAMO.PhysicalGapRotation

noncomputable section
namespace UAMO
open ProjectiveAngle Filter Set CircleDOS MeasureTheory
open scoped Topology

theorem finiteAngularFlow_add_int_period (a lam t α x s : ℝ) (n : ℕ) (k : ℤ) :
    finiteAngularFlow a lam (t+(k:ℝ)*(2*Real.pi)) α x s n=
      finiteAngularFlow a lam t α x s n+(n:ℝ)*(k:ℝ)*(2*Real.pi) := by
  have hp : Function.Periodic
      (fun u:ℝ => finiteAngularFlow a lam u α x s n-(n:ℝ)*u) (2*Real.pi) := by
    intro u
    dsimp only
    rw [finiteAngularFlow_spectral_periodic]
    ring
  have h := hp.int_mul k t
  simp only [zsmul_eq_mul] at h
  linarith

theorem physicalAngularMean_add_int_period (a lam t α x s : ℝ) (k : ℤ)
    {n : ℕ} (hn : n≠0) :
    physicalAngularMean a lam (t+(k:ℝ)*(2*Real.pi)) α x s n=
      physicalAngularMean a lam t α x s n+(k:ℝ) := by
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast hn
  change (finiteAngularFlow a lam (t+(k:ℝ)*(2*Real.pi)) α x s n-s)/
    (2*Real.pi*(n:ℝ))=(finiteAngularFlow a lam t α x s n-s)/(2*Real.pi*(n:ℝ))+(k:ℝ)
  rw [finiteAngularFlow_add_int_period]
  field_simp [hn0,Real.pi_ne_zero]
  ring

theorem physicalAngularRotation_add_int_period {a lam t α ρ : ℝ}
    (hρ : HasPhysicalAngularRotation a lam t α ρ) (k : ℤ) :
    HasPhysicalAngularRotation a lam (t+(k:ℝ)*(2*Real.pi)) α (ρ+(k:ℝ)) := by
  intro x s
  apply ((hρ x s).add_const (k:ℝ)).congr'
  filter_upwards [eventually_ge_atTop (1:ℕ)] with n hn
  exact (physicalAngularMean_add_int_period a lam t α x s k (by omega)).symm

theorem physicalRotationLabel_add_int_period {a lam t α : ℝ}
    {label : AddCircle (1:ℝ)} (hlabel : HasPhysicalRotationLabel a lam t α label)
    (k : ℤ) : HasPhysicalRotationLabel a lam (t+(k:ℝ)*(2*Real.pi)) α label := by
  obtain ⟨ρ,hρ,he⟩ := hlabel
  refine ⟨ρ+(k:ℝ),physicalAngularRotation_add_int_period hρ k,?_⟩
  have hk : ((k:ℝ):AddCircle (1:ℝ))=0 := by
    rw [AddCircle.coe_eq_zero_iff]
    exact ⟨k,by simp⟩
  rw [AddCircle.coe_add,hk,add_zero,he]

theorem circleExp_add_int_period (t : ℝ) (k : ℤ) :
    Complex.exp (((t+(k:ℝ)*(2*Real.pi):ℝ):ℂ)*Complex.I)=
      Complex.exp ((t:ℂ)*Complex.I) := by
  have hp : Function.Periodic (fun u:ℝ => Complex.exp ((u:ℂ)*Complex.I)) (2*Real.pi) := by
    intro u
    push_cast
    rw [add_mul,Complex.exp_add,Complex.exp_two_pi_mul_I,mul_one]
  simpa only [zsmul_eq_mul] using hp.int_mul k t

theorem physicalRotationLabel_of_fundamental_turn (a lam α : ℝ) (ν : Measure ℂ)
    (hfund : ∀t∈Ico (0:ℝ) (2*Real.pi),HasPhysicalRotationLabel a lam t α
      ((arcLabel ν (Complex.exp ((t:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ))) (t : ℝ) :
    HasPhysicalRotationLabel a lam t α
      ((arcLabel ν (Complex.exp ((t:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ)) := by
  obtain ⟨k,hk,_⟩ := existsUnique_sub_zsmul_mem_Ico Real.two_pi_pos t 0
  simp only [zsmul_eq_mul,zero_add] at hk
  let u := t-(k:ℝ)*(2*Real.pi)
  have hu : u∈Ico (0:ℝ) (2*Real.pi) := hk
  have he : u+(k:ℝ)*(2*Real.pi)=t := by dsimp [u]; ring
  have h := physicalRotationLabel_add_int_period (hfund u hu) k
  have hz := circleExp_add_int_period u k
  rw [he] at h hz
  rw [hz]
  exact h

end UAMO

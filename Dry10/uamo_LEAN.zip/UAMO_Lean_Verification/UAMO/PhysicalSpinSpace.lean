import UAMO.PhysicalRepresentation
import Mathlib.Analysis.InnerProductSpace.PiL2

noncomputable section
namespace UAMO.PhysicalRealPart
open PhysicalRepresentation PhysicalWalk
open scoped InnerProductSpace Matrix

abbrev SpinHilbert := PiLp 2 (fun _ : Fin 2 => Hilbert)

def spinAction (M : TwoByTwo Operator) (ψ : SpinHilbert) : SpinHilbert :=
  fun i => M i 0 (ψ 0) + M i 1 (ψ 1)

@[simp] theorem spinAction_apply (M : TwoByTwo Operator) (ψ : SpinHilbert) (i : Fin 2) :
    spinAction M ψ i = M i 0 (ψ 0) + M i 1 (ψ 1) := rfl

theorem spinAction_one (ψ : SpinHilbert) : spinAction 1 ψ = ψ := by
  apply PiLp.ext
  intro i
  fin_cases i <;> simp [spinAction, Matrix.one_apply, Fin.zero_eta, Fin.mk_one]

theorem spinAction_mul (M N : TwoByTwo Operator) (ψ : SpinHilbert) :
    spinAction (M*N) ψ = spinAction M (spinAction N ψ) := by
  ext i
  simp only [spinAction_apply, Matrix.mul_apply, Fin.sum_univ_two,
    ContinuousLinearMap.add_apply, ContinuousLinearMap.mul_apply, map_add]
  abel

theorem spinAction_add (M : TwoByTwo Operator) (ψ χ : SpinHilbert) :
    spinAction M (ψ+χ) = spinAction M ψ+spinAction M χ := by
  ext i
  simp only [spinAction_apply, PiLp.add_apply, map_add]
  abel

theorem spinAction_smul (M : TwoByTwo Operator) (c : ℂ) (ψ : SpinHilbert) :
    spinAction M (c • ψ) = c • spinAction M ψ := by
  ext i
  simp only [spinAction_apply, PiLp.smul_apply, map_smul, smul_add]

theorem spinAction_adjoint (M : TwoByTwo Operator) (ψ χ : SpinHilbert) :
    ⟪spinAction M ψ,χ⟫_ℂ = ⟪ψ,spinAction (star M) χ⟫_ℂ := by
  simp only [PiLp.inner_apply, Fin.sum_univ_two, spinAction_apply,
    inner_add_left, inner_add_right, Matrix.star_apply,
    ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_inner_right]
  ring

theorem spinAction_inner (M : TwoByTwo Operator) (hM : M ∈ unitary (TwoByTwo Operator))
    (ψ χ : SpinHilbert) : ⟪spinAction M ψ,spinAction M χ⟫_ℂ = ⟪ψ,χ⟫_ℂ := by
  rw [spinAction_adjoint, ← spinAction_mul, unitary.star_mul_self_of_mem hM, spinAction_one]

theorem spinAction_norm (M : TwoByTwo Operator) (hM : M ∈ unitary (TwoByTwo Operator))
    (ψ : SpinHilbert) : ‖spinAction M ψ‖ = ‖ψ‖ := by
  rw [@norm_eq_sqrt_re_inner ℂ, @norm_eq_sqrt_re_inner ℂ, spinAction_inner M hM]

def spinUnitaryEquiv (M : TwoByTwo Operator) (hM : M ∈ unitary (TwoByTwo Operator)) :
    SpinHilbert ≃ₗᵢ[ℂ] SpinHilbert where
  toFun := spinAction M
  invFun := spinAction (star M)
  left_inv := by
    intro ψ
    rw [← spinAction_mul, unitary.star_mul_self_of_mem hM, spinAction_one]
  right_inv := by
    intro ψ
    rw [← spinAction_mul, unitary.mul_star_self_of_mem hM, spinAction_one]
  map_add' := spinAction_add M
  map_smul' := spinAction_smul M
  norm_map' := spinAction_norm M hM

end UAMO.PhysicalRealPart

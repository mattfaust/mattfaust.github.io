import UAMO.PhysicalTransferResidual
import UAMO.PhysicalHoppingInverse
import Mathlib.Algebra.Algebra.Spectrum.Basic

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart
open scoped Matrix

private theorem triangular_isUnit {A : Type*} [Ring A] (a b d : A)
    (ha : IsUnit a) (hd : IsUnit d) : IsUnit (!![a,b;0,d] : TwoByTwo A) := by
  obtain ⟨u,rfl⟩ := ha
  obtain ⟨v,rfl⟩ := hd
  refine ⟨⟨!![↑u,b;0,↑v], !![↑u⁻¹,-(↑u⁻¹*b*↑v⁻¹);0,↑v⁻¹], ?_, ?_⟩, rfl⟩
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [Matrix.mul_apply, Fin.sum_univ_two, mul_assoc]
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [Matrix.mul_apply, Fin.sum_univ_two, mul_assoc]

def residualCoefficientOperator (a r Φ θ : ℝ) (z : ℂ) : TwoByTwo Operator :=
  !![(-z*(coupling a : ℂ)) • (1 : Operator),
    -physicalB (coupling r) Φ θ - (z*(complementaryCoupling a : ℂ)) • (1 : Operator);
    0, star (physicalQ (coupling r) (complementaryCoupling r) Φ θ)]

theorem residualCoefficientOperator_isUnit {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (Φ θ : ℝ) {z : ℂ} (hz : z ≠ 0) :
    IsUnit (residualCoefficientOperator a r Φ θ z) := by
  apply triangular_isUnit
  · have h : IsUnit (-z*(coupling a : ℂ)) := isUnit_iff_ne_zero.mpr
      (mul_ne_zero (neg_ne_zero.mpr hz)
        (Complex.ofReal_ne_zero.mpr (ne_of_gt (coupling_pos ha))))
    simpa only [Algebra.algebraMap_eq_smul_one] using h.map (algebraMap ℂ Operator)
  · exact physicalQ_star_isUnit r Φ θ hr hr1

def staggerOperator : TwoByTwo Operator := !![1,0;0,shift]

theorem staggerOperator_unitary : staggerOperator ∈ unitary (TwoByTwo Operator) := by
  constructor <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [staggerOperator, Matrix.mul_apply, Fin.sum_univ_two, Matrix.star_apply,
      unitary.star_mul_self_of_mem shift_unitary, unitary.mul_star_self_of_mem shift_unitary]

theorem staggerOperator_star_zero (ψ : SpinHilbert) (n : ℤ) :
    spinAction (star staggerOperator) ψ 0 n = ψ 0 n := by
  simp [spinAction, staggerOperator, Matrix.star_apply]

theorem staggerOperator_star_one (ψ : SpinHilbert) (n : ℤ) :
    spinAction (star staggerOperator) ψ 1 n = ψ 1 (n+1) := by
  simp [spinAction, staggerOperator, Matrix.star_apply]

def siteVector (ψ : SpinHilbert) (n : ℤ) : TransferVector := ![ψ 0 n, ψ 1 n]

theorem residualCoefficientOperator_apply (a r Φ θ : ℝ) (z : ℂ)
    (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction (residualCoefficientOperator a r Φ θ z) ψ) n =
      residualCoefficient (coupling a) (complementaryCoupling a)
        (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z *ᵥ
          siteVector ψ n := by
  ext i
  fin_cases i <;>
    simp [siteVector, spinAction, residualCoefficientOperator, residualCoefficient,
      Matrix.mulVec, dotProduct, Fin.sum_univ_two, physicalB_apply, physicalQ_star_apply,
      bValue, qValue, oddAlpha, physicalHopping, sub_eq_add_neg]
  ring

theorem residualCoefficientOperator_inverse_apply {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (Φ θ : ℝ) {z : ℂ} (hz : z ≠ 0)
    (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction ((residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz).unit⁻¹).val ψ) n =
      residualCoefficientInv (coupling a) (complementaryCoupling a)
        (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z *ᵥ
          siteVector ψ n := by
  have h := congrArg (fun χ : SpinHilbert => siteVector χ n)
    (show spinAction (residualCoefficientOperator a r Φ θ z)
      (spinAction ((residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz).unit⁻¹).val ψ) = ψ by
        rw [← spinAction_mul,
          (residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz).mul_val_inv, spinAction_one])
  dsimp only at h
  rw [residualCoefficientOperator_apply] at h
  calc
    _ = residualCoefficientInv (coupling a) (complementaryCoupling a)
        (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z *ᵥ
      (residualCoefficient (coupling a) (complementaryCoupling a)
        (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z *ᵥ
          siteVector (spinAction
            ((residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz).unit⁻¹).val ψ) n) := by
      rw [mulVec_mulVec, residualCoefficient_inv_mul _ _ _ _ _
        (ne_of_gt (coupling_pos ha)) (physicalHopping_ne_zero hr hr1 _) hz, one_mulVec]
    _ = _ := congrArg (_ *ᵥ ·) h

theorem spinAction_matrix_sub (M N : TwoByTwo Operator) (ψ : SpinHilbert) :
    spinAction (M-N) ψ = spinAction M ψ - spinAction N ψ := by
  ext i
  simp only [spinAction, Matrix.sub_apply, ContinuousLinearMap.sub_apply, PiLp.sub_apply]
  abel

theorem spinAction_matrix_smul (M : TwoByTwo Operator) (z : ℂ) (ψ : SpinHilbert) :
    spinAction (z • M) ψ = z • spinAction M ψ := by
  ext i
  simp [spinAction, smul_add]

def physicalDifferenceOperator (a r Φ θ : ℝ) (z : ℂ)
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (hz : z ≠ 0) : TwoByTwo Operator :=
  ((residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz).unit⁻¹).val *
    (physicalCoinFactor r Φ θ - z • star (physicalShiftFactor a)) * star staggerOperator

theorem physicalDifferenceOperator_apply (a r Φ θ : ℝ) (z : ℂ)
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r < 1) (hz : z ≠ 0)
    (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction (physicalDifferenceOperator a r Φ θ z ha hr hr1 hz) ψ) n =
      siteVector ψ (n+1) - uamoTransfer a r z (phaseAngle Φ θ n) *ᵥ siteVector ψ n := by
  let χ := spinAction (star staggerOperator) ψ
  have hlocal : siteVector
      (spinAction (physicalCoinFactor r Φ θ - z • star (physicalShiftFactor a)) χ) n =
      residualCoefficient (coupling a) (complementaryCoupling a)
        (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z *ᵥ
          physicalTransferResidual a r Φ θ z χ n := by
    rw [spinAction_matrix_sub, spinAction_matrix_smul]
    simpa only [siteVector, PiLp.sub_apply, PiLp.smul_apply,
      lp.coeFn_sub, lp.coeFn_smul, Pi.sub_apply, Pi.smul_apply, smul_eq_mul] using
        physicalTransferResidual_identity ha hr hr1 Φ θ hz χ n
  rw [physicalDifferenceOperator, spinAction_mul, spinAction_mul,
    residualCoefficientOperator_inverse_apply ha hr hr1 Φ θ hz]
  change residualCoefficientInv _ _ _ _ _ *ᵥ
    siteVector (spinAction (physicalCoinFactor r Φ θ - z • star (physicalShiftFactor a)) χ) n = _
  rw [hlocal, mulVec_mulVec, residualCoefficient_inv_mul _ _ _ _ _
    (ne_of_gt (coupling_pos ha)) (physicalHopping_ne_zero hr hr1 _) hz, one_mulVec]
  simp only [physicalTransferResidual, staggeredState, χ, siteVector,
    staggerOperator_star_zero, staggerOperator_star_one, add_sub_cancel_right, sub_add_cancel]

theorem spinAction_injective {M N : TwoByTwo Operator}
    (h : ∀ ψ : SpinHilbert, spinAction M ψ = spinAction N ψ) : M = N := by
  ext i j ψ n
  let χ : SpinHilbert := fun k => if k = j then ψ else 0
  have hh := congrArg (fun v : SpinHilbert => v i n) (h χ)
  fin_cases j <;> simpa [χ, spinAction] using hh

theorem physicalDifferenceOperator_factorization (a r Φ θ : ℝ) (z : ℂ)
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r < 1) (hz : z ≠ 0) :
    residualCoefficientOperator a r Φ θ z *
      physicalDifferenceOperator a r Φ θ z ha hr hr1 hz * staggerOperator =
        star (physicalShiftFactor a) *
          (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ - z • 1) := by
  rw [physicalWalk_residual_factorization a r Φ θ ha.le ha1 hr hr1.le z]
  simp only [physicalDifferenceOperator, mul_assoc]
  rw [← mul_assoc (residualCoefficientOperator a r Φ θ z),
    (residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz).mul_val_inv, one_mul,
    unitary.star_mul_self_of_mem staggerOperator_unitary, mul_one]

theorem physicalWalk_resolvent_iff_difference (a r Φ θ : ℝ) (z : ℂ)
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r < 1) (hz : z ≠ 0) :
    z ∉ spectrum ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ↔
      IsUnit (physicalDifferenceOperator a r Φ θ z ha hr hr1 hz) := by
  have hC := residualCoefficientOperator_isUnit ha hr hr1 Φ θ hz
  have hJ : IsUnit staggerOperator := ⟨⟨staggerOperator, star staggerOperator,
    unitary.mul_star_self_of_mem staggerOperator_unitary,
    unitary.star_mul_self_of_mem staggerOperator_unitary⟩, rfl⟩
  have hS : IsUnit (physicalShiftFactor a) := ⟨⟨physicalShiftFactor a, star (physicalShiftFactor a),
    unitary.mul_star_self_of_mem (physicalShiftFactor_unitary a),
    unitary.star_mul_self_of_mem (physicalShiftFactor_unitary a)⟩, rfl⟩
  rw [spectrum.not_mem_iff, Algebra.algebraMap_eq_smul_one]
  constructor
  · intro h
    have h' : IsUnit (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ - z • 1) := by
      simpa only [neg_sub] using h.neg
    unfold physicalDifferenceOperator
    rw [← physicalWalk_residual_factorization a r Φ θ ha.le ha1 hr hr1.le z]
    exact ((hC.unit⁻¹.isUnit.mul (hS.star.mul h')).mul hJ.star)
  · intro h
    have hh := (hC.mul h).mul hJ
    rw [physicalDifferenceOperator_factorization a r Φ θ z ha ha1 hr hr1 hz] at hh
    have hw := hS.mul hh
    rw [← mul_assoc, unitary.mul_star_self_of_mem (physicalShiftFactor_unitary a), one_mul] at hw
    simpa only [neg_sub] using hw.neg

end UAMO.CMV

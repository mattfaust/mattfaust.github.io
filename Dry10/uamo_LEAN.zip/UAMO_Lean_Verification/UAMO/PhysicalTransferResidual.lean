import UAMO.CMVTransfer
import UAMO.PhysicalCMVConjugacy

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart
open scoped Matrix

abbrev TransferVector := Fin 2 → ℂ

def residualCoefficient (lam t b : ℝ) (q z : ℂ) : TransferMatrix :=
  !![-z * (lam : ℂ), -(b : ℂ) - z * (t : ℂ); 0, star q]

def residualCoefficientInv (lam t b : ℝ) (q z : ℂ) : TransferMatrix :=
  !![-(z * (lam : ℂ))⁻¹,
    -((b : ℂ) + z * (t : ℂ)) / (z * (lam : ℂ) * star q);
    0, (star q)⁻¹]

theorem residualCoefficient_inv_mul (lam t b : ℝ) (q z : ℂ)
    (hlam : lam ≠ 0) (hq : q ≠ 0) (hz : z ≠ 0) :
    residualCoefficientInv lam t b q z * residualCoefficient lam t b q z = 1 := by
  have hl : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hqs : (starRingEnd ℂ) q ≠ 0 := by
    simpa only [Complex.star_def] using (star_ne_zero.mpr hq)
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [residualCoefficient, residualCoefficientInv, Matrix.mul_apply,
      Fin.sum_univ_two, hl, hz, hqs] <;> field_simp [hl, hz, hqs] <;> ring

def localWalkResidual (lam t b : ℝ) (q z : ℂ)
    (v w : TransferVector) : TransferVector :=
  ![q * v 0 - (b : ℂ) * w 1 - z * ((lam : ℂ) * w 0 + (t : ℂ) * w 1),
    (b : ℂ) * v 0 + star q * w 1 - z * (-(t : ℂ) * v 0 + (lam : ℂ) * v 1)]

theorem localWalkResidual_eq (lam t b : ℝ) (q z : ℂ)
    (hlam : lam ≠ 0) (hq : q ≠ 0) (hz : z ≠ 0)
    (hcoin : (b : ℂ)^2 + q * star q = 1) (v w : TransferVector) :
    localWalkResidual lam t b q z v w = residualCoefficient lam t b q z *ᵥ
      (w - physicalTransfer lam t b (star q) z *ᵥ v) := by
  have hl : (lam : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hlam
  have hqs : (starRingEnd ℂ) q ≠ 0 := by
    simpa only [Complex.star_def] using (star_ne_zero.mpr hq)
  ext i
  fin_cases i <;>
    simp only [localWalkResidual, residualCoefficient, physicalTransfer,
      Matrix.mulVec, dotProduct, Fin.sum_univ_two, Matrix.smul_apply,
      Pi.sub_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
      Matrix.cons_val_fin_one, Matrix.of_apply, smul_eq_mul, zero_mul, zero_add]
  · simp only [Complex.star_def] at hcoin ⊢
    field_simp [hl, hz, hqs]
    apply (eq_div_iff (mul_ne_zero
      (mul_ne_zero (mul_ne_zero hqs (mul_ne_zero hl hz)) hqs) hqs)).2
    linear_combination z * (lam : ℂ) * ((starRingEnd ℂ) q)^2 * v 0 * hcoin
  · simp only [Complex.star_def]
    field_simp [hl, hz, hqs]
    ring

def staggeredState (ψ : SpinHilbert) (n : ℤ) : TransferVector :=
  ![ψ 0 n, ψ 1 (n-1)]

def physicalTransferResidual (a r Φ θ : ℝ) (z : ℂ) (ψ : SpinHilbert)
    (n : ℤ) : TransferVector :=
  staggeredState ψ (n+1) -
    uamoTransfer a r z (phaseAngle Φ θ n) *ᵥ staggeredState ψ n

def physicalShiftFactor (a : ℝ) : TwoByTwo Operator :=
  shiftFactor (coupling a) (complementaryCoupling a) shift

def physicalCoinFactor (r Φ θ : ℝ) : TwoByTwo Operator :=
  coinQB (physicalQ (coupling r) (complementaryCoupling r) Φ θ)
    (physicalB (coupling r) Φ θ)

theorem physicalShiftFactor_unitary (a : ℝ) :
    physicalShiftFactor a ∈ unitary (TwoByTwo Operator) :=
  shiftFactor_unitary a shift shift_unitary

theorem physicalShiftFactor_star_zero (a : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (star (physicalShiftFactor a)) ψ 0 n =
      (coupling a : ℂ)*ψ 0 (n+1) + (complementaryCoupling a : ℂ)*ψ 1 n := by
  simp [spinAction, physicalShiftFactor, shiftFactor, Matrix.star_apply,
    Complex.star_def]

theorem physicalShiftFactor_star_one (a : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (star (physicalShiftFactor a)) ψ 1 n =
      -(complementaryCoupling a : ℂ)*ψ 0 n + (coupling a : ℂ)*ψ 1 (n-1) := by
  simp [spinAction, physicalShiftFactor, shiftFactor, Matrix.star_apply,
    Complex.star_def]

theorem physicalCoinFactor_zero (r Φ θ : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (physicalCoinFactor r Φ θ) ψ 0 n =
      physicalHopping r (phaseAngle Φ θ n)*ψ 0 n -
        (oddAlpha r (phaseAngle Φ θ n) : ℂ)*ψ 1 n := by
  simp [spinAction, physicalCoinFactor, coinQB, physicalQ_apply, physicalB_apply,
    qValue, bValue, physicalHopping, oddAlpha, sub_eq_add_neg]

theorem physicalCoinFactor_one (r Φ θ : ℝ) (ψ : SpinHilbert) (n : ℤ) :
    spinAction (physicalCoinFactor r Φ θ) ψ 1 n =
      (oddAlpha r (phaseAngle Φ θ n) : ℂ)*ψ 0 n +
        star (physicalHopping r (phaseAngle Φ θ n))*ψ 1 n := by
  simp [spinAction, physicalCoinFactor, coinQB, physicalQ_star_apply, physicalB_apply,
    qValue, bValue, physicalHopping, oddAlpha]

theorem physicalTransferResidual_identity {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (hr1 : r < 1) (Φ θ : ℝ) {z : ℂ} (hz : z ≠ 0)
    (ψ : SpinHilbert) (n : ℤ) :
    ![spinAction (physicalCoinFactor r Φ θ) ψ 0 n -
        z * spinAction (star (physicalShiftFactor a)) ψ 0 n,
      spinAction (physicalCoinFactor r Φ θ) ψ 1 n -
        z * spinAction (star (physicalShiftFactor a)) ψ 1 n] =
      residualCoefficient (coupling a) (complementaryCoupling a)
        (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z *ᵥ
          physicalTransferResidual a r Φ θ z ψ n := by
  rw [physicalCoinFactor_zero, physicalCoinFactor_one,
    physicalShiftFactor_star_zero, physicalShiftFactor_star_one]
  simpa [localWalkResidual, physicalTransferResidual, staggeredState, uamoTransfer] using
    localWalkResidual_eq (coupling a) (complementaryCoupling a)
      (oddAlpha r (phaseAngle Φ θ n)) (physicalHopping r (phaseAngle Φ θ n)) z
      (ne_of_gt (coupling_pos ha)) (physicalHopping_ne_zero hr hr1 _) hz
      (physicalHopping_normalization r _) (staggeredState ψ n) (staggeredState ψ (n+1))

theorem physicalWalk_shift_coin (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ =
      physicalShiftFactor a * physicalCoinFactor r Φ θ := by
  simp only [PhysicalRepresentation.walk, PhysicalWalk.walk,
    complementaryCoupling_eq_sqrt ha0 ha1, complementaryCoupling_eq_sqrt hr0 hr1,
    coinFactor_eq_coinQB, physicalShiftFactor, physicalCoinFactor, physicalQ, physicalB]

theorem physicalWalk_residual_factorization (a r Φ θ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (z : ℂ) :
    star (physicalShiftFactor a) *
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ - z • 1) =
      physicalCoinFactor r Φ θ - z • star (physicalShiftFactor a) := by
  rw [physicalWalk_shift_coin a r Φ θ ha0 ha1 hr0 hr1, mul_sub,
    ← mul_assoc, unitary.star_mul_self_of_mem (physicalShiftFactor_unitary a),
    one_mul, Matrix.mul_smul, mul_one]

end UAMO.CMV

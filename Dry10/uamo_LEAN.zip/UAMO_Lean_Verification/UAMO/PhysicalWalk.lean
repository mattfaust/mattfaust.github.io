import UAMO.Basic
import Mathlib.Algebra.Star.Unitary
import Mathlib.Data.Matrix.ConjTranspose
import Mathlib.Data.Matrix.Notation
import Mathlib.Tactic.NoncommRing
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.LinearCombination

namespace UAMO
namespace PhysicalWalk

noncomputable section

open scoped Matrix

variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

abbrev TwoByTwo (A : Type*) := Matrix (Fin 2) (Fin 2) A
abbrev Column (A : Type*) := Matrix (Fin 2) (Fin 1) A

def shiftFactor (lam co : ℝ) (u : A) : TwoByTwo A :=
  !![(lam : ℂ) • u, -(co : ℂ) • (1 : A);
    (co : ℂ) • (1 : A), (lam : ℂ) • star u]

def coinFactor (lam co : ℝ) (v : A) : TwoByTwo A :=
  let t := ((lam / 2 : ℝ) : ℂ) • (v + star v)
  let s := (-Complex.I * ((lam / 2 : ℝ) : ℂ)) • (v - star v)
  !![t + (Complex.I * (co : ℂ)) • (1 : A), -s;
    s, t - (Complex.I * (co : ℂ)) • (1 : A)]

def flip : TwoByTwo A := !![0, 1; 1, 0]

def firstColumnRaw (a : ℝ) (u : A) : Column A := !![(a : ℂ) • u; 1]

def secondColumnRaw (r : ℝ) (v : A) : Column A :=
  !![(r : ℂ) • star v - Complex.I • (1 : A);
    1 - (Complex.I * (r : ℂ)) • star v]

theorem firstColumnRaw_gram (a : ℝ) (u : A) (hu : u ∈ unitary A) :
    (firstColumnRaw a u)ᴴ * firstColumnRaw a u =
      ((1 + a ^ 2 : ℝ) : ℂ) • (1 : Matrix (Fin 1) (Fin 1) A) := by
  ext i j
  fin_cases i
  fin_cases j
  simp only [firstColumnRaw, Matrix.mul_apply, Fin.sum_univ_two,
    Matrix.conjTranspose_apply, Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_fin_one, star_smul, Complex.star_def, Complex.conj_ofReal,
    star_one, smul_mul_assoc, mul_smul_comm, smul_smul,
    unitary.star_mul_self_of_mem hu, one_mul, Matrix.smul_apply,
    Matrix.one_apply_eq, Complex.ofReal_add, Complex.ofReal_one, Complex.ofReal_pow]
  module

theorem secondColumnRaw_gram (r : ℝ) (v : A) (hv : v ∈ unitary A) :
    (secondColumnRaw r v)ᴴ * secondColumnRaw r v =
      ((2 * (1 + r ^ 2) : ℝ) : ℂ) • (1 : Matrix (Fin 1) (Fin 1) A) := by
  ext i j
  fin_cases i
  fin_cases j
  simp only [secondColumnRaw, Matrix.mul_apply, Fin.sum_univ_two,
    Matrix.conjTranspose_apply, Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_fin_one, star_sub, star_smul, star_star, star_one,
    Complex.star_def, Complex.conj_ofReal, map_mul, Complex.conj_I,
    sub_mul, mul_sub, smul_mul_assoc, mul_smul_comm, smul_smul,
    unitary.mul_star_self_of_mem hv, one_mul, mul_one, Matrix.smul_apply,
    Matrix.one_apply_eq, Complex.ofReal_mul, Complex.ofReal_add,
    Complex.ofReal_ofNat, Complex.ofReal_one, Complex.ofReal_pow]
  simp only [neg_mul, mul_neg, Complex.I_mul_I]
  match_scalars
  all_goals ring_nf
  simp [Complex.I_sq]
  ring

def firstColumn (a : ℝ) (u : A) : Column A :=
  (((Real.sqrt (1 + a ^ 2))⁻¹ : ℝ) : ℂ) • firstColumnRaw a u

def secondColumn (r : ℝ) (v : A) : Column A :=
  (((Real.sqrt (2 * (1 + r ^ 2)))⁻¹ : ℝ) : ℂ) • secondColumnRaw r v

theorem normalizedColumn_gram (C : Column A) (s : ℝ) (hs : 0 < s)
    (hC : Cᴴ * C = (s : ℂ) • (1 : Matrix (Fin 1) (Fin 1) A)) :
    ((((Real.sqrt s)⁻¹ : ℝ) : ℂ) • C)ᴴ *
        ((((Real.sqrt s)⁻¹ : ℝ) : ℂ) • C) = 1 := by
  have hsqrt : Real.sqrt s ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr hs)
  have hscale : (Real.sqrt s)⁻¹ * (Real.sqrt s)⁻¹ * s = 1 := by
    rw [← Real.mul_self_sqrt hs.le]
    field_simp
  have hscaleC : (((Real.sqrt s)⁻¹ : ℝ) : ℂ) *
      (((Real.sqrt s)⁻¹ : ℝ) : ℂ) * (s : ℂ) = 1 := by
    exact_mod_cast hscale
  rw [Matrix.conjTranspose_smul, Matrix.smul_mul, Matrix.mul_smul, hC]
  simp only [smul_smul, Complex.star_def, Complex.conj_ofReal]
  rw [← mul_assoc, hscaleC, one_smul]

theorem firstColumn_isometry (a : ℝ) (u : A) (hu : u ∈ unitary A) :
    (firstColumn a u)ᴴ * firstColumn a u = 1 :=
  normalizedColumn_gram _ _ (by positivity) (firstColumnRaw_gram a u hu)

theorem secondColumn_isometry (r : ℝ) (v : A) (hv : v ∈ unitary A) :
    (secondColumn r v)ᴴ * secondColumn r v = 1 :=
  normalizedColumn_gram _ _ (by positivity) (secondColumnRaw_gram r v hv)

def reflection (C : Column A) : TwoByTwo A := (2 : ℂ) • (C * Cᴴ) - 1

omit [Algebra ℂ A] [StarModule ℂ A] in
theorem columnProjection_idempotent (C : Column A) (hC : Cᴴ * C = 1) :
    (C * Cᴴ) * (C * Cᴴ) = C * Cᴴ := by
  calc
    (C * Cᴴ) * (C * Cᴴ) = C * (Cᴴ * C) * Cᴴ := by simp only [Matrix.mul_assoc]
    _ = C * Cᴴ := by rw [hC, Matrix.mul_one]

theorem reflection_selfAdjoint (C : Column A) : star (reflection C) = reflection C := by
  simp only [reflection, star_sub, star_smul, star_ofNat, star_one,
    Matrix.star_eq_conjTranspose, Matrix.conjTranspose_mul,
    Matrix.conjTranspose_conjTranspose]

omit [StarModule ℂ A] in
theorem reflection_square (C : Column A) (hC : Cᴴ * C = 1) :
    reflection C * reflection C = 1 := by
  have hP := columnProjection_idempotent C hC
  simp only [reflection, sub_mul, mul_sub, smul_mul_assoc, mul_smul_comm,
    smul_smul, one_mul, mul_one, hP]
  module

theorem reflection_unitary (C : Column A) (hC : Cᴴ * C = 1) :
    reflection C ∈ unitary (TwoByTwo A) := by
  apply unitary.mem_iff.mpr
  rw [reflection_selfAdjoint, reflection_square C hC]
  exact ⟨rfl, rfl⟩

omit [StarRing A] [Algebra ℂ A] [StarModule ℂ A] in
theorem flip_square : (flip : TwoByTwo A) * flip = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [flip, Matrix.mul_apply, Fin.sum_univ_two]

omit [Algebra ℂ A] [StarModule ℂ A] in
theorem flip_unitary : (flip : TwoByTwo A) ∈ unitary (TwoByTwo A) := by
  have hs : star (flip : TwoByTwo A) = flip := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [flip, Matrix.star_eq_conjTranspose]
  apply unitary.mem_iff.mpr
  rw [hs, flip_square]
  exact ⟨rfl, rfl⟩

theorem reflection_normalized (C : Column A) (s : ℝ) (hs : 0 ≤ s) :
    reflection ((((Real.sqrt s)⁻¹ : ℝ) : ℂ) • C) =
      ((2 / s : ℝ) : ℂ) • (C * Cᴴ) - 1 := by
  have hscale : (Real.sqrt s)⁻¹ * (Real.sqrt s)⁻¹ = s⁻¹ := by
    rw [← mul_inv, Real.mul_self_sqrt hs]
  have hscaleC : (((Real.sqrt s)⁻¹ : ℝ) : ℂ) *
      (((Real.sqrt s)⁻¹ : ℝ) : ℂ) = (s⁻¹ : ℝ) := by exact_mod_cast hscale
  simp only [reflection, Matrix.conjTranspose_smul, Matrix.smul_mul, Matrix.mul_smul,
    smul_smul, Complex.star_def, Complex.conj_ofReal]
  rw [hscaleC]
  congr 2
  push_cast
  ring

theorem first_reflection_factor (a : ℝ) (u : A) (hu : u ∈ unitary A) :
    reflection (firstColumn a u) =
      shiftFactor (coupling a) (complementaryCoupling a) u * flip := by
  rw [firstColumn, reflection_normalized _ _ (by positivity)]
  have ha : (1 + (a : ℂ) ^ 2) ≠ 0 := by
    exact_mod_cast (show (1 + a ^ 2 : ℝ) ≠ 0 by positivity)
  ext i j
  fin_cases i <;> fin_cases j
  all_goals simp only [firstColumnRaw, shiftFactor, flip, Matrix.mul_apply,
    Fin.sum_univ_two, Fin.sum_univ_one, Matrix.conjTranspose_apply, Matrix.of_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    Matrix.sub_apply, Matrix.smul_apply, Matrix.one_apply, Fin.zero_eta,
    Fin.mk_one, zero_ne_one, one_ne_zero, if_true, if_false,
    zero_mul, mul_zero, one_mul, mul_one, add_zero, zero_add,
    star_smul, Complex.star_def, Complex.conj_ofReal, star_one,
    smul_mul_assoc, mul_smul_comm, smul_smul,
    unitary.mul_star_self_of_mem hu, coupling, complementaryCoupling]
  all_goals match_scalars
  all_goals field_simp
  all_goals ring

theorem second_reflection_factor (r : ℝ) (v : A) (hv : v ∈ unitary A) :
    reflection (secondColumn r v) =
      flip * coinFactor (coupling r) (complementaryCoupling r) v := by
  rw [secondColumn, reflection_normalized _ _ (by positivity)]
  have hr : (1 + (r : ℂ) ^ 2) ≠ 0 := by
    exact_mod_cast (show (1 + r ^ 2 : ℝ) ≠ 0 by positivity)
  ext i j
  fin_cases i <;> fin_cases j
  all_goals simp only [secondColumnRaw, coinFactor, flip, Matrix.mul_apply,
    Fin.sum_univ_two, Fin.sum_univ_one, Matrix.conjTranspose_apply, Matrix.of_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    Matrix.sub_apply, Matrix.smul_apply, Matrix.one_apply, Fin.zero_eta,
    Fin.mk_one, zero_ne_one, one_ne_zero, if_true, if_false,
    zero_mul, mul_zero, one_mul, mul_one, add_zero, zero_add,
    star_sub, star_smul, star_star, star_one, Complex.star_def,
    Complex.conj_ofReal, map_mul, Complex.conj_I, sub_mul, mul_sub,
    smul_add, smul_sub, smul_mul_assoc, mul_smul_comm, smul_smul,
    unitary.star_mul_self_of_mem hv, coupling, complementaryCoupling]
  all_goals match_scalars
  all_goals field_simp
  all_goals ring_nf
  all_goals simp [Complex.I_sq]

theorem shiftFactor_unitary (a : ℝ) (u : A) (hu : u ∈ unitary A) :
    shiftFactor (coupling a) (complementaryCoupling a) u ∈ unitary (TwoByTwo A) := by
  have heq : shiftFactor (coupling a) (complementaryCoupling a) u =
      reflection (firstColumn a u) * flip := by
    rw [first_reflection_factor a u hu, mul_assoc, flip_square, mul_one]
  rw [heq]
  exact (unitary _).mul_mem
    (reflection_unitary _ (firstColumn_isometry a u hu)) flip_unitary

def walk (lam₁ lam₂ : ℝ) (u v : A) : TwoByTwo A :=
  shiftFactor lam₁ (Real.sqrt (1 - lam₁ ^ 2)) u *
    coinFactor lam₂ (Real.sqrt (1 - lam₂ ^ 2)) v

theorem walk_eq_reflection_product
    (a r : ℝ) (ha : 0 ≤ a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r ≤ 1)
    (u v : A) (hu : u ∈ unitary A) (hv : v ∈ unitary A) :
    walk (coupling a) (coupling r) u v =
      reflection (firstColumn a u) * reflection (secondColumn r v) := by
  rw [walk, complementaryCoupling_eq_sqrt ha ha1,
    complementaryCoupling_eq_sqrt hr hr1,
    first_reflection_factor a u hu, second_reflection_factor r v hv,
    mul_assoc, ← mul_assoc flip flip, flip_square, one_mul]

theorem walk_unitary_stereographic
    (a r : ℝ) (ha : 0 ≤ a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r ≤ 1)
    (u v : A) (hu : u ∈ unitary A) (hv : v ∈ unitary A) :
    walk (coupling a) (coupling r) u v ∈ unitary (TwoByTwo A) := by
  rw [walk_eq_reflection_product a r ha ha1 hr hr1 u v hu hv]
  exact (unitary _).mul_mem
    (reflection_unitary _ (firstColumn_isometry a u hu))
    (reflection_unitary _ (secondColumn_isometry r v hv))

def stereographicParameter (lam : ℝ) : ℝ := lam / (1 + Real.sqrt (1 - lam ^ 2))

theorem stereographicParameter_mem_Icc {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1) :
    stereographicParameter lam ∈ Set.Icc (0 : ℝ) 1 := by
  have hd : 1 ≤ 1 + Real.sqrt (1 - lam ^ 2) := by
    linarith [Real.sqrt_nonneg (1 - lam ^ 2)]
  constructor
  · exact div_nonneg hlam (le_trans zero_le_one hd)
  · exact (div_le_self hlam hd).trans hlam1

theorem coupling_stereographicParameter {lam : ℝ} (hlam : 0 ≤ lam) (hlam1 : lam ≤ 1) :
    coupling (stereographicParameter lam) = lam := by
  have hnonneg : 0 ≤ 1 - lam ^ 2 := by nlinarith
  have hsq := Real.sq_sqrt hnonneg
  have hd : 1 + Real.sqrt (1 - lam ^ 2) ≠ 0 := by positivity
  unfold coupling stereographicParameter
  field_simp
  linear_combination -(lam * (1 + Real.sqrt (1 - lam ^ 2))) * hsq

def overlapPolynomial (a r : ℝ) (U V : A) : A :=
  (-Complex.I) •
    (1 + (a : ℂ) • U + (r : ℂ) • V - ((a * r : ℝ) : ℂ) • (V * U))

theorem raw_overlap (a r : ℝ) (u v : A) :
    ((secondColumnRaw r v)ᴴ * firstColumnRaw a u) 0 0 =
      1 + (Complex.I * (a : ℂ)) • u + (Complex.I * (r : ℂ)) • v +
        ((a * r : ℝ) : ℂ) • (v * u) := by
  simp only [secondColumnRaw, firstColumnRaw, Matrix.mul_apply,
    Fin.sum_univ_two, Matrix.conjTranspose_apply, Matrix.of_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_fin_one,
    star_sub, star_smul, star_star, star_one, Complex.star_def,
    Complex.conj_ofReal, map_mul, Complex.conj_I, sub_mul,
    smul_mul_assoc, mul_smul_comm, smul_smul, one_mul, mul_one,
    Complex.ofReal_mul]
  module

theorem normalized_overlap_scale (a r : ℝ) :
    (Real.sqrt (2 * (1 + r ^ 2)))⁻¹ * (Real.sqrt (1 + a ^ 2))⁻¹ =
      (Real.sqrt (2 * ((1 + a ^ 2) * (1 + r ^ 2))))⁻¹ := by
  rw [← mul_inv, ← Real.sqrt_mul (by positivity)]
  congr 2
  ring

theorem reflection_overlap (a r : ℝ) (u v : A) :
    (-Complex.I) • (((secondColumn r v)ᴴ * firstColumn a u) 0 0) =
      (((Real.sqrt (2 * ((1 + a ^ 2) * (1 + r ^ 2))))⁻¹ : ℝ) : ℂ) •
        overlapPolynomial a r (Complex.I • u) (Complex.I • v) := by
  have hscale : (((Real.sqrt (2 * (1 + r ^ 2)))⁻¹ : ℝ) : ℂ) *
      (((Real.sqrt (1 + a ^ 2))⁻¹ : ℝ) : ℂ) =
        (((Real.sqrt (2 * ((1 + a ^ 2) * (1 + r ^ 2))))⁻¹ : ℝ) : ℂ) := by
    exact_mod_cast normalized_overlap_scale a r
  have hm : (secondColumn r v)ᴴ * firstColumn a u =
      (((Real.sqrt (2 * ((1 + a ^ 2) * (1 + r ^ 2))))⁻¹ : ℝ) : ℂ) •
        ((secondColumnRaw r v)ᴴ * firstColumnRaw a u) := by
    simp only [firstColumn, secondColumn, Matrix.conjTranspose_smul,
      Matrix.smul_mul, Matrix.mul_smul, smul_smul, Complex.star_def,
      Complex.conj_ofReal]
    rw [mul_comm, hscale]
  rw [hm, Matrix.smul_apply, raw_overlap]
  simp only [overlapPolynomial, smul_mul_assoc, mul_smul_comm, smul_smul,
    Complex.I_mul_I, smul_neg, neg_smul, one_smul, Complex.ofReal_mul]
  module

end
end PhysicalWalk
end UAMO

import UAMO.CMVFrobeniusPolynomial
import UAMO.LogPolynomialFourierDecay

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial MeasureTheory CircleDOS

def normalizedFrobeniusLog (M : TransferMatrix) (n : ℕ) : ℝ :=
  (Real.log (transferFrobeniusSq M)-Real.log ‖M.det‖)/(2*(n:ℝ))

theorem transferFrobeniusSq_pos_of_det_ne_zero (M : TransferMatrix) (hd : M.det≠0) :
    0<transferFrobeniusSq M := by
  have hn : M≠0 := by intro h; simp [h] at hd
  exact (sq_pos_of_pos (transferNorm_pos_of_ne_zero hn)).trans_le
    (transferNorm_sq_le_frobeniusSq M)

theorem normalizedFrobeniusLog_smul (c : ℂ) (hc : c≠0) (M : TransferMatrix)
    (hd : M.det≠0) (n : ℕ) :
    normalizedFrobeniusLog (c • M) n=normalizedFrobeniusLog M n := by
  have hcn : ‖c‖≠0 := norm_ne_zero_iff.mpr hc
  have hfn : transferFrobeniusSq M≠0 := (transferFrobeniusSq_pos_of_det_ne_zero M hd).ne'
  simp only [normalizedFrobeniusLog,transferFrobeniusSq_smul,Matrix.det_smul,
    Fintype.card_fin,norm_mul,norm_pow]
  rw [Real.log_mul (pow_ne_zero 2 hcn) hfn,
    Real.log_mul (pow_ne_zero 2 hcn) (norm_ne_zero_iff.mpr hd)]
  ring

theorem normalizedFrobeniusLog_of_det_norm_one (M : TransferMatrix)
    (hd : ‖M.det‖=1) (n : ℕ) :
    normalizedFrobeniusLog M n=Real.log (transferFrobeniusSq M)/(2*(n:ℝ)) := by
  simp only [normalizedFrobeniusLog,hd,Real.log_one,sub_zero]

theorem normalizedFrobeniusLog_operator_gap (M : TransferMatrix)
    (hd : M.det≠0) {n : ℕ} (hn : 0<n) :
    0≤normalizedFrobeniusLog M n-
        (Real.log (transferNorm M)-Real.log ‖M.det‖/2)/(n:ℝ) ∧
    normalizedFrobeniusLog M n-
        (Real.log (transferNorm M)-Real.log ‖M.det‖/2)/(n:ℝ)≤Real.log 2/(2*(n:ℝ)) := by
  have hne : M≠0 := by intro h; simp [h] at hd
  obtain ⟨hlo,hhi⟩ := transfer_log_frobenius_gap_of_pos M (transferNorm_pos_of_ne_zero hne)
  have he : normalizedFrobeniusLog M n-
        (Real.log (transferNorm M)-Real.log ‖M.det‖/2)/(n:ℝ)=
      (Real.log (transferFrobeniusSq M)/2-Real.log (transferNorm M))/(n:ℝ) := by
    unfold normalizedFrobeniusLog
    ring
  rw [he]
  exact ⟨div_nonneg hlo (by exact_mod_cast hn.le),by
    simpa only [div_div] using div_le_div_of_nonneg_right hhi (Nat.cast_nonneg n)⟩

theorem polynomialMatrix_det_eval (P : TransferPolynomialMatrix) (w : ℂ) :
    P.det.eval w=(P.map (Polynomial.eval w)).det := by
  simp only [Matrix.det_fin_two,Matrix.map_apply,Polynomial.eval_sub,Polynomial.eval_mul]

theorem polynomialMatrix_det_natDegree_le (P : TransferPolynomialMatrix) (D : ℕ)
    (hP : ∀i j,(P i j).natDegree≤D) : P.det.natDegree≤2*D := by
  rw [Matrix.det_fin_two]
  exact (Polynomial.natDegree_sub_le _ _).trans (max_le
    ((Polynomial.natDegree_mul_le_of_le (hP 0 0) (hP 1 1)).trans (by omega))
    ((Polynomial.natDegree_mul_le_of_le (hP 0 1) (hP 1 0)).trans (by omega)))

theorem normalizedFrobeniusLog_polynomial_eq (P : TransferPolynomialMatrix) (D n : ℕ)
    (hP : ∀i j,(P i j).natDegree≤D) (t : ℝ) :
    normalizedFrobeniusLog (P.map (Polynomial.eval (logFourierChar 1 t))) n =
      (Real.log ‖(frobeniusPolynomial P D).eval (logFourierChar 1 t)‖-
        Real.log ‖P.det.eval (logFourierChar 1 t)‖)/(2*(n:ℝ)) := by
  rw [norm_frobeniusPolynomial_eval P D hP (logFourierChar_norm 1 t),
    polynomialMatrix_det_eval]
  rfl

theorem normalizedFrobeniusLog_polynomial_fourier_bound
    (P : TransferPolynomialMatrix) (D n : ℕ) (hn : 0<n)
    (hP : ∀i j,(P i j).natDegree≤D)
    (hd : ∀t:ℝ,(P.map (Polynomial.eval (logFourierChar 1 t))).det≠0)
    {k : ℤ} (hk : k≠0) :
    ‖logFourierCoeff
      (fun t => normalizedFrobeniusLog (P.map (Polynomial.eval (logFourierChar 1 t))) n) k‖≤
        (D:ℝ)/((n:ℝ)*|(k:ℝ)|) := by
  let F := frobeniusPolynomial P D
  have hF : ∀t:ℝ,F.eval (logFourierChar 1 t)≠0 := by
    intro t
    apply norm_pos_iff.mp
    rw [norm_frobeniusPolynomial_eval P D hP (logFourierChar_norm 1 t)]
    exact transferFrobeniusSq_pos_of_det_ne_zero _ (hd t)
  have hd' : ∀t:ℝ,P.det.eval (logFourierChar 1 t)≠0 := by
    intro t
    rw [polynomialMatrix_det_eval]
    exact hd t
  have hF0 : F≠0 := by intro h; have ht := hF 0; simp [h] at ht
  have hd0 : P.det≠0 := by intro h; have ht := hd' 0; simp [h] at ht
  have hcF := continuous_logPolynomial_boundary F hF
  have hcd := continuous_logPolynomial_boundary P.det hd'
  have hcoef : logFourierCoeff
      (fun t => normalizedFrobeniusLog (P.map (Polynomial.eval (logFourierChar 1 t))) n) k =
      (logFourierCoeff (fun t => Real.log ‖F.eval (logFourierChar 1 t)‖) k-
        logFourierCoeff (fun t => Real.log ‖P.det.eval (logFourierChar 1 t)‖) k)/
          ((2*(n:ℝ):ℝ):ℂ) := by
    simp only [normalizedFrobeniusLog_polynomial_eq P D n hP,logFourierCoeff,
      Complex.ofReal_div,Complex.ofReal_sub,div_mul_eq_mul_div,sub_mul]
    rw [intervalIntegral.integral_div,intervalIntegral.integral_sub]
    · exact ((Complex.continuous_ofReal.comp hcF).mul
        (logFourierChar_continuous _)).intervalIntegrable _ _
    · exact ((Complex.continuous_ofReal.comp hcd).mul
        (logFourierChar_continuous _)).intervalIntegrable _ _
  have h₁ := norm_logPolynomialFourierCoeff F hF0 hF hk
  have h₂ := norm_logPolynomialFourierCoeff P.det hd0 hd' hk
  have hD₁ : (F.natDegree:ℝ)≤2*(D:ℝ) := by
    exact_mod_cast frobeniusPolynomial_natDegree_le P D hP
  have hD₂ : (P.det.natDegree:ℝ)≤2*(D:ℝ) := by
    exact_mod_cast polynomialMatrix_det_natDegree_le P D hP
  have hk0 : 0 < |(k:ℝ)|  := abs_pos.mpr (by exact_mod_cast hk)
  have hn0 : (0:ℝ)<n := by exact_mod_cast hn
  rw [hcoef,norm_div,Complex.norm_real,Real.norm_eq_abs,abs_of_pos (by positivity : 0<2*(n:ℝ))]
  calc
    _ ≤ (‖logFourierCoeff (fun t => Real.log ‖F.eval (logFourierChar 1 t)‖) k‖+
        ‖logFourierCoeff (fun t => Real.log ‖P.det.eval (logFourierChar 1 t)‖) k‖)/(2*(n:ℝ)) :=
      div_le_div_of_nonneg_right (norm_sub_le _ _) (by positivity)
    _ ≤ ((2*(D:ℝ))/(2*|(k:ℝ)|)+(2*(D:ℝ))/(2*|(k:ℝ)|))/(2*(n:ℝ)) := by
      apply div_le_div_of_nonneg_right _ (by positivity)
      exact add_le_add (h₁.trans (div_le_div_of_nonneg_right hD₁ (by positivity)))
        (h₂.trans (div_le_div_of_nonneg_right hD₂ (by positivity)))
    _ = _ := by field_simp; ring

end UAMO.CMV

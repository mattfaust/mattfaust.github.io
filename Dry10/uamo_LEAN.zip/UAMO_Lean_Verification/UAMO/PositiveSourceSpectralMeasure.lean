import UAMO.UnitarySpectralMeasure
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

noncomputable section
namespace UAMO.SourceSpectral
open MeasureTheory CompactlySupported UnitarySpectral
open scoped ContinuousFunctionalCalculus

structure PositiveState (A : Type*) [CStarAlgebra A] where
  functional : A →L[ℂ] ℂ
  normalized : functional 1 = 1
  star_preserving : ∀ a : A, functional (star a) = star (functional a)
  positive : ∀ a : A, 0 ≤ (functional (star a * a)).re

section Construction
variable {A : Type*} [CStarAlgebra A]
variable (τ : PositiveState A) (U : A) (hU : IsStarNormal U)

def realFunctional : A →L[ℝ] ℝ := Complex.reCLM.comp (τ.functional.restrictScalars ℝ)

def spectralFunctional : C_c(spectrum ℂ U, ℝ) →ₗ[ℝ] ℝ :=
  (realFunctional τ).toLinearMap.comp
    (((cfcL hU).restrictScalars ℝ).toLinearMap.comp compactRealToComplex)

theorem spectralFunctional_nonneg (f : C_c(spectrum ℂ U, ℝ)) (hf : 0 ≤ f) :
    0 ≤ spectralFunctional τ U hU f := by
  let g : C(spectrum ℂ U, ℂ) :=
    ⟨fun z => (Real.sqrt (f z) : ℂ),
      Complex.continuous_ofReal.comp (Real.continuous_sqrt.comp f.continuous)⟩
  have hsq : star g * g = compactRealToComplex f := by
    ext z
    change star (Real.sqrt (f z) : ℂ) * (Real.sqrt (f z) : ℂ) = (f z : ℂ)
    rw [Complex.star_def, Complex.conj_ofReal, ← Complex.ofReal_mul, Real.mul_self_sqrt (hf z)]
  change 0 ≤ (τ.functional (cfcHom hU (compactRealToComplex f))).re
  rw [← hsq, map_mul, map_star]
  exact τ.positive _

def spectralMeasure : Measure (spectrum ℂ U) :=
  RealRMK.rieszMeasure (spectralFunctional_nonneg τ U hU)

theorem spectralMeasure_integral_real (f : C(spectrum ℂ U, ℝ)) :
    ∫ z, f z ∂spectralMeasure τ U hU =
      (τ.functional (cfcHom hU (realContinuousToComplex f))).re := by
  let fc : C_c(spectrum ℂ U, ℝ) :=
    { toContinuousMap := f
      hasCompactSupport' := HasCompactSupport.of_compactSpace f }
  exact RealRMK.integral_rieszMeasure (spectralFunctional_nonneg τ U hU) fc

instance spectralMeasure_isProbabilityMeasure : IsProbabilityMeasure (spectralMeasure τ U hU) := by
  constructor
  apply (ENNReal.toReal_eq_one_iff _).mp
  have h := spectralMeasure_integral_real τ U hU (1 : C(spectrum ℂ U, ℝ))
  have hone : realContinuousToComplex (1 : C(spectrum ℂ U, ℝ)) = 1 := by ext; simp
  simpa only [ContinuousMap.one_apply, integral_const, smul_eq_mul, mul_one,
    hone, map_one, τ.normalized, Complex.one_re, measureReal_def] using h

theorem trace_real_test_im_zero (f : C(spectrum ℂ U, ℝ)) :
    (τ.functional (cfcHom hU (realContinuousToComplex f))).im = 0 := by
  have hs : star (realContinuousToComplex f) = realContinuousToComplex f := by ext; simp
  have h := τ.star_preserving (cfcHom hU (realContinuousToComplex f))
  rw [← map_star, hs] at h
  have hi := congrArg Complex.im h
  simp only [Complex.star_def, Complex.conj_im] at hi
  linarith

theorem spectralMeasure_integral_complex (f : C(spectrum ℂ U, ℂ)) :
    ∫ z, f z ∂spectralMeasure τ U hU = τ.functional (cfcHom hU f) := by
  let fr : C(spectrum ℂ U, ℝ) := ⟨fun z => (f z).re, Complex.continuous_re.comp f.continuous⟩
  let fi : C(spectrum ℂ U, ℝ) := ⟨fun z => (f z).im, Complex.continuous_im.comp f.continuous⟩
  have hdecomp : f = realContinuousToComplex fr + Complex.I • realContinuousToComplex fi := by
    ext z
    change f z = ((f z).re : ℂ) + Complex.I * ((f z).im : ℂ)
    simpa only [mul_comm Complex.I] using (Complex.re_add_im (f z)).symm
  have hint (g : C(spectrum ℂ U, ℝ)) :
      ∫ z, (g z : ℂ) ∂spectralMeasure τ U hU = τ.functional (cfcHom hU (realContinuousToComplex g)) := by
    rw [integral_complex_ofReal, spectralMeasure_integral_real]
    apply Complex.ext
    · rfl
    · exact (trace_real_test_im_zero τ U hU g).symm
  have hfr : Integrable (fun z => (fr z : ℂ)) (spectralMeasure τ U hU) :=
    (Complex.continuous_ofReal.comp fr.continuous).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)
  have hfi : Integrable (fun z => (fi z : ℂ)) (spectralMeasure τ U hU) :=
    (Complex.continuous_ofReal.comp fi.continuous).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)
  rw [hdecomp]
  simp only [ContinuousMap.add_apply, ContinuousMap.smul_apply, realContinuousToComplex_apply,
    smul_eq_mul, map_add, map_smul]
  rw [integral_add hfr (hfi.const_mul _), integral_const_mul, hint fr, hint fi]

def complexMeasure : Measure ℂ :=
  (spectralMeasure τ U hU).map (fun z : spectrum ℂ U => (z : ℂ))

instance complexMeasure_isProbabilityMeasure : IsProbabilityMeasure (complexMeasure τ U hU) :=
  isProbabilityMeasure_map continuous_subtype_val.measurable.aemeasurable

theorem complexMeasure_integral_cfc (f : ℂ → ℂ) (hf : Continuous f) :
    ∫ z, f z ∂complexMeasure τ U hU = τ.functional (cfc f U) := by
  rw [complexMeasure,
    (MeasurableEmbedding.subtype_coe (spectrum.isClosed (𝕜 := ℂ) U).measurableSet).integral_map f,
    cfc_apply f U hU hf.continuousOn]
  exact spectralMeasure_integral_complex τ U hU ⟨_, hf.comp continuous_subtype_val⟩

theorem complexMeasure_moment (n : ℕ) :
    ∫ z : ℂ, z ^ n ∂complexMeasure τ U hU = τ.functional (U ^ n) := by
  rw [complexMeasure_integral_cfc τ U hU (fun z : ℂ => z ^ n) (continuous_id.pow n),
    cfc_pow_id U n hU]

theorem complexMeasure_ae_circle (hunit : U ∈ unitary A) :
    ∀ᵐ z ∂complexMeasure τ U hU, ‖z‖ = 1 := by
  rw [complexMeasure]
  apply (ae_map_iff continuous_subtype_val.measurable.aemeasurable
    (isClosed_eq continuous_norm continuous_const).measurableSet).mpr
  exact Filter.Eventually.of_forall fun z =>
    mem_sphere_zero_iff_norm.mp (spectrum.subset_circle_of_unitary hunit z.property)

end Construction
end UAMO.SourceSpectral

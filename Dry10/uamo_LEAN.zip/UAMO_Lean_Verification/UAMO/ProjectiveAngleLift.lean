import UAMO.StablePlane
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Instances.Matrix

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

def actionX (M : PlaneMatrix) (s : ℝ) : ℝ := M 0 0*Real.cos s+M 0 1*Real.sin s
def actionY (M : PlaneMatrix) (s : ℝ) : ℝ := M 1 0*Real.cos s+M 1 1*Real.sin s
def radial (M : PlaneMatrix) (s : ℝ) : ℝ :=
  actionX M s*Real.cos s+actionY M s*Real.sin s
def transverse (M : PlaneMatrix) (s : ℝ) : ℝ :=
  actionY M s*Real.cos s-actionX M s*Real.sin s

def positiveAngleLift (M : PlaneMatrix) (s : ℝ) : ℝ :=
  s+Real.arctan (transverse M s/radial M s)

theorem mulVec_angleVector (M : PlaneMatrix) (s : ℝ) :
    M*ᵥangleVector s=![actionX M s,actionY M s] := by
  ext i
  fin_cases i <;> simp [Matrix.mulVec,dotProduct,Fin.sum_univ_two,angleVector,actionX,actionY]

theorem radial_transverse_reconstruct (M : PlaneMatrix) (s : ℝ) :
    radial M s*Real.cos s-transverse M s*Real.sin s=actionX M s ∧
    radial M s*Real.sin s+transverse M s*Real.cos s=actionY M s := by
  constructor
  · unfold radial transverse
    linear_combination actionX M s*(Real.sin_sq_add_cos_sq s)
  · unfold radial transverse
    linear_combination actionY M s*(Real.sin_sq_add_cos_sq s)

theorem positiveAngleLift_direction (M : PlaneMatrix) (s : ℝ) (hr : 0<radial M s) :
    ∃c:ℝ,0<c ∧ angleVector (positiveAngleLift M s)=c • (M*ᵥangleVector s) := by
  let u := transverse M s/radial M s
  have hsin : Real.sin (Real.arctan u)=u*Real.cos (Real.arctan u) := by
    rw [Real.sin_arctan,Real.cos_arctan]
    ring
  refine ⟨Real.cos (Real.arctan u)/radial M s,
    div_pos (Real.cos_arctan_pos u) hr,?_⟩
  rw [mulVec_angleVector]
  obtain ⟨hx,hy⟩ := radial_transverse_reconstruct M s
  funext i
  fin_cases i
  · change Real.cos (s+Real.arctan u)=_ * actionX M s
    rw [Real.cos_add,hsin]
    dsimp only [u]
    field_simp [hr.ne']
    linear_combination Real.cos (Real.arctan (transverse M s/radial M s))*hx
  · change Real.sin (s+Real.arctan u)=_ * actionY M s
    rw [Real.sin_add,hsin]
    dsimp only [u]
    field_simp [hr.ne']
    linear_combination Real.cos (Real.arctan (transverse M s/radial M s))*hy

theorem positiveAngleLift_add_pi (M : PlaneMatrix) (s : ℝ) :
    positiveAngleLift M (s+Real.pi)=positiveAngleLift M s+Real.pi := by
  have hr : radial M (s+Real.pi)=radial M s := by
    simp only [radial,actionX,actionY,Real.cos_add_pi,Real.sin_add_pi]
    ring
  have ht : transverse M (s+Real.pi)=transverse M s := by
    simp only [transverse,actionX,actionY,Real.cos_add_pi,Real.sin_add_pi]
    ring
  simp only [positiveAngleLift,hr,ht]
  ring

theorem continuous_positiveAngleLift {X : Type*} [TopologicalSpace X]
    (M : X→PlaneMatrix) (s : X→ℝ) (hM : Continuous M) (hs : Continuous s)
    (hr : ∀x,radial (M x) (s x)≠0) :
    Continuous (fun x => positiveAngleLift (M x) (s x)) := by
  have hx : Continuous (fun x => actionX (M x) (s x)) := by
    unfold actionX
    fun_prop
  have hy : Continuous (fun x => actionY (M x) (s x)) := by
    unfold actionY
    fun_prop
  exact hs.add (Real.continuous_arctan.comp
    ((hy.mul (Real.continuous_cos.comp hs) |>.sub
      (hx.mul (Real.continuous_sin.comp hs))).div
      ((hx.mul (Real.continuous_cos.comp hs)).add
        (hy.mul (Real.continuous_sin.comp hs))) hr))

def actionXDerivative (M : PlaneMatrix) (s : ℝ) : ℝ :=
  M 0 0*(-Real.sin s)+M 0 1*Real.cos s
def actionYDerivative (M : PlaneMatrix) (s : ℝ) : ℝ :=
  M 1 0*(-Real.sin s)+M 1 1*Real.cos s
def radialDerivative (M : PlaneMatrix) (s : ℝ) : ℝ :=
  (actionXDerivative M s*Real.cos s+actionX M s*(-Real.sin s))+
    (actionYDerivative M s*Real.sin s+actionY M s*Real.cos s)
def transverseDerivative (M : PlaneMatrix) (s : ℝ) : ℝ :=
  (actionYDerivative M s*Real.cos s+actionY M s*(-Real.sin s))-
    (actionXDerivative M s*Real.sin s+actionX M s*Real.cos s)

theorem actionX_hasDerivAt (M : PlaneMatrix) (s : ℝ) :
    HasDerivAt (actionX M) (actionXDerivative M s) s :=
  ((Real.hasDerivAt_cos s).const_mul (M 0 0)).add
    ((Real.hasDerivAt_sin s).const_mul (M 0 1))

theorem actionY_hasDerivAt (M : PlaneMatrix) (s : ℝ) :
    HasDerivAt (actionY M) (actionYDerivative M s) s :=
  ((Real.hasDerivAt_cos s).const_mul (M 1 0)).add
    ((Real.hasDerivAt_sin s).const_mul (M 1 1))

theorem radial_hasDerivAt (M : PlaneMatrix) (s : ℝ) :
    HasDerivAt (radial M) (radialDerivative M s) s :=
  ((actionX_hasDerivAt M s).mul (Real.hasDerivAt_cos s)).add
    ((actionY_hasDerivAt M s).mul (Real.hasDerivAt_sin s))

theorem transverse_hasDerivAt (M : PlaneMatrix) (s : ℝ) :
    HasDerivAt (transverse M) (transverseDerivative M s) s :=
  ((actionY_hasDerivAt M s).mul (Real.hasDerivAt_cos s)).sub
    ((actionX_hasDerivAt M s).mul (Real.hasDerivAt_sin s))

theorem radial_transverse_square (M : PlaneMatrix) (s : ℝ) :
    radial M s^2+transverse M s^2=actionX M s^2+actionY M s^2 := by
  calc
    _ = (actionX M s^2+actionY M s^2)*(Real.sin s^2+Real.cos s^2) := by
      unfold radial transverse
      ring
    _ = _ := by rw [Real.sin_sq_add_cos_sq,mul_one]

theorem angle_derivative_numerator (M : PlaneMatrix) (s : ℝ) :
    radial M s^2+transverse M s^2+
      transverseDerivative M s*radial M s-transverse M s*radialDerivative M s=M.det := by
  calc
    _ = M.det*(Real.sin s^2+Real.cos s^2)^2 := by
      simp only [radial,transverse,radialDerivative,transverseDerivative,
        actionX,actionY,actionXDerivative,actionYDerivative,Matrix.det_fin_two]
      ring
    _ = _ := by rw [Real.sin_sq_add_cos_sq,one_pow,mul_one]

theorem positiveAngleLift_hasDerivAt (M : PlaneMatrix) (s : ℝ) (hr : 0<radial M s) :
    HasDerivAt (positiveAngleLift M) (M.det/(actionX M s^2+actionY M s^2)) s := by
  have h := (hasDerivAt_id s).add
    (((transverse_hasDerivAt M s).div (radial_hasDerivAt M s) hr.ne').arctan)
  have hsum : 0<radial M s^2+transverse M s^2 := by
    nlinarith [sq_pos_of_pos hr,sq_nonneg (transverse M s)]
  have he : 1+1/(1+(transverse M s/radial M s)^2)*
      ((transverseDerivative M s*radial M s-transverse M s*radialDerivative M s)/radial M s^2)=
      M.det/(actionX M s^2+actionY M s^2) := by
    rw [← radial_transverse_square]
    have ht : 1+(transverse M s/radial M s)^2≠0 := by positivity
    field_simp [hr.ne',hsum.ne',ht]
    linear_combination radial M s^2*(radial M s^2+transverse M s^2)*
      (angle_derivative_numerator M s)
  convert h using 1
  exact he.symm

theorem positiveAngleLift_strictMono (M : PlaneMatrix) (hdet : 0<M.det)
    (hr : ∀s:ℝ,0<radial M s) : StrictMono (positiveAngleLift M) := by
  apply strictMono_of_hasDerivAt_pos (fun s => positiveAngleLift_hasDerivAt M s (hr s))
  intro s
  apply div_pos hdet
  rw [← radial_transverse_square]
  nlinarith [sq_pos_of_pos (hr s),sq_nonneg (transverse M s)]

end UAMO.ProjectiveAngle

import UAMO.RationalTransferBlocks
import UAMO.TransferMatrixPowerGrowth

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm

theorem transferSpectralRadius_log_intervalIntegrable (B : ℝ → TransferMatrix)
    (hc : Continuous B) (hd : ∀x,‖(B x).det‖=1) (u v : ℝ) :
    IntervalIntegrable (fun x => Real.log (transferSpectralRadius (B x))) volume u v := by
  have hcont (n : ℕ) : Continuous (fun x => Real.log (transferNorm ((B x)^n))/(n:ℝ)) := by
    apply Continuous.div_const
    apply Continuous.log (continuous_transferNorm.comp (hc.pow n))
    intro x
    exact (zero_lt_one.trans_le (transferNorm_pow_ge_one (B x) (hd x) n)).ne'
  have hmeas (μ : Measure ℝ) :
      AEStronglyMeasurable (fun x => Real.log (transferSpectralRadius (B x))) μ :=
    aestronglyMeasurable_of_tendsto_ae atTop (fun n => (hcont n).aestronglyMeasurable)
      (Eventually.of_forall (fun x => transferNorm_log_pow_tendsto (B x) (hd x)))
  have hbound : Continuous (fun x => Real.log (transferNorm (B x))) :=
    (continuous_transferNorm.comp hc).log
      (fun x => (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm (B x) (hd x))).ne')
  have hnorm (x : ℝ) : ‖Real.log (transferSpectralRadius (B x))‖≤Real.log (transferNorm (B x)) := by
    rw [Real.norm_eq_abs,abs_of_nonneg (transferSpectralRadius_log_bound (B x) (hd x)).1]
    exact (transferSpectralRadius_log_bound (B x) (hd x)).2
  exact ⟨(hbound.intervalIntegrable u v).1.mono' (hmeas _) (Eventually.of_forall hnorm),
    (hbound.intervalIntegrable u v).2.mono' (hmeas _) (Eventually.of_forall hnorm)⟩

theorem integral_transferNorm_log_pow_tendsto (B : ℝ → TransferMatrix)
    (hc : Continuous B) (hd : ∀x,‖(B x).det‖=1) {u v : ℝ} (huv : u≤v) :
    Tendsto (fun n:ℕ => ∫x in u..v,Real.log (transferNorm ((B x)^n))/(n:ℝ)) atTop
      (𝓝 (∫x in u..v,Real.log (transferSpectralRadius (B x)))) := by
  have hcont (n : ℕ) : Continuous (fun x => Real.log (transferNorm ((B x)^n))/(n:ℝ)) := by
    apply Continuous.div_const
    apply Continuous.log (continuous_transferNorm.comp (hc.pow n))
    intro x
    exact (zero_lt_one.trans_le (transferNorm_pow_ge_one (B x) (hd x) n)).ne'
  have hbound : Continuous (fun x => Real.log (transferNorm (B x))) :=
    (continuous_transferNorm.comp hc).log
      (fun x => (zero_lt_one.trans_le (one_le_transferNorm_of_det_norm (B x) (hd x))).ne')
  simp only [intervalIntegral.integral_of_le huv]
  apply tendsto_integral_of_dominated_convergence (fun x => Real.log (transferNorm (B x)))
  · intro n
    exact (hcont n).aestronglyMeasurable
  · exact (hbound.intervalIntegrable u v).1
  · intro n
    exact Eventually.of_forall (fun x => by
      rw [Real.norm_eq_abs,abs_of_nonneg (transferNorm_log_pow_bound (B x) (hd x) n).1]
      exact (transferNorm_log_pow_bound (B x) (hd x) n).2)
  · exact Eventually.of_forall (fun x => transferNorm_log_pow_tendsto (B x) (hd x))

theorem lyapunov_rational_formula (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    (p : ℤ) {q : ℕ} (hq : 0<q) :
    lyapunov A (2*Real.pi*p/q)=
      (∫x in (0:ℝ)..(2*Real.pi),Real.log (transferSpectralRadius
        (transferProduct A (2*Real.pi*p/q) x q)))/(2*Real.pi)/(q:ℝ) := by
  let ω := 2*Real.pi*p/q
  let B := fun x => transferProduct A ω x q
  have hq0 : (q:ℝ)≠0 := by exact_mod_cast hq.ne'
  have hclose : (q:ℝ)*ω=(p:ℝ)*(2*Real.pi) := by dsimp [ω]; field_simp; ring
  have hBcont : Continuous B := continuous_transferProduct A hc ω q
  have hBdet : ∀x,‖(B x).det‖=1 := fun x => transferProduct_det_norm A hd ω x q
  have hpowers := integral_transferNorm_log_pow_tendsto B hBcont hBdet
    (show (0:ℝ)≤2*Real.pi by positivity)
  have hlim := (hpowers.div_const (2*Real.pi)).div_const (q:ℝ)
  have heq (n : ℕ) :
      (∫x in (0:ℝ)..(2*Real.pi),Real.log (transferNorm ((B x)^n))/(n:ℝ))/(2*Real.pi)/(q:ℝ)=
        finiteLyapunov A ω (q*n) := by
    rw [intervalIntegral.integral_div]
    unfold finiteLyapunov transferLogAverage transferLogNorm
    simp only [transferProduct_rational_block A hp p q hclose,Nat.cast_mul,B]
    ring
  have hn : Tendsto (fun n:ℕ => q*n) atTop atTop := by
    apply tendsto_atTop_mono (fun n => ?_) tendsto_id
    exact Nat.le_mul_of_pos_left n hq
  have hactual := (tendsto_finiteLyapunov A hc hp hd ω).comp hn
  apply tendsto_nhds_unique hactual
  simpa only [heq,ω,B] using hlim

end UAMO.CMV

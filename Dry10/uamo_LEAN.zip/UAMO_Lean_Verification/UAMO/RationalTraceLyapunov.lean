import UAMO.TransferTraceRadius
import UAMO.RationalLyapunovFormula

noncomputable section
namespace UAMO.CMV
open MeasureTheory
open scoped Topology Matrix.L2OpNorm

def transferTraceLog (M : TransferMatrix) : ℝ := Real.log (max 1 ‖M.trace‖)

theorem continuous_transferTraceLog : Continuous transferTraceLog := by
  apply (continuous_const.max continuous_id.matrix_trace.norm).log
  intro M
  exact (zero_lt_one.trans_le (le_max_left (1:ℝ) ‖M.trace‖)).ne'

theorem rational_lyapunov_trace_error (A : ℝ→TransferMatrix) (hc : Continuous A)
    (hp : Function.Periodic A (2*Real.pi)) (hd : ∀x,‖(A x).det‖=1)
    (p : ℤ) {q : ℕ} (hq : 0<q) :
    |lyapunov A (2*Real.pi*p/q)-
      (∫x in (0:ℝ)..(2*Real.pi),transferTraceLog
        (transferProduct A (2*Real.pi*p/q) x q))/(2*Real.pi)/(q:ℝ)|≤
      Real.log 2/(q:ℝ) := by
  let B := fun x => transferProduct A (2*Real.pi*p/q) x q
  have hBc : Continuous B := continuous_transferProduct A hc _ q
  have hBd : ∀x,‖(B x).det‖=1 := fun x => transferProduct_det_norm A hd _ x q
  have hI := transferSpectralRadius_log_intervalIntegrable B hBc hBd 0 (2*Real.pi)
  have hJ : IntervalIntegrable (fun x => transferTraceLog (B x)) volume 0 (2*Real.pi) :=
    (continuous_transferTraceLog.comp hBc).intervalIntegrable 0 (2*Real.pi)
  have hbound (x : ℝ) :
      ‖Real.log (transferSpectralRadius (B x))-transferTraceLog (B x)‖≤Real.log 2 := by
    exact transferSpectralRadius_log_trace_bound (B x) (hBd x)
  have hdiff := intervalIntegral.norm_integral_le_of_norm_le_const
    (a:=(0:ℝ)) (b:=2*Real.pi)
    (fun x _ => hbound x)
  simp only [sub_zero,abs_of_pos Real.two_pi_pos] at hdiff
  rw [intervalIntegral.integral_sub hI hJ] at hdiff
  rw [lyapunov_rational_formula A hc hp hd p hq,← sub_div,← sub_div,abs_div,abs_div]
  have hqR : (0:ℝ)<q := by exact_mod_cast hq
  rw [abs_of_pos Real.two_pi_pos,abs_of_pos hqR]
  apply (div_le_div_iff_of_pos_right hqR).mpr
  apply (div_le_iff₀ Real.two_pi_pos).mpr
  simpa only [Real.norm_eq_abs,B,mul_comm] using hdiff

end UAMO.CMV

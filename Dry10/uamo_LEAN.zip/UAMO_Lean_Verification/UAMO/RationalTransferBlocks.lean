import UAMO.CMVLyapunov
import Mathlib.RingTheory.Coprime.Basic

noncomputable section
namespace UAMO.CMV
open Matrix

theorem transferProduct_rational_block (A : ℝ → TransferMatrix) {T ω : ℝ}
    (hp : Function.Periodic A T) (p : ℤ) (q : ℕ)
    (hclose : (q:ℝ)*ω=(p:ℝ)*T) (x : ℝ) (n : ℕ) :
    transferProduct A ω x (q*n)=(transferProduct A ω x q)^n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Nat.mul_succ,transferProduct_add]
    have he : transferProduct A ω (x+(q:ℝ)*ω) (q*n)=transferProduct A ω x (q*n) := by
      rw [hclose]
      simpa only [zsmul_eq_mul] using (transferProduct_periodic A hp ω (q*n)).zsmul p x
    rw [he,ih,pow_succ]

end UAMO.CMV

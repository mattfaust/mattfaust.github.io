import UAMO.RealCocycleTwist
import UAMO.CMVConjugacyGrowth

noncomputable section
namespace UAMO.CMV
open Matrix

def realCocycleConjugator (a : ℝ) : TransferMatrix :=
  !![Complex.I,1;Complex.I/(a : ℂ),-(a : ℂ)]

def complexRealTransfer (a lam t x : ℝ) : TransferMatrix :=
  (realTransfer a lam t x).map Complex.ofReal

theorem realCocycleConjugator_det {a : ℝ} (ha : 0<a) :
    (realCocycleConjugator a).det ≠ 0 := by
  have hac : (a : ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha.ne'
  have hs : (a : ℂ)^2+1≠0 := by
    have hr : a^2+1≠0 := by positivity
    exact_mod_cast hr
  simp only [realCocycleConjugator,Matrix.det_fin_two_of]
  have heq : Complex.I * -(a : ℂ) - 1 * (Complex.I/(a : ℂ)) =
      -Complex.I*((a : ℂ)^2+1)/(a : ℂ) := by field_simp; ring
  rw [heq]
  exact div_ne_zero (mul_ne_zero (neg_ne_zero.mpr Complex.I_ne_zero) hs) hac

theorem realCocycle_numerator_intertwining {a : ℝ} (ha : 0<a) (lam t x : ℝ) :
    physicalTransfer (coupling a) (complementaryCoupling a) (lam*Real.sin x)
      1 (Complex.exp ((t : ℂ)*Complex.I)) * realCocycleConjugator a =
    realCocycleConjugator a * (realTransferNumerator a lam t x).map Complex.ofReal := by
  have hac : (a : ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha.ne'
  have hs : 1+(a : ℂ)^2≠0 := by
    have hr : 1+a^2≠0 := by positivity
    exact_mod_cast hr
  have hexp : Complex.exp ((t : ℂ)*Complex.I) =
      (Real.cos t : ℂ)+(Real.sin t : ℂ)*Complex.I := by
    rw [Complex.exp_mul_I,Complex.ofReal_cos,Complex.ofReal_sin]
  have hexpi : (Complex.exp ((t : ℂ)*Complex.I))⁻¹ =
      (Real.cos t : ℂ)-(Real.sin t : ℂ)*Complex.I := by
    rw [← Complex.exp_neg,show -((t : ℂ)*Complex.I)=(-t : ℂ)*Complex.I by ring,
      Complex.exp_mul_I]
    simp [Complex.cos_neg,Complex.sin_neg,Complex.ofReal_cos,Complex.ofReal_sin,sub_eq_add_neg]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp only [physicalTransfer,realCocycleConjugator,realTransferNumerator,
      Matrix.mul_apply,Fin.sum_univ_two,Matrix.smul_apply,Matrix.map_apply,
      Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.head_cons,Matrix.head_fin_const,
      smul_eq_mul,inv_one,one_mul] <;>
    simp only [hexpi] <;>
    simp [hexp,coupling,complementaryCoupling] <;>
    field_simp [hac,hs] <;> ring_nf
  all_goals try simp [Complex.I_sq]
  all_goals try ring

theorem coupling_lt_one_of_lt_one {r : ℝ} (hr : r<1) : coupling r<1 := by
  rw [coupling,div_lt_one (by positivity : (0 : ℝ)<1+r^2)]
  nlinarith [sq_pos_of_ne_zero (sub_ne_zero.mpr hr.ne)]

theorem physicalHopping_norm_eq_realTransferDenominator (r x : ℝ) :
    ‖physicalHopping r x‖ = realTransferDenominator (coupling r) x := by
  have hn := congrArg Complex.re (physicalHopping_normalization r x)
  rw [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq] at hn
  simp only [Complex.add_re,← Complex.ofReal_pow,Complex.ofReal_re,Complex.one_re] at hn
  rw [realTransferDenominator,← show ‖physicalHopping r x‖^2=
      1-coupling r^2*Real.sin x^2 by dsimp [oddAlpha] at hn; nlinarith [hn],
    Real.sqrt_sq_eq_abs,abs_of_nonneg (norm_nonneg _)]

theorem realCocycle_intertwining {a r : ℝ} (ha : 0<a) (hr : 0≤r) (hr1 : r<1)
    (t x : ℝ) :
    ((star (physicalHopping r x)/(‖physicalHopping r x‖ : ℂ)) •
      uamoTransfer a r (Complex.exp ((t : ℂ)*Complex.I)) x) * realCocycleConjugator a =
      realCocycleConjugator a * complexRealTransfer a (coupling r) t x := by
  have hq : star (physicalHopping r x)≠0 :=
    star_ne_zero.mpr (physicalHopping_ne_zero hr hr1 x)
  have hg : (star (physicalHopping r x)/(‖physicalHopping r x‖ : ℂ)) *
      (star (physicalHopping r x))⁻¹ = (‖physicalHopping r x‖ : ℂ)⁻¹ := by
    rw [div_eq_mul_inv,mul_right_comm,mul_inv_cancel₀ hq,one_mul]
  have hA : (star (physicalHopping r x)/(‖physicalHopping r x‖ : ℂ)) •
      uamoTransfer a r (Complex.exp ((t : ℂ)*Complex.I)) x =
      (‖physicalHopping r x‖ : ℂ)⁻¹ •
      physicalTransfer (coupling a) (complementaryCoupling a) (coupling r*Real.sin x)
        1 (Complex.exp ((t : ℂ)*Complex.I)) := by
    simp only [uamoTransfer,physicalTransfer,oddAlpha,inv_one,one_smul,smul_smul,hg]
  have hB : complexRealTransfer a (coupling r) t x =
      (‖physicalHopping r x‖ : ℂ)⁻¹ •
        (realTransferNumerator a (coupling r) t x).map Complex.ofReal := by
    ext i j
    simp [complexRealTransfer,realTransfer,physicalHopping_norm_eq_realTransferDenominator]
  rw [hA,hB,Matrix.smul_mul,Matrix.mul_smul,
    realCocycle_numerator_intertwining ha]

theorem realCocycle_conjugacy {a r : ℝ} (ha : 0<a) (hr : 0≤r) (hr1 : r<1)
    (t x : ℝ) :
    (star (physicalHopping r x)/(‖physicalHopping r x‖ : ℂ)) •
      uamoTransfer a r (Complex.exp ((t : ℂ)*Complex.I)) x =
    realCocycleConjugator a * complexRealTransfer a (coupling r) t x *
      (realCocycleConjugator a)⁻¹ := by
  have hi := Matrix.mul_nonsing_inv (realCocycleConjugator a)
    (isUnit_iff_ne_zero.mpr (realCocycleConjugator_det ha))
  rw [← realCocycle_intertwining ha hr hr1, mul_assoc,hi,mul_one]

theorem continuous_complexRealTransfer (a : ℝ) {lam : ℝ}
    (hlam : 0≤lam) (hlam1 : lam<1) (t : ℝ) :
    Continuous (complexRealTransfer a lam t) := by
  have hp : Continuous (realTransferDenominator lam) := by
    unfold realTransferDenominator
    fun_prop
  have hn : Continuous (realTransferNumerator a lam t) := by
    apply continuous_matrix
    intro i j
    fin_cases i <;> fin_cases j <;> simp [realTransferNumerator] <;> fun_prop
  have hR : Continuous (realTransfer a lam t) :=
    (hp.inv₀ (fun x => (realTransferDenominator_pos hlam hlam1 x).ne')).smul hn
  apply continuous_matrix
  intro i j
  exact Complex.continuous_ofReal.comp ((continuous_apply j).comp ((continuous_apply i).comp hR))

theorem complexRealTransfer_periodic (a lam t : ℝ) :
    Function.Periodic (complexRealTransfer a lam t) (2*Real.pi) := by
  intro x
  simp only [complexRealTransfer,realTransfer,realTransferNumerator,
    realTransferDenominator,Real.sin_add_two_pi]

theorem complexRealTransfer_det {a lam : ℝ} (ha : a≠0) (hlam : 0≤lam)
    (hlam1 : lam<1) (t x : ℝ) : (complexRealTransfer a lam t x).det=1 := by
  have h := congrArg Complex.ofReal (realTransfer_det ha hlam hlam1 t x)
  simpa [complexRealTransfer,Matrix.det_fin_two] using h

end UAMO.CMV

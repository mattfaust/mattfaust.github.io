import UAMO.RealCocycleConjugacy
import UAMO.LatticeMatrixMultiplier
import UAMO.LatticeScalarGauge
import UAMO.CMVTransferDetGrowthComparison

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalRepresentation

theorem transfer_entry_product_bound (A B : TransferMatrix) {K L : ℝ}
    (hK : 0≤K) (_hL : 0≤L) (hA : ∀i j,‖A i j‖≤K) (hB : ∀i j,‖B i j‖≤L)
    (i j : Fin 2) : ‖(A*B) i j‖≤2*K*L := by
  simp only [Matrix.mul_apply,Fin.sum_univ_two]
  calc
    _ ≤ ‖A i 0*B 0 j‖+‖A i 1*B 1 j‖ := norm_add_le _ _
    _ ≤ K*L+K*L := add_le_add
      (by rw [norm_mul]; exact mul_le_mul (hA i 0) (hB 0 j) (norm_nonneg _) hK)
      (by rw [norm_mul]; exact mul_le_mul (hA i 1) (hB 1 j) (norm_nonneg _) hK)
    _ = _ := by ring

theorem latticeDifference_isUnit_iff_scalar_conjugacy
    (A B : ℤ→TransferMatrix) (η : ℤ→ℂ) (C D : TransferMatrix)
    (CA CB : ℝ) (hCA : 0≤CA) (hCB : 0≤CB)
    (hA : ∀n i j,‖A n i j‖≤CA) (hB : ∀n i j,‖B n i j‖≤CB)
    (hη : ∀n,‖η n‖=1) (hCD : C*D=1)
    (hconj : ∀n,(η n • A n)*C=C*B n) :
    IsUnit (latticeDifference A CA hCA hA) ↔
      IsUnit (latticeDifference B CB hCB hB) := by
  let ηi := fun n => (η n)⁻¹
  have hηi : ∀n,‖ηi n‖=1 := by intro n; simp [ηi,hη]
  let g := orbitGauge ηi
  have hg : ∀n,‖g n‖=1 := orbitGauge_norm ηi hηi
  have hgn : ∀n,g n≠0 := fun n => norm_ne_zero_iff.mp (by rw [hg]; norm_num)
  let F := fun n => g n • C
  let G := fun n => (g n)⁻¹ • D
  have hF : ∀n i j,‖F n i j‖≤transferNorm C := by
    intro n i j
    simpa only [F,Matrix.smul_apply,smul_eq_mul,norm_mul,hg,one_mul] using
      transferNorm_entry_le C i j
  have hG : ∀n i j,‖G n i j‖≤transferNorm D := by
    intro n i j
    simpa only [G,Matrix.smul_apply,smul_eq_mul,norm_mul,norm_inv,hg,inv_one,one_mul] using
      transferNorm_entry_le D i j
  apply latticeDifference_isUnit_iff_frame A B F G CA CB (transferNorm C) (transferNorm D)
    hCA hCB (norm_nonneg _) (norm_nonneg _) hA hB hF hG
  · intro n
    simp only [F,G,Matrix.smul_mul,Matrix.mul_smul,smul_smul,inv_mul_cancel₀ (hgn n),
      one_smul,hCD]
  · intro n
    have hne : η n≠0 := norm_ne_zero_iff.mp (by rw [hη]; norm_num)
    have he := congrArg (fun M => (η n)⁻¹ • M) (hconj n)
    simp only [Matrix.smul_mul,smul_smul,inv_mul_cancel₀ hne,one_smul] at he
    dsimp only [F]
    rw [Matrix.mul_smul,he,smul_smul,Matrix.smul_mul]
    congr 1
    rw [show g (n+1)=ηi n*g n from orbitGauge_succ ηi hηi n]
    dsimp only [ηi]
    ring

theorem physicalWalk_resolvent_iff_real_latticeDifference
    {a r : ℝ} (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1)
    (Φ θ t : ℝ) (CB : ℝ) (hCB : 0≤CB)
    (hB : ∀n i j,‖complexRealTransfer a (coupling r) t (phaseAngle Φ θ n) i j‖≤CB) :
    Complex.exp ((t:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ↔
      IsUnit (latticeDifference
        (fun n => complexRealTransfer a (coupling r) t (phaseAngle Φ θ n)) CB hCB hB) := by
  let z := Complex.exp ((t:ℂ)*Complex.I)
  let A := fun n => uamoTransfer a r z (phaseAngle Φ θ n)
  let B := fun n => complexRealTransfer a (coupling r) t (phaseAngle Φ θ n)
  let η := fun n => star (physicalHopping r (phaseAngle Φ θ n)) /
    (‖physicalHopping r (phaseAngle Φ θ n)‖:ℂ)
  let C := realCocycleConjugator a
  let D := C⁻¹
  have hη : ∀n,‖η n‖=1 := by
    intro n
    simp only [η,norm_div,norm_star,Complex.norm_real,Real.norm_eq_abs,
      abs_of_nonneg (norm_nonneg _),
      div_self (norm_ne_zero_iff.mpr (physicalHopping_ne_zero hr hr1 _))]
  have hCD : C*D=1 := Matrix.mul_nonsing_inv C
    (isUnit_iff_ne_zero.mpr (realCocycleConjugator_det ha))
  have hconj : ∀n,(η n • A n)*C=C*B n := fun n => realCocycle_intertwining ha hr hr1 t _
  have he : ∀n,η n • A n=C*B n*D := fun n => realCocycle_conjugacy ha hr hr1 t _
  let CA := 2*(2*transferNorm C*CB)*transferNorm D
  have hCA : 0≤CA := by dsimp only [CA,transferNorm]; positivity
  have hA : ∀n i j,‖A n i j‖≤CA := by
    intro n i j
    have hh := transfer_entry_product_bound (C*B n) D
      (show 0≤2*transferNorm C*CB by dsimp only [transferNorm]; positivity)
      (norm_nonneg _) (transfer_entry_product_bound C (B n) (norm_nonneg _) hCB
        (transferNorm_entry_le C) (hB n)) (transferNorm_entry_le D) i j
    rw [← he] at hh
    simpa only [Matrix.smul_apply,smul_eq_mul,norm_mul,hη,one_mul] using hh
  rw [show (z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ)) ↔
    IsUnit (physicalDifferenceOperator a r Φ θ z ha hr hr1 (Complex.exp_ne_zero _)) from
      (by simpa only [spectrum,Set.mem_compl_iff,not_not] using
        physicalWalk_resolvent_iff_difference a r Φ θ z ha ha1 hr hr1 (Complex.exp_ne_zero _)),
    physicalDifferenceOperator_eq_latticeDifference a r Φ θ z ha hr hr1 (Complex.exp_ne_zero _)
      CA hCA hA]
  exact latticeDifference_isUnit_iff_scalar_conjugacy A B η C D CA CB hCA hCB hA hB hη hCD hconj

end UAMO.CMV

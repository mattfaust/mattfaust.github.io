import UAMO.Basic
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.Tactic

noncomputable section
namespace UAMO
open Matrix

def realTransferDenominator (lam x : ℝ) : ℝ :=
  Real.sqrt (1-lam^2*Real.sin x^2)

def realTransfer (a lam t x : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  (realTransferDenominator lam x)⁻¹ • realTransferNumerator a lam t x

theorem realTransferDenominator_sq_pos {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1) (x : ℝ) :
    0<1-lam^2*Real.sin x^2 := by
  have h := realTransferNumerator_det_pos (a := 1) (by norm_num) hlam hlam1 0 x
  rwa [realTransferNumerator_det (by norm_num : (1 : ℝ)≠0)] at h

theorem realTransferDenominator_pos {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1) (x : ℝ) :
    0<realTransferDenominator lam x := Real.sqrt_pos.mpr (realTransferDenominator_sq_pos hlam hlam1 x)

theorem realTransferDenominator_sq {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1) (x : ℝ) :
    (realTransferDenominator lam x)^2=1-lam^2*Real.sin x^2 :=
  Real.sq_sqrt (realTransferDenominator_sq_pos hlam hlam1 x).le

theorem realTransfer_det {a lam : ℝ} (ha : a≠0) (hlam : 0≤lam) (hlam1 : lam<1) (t x : ℝ) :
    (realTransfer a lam t x).det=1 := by
  rw [realTransfer,Matrix.det_smul,Fintype.card_fin,realTransferNumerator_det ha,
    ← realTransferDenominator_sq hlam hlam1 x]
  rw [inv_pow]
  exact inv_mul_cancel₀ (pow_ne_zero 2 (realTransferDenominator_pos hlam hlam1 x).ne')

end UAMO

import UAMO.GreenStableProjection

noncomputable section
namespace UAMO.CMV
open Matrix PhysicalWalk PhysicalRepresentation PhysicalRealPart

def spinConjugate (ψ : SpinHilbert) : SpinHilbert := fun i => star (ψ i)

@[simp] theorem spinConjugate_apply (ψ : SpinHilbert) (i : Fin 2) (n : ℤ) :
    spinConjugate ψ i n=star (ψ i n) := rfl

@[simp] theorem siteVector_spinConjugate (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinConjugate ψ) n=star (siteVector ψ n) := by
  ext i
  simp only [siteVector_apply,spinConjugate_apply,Pi.star_apply]

theorem spinConjugate_siteImpulse (n : ℤ) (v : TransferVector) :
    spinConjugate (siteImpulse n v)=siteImpulse n (star v) := by
  apply spin_eq_of_siteVector_eq
  intro k
  rw [siteVector_spinConjugate,siteVector_siteImpulse,siteVector_siteImpulse]
  split_ifs <;> simp

theorem latticeDifference_spinConjugate
    (A : ℤ→TransferMatrix) (B : ℝ) (hB : 0≤B)
    (hA : ∀n i j,‖A n i j‖≤B)
    (hreal : ∀n i j,star (A n i j)=A n i j) (ψ : SpinHilbert) :
    spinAction (latticeDifference A B hB hA) (spinConjugate ψ)=
      spinConjugate (spinAction (latticeDifference A B hB hA) ψ) := by
  apply spin_eq_of_siteVector_eq
  intro n
  rw [latticeDifference_apply,siteVector_spinConjugate,siteVector_spinConjugate,
    siteVector_spinConjugate,latticeDifference_apply]
  ext i
  simp only [Pi.sub_apply,Pi.star_apply,Matrix.mulVec,dotProduct,Fin.sum_univ_two,
    star_sub,star_add,StarMul.star_mul,hreal]
  ring

theorem greenColumn_spinConjugate
    (A : ℤ→TransferMatrix) (B : ℝ) (hB : 0≤B)
    (hA : ∀n i j,‖A n i j‖≤B)
    (hreal : ∀n i j,star (A n i j)=A n i j)
    (hD : IsUnit (latticeDifference A B hB hA)) (m : ℤ) (v : TransferVector) :
    spinConjugate (greenColumn (latticeDifference A B hB hA) m v)=
      greenColumn (latticeDifference A B hB hA) m (star v) := by
  apply greenColumn_unique hD
  rw [latticeDifference_spinConjugate A B hB hA hreal,
    greenColumn_solution hD,spinConjugate_siteImpulse]

theorem greenColumn_real_source
    (A : ℤ→TransferMatrix) (B : ℝ) (hB : 0≤B)
    (hA : ∀n i j,‖A n i j‖≤B)
    (hreal : ∀n i j,star (A n i j)=A n i j)
    (hD : IsUnit (latticeDifference A B hB hA)) (m : ℤ) (v : TransferVector)
    (hv : star v=v) (i : Fin 2) (n : ℤ) :
    star (greenColumn (latticeDifference A B hB hA) m v i n)=
      greenColumn (latticeDifference A B hB hA) m v i n := by
  have h := congrArg (fun ψ : SpinHilbert => ψ i n)
    (greenColumn_spinConjugate A B hB hA hreal hD m v)
  simpa only [spinConjugate_apply,hv] using h

theorem greenStableMatrix_entry_real
    (A : ℤ→TransferMatrix) (B : ℝ) (hB : 0≤B)
    (hA : ∀n i j,‖A n i j‖≤B)
    (hreal : ∀n i j,star (A n i j)=A n i j)
    (hD : IsUnit (latticeDifference A B hB hA)) (n : ℤ) (i j : Fin 2) :
    star (greenStableMatrix (latticeDifference A B hB hA) n i j)=
      greenStableMatrix (latticeDifference A B hB hA) n i j := by
  have hb : star (Pi.single j (1:ℂ) : TransferVector)=Pi.single j (1:ℂ) := by
    simpa only [star_one] using (Pi.single_star (f:=fun _ : Fin 2 => ℂ) j (1:ℂ)).symm
  have h := greenColumn_real_source A B hB hA hreal hD (n-1)
    (Pi.single j 1) hb i n
  have he : greenStableMatrix (latticeDifference A B hB hA) n i j=
      greenColumn (latticeDifference A B hB hA) (n-1) (Pi.single j 1) i n := by
    simpa only [Matrix.mulVec_single_one,siteVector_apply] using
      congrFun (greenStableMatrix_mulVec (latticeDifference A B hB hA) n (Pi.single j 1)) i
  rw [he]
  exact h

def greenStableRealMatrix (D : TwoByTwo Operator) (n : ℤ) : Matrix (Fin 2) (Fin 2) ℝ :=
  (greenStableMatrix D n).map Complex.re

theorem greenStableRealMatrix_map
    (A : ℤ→TransferMatrix) (B : ℝ) (hB : 0≤B)
    (hA : ∀n i j,‖A n i j‖≤B)
    (hreal : ∀n i j,star (A n i j)=A n i j)
    (hD : IsUnit (latticeDifference A B hB hA)) (n : ℤ) :
    (greenStableRealMatrix (latticeDifference A B hB hA) n).map Complex.ofReal=
      greenStableMatrix (latticeDifference A B hB hA) n := by
  ext i j
  exact Complex.conj_eq_iff_re.mp (greenStableMatrix_entry_real A B hB hA hreal hD n i j)

end UAMO.CMV

import UAMO.ProjectiveAngleLift
import UAMO.RealCocycleTwist

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

def diagonalFactor (a : ℝ) : PlaneMatrix := !![a,0;0,a⁻¹]
def rotationFactor (t : ℝ) : PlaneMatrix :=
  !![Real.cos t,-Real.sin t;Real.sin t,Real.cos t]
def symmetricFactor (b t : ℝ) : PlaneMatrix :=
  !![1-b*Real.cos t,b*Real.sin t;b*Real.sin t,1+b*Real.cos t]

theorem realTransferNumerator_factorization (a lam t x : ℝ) :
    realTransferNumerator a lam t x =
      diagonalFactor a*rotationFactor t*symmetricFactor (lam*Real.sin x) t := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [realTransferNumerator,diagonalFactor,rotationFactor,symmetricFactor,
      Matrix.mul_apply,Fin.sum_univ_two]
  · linear_combination a*lam*Real.sin x*(Real.sin_sq_add_cos_sq t)
  · ring
  · ring
  · linear_combination -(a⁻¹*lam*Real.sin x)*(Real.sin_sq_add_cos_sq t)

theorem realTransfer_factorization (a lam t x : ℝ) :
    realTransfer a lam t x = (realTransferDenominator lam x)⁻¹ •
      (diagonalFactor a*rotationFactor t*symmetricFactor (lam*Real.sin x) t) := by
  rw [realTransfer,realTransferNumerator_factorization]

theorem diagonalFactor_det {a : ℝ} (ha : a≠0) : (diagonalFactor a).det=1 := by
  simp [diagonalFactor,Matrix.det_fin_two,ha]

theorem rotationFactor_det (t : ℝ) : (rotationFactor t).det=1 := by
  simp only [rotationFactor,Matrix.det_fin_two_of]
  nlinarith [Real.sin_sq_add_cos_sq t]

theorem symmetricFactor_det (b t : ℝ) : (symmetricFactor b t).det=1-b^2 := by
  simp only [symmetricFactor,Matrix.det_fin_two_of]
  linear_combination -(b^2)*(Real.sin_sq_add_cos_sq t)

theorem symmetricFactor_det_pos {b : ℝ} (hb : |b|<1) (t : ℝ) :
    0<(symmetricFactor b t).det := by
  rw [symmetricFactor_det]
  obtain ⟨hl,hr⟩ := abs_lt.mp hb
  nlinarith

theorem diagonalFactor_radial (a s : ℝ) :
    radial (diagonalFactor a) s = a*Real.cos s^2+a⁻¹*Real.sin s^2 := by
  simp [radial,actionX,actionY,diagonalFactor]
  ring

theorem diagonalFactor_radial_pos {a : ℝ} (ha : 0<a) (s : ℝ) :
    0<radial (diagonalFactor a) s := by
  rw [diagonalFactor_radial]
  have hi : 0<a⁻¹ := inv_pos.mpr ha
  calc
    0 < min a a⁻¹ := lt_min ha hi
    _ = min a a⁻¹*Real.cos s^2+min a a⁻¹*Real.sin s^2 := by
      linear_combination -(min a a⁻¹)*(Real.sin_sq_add_cos_sq s)
    _ ≤ a*Real.cos s^2+a⁻¹*Real.sin s^2 := add_le_add
      (mul_le_mul_of_nonneg_right (min_le_left _ _) (sq_nonneg _))
      (mul_le_mul_of_nonneg_right (min_le_right _ _) (sq_nonneg _))

theorem symmetricFactor_radial (b t s : ℝ) :
    radial (symmetricFactor b t) s=1-b*Real.cos (t+2*s) := by
  simp only [radial,actionX,actionY,symmetricFactor,Matrix.of_apply,
    Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.head_cons,Matrix.head_fin_const,
    Real.cos_add,Real.cos_two_mul,Real.sin_two_mul]
  linear_combination (1+b*Real.cos t)*(Real.sin_sq_add_cos_sq s)

theorem symmetricFactor_radial_lower (b t s : ℝ) :
    1-|b| ≤ radial (symmetricFactor b t) s := by
  rw [symmetricFactor_radial]
  have h : b*Real.cos (t+2*s) ≤ |b| := calc
    _ ≤ |b*Real.cos (t+2*s)| := le_abs_self _
    _ = |b| * |Real.cos (t+2*s)| := abs_mul _ _
    _ ≤ |b| * 1 := mul_le_mul_of_nonneg_left (Real.abs_cos_le_one _) (abs_nonneg _)
    _ = |b| := mul_one _
  linarith

theorem symmetricFactor_radial_pos {b : ℝ} (hb : |b|<1) (t s : ℝ) :
    0<radial (symmetricFactor b t) s :=
  lt_of_lt_of_le (by linarith) (symmetricFactor_radial_lower b t s)

theorem coupling_sine_abs_lt_one {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1) (x : ℝ) :
    |lam*Real.sin x|<1 := by
  rw [abs_mul,abs_of_nonneg hlam]
  exact (mul_le_mul_of_nonneg_left (Real.abs_sin_le_one x) hlam).trans_lt (by simpa using hlam1)

theorem physical_symmetricFactor_radial_pos {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1)
    (t x s : ℝ) : 0<radial (symmetricFactor (lam*Real.sin x) t) s :=
  symmetricFactor_radial_pos (coupling_sine_abs_lt_one hlam hlam1 x) t s

theorem rotationFactor_mulVec (t s : ℝ) :
    rotationFactor t*ᵥangleVector s=angleVector (t+s) := by
  ext i
  fin_cases i <;> simp [rotationFactor,angleVector,Matrix.mulVec,dotProduct,
    Fin.sum_univ_two,Real.cos_add,Real.sin_add]
  all_goals ring

theorem continuous_symmetricFactor : Continuous (fun p : ℝ×ℝ => symmetricFactor p.1 p.2) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  fin_cases i <;> fin_cases j <;> simp [symmetricFactor] <;> fun_prop

end UAMO.ProjectiveAngle

import UAMO.RealProjectiveFactors

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

def realTransferAngleLift (a lam t x s : ℝ) : ℝ :=
  positiveAngleLift (diagonalFactor a)
    (t+positiveAngleLift (symmetricFactor (lam*Real.sin x) t) s)

theorem realTransferAngleLift_add_pi (a lam t x s : ℝ) :
    realTransferAngleLift a lam t x (s+Real.pi)=
      realTransferAngleLift a lam t x s+Real.pi := by
  unfold realTransferAngleLift
  rw [positiveAngleLift_add_pi,← add_assoc,positiveAngleLift_add_pi]

theorem continuous_realTransferAngleLift {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) :
    Continuous (fun p : ℝ×ℝ×ℝ => realTransferAngleLift a lam p.1 p.2.1 p.2.2) := by
  have hM : Continuous (fun p : ℝ×ℝ×ℝ => symmetricFactor (lam*Real.sin p.2.1) p.1) :=
    continuous_symmetricFactor.comp
      (show Continuous (fun p : ℝ×ℝ×ℝ => (lam*Real.sin p.2.1,p.1)) from by fun_prop)
  have hinner : Continuous (fun p : ℝ×ℝ×ℝ =>
      positiveAngleLift (symmetricFactor (lam*Real.sin p.2.1) p.1) p.2.2) :=
    continuous_positiveAngleLift _ _ hM (by fun_prop)
      (fun p => (physical_symmetricFactor_radial_pos hlam hlam1 p.1 p.2.1 p.2.2).ne')
  exact continuous_positiveAngleLift (fun _ => diagonalFactor a) _ continuous_const
    (continuous_fst.add hinner) (fun _ => (diagonalFactor_radial_pos ha _).ne')

theorem realTransferAngleLift_direction {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (t x s : ℝ) :
    ∃c:ℝ,0<c ∧ angleVector (realTransferAngleLift a lam t x s)=
      c • (realTransfer a lam t x*ᵥangleVector s) := by
  obtain ⟨c₁,hc₁,h₁⟩ := positiveAngleLift_direction
    (symmetricFactor (lam*Real.sin x) t) s (physical_symmetricFactor_radial_pos hlam hlam1 t x s)
  obtain ⟨c₂,hc₂,h₂⟩ := positiveAngleLift_direction (diagonalFactor a)
    (t+positiveAngleLift (symmetricFactor (lam*Real.sin x) t) s) (diagonalFactor_radial_pos ha _)
  have hd := realTransferDenominator_pos hlam hlam1 x
  refine ⟨c₂*c₁*realTransferDenominator lam x,by positivity,?_⟩
  change angleVector (positiveAngleLift (diagonalFactor a)
    (t+positiveAngleLift (symmetricFactor (lam*Real.sin x) t) s))=_
  rw [h₂,← rotationFactor_mulVec,h₁,Matrix.mulVec_smul,Matrix.mulVec_smul,smul_smul,
    Matrix.mulVec_mulVec,Matrix.mulVec_mulVec,
    realTransfer_factorization,Matrix.smul_mulVec_assoc,smul_smul]
  congr 1
  field_simp [hd.ne']

theorem realTransferAngleLift_strictMono {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (t x : ℝ) :
    StrictMono (realTransferAngleLift a lam t x) := by
  have hD := positiveAngleLift_strictMono (diagonalFactor a)
    (by rw [diagonalFactor_det ha.ne']; norm_num) (diagonalFactor_radial_pos ha)
  have hP := positiveAngleLift_strictMono (symmetricFactor (lam*Real.sin x) t)
    (symmetricFactor_det_pos (coupling_sine_abs_lt_one hlam hlam1 x) t)
    (physical_symmetricFactor_radial_pos hlam hlam1 t x)
  intro s u hsu
  exact hD (add_lt_add_left (hP hsu) t)

end UAMO.ProjectiveAngle

import UAMO.RealTransferAngleLift

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

theorem positiveAngleLift_add_two_pi (M : PlaneMatrix) (s : ℝ) :
    positiveAngleLift M (s+2*Real.pi)=positiveAngleLift M s+2*Real.pi := by
  rw [show s+2*Real.pi=(s+Real.pi)+Real.pi by ring,
    positiveAngleLift_add_pi,positiveAngleLift_add_pi]
  ring

theorem symmetricFactor_spectral_periodic (b t : ℝ) :
    symmetricFactor b (t+2*Real.pi)=symmetricFactor b t := by
  simp only [symmetricFactor,Real.cos_add_two_pi,Real.sin_add_two_pi]

theorem realTransferAngleLift_spectral_periodic (a lam t x s : ℝ) :
    realTransferAngleLift a lam (t+2*Real.pi) x s=
      realTransferAngleLift a lam t x s+2*Real.pi := by
  simp only [realTransferAngleLift,symmetricFactor_spectral_periodic]
  rw [show t+2*Real.pi+positiveAngleLift (symmetricFactor (lam*Real.sin x) t) s=
    (t+positiveAngleLift (symmetricFactor (lam*Real.sin x) t) s)+2*Real.pi by ring,
    positiveAngleLift_add_two_pi]

theorem positiveAngleLift_zero_of_lower_left_zero (M : PlaneMatrix) (h : M 1 0=0) :
    positiveAngleLift M 0=0 := by
  simp [positiveAngleLift,transverse,actionX,actionY,h]

theorem realTransferAngleLift_zero_axis (a lam x : ℝ) :
    realTransferAngleLift a lam 0 x 0=0 := by
  unfold realTransferAngleLift
  rw [positiveAngleLift_zero_of_lower_left_zero _ (by simp [symmetricFactor]),zero_add]
  exact positiveAngleLift_zero_of_lower_left_zero _ (by simp [diagonalFactor])

theorem realTransferAngleLift_pi_axis (a lam x : ℝ) :
    realTransferAngleLift a lam Real.pi x 0=Real.pi := by
  unfold realTransferAngleLift
  rw [positiveAngleLift_zero_of_lower_left_zero _ (by simp [symmetricFactor]),add_zero]
  have h := positiveAngleLift_add_pi (diagonalFactor a) 0
  have h0 : positiveAngleLift (diagonalFactor a) 0=0 :=
    positiveAngleLift_zero_of_lower_left_zero _ (by simp [diagonalFactor])
  simpa only [zero_add,h0] using h

end UAMO.ProjectiveAngle

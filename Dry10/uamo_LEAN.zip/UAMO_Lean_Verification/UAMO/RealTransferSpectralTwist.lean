import UAMO.RealTransferAngleLift

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

theorem symmetricFactor_transverse (b t s : ℝ) :
    transverse (symmetricFactor b t) s=b*Real.sin (t+2*s) := by
  simp only [transverse,actionX,actionY,symmetricFactor,Matrix.of_apply,
    Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.head_cons,Matrix.head_fin_const,
    Real.sin_add,Real.cos_two_mul,Real.sin_two_mul]
  linear_combination -(b*Real.sin t)*(Real.sin_sq_add_cos_sq s)

def spectralInnerAngle (b t s : ℝ) : ℝ :=
  t+positiveAngleLift (symmetricFactor b t) s

def spectralInnerDerivative (b t s : ℝ) : ℝ :=
  (1-b*Real.cos (t+2*s))/(1-2*b*Real.cos (t+2*s)+b^2)

theorem spectralInnerAngle_formula (b t s : ℝ) :
    spectralInnerAngle b t s=t+s+
      Real.arctan ((b*Real.sin (t+2*s))/(1-b*Real.cos (t+2*s))) := by
  simp only [spectralInnerAngle,positiveAngleLift,symmetricFactor_transverse,symmetricFactor_radial]
  ring

theorem spectral_denominator_eq_squares (b t s : ℝ) :
    1-2*b*Real.cos (t+2*s)+b^2=
      (1-b*Real.cos (t+2*s))^2+(b*Real.sin (t+2*s))^2 := by
  linear_combination -(b^2)*(Real.sin_sq_add_cos_sq (t+2*s))

theorem spectral_radial_pos {b : ℝ} (hb : |b|<1) (t s : ℝ) :
    0<1-b*Real.cos (t+2*s) := by
  rw [← symmetricFactor_radial]
  exact symmetricFactor_radial_pos hb t s

theorem spectral_denominator_pos {b : ℝ} (hb : |b|<1) (t s : ℝ) :
    0<1-2*b*Real.cos (t+2*s)+b^2 := by
  rw [spectral_denominator_eq_squares]
  exact add_pos_of_pos_of_nonneg (sq_pos_of_pos (spectral_radial_pos hb t s)) (sq_nonneg _)

theorem spectralInnerDerivative_pos {b : ℝ} (hb : |b|<1) (t s : ℝ) :
    0<spectralInnerDerivative b t s :=
  div_pos (spectral_radial_pos hb t s) (spectral_denominator_pos hb t s)

theorem spectralInnerAngle_hasDerivAt {b : ℝ} (hb : |b|<1) (t s : ℝ) :
    HasDerivAt (fun u => spectralInnerAngle b u s) (spectralInnerDerivative b t s) t := by
  have hsin : HasDerivAt (fun u => b*Real.sin (u+2*s)) (b*Real.cos (t+2*s)) t := by
    simpa using (((hasDerivAt_id t).add_const (2*s)).sin.const_mul b)
  have hcos : HasDerivAt (fun u => 1-b*Real.cos (u+2*s)) (b*Real.sin (t+2*s)) t := by
    simpa using (((hasDerivAt_id t).add_const (2*s)).cos.const_mul b).const_sub 1
  have hr := spectral_radial_pos hb t s
  have h := ((hasDerivAt_id t).add_const s).add ((hsin.div hcos hr.ne').arctan)
  have he : 1+1/(1+((b*Real.sin (t+2*s))/(1-b*Real.cos (t+2*s)))^2)*
      ((b*Real.cos (t+2*s)*(1-b*Real.cos (t+2*s))-
        (b*Real.sin (t+2*s))*(b*Real.sin (t+2*s)))/(1-b*Real.cos (t+2*s))^2)=
      spectralInnerDerivative b t s := by
    unfold spectralInnerDerivative
    rw [spectral_denominator_eq_squares]
    have hsum : 0<(1-b*Real.cos (t+2*s))^2+(b*Real.sin (t+2*s))^2 := by
      exact add_pos_of_pos_of_nonneg (sq_pos_of_pos hr) (sq_nonneg _)
    have hquot : 1+((b*Real.sin (t+2*s))/(1-b*Real.cos (t+2*s)))^2≠0 := by positivity
    field_simp [hr.ne',hsum.ne',hquot]
    ring
  rw [he] at h
  simpa only [spectralInnerAngle_formula] using h

def realTransferAngleSpectralDerivative (a lam t x s : ℝ) : ℝ :=
  let u := spectralInnerAngle (lam*Real.sin x) t s
  (actionX (diagonalFactor a) u^2+actionY (diagonalFactor a) u^2)⁻¹ *
    spectralInnerDerivative (lam*Real.sin x) t s

theorem realTransferAngleSpectralDerivative_pos {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (t x s : ℝ) :
    0<realTransferAngleSpectralDerivative a lam t x s := by
  let u := spectralInnerAngle (lam*Real.sin x) t s
  have hden : 0<actionX (diagonalFactor a) u^2+actionY (diagonalFactor a) u^2 := by
    rw [← radial_transverse_square]
    exact add_pos_of_pos_of_nonneg (sq_pos_of_pos (diagonalFactor_radial_pos ha u)) (sq_nonneg _)
  exact mul_pos (inv_pos.mpr hden)
    (spectralInnerDerivative_pos (coupling_sine_abs_lt_one hlam hlam1 x) t s)

theorem realTransferAngleLift_spectral_hasDerivAt {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (t x s : ℝ) :
    HasDerivAt (fun u => realTransferAngleLift a lam u x s)
      (realTransferAngleSpectralDerivative a lam t x s) t := by
  have hi := spectralInnerAngle_hasDerivAt (coupling_sine_abs_lt_one hlam hlam1 x) t s
  have ho := positiveAngleLift_hasDerivAt (diagonalFactor a)
    (spectralInnerAngle (lam*Real.sin x) t s) (diagonalFactor_radial_pos ha _)
  have h := ho.comp t hi
  simpa only [diagonalFactor_det ha.ne',one_div,realTransferAngleSpectralDerivative,
    realTransferAngleLift,spectralInnerAngle] using h

theorem realTransferAngleLift_spectral_strictMono {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (x s : ℝ) :
    StrictMono (fun t => realTransferAngleLift a lam t x s) :=
  strictMono_of_hasDerivAt_pos (fun t => realTransferAngleLift_spectral_hasDerivAt ha hlam hlam1 t x s)
    (fun t => realTransferAngleSpectralDerivative_pos ha hlam hlam1 t x s)

end UAMO.ProjectiveAngle

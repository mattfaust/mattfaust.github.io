import UAMO.ReflectionMoments
import UAMO.MatrixTrace
import Mathlib.LinearAlgebra.Matrix.Unique

noncomputable section
namespace UAMO
open scoped Matrix
open PhysicalWalk

section CStar
variable {A : Type*} [CStarAlgebra A] [PartialOrder A] [StarOrderedRing A]

def matrixReflectionDiscriminant (C D : Column A) : CStarMatrix (Fin 2) (Fin 2) A :=
  CStarMatrix.ofMatrix (reflection C * reflection D + reflection D * reflection C)

def scalarOverlapDiscriminant (C D : Column A) : A := overlapDiscriminant C D 0 0

omit [PartialOrder A] [StarOrderedRing A] in
theorem matrixReflectionDiscriminant_selfAdjoint (C D : Column A) :
    IsSelfAdjoint (matrixReflectionDiscriminant C D) := by
  change star (reflection C * reflection D + reflection D * reflection C) = _
  rw [star_add, star_mul, star_mul, reflection_selfAdjoint, reflection_selfAdjoint]
  exact add_comm _ _

omit [PartialOrder A] [StarOrderedRing A] in
theorem scalarOverlapDiscriminant_selfAdjoint (C D : Column A) :
    IsSelfAdjoint (scalarOverlapDiscriminant C D) := by
  rw [scalarOverlapDiscriminant, overlapDiscriminant_entry]
  simp [IsSelfAdjoint, star_sub, star_smul, star_mul]

theorem matrixReflectionDiscriminant_moments (τ : A →L[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (C D : Column A) (hC : Cᴴ * C = 1) (hD : Dᴴ * D = 1) (n : ℕ) :
    normalizedMatrixTrace₂ τ (matrixReflectionDiscriminant C D ^ n) =
      τ (scalarOverlapDiscriminant C D ^ n) := by
  have htrace (M : TwoByTwo A) :
      normalizedMatrixTrace₂ τ (CStarMatrix.ofMatrix M) =
        matrixTraceTwoLinear τ.toLinearMap M := by
    rw [normalizedMatrixTrace₂_apply, matrixTraceTwoLinear_apply]
    rfl
  change normalizedMatrixTrace₂ τ
    (CStarMatrix.ofMatrix ((reflection C * reflection D + reflection D * reflection C) ^ n)) = _
  have hp : (overlapDiscriminant C D ^ n) 0 0 = (overlapDiscriminant C D 0 0) ^ n :=
    map_pow (Matrix.uniqueRingEquiv : Matrix (Fin 1) (Fin 1) A ≃+* A) _ n
  rw [htrace, reflection_overlap_trace_moments τ.toLinearMap hτ C D hC hD n,
    hp]
  rfl

end CStar
end UAMO

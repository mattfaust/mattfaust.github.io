import UAMO.ReflectionOverlap
import Mathlib.LinearAlgebra.Matrix.Trace

namespace UAMO
noncomputable section
open scoped Matrix
open PhysicalWalk
variable {A : Type*} [Ring A] [Algebra ℂ A]

def matrixTraceTwoLinear (τ : A →ₗ[ℂ] ℂ) : TwoByTwo A →ₗ[ℂ] ℂ :=
  (1 / 2 : ℂ) • τ.comp (Matrix.traceLinearMap (Fin 2) ℂ A)

@[simp] theorem matrixTraceTwoLinear_apply (τ : A →ₗ[ℂ] ℂ) (M : TwoByTwo A) :
    matrixTraceTwoLinear τ M = (τ (M 0 0) + τ (M 1 1)) / 2 := by
  simp [matrixTraceTwoLinear, Matrix.trace, Matrix.diag, Fin.sum_univ_two, div_eq_mul_inv]
  ring

theorem matrixTraceTwoLinear_cyclic (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X)) (M N : TwoByTwo A) :
    matrixTraceTwoLinear τ (M * N) = matrixTraceTwoLinear τ (N * M) := by
  simp only [matrixTraceTwoLinear_apply, Matrix.mul_apply, Fin.sum_univ_two, map_add]
  rw [hτ (M 0 0) (N 0 0), hτ (M 0 1) (N 1 0),
    hτ (M 1 0) (N 0 1), hτ (M 1 1) (N 1 1)]
  ring

theorem matrixTraceTwoLinear_rectangular (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (C : Column A) (B : Matrix (Fin 1) (Fin 2) A) :
    matrixTraceTwoLinear τ (C * B) = τ ((B * C) 0 0) / 2 := by
  simp only [matrixTraceTwoLinear_apply, Matrix.mul_apply, Fin.sum_univ_one,
    Fin.sum_univ_two, map_add]
  rw [hτ (C 0 0) (B 0 0), hτ (C 1 0) (B 0 1)]

variable [StarRing A]

theorem matrixTraceTwoLinear_corner (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (C : Column A) (hC : Cᴴ * C = 1) (B : Matrix (Fin 1) (Fin 1) A) :
    matrixTraceTwoLinear τ (C * B * Cᴴ) = τ (B 0 0) / 2 := by
  rw [Matrix.mul_assoc, matrixTraceTwoLinear_rectangular τ hτ,
    Matrix.mul_assoc, hC, Matrix.mul_one]

theorem matrixTraceTwoLinear_projection (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (C : Column A) (hC : Cᴴ * C = 1) :
    matrixTraceTwoLinear τ (C * Cᴴ) = τ 1 / 2 := by
  rw [matrixTraceTwoLinear_rectangular τ hτ, hC, Matrix.one_apply_eq]

theorem matrixTraceTwoLinear_reflection (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (C : Column A) (hC : Cᴴ * C = 1) :
    matrixTraceTwoLinear τ (reflection C) = 0 := by
  simp only [reflection, map_sub, map_smul, smul_eq_mul,
    matrixTraceTwoLinear_projection τ hτ C hC]
  simp [matrixTraceTwoLinear_apply]
  ring

theorem reflection_projection_eq (C : Column A) :
    (1 / 2 : ℂ) • (1 + reflection C) = C * Cᴴ := by
  simp [reflection, smul_sub, smul_add, smul_smul]

theorem reflection_overlap_trace_moments (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (C D : Column A) (hC : Cᴴ * C = 1) (hD : Dᴴ * D = 1) (n : ℕ) :
    matrixTraceTwoLinear τ
        ((reflection C * reflection D + reflection D * reflection C) ^ n) =
      τ ((overlapDiscriminant C D ^ n) 0 0) := by
  let Z := reflection C * reflection D + reflection D * reflection C
  have hm := reflection_projection_trace_moments (matrixTraceTwoLinear τ)
    (matrixTraceTwoLinear_cyclic τ hτ) (reflection C) (reflection D)
    (reflection_square C hC) (reflection_square D hD)
    (matrixTraceTwoLinear_reflection τ hτ C hC)
    (matrixTraceTwoLinear_reflection τ hτ D hD) n
  rw [reflection_projection_eq] at hm
  change matrixTraceTwoLinear τ ((C * Cᴴ) * Z ^ n) =
    (1 / 2 : ℂ) * matrixTraceTwoLinear τ (Z ^ n) at hm
  have hc : matrixTraceTwoLinear τ ((C * Cᴴ) * Z ^ n) =
      τ ((overlapDiscriminant C D ^ n) 0 0) / 2 := by
    rw [matrixTraceTwoLinear_cyclic τ hτ, ← Matrix.mul_assoc,
      reflection_discriminant_power_intertwines C D hC n,
      matrixTraceTwoLinear_corner τ hτ C hC]
  rw [hc] at hm
  linear_combination -2 * hm

end
end UAMO

import UAMO.ReflectionSpectrum
import UAMO.ReflectionTrace

noncomputable section
namespace UAMO
namespace PhysicalWalk
open scoped Matrix
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A]

theorem reflection_mul_column (C : Column A) (hC : Cᴴ * C = 1) :
    reflection C * C = C := by
  simp only [reflection, Matrix.sub_mul, Matrix.smul_mul, Matrix.mul_assoc,
    hC, Matrix.mul_one, Matrix.one_mul]
  module

def overlapDiscriminant (C D : Column A) : Matrix (Fin 1) (Fin 1) A :=
  (4 : ℂ) • ((Cᴴ * D) * (Dᴴ * C)) - (2 : ℂ) • 1

theorem reflection_discriminant_intertwines (C D : Column A) (hC : Cᴴ * C = 1) :
    (reflection C * reflection D + reflection D * reflection C) * C =
      C * overlapDiscriminant C D := by
  rw [Matrix.add_mul, Matrix.mul_assoc, Matrix.mul_assoc, reflection_mul_column C hC]
  simp only [reflection, overlapDiscriminant, Matrix.sub_mul, Matrix.mul_sub,
    Matrix.add_mul, Matrix.mul_add, Matrix.smul_mul, Matrix.mul_smul,
    Matrix.one_mul, Matrix.mul_one, Matrix.mul_assoc, hC, smul_add, smul_sub, smul_smul]
  module

theorem reflection_discriminant_power_intertwines (C D : Column A)
    (hC : Cᴴ * C = 1) (n : ℕ) :
    (reflection C * reflection D + reflection D * reflection C) ^ n * C =
      C * overlapDiscriminant C D ^ n := by
  induction n with
  | zero => simp
  | succ n hn =>
      rw [pow_succ', Matrix.mul_assoc, hn, ← Matrix.mul_assoc,
        reflection_discriminant_intertwines C D hC, Matrix.mul_assoc, ← pow_succ']

theorem overlapDiscriminant_entry (C D : Column A) :
    overlapDiscriminant C D 0 0 =
      (4 : ℂ) • (star ((Dᴴ * C) 0 0) * ((Dᴴ * C) 0 0)) - (2 : ℂ) • (1 : A) := by
  have hstar : (Cᴴ * D) 0 0 = star ((Dᴴ * C) 0 0) := by
    have h : (Dᴴ * C)ᴴ = Cᴴ * D := by simp
    simpa using (congrArg (fun M : Matrix (Fin 1) (Fin 1) A => M 0 0) h).symm
  simp [overlapDiscriminant, Matrix.mul_apply, hstar]

end PhysicalWalk
end UAMO

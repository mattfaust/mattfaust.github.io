import UAMO.ReflectionMatrix
import UAMO.ReflectionSpectrum
import UAMO.SpectralMomentCorrespondence

noncomputable section
namespace UAMO
open scoped Matrix
open PhysicalWalk SpectralMoments

local instance magneticMatrix_nontrivial (φ : ℝ) : Nontrivial (MagneticMatrixAlgebra φ) := by
  apply nontrivial_of_ne (0 : MagneticMatrixAlgebra φ) 1
  intro h
  have hh := congrArg (magneticMatrixTrace φ) h
  exact zero_ne_one (by simpa only [map_zero, magneticMatrixTrace_one] using hh)

local instance magneticAlgebra_nontrivial (φ : ℝ) : Nontrivial (magneticAlgebra φ) := by
  apply nontrivial_of_ne (0 : magneticAlgebra φ) 1
  intro h
  have hh := congrArg (magneticTrace φ) h
  exact zero_ne_one (by simpa only [map_zero, magneticTrace_one] using hh)

def magneticFaithfulState (φ : ℝ) : FaithfulTracialState (magneticAlgebra φ) where
  functional := magneticTraceReal φ
  normalized := magneticTraceReal_one φ
  positive := magneticTraceReal_star_mul_self_nonneg φ
  faithful := magneticTraceReal_faithful φ
  cyclic := magneticTraceReal_cyclic φ

def magneticMatrixFaithfulState (φ : ℝ) : FaithfulTracialState (MagneticMatrixAlgebra φ) where
  functional := magneticMatrixTraceReal φ
  normalized := magneticMatrixTraceReal_one φ
  positive := magneticMatrixTraceReal_star_mul_self_nonneg φ
  faithful := magneticMatrixTraceReal_faithful φ
  cyclic := magneticMatrixTraceReal_cyclic φ

theorem magnetic_reflection_overlap_moments (φ : ℝ)
    (C D : Column (magneticAlgebra φ)) (hC : Cᴴ * C = 1) (hD : Dᴴ * D = 1) (n : ℕ) :
    (magneticMatrixFaithfulState φ).functional (matrixReflectionDiscriminant C D ^ n) =
      (magneticFaithfulState φ).functional (scalarOverlapDiscriminant C D ^ n) :=
  congrArg Complex.re (matrixReflectionDiscriminant_moments
    (magneticTrace φ) (magneticTrace_cyclic φ) C D hC hD n)

theorem magnetic_reflection_overlap_measure (φ : ℝ)
    (C D : Column (magneticAlgebra φ)) (hC : Cᴴ * C = 1) (hD : Dᴴ * D = 1) :
    realSpectralMeasure (magneticMatrixFaithfulState φ)
      (matrixReflectionDiscriminant C D) (matrixReflectionDiscriminant_selfAdjoint C D) =
    realSpectralMeasure (magneticFaithfulState φ)
      (scalarOverlapDiscriminant C D) (scalarOverlapDiscriminant_selfAdjoint C D) :=
  realSpectralMeasure_eq_of_moments _ _ _ _ _ _
    (magnetic_reflection_overlap_moments φ C D hC hD)

theorem magnetic_reflection_overlap_spectrum (φ : ℝ)
    (C D : Column (magneticAlgebra φ)) (hC : Cᴴ * C = 1) (hD : Dᴴ * D = 1) :
    spectrum ℂ (matrixReflectionDiscriminant C D) =
      spectrum ℂ (scalarOverlapDiscriminant C D) :=
  spectrum_eq_of_moments _ _ _ _
    (matrixReflectionDiscriminant_selfAdjoint C D) (scalarOverlapDiscriminant_selfAdjoint C D)
    (magnetic_reflection_overlap_moments φ C D hC hD)

set_option maxHeartbeats 800000 in

theorem magnetic_reflection_product_overlap_spectrum (φ : ℝ)
    (C D : Column (magneticAlgebra φ)) (hC : Cᴴ * C = 1) (hD : Dᴴ * D = 1) (t : ℝ) :
    Complex.exp ((t : ℂ) * Complex.I) ∈ spectrum ℂ (reflection C * reflection D) ↔
      ((2 * Real.cos t : ℝ) : ℂ) ∈ spectrum ℂ (scalarOverlapDiscriminant C D) := by
  rw [reflection_product_unitCircle_spectrum _ _
    (reflection_square C hC) (reflection_square D hD) t]
  have heq := AlgEquiv.spectrum_eq (CStarMatrix.ofMatrixStarAlgEquiv (n := Fin 2)
    (A := magneticAlgebra φ))
    (reflection C * reflection D + reflection D * reflection C)
  change spectrum ℂ (matrixReflectionDiscriminant C D) = _ at heq
  rw [← heq, magnetic_reflection_overlap_spectrum φ C D hC hD]

end UAMO

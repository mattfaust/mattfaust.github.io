import UAMO.PhysicalWalk
import UAMO.PhysicalRepresentation
import Mathlib.Algebra.Algebra.Spectrum.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic

noncomputable section
namespace UAMO

section Algebra
variable {A : Type*} [Ring A] [Algebra ℂ A]

omit [Algebra ℂ A] in
theorem involution_isUnit (R : A) (hR : R * R = 1) : IsUnit R :=
  ⟨⟨R, R, hR, hR⟩, rfl⟩

theorem involution_pencil_conjugacy (R S : A) (hR : R * R = 1) (z : ℂ) :
    R * (algebraMap ℂ A z - R * S) * R = algebraMap ℂ A z - S * R := by
  rw [mul_sub, sub_mul]
  have hcentral : R * algebraMap ℂ A z * R = algebraMap ℂ A z := by
    rw [← Algebra.commutes z R, mul_assoc, hR, mul_one]
  rw [hcentral, ← mul_assoc R R S, hR, one_mul]

theorem involution_pencil_isUnit_iff (R S : A)
    (hR : R * R = 1) (hS : S * S = 1) (z : ℂ) :
    IsUnit (algebraMap ℂ A z - R * S) ↔ IsUnit (algebraMap ℂ A z - S * R) := by
  constructor
  · intro h
    rw [← involution_pencil_conjugacy R S hR z]
    exact ((involution_isUnit R hR).mul h).mul (involution_isUnit R hR)
  · intro h
    rw [← involution_pencil_conjugacy S R hS z]
    exact ((involution_isUnit S hS).mul h).mul (involution_isUnit S hS)

theorem reflection_discriminant_factorization (R S : A)
    (hR : R * R = 1) (hS : S * S = 1) (z : ℂ) (hz : z ≠ 0) :
    (algebraMap ℂ A z - R * S) * (algebraMap ℂ A z - S * R) =
      algebraMap ℂ A z * (algebraMap ℂ A (z + z⁻¹) - (R * S + S * R)) := by
  have hprod : (R * S) * (S * R) = 1 := by
    rw [mul_assoc, ← mul_assoc S S R, hS, one_mul, hR]
  have hzinv : algebraMap ℂ A z * algebraMap ℂ A z⁻¹ = 1 := by
    rw [← map_mul, mul_inv_cancel₀ hz, map_one]
  simp only [map_add, sub_mul, mul_sub, mul_add, hprod, hzinv]
  rw [← Algebra.commutes z (R * S)]
  abel

theorem reflection_product_spectrum_iff (R S : A)
    (hR : R * R = 1) (hS : S * S = 1) (z : ℂ) (hz : z ≠ 0) :
    z ∈ spectrum ℂ (R * S) ↔ z + z⁻¹ ∈ spectrum ℂ (R * S + S * R) := by
  rw [spectrum.mem_iff, spectrum.mem_iff, not_iff_not]
  have hprod : (R * S) * (S * R) = 1 := by
    rw [mul_assoc, ← mul_assoc S S R, hS, one_mul, hR]
  have hprod' : (S * R) * (R * S) = 1 := by
    rw [mul_assoc, ← mul_assoc R R S, hR, one_mul, hS]
  have hc : Commute (R * S) (S * R) := by
    show (R * S) * (S * R) = (S * R) * (R * S)
    rw [hprod, hprod']
  have hp : Commute (algebraMap ℂ A z - R * S) (algebraMap ℂ A z - S * R) :=
    (show Commute (algebraMap ℂ A z) _ from Algebra.commutes z _).sub_left
      ((show Commute (algebraMap ℂ A z) (R * S) from Algebra.commutes z _).symm.sub_right hc)
  have hzunit : IsUnit (algebraMap ℂ A z) :=
    (isUnit_iff_ne_zero.mpr hz).map (algebraMap ℂ A)
  constructor
  · intro h
    have hi := h.mul ((involution_pencil_isUnit_iff R S hR hS z).mp h)
    rw [reflection_discriminant_factorization R S hR hS z hz] at hi
    exact ((show Commute (algebraMap ℂ A z) _ from Algebra.commutes z _).isUnit_mul_iff.mp hi).2
  · intro h
    have hi := hzunit.mul h
    rw [← reflection_discriminant_factorization R S hR hS z hz] at hi
    exact (hp.isUnit_mul_iff.mp hi).1

theorem unitCircle_joukowski (t : ℝ) :
    Complex.exp ((t : ℂ) * Complex.I) +
      (Complex.exp ((t : ℂ) * Complex.I))⁻¹ = (2 * Real.cos t : ℝ) := by
  have hi : (Complex.exp ((t : ℂ) * Complex.I))⁻¹ =
      Complex.exp (-(t : ℂ) * Complex.I) := by
    rw [← Complex.exp_neg]
    congr 1
    ring
  rw [hi, Complex.exp_mul_I, Complex.exp_mul_I, Complex.cos_neg, Complex.sin_neg,
    ← Complex.ofReal_cos, ← Complex.ofReal_sin]
  push_cast
  ring

theorem reflection_product_unitCircle_spectrum (R S : A)
    (hR : R * R = 1) (hS : S * S = 1) (t : ℝ) :
    Complex.exp ((t : ℂ) * Complex.I) ∈ spectrum ℂ (R * S) ↔
      ((2 * Real.cos t : ℝ) : ℂ) ∈ spectrum ℂ (R * S + S * R) := by
  rw [reflection_product_spectrum_iff R S hR hS _ (Complex.exp_ne_zero _),
    unitCircle_joukowski]

end Algebra

section Physical
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]
open PhysicalWalk

end Physical

end UAMO

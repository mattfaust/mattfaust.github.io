import UAMO.ReflectionSpectrum
import Mathlib.LinearAlgebra.Trace

namespace UAMO
noncomputable section
variable {A : Type*} [Ring A] [Algebra ℂ A]

def reflectionDiscriminant (R S : A) : A := R * S + S * R

omit [Algebra ℂ A] in
theorem reflection_commutes_discriminant (R S : A) (hR : R * R = 1) :
    Commute R (reflectionDiscriminant R S) := by
  show R * (R * S + S * R) = (R * S + S * R) * R
  simp only [mul_add, add_mul, ← mul_assoc, hR, one_mul]
  rw [mul_assoc S R R, hR, mul_one]
  abel

theorem reflection_trace_step (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (R S : A) (hR : R * R = 1) (n : ℕ) :
    τ (R * reflectionDiscriminant R S ^ (n + 1)) =
      2 * τ (S * reflectionDiscriminant R S ^ n) := by
  let D := reflectionDiscriminant R S
  have hc : Commute R (D ^ n) := (reflection_commutes_discriminant R S hR).pow_right n
  have hRD : R * D = S + R * S * R := by
    simp only [D, reflectionDiscriminant, mul_add, ← mul_assoc, hR, one_mul]
  change τ (R * D ^ (n + 1)) = 2 * τ (S * D ^ n)
  calc
    _ = τ ((R * D) * D ^ n) := by rw [pow_succ']; simp [mul_assoc]
    _ = τ (S * D ^ n) + τ ((R * S * R) * D ^ n) := by rw [hRD, add_mul, map_add]
    _ = τ (S * D ^ n) + τ ((R * D ^ n) * (R * S)) := by
      congr 1
      rw [mul_assoc (R * S) R, hτ]
    _ = τ (S * D ^ n) + τ (D ^ n * S) := by
      rw [hc.eq]
      congr 2
      simp only [mul_assoc, ← mul_assoc R R S, hR, one_mul]
    _ = 2 * τ (S * D ^ n) := by rw [hτ (D ^ n) S]; ring

theorem reflection_trace_moments_zero (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (R S : A) (hR : R * R = 1) (hS : S * S = 1)
    (hτR : τ R = 0) (hτS : τ S = 0) (n : ℕ) :
    τ (R * reflectionDiscriminant R S ^ n) = 0 ∧
      τ (S * reflectionDiscriminant R S ^ n) = 0 := by
  have hswap : reflectionDiscriminant S R = reflectionDiscriminant R S := by
    simp [reflectionDiscriminant, add_comm]
  induction n with
  | zero => simpa using And.intro hτR hτS
  | succ n hn =>
      constructor
      · rw [reflection_trace_step τ hτ R S hR n, hn.2, mul_zero]
      · rw [← hswap, reflection_trace_step τ hτ S R hS n, hswap, hn.1, mul_zero]

theorem reflection_projection_trace_moments (τ : A →ₗ[ℂ] ℂ)
    (hτ : ∀ X Y, τ (X * Y) = τ (Y * X))
    (R S : A) (hR : R * R = 1) (hS : S * S = 1)
    (hτR : τ R = 0) (hτS : τ S = 0) (n : ℕ) :
    τ (((1 / 2 : ℂ) • (1 + R)) * reflectionDiscriminant R S ^ n) =
      (1 / 2 : ℂ) * τ (reflectionDiscriminant R S ^ n) := by
  simp only [smul_mul_assoc, add_mul, one_mul, map_smul, map_add, smul_eq_mul]
  rw [(reflection_trace_moments_zero τ hτ R S hR hS hτR hτS n).1, add_zero]

end
end UAMO

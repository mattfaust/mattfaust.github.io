import UAMO.MagneticStationarity
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.Calculus.FDeriv.Mul

noncomputable section
namespace UAMO
open scoped InnerProductSpace

section General
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]

theorem real_resolvent_isSelfAdjoint (H : E →L[ℂ] E) (hH : IsSelfAdjoint H) (m : ℝ) :
    IsSelfAdjoint (resolvent H (m : ℂ)) := by
  have hm : IsSelfAdjoint (m : ℂ) := Complex.conj_ofReal m
  have hshift : IsSelfAdjoint (algebraMap ℂ (E →L[ℂ] E) (m : ℂ) - H) :=
    (hm.algebraMap (E →L[ℂ] E)).sub hH
  change star (Ring.inverse (algebraMap ℂ (E →L[ℂ] E) (m : ℂ) - H)) =
    Ring.inverse (algebraMap ℂ (E →L[ℂ] E) (m : ℂ) - H)
  rw [← Ring.inverse_star, hshift.star_eq]

theorem actual_resolvent_column_hasDerivAt (H : E →L[ℂ] E) (root : E) (z : ℂ)
    (hz : z ∈ resolventSet ℂ H) :
    HasDerivAt (fun w => resolvent H w root) (-resolvent H z (resolvent H z root)) z := by
  have hd := (spectrum.hasDerivAt_resolvent hz).clm_apply (hasDerivAt_const z root)
  simpa only [pow_two, map_zero, add_zero, ContinuousLinearMap.mul_apply,
    ContinuousLinearMap.neg_apply] using hd

omit [CompleteSpace E] in
theorem actual_resolvent_column_ne_zero (H : E →L[ℂ] E) (root : E) (hroot : root ≠ 0)
    (z : ℂ) (hz : z ∈ resolventSet ℂ H) : resolvent H z root ≠ 0 := by
  intro hzero
  have h := cyclic_resolvent_left_identity H z hz root
  rw [hzero, smul_zero, map_zero, sub_zero] at h
  exact hroot h.symm

theorem actual_projectedGreen_hasDerivAt (H : E →L[ℂ] E) (hH : IsSelfAdjoint H)
    (root : E) (m : ℝ) (hm : (m : ℂ) ∈ resolventSet ℂ H) :
    HasDerivAt (fun z => ⟪root, resolvent H z root⟫_ℂ)
      ((-(‖resolvent H (m : ℂ) root‖ ^ 2) : ℝ) : ℂ) (m : ℂ) := by
  have hR := (real_resolvent_isSelfAdjoint H hH m).isSymmetric
  have hvalue : ⟪root, -resolvent H (m : ℂ) (resolvent H (m : ℂ) root)⟫_ℂ =
      ((-(‖resolvent H (m : ℂ) root‖ ^ 2) : ℝ) : ℂ) := by
    rw [inner_neg_right, ← hR.apply_clm, inner_self_eq_norm_sq_to_K]
    simp only [Complex.ofReal_neg, Complex.ofReal_pow]
    rfl
  have hd := (innerSL ℂ root).hasFDerivAt.comp_hasDerivAt (m : ℂ)
    (actual_resolvent_column_hasDerivAt H root (m : ℂ) hm)
  simpa only [Function.comp_def, innerSL_apply, hvalue] using hd

theorem real_resolvent_inner_im_zero (H : E →L[ℂ] E) (hH : IsSelfAdjoint H)
    (root : E) (m : ℝ) : (⟪root, resolvent H (m : ℂ) root⟫_ℂ).im = 0 := by
  have hs := (real_resolvent_isSelfAdjoint H hH m).isSymmetric.apply_clm root root
  have hi := congrArg Complex.im hs
  have hsym := inner_im_symm (𝕜 := ℂ) root (resolvent H (m : ℂ) root)
  change (⟪root, resolvent H (m : ℂ) root⟫_ℂ).im =
    -(⟪resolvent H (m : ℂ) root, root⟫_ℂ).im at hsym
  linarith

end General

def scalarGreen (a r φ E : ℝ) : ℝ :=
  (⟪magneticOrigin, resolvent (scalarHamiltonian a r φ) (E : ℂ) magneticOrigin⟫_ℂ).re

theorem scalarGreen_energy_hasDerivAt (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    HasDerivAt (scalarGreen a r φ)
      (-(‖resolvent (scalarHamiltonian a r φ) (E : ℂ) magneticOrigin‖ ^ 2)) E := by
  simpa only [scalarGreen, Complex.ofReal_re] using
    (actual_projectedGreen_hasDerivAt _ (scalarHamiltonian_selfAdjoint a r φ)
      magneticOrigin E hE).real_of_complex

theorem scalarGreen_energy_deriv_neg (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    deriv (scalarGreen a r φ) E < 0 := by
  rw [(scalarGreen_energy_hasDerivAt a r φ E hE).deriv]
  have hΩ : magneticOrigin ≠ 0 := by
    intro h
    have := magneticOrigin_norm
    rw [h, norm_zero] at this
    norm_num at this
  exact neg_neg_of_pos (sq_pos_of_pos (norm_pos_iff.mpr
    (actual_resolvent_column_ne_zero _ _ hΩ _ hE)))

theorem scalarGreen_eq_zero_iff (a r φ E : ℝ) :
    scalarGreen a r φ E = 0 ↔
      ⟪magneticOrigin, resolvent (scalarHamiltonian a r φ) (E : ℂ) magneticOrigin⟫_ℂ = 0 := by
  constructor
  · intro h
    apply Complex.ext
    · exact h
    · simpa only [Complex.zero_im] using
        real_resolvent_inner_im_zero _ (scalarHamiltonian_selfAdjoint a r φ) magneticOrigin E
  · intro h
    exact congrArg Complex.re h

end UAMO

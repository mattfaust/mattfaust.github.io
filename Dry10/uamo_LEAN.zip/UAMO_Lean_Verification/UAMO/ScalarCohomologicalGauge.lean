import UAMO.PhysicalProfileFourierGenerators
import UAMO.SeedCoefficient
import Mathlib.Analysis.SpecialFunctions.Exponential

noncomputable section
namespace UAMO.ScalarGauge
open scoped BigOperators ComplexConjugate
open UAMO.ProfileFourier
attribute [local instance] Real.fact_zero_lt_one

def mode (k : ℤ) (z : ℂ) : ℂ :=
  Complex.exp (2*Real.pi*Complex.I*(k:ℂ)*z)

theorem mode_real (k : ℤ) (x : ℝ) :
    mode k (x:ℂ)=fourier k (x:ProfileCircle) := by
  simp only [mode,fourier_coe_apply,Complex.ofReal_one,div_one]

theorem mode_add (k : ℤ) (z w : ℂ) : mode k (z+w)=mode k z*mode k w := by
  simp only [mode,mul_add,Complex.exp_add]

theorem mode_zero (z : ℂ) : mode 0 z=1 := by simp [mode]

theorem mode_neg_real (k : ℤ) (x : ℝ) : mode (-k) (x:ℂ)=conj (mode k (x:ℂ)) := by
  simp only [mode_real,fourier_neg]

theorem mode_eq_weyl_zpow (k : ℤ) (x : ℝ) : mode k (x:ℂ)=weylPhase x^k := by
  rw [mode,weylPhase_zpow]
  congr 1
  push_cast
  ring

def divisor (α : ℝ) (k : ℤ) : ℂ := mode k (α:ℂ)-1

theorem divisor_ne_zero {α : ℝ} (hα : Irrational α) {k : ℤ} (hk : k≠0) :
    divisor α k≠0 := by
  rw [divisor,sub_ne_zero,mode_eq_weyl_zpow]
  exact weylPhase_noIntegerResonance hα k hk

theorem divisor_neg (α : ℝ) (k : ℤ) : divisor α (-k)=conj (divisor α k) := by
  simp only [divisor,mode_neg_real,map_sub,map_one]

def finiteFourier (S : Finset ℤ) (c : ℤ→ℂ) (z : ℂ) : ℂ := ∑ k∈S,c k*mode k z

def finitePotential (S : Finset ℤ) (α : ℝ) (c : ℤ→ℂ) (z : ℂ) : ℂ :=
  finiteFourier S (fun k => c k/divisor α k) z

theorem finitePotential_translation (S : Finset ℤ) (α : ℝ) (c : ℤ→ℂ)
    (hS : ∀k∈S,divisor α k≠0) (z : ℂ) :
    finitePotential S α c (z+α)-finitePotential S α c z=finiteFourier S c z := by
  simp only [finitePotential,finiteFourier,← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro k hk
  rw [mode_add]
  have hd := hS k hk
  dsimp only [divisor] at hd
  dsimp only [divisor]
  field_simp
  ring

theorem finitePotential_translation_irrational (S : Finset ℤ) {α : ℝ}
    (hα : Irrational α) (c : ℤ→ℂ) (hS : 0∉S) (z : ℂ) :
    finitePotential S α c (z+α)-finitePotential S α c z=finiteFourier S c z := by
  apply finitePotential_translation
  intro k hk
  exact divisor_ne_zero hα (fun he => hS (he ▸ hk))

theorem finiteFourier_conj (S : Finset ℤ) (c : ℤ→ℂ)
    (hS : ∀k,k∈S ↔ -k∈S) (hc : ∀k,c (-k)=conj (c k)) (x : ℝ) :
    conj (finiteFourier S c (x:ℂ))=finiteFourier S c (x:ℂ) := by
  simp only [finiteFourier,map_sum,map_mul,← hc,← mode_neg_real]
  apply Finset.sum_bij (fun k _ => -k)
  · intro k hk; exact (hS k).mp hk
  · intro k hk j hj he; omega
  · intro k hk; exact ⟨-k,(hS k).mp hk,neg_neg k⟩
  · intro k hk; rfl

theorem finitePotential_conj (S : Finset ℤ) (α : ℝ) (c : ℤ→ℂ)
    (hS : ∀k,k∈S ↔ -k∈S) (hc : ∀k,c (-k)=conj (c k)) (x : ℝ) :
    conj (finitePotential S α c (x:ℂ))=finitePotential S α c (x:ℂ) := by
  apply finiteFourier_conj S _ hS
  intro k
  rw [hc,divisor_neg,map_div₀]

theorem finitePotential_im_zero (S : Finset ℤ) (α : ℝ) (c : ℤ→ℂ)
    (hS : ∀k,k∈S ↔ -k∈S) (hc : ∀k,c (-k)=conj (c k)) (x : ℝ) :
    (finitePotential S α c (x:ℂ)).im=0 := by
  have h := congrArg Complex.im (finitePotential_conj S α c hS hc x)
  simp only [Complex.conj_im] at h
  linarith

def halfModes (Q : ℕ) : Finset ℤ :=
  (Finset.Icc (-(Q:ℤ)) Q).filter (fun k => k≠0 ∧ 2*k.natAbs<Q)

theorem mem_halfModes (Q : ℕ) (k : ℤ) : k∈halfModes Q ↔ k≠0 ∧ 2*k.natAbs<Q := by
  simp only [halfModes,Finset.mem_filter,Finset.mem_Icc]
  constructor
  · exact fun h => h.2
  · intro h
    exact ⟨by omega,h⟩

theorem zero_not_mem_halfModes (Q : ℕ) : 0∉halfModes Q := by
  simp only [mem_halfModes,ne_eq,not_true_eq_false,false_and,not_false_eq_true]

theorem halfModes_neg (Q : ℕ) (k : ℤ) : k∈halfModes Q ↔ -k∈halfModes Q := by
  simp only [mem_halfModes,neg_ne_zero,Int.natAbs_neg]

def gaugePotential (Q : ℕ) (α : ℝ) (c : ℤ→ℂ) : ℂ→ℂ := finitePotential (halfModes Q) α c

theorem gaugePotential_translation (Q : ℕ) {α : ℝ} (hα : Irrational α)
    (c : ℤ→ℂ) (z : ℂ) :
    gaugePotential Q α c (z+α)-gaugePotential Q α c z=finiteFourier (halfModes Q) c z :=
  finitePotential_translation_irrational _ hα c (zero_not_mem_halfModes Q) z

theorem gaugePotential_real (Q : ℕ) (α : ℝ) (c : ℤ→ℂ)
    (hc : ∀k,c (-k)=conj (c k)) (x : ℝ) : (gaugePotential Q α c (x:ℂ)).im=0 :=
  finitePotential_im_zero _ α c (halfModes_neg Q) hc x

end UAMO.ScalarGauge

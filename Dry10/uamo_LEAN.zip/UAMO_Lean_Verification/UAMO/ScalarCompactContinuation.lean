import UAMO.CenteredEnergyBounds
import UAMO.ScalarContinuationLimit
import Mathlib.Topology.Sequences

noncomputable section
namespace UAMO
open Filter Set
open scoped Topology

theorem scalar_centered_energies_have_convergent_subsequence
    (a φ : ℝ) (r energy : ℕ → ℝ)
    (hr : ∀ n, r n ∈ Icc (0 : ℝ) 1)
    (hres : ∀ n, (energy n : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a (r n) φ))
    (hzero : ∀ n, scalarGreen a (r n) φ (energy n) = 0) :
    ∃ E ∈ Icc (-(4 + 2 * (|a|⁻¹ + |a|))) (4 + 2 * (|a|⁻¹ + |a|)),
      ∃ s : ℕ → ℕ, StrictMono s ∧ Tendsto (energy ∘ s) atTop (𝓝 E) :=
  isCompact_Icc.isSeqCompact fun n =>
    scalarGreen_zero_energy_mem_Icc a (r n) φ (energy n)
      (hr n).1 (hr n).2 (hres n) (hzero n)

theorem scalar_positive_stationary_sequence_noncollapse
    (a φ rlim seed : ℝ) (r energy : ℕ → ℝ)
    (hr : ∀ n, r n ∈ Icc (0 : ℝ) 1)
    (hrlim : Tendsto r atTop (𝓝 rlim)) (hseed : 0 < seed)
    (hres : ∀ n, (energy n : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a (r n) φ))
    (hzero : ∀ n, scalarGreen a (r n) φ (energy n) = 0)
    (hlower : ∀ n, seed ≤ scalarLogPotential a (r n) φ (energy n))
    (hbaseline : ∀ E : ℝ, (E : ℂ) ∈ spectrum ℂ (scalarHamiltonian a rlim φ) →
      scalarTotalLogPotential a φ (rlim,E) = 0) :
    ∃ E : ℝ, ∃ s : ℕ → ℕ, StrictMono s ∧
      Tendsto (fun n => (r (s n),energy (s n))) atTop (𝓝 (rlim,E)) ∧
      (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a rlim φ) ∧
      scalarGreen a rlim φ E = 0 := by
  obtain ⟨E,_,s,hs,hE⟩ :=
    scalar_centered_energies_have_convergent_subsequence a φ r energy hr hres hzero
  have hp : Tendsto (fun n => (r (s n),energy (s n))) atTop (𝓝 (rlim,E)) :=
    (hrlim.comp hs.tendsto_atTop).prodMk_nhds hE
  have hlim := scalar_positive_height_limit_centered a φ
    (fun n => (r (s n),energy (s n))) (rlim,E) seed hseed hp
    (Eventually.of_forall fun n => hres (s n))
    (Eventually.of_forall fun n => hlower (s n))
    (Eventually.of_forall fun n => hzero (s n)) (hbaseline E)
  exact ⟨E,s,hs,hp,hlim⟩

end UAMO

import UAMO.LogPotentialExtension
import UAMO.GapHeight

noncomputable section
namespace UAMO
open Filter Set
open scoped Topology

theorem scalar_positive_height_limit_resolvent
    (a φ : ℝ) (points : ℕ → ℝ × ℝ) (limit : ℝ × ℝ) (seed : ℝ)
    (hseed : 0 < seed) (hlimit : Tendsto points atTop (𝓝 limit))
    (hres : ∀ᶠ n in atTop,
      ((points n).2 : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a (points n).1 φ))
    (hlower : ∀ᶠ n in atTop, seed ≤ scalarLogPotential a (points n).1 φ (points n).2)
    (hbaseline : (limit.2 : ℂ) ∈ spectrum ℂ (scalarHamiltonian a limit.1 φ) →
      scalarTotalLogPotential a φ limit = 0) :
    (limit.2 : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a limit.1 φ) := by
  have hlower' : ∀ᶠ n in atTop, seed ≤ scalarPositiveLogPotential a φ (points n) := by
    filter_upwards [hres, hlower] with n hn hl
    rw [show points n = ((points n).1, (points n).2) from rfl,
      scalarPositiveLogPotential_eq_max a φ (points n).1 (points n).2 hn]
    exact hl.trans (le_max_right _ _)
  have hbound := ((scalarPositiveLogPotential_upperSemicontinuous a φ).isClosed_preimage
    seed).mem_of_tendsto hlimit hlower'
  change seed ≤ scalarPositiveLogPotential a φ limit at hbound
  apply spectrum.not_mem_iff.mp
  intro hs
  rw [scalarPositiveLogPotential_eq_zero_of_total_eq_zero a φ limit (hbaseline hs)] at hbound
  exact (not_le_of_gt hseed) hbound

theorem scalar_positive_height_limit_centered
    (a φ : ℝ) (points : ℕ → ℝ × ℝ) (limit : ℝ × ℝ) (seed : ℝ)
    (hseed : 0 < seed) (hlimit : Tendsto points atTop (𝓝 limit))
    (hres : ∀ᶠ n in atTop,
      ((points n).2 : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a (points n).1 φ))
    (hlower : ∀ᶠ n in atTop, seed ≤ scalarLogPotential a (points n).1 φ (points n).2)
    (hzero : ∀ᶠ n in atTop, scalarGreen a (points n).1 φ (points n).2 = 0)
    (hbaseline : (limit.2 : ℂ) ∈ spectrum ℂ (scalarHamiltonian a limit.1 φ) →
      scalarTotalLogPotential a φ limit = 0) :
    (limit.2 : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a limit.1 φ) ∧
      scalarGreen a limit.1 φ limit.2 = 0 := by
  have hr := scalar_positive_height_limit_resolvent a φ points limit seed
    hseed hlimit hres hlower hbaseline
  refine ⟨hr, ?_⟩
  have hc := (scalarJointGreen_contDiffAt a φ limit hr).continuousAt.tendsto.comp hlimit
  have hz : Tendsto (fun n => scalarJointGreen a φ (points n)) atTop (𝓝 0) :=
    tendsto_const_nhds.congr' (hzero.mono fun _ h => h.symm)
  exact tendsto_nhds_unique hc hz

end UAMO

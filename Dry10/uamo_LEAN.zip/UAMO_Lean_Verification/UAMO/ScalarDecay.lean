import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Tactic

noncomputable section
namespace UAMO.Wronskian

def decay (a : ℝ) (n : ℤ) : ℝ := Real.exp (-a * |(n : ℝ)|)

def decayMass (a : ℝ) : ℝ := ∑' n : ℤ, decay a n

theorem decay_summable {a : ℝ} (ha : 0 < a) : Summable (decay a) := by
  have h := Real.summable_exp_nat_mul_iff.mpr (neg_lt_zero.mpr ha)
  apply summable_int_iff_summable_nat_and_neg.mpr
  constructor <;>
    simpa [decay, abs_of_nonneg (Nat.cast_nonneg _ : (0 : ℝ) ≤ _), mul_comm] using h

end UAMO.Wronskian

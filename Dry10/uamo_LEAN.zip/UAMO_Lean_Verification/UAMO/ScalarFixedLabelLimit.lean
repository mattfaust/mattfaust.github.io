import UAMO.ScalarCompactContinuation
import UAMO.GapProjectionTrace
import UAMO.PhysicalDOSLabels

noncomputable section
namespace UAMO
open Filter Set MeasureTheory
open scoped Topology

theorem scalar_positive_height_lower_at_limit (a φ : ℝ)
    (points : ℕ→ℝ×ℝ) (limit : ℝ×ℝ) {seed : ℝ} (hseed : 0<seed)
    (hp : Tendsto points atTop (𝓝 limit))
    (hres : ∀ n,((points n).2 : ℂ)∈resolventSet ℂ (scalarHamiltonian a (points n).1 φ))
    (hlower : ∀ n,seed≤scalarLogPotential a (points n).1 φ (points n).2)
    (hlimres : (limit.2 : ℂ)∈resolventSet ℂ (scalarHamiltonian a limit.1 φ)) :
    seed≤scalarLogPotential a limit.1 φ limit.2 := by
  have h := ((scalarPositiveLogPotential_upperSemicontinuous a φ).isClosed_preimage
    seed).mem_of_tendsto hp
    (Eventually.of_forall fun n => by
      change seed ≤ scalarPositiveLogPotential a φ (points n)
      rw [show points n=((points n).1,(points n).2) by rfl,
        scalarPositiveLogPotential_eq_max a φ _ _ (hres n)]
      exact (hlower n).trans (le_max_right _ _))
  change seed ≤ scalarPositiveLogPotential a φ limit at h
  rw [show limit=(limit.1,limit.2) by rfl,
    scalarPositiveLogPotential_eq_max a φ _ _ hlimres] at h
  rcases le_max_iff.mp h with h | h
  · exact False.elim ((not_le_of_gt hseed) h)
  · exact h

theorem scalarIDS_eq_at_joint_resolvent_limit (a φ : ℝ) (ha : a≠0)
    (points : ℕ→ℝ×ℝ) (limit : ℝ×ℝ) (label : ℝ)
    (hp : Tendsto points atTop (𝓝 limit))
    (hlimres : (limit.2 : ℂ)∈resolventSet ℂ (scalarHamiltonian a limit.1 φ))
    (hlabel : ∀ n,scalarIDS a (points n).1 φ (points n).2=label) :
    scalarIDS a limit.1 φ limit.2=label := by
  have h3 : Tendsto (fun n => ((a,(points n).1),(points n).2))
      atTop (𝓝 ((a,limit.1),limit.2)) :=
    (tendsto_const_nhds.prodMk_nhds ((continuous_fst.tendsto limit).comp hp)).prodMk_nhds
      ((continuous_snd.tendsto limit).comp hp)
  have he := h3.eventually (scalarLowerSpectralMass_eventually_eq a limit.1 φ limit.2 ha hlimres)
  obtain ⟨n,hn⟩ := he.exists
  exact hn.symm.trans (hlabel n)

theorem scalar_positive_fixed_label_sequence_limit (a φ rlim seed label : ℝ)
    (ha : a≠0) (r energy : ℕ→ℝ) (hr : ∀ n,r n∈Icc (0 : ℝ) 1)
    (hrlim : Tendsto r atTop (𝓝 rlim)) (hseed : 0<seed)
    (hres : ∀ n,(energy n : ℂ)∈resolventSet ℂ (scalarHamiltonian a (r n) φ))
    (hzero : ∀ n,scalarGreen a (r n) φ (energy n)=0)
    (hlower : ∀ n,seed≤scalarLogPotential a (r n) φ (energy n))
    (hlabel : ∀ n,scalarIDS a (r n) φ (energy n)=label)
    (hbaseline : ∀ E : ℝ,(E : ℂ)∈spectrum ℂ (scalarHamiltonian a rlim φ) →
      scalarTotalLogPotential a φ (rlim,E)=0) :
    ∃ E : ℝ,(E : ℂ)∈resolventSet ℂ (scalarHamiltonian a rlim φ) ∧
      scalarGreen a rlim φ E=0 ∧ seed≤scalarLogPotential a rlim φ E ∧
      scalarIDS a rlim φ E=label := by
  obtain ⟨E,s,_,hp,hE,hg⟩ := scalar_positive_stationary_sequence_noncollapse
    a φ rlim seed r energy hr hrlim hseed hres hzero hlower hbaseline
  refine ⟨E,hE,hg,?_,?_⟩
  · exact scalar_positive_height_lower_at_limit a φ
      (fun n => (r (s n),energy (s n))) (rlim,E) hseed hp
      (fun n => hres (s n)) (fun n => hlower (s n)) hE
  · exact scalarIDS_eq_at_joint_resolvent_limit a φ ha
      (fun n => (r (s n),energy (s n))) (rlim,E) label hp hE
      (fun n => hlabel (s n))

end UAMO

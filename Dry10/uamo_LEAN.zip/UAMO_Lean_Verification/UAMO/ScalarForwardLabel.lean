import UAMO.GapHeight
import UAMO.GapProjectionTrace
import UAMO.PhysicalDOSLabels

noncomputable section
namespace UAMO
open Set Filter
open scoped Topology

theorem scalar_fixed_label_forward_extension (a α r E : ℝ) (ha : a≠0)
    (hα : Irrational α) (hr : 0<r)
    (hE : (E : ℂ)∈resolventSet ℂ (scalarHamiltonian a r (Real.pi*α)))
    (hg : scalarGreen a r (Real.pi*α) E=0) :
    ∃ ε>0,∀ t∈Icc r (r+ε),∃ F : ℝ,
      (F : ℂ)∈resolventSet ℂ (scalarHamiltonian a t (Real.pi*α)) ∧
      scalarGreen a t (Real.pi*α) F=0 ∧
      scalarLogPotential a r (Real.pi*α) E≤scalarLogPotential a t (Real.pi*α) F ∧
      scalarIDS a t (Real.pi*α) F=scalarIDS a r (Real.pi*α) E := by
  obtain ⟨s,e,d,hs,hrs,he,hbranch⟩ := scalar_local_gap_height_branch a r α E hα hE hg
  have hc : ContinuousAt e r := (hbranch r hrs).2.2.1.continuousAt
  have htend : Tendsto (fun t : ℝ => ((a,t),e t)) (𝓝 r) (𝓝 ((a,r),E)) := by
    have hcont : ContinuousAt (fun t : ℝ => ((a,t),e t)) r :=
      ((show ContinuousAt (fun _ : ℝ => a) r from continuousAt_const).prodMk continuousAt_id).prodMk hc
    simpa only [he] using hcont.tendsto
  have hlabel : ∀ᶠ t in 𝓝 r,scalarIDS a t (Real.pi*α) (e t)=scalarIDS a r (Real.pi*α) E :=
    htend.eventually (scalarLowerSpectralMass_eventually_eq a r (Real.pi*α) E ha hE)
  have hn : ∀ᶠ t in 𝓝 r,t∈s ∧ scalarIDS a t (Real.pi*α) (e t)=scalarIDS a r (Real.pi*α) E :=
    by filter_upwards [hs.mem_nhds hrs,hlabel] with t ht hl; exact ⟨ht,hl⟩
  obtain ⟨δ,hδ,hball⟩ := Metric.mem_nhds_iff.mp hn
  have hI : Icc r (r+δ/2)⊆s := by
    intro t ht
    apply (hball ?_).1
    rw [Metric.mem_ball,Real.dist_eq,abs_of_nonneg (by linarith [ht.1] : 0≤t-r)]
    linarith [ht.2]
  refine ⟨δ/2,by positivity,?_⟩
  intro t ht
  have htS := hI ht
  have hIt : Icc r t⊆s := fun u hu => hI ⟨hu.1,hu.2.trans ht.2⟩
  have hheight := scalar_gap_height_bounds_on_branch a α e d hs hα
    (fun u hu => (hbranch u hu).2.2.1)
    (fun u hu => (hbranch u hu).2.2.2.1.continuousWithinAt)
    (fun u hu => (hbranch u hu).1)
    (fun u hu => (hbranch u hu).2.1) hr ht.1 hIt
  have htl : scalarIDS a t (Real.pi*α) (e t)=scalarIDS a r (Real.pi*α) E := by
    apply (hball ?_).2
    rw [Metric.mem_ball,Real.dist_eq,abs_of_nonneg (by linarith [ht.1] : 0≤t-r)]
    linarith [ht.2]
  exact ⟨e t,(hbranch t htS).1,(hbranch t htS).2.1,by simpa only [he] using hheight.1,htl⟩

end UAMO

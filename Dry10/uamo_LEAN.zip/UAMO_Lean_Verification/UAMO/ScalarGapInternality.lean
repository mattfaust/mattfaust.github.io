import UAMO.GapProjectionTrace
import UAMO.PhysicalDOSLabels

noncomputable section
namespace UAMO
open Set MeasureTheory

theorem scalarIDS_pos_iff_spectrum_below (a r φ E : ℝ) :
    0 < scalarIDS a r φ E ↔
      ∃ l : ℝ, (l : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ∧ l < E := by
  constructor
  · intro hp
    by_contra hn
    have hsub : Iio E ⊆ {x : ℝ | (x : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)}ᶜ := by
      intro x hx hspec
      exact hn ⟨x,hspec,hx⟩
    have hz : scalarRealSpectralMeasure a r φ (Iio E) = 0 :=
      measure_mono_null hsub (scalarRealSpectralMeasure_spectrum_compl a r φ)
    simp only [scalarIDS, measureReal_def, hz, ENNReal.toReal_zero, lt_self_iff_false] at hp
  · rintro ⟨l,hl,hlE⟩
    have hb := scalarRealSpectralMeasure_ball_pos_of_mem a r φ l hl (sub_pos.mpr hlE)
    have hsub : Metric.ball l (E-l) ⊆ Iio E := by
      intro x hx
      have hx' : |x-l| < E-l := by simpa only [Metric.mem_ball, Real.dist_eq] using hx
      have h := (abs_lt.mp hx').2
      exact show x<E by linarith
    exact ENNReal.toReal_pos (ne_of_gt (hb.trans_le (measure_mono hsub))) (measure_ne_top _ _)

theorem scalarIDS_lt_one_iff_spectrum_above (a r φ E : ℝ)
    (hres : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    scalarIDS a r φ E < 1 ↔
      ∃ u : ℝ, (u : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ∧ E < u := by
  have hsum : scalarIDS a r φ E + (scalarRealSpectralMeasure a r φ).real (Ici E) = 1 := by
    simpa only [compl_Iio, measureReal_univ_eq_one, scalarIDS] using
      (measureReal_add_measureReal_compl (μ := scalarRealSpectralMeasure a r φ)
        (s := Iio E) measurableSet_Iio)
  constructor
  · intro hp
    by_contra hn
    have hsub : Ici E ⊆ {x : ℝ | (x : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)}ᶜ := by
      intro x hx hspec
      have hne : E ≠ x := by
        intro heq
        subst x
        exact hspec hres
      exact hn ⟨x,hspec,lt_of_le_of_ne hx hne⟩
    have hz : scalarRealSpectralMeasure a r φ (Ici E) = 0 :=
      measure_mono_null hsub (scalarRealSpectralMeasure_spectrum_compl a r φ)
    rw [measureReal_def, hz, ENNReal.toReal_zero, add_zero] at hsum
    linarith
  · rintro ⟨u,hu,hEu⟩
    have hb := scalarRealSpectralMeasure_ball_pos_of_mem a r φ u hu (sub_pos.mpr hEu)
    have hsub : Metric.ball u (u-E) ⊆ Ici E := by
      intro x hx
      have hx' : |x-u| < u-E := by simpa only [Metric.mem_ball, Real.dist_eq] using hx
      have h := (abs_lt.mp hx').1
      exact show E≤x by linarith
    have hp : 0 < (scalarRealSpectralMeasure a r φ).real (Ici E) :=
      ENNReal.toReal_pos (ne_of_gt (hb.trans_le (measure_mono hsub))) (measure_ne_top _ _)
    linarith

theorem scalar_internal_resolvent_iff_IDS (a r φ E : ℝ)
    (hres : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    (∃ l u : ℝ, (l : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ∧
      (u : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ∧ l < E ∧ E < u) ↔
    scalarIDS a r φ E ∈ Ioo (0 : ℝ) 1 := by
  constructor
  · rintro ⟨l,u,hl,hu,hlE,hEu⟩
    exact ⟨(scalarIDS_pos_iff_spectrum_below a r φ E).mpr ⟨l,hl,hlE⟩,
      (scalarIDS_lt_one_iff_spectrum_above a r φ E hres).mpr ⟨u,hu,hEu⟩⟩
  · intro h
    obtain ⟨l,hl,hlE⟩ := (scalarIDS_pos_iff_spectrum_below a r φ E).mp h.1
    obtain ⟨u,hu,hEu⟩ := (scalarIDS_lt_one_iff_spectrum_above a r φ E hres).mp h.2
    exact ⟨l,u,hl,hu,hlE,hEu⟩

end UAMO

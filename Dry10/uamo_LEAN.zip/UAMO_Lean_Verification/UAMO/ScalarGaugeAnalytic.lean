import UAMO.ScalarGaugeBounds
import Mathlib.Analysis.Complex.LocallyUniformLimit

noncomputable section
namespace UAMO.ScalarGauge
open scoped BigOperators ComplexConjugate
open UAMO.Wronskian UAMO.ProfileFourier

attribute [local instance] Real.fact_zero_lt_one

def openStrip (s : ℝ) : Set ℂ := {z | |z.im|<s}

theorem isOpen_openStrip (s : ℝ) : IsOpen (openStrip s) :=
  isOpen_lt (Complex.continuous_im.abs) continuous_const

theorem mode_differentiable (k : ℤ) : Differentiable ℂ (mode k) := by
  unfold mode
  fun_prop

theorem mode_one (k : ℤ) : mode k (1:ℂ)=1 := by
  rw [show (1:ℂ)=((1:ℝ):ℂ) from rfl,mode_real]
  have h : ((1:ℝ):ProfileCircle)=0 := AddCircle.coe_period 1
  rw [h,fourier_eval_zero]
  rfl

theorem mode_periodic (k : ℤ) (z : ℂ) : mode k (z+1)=mode k z := by
  rw [mode_add,mode_one,mul_one]

def fullPotential (α : ℝ) (c : ℤ→ℂ) : ℂ→ℂ :=
  fourierSeries (fun k => c k/divisor α k)

def SubexponentialDivisors (α : ℝ) : Prop :=
  ∀ε:ℝ,0<ε → ∃D:ℝ,0<D ∧ ∀k:ℤ,k≠0 → ‖(divisor α k)⁻¹‖≤D*Real.exp (ε*|(k:ℝ)|)

end UAMO.ScalarGauge

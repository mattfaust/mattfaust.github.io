import UAMO.ScalarCohomologicalGauge
import UAMO.ScalarDecay

noncomputable section
namespace UAMO.ScalarGauge
open scoped BigOperators
open UAMO.Wronskian

theorem mode_norm (k : ℤ) (z : ℂ) :
    ‖mode k z‖=Real.exp (-2*Real.pi*(k:ℝ)*z.im) := by
  rw [mode,Complex.norm_exp]
  congr 1
  simp [Complex.mul_re,Complex.mul_im]

theorem mode_strip_bound (k : ℤ) {z : ℂ} {s : ℝ} (hz : |z.im|≤s) :
    ‖mode k z‖≤Real.exp (2*Real.pi*|(k:ℝ)| *s) := by
  rw [mode_norm]
  apply Real.exp_le_exp.mpr
  have h0 := neg_le_abs ((k:ℝ)*z.im)
  rw [abs_mul] at h0
  have h1 := mul_le_mul_of_nonneg_left hz (abs_nonneg (k:ℝ))
  nlinarith [Real.pi_pos]

def ExponentialCoefficients (c : ℤ→ℂ) (A s b : ℝ) : Prop :=
  ∀k,‖c k‖≤A*Real.exp (-(2*Real.pi*s+2*b)*|(k:ℝ)|)

theorem weighted_mode_bound (c : ℤ→ℂ) {A s b : ℝ} (hA : 0≤A)
    (hc : ExponentialCoefficients c A s b) {z : ℂ} (hz : |z.im|≤s) (k : ℤ) :
    ‖c k*mode k z‖≤A*decay (2*b) k := by
  rw [norm_mul]
  calc
    _ ≤ (A*Real.exp (-(2*Real.pi*s+2*b)*|(k:ℝ)|))*
        Real.exp (2*Real.pi*|(k:ℝ)| *s) :=
      mul_le_mul (hc k) (mode_strip_bound k hz) (norm_nonneg _)
        (mul_nonneg hA (Real.exp_pos _).le)
    _ = _ := by
      rw [mul_assoc,← Real.exp_add]
      unfold decay
      congr 2
      ring

def fourierSeries (c : ℤ→ℂ) (z : ℂ) : ℂ := ∑'k:ℤ,c k*mode k z

theorem fourierSeries_summable (c : ℤ→ℂ) {A s b : ℝ}
    (hA : 0≤A) (hb : 0<b) (hc : ExponentialCoefficients c A s b)
    {z : ℂ} (hz : |z.im|≤s) : Summable (fun k:ℤ => c k*mode k z) := by
  exact Summable.of_norm_bounded _ ((decay_summable (a:=2*b) (by linarith)).mul_left A)
    (weighted_mode_bound c hA hc hz)

theorem fourierSeries_remainder (S : Finset ℤ) (c : ℤ→ℂ) {z : ℂ}
    (hs : Summable (fun k:ℤ => c k*mode k z)) :
    fourierSeries c z-finiteFourier S c z=∑'k:{k:ℤ // k∉S},c k*mode k z := by
  have h := hs.sum_add_tsum_subtype_compl S
  change finiteFourier S c z+_ = fourierSeries c z at h
  exact eq_sub_of_add_eq' h |>.symm

theorem halfModes_complement_abs (Q : ℕ) {k : ℤ} (hk : k≠0) (h : k∉halfModes Q) :
    (Q:ℝ)/2≤|(k:ℝ)| := by
  have hh : Q≤2*k.natAbs := by
    rw [mem_halfModes] at h
    omega
  have he : (k.natAbs:ℝ)=|(k:ℝ)| := by
    rw [← Int.cast_abs,← Int.natCast_natAbs k]
    rfl
  have hh' : (Q:ℝ)≤2*(k.natAbs:ℝ) := by exact_mod_cast hh
  rw [he] at hh'
  linarith

theorem fourierSeries_tail_bound (Q : ℕ) (c : ℤ→ℂ) {A s b : ℝ}
    (hA : 0≤A) (hb : 0<b) (hc : ExponentialCoefficients c A s b) (hc0 : c 0=0)
    {z : ℂ} (hz : |z.im|≤s) :
    ‖fourierSeries c z-finiteFourier (halfModes Q) c z‖≤
      A*decayMass b*Real.exp (-b*(Q:ℝ)/2) := by
  rw [fourierSeries_remainder _ c (fourierSeries_summable c hA hb hc hz)]
  have hsum := ((decay_summable hb).subtype {k:ℤ | k∉halfModes Q}).mul_left
    (A*Real.exp (-b*(Q:ℝ)/2))
  have hnorm (k : {k:ℤ // k∉halfModes Q}) :
      ‖c k*mode k z‖≤A*Real.exp (-b*(Q:ℝ)/2)*decay b k := by
    by_cases hk : (k:ℤ)=0
    · simp only [hk,hc0,zero_mul,norm_zero]
      simp only [decay,Int.cast_zero,abs_zero,mul_zero,Real.exp_zero,mul_one]
      positivity
    · have ha := halfModes_complement_abs Q hk k.property
      have hdec : decay (2*b) k≤Real.exp (-b*(Q:ℝ)/2)*decay b k := by
        unfold decay
        rw [← Real.exp_add]
        apply Real.exp_le_exp.mpr
        nlinarith
      exact (weighted_mode_bound c hA hc hz k).trans (by
        simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hdec hA)
  calc
    _ ≤ ∑'k:{k:ℤ // k∉halfModes Q},A*Real.exp (-b*(Q:ℝ)/2)*decay b k :=
      tsum_of_norm_bounded hsum.hasSum hnorm
    _ = (A*Real.exp (-b*(Q:ℝ)/2))*∑'k:{k:ℤ // k∉halfModes Q},decay b k :=
      tsum_mul_left
    _ ≤ (A*Real.exp (-b*(Q:ℝ)/2))*decayMass b := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact Summable.tsum_subtype_le (decay b) _ (fun k => (show 0 < decay b k from Real.exp_pos _).le) (decay_summable hb)
    _ = _ := by ring

end UAMO.ScalarGauge

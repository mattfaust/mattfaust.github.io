import Mathlib.NumberTheory.DiophantineApproximation.ContinuedFractions
import Mathlib.Algebra.ContinuedFractions.Computation.TerminatesIffRat

noncomputable section
namespace UAMO.ScalarGauge
open GenContFract

theorem continuedFraction_integral_contsAux (α : ℝ) (n : ℕ) :
    ∃p : GenContFract.Pair ℤ,(GenContFract.of α).contsAux n=p.map (fun k:ℤ => (k:ℝ)) := by
  induction n using Nat.strong_induction_on with
  | h n IH =>
    let g := GenContFract.of α
    rcases n with (_ | _ | n)
    · refine ⟨⟨1,0⟩,?_⟩
      simp [GenContFract.contsAux,GenContFract.Pair.map]
    · refine ⟨⟨⌊α⌋,1⟩,?_⟩
      simp [GenContFract.contsAux,GenContFract.Pair.map]
    · obtain ⟨pred,hpred⟩ := IH (n+1) (by omega)
      cases hs : g.s.get? n with
      | none =>
        refine ⟨pred,?_⟩
        have hh : g.contsAux (n+2)=g.contsAux (n+1) :=
          GenContFract.contsAux_stable_of_terminated (n+1).le_succ hs
        simpa only [g,hh] using hpred
      | some gp =>
        obtain ⟨prev,hprev⟩ := IH n (by omega)
        obtain ⟨ha,z,hb⟩ := GenContFract.of_partNum_eq_one_and_exists_int_partDen_eq hs
        simp only [g,ha,hb,GenContFract.contsAux_recurrence hs hprev hpred]
        refine ⟨⟨z*pred.a+prev.a,z*pred.b+prev.b⟩,?_⟩
        cases prev
        cases pred
        simp [GenContFract.nextConts,GenContFract.nextNum,GenContFract.nextDen,GenContFract.Pair.map]

theorem continuedFraction_integral_conts (α : ℝ) (n : ℕ) :
    ∃p : GenContFract.Pair ℤ,(GenContFract.of α).conts n=p.map (fun k:ℤ => (k:ℝ)) := by
  rw [GenContFract.nth_cont_eq_succ_nth_contAux]
  exact continuedFraction_integral_contsAux α (n+1)

theorem continuedFraction_den_ge_one (α : ℝ) (n : ℕ) :
    1≤(GenContFract.of α).dens n := by
  induction n with
  | zero => rw [GenContFract.zeroth_den_eq_one]
  | succ n ih => exact ih.trans GenContFract.of_den_mono

theorem convergent_den_le_continuant (α : ℝ) (n : ℕ) :
    ((α.convergent n).den:ℝ)≤(GenContFract.of α).dens n := by
  obtain ⟨⟨p,q⟩,hpq⟩ := continuedFraction_integral_conts α n
  have hp : (GenContFract.of α).nums n=(p:ℝ) := by
    simp only [GenContFract.num_eq_conts_a,hpq,GenContFract.Pair.map]
  have hq : (GenContFract.of α).dens n=(q:ℝ) := by
    simp only [GenContFract.den_eq_conts_b,hpq,GenContFract.Pair.map]
  have hqpos : 0<q := by
    have hh := continuedFraction_den_ge_one α n
    rw [hq] at hh
    have hh' : (0:ℝ)<q := by linarith
    exact_mod_cast hh'
  have hconv : α.convergent n=Rat.divInt p q := by
    apply Rat.cast_injective (α:=ℝ)
    rw [← Real.convs_eq_convergent,GenContFract.conv_eq_num_div_den,hp,hq,
      Rat.divInt_eq_div,Rat.cast_div,Rat.cast_intCast,Rat.cast_intCast]
  have hd := Rat.den_dvd p q
  have hle : ((Rat.divInt p q).den:ℤ)≤q := Int.le_of_dvd hqpos hd
  rw [hq,hconv]
  exact_mod_cast hle

theorem irrational_continuedFraction_not_terminated {α : ℝ} (hα : Irrational α) (n : ℕ) :
    ¬(GenContFract.of α).TerminatedAt n := by
  intro hn
  have ht : (GenContFract.of α).Terminates := ⟨n,hn⟩
  obtain ⟨R,hR⟩ := (GenContFract.terminates_iff_rat α).mp ht
  exact hα.ne_rat R hR

theorem convergent_quadratic_error {α : ℝ} (hα : Irrational α) (n : ℕ) :
    |α-(α.convergent n:ℝ)|≤1/((α.convergent n).den:ℝ)^2 := by
  have hh := GenContFract.abs_sub_convs_le (irrational_continuedFraction_not_terminated hα n)
  rw [Real.convs_eq_convergent] at hh
  apply hh.trans
  apply one_div_le_one_div_of_le (by positivity)
  rw [pow_two]
  exact mul_le_mul (convergent_den_le_continuant α n)
    ((convergent_den_le_continuant α n).trans GenContFract.of_den_mono)
    (by positivity) (by linarith [continuedFraction_den_ge_one α n])

end UAMO.ScalarGauge

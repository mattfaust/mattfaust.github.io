import UAMO.ScalarGaugeConvergents
import Mathlib.Algebra.ContinuedFractions.Determinant

noncomputable section
namespace UAMO.ScalarGauge
open GenContFract

theorem continuedFraction_integral_num_den (α : ℝ) (n : ℕ) :
    ∃p q:ℤ,(GenContFract.of α).nums n=(p:ℝ) ∧ (GenContFract.of α).dens n=(q:ℝ) := by
  obtain ⟨⟨p,q⟩,hpq⟩ := continuedFraction_integral_conts α n
  exact ⟨p,q,by simp only [GenContFract.num_eq_conts_a,hpq,GenContFract.Pair.map],
    by simp only [GenContFract.den_eq_conts_b,hpq,GenContFract.Pair.map]⟩

theorem convergent_den_eq_continuant {α : ℝ} (hα : Irrational α) (n : ℕ) :
    ((α.convergent n).den:ℝ)=(GenContFract.of α).dens n := by
  obtain ⟨p,q,hp,hq⟩ := continuedFraction_integral_num_den α n
  obtain ⟨p',q',hp',hq'⟩ := continuedFraction_integral_num_den α (n+1)
  have hqpos : 0<q := by
    have hh := continuedFraction_den_ge_one α n
    rw [hq] at hh
    have hh' : (0:ℝ)<q := by linarith
    exact_mod_cast hh'
  have hconv : α.convergent n=Rat.divInt p q := by
    apply Rat.cast_injective (α:=ℝ)
    rw [← Real.convs_eq_convergent,GenContFract.conv_eq_num_div_den,hp,hq,
      Rat.divInt_eq_div,Rat.cast_div,Rat.cast_intCast,Rat.cast_intCast]
  obtain ⟨c,hpc,hqc⟩ := Rat.num_den_mk hqpos.ne' hconv
  have hdetR := (SimpContFract.of α).determinant (irrational_continuedFraction_not_terminated hα n)
  change (GenContFract.of α).nums n*(GenContFract.of α).dens (n+1)-
    (GenContFract.of α).dens n*(GenContFract.of α).nums (n+1)=(-1:ℝ)^(n+1) at hdetR
  rw [hp,hq,hp',hq'] at hdetR
  have hdet : p*q'-q*p'=(-1:ℤ)^(n+1) := by exact_mod_cast hdetR
  have hdvd : c∣(-1:ℤ)^(n+1) := by
    refine ⟨(α.convergent n).num*q'-((α.convergent n).den:ℤ)*p',?_⟩
    rw [← hdet,hpc,hqc]
    ring
  have hcunit : IsUnit c := isUnit_of_dvd_unit hdvd ((isUnit_neg_one: IsUnit (-1:ℤ)).pow (n+1))
  have hcpos : 0<c := by
    rw [hqc] at hqpos
    exact (mul_pos_iff_of_pos_right (by exact_mod_cast (α.convergent n).pos)).mp hqpos
  have hc : c=1 := by
    rcases Int.isUnit_iff.mp hcunit with hc | hc
    · exact hc
    · omega
  rw [hq,hqc,hc,one_mul,Int.cast_natCast]

theorem convergent_den_fibonacci {α : ℝ} (hα : Irrational α) (n : ℕ) :
    Nat.fib (n+1)≤(α.convergent n).den := by
  have h := GenContFract.succ_nth_fib_le_of_nth_den
    (v:=α) (n:=n) (Or.inr (irrational_continuedFraction_not_terminated hα (n-1)))
  rw [← convergent_den_eq_continuant hα n] at h
  exact_mod_cast h

end UAMO.ScalarGauge

import Mathlib.Topology.Order.IntermediateValue
import UAMO.ScalarFixedLabelLimit
import UAMO.ScalarForwardLabel
import UAMO.ScalarGapInternality

noncomputable section
namespace UAMO
open Set Filter
open scoped Topology

def scalarPositiveLabelCouplings (a φ r₀ r₁ seed label : ℝ) : Set ℝ :=
  {r | r∈Icc r₀ r₁ ∧ ∃ E : ℝ,
    (E : ℂ)∈resolventSet ℂ (scalarHamiltonian a r φ) ∧
    scalarGreen a r φ E=0 ∧ seed≤scalarLogPotential a r φ E ∧
    scalarIDS a r φ E=label}

theorem scalarPositiveLabelCouplings_isClosed (a φ r₀ r₁ seed label : ℝ)
    (ha : a≠0) (hr₀ : 0≤r₀) (hr₁ : r₁≤1) (hseed : 0<seed)
    (hbaseline : ∀ r∈Icc r₀ r₁,∀ E : ℝ,
      (E : ℂ)∈spectrum ℂ (scalarHamiltonian a r φ) → scalarTotalLogPotential a φ (r,E)=0) :
    IsClosed (scalarPositiveLabelCouplings a φ r₀ r₁ seed label) := by
  apply IsSeqClosed.isClosed
  intro r rlim hr hl
  have hrange : rlim∈Icc r₀ r₁ :=
    isClosed_Icc.mem_of_tendsto hl (Eventually.of_forall fun n => (hr n).1)
  choose energy he using fun n => (hr n).2
  obtain ⟨E,hE,hg,hh,hs⟩ := scalar_positive_fixed_label_sequence_limit a φ rlim seed label
    ha r energy (fun n => ⟨hr₀.trans (hr n).1.1,(hr n).1.2.trans hr₁⟩) hl hseed
    (fun n => (he n).1) (fun n => (he n).2.1) (fun n => (he n).2.2.1)
    (fun n => (he n).2.2.2) (hbaseline rlim hrange)
  exact ⟨hrange,E,hE,hg,hh,hs⟩

theorem scalar_positive_seed_global_continuation (a α r₀ r₁ E₀ : ℝ)
    (ha : a≠0) (hα : Irrational α) (hr₀ : 0<r₀) (hr : r₀≤r₁) (hr₁ : r₁≤1)
    (hE₀ : (E₀ : ℂ)∈resolventSet ℂ (scalarHamiltonian a r₀ (Real.pi*α)))
    (hg₀ : scalarGreen a r₀ (Real.pi*α) E₀=0)
    (hh₀ : 0<scalarLogPotential a r₀ (Real.pi*α) E₀)
    (hbaseline : ∀ r∈Icc r₀ r₁,∀ E : ℝ,
      (E : ℂ)∈spectrum ℂ (scalarHamiltonian a r (Real.pi*α)) →
      scalarTotalLogPotential a (Real.pi*α) (r,E)=0) :
    ∀ r∈Icc r₀ r₁,∃ E : ℝ,
      (E : ℂ)∈resolventSet ℂ (scalarHamiltonian a r (Real.pi*α)) ∧
      scalarGreen a r (Real.pi*α) E=0 ∧
      scalarLogPotential a r₀ (Real.pi*α) E₀≤scalarLogPotential a r (Real.pi*α) E ∧
      scalarIDS a r (Real.pi*α) E=scalarIDS a r₀ (Real.pi*α) E₀ := by
  let seed := scalarLogPotential a r₀ (Real.pi*α) E₀
  let label := scalarIDS a r₀ (Real.pi*α) E₀
  let S := scalarPositiveLabelCouplings a (Real.pi*α) r₀ r₁ seed label
  have hS : IsClosed S := scalarPositiveLabelCouplings_isClosed
    a (Real.pi*α) r₀ r₁ seed label ha hr₀.le hr₁ hh₀ hbaseline
  have hstart : r₀∈S := ⟨⟨le_refl _,hr⟩,E₀,hE₀,hg₀,le_refl _,rfl⟩
  have hstep : ∀ r∈S,r∈Ico r₀ r₁ → ∃ ε>0,Icc r (r+ε)⊆S := by
    intro r hrS hrange
    obtain ⟨_,E,hE,hg,hh,hs⟩ := hrS
    obtain ⟨ε,hε,hext⟩ := scalar_fixed_label_forward_extension a α r E ha hα
      (hr₀.trans_le hrange.1) hE hg
    refine ⟨min ε (r₁-r),lt_min hε (sub_pos.mpr hrange.2),?_⟩
    intro t ht
    have htr : t≤r₁ := by have := min_le_right ε (r₁-r); linarith [ht.2]
    have hte : t≤r+ε := by have := min_le_left ε (r₁-r); linarith [ht.2]
    obtain ⟨F,hF,hfg,hfh,hfs⟩ := hext t ⟨ht.1,hte⟩
    exact ⟨⟨hrange.1.trans ht.1,htr⟩,F,hF,hfg,hh.trans hfh,hfs.trans hs⟩
  have hcover : Icc r₀ r₁ ⊆ S := by
    apply (hS.inter isClosed_Icc).Icc_subset_of_forall_mem_nhdsWithin hstart
    rintro r ⟨hrS, hrange⟩
    obtain ⟨ε, hε, hεS⟩ := hstep r hrS hrange
    exact mem_of_superset (Ioc_mem_nhdsGT (lt_add_of_pos_right r hε))
      (Ioc_subset_Icc_self.trans hεS)
  exact fun r hrange => (hcover hrange).2

end UAMO

import UAMO.GapProjectionTrace
import UAMO.PhysicalDOSLabels
import Mathlib.MeasureTheory.Measure.Portmanteau

noncomputable section
namespace UAMO
open MeasureTheory Set Filter
open scoped Topology ContinuousFunctionalCalculus

local instance idsContinuity_realNormedSpace (φ : ℝ) :
    NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)
local instance idsContinuity_realModule (φ : ℝ) : Module ℝ (magneticAlgebra φ) :=
  @Algebra.toModule ℝ (magneticAlgebra φ) _ _ (magneticAlgebra_realNormedAlgebra φ).toAlgebra
local instance idsContinuity_continuousSMul (φ : ℝ) :
    ContinuousSMul ℝ (magneticAlgebra φ) := by
  constructor
  apply continuous_induced_rng.mpr
  change Continuous (fun p : ℝ × magneticAlgebra φ => p.1 • (p.2 : MagneticOperator))
  exact continuous_fst.smul (continuous_subtype_val.comp continuous_snd)
local instance idsContinuity_nontrivial (φ : ℝ) : Nontrivial (magneticAlgebra φ) := by
  apply nontrivial_of_ne (0 : magneticAlgebra φ) 1
  intro h
  have hh := congrArg (magneticTraceReal φ) h
  exact zero_ne_one (by simpa only [map_zero, magneticTraceReal_one] using hh)

def scalarPencilProbabilityMeasure (a r φ E : ℝ) : ProbabilityMeasure ℝ :=
  ⟨(scalarRealSpectralMeasure a r φ).map (fun x : ℝ => E - x),
    isProbabilityMeasure_map (continuous_const.sub continuous_id).measurable.aemeasurable⟩

theorem scalarPencilProbabilityMeasure_integral (a r φ E : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂(scalarPencilProbabilityMeasure a r φ E : Measure ℝ) =
      magneticTraceReal φ (cfc f (scalarAlgebraPencil a r φ E)) := by
  change ∫ x, f x ∂(scalarRealSpectralMeasure a r φ).map (fun x : ℝ => E - x) = _
  have hc : Continuous (fun x : ℝ => E - x) := continuous_const.sub continuous_id
  rw [integral_map hc.measurable.aemeasurable
    hf.aestronglyMeasurable,
    scalarRealSpectralMeasure_integral_cfc a r φ (fun x : ℝ => f (E - x))
      (hf.comp hc)]
  congr 1
  rw [scalarAlgebraPencil, ← cfc_real_pencil _
    (scalarAlgebraHamiltonian_isSelfAdjoint a r φ) E]
  exact cfc_comp' f (fun x : ℝ => E - x) (scalarAlgebraHamiltonian a r φ)
    hf.continuousOn (continuous_const.sub continuous_id).continuousOn
    (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)

theorem continuousAt_scalarPencilProbabilityMeasure (φ : ℝ)
    (p : (ℝ × ℝ) × ℝ) (ha : p.1.1 ≠ 0) :
    ContinuousAt (fun q : (ℝ × ℝ) × ℝ =>
      scalarPencilProbabilityMeasure q.1.1 q.1.2 φ q.2) p := by
  apply ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mpr
  intro f
  simp_rw [scalarPencilProbabilityMeasure_integral _ _ _ _ f f.continuous]
  have hH := (continuousAt_scalarAlgebraHamiltonian_joint φ p.1 ha).comp
    continuous_fst.continuousAt
  have hP : ContinuousAt (fun q : (ℝ × ℝ) × ℝ =>
      scalarAlgebraPencil q.1.1 q.1.2 φ q.2) p :=
    (continuous_snd.continuousAt.smul continuousAt_const).sub hH
  exact (magneticTraceReal φ).continuous.continuousAt.comp
    (continuousAt_cfc_of_continuous _ p hP f f.continuous
      (Eventually.of_forall fun q => scalarAlgebraPencil_isSelfAdjoint q.1.1 q.1.2 φ q.2))

theorem scalarPencilProbabilityMeasure_Ioi (a r φ E : ℝ) :
    (scalarPencilProbabilityMeasure a r φ E : Measure ℝ) (Ioi 0) =
      scalarRealSpectralMeasure a r φ (Iio E) := by
  change (scalarRealSpectralMeasure a r φ).map (fun x : ℝ => E - x) (Ioi 0) = _
  have hc : Continuous (fun x : ℝ => E - x) := continuous_const.sub continuous_id
  rw [Measure.map_apply hc.measurable measurableSet_Ioi]
  congr 1
  ext x
  simp only [mem_preimage, mem_Ioi, mem_Iio, sub_pos]

theorem continuousAt_scalarIDS_joint_of_singleton (φ : ℝ) (p : (ℝ × ℝ) × ℝ)
    (ha : p.1.1 ≠ 0) (hzero : scalarRealSpectralMeasure p.1.1 p.1.2 φ {p.2} = 0) :
    ContinuousAt (fun q : (ℝ × ℝ) × ℝ => scalarIDS q.1.1 q.1.2 φ q.2) p := by
  have hfront : (scalarPencilProbabilityMeasure p.1.1 p.1.2 φ p.2 : Measure ℝ)
      (frontier (Ioi (0 : ℝ))) = 0 := by
    rw [frontier_Ioi]
    change (scalarRealSpectralMeasure p.1.1 p.1.2 φ).map (fun x : ℝ => p.2 - x) {0} = 0
    have hc : Continuous (fun x : ℝ => p.2 - x) := continuous_const.sub continuous_id
    rw [Measure.map_apply hc.measurable (measurableSet_singleton 0)]
    have he : (fun x : ℝ => p.2 - x) ⁻¹' {0} = {p.2} := by
      ext x
      simp only [mem_preimage, mem_singleton_iff, sub_eq_zero, eq_comm]
    rw [he, hzero]
  have ht := ProbabilityMeasure.tendsto_measure_of_null_frontier_of_tendsto'
    (continuousAt_scalarPencilProbabilityMeasure φ p ha) hfront
  simp_rw [scalarPencilProbabilityMeasure_Ioi] at ht
  exact (ENNReal.tendsto_toReal (measure_ne_top _ _)).comp ht

theorem continuousAt_scalarIDS_joint (φ : ℝ) (p : (ℝ × ℝ) × ℝ) (ha : p.1.1 ≠ 0)
    [NoAtoms (scalarRealSpectralMeasure p.1.1 p.1.2 φ)] :
    ContinuousAt (fun q : (ℝ × ℝ) × ℝ => scalarIDS q.1.1 q.1.2 φ q.2) p :=
  continuousAt_scalarIDS_joint_of_singleton φ p ha (measure_singleton p.2)

theorem continuousAt_scalarIDS_joint_physical {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r ≤ 1) (φ E : ℝ) :
    ContinuousAt (fun q : (ℝ × ℝ) × ℝ => scalarIDS q.1.1 q.1.2 φ q.2) ((a,r),E) := by
  letI := scalarRealSpectralMeasure_noAtoms ha ha1 hr hr1 φ
  exact continuousAt_scalarIDS_joint φ ((a,r),E) ha.ne'

end UAMO

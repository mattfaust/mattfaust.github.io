import UAMO.GapEndpointContinuity
import UAMO.ScalarGlobalContinuation

noncomputable section
namespace UAMO
open Set

theorem compact_internal_gap_endpoints {S : Set ℝ} (hS : IsCompact S) {E : ℝ}
    (hE : E ∉ S) (hl : ∃ l ∈ S, l < E) (hu : ∃ u ∈ S, E < u) :
    ∃ l u : ℝ, l ∈ S ∧ u ∈ S ∧ E ∈ Ioo l u ∧ Disjoint (Ioo l u) S := by
  obtain ⟨l₀,hl₀,hl₀E⟩ := hl
  obtain ⟨u₀,hu₀,hEu₀⟩ := hu
  obtain ⟨l,hl,hmax⟩ := (hS.inter_right isClosed_Iic).exists_isGreatest
    (show (S ∩ Iic E).Nonempty from ⟨l₀,hl₀,hl₀E.le⟩)
  obtain ⟨u,hu,hmin⟩ := (hS.inter_right isClosed_Ici).exists_isLeast
    (show (S ∩ Ici E).Nonempty from ⟨u₀,hu₀,hEu₀.le⟩)
  have hlE : l < E := lt_of_le_of_ne hl.2 (fun he => hE (he ▸ hl.1))
  have hEu : E < u := lt_of_le_of_ne hu.2 (fun he => hE (he.symm ▸ hu.1))
  refine ⟨l,u,hl.1,hu.1,⟨hlE,hEu⟩,Set.disjoint_left.mpr ?_⟩
  intro x hx hxS
  by_cases hxE : x ≤ E
  · exact (not_le_of_gt hx.1) (hmax ⟨hxS,hxE⟩)
  · exact (not_le_of_gt hx.2) (hmin ⟨hxS,(le_of_not_ge hxE)⟩)

theorem scalar_internal_gap_endpoints (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (hlabel : scalarIDS a r φ E ∈ Ioo (0 : ℝ) 1) :
    ∃ l u : ℝ, (l : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ∧
      (u : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) ∧ E ∈ Ioo l u ∧
      ∀ x ∈ Ioo l u, (x : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ) := by
  let S := {x : ℝ | (x : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)}
  have hS : IsCompact S := by
    dsimp only [S]
    rw [scalarRealSpectrum_eq_algebraSpectrum]
    exact spectrum.isCompact _
  obtain ⟨l₀,u₀,hl₀,hu₀,hl₀E,hEu₀⟩ :=
    (scalar_internal_resolvent_iff_IDS a r φ E hE).mpr hlabel
  obtain ⟨l,u,hl,hu,hlu,hgap⟩ := compact_internal_gap_endpoints hS
    (show E ∉ S from fun h => h hE) ⟨l₀,hl₀,hl₀E⟩ ⟨u₀,hu₀,hEu₀⟩
  refine ⟨l,u,hl,hu,hlu,?_⟩
  intro x hx
  by_contra hnot
  exact (Set.disjoint_left.mp hgap hx) hnot

end UAMO

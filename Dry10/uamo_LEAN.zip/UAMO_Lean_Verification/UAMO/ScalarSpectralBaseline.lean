import UAMO.ScalarSpectralLift
import UAMO.UAMOSpectralLyapunovExact

noncomputable section
namespace UAMO
open CMV

theorem scalarTotalLogPotential_spectral_eq {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hr1 : r≤1)
    (hα : Irrational α) (E : ℝ)
    (hE : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r (-Real.pi*α))) :
    scalarTotalLogPotential a (-Real.pi*α) (r,E)=
      ((max 0 (Real.log (r/a)) : ℝ):EReal) := by
  obtain ⟨z,hz,hzre,hzs⟩ := exists_physical_spectral_circle_lift
    ha ha1 hr.le hr1 hα 0 E hE
  rw [scalarTotalLogPotential_eq_uamoLyapunov ha ha1 hr.le hr1 α E z hz hzre,
    uamoLyapunov_spectral_eq ha ha1 hr hr1 hα 0 hzs]

theorem scalarTotalLogPotential_spectral_zero {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hra : r≤a)
    (hα : Irrational α) (E : ℝ)
    (hE : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r (-Real.pi*α))) :
    scalarTotalLogPotential a (-Real.pi*α) (r,E)=0 := by
  rw [scalarTotalLogPotential_spectral_eq ha ha1 hr (hra.trans ha1) hα E hE,
    max_eq_left (Real.log_nonpos (div_nonneg hr.le ha.le) ((div_le_one ha).mpr hra))]
  rfl

theorem scalarTotalLogPotential_spectral_zero_pos_field {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hra : r≤a)
    (hα : Irrational α) (E : ℝ)
    (hE : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r (Real.pi*α))) :
    scalarTotalLogPotential a (Real.pi*α) (r,E)=0 := by
  have hfield : -Real.pi*(-α)=Real.pi*α := by ring
  have hE' : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r (-Real.pi*(-α))) := by
    simpa only [hfield] using hE
  simpa only [hfield] using
    scalarTotalLogPotential_spectral_zero ha ha1 hr hra hα.neg E hE'

end UAMO

import UAMO.BoundaryCircleContinuation

noncomputable section
namespace UAMO
open Set MeasureTheory CircleDOS PhysicalDOS PhysicalRepresentation

theorem scalar_spectral_normalized_bound {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0≤r) (hr1 : r≤1) (φ E : ℝ)
    (hE : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r φ)) :
    (a/((1+a^2)*(1+r^2)))*E∈Icc (-1:ℝ) 1 := by
  let S : Set ℝ := {x | (a/((1+a^2)*(1+r^2)))*x∈Icc (-1:ℝ) 1}
  have hclosed : IsClosed S :=
    isClosed_Icc.preimage (continuous_const.mul continuous_id)
  have hmass : scalarRealSpectralMeasure a r φ Sᶜ=0 := by
    exact ae_iff.mp (scalarRealSpectralMeasure_scaled_ae_Icc ha ha1 hr hr1 φ)
  by_contra hnot
  obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp hclosed.isOpen_compl E hnot
  have hpos := scalarRealSpectralMeasure_ball_pos_of_mem a r φ E hE hε
  have hle := (measure_mono hball).trans_eq hmass
  exact (not_le_of_gt hpos) hle

theorem scalar_spectral_upperLift_mem_physical {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1)
    (hα : Irrational α) (θ E : ℝ)
    (hE : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r (-Real.pi*α))) :
    upperLift ((a/((1+a^2)*(1+r^2)))*E)∈spectrum ℂ
      (cstarWalk (coupling a) (coupling r) α θ) := by
  have hnorm := upperLift_norm_of_mem_Icc
    (scalar_spectral_normalized_bound ha ha1 hr hr1 (-Real.pi*α) E hE)
  rw [cstarWalk_spectrum]
  intro hres
  have hscalar := (physical_circle_resolvent_scalar ha ha1 hr hr1 hα θ _ hnorm).mp hres
  rw [scalarEnergyOfCircle_upperLift ha.ne' r E] at hscalar
  exact hE hscalar

theorem exists_physical_spectral_circle_lift {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1)
    (hα : Irrational α) (θ E : ℝ)
    (hE : (E:ℂ)∈spectrum ℂ (scalarHamiltonian a r (-Real.pi*α))) :
    ∃z:ℂ, ‖z‖=1 ∧ z.re=(a/((1+a^2)*(1+r^2)))*E ∧
      z∈spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ) := by
  exact ⟨upperLift ((a/((1+a^2)*(1+r^2)))*E),
    upperLift_norm_of_mem_Icc
      (scalar_spectral_normalized_bound ha ha1 hr hr1 (-Real.pi*α) E hE),
    upperLift_re _,scalar_spectral_upperLift_mem_physical ha ha1 hr hr1 hα θ E hE⟩

end UAMO

import UAMO.CanonicalTrace
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.ExpLog
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Basic
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Isometric
import Mathlib.MeasureTheory.Integral.RieszMarkovKakutani.Real
import Mathlib.MeasureTheory.Measure.Typeclasses.Probability

noncomputable section

namespace UAMO

open MeasureTheory CompactlySupported
open scoped ContinuousFunctionalCalculus

local instance (φ : ℝ) : NormedSpace ℝ (magneticAlgebra φ) :=
  NormedAlgebra.toNormedSpace (𝕜 := ℝ) (magneticAlgebra φ)

abbrev ScalarRealSpectrum (a r φ : ℝ) : Type :=
  spectrum ℝ (scalarAlgebraHamiltonian a r φ)

def compactTestToContinuous {X : Type*} [TopologicalSpace X] :
    C_c(X, ℝ) →ₗ[ℝ] C(X, ℝ) where
  toFun := fun f => f.toContinuousMap
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

def scalarSpectralFunctional (a r φ : ℝ) :
    C_c(ScalarRealSpectrum a r φ, ℝ) →ₗ[ℝ] ℝ :=
  (magneticTraceReal φ).toLinearMap.comp
    ((cfcL (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)).toLinearMap.comp
      compactTestToContinuous)

set_option maxHeartbeats 800000 in

theorem scalarSpectralFunctional_nonneg (a r φ : ℝ)
    (f : C_c(ScalarRealSpectrum a r φ, ℝ)) (hf : 0 ≤ f) :
    0 ≤ scalarSpectralFunctional a r φ f := by
  let g : C(ScalarRealSpectrum a r φ, ℝ) :=
    ⟨fun x => Real.sqrt (f x), Real.continuous_sqrt.comp f.continuous⟩
  have hsq : g * g = f.toContinuousMap := by
    ext x
    exact Real.mul_self_sqrt (hf x)
  let hH := scalarAlgebraHamiltonian_isSelfAdjoint a r φ
  have hfact : cfcHom hH f.toContinuousMap = star (cfcHom hH g) * cfcHom hH g := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul, hsq]
  change 0 ≤ magneticTraceReal φ (cfcHom hH f.toContinuousMap)
  rw [hfact]
  exact magneticTraceReal_star_mul_self_nonneg φ (cfcHom hH g)

def scalarSpectralMeasure (a r φ : ℝ) : Measure (ScalarRealSpectrum a r φ) :=
  RealRMK.rieszMeasure (scalarSpectralFunctional_nonneg a r φ)

theorem scalarSpectralMeasure_integral_compact (a r φ : ℝ)
    (f : C_c(ScalarRealSpectrum a r φ, ℝ)) :
    ∫ x, f x ∂scalarSpectralMeasure a r φ =
      magneticTraceReal φ
        (cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a r φ) f.toContinuousMap) :=
  RealRMK.integral_rieszMeasure (scalarSpectralFunctional_nonneg a r φ) f

theorem scalarSpectralMeasure_integral (a r φ : ℝ)
    (f : C(ScalarRealSpectrum a r φ, ℝ)) :
    ∫ x, f x ∂scalarSpectralMeasure a r φ =
      magneticTraceReal φ (cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a r φ) f) := by
  let fc : C_c(ScalarRealSpectrum a r φ, ℝ) :=
    { toContinuousMap := f
      hasCompactSupport' := HasCompactSupport.of_compactSpace f }
  exact scalarSpectralMeasure_integral_compact a r φ fc

instance scalarSpectralMeasure_isProbabilityMeasure (a r φ : ℝ) :
    IsProbabilityMeasure (scalarSpectralMeasure a r φ) := by
  constructor
  apply (ENNReal.toReal_eq_one_iff _).mp
  have h := scalarSpectralMeasure_integral a r φ (1 : C(ScalarRealSpectrum a r φ, ℝ))
  simpa only [ContinuousMap.one_apply, integral_const, smul_eq_mul, mul_one,
    map_one, magneticTraceReal_one, measureReal_def] using h

def scalarRealSpectralMeasure (a r φ : ℝ) : Measure ℝ :=
  (scalarSpectralMeasure a r φ).map (fun x : ScalarRealSpectrum a r φ => (x : ℝ))

instance scalarRealSpectralMeasure_isProbabilityMeasure (a r φ : ℝ) :
    IsProbabilityMeasure (scalarRealSpectralMeasure a r φ) :=
  isProbabilityMeasure_map continuous_subtype_val.measurable.aemeasurable

theorem scalarRealSpectralMeasure_integral (a r φ : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂scalarRealSpectralMeasure a r φ =
      magneticTraceReal φ
        (cfcHom (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)
          (⟨fun x => f x, hf.comp continuous_subtype_val⟩ :
            C(ScalarRealSpectrum a r φ, ℝ))) := by
  rw [scalarRealSpectralMeasure,
    integral_map continuous_subtype_val.measurable.aemeasurable hf.aestronglyMeasurable]
  exact scalarSpectralMeasure_integral a r φ
    (⟨fun x => f x, hf.comp continuous_subtype_val⟩ : C(ScalarRealSpectrum a r φ, ℝ))

theorem scalarRealSpectralMeasure_integral_cfc (a r φ : ℝ)
    (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂scalarRealSpectralMeasure a r φ =
      magneticTraceReal φ (cfc f (scalarAlgebraHamiltonian a r φ)) := by
  rw [cfc_apply f (scalarAlgebraHamiltonian a r φ)
    (scalarAlgebraHamiltonian_isSelfAdjoint a r φ) hf.continuousOn]
  exact scalarRealSpectralMeasure_integral a r φ f hf

def scalarEnergyBump (E ε x : ℝ) : ℝ := max 0 (ε - |x - E|)

theorem continuous_scalarEnergyBump (E ε : ℝ) : Continuous (scalarEnergyBump E ε) := by
  unfold scalarEnergyBump
  fun_prop

set_option maxHeartbeats 800000 in

theorem scalarRealSpectralMeasure_ball_pos_of_mem (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ))
    {ε : ℝ} (he : 0 < ε) :
    0 < scalarRealSpectralMeasure a r φ (Metric.ball E ε) := by
  by_contra hpos
  have hmass : scalarRealSpectralMeasure a r φ (Metric.ball E ε) = 0 :=
    le_antisymm (le_of_not_gt hpos) (zero_le _)
  have hout : ∀ᵐ x ∂scalarRealSpectralMeasure a r φ, x ∉ Metric.ball E ε := by
    apply ae_iff.mpr
    simpa only [not_not, Set.setOf_mem_eq] using hmass
  have hzero : (fun x => scalarEnergyBump E ε x * scalarEnergyBump E ε x)
      =ᵐ[scalarRealSpectralMeasure a r φ] (fun _ => (0 : ℝ)) := by
    filter_upwards [hout] with x hx
    have hx' : ε ≤ |x - E| := by
      simpa only [Metric.mem_ball, Real.dist_eq, not_lt] using hx
    simp only [scalarEnergyBump, max_eq_left (sub_nonpos.mpr hx'), zero_mul]
  let g : C(ScalarRealSpectrum a r φ, ℝ) :=
    ⟨fun x => scalarEnergyBump E ε x,
      (continuous_scalarEnergyBump E ε).comp continuous_subtype_val⟩
  let hH := scalarAlgebraHamiltonian_isSelfAdjoint a r φ
  have htrace : magneticTraceReal φ (star (cfcHom hH g) * cfcHom hH g) = 0 := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul]
    have hint := scalarRealSpectralMeasure_integral a r φ
      (fun x => scalarEnergyBump E ε x * scalarEnergyBump E ε x)
      ((continuous_scalarEnergyBump E ε).mul (continuous_scalarEnergyBump E ε))
    rw [integral_congr_ae hzero, integral_zero] at hint
    exact hint.symm
  have hg : g = 0 := by
    apply (cfcHom_isClosedEmbedding hH).injective
    rw [map_zero]
    exact magneticTraceReal_faithful φ (cfcHom hH g) htrace
  have hEin : E ∈ spectrum ℝ (scalarAlgebraHamiltonian a r φ) := by
    rw [← scalarRealSpectrum_eq_algebraSpectrum]
    exact hE
  have hvalue := congrArg (fun f : C(ScalarRealSpectrum a r φ, ℝ) => f ⟨E, hEin⟩) hg
  have : ε = 0 := by
    simpa only [g, ContinuousMap.coe_mk, sub_self, abs_zero, sub_zero,
      scalarEnergyBump, max_eq_right he.le, ContinuousMap.zero_apply] using hvalue
  exact he.ne' this

theorem scalarRealSpectralMeasure_spectrum_compl (a r φ : ℝ) :
    scalarRealSpectralMeasure a r φ
      {E : ℝ | (E : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)}ᶜ = 0 := by
  rw [scalarRealSpectrum_eq_algebraSpectrum, scalarRealSpectralMeasure,
    Measure.map_apply continuous_subtype_val.measurable
      (spectrum.isClosed (scalarAlgebraHamiltonian a r φ)).measurableSet.compl]
  have hempty : (fun x : ScalarRealSpectrum a r φ => (x : ℝ)) ⁻¹'
      (spectrum ℝ (scalarAlgebraHamiltonian a r φ))ᶜ = ∅ := by
    ext x
    simp
  rw [hempty, measure_empty]

section GenericCFC

variable {A : Type*} [CStarAlgebra A]

theorem spectral_shift_ne_zero {H : A} (energy : ℝ)
    (hunit : IsUnit (energy • (1 : A) - H))
    {x : ℝ} (hx : x ∈ spectrum ℝ H) : energy - x ≠ 0 := by
  intro hzero
  have heq : energy = x := sub_eq_zero.mp hzero
  subst x
  change ¬ IsUnit (algebraMap ℝ A energy - H) at hx
  exact hx (by simpa only [Algebra.algebraMap_eq_smul_one] using hunit)

theorem cfc_real_pencil (H : A) (hH : IsSelfAdjoint H) (energy : ℝ) :
    cfc (fun x : ℝ => energy - x) H = energy • (1 : A) - H := by
  rw [cfc_sub (fun _ : ℝ => energy) (fun x : ℝ => x) H,
    cfc_const energy H hH, cfc_id' ℝ H hH, Algebra.algebraMap_eq_smul_one]

theorem cfc_log_squared_real_pencil (H : A) (hH : IsSelfAdjoint H) (energy : ℝ)
    (hunit : IsUnit (energy • (1 : A) - H)) :
    CFC.log ((energy • (1 : A) - H) ^ 2) =
      (2 : ℝ) • cfc (fun x : ℝ => Real.log |energy - x|) H := by
  have hf : ContinuousOn (fun x : ℝ => (energy - x) ^ 2) (spectrum ℝ H) := by fun_prop
  have hlog : ContinuousOn Real.log ((fun x : ℝ => (energy - x) ^ 2) '' spectrum ℝ H) := by
    apply Real.continuousOn_log.mono
    rintro _ ⟨x, hx, rfl⟩
    exact pow_ne_zero 2 (spectral_shift_ne_zero energy hunit hx)
  have hlogabs : ContinuousOn (fun x : ℝ => Real.log |energy - x|) (spectrum ℝ H) :=
    ((continuous_const.sub continuous_id).continuousOn.abs).log
      (fun x hx => abs_ne_zero.mpr (spectral_shift_ne_zero energy hunit hx))
  have hsquare : cfc (fun x : ℝ => (energy - x) ^ 2) H =
      (energy • (1 : A) - H) ^ 2 := by
    rw [cfc_pow (fun x : ℝ => energy - x) 2 H, cfc_real_pencil H hH energy]
  calc
    CFC.log ((energy • (1 : A) - H) ^ 2) =
        cfc (fun x : ℝ => Real.log ((energy - x) ^ 2)) H := by
      change cfc Real.log _ = _
      rw [← hsquare]
      exact (cfc_comp' Real.log (fun x : ℝ => (energy - x) ^ 2) H hlog hf hH).symm
    _ = cfc (fun x : ℝ => (2 : ℝ) * Real.log |energy - x|) H := by
      apply cfc_congr
      intro x _
      change Real.log ((energy - x) ^ 2) = 2 * Real.log |energy - x|
      rw [Real.log_pow, Real.log_abs]
      norm_num
    _ = (2 : ℝ) • cfc (fun x : ℝ => Real.log |energy - x|) H :=
      cfc_const_mul 2 (fun x : ℝ => Real.log |energy - x|) H hlogabs

end GenericCFC

theorem scalarSpectralMeasure_integral_cfc_of_continuousOn (a r φ : ℝ)
    (f : ℝ → ℝ)
    (hf : ContinuousOn f (spectrum ℝ (scalarAlgebraHamiltonian a r φ))) :
    ∫ x : ScalarRealSpectrum a r φ, f x ∂scalarSpectralMeasure a r φ =
      magneticTraceReal φ (cfc f (scalarAlgebraHamiltonian a r φ)) := by
  rw [cfc_apply f (scalarAlgebraHamiltonian a r φ)
    (scalarAlgebraHamiltonian_isSelfAdjoint a r φ) hf]
  exact scalarSpectralMeasure_integral a r φ ⟨_, hf.restrict⟩

theorem scalar_spectral_shift_ne_zero (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (x : ScalarRealSpectrum a r φ) : energy - (x : ℝ) ≠ 0 :=
  spectral_shift_ne_zero energy (scalarAlgebraPencil_isUnit a r φ energy hm) x.property

theorem scalar_log_kernel_continuous (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    Continuous (fun x : ScalarRealSpectrum a r φ => Real.log |energy - (x : ℝ)|) :=
  (continuous_const.sub continuous_subtype_val).abs.log
    (fun x => abs_ne_zero.mpr (scalar_spectral_shift_ne_zero a r φ energy hm x))

theorem scalarTraceLog_eq_spectralIntegral (a r φ energy : ℝ)
    (hm : (energy : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    magneticTraceReal φ (CFC.log ((scalarAlgebraPencil a r φ energy) ^ 2)) / 2 =
      ∫ x : ScalarRealSpectrum a r φ,
        Real.log |energy - (x : ℝ)| ∂scalarSpectralMeasure a r φ := by
  have hcont : ContinuousOn (fun x : ℝ => Real.log |energy - x|)
      (spectrum ℝ (scalarAlgebraHamiltonian a r φ)) :=
    continuousOn_iff_continuous_restrict.mpr (scalar_log_kernel_continuous a r φ energy hm)
  change magneticTraceReal φ
    (CFC.log ((energy • (1 : magneticAlgebra φ) - scalarAlgebraHamiltonian a r φ) ^ 2)) / 2 = _
  rw [cfc_log_squared_real_pencil _ (scalarAlgebraHamiltonian_isSelfAdjoint a r φ)
    energy (scalarAlgebraPencil_isUnit a r φ energy hm), map_smul]
  change (2 * magneticTraceReal φ
    (cfc (fun x : ℝ => Real.log |energy - x|) (scalarAlgebraHamiltonian a r φ))) / 2 = _
  rw [mul_div_cancel_left₀ _ (by norm_num : (2 : ℝ) ≠ 0)]
  exact (scalarSpectralMeasure_integral_cfc_of_continuousOn a r φ _ hcont).symm

theorem scalarRealSpectralMeasure_integral_eq_subtype (a r φ : ℝ) (f : ℝ → ℝ) :
    ∫ x, f x ∂scalarRealSpectralMeasure a r φ =
      ∫ x : ScalarRealSpectrum a r φ, f x ∂scalarSpectralMeasure a r φ := by
  rw [scalarRealSpectralMeasure]
  exact (MeasurableEmbedding.subtype_coe
    (spectrum.isClosed (𝕜 := ℝ) (scalarAlgebraHamiltonian a r φ)).measurableSet).integral_map f

end UAMO

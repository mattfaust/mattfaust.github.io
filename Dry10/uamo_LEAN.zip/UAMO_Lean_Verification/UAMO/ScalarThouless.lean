import UAMO.CMVThoulessClosed
import UAMO.PhysicalDOSReconstruction
import UAMO.CircleNoAtomsProjection
import UAMO.UAMOSpectralLyapunovLower
import Mathlib.Probability.CDF

noncomputable section
namespace UAMO
open MeasureTheory CircleDOS PhysicalDOS CMV
open scoped Topology

theorem scalarTotalLogPotential_eq_uamoLyapunov {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r ≤ 1)
    (Φ E : ℝ) (z : ℂ) (hz : ‖z‖ = 1)
    (hzre : z.re = (a/((1+a^2)*(1+r^2)))*E) :
    scalarTotalLogPotential a (-Real.pi*Φ) (r,E) =
      (uamoLyapunov a r (2*Real.pi*Φ) z : EReal) := by
  have hp := physicalUnitaryDOS_total_log_identity ha ha1 hr hr1 Φ E z hz hzre
  rw [circleTotalPotential_eq_uamoLyapunov_on_circle_closed ha ha1 hr hr1 Φ z hz] at hp
  have hn := cmv_normalization_cancellation_closed ha hr hr1
  rw [physicalHopping_log_integral_closed hr hr1] at hn
  have he : 2*((uamoLyapunov a r (2*Real.pi*Φ) z + Real.log (coupling a) -
      Real.log (1+r^2))/2) = uamoLyapunov a r (2*Real.pi*Φ) z +
        Real.log (2*a/((1+a^2)*(1+r^2))) := by linarith
  have hp' : ((uamoLyapunov a r (2*Real.pi*Φ) z +
      Real.log (2*a/((1+a^2)*(1+r^2))) : ℝ) : EReal) =
      (Real.log (2*a/((1+a^2)*(1+r^2))) : EReal) +
        scalarTotalLogPotential a (-Real.pi*Φ) (r,E) := by
    rw [show (2 : EReal) = ((2 : ℝ) : EReal) from rfl, ← EReal.coe_mul, he] at hp
    exact hp
  have h := congrArg (fun x : EReal => x-(Real.log (2*a/((1+a^2)*(1+r^2))) : ℝ)) hp'
  simpa only [EReal.coe_add, EReal.add_sub_cancel_right, EReal.add_sub_cancel_left] using h.symm

theorem scalarRealSpectralMeasure_noAtoms {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r ≤ 1) (φ : ℝ) :
    NoAtoms (scalarRealSpectralMeasure a r φ) := by
  let Φ := -φ/Real.pi
  have hφ : -Real.pi*Φ = φ := by dsimp [Φ]; field_simp
  letI := physicalUnitaryDOS_noAtoms_closed ha ha1 hr hr1 Φ
  have h := noAtoms_realPart (physicalUnitaryDOS a r Φ ha.le ha1 hr hr1)
    (physicalUnitaryDOS_ae_circle a r Φ ha.le ha1 hr hr1)
  rw [physicalUnitaryDOS_realPart ha ha1 hr hr1 Φ, hφ] at h
  letI := h
  exact noAtoms_of_map (scalarRealSpectralMeasure a r φ)
    (fun E : ℝ => (a/((1+a^2)*(1+r^2)))*E) (continuous_const.mul continuous_id).measurable

end UAMO

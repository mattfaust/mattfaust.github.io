import UAMO.CircleLogPotential

noncomputable section
namespace UAMO
open MeasureTheory Set Filter
open scoped Topology

def scalarContinuousRegularization (a r φ E δ : ℝ) : ℝ :=
  ∫ x : ℝ, Real.log (|E-x|+δ) ∂scalarRealSpectralMeasure a r φ

theorem scalar_continuousLog_integrable (a r φ E δ : ℝ) (hδ : 0 < δ) :
    Integrable (fun x : ℝ => Real.log (|E-x|+δ))
      (scalarRealSpectralMeasure a r φ) := by
  rw [scalarRealSpectralMeasure]
  apply (integrable_map_measure
    (((continuous_const.sub continuous_id).abs.add continuous_const).log
      (fun x : ℝ => (add_pos_of_nonneg_of_pos (abs_nonneg (E-x)) hδ).ne')).aestronglyMeasurable
    continuous_subtype_val.measurable.aemeasurable).mpr
  exact (((continuous_const.sub continuous_subtype_val).abs.add continuous_const).log
    (fun x : ScalarRealSpectrum a r φ =>
      (add_pos_of_nonneg_of_pos (abs_nonneg (E-x)) hδ).ne')).integrable_of_hasCompactSupport
        (HasCompactSupport.of_compactSpace _)

theorem scalarContinuousRegularization_monotone (a r φ E : ℝ) :
    MonotoneOn (scalarContinuousRegularization a r φ E) (Ioi 0) := by
  intro δ hδ ε hε hδε
  change 0 < δ at hδ
  change 0 < ε at hε
  exact integral_mono (scalar_continuousLog_integrable a r φ E δ hδ)
    (scalar_continuousLog_integrable a r φ E ε hε)
    (fun x => Real.log_le_log (by positivity) (add_le_add_left hδε _))

theorem scalarContinuousRegularization_discrete (a r φ E : ℝ) (n : ℕ) :
    scalarContinuousRegularization a r φ E (logRegularizationScale n) =
      scalarRegularizedLogPotential a φ n (r,E) :=
  (scalarRegularizedLogPotential_eq_realSpectralIntegral a φ r E n).symm

theorem scalarContinuousRegularization_tendsto (a r φ E : ℝ) :
    Tendsto (fun n => (scalarContinuousRegularization a r φ E
      (logRegularizationScale n) : EReal)) atTop
      (𝓝 (scalarTotalLogPotential a φ (r,E))) := by
  simpa only [scalarContinuousRegularization_discrete, scalarTotalLogPotential] using
    tendsto_regularization_inf _ (scalarContinuousRegularization_monotone a r φ E)
      logRegularizationScale logRegularizationScale_pos logRegularizationScale_tendsto

theorem realProjectionRegularizedPotential_scalar_scale
    (ν : Measure ℂ) (a r φ E κ δ : ℝ) (hκ : 0 < κ) (hδ : 0 < δ)
    (hreal : Measure.map Complex.re ν =
      Measure.map (fun x : ℝ => κ*x) (scalarRealSpectralMeasure a r φ)) :
    CircleDOS.realProjectionRegularizedPotential ν (κ*E) (κ*δ) =
      Real.log κ + scalarContinuousRegularization a r φ E δ := by
  have hf : Continuous (fun y : ℝ => Real.log (|κ*E-y|+κ*δ)) :=
    ((continuous_const.sub continuous_id).abs.add continuous_const).log
      (fun y => (add_pos_of_nonneg_of_pos (abs_nonneg _) (mul_pos hκ hδ)).ne')
  have hm := integral_map (μ := ν) Complex.continuous_re.measurable.aemeasurable
    hf.aestronglyMeasurable
  change (∫ y : ℝ, Real.log (|κ*E-y|+κ*δ) ∂Measure.map Complex.re ν) = _ at hm
  rw [hreal] at hm
  have hs : Measurable (fun x : ℝ => κ*x) :=
    (continuous_const.mul continuous_id).measurable
  rw [integral_map hs.aemeasurable hf.aestronglyMeasurable] at hm
  unfold CircleDOS.realProjectionRegularizedPotential
  rw [← hm]
  have heq (x : ℝ) : Real.log (|κ*E-κ*x|+κ*δ) =
      Real.log κ + Real.log (|E-x|+δ) := by
    rw [show κ*E-κ*x = κ*(E-x) by ring, abs_mul, abs_of_pos hκ,
      ← mul_add, Real.log_mul hκ.ne' (by positivity)]
  simp_rw [heq]
  rw [integral_add (integrable_const _) (scalar_continuousLog_integrable a r φ E δ hδ)]
  simp only [integral_const, measureReal_def, measure_univ, ENNReal.toReal_one,
    one_smul, scalarContinuousRegularization]

theorem realProjectionTotalPotential_scalar_scale
    (ν : Measure ℂ) [IsFiniteMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (a r φ E κ : ℝ) (hκ : 0 < κ)
    (hreal : Measure.map Complex.re ν =
      Measure.map (fun x : ℝ => κ*x) (scalarRealSpectralMeasure a r φ)) :
    CircleDOS.realProjectionTotalPotential ν (κ*E) =
      (Real.log κ : EReal) + scalarTotalLogPotential a φ (r,E) := by
  have hl := tendsto_regularization_inf _
    (CircleDOS.realProjectionRegularizedPotential_monotone ν hc (κ*E))
    (fun n => κ*logRegularizationScale n)
    (fun n => mul_pos hκ (logRegularizationScale_pos n))
    (by simpa using logRegularizationScale_tendsto.const_mul κ)
  have hr := tendsto_ereal_add_real (scalarContinuousRegularization_tendsto a r φ E)
    (Real.log κ)
  apply tendsto_nhds_unique hl
  simpa only [realProjectionRegularizedPotential_scalar_scale ν a r φ E κ _ hκ
    (logRegularizationScale_pos _) hreal, EReal.coe_add] using hr

theorem circle_total_log_scalar_identity
    (ν : Measure ℂ) [IsProbabilityMeasure ν] (hc : ∀ᵐ w ∂ν, ‖w‖ = 1)
    (hconj : Measure.map star ν = ν) (a r φ E κ : ℝ) (hκ : 0 < κ)
    (hreal : Measure.map Complex.re ν =
      Measure.map (fun x : ℝ => κ*x) (scalarRealSpectralMeasure a r φ))
    (z : ℂ) (hz : ‖z‖ = 1) (hzre : z.re = κ*E) :
    (2 : EReal)*CircleDOS.circleTotalPotential ν z =
      (Real.log (2*κ) : EReal) + scalarTotalLogPotential a φ (r,E) := by
  rw [CircleDOS.circle_total_log_identity ν hc hconj z hz, hzre,
    realProjectionTotalPotential_scalar_scale ν hc a r φ E κ hκ hreal,
    Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) hκ.ne', EReal.coe_add]
  exact (add_assoc _ _ _).symm

end UAMO

import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Data.Real.Irrational
import Mathlib.Algebra.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace UAMO
noncomputable section
open scoped BigOperators

def NoIntegerResonance (ξ : ℂ) : Prop := ∀ n : ℤ, n ≠ 0 → ξ ^ n ≠ 1

def weylPhase (α : ℝ) : ℂ := Complex.exp (((2 * Real.pi * α : ℝ) : ℂ) * Complex.I)

theorem weylPhase_norm (α : ℝ) : ‖weylPhase α‖ = 1 :=
  Complex.norm_exp_ofReal_mul_I (2 * Real.pi * α)

theorem weylPhase_zpow (α : ℝ) (n : ℤ) :
    weylPhase α ^ n =
      Complex.exp (((2 * Real.pi * α * (n : ℝ) : ℝ) : ℂ) * Complex.I) := by
  unfold weylPhase
  rw [← Complex.exp_int_mul]
  congr 1
  simp only [Complex.ofReal_mul, Complex.ofReal_intCast]
  ring

theorem weylPhase_noIntegerResonance {α : ℝ} (hα : Irrational α) :
    NoIntegerResonance (weylPhase α) := by
  intro n hn h
  rw [weylPhase_zpow] at h
  obtain ⟨m, hm⟩ := Complex.exp_eq_one_iff.mp h
  have hi := congrArg Complex.im hm
  simp [Complex.mul_re, Complex.mul_im] at hi
  have heq : α * (n : ℝ) = (m : ℝ) := by
    nlinarith [Real.pi_pos]
  exact (hα.mul_intCast hn).ne_int m heq

end
end UAMO

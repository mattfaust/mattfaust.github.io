import UAMO.BoundarySeedNormalForm

noncomputable section
namespace UAMO.BoundarySeed
open Matrix

theorem product_difference_bound (u v x y : ℂ) {δ : ℝ} (hδ : 0≤δ)
    (hu : ‖u-x‖≤δ) (hv : ‖v-y‖≤δ) :
    ‖u*v-x*y‖≤δ^2+δ*‖y‖+‖x‖*δ := by
  have he : u*v-x*y=((u-x)*(v-y)+(u-x)*y)+x*(v-y) := by ring
  rw [he]
  calc
    _ ≤ ‖(u-x)*(v-y)‖+‖(u-x)*y‖+‖x*(v-y)‖ :=
      (norm_add_le _ _).trans (add_le_add_right (norm_add_le _ _) _)
    _ ≤ δ^2+δ*‖y‖+‖x‖*δ := by
      simp only [norm_mul]
      have h₁ := mul_le_mul hu hv (norm_nonneg _) hδ
      have h₂ := mul_le_mul_of_nonneg_right hu (norm_nonneg y)
      have h₃ := mul_le_mul_of_nonneg_left hv (norm_nonneg x)
      nlinarith

theorem det_difference_entry_bound (A B : CMV.TransferMatrix) {δ : ℝ}
    (hδ : 0≤δ) (hentry : ∀ i j,‖A i j-B i j‖≤δ) :
    ‖A.det-B.det‖≤2*δ^2+δ*(‖B 0 0‖+‖B 0 1‖+‖B 1 0‖+‖B 1 1‖) := by
  have h₁ := product_difference_bound (A 0 0) (A 1 1) (B 0 0) (B 1 1)
    hδ (hentry 0 0) (hentry 1 1)
  have h₂ := product_difference_bound (A 0 1) (A 1 0) (B 0 1) (B 1 0)
    hδ (hentry 0 1) (hentry 1 0)
  have he : A.det-B.det=(A 0 0*A 1 1-B 0 0*B 1 1)-(A 0 1*A 1 0-B 0 1*B 1 0) := by
    rw [Matrix.det_fin_two,Matrix.det_fin_two]
    ring
  rw [he]
  exact (norm_sub_le _ _).trans (by nlinarith)

theorem scalar_distance_sign_le_square {a s : ℝ} (hs : |s|=1)
    (hnear : |a-s|≤1/2) : |a-s|≤|a^2-1| := by
  have hns := abs_le.mp hnear
  have hs' : s=1 ∨ s= -1 := (abs_eq (by norm_num : (0 : ℝ)≤1)).mp hs
  have hab := abs_le.mp (le_refl |a^2-1|)
  rcases hs' with rfl|rfl
  · rw [abs_le]
    constructor <;> nlinarith [sq_nonneg (a-1)]
  · rw [abs_le]
    constructor <;> nlinarith [sq_nonneg (a+1)]

def hermitianSeed (η : ℂ) : CMV.TransferMatrix := !![0,star η;η,0]

theorem scalar_seed_det (a ε : ℝ) (η : ℂ) :
    (((a : ℂ) • (1 : CMV.TransferMatrix)+(ε : ℂ) • hermitianSeed η).det)=
      ((a^2-ε^2*‖η‖^2 : ℝ) : ℂ) := by
  simp only [Matrix.det_fin_two,Matrix.add_apply,Matrix.smul_apply,Matrix.one_apply,
    hermitianSeed,Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,
    smul_eq_mul,Complex.star_def]
  norm_num only [Fin.zero_eta,Fin.isValue,ite_true,ite_false,mul_one,mul_zero,zero_add,add_zero]
  simp only [zero_ne_one,one_ne_zero,ite_false,mul_zero,zero_add]
  rw [show (ε : ℂ)*starRingEnd ℂ η*((ε : ℂ)*η)=(ε : ℂ)^2*(η*starRingEnd ℂ η) by ring,
    Complex.mul_conj,Complex.normSq_eq_norm_sq]
  push_cast
  ring

theorem scalar_seed_diagonal_control (A : CMV.TransferMatrix) (a s ε : ℝ) (η : ℂ)
    {δ : ℝ} (hs : |s|=1) (hnear : |a-s|≤1/2) (hε : |ε|≤1)
    (hδ : 0≤δ) (hδ1 : δ≤1) (hdet : A.det=1)
    (hentry : ∀ i j,‖A i j-((a : ℂ) • (1 : CMV.TransferMatrix)+
      (ε : ℂ) • hermitianSeed η) i j‖≤δ) :
    |a-s|≤ε^2*‖η‖^2+(6+2*‖η‖)*δ := by
  let B : CMV.TransferMatrix := (a : ℂ) • 1+(ε : ℂ) • hermitianSeed η
  have hb := det_difference_entry_bound A B hδ hentry
  have he : ‖B 0 0‖+‖B 0 1‖+‖B 1 0‖+‖B 1 1‖=2*|a|+2*|ε| *‖η‖ := by
    simp [B,hermitianSeed,Matrix.one_apply,norm_mul,Complex.norm_real,Real.norm_eq_abs]
    ring
  rw [he,hdet,scalar_seed_det] at hb
  have hb' : |1-(a^2-ε^2*‖η‖^2)|≤2*δ^2+δ*(2*|a|+2*|ε| *‖η‖) := by
    simpa only [← Complex.ofReal_one,← Complex.ofReal_sub,Complex.norm_real,Real.norm_eq_abs] using hb
  have ha : |a|≤2 := by
    have hh : |a|≤|a-s|+|s| := by simpa only [sub_add_cancel] using abs_add_le (a-s) s
    rw [hs] at hh
    linarith
  have hn := norm_nonneg η
  have heps := mul_le_mul_of_nonneg_right hε hn
  have hsmall := mul_le_mul_of_nonneg_left (show 2*|a|+2*|ε| *‖η‖≤4+2*‖η‖ by nlinarith) hδ
  have hδsq : δ^2≤δ := by nlinarith
  have hsq : |a^2-1|≤ε^2*‖η‖^2+(6+2*‖η‖)*δ := by
    have hh := abs_le.mp hb'
    apply abs_le.mpr
    constructor <;> nlinarith [mul_nonneg (sq_nonneg ε) (sq_nonneg ‖η‖)]
  exact (scalar_distance_sign_le_square hs hnear).trans hsq

end UAMO.BoundarySeed

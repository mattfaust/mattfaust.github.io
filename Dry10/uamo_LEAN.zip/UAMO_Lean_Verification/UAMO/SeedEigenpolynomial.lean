import UAMO.SeedCoefficient
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Tactic

noncomputable section
namespace UAMO
open Polynomial
open scoped BigOperators

theorem NoIntegerResonance.zpow_injective {q : ℂ} (hq0 : q ≠ 0)
    (hq : NoIntegerResonance q) : Function.Injective (fun n : ℤ => q ^ n) := by
  intro m n h
  change q ^ m = q ^ n at h
  by_contra hmn
  apply hq (m - n) (sub_ne_zero.mpr hmn)
  rw [zpow_sub₀ hq0, h, div_self (zpow_ne_zero _ hq0)]

end UAMO

import UAMO.GapHeight
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.LocalExtr.Basic

noncomputable section
namespace UAMO.GapHeightTools
open Set
open scoped Topology

theorem strictConcaveOn_of_decreasing_gap_derivative
    {L g : ℝ → ℝ} {a b : ℝ}
    (hcont : ContinuousOn L (Icc a b))
    (hderiv : ∀ x ∈ Ioo a b, HasDerivAt L (g x) x)
    (hanti : StrictAntiOn g (Ioo a b)) : StrictConcaveOn ℝ (Icc a b) L := by
  apply StrictAntiOn.strictConcaveOn_of_deriv (convex_Icc a b) hcont
  intro x hx y hy hxy
  have hx' : x ∈ Ioo a b := by simpa only [interior_Icc] using hx
  have hy' : y ∈ Ioo a b := by simpa only [interior_Icc] using hy
  rw [(hderiv x hx').deriv, (hderiv y hy').deriv]
  exact hanti hx' hy' hxy

theorem strictConcave_zero_endpoints_positive
    {L : ℝ → ℝ} {a b x : ℝ} (hab : a < b)
    (hconcave : StrictConcaveOn ℝ (Icc a b) L)
    (ha : L a = 0) (hb : L b = 0) (hx : x ∈ Ioo a b) : 0 < L x := by
  have hsegment : x ∈ openSegment ℝ a b := by
    rw [openSegment_eq_Ioo hab]
    exact hx
  have h := hconcave.lt_on_openSegment
    (show a ∈ Icc a b from ⟨le_rfl, hab.le⟩)
    (show b ∈ Icc a b from ⟨hab.le, le_rfl⟩) (ne_of_lt hab) hsegment
  simpa only [ha, hb, min_self] using h

theorem exists_unique_positive_gap_maximum
    {L g : ℝ → ℝ} {a b : ℝ} (hab : a < b)
    (hcont : ContinuousOn L (Icc a b))
    (ha : L a = 0) (hb : L b = 0)
    (hderiv : ∀ x ∈ Ioo a b, HasDerivAt L (g x) x)
    (hanti : StrictAntiOn g (Ioo a b)) :
    ∃ m ∈ Ioo a b, 0 < L m ∧ g m = 0 ∧ IsMaxOn L (Icc a b) m ∧
      (∀ x ∈ Icc a b, IsMaxOn L (Icc a b) x → x = m) ∧
      (∀ x ∈ Ioo a b, g x = 0 → x = m) := by
  have hconcave := strictConcaveOn_of_decreasing_gap_derivative hcont hderiv hanti
  obtain ⟨m, hm, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hab.le) hcont
  have hmid : (a + b) / 2 ∈ Ioo a b := by constructor <;> linarith
  have hpositive : 0 < L m :=
    (strictConcave_zero_endpoints_positive hab hconcave ha hb hmid).trans_le
      (hmax ⟨hmid.1.le, hmid.2.le⟩)
  have hma : m ≠ a := by
    intro heq
    rw [heq, ha] at hpositive
    exact (lt_irrefl (0 : ℝ)) hpositive
  have hmb : m ≠ b := by
    intro heq
    rw [heq, hb] at hpositive
    exact (lt_irrefl (0 : ℝ)) hpositive
  have hmin : m ∈ Ioo a b :=
    ⟨lt_of_le_of_ne hm.1 hma.symm, lt_of_le_of_ne hm.2 hmb⟩
  have hlocal : IsLocalMax L m := hmax.isLocalMax (Icc_mem_nhds hmin.1 hmin.2)
  have hzero : g m = 0 := hlocal.hasDerivAt_eq_zero (hderiv m hmin)
  refine ⟨m, hmin, hpositive, hzero, hmax, ?_, ?_⟩
  · intro x hx hxmax
    exact hconcave.eq_of_isMaxOn hxmax hmax hx hm
  · intro x hx hxzero
    exact hanti.injOn hx hmin (hxzero.trans hzero.symm)

end UAMO.GapHeightTools

namespace UAMO
open Set
open scoped Topology

theorem scalarGreen_strictAntiOn (a r φ : ℝ) {l u : ℝ}
    (hres : ∀ E ∈ Ioo l u, (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    StrictAntiOn (scalarGreen a r φ) (Ioo l u) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioo l u)
  · intro E hE
    exact (scalarGreen_energy_hasDerivAt a r φ E (hres E hE)).continuousAt.continuousWithinAt
  · intro E hE
    have hE' : E ∈ Ioo l u := by simpa only [interior_Ioo] using hE
    exact scalarGreen_energy_deriv_neg a r φ E (hres E hE')

theorem scalar_seed_gap_unique_positive_maximum (a r φ : ℝ) {l u : ℝ}
    (hlu : l < u)
    (hres : ∀ E ∈ Ioo l u, (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ))
    (L : ℝ → ℝ) (hL : ∀ E ∈ Ioo l u, L E = scalarLogPotential a r φ E)
    (hcont : ContinuousOn L (Icc l u)) (hl : L l = 0) (hu : L u = 0) :
    ∃ E ∈ Ioo l u,
      0 < scalarLogPotential a r φ E ∧ scalarGreen a r φ E = 0 ∧
      IsMaxOn L (Icc l u) E ∧
      (∀ x ∈ Icc l u, IsMaxOn L (Icc l u) x → x = E) ∧
      (∀ x ∈ Ioo l u, scalarGreen a r φ x = 0 → x = E) := by
  have hderiv : ∀ E ∈ Ioo l u, HasDerivAt L (scalarGreen a r φ E) E := by
    intro E hE
    have heq : L =ᶠ[𝓝 E] scalarLogPotential a r φ := by
      filter_upwards [isOpen_Ioo.mem_nhds hE] with x hx
      exact hL x hx
    exact (scalarLogPotential_energy_hasDerivAt a r φ E (hres E hE)).congr_of_eventuallyEq heq
  obtain ⟨E,hE,hpos,hzero,hmax,huniq,hzeroUniq⟩ :=
    GapHeightTools.exists_unique_positive_gap_maximum hlu hcont hl hu hderiv
      (scalarGreen_strictAntiOn a r φ hres)
  exact ⟨E,hE,by simpa only [hL E hE] using hpos,hzero,hmax,huniq,hzeroUniq⟩

end UAMO

import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Basic
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Isometric
import Mathlib.Analysis.CStarAlgebra.Spectrum
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.Topology.Algebra.Polynomial
import Mathlib.MeasureTheory.Integral.RieszMarkovKakutani.Real
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
import Mathlib.MeasureTheory.Function.LocallyIntegrable
import Mathlib.Tactic

noncomputable section
namespace UAMO.SpectralMoments
open MeasureTheory CompactlySupported Set
open scoped ContinuousFunctionalCalculus Polynomial Topology

theorem exists_polynomial_uniform_approximation (K : Set ℝ) (hK : IsCompact K)
    (f : ℝ → ℝ) (hf : ContinuousOn f K) (epsilon : ℝ) (hepsilon : 0 < epsilon) :
    ∃ p : ℝ[X], ∀ x ∈ K, ‖f x - p.eval x‖ < epsilon := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK
  let F : C(K, ℝ) := ⟨fun x => f x, hf.restrict⟩
  have hmem : F ∈ (polynomialFunctions K).topologicalClosure := by
    rw [polynomialFunctions.topologicalClosure]
    trivial
  change F ∈ closure (polynomialFunctions K : Set C(K, ℝ)) at hmem
  obtain ⟨G, hG, hdist⟩ := Metric.mem_closure_iff.mp hmem epsilon hepsilon
  rw [polynomialFunctions_coe] at hG
  obtain ⟨p, rfl⟩ := hG
  refine ⟨p, fun x hx => ?_⟩
  have hpoint := ContinuousMap.norm_coe_le_norm
    (F - Polynomial.toContinuousMapOnAlgHom K p) (⟨x, hx⟩ : K)
  have hpoint' : ‖f x - p.eval x‖ ≤ ‖F - Polynomial.toContinuousMapOnAlgHom K p‖ := hpoint
  exact hpoint'.trans_lt (by simpa only [dist_eq_norm] using hdist)

theorem integrable_continuous_of_probability_mass_Icc
    (μ : ProbabilityMeasure ℝ) (a b : ℝ)
    (hμ : (μ : Measure ℝ) (Icc a b) = 1)
    (f : ℝ → ℝ) (hf : Continuous f) : Integrable f (μ : Measure ℝ) := by
  have hae : ∀ᵐ x ∂(μ : Measure ℝ), x ∈ Icc a b :=
    (mem_ae_iff_prob_eq_one measurableSet_Icc).mpr hμ
  have hi : IntegrableOn f (Icc a b) (μ : Measure ℝ) :=
    ContinuousOn.integrableOn_compact isCompact_Icc hf.continuousOn
  simpa only [IntegrableOn, Measure.restrict_eq_self_of_ae_mem hae] using hi

theorem probabilityMeasure_eq_of_compact_moments
    (μ ν : ProbabilityMeasure ℝ) (a b : ℝ)
    (hμ : (μ : Measure ℝ) (Icc a b) = 1)
    (hν : (ν : Measure ℝ) (Icc a b) = 1)
    (hmom : ∀ k : ℕ,
      ∫ x : ℝ, x ^ k ∂(μ : Measure ℝ) = ∫ x : ℝ, x ^ k ∂(ν : Measure ℝ)) :
    μ = ν := by
  have hμae : ∀ᵐ x ∂(μ : Measure ℝ), x ∈ Icc a b :=
    (mem_ae_iff_prob_eq_one measurableSet_Icc).mpr hμ
  have hνae : ∀ᵐ x ∂(ν : Measure ℝ), x ∈ Icc a b :=
    (mem_ae_iff_prob_eq_one measurableSet_Icc).mpr hν
  have hpoly (p : ℝ[X]) :
      ∫ x, p.eval x ∂(μ : Measure ℝ) = ∫ x, p.eval x ∂(ν : Measure ℝ) := by
    induction p using Polynomial.induction_on' with
    | add p q hp hq =>
      simp only [Polynomial.eval_add]
      rw [integral_add
        (integrable_continuous_of_probability_mass_Icc μ a b hμ _ p.continuous)
        (integrable_continuous_of_probability_mass_Icc μ a b hμ _ q.continuous),
        integral_add
        (integrable_continuous_of_probability_mass_Icc ν a b hν _ p.continuous)
        (integrable_continuous_of_probability_mass_Icc ν a b hν _ q.continuous), hp, hq]
    | monomial k c =>
      simp only [Polynomial.eval_monomial, integral_const_mul, hmom]
  apply ProbabilityMeasure.toMeasure_injective
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  apply sub_eq_zero.mp
  apply norm_eq_zero.mp
  apply le_antisymm _ (norm_nonneg _)
  apply le_of_forall_pos_le_add
  intro epsilon hepsilon
  obtain ⟨p, hp⟩ := exists_polynomial_uniform_approximation (Icc a b) isCompact_Icc
    f f.continuous.continuousOn (epsilon / 2) (by linarith)
  have hμbound :
      ‖(∫ x, f x ∂(μ : Measure ℝ)) - ∫ x, p.eval x ∂(μ : Measure ℝ)‖ ≤ epsilon / 2 := by
    rw [← integral_sub
      (integrable_continuous_of_probability_mass_Icc μ a b hμ _ f.continuous)
      (integrable_continuous_of_probability_mass_Icc μ a b hμ _ p.continuous)]
    have h := norm_integral_le_of_norm_le_const (μ := (μ : Measure ℝ))
      (hμae.mono (fun x hx => (hp x hx).le))
    simpa using h
  have hνbound :
      ‖(∫ x, f x ∂(ν : Measure ℝ)) - ∫ x, p.eval x ∂(ν : Measure ℝ)‖ ≤ epsilon / 2 := by
    rw [← integral_sub
      (integrable_continuous_of_probability_mass_Icc ν a b hν _ f.continuous)
      (integrable_continuous_of_probability_mass_Icc ν a b hν _ p.continuous)]
    have h := norm_integral_le_of_norm_le_const (μ := (ν : Measure ℝ))
      (hνae.mono (fun x hx => (hp x hx).le))
    simpa using h
  calc
    _ ≤ ‖(∫ x, f x ∂(μ : Measure ℝ)) - ∫ x, p.eval x ∂(μ : Measure ℝ)‖ +
        ‖(∫ x, p.eval x ∂(μ : Measure ℝ)) - ∫ x, f x ∂(ν : Measure ℝ)‖ :=
      norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ = ‖(∫ x, f x ∂(μ : Measure ℝ)) - ∫ x, p.eval x ∂(μ : Measure ℝ)‖ +
        ‖(∫ x, f x ∂(ν : Measure ℝ)) - ∫ x, p.eval x ∂(ν : Measure ℝ)‖ := by
      rw [hpoly p, norm_sub_rev (∫ x, p.eval x ∂(ν : Measure ℝ))]
    _ ≤ epsilon / 2 + epsilon / 2 := add_le_add hμbound hνbound
    _ = 0 + epsilon := by linarith

structure FaithfulTracialState (A : Type*) [CStarAlgebra A] where
  functional : A →L[ℝ] ℝ
  normalized : functional 1 = 1
  positive : ∀ a : A, 0 ≤ functional (star a * a)
  faithful : ∀ a : A, functional (star a * a) = 0 → a = 0
  cyclic : ∀ a b : A, functional (a * b) = functional (b * a)

section SpectralConstruction
variable {A : Type*} [CStarAlgebra A]
variable (τ : FaithfulTracialState A) (H : A) (hH : IsSelfAdjoint H)

abbrev RealSpectrum : Type _ := spectrum ℝ H

private def compactTestToContinuous {X : Type*} [TopologicalSpace X] :
    C_c(X, ℝ) →ₗ[ℝ] C(X, ℝ) where
  toFun := fun f => f.toContinuousMap
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

def spectralFunctional : C_c(RealSpectrum H, ℝ) →ₗ[ℝ] ℝ :=
  τ.functional.toLinearMap.comp ((cfcL hH).toLinearMap.comp compactTestToContinuous)

set_option maxHeartbeats 800000 in
theorem spectralFunctional_nonneg (f : C_c(RealSpectrum H, ℝ)) (hf : 0 ≤ f) :
    0 ≤ spectralFunctional τ H hH f := by
  let g : C(RealSpectrum H, ℝ) :=
    ⟨fun x => Real.sqrt (f x), Real.continuous_sqrt.comp f.continuous⟩
  have hsq : g * g = f.toContinuousMap := by
    ext x
    exact Real.mul_self_sqrt (hf x)
  have hfact : cfcHom hH f.toContinuousMap = star (cfcHom hH g) * cfcHom hH g := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul, hsq]
  change 0 ≤ τ.functional (cfcHom hH f.toContinuousMap)
  rw [hfact]
  exact τ.positive _

def spectralMeasure : Measure (RealSpectrum H) :=
  RealRMK.rieszMeasure (spectralFunctional_nonneg τ H hH)

theorem spectralMeasure_integral (f : C(RealSpectrum H, ℝ)) :
    ∫ x, f x ∂spectralMeasure τ H hH = τ.functional (cfcHom hH f) := by
  let fc : C_c(RealSpectrum H, ℝ) :=
    { toContinuousMap := f
      hasCompactSupport' := HasCompactSupport.of_compactSpace f }
  exact RealRMK.integral_rieszMeasure (spectralFunctional_nonneg τ H hH) fc

instance spectralMeasure_isProbabilityMeasure : IsProbabilityMeasure (spectralMeasure τ H hH) := by
  constructor
  apply (ENNReal.toReal_eq_one_iff _).mp
  have h := spectralMeasure_integral τ H hH (1 : C(RealSpectrum H, ℝ))
  simpa only [ContinuousMap.one_apply, integral_const, smul_eq_mul, mul_one,
    map_one, τ.normalized, measureReal_def] using h

def realSpectralMeasure : Measure ℝ :=
  (spectralMeasure τ H hH).map (fun x : RealSpectrum H => (x : ℝ))

instance realSpectralMeasure_isProbabilityMeasure : IsProbabilityMeasure (realSpectralMeasure τ H hH) :=
  isProbabilityMeasure_map continuous_subtype_val.measurable.aemeasurable

theorem realSpectralMeasure_integral_eq_subtype (f : ℝ → ℝ) :
    ∫ x, f x ∂realSpectralMeasure τ H hH =
      ∫ x : RealSpectrum H, f x ∂spectralMeasure τ H hH := by
  rw [realSpectralMeasure]
  exact (MeasurableEmbedding.subtype_coe (spectrum.isClosed (𝕜 := ℝ) H).measurableSet).integral_map f

theorem realSpectralMeasure_integral_cfc (f : ℝ → ℝ) (hf : Continuous f) :
    ∫ x, f x ∂realSpectralMeasure τ H hH = τ.functional (cfc f H) := by
  rw [realSpectralMeasure_integral_eq_subtype, cfc_apply f H hH hf.continuousOn]
  exact spectralMeasure_integral τ H hH ⟨_, hf.comp continuous_subtype_val⟩

theorem realSpectralMeasure_moment (k : ℕ) :
    ∫ x : ℝ, x ^ k ∂realSpectralMeasure τ H hH = τ.functional (H ^ k) := by
  rw [realSpectralMeasure_integral_cfc τ H hH (fun x : ℝ => x ^ k) (continuous_id.pow k),
    cfc_pow_id H k hH]

def energyBump (E ε x : ℝ) : ℝ := max 0 (ε - |x - E|)

theorem continuous_energyBump (E ε : ℝ) : Continuous (energyBump E ε) := by
  unfold energyBump
  fun_prop

set_option maxHeartbeats 800000 in

theorem realSpectralMeasure_ball_pos_of_mem (E : ℝ) (hE : E ∈ spectrum ℝ H)
    {ε : ℝ} (he : 0 < ε) :
    0 < realSpectralMeasure τ H hH (Metric.ball E ε) := by
  by_contra hpos
  have hmass : realSpectralMeasure τ H hH (Metric.ball E ε) = 0 :=
    le_antisymm (le_of_not_gt hpos) (zero_le _)
  have hout : ∀ᵐ x ∂realSpectralMeasure τ H hH, x ∉ Metric.ball E ε := by
    apply ae_iff.mpr
    simpa only [not_not, Set.setOf_mem_eq] using hmass
  have hzero : (fun x => energyBump E ε x * energyBump E ε x)
      =ᵐ[realSpectralMeasure τ H hH] (fun _ => (0 : ℝ)) := by
    filter_upwards [hout] with x hx
    have hx' : ε ≤ |x - E| := by
      simpa only [Metric.mem_ball, Real.dist_eq, not_lt] using hx
    simp only [energyBump, max_eq_left (sub_nonpos.mpr hx'), zero_mul]
  let g : C(RealSpectrum H, ℝ) :=
    ⟨fun x => energyBump E ε x, (continuous_energyBump E ε).comp continuous_subtype_val⟩
  have htrace : τ.functional (star (cfcHom hH g) * cfcHom hH g) = 0 := by
    rw [(cfcHom_predicate hH g).star_eq, ← map_mul]
    have hint := realSpectralMeasure_integral_cfc τ H hH
      (fun x => energyBump E ε x * energyBump E ε x)
      ((continuous_energyBump E ε).mul (continuous_energyBump E ε))
    rw [integral_congr_ae hzero, integral_zero] at hint
    rw [cfc_apply _ H hH ((continuous_energyBump E ε).mul
      (continuous_energyBump E ε)).continuousOn] at hint
    exact hint.symm
  have hg : g = 0 := by
    apply (cfcHom_isClosedEmbedding hH).injective
    rw [map_zero]
    exact τ.faithful _ htrace
  have hvalue := congrArg (fun f : C(RealSpectrum H, ℝ) => f ⟨E, hE⟩) hg
  have : ε = 0 := by
    simpa only [g, ContinuousMap.coe_mk, sub_self, abs_zero, sub_zero,
      energyBump, max_eq_right he.le, ContinuousMap.zero_apply] using hvalue
  exact he.ne' this

theorem realSpectralMeasure_spectrum_compl :
    realSpectralMeasure τ H hH (spectrum ℝ H)ᶜ = 0 := by
  rw [realSpectralMeasure, Measure.map_apply continuous_subtype_val.measurable
    (spectrum.isClosed H).measurableSet.compl]
  have hempty : (fun x : RealSpectrum H => (x : ℝ)) ⁻¹' (spectrum ℝ H)ᶜ = ∅ := by
    ext x
    simp
  rw [hempty, measure_empty]

def measureSupport : Set ℝ :=
  {E | ∀ ε > 0, 0 < realSpectralMeasure τ H hH (Metric.ball E ε)}

theorem measureSupport_eq_spectrum : measureSupport τ H hH = spectrum ℝ H := by
  apply Set.Subset.antisymm
  · intro E hE
    by_contra hnot
    obtain ⟨ε, he, hball⟩ := Metric.isOpen_iff.mp (spectrum.isClosed H).isOpen_compl E hnot
    have hzero : realSpectralMeasure τ H hH (Metric.ball E ε) = 0 :=
      le_antisymm ((measure_mono hball).trans_eq
        (realSpectralMeasure_spectrum_compl τ H hH)) (zero_le _)
    exact (ne_of_gt (hE ε he)) hzero
  · intro E hE ε he
    exact realSpectralMeasure_ball_pos_of_mem τ H hH E hE he

theorem realSpectralMeasure_window [Nontrivial A] {R : ℝ} (hbound : ‖H‖ ≤ R) :
    realSpectralMeasure τ H hH (Icc (-R) R) = 1 := by
  rw [realSpectralMeasure, Measure.map_apply continuous_subtype_val.measurable measurableSet_Icc]
  have hpre : (fun x : RealSpectrum H => (x : ℝ)) ⁻¹' Icc (-R) R = univ := by
    apply Set.eq_univ_of_forall
    intro x
    have hn : ‖(x : ℝ)‖ ≤ R := (spectrum.norm_le_norm_of_mem x.property).trans hbound
    exact abs_le.mp hn
  rw [hpre, measure_univ]

end SpectralConstruction

section MomentComparison
variable {A B : Type*} [CStarAlgebra A] [CStarAlgebra B] [Nontrivial A] [Nontrivial B]
variable (τ : FaithfulTracialState A) (σ : FaithfulTracialState B)
variable (H : A) (K : B) (hH : IsSelfAdjoint H) (hK : IsSelfAdjoint K)

theorem realSpectralMeasure_eq_of_moments
    (hmom : ∀ n : ℕ, τ.functional (H ^ n) = σ.functional (K ^ n)) :
    realSpectralMeasure τ H hH = realSpectralMeasure σ K hK := by
  let μ : ProbabilityMeasure ℝ := ⟨realSpectralMeasure τ H hH, inferInstance⟩
  let ν : ProbabilityMeasure ℝ := ⟨realSpectralMeasure σ K hK, inferInstance⟩
  have hμ : (μ : Measure ℝ) (Icc (-(max ‖H‖ ‖K‖)) (max ‖H‖ ‖K‖)) = 1 :=
    realSpectralMeasure_window τ H hH (le_max_left _ _)
  have hν : (ν : Measure ℝ) (Icc (-(max ‖H‖ ‖K‖)) (max ‖H‖ ‖K‖)) = 1 :=
    realSpectralMeasure_window σ K hK (le_max_right _ _)
  have heq : μ = ν := by
    apply probabilityMeasure_eq_of_compact_moments μ ν _ _ hμ hν
    intro n
    change (∫ x : ℝ, x ^ n ∂realSpectralMeasure τ H hH) =
      ∫ x : ℝ, x ^ n ∂realSpectralMeasure σ K hK
    rw [realSpectralMeasure_moment, realSpectralMeasure_moment, hmom]
  exact congrArg (fun ρ : ProbabilityMeasure ℝ => (ρ : Measure ℝ)) heq

include hH hK in

theorem realSpectrum_eq_of_moments
    (hmom : ∀ n : ℕ, τ.functional (H ^ n) = σ.functional (K ^ n)) :
    spectrum ℝ H = spectrum ℝ K := by
  rw [← measureSupport_eq_spectrum τ H hH, ← measureSupport_eq_spectrum σ K hK]
  unfold measureSupport
  rw [realSpectralMeasure_eq_of_moments τ σ H K hH hK hmom]

include hH hK in

theorem spectrum_eq_of_moments
    (hmom : ∀ n : ℕ, τ.functional (H ^ n) = σ.functional (K ^ n)) :
    spectrum ℂ H = spectrum ℂ K := by
  have hr := realSpectrum_eq_of_moments τ σ H K hH hK hmom
  ext z
  constructor
  · intro hz
    rw [hH.mem_spectrum_eq_re hz]
    have hx : z.re ∈ spectrum ℝ H := by
      apply (spectrum.algebraMap_mem_iff ℂ).mp
      change (z.re : ℂ) ∈ spectrum ℂ H
      rwa [← hH.mem_spectrum_eq_re hz]
    exact (spectrum.algebraMap_mem_iff ℂ).mpr (hr ▸ hx)
  · intro hz
    rw [hK.mem_spectrum_eq_re hz]
    have hx : z.re ∈ spectrum ℝ K := by
      apply (spectrum.algebraMap_mem_iff ℂ).mp
      change (z.re : ℂ) ∈ spectrum ℂ K
      rwa [← hK.mem_spectrum_eq_re hz]
    exact (spectrum.algebraMap_mem_iff ℂ).mpr (hr.symm ▸ hx)

end MomentComparison
end UAMO.SpectralMoments

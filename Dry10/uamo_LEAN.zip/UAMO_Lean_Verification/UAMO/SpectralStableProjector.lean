import UAMO.GreenStableDynamics
import UAMO.GreenProjectionContinuity
import UAMO.StableProjectorOrthogonalization
import UAMO.RealCocycleResolvent
import UAMO.PhysicalPhaseSpectrum

noncomputable section
namespace UAMO
open Matrix CMV PhysicalRepresentation StablePlane
open scoped Matrix Topology

theorem physical_gap_exists_continuous_stable_projector {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r<1) (hα : Irrational α)
    (t θ₀ : ℝ)
    (hres : Complex.exp ((t:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α θ₀)) :
    ∃P:ℝ→PlaneMatrix,Continuous P ∧
      (∀x,(P x).transpose=P x) ∧ (∀x,P x*P x=P x) ∧
      (∀x,P x 0 0+P x 1 1=1) ∧
      ∀x v,IsStable (fun y => realTransfer a (coupling r) t (2*Real.pi*y)) α x (P x*ᵥv) := by
  have hlam : 0≤coupling r := by unfold coupling; positivity
  have hlam1 := coupling_lt_one_of_lt_one hr1
  obtain ⟨C,hC,hb⟩ := complexRealTransfer_bounded a hlam hlam1 t
  let R := fun x => realTransfer a (coupling r) t (2*Real.pi*x)
  let A := fun x (n:ℤ) => (R (x+(n:ℝ)*α)).map Complex.ofReal
  have hA : ∀x n i j,‖A x n i j‖≤C := fun x n => hb (2*Real.pi*(x+(n:ℝ)*α))
  let D := fun x => latticeDifference (A x) C hC (hA x)
  have hDeq (x : ℝ) : D x=latticeDifference
      (fun n => complexRealTransfer a (coupling r) t (phaseAngle α x n)) C hC
      (fun n => hb (phaseAngle α x n)) := by
    ext i j ψ n
    simp [D,A,R,latticeDifference,latticeMatrixMultiplier,complexRealTransfer,phaseAngle,add_comm]
  have hres_all (x : ℝ) : Complex.exp ((t:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling a) (coupling r) α x) := by
    have he := walk_spectrum_phase_independent hα (coupling a) (coupling r) x θ₀
    have hn : Complex.exp ((t:ℂ)*Complex.I)∉spectrum ℂ
        (PhysicalRepresentation.walk (coupling a) (coupling r) α θ₀) := by
      simpa only [spectrum,Set.mem_compl_iff,not_not] using hres
    rw [← he] at hn
    simpa only [spectrum,Set.mem_compl_iff,not_not] using hn
  have hD : ∀x,IsUnit (D x) := by
    intro x
    rw [hDeq]
    exact (physicalWalk_resolvent_iff_real_latticeDifference ha ha1 hr hr1 α x t C hC
      (fun n => hb (phaseAngle α x n))).mp (hres_all x)
  have hcD : Continuous (fun x => CStarMatrix.ofMatrix (D x)) := by
    have hc := continuous_real_latticeDifference a hlam hlam1 t α C hC hb
    simpa only [← hDeq] using hc
  let P := fun x => greenStableRealMatrix (D x) 0
  have hcP : Continuous P := by
    apply continuous_iff_continuousAt.mpr
    intro x
    exact continuousAt_greenStableRealMatrix D x hcD.continuousAt (hD x) 0
  have hreal (x : ℝ) : ∀n i j,star (A x n i j)=A x n i j := by
    intros
    simp [A]
  have hmap (x : ℝ) : (P x).map Complex.ofReal=greenStableMatrix (D x) 0 :=
    greenStableRealMatrix_map (A x) C hC (hA x) (hreal x) (hD x) 0
  have hdet (x : ℝ) : ∀n,(A x n).det=1 := by
    intro n
    exact complexRealTransfer_det ha.ne' hlam hlam1 t _
  have hPn : ∀x,P x≠0 := by
    intro x hx
    have hz := congrArg (fun M : PlaneMatrix => M.map Complex.ofReal) hx
    dsimp only at hz
    rw [hmap] at hz
    have hz' : greenStableMatrix (D x) 0=0 := by simpa using hz
    exact greenStableMatrix_ne_zero (A x) C hC (hA x) (hD x) (hdet x) 0 hz'
  have hPd : ∀x,(P x).det=0 := by
    intro x
    have hd := greenStableMatrix_det_zero (A x) C hC (hA x) (hD x) (hdet x) 0
    rw [← hmap] at hd
    have he : (((P x).det:ℝ):ℂ)=0 := by
      simpa only [Matrix.det_fin_two,Matrix.map_apply,Complex.ofReal_sub,Complex.ofReal_mul] using hd
    exact Complex.ofReal_eq_zero.mp he
  have hstable : ∀x v,IsStable R α x (P x*ᵥv) := by
    intro x v
    exact greenStableRealMatrix_image_isStable R α x C hC (hA x) (hD x) v
  refine ⟨fun x => orthogonalRangeProjector (P x),
    continuous_orthogonalRangeProjector P hcP hPn,
    fun x => orthogonalRangeProjector_transpose (P x),
    fun x => orthogonalRangeProjector_idempotent (hPn x) (hPd x),
    fun x => orthogonalRangeProjector_trace (hPn x),?_⟩
  intro x v
  exact orthogonalRangeProjector_stable_image R α x (P x) (hstable x) v

theorem boundary_physical_gap_odd_stable_degree {r α : ℝ} (hr : 0≤r)
    (hr1 : r<1) (hα : Irrational α) (t θ₀ : ℝ)
    (hres : Complex.exp ((t:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk 1 (coupling r) α θ₀)) :
    ∃θ:ℝ→ℝ,Continuous θ ∧
      (∀x,IsStable (fun y => realTransfer 1 (coupling r) t (2*Real.pi*y)) α x
        (angleVector (θ x))) ∧
      ∃m:ℤ,Odd m ∧ stableAngleDegree θ=(m:ℝ) := by
  have hres' : Complex.exp ((t:ℂ)*Complex.I)∈resolventSet ℂ
      (PhysicalRepresentation.walk (coupling 1) (coupling r) α θ₀) := by
    simpa only [show coupling 1=1 by norm_num [coupling]] using hres
  obtain ⟨P,hP,hsym,hid,htr,hs⟩ := physical_gap_exists_continuous_stable_projector
    (by norm_num : (0:ℝ)<1) (by norm_num) hr hr1 hα t θ₀ hres'
  exact StableAngleLift.boundary_stable_projector_odd_degree
    (by unfold coupling; positivity) (coupling_lt_one_of_lt_one hr1) t α P hP hsym hid htr hs

end UAMO

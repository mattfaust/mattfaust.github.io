import Mathlib.Algebra.Star.Module
import Mathlib.Data.Real.Star
import Mathlib.Data.Complex.Module
import Mathlib.Tactic.Module
import Mathlib.Tactic.NoncommRing

namespace UAMO

section StarRing
variable {R : Type*} [Ring R] [StarRing R]

theorem star_square_add (A B : R) :
    star (A + B) * (A + B) =
      (star A * A + star B * B) + (star A * B + star B * A) := by
  rw [star_add]
  noncomm_ring

end StarRing

section RealStarAlgebra
variable {R : Type*} [Ring R] [StarRing R] [Algebra ℝ R] [StarModule ℝ R]

def overlapCore (a r : ℝ) (U V : R) : R := 1 - (a * r) • (V * U)

def overlapLinear (a r : ℝ) (U V : R) : R := a • U + r • star V

theorem overlap_diagonal_sum (a r : ℝ) (U V : R)
    (hU : star U * U = 1) (hV : star V * V = 1) (hV' : V * star V = 1) :
    star (overlapCore a r U V) * overlapCore a r U V +
      star (overlapLinear a r U V) * overlapLinear a r U V =
        ((1 + a ^ 2) * (1 + r ^ 2)) • (1 : R) := by
  have hVU : star (V * U) * (V * U) = 1 := by
    rw [star_mul]
    calc
      star U * star V * (V * U) = star U * (star V * V) * U := by noncomm_ring
      _ = 1 := by rw [hV, mul_one, hU]
  simp only [overlapCore, overlapLinear, star_sub, star_add, star_one, star_smul,
    star_trivial, star_star, sub_mul, mul_sub, add_mul, mul_add, smul_mul_assoc,
    mul_smul_comm, smul_smul, one_mul, mul_one, hVU, hU, hV']
  rw [star_mul]
  module

theorem overlap_cross_term (a r : ℝ) (U V : R) :
    star (overlapCore a r U V) * overlapLinear a r U V +
        star (overlapLinear a r U V) * overlapCore a r U V =
      a • (U + star U) + r • (V + star V) -
        (a ^ 2 * r) • (star U * V * U + star U * star V * U) -
        (a * r ^ 2) • (V ^ 2 * U + star U * star V ^ 2) := by
  simp only [overlapCore, overlapLinear, star_sub, star_add, star_one, star_smul,
    star_trivial, star_star, star_mul, sub_mul, mul_sub, add_mul, mul_add,
    smul_mul_assoc, mul_smul_comm, smul_smul, one_mul, mul_one, pow_two, mul_assoc]
  module

theorem completed_square_plus (a r : ℝ) (U V : R)
    (hU : star U * U = 1) (hV : star V * V = 1) (hV' : V * star V = 1) :
    star (overlapCore a r U V + overlapLinear a r U V) *
        (overlapCore a r U V + overlapLinear a r U V) =
      ((1 + a ^ 2) * (1 + r ^ 2)) • (1 : R) +
        (star (overlapCore a r U V) * overlapLinear a r U V +
          star (overlapLinear a r U V) * overlapCore a r U V) := by
  rw [star_square_add, overlap_diagonal_sum a r U V hU hV hV']

end RealStarAlgebra

section ComplexWeyl
variable {R : Type*} [Ring R] [StarRing R] [Algebra ℂ R]

variable [StarModule ℂ R]

end ComplexWeyl
end UAMO

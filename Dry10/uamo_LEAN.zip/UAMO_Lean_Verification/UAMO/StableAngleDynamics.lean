import UAMO.RealTransferAngleLift
import UAMO.BoundaryStableParity

noncomputable section
namespace UAMO.ProjectiveAngle
open Matrix StablePlane

theorem wedge_angleVector (s t : ℝ) :
    wedge (angleVector s) (angleVector t)=Real.sin (t-s) := by
  simp only [wedge,angleVector,Matrix.cons_val_zero,Matrix.cons_val_one,
    Matrix.cons_val_fin_one,Real.sin_sub]
  ring

theorem continuous_parallel_angle_difference (f g : ℝ→ℝ)
    (hf : Continuous f) (hg : Continuous g)
    (hw : ∀x:ℝ,wedge (angleVector (g x)) (angleVector (f x))=0) :
    ∃k:ℤ,∀x:ℝ,f x=g x+(k:ℝ)*Real.pi := by
  let d : ℝ→ℝ := fun x => (f x-g x)/Real.pi
  have hd : Continuous d := (hf.sub hg).div_const _
  have hint (x : ℝ) : ∃k:ℤ,d x=(k:ℝ) := by
    have hs : Real.sin (f x-g x)=0 := by rw [← wedge_angleVector]; exact hw x
    obtain ⟨k,hk⟩ := Real.sin_eq_zero_iff.mp hs
    refine ⟨k,?_⟩
    dsimp only [d]
    rw [← hk,mul_div_cancel_right₀ _ Real.pi_ne_zero]
  obtain ⟨k,hk⟩ := continuous_integer_valued_constant d hd hint
  refine ⟨k,fun x => ?_⟩
  have h := (div_eq_iff Real.pi_ne_zero).mp (hk x)
  linarith

theorem realTransfer_stable_angle_step {a lam : ℝ} (ha : 0<a)
    (hlam : 0≤lam) (hlam1 : lam<1) (t α : ℝ) (θ : ℝ→ℝ) (hθ : Continuous θ)
    (hstable : ∀x:ℝ,IsStable (fun y => realTransfer a lam t (2*Real.pi*y)) α x
      (angleVector (θ x))) :
    ∃k:ℤ,∀x:ℝ,realTransferAngleLift a lam t (2*Real.pi*x) (θ x)=
      θ (x+α)+(k:ℝ)*Real.pi := by
  have hF : Continuous (fun x:ℝ => realTransferAngleLift a lam t (2*Real.pi*x) (θ x)) :=
    (continuous_realTransferAngleLift ha hlam hlam1).comp
      (show Continuous (fun x:ℝ => (t,2*Real.pi*x,θ x)) from by fun_prop)
  apply continuous_parallel_angle_difference _ _ hF (hθ.comp (continuous_id.add continuous_const))
  intro x
  obtain ⟨c,_,hc⟩ := realTransferAngleLift_direction ha hlam hlam1 t (2*Real.pi*x) (θ x)
  have hstep : IsStable (fun y => realTransfer a lam t (2*Real.pi*y)) α (x+α)
      (realTransfer a lam t (2*Real.pi*x)*ᵥangleVector (θ x)) :=
    (isStable_step_iff _ α x _).mpr (hstable x)
  have hscaled : IsStable (fun y => realTransfer a lam t (2*Real.pi*y)) α (x+α)
      (angleVector (realTransferAngleLift a lam t (2*Real.pi*x) (θ x))) := by
    rw [hc]
    exact (stableSubspace _ α (x+α)).smul_mem c hstep
  exact stable_wedge_eq_zero _
    (fun y => realTransfer_det ha.ne' hlam hlam1 t (2*Real.pi*y)) α (x+α)
    (hstable (x+α)) hscaled

theorem boundary_stable_angle_integer_dynamics {lam : ℝ}
    (hlam : 0≤lam) (hlam1 : lam<1) (t α : ℝ) (θ : ℝ→ℝ) (hθ : Continuous θ)
    (hstable : ∀x:ℝ,IsStable (fun y => realTransfer 1 lam t (2*Real.pi*y)) α x
      (angleVector (θ x))) :
    ∃m k:ℤ,Odd m ∧ (∀x:ℝ,θ (x+1)=θ x+(m:ℝ)*Real.pi) ∧
      (∀x:ℝ,realTransferAngleLift 1 lam t (2*Real.pi*x) (θ x)=
        θ (x+α)+(k:ℝ)*Real.pi) := by
  obtain ⟨j,hj⟩ := boundary_stable_angle_odd_winding_period_one hlam hlam1 t α θ hθ hstable
  obtain ⟨k,hk⟩ := realTransfer_stable_angle_step (by norm_num : (0:ℝ)<1)
    hlam hlam1 t α θ hθ hstable
  refine ⟨2*j+1,k,⟨j,by ring⟩,?_,hk⟩
  intro x
  have h := hj x
  push_cast
  linarith

end UAMO.ProjectiveAngle

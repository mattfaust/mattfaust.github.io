import UAMO.BoundaryStableParity
import Mathlib.Topology.Homotopy.Lifting
import Mathlib.Analysis.Convex.Contractible
import Mathlib.Topology.Algebra.Module.LocallyConvex
import Mathlib.Analysis.SpecialFunctions.Complex.Circle

noncomputable section
namespace UAMO.StableAngleLift
open Set Topology Filter Matrix StablePlane
open scoped Topology

section AdditiveCircleCover
variable (p : ℝ) [Fact (0<p)]

def circleSection (a : ℝ) (u : AddCircle p) : ℝ := (AddCircle.equivIco p a u).1

@[simp] theorem circleSection_coe (a : ℝ) (u : AddCircle p) :
    ((circleSection p a u : ℝ) : AddCircle p)=u :=
  (AddCircle.equivIco p a).symm_apply_apply u

theorem circleSection_continuousAt (a : ℝ) {u : AddCircle p} (hu : u≠(a : AddCircle p)) :
    ContinuousAt (circleSection p a) u :=
  continuousAt_subtype_val.comp (AddCircle.continuousAt_equivIco p a hu)

def circleRemainder (a x : ℝ) : AddSubgroup.zmultiples p :=
  ⟨x-circleSection p a (x : AddCircle p),by
    apply (QuotientAddGroup.eq_zero_iff _).mp
    rw [AddCircle.coe_sub,circleSection_coe,sub_self]⟩

omit [Fact (0<p)] in
@[simp] theorem circleKernel_coe (k : AddSubgroup.zmultiples p) :
    ((k : ℝ) : AddCircle p)=0 := (QuotientAddGroup.eq_zero_iff _).mpr k.property

def circleCoverTrivialization (a : ℝ) :
    Trivialization (AddSubgroup.zmultiples p) ((↑) : ℝ→AddCircle p) where
  toFun x := ((x : AddCircle p),circleRemainder p a x)
  invFun u := circleSection p a u.1+(u.2 : ℝ)
  source := {x : ℝ | (x : AddCircle p)≠(a : AddCircle p)}
  target := {(a : AddCircle p)}ᶜ ×ˢ univ
  map_source' := by intro x hx; exact ⟨hx,mem_univ _⟩
  map_target' := by
    intro u hu
    change ((circleSection p a u.1+(u.2 : ℝ) : ℝ) : AddCircle p)≠(a : AddCircle p)
    simpa only [AddCircle.coe_add,circleSection_coe,circleKernel_coe,add_zero] using hu.1
  left_inv' := by intro x hx; dsimp only [circleRemainder]; ring
  right_inv' := by
    intro u hu
    apply Prod.ext
    · simp only [AddCircle.coe_add,circleSection_coe,circleKernel_coe,add_zero]
    · apply Subtype.ext
      dsimp only [circleRemainder]
      simp only [AddCircle.coe_add,circleSection_coe,circleKernel_coe,add_zero]
      ring
  open_source := isOpen_compl_singleton.preimage (AddCircle.continuous_mk' p)
  open_target := isOpen_compl_singleton.prod isOpen_univ
  continuousOn_toFun := by
    apply continuousOn_of_forall_continuousAt
    intro x hx
    have hs : ContinuousAt (fun y : ℝ => circleSection p a (y : AddCircle p)) x :=
      (circleSection_continuousAt p a hx).comp (AddCircle.continuous_mk' p).continuousAt
    have hr : ContinuousAt (circleRemainder p a) x :=
      ContinuousAt.codRestrict (fun y => (circleRemainder p a y).property)
        (continuousAt_id.sub hs)
    exact (AddCircle.continuous_mk' p).continuousAt.prodMk hr
  continuousOn_invFun := by
    apply continuousOn_of_forall_continuousAt
    intro u hu
    exact ((circleSection_continuousAt p a hu.1).comp continuousAt_fst).add
      (continuousAt_subtype_val.comp continuousAt_snd)
  baseSet := {(a : AddCircle p)}ᶜ
  open_baseSet := isOpen_compl_singleton
  source_eq := rfl
  target_eq := rfl
  proj_toFun := by intro x hx; rfl

theorem isCoveringMap_addCircle : IsCoveringMap ((↑) : ℝ→AddCircle p) := by
  intro u
  obtain ⟨x,rfl⟩ := QuotientAddGroup.mk_surjective u
  apply IsEvenlyCovered.to_isEvenlyCovered_preimage (I := AddSubgroup.zmultiples p)
  refine ⟨inferInstance,circleCoverTrivialization p (x-p/2),?_⟩
  change (x : AddCircle p)≠((x-p/2 : ℝ) : AddCircle p)
  intro h
  have hp : 0<p := Fact.out
  have hx : x∈Ico (x-p/2) (x-p/2+p) := by constructor <;> linarith
  have ha : x-p/2∈Ico (x-p/2) (x-p/2+p) := by constructor <;> linarith
  have hh := (AddCircle.coe_eq_coe_iff_of_mem_Ico hx ha).mp h
  linarith

theorem exists_continuous_addCircle_lift (f : ℝ→AddCircle p) (hf : Continuous f) :
    ∃ θ : ℝ→ℝ,Continuous θ ∧ ∀ x,(θ x : AddCircle p)=f x := by
  obtain ⟨t₀,ht₀⟩ := QuotientAddGroup.mk_surjective (f 0)
  obtain ⟨θ,hθ,-⟩ := (isCoveringMap_addCircle p).existsUnique_continuousMap_lifts
    ⟨f,hf⟩ 0 t₀ ht₀
  refine ⟨θ,θ.continuous,fun x => ?_⟩
  exact congrFun hθ.2 x

end AdditiveCircleCover

theorem exists_continuous_circle_angle (f : ℝ→Circle) (hf : Continuous f) :
    ∃ θ : ℝ→ℝ,Continuous θ ∧ ∀ x,Circle.exp (θ x)=f x := by
  letI : Fact (0<2*Real.pi) := ⟨Real.two_pi_pos⟩
  obtain ⟨θ,hθ,he⟩ := exists_continuous_addCircle_lift (2*Real.pi)
    (fun x => AddCircle.homeomorphCircle'.symm (f x))
    (AddCircle.homeomorphCircle'.symm.continuous.comp hf)
  refine ⟨θ,hθ,fun x => ?_⟩
  have hh := congrArg AddCircle.homeomorphCircle' (he x)
  simpa only [AddCircle.homeomorphCircle'_apply_mk,Homeomorph.apply_symm_apply] using hh

def projectorPhase (P : PlaneMatrix) : ℂ :=
  ((P 0 0-P 1 1 : ℝ) : ℂ)+((2*P 0 1 : ℝ) : ℂ)*Complex.I

theorem continuous_projectorPhase : Continuous projectorPhase := by
  unfold projectorPhase
  fun_prop

theorem projectorPhase_norm (P : PlaneMatrix) (hsym : P.transpose=P) (hid : P*P=P)
    (htr : P 0 0+P 1 1=1) : ‖projectorPhase P‖=1 := by
  have hs := congrArg (fun B : PlaneMatrix => B 0 1) hsym
  change P 1 0=P 0 1 at hs
  have hh := congrArg (fun B : PlaneMatrix => B 0 0) hid
  simp only [Matrix.mul_apply,Fin.sum_univ_two,hs] at hh
  have hn : ‖projectorPhase P‖^2=1 := by
    rw [Complex.sq_norm,Complex.normSq_apply]
    simp only [projectorPhase,Complex.add_re,Complex.add_im,Complex.ofReal_re,
      Complex.ofReal_im,Complex.mul_re,Complex.mul_im,Complex.I_re,Complex.I_im,
      mul_zero,zero_mul,mul_one,sub_zero,add_zero,zero_add]
    nlinarith
  nlinarith [norm_nonneg (projectorPhase P)]

theorem projector_fixes_half_angle (P : PlaneMatrix) (hsym : P.transpose=P)
    (htr : P 0 0+P 1 1=1) (s : ℝ)
    (hphase : (Circle.exp s : ℂ)=projectorPhase P) :
    P*ᵥangleVector (s/2)=angleVector (s/2) := by
  have hs := congrArg (fun B : PlaneMatrix => B 0 1) hsym
  change P 1 0=P 0 1 at hs
  have hc := congrArg Complex.re hphase
  have hi := congrArg Complex.im hphase
  simp [Circle.coe_exp,Complex.exp_mul_I,projectorPhase] at hc hi
  simp only [← Complex.ofReal_cos,← Complex.ofReal_sin,Complex.ofReal_re] at hc hi
  have hcos := Real.cos_two_mul (s/2)
  have hsin := Real.sin_two_mul (s/2)
  rw [show 2*(s/2)=s by ring] at hcos hsin
  have hunit := Real.sin_sq_add_cos_sq (s/2)
  have h00 : P 0 0=Real.cos (s/2)^2 := by nlinarith
  have h11 : P 1 1=Real.sin (s/2)^2 := by nlinarith
  have h01 : P 0 1=Real.sin (s/2)*Real.cos (s/2) := by nlinarith
  funext i
  fin_cases i
  · simp [angleVector,mulVec,dotProduct,Fin.sum_univ_two,h00,h01]
    linear_combination Real.cos (s/2)*hunit
  · simp [angleVector,mulVec,dotProduct,Fin.sum_univ_two,h11,hs,h01]
    linear_combination Real.sin (s/2)*hunit

theorem exists_continuous_projector_angle (P : ℝ→PlaneMatrix) (hP : Continuous P)
    (hsym : ∀ x,(P x).transpose=P x) (hid : ∀ x,P x*P x=P x)
    (htr : ∀ x,P x 0 0+P x 1 1=1) :
    ∃ θ : ℝ→ℝ,Continuous θ ∧ ∀ x,P x*ᵥangleVector (θ x)=angleVector (θ x) := by
  let f : ℝ→Circle := fun x => ⟨projectorPhase (P x),
    mem_sphere_zero_iff_norm.mpr (projectorPhase_norm (P x) (hsym x) (hid x) (htr x))⟩
  have hf : Continuous f := (continuous_projectorPhase.comp hP).subtype_mk _
  obtain ⟨s,hsc,hs⟩ := exists_continuous_circle_angle f hf
  refine ⟨fun x => s x/2,hsc.div_const 2,fun x => ?_⟩
  exact projector_fixes_half_angle (P x) (hsym x) (htr x) (s x)
    (congrArg (fun z : Circle => (z : ℂ)) (hs x))

theorem exists_continuous_stable_angle_of_projector (A : ℝ→PlaneMatrix) (ω : ℝ)
    (P : ℝ→PlaneMatrix) (hP : Continuous P)
    (hsym : ∀ x,(P x).transpose=P x) (hid : ∀ x,P x*P x=P x)
    (htr : ∀ x,P x 0 0+P x 1 1=1)
    (hstable : ∀ x v,IsStable A ω x (P x*ᵥv)) :
    ∃ θ : ℝ→ℝ,Continuous θ ∧ ∀ x,IsStable A ω x (angleVector (θ x)) := by
  obtain ⟨θ,hθ,hfix⟩ := exists_continuous_projector_angle P hP hsym hid htr
  refine ⟨θ,hθ,fun x => ?_⟩
  rw [← hfix x]
  exact hstable x _

theorem boundary_stable_projector_odd_degree {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1)
    (t α : ℝ) (P : ℝ→PlaneMatrix) (hP : Continuous P)
    (hsym : ∀ x,(P x).transpose=P x) (hid : ∀ x,P x*P x=P x)
    (htr : ∀ x,P x 0 0+P x 1 1=1)
    (hstable : ∀ x v,IsStable (fun y => realTransfer 1 lam t (2*Real.pi*y)) α x (P x*ᵥv)) :
    ∃ θ : ℝ→ℝ,Continuous θ ∧ (∀ x,IsStable (fun y => realTransfer 1 lam t (2*Real.pi*y)) α x
      (angleVector (θ x))) ∧ ∃ m : ℤ,Odd m ∧ stableAngleDegree θ=(m : ℝ) := by
  obtain ⟨θ,hθ,hs⟩ := exists_continuous_stable_angle_of_projector _ α P hP hsym hid htr hstable
  exact ⟨θ,hθ,hs,boundary_stableAngleDegree_odd hlam hlam1 t α θ hθ hs⟩

end UAMO.StableAngleLift

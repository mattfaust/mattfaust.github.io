import UAMO.Basic
import Mathlib.Topology.Instances.Int
import Mathlib.Topology.Connected.TotallyDisconnected
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Complex
import Mathlib.LinearAlgebra.Matrix.ToLin

noncomputable section
namespace UAMO.StablePlane
open Matrix Filter Set
open scoped Topology Matrix

abbrev Plane := Fin 2 → ℝ
abbrev PlaneMatrix := Matrix (Fin 2) (Fin 2) ℝ

def forwardProduct (A : ℝ→PlaneMatrix) (ω x : ℝ) : ℕ→PlaneMatrix
  | 0 => 1
  | n+1 => A (x+(n : ℝ)*ω)*forwardProduct A ω x n

@[simp] theorem forwardProduct_succ (A : ℝ→PlaneMatrix) (ω x : ℝ) (n : ℕ) :
    forwardProduct A ω x (n+1)=A (x+(n : ℝ)*ω)*forwardProduct A ω x n := rfl

def IsStable (A : ℝ→PlaneMatrix) (ω x : ℝ) (v : Plane) : Prop :=
  Tendsto (fun n => forwardProduct A ω x n *ᵥ v) atTop (𝓝 0)

def stableSubspace (A : ℝ→PlaneMatrix) (ω x : ℝ) : Submodule ℝ Plane where
  carrier := {v | IsStable A ω x v}
  zero_mem' := by simp [IsStable]
  add_mem' := by
    intro v w hv hw
    simpa only [mem_setOf_eq,IsStable,mulVec_add,add_zero] using hv.add hw
  smul_mem' := by
    intro c v hv
    simpa only [mem_setOf_eq,IsStable,mulVec_smul,smul_zero] using hv.const_smul c

def wedge (v w : Plane) : ℝ := v 0*w 1-v 1*w 0

theorem wedge_mulVec (B : PlaneMatrix) (v w : Plane) :
    wedge (B*ᵥv) (B*ᵥw)=B.det*wedge v w := by
  simp only [wedge,mulVec, dotProduct,Fin.sum_univ_two,det_fin_two]
  ring

theorem forwardProduct_det (A : ℝ→PlaneMatrix) (hA : ∀ x,(A x).det=1) (ω x : ℝ) (n : ℕ) :
    (forwardProduct A ω x n).det=1 := by
  induction n with
  | zero => simp [forwardProduct]
  | succ n ih => rw [forwardProduct_succ,det_mul,hA,ih,one_mul]

theorem stable_wedge_eq_zero (A : ℝ→PlaneMatrix) (hA : ∀ x,(A x).det=1)
    (ω x : ℝ) {v w : Plane} (hv : IsStable A ω x v) (hw : IsStable A ω x w) :
    wedge v w=0 := by
  have hv0 := (tendsto_pi_nhds.mp hv) 0
  have hv1 := (tendsto_pi_nhds.mp hv) 1
  have hw0 := (tendsto_pi_nhds.mp hw) 0
  have hw1 := (tendsto_pi_nhds.mp hw) 1
  have hh := (hv0.mul hw1).sub (hv1.mul hw0)
  simp only [Pi.zero_apply,mul_zero,sub_zero] at hh
  have he (n : ℕ) : wedge (forwardProduct A ω x n*ᵥv) (forwardProduct A ω x n*ᵥw)=wedge v w := by
    rw [wedge_mulVec,forwardProduct_det A hA,one_mul]
  change Tendsto (fun n => wedge (forwardProduct A ω x n*ᵥv) (forwardProduct A ω x n*ᵥw)) atTop (𝓝 0) at hh
  simp only [he] at hh
  exact tendsto_nhds_unique tendsto_const_nhds hh

theorem forwardProduct_tail (A : ℝ→PlaneMatrix) (ω x : ℝ) (n : ℕ) :
    forwardProduct A ω x (n+1)=forwardProduct A ω (x+ω) n*A x := by
  induction n with
  | zero => simp [forwardProduct]
  | succ n ih =>
      rw [forwardProduct_succ A ω x (n+1),forwardProduct_succ A ω (x+ω) n,ih,mul_assoc]
      congr 2
      push_cast
      ring

theorem isStable_step_iff (A : ℝ→PlaneMatrix) (ω x : ℝ) (v : Plane) :
    IsStable A ω (x+ω) (A x*ᵥv) ↔ IsStable A ω x v := by
  have he (n : ℕ) : forwardProduct A ω (x+ω) n*ᵥ(A x*ᵥv)=
      forwardProduct A ω x (n+1)*ᵥv := by
    rw [mulVec_mulVec,forwardProduct_tail]
  unfold IsStable
  simp only [he]
  exact tendsto_add_atTop_iff_nat (f := fun n => forwardProduct A ω x n*ᵥv) 1

def quarterTurn : PlaneMatrix := !![0,-1;1,0]

@[simp] theorem quarterTurn_mulVec_zero (v : Plane) : (quarterTurn*ᵥv) 0= -v 1 := by
  simp [quarterTurn,mulVec,dotProduct,Fin.sum_univ_two]
@[simp] theorem quarterTurn_mulVec_one (v : Plane) : (quarterTurn*ᵥv) 1=v 0 := by
  simp [quarterTurn,mulVec,dotProduct,Fin.sum_univ_two]

theorem forwardProduct_half_shift (A : ℝ→PlaneMatrix) (h : ℝ)
    (hA : ∀ x,A (x+h)*quarterTurn=quarterTurn*A x) (ω x : ℝ) (n : ℕ) :
    forwardProduct A ω (x+h) n*quarterTurn=quarterTurn*forwardProduct A ω x n := by
  induction n with
  | zero => simp [forwardProduct]
  | succ n ih =>
      rw [forwardProduct_succ,forwardProduct_succ,mul_assoc,ih,← mul_assoc,
        show x+h+(n : ℝ)*ω=(x+(n : ℝ)*ω)+h by ring,hA,mul_assoc]

theorem isStable_half_shift (A : ℝ→PlaneMatrix) (h : ℝ)
    (hA : ∀ x,A (x+h)*quarterTurn=quarterTurn*A x) (ω x : ℝ) {v : Plane}
    (hv : IsStable A ω x v) : IsStable A ω (x+h) (quarterTurn*ᵥv) := by
  have hvec (n : ℕ) : forwardProduct A ω (x+h) n*ᵥ(quarterTurn*ᵥv)=
      quarterTurn*ᵥ(forwardProduct A ω x n*ᵥv) := by
    rw [mulVec_mulVec,mulVec_mulVec,forwardProduct_half_shift A h hA]
  unfold IsStable
  simp_rw [hvec]
  apply tendsto_pi_nhds.mpr
  intro i
  fin_cases i
  · simpa [quarterTurn,mulVec,dotProduct,Fin.sum_univ_two] using ((tendsto_pi_nhds.mp hv) 1).neg
  · simpa [quarterTurn,mulVec,dotProduct,Fin.sum_univ_two] using (tendsto_pi_nhds.mp hv) 0

def angleVector (t : ℝ) : Plane := ![Real.cos t,Real.sin t]

theorem wedge_angleVector_quarterTurn (s t : ℝ) :
    wedge (angleVector s) (quarterTurn*ᵥangleVector t)=Real.cos (s-t) := by
  simp only [wedge,quarterTurn_mulVec_one,quarterTurn_mulVec_zero,angleVector,
    Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one,Real.cos_sub]
  ring

theorem continuous_integer_valued_constant (f : ℝ→ℝ) (hf : Continuous f)
    (hint : ∀ x,∃ k : ℤ,f x=(k : ℝ)) : ∃ k : ℤ,∀ x,f x=(k : ℝ) := by
  choose k hk using hint
  have hc : Continuous (fun x => (k x : ℝ)) := by
    have he : (fun x => (k x : ℝ))=f := by funext x; exact (hk x).symm
    rw [he]
    exact hf
  have hkc : Continuous k := Int.isClosedEmbedding_coe_real.isEmbedding.isInducing.continuous_iff.mpr hc
  refine ⟨k 0,fun x => ?_⟩
  rw [hk x,TotallyDisconnectedSpace.eq_of_continuous k hkc x 0]

theorem stable_angle_odd_winding (A : ℝ→PlaneMatrix) (hdet : ∀ x,(A x).det=1)
    (h ω : ℝ) (hsym : ∀ x,A (x+h)*quarterTurn=quarterTurn*A x)
    (θ : ℝ→ℝ) (hθ : Continuous θ) (hstable : ∀ x,IsStable A ω x (angleVector (θ x))) :
    ∃ k : ℤ,∀ x,θ (x+2*h)-θ x=(2*(k : ℝ)+1)*Real.pi := by
  have hcos (x : ℝ) : Real.cos (θ (x+h)-θ x)=0 := by
    rw [← wedge_angleVector_quarterTurn]
    exact stable_wedge_eq_zero A hdet ω (x+h) (hstable (x+h))
      (isStable_half_shift A h hsym ω x (hstable x))
  let f : ℝ→ℝ := fun x => (θ (x+h)-θ x-Real.pi/2)/Real.pi
  have hf : Continuous f := by dsimp only [f]; fun_prop
  have hint (x : ℝ) : ∃ k : ℤ,f x=(k : ℝ) := by
    obtain ⟨k,hk⟩ := Real.cos_eq_zero_iff.mp (hcos x)
    refine ⟨k,?_⟩
    dsimp only [f]
    rw [hk]
    field_simp
    ring
  obtain ⟨k,hk⟩ := continuous_integer_valued_constant f hf hint
  have hdiff (x : ℝ) : θ (x+h)-θ x=Real.pi/2+(k : ℝ)*Real.pi := by
    have hh := hk x
    dsimp only [f] at hh
    have hmul := (div_eq_iff Real.pi_ne_zero).mp hh
    linarith
  refine ⟨k,fun x => ?_⟩
  have h₁ := hdiff x
  have h₂ := hdiff (x+h)
  rw [show x+h+h=x+2*h by ring] at h₂
  linarith

end UAMO.StablePlane

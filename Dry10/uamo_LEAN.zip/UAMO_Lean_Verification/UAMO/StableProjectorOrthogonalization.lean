import UAMO.StableAngleLift

noncomputable section
namespace UAMO.StablePlane
open Matrix
open scoped Matrix

def projectorSquareSum (P : PlaneMatrix) : ℝ :=
  P 0 0^2+P 0 1^2+P 1 0^2+P 1 1^2

def orthogonalRangeProjector (P : PlaneMatrix) : PlaneMatrix :=
  (projectorSquareSum P)⁻¹ • (P*P.transpose)

theorem projectorSquareSum_pos {P : PlaneMatrix} (hP : P≠0) :
    0<projectorSquareSum P := by
  have hs : 0≤projectorSquareSum P := by unfold projectorSquareSum; positivity
  by_contra h
  have hz : projectorSquareSum P=0 := le_antisymm (le_of_not_gt h) hs
  apply hP
  have h00 : P 0 0=0 := by dsimp [projectorSquareSum] at hz; nlinarith [sq_nonneg (P 0 1),sq_nonneg (P 1 0),sq_nonneg (P 1 1)]
  have h01 : P 0 1=0 := by dsimp [projectorSquareSum] at hz; nlinarith [sq_nonneg (P 0 0),sq_nonneg (P 1 0),sq_nonneg (P 1 1)]
  have h10 : P 1 0=0 := by dsimp [projectorSquareSum] at hz; nlinarith [sq_nonneg (P 0 0),sq_nonneg (P 0 1),sq_nonneg (P 1 1)]
  have h11 : P 1 1=0 := by dsimp [projectorSquareSum] at hz; nlinarith [sq_nonneg (P 0 0),sq_nonneg (P 0 1),sq_nonneg (P 1 0)]
  ext i j
  fin_cases i <;> fin_cases j <;> simp [h00,h01,h10,h11]

theorem orthogonalRangeProjector_transpose (P : PlaneMatrix) :
    (orthogonalRangeProjector P).transpose=orthogonalRangeProjector P := by
  simp [orthogonalRangeProjector,Matrix.transpose_mul]

theorem orthogonalRangeProjector_trace {P : PlaneMatrix} (hP : P≠0) :
    orthogonalRangeProjector P 0 0+orthogonalRangeProjector P 1 1=1 := by
  have hne := (projectorSquareSum_pos hP).ne'
  simp only [orthogonalRangeProjector,Matrix.smul_apply,smul_eq_mul,
    Matrix.mul_apply,Fin.sum_univ_two,Matrix.transpose_apply]
  have he : P 0 0*P 0 0+P 0 1*P 0 1+(P 1 0*P 1 0+P 1 1*P 1 1)=projectorSquareSum P := by
    unfold projectorSquareSum
    ring
  rw [← mul_add,he,inv_mul_cancel₀ hne]

theorem rank_one_gram_square (P : PlaneMatrix) (hdet : P.det=0) :
    (P*P.transpose)*(P*P.transpose)=projectorSquareSum P • (P*P.transpose) := by
  have hd : P 0 0*P 1 1-P 0 1*P 1 0=0 := by simpa only [Matrix.det_fin_two] using hdet
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp only [Matrix.mul_apply,Fin.sum_univ_two,Matrix.transpose_apply,
      Matrix.smul_apply,smul_eq_mul,projectorSquareSum,Fin.zero_eta,Fin.mk_one]
  · linear_combination (P 1 0*P 0 1-P 1 1*P 0 0)*hd
  · ring
  · ring
  · linear_combination (P 1 0*P 0 1-P 1 1*P 0 0)*hd

theorem orthogonalRangeProjector_idempotent {P : PlaneMatrix} (hP : P≠0)
    (hdet : P.det=0) : orthogonalRangeProjector P*orthogonalRangeProjector P=
      orthogonalRangeProjector P := by
  have hne := (projectorSquareSum_pos hP).ne'
  simp only [orthogonalRangeProjector,Matrix.smul_mul,Matrix.mul_smul,
    rank_one_gram_square P hdet,smul_smul]
  congr 1
  field_simp

theorem orthogonalRangeProjector_mulVec (P : PlaneMatrix) (v : Plane) :
    orthogonalRangeProjector P*ᵥv=P*ᵥ((projectorSquareSum P)⁻¹ • (P.transpose*ᵥv)) := by
  simp only [orthogonalRangeProjector,Matrix.smul_mulVec_assoc,
    Matrix.mulVec_smul,Matrix.mulVec_mulVec]

theorem continuous_orthogonalRangeProjector {X : Type*} [TopologicalSpace X]
    (P : X→PlaneMatrix) (hc : Continuous P) (hne : ∀x,P x≠0) :
    Continuous (fun x => orthogonalRangeProjector (P x)) := by
  have hs : Continuous (fun x => projectorSquareSum (P x)) := by
    unfold projectorSquareSum
    fun_prop
  have ht : Continuous (fun x => (P x).transpose) := by
    apply continuous_matrix
    intro i j
    exact (continuous_apply i).comp ((continuous_apply j).comp hc)
  exact (hs.inv₀ (fun x => (projectorSquareSum_pos (hne x)).ne')).smul (hc.mul ht)

theorem orthogonalRangeProjector_stable_image (A : ℝ→PlaneMatrix) (ω x : ℝ)
    (P : PlaneMatrix) (hstable : ∀v,IsStable A ω x (P*ᵥv)) (v : Plane) :
    IsStable A ω x (orthogonalRangeProjector P*ᵥv) := by
  rw [orthogonalRangeProjector_mulVec]
  exact hstable _

end UAMO.StablePlane

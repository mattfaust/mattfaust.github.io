import UAMO.CMVLyapunov
import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section
namespace UAMO.CMV
open Filter Matrix MeasureTheory Set
open scoped Topology Matrix.L2OpNorm ENNReal

def transferSpectralRadius (M : TransferMatrix) : ℝ := (spectralRadius ℂ M).toReal

theorem transferSpectralRadius_finite (M : TransferMatrix) : spectralRadius ℂ M≠∞ :=
  ne_top_of_le_ne_top ENNReal.coe_ne_top (spectrum.spectralRadius_le_nnnorm M)

theorem transferNorm_pow_ge_one (M : TransferMatrix) (hd : ‖M.det‖=1) (n : ℕ) :
    1≤transferNorm (M^n) := by
  apply one_le_transferNorm_of_det_norm
  simp only [Matrix.det_pow,norm_pow,hd,one_pow]

theorem transferNorm_root_tendsto (M : TransferMatrix) :
    Tendsto (fun n:ℕ => transferNorm (M^n)^(1/(n:ℝ))) atTop
      (𝓝 (transferSpectralRadius M)) := by
  have h := (ENNReal.tendsto_toReal (transferSpectralRadius_finite M)).comp
    (spectrum.pow_norm_pow_one_div_tendsto_nhds_spectralRadius M)
  simpa only [Function.comp_def,ENNReal.toReal_ofReal (Real.rpow_nonneg (norm_nonneg _) _)] using h

theorem transferSpectralRadius_ge_one (M : TransferMatrix) (hd : ‖M.det‖=1) :
    1≤transferSpectralRadius M := by
  apply ge_of_tendsto (transferNorm_root_tendsto M)
  exact Eventually.of_forall (fun n => Real.one_le_rpow (transferNorm_pow_ge_one M hd n) (by positivity))

theorem transferNorm_log_pow_tendsto (M : TransferMatrix) (hd : ‖M.det‖=1) :
    Tendsto (fun n:ℕ => Real.log (transferNorm (M^n))/(n:ℝ)) atTop
      (𝓝 (Real.log (transferSpectralRadius M))) := by
  have hp (n : ℕ) : 0<transferNorm (M^n) := zero_lt_one.trans_le (transferNorm_pow_ge_one M hd n)
  have hρ : 0<transferSpectralRadius M := zero_lt_one.trans_le (transferSpectralRadius_ge_one M hd)
  have h := (Real.continuousAt_log hρ.ne').tendsto.comp (transferNorm_root_tendsto M)
  simpa only [Function.comp_def,Real.log_rpow (hp _),one_div,mul_comm _ (Real.log _),← div_eq_mul_inv] using h

theorem transferNorm_log_pow_bound (M : TransferMatrix) (hd : ‖M.det‖=1) (n : ℕ) :
    0≤Real.log (transferNorm (M^n))/(n:ℝ) ∧
      Real.log (transferNorm (M^n))/(n:ℝ)≤Real.log (transferNorm M) := by
  have hnonneg := Real.log_nonneg (transferNorm_pow_ge_one M hd n)
  refine ⟨div_nonneg hnonneg (Nat.cast_nonneg _),?_⟩
  by_cases hn : n=0
  · simp only [hn,Nat.cast_zero,div_zero]
    exact Real.log_nonneg (one_le_transferNorm_of_det_norm M hd)
  · have hnpos : (0:ℝ)<n := by exact_mod_cast Nat.pos_of_ne_zero hn
    apply (div_le_iff₀ hnpos).mpr
    have hnorm : transferNorm (M^n)≤transferNorm M^n := norm_pow_le M n
    have hh := Real.log_le_log (zero_lt_one.trans_le (transferNorm_pow_ge_one M hd n)) hnorm
    rw [Real.log_pow] at hh
    simpa only [mul_comm] using hh

theorem transferSpectralRadius_log_bound (M : TransferMatrix) (hd : ‖M.det‖=1) :
    0≤Real.log (transferSpectralRadius M) ∧
      Real.log (transferSpectralRadius M)≤Real.log (transferNorm M) := by
  constructor
  · exact Real.log_nonneg (transferSpectralRadius_ge_one M hd)
  · apply le_of_tendsto (transferNorm_log_pow_tendsto M hd)
    exact Eventually.of_forall (fun n => (transferNorm_log_pow_bound M hd n).2)

end UAMO.CMV

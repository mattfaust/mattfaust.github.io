import UAMO.TransferMatrixPowerGrowth

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm ENNReal

theorem transfer_eigenvalue_quadratic (M : TransferMatrix) {ζ : ℂ}
    (hζ : ζ∈spectrum ℂ M) : ζ^2-M.trace*ζ+M.det=0 := by
  have hz : (algebraMap ℂ TransferMatrix ζ-M).det=0 := by
    simpa only [spectrum.mem_iff,Matrix.isUnit_iff_isUnit_det,isUnit_iff_ne_zero,not_not] using hζ
  have he : (algebraMap ℂ TransferMatrix ζ-M).det=ζ^2-M.trace*ζ+M.det := by
    simp only [Algebra.algebraMap_eq_smul_one,Matrix.det_fin_two,Matrix.sub_apply,
      Matrix.smul_apply,smul_eq_mul,Matrix.one_apply,Matrix.trace,Fin.sum_univ_two]
    norm_num
    ring
  rwa [he] at hz

theorem transfer_trace_of_eigenvalue (M : TransferMatrix) {ζ : ℂ}
    (hζ : ζ∈spectrum ℂ M) (hζ0 : ζ≠0) : M.trace=ζ+M.det/ζ := by
  have hh := transfer_eigenvalue_quadratic M hζ
  apply (mul_right_cancel₀ hζ0)
  field_simp
  linear_combination -hh

theorem transferSpectralRadius_trace_bounds (M : TransferMatrix) (hd : ‖M.det‖=1) :
    max 1 ‖M.trace‖≤2*transferSpectralRadius M ∧
      transferSpectralRadius M≤2*max 1 ‖M.trace‖ := by
  obtain ⟨ζ,hζ,hρ⟩ := spectrum.exists_nnnorm_eq_spectralRadius M
  have hnorm : ‖ζ‖=transferSpectralRadius M := by
    have hh := congrArg ENNReal.toReal hρ
    simpa only [ENNReal.coe_toReal,coe_nnnorm,transferSpectralRadius] using hh
  have hge := transferSpectralRadius_ge_one M hd
  have hζ0 : ζ≠0 := by
    intro h
    simp only [h,norm_zero] at hnorm
    linarith
  have ht := transfer_trace_of_eigenvalue M hζ hζ0
  have hdiv : ‖M.det/ζ‖≤1 := by
    rw [norm_div,hd,hnorm]
    exact (div_le_one (by linarith)).mpr hge
  have htr : ‖M.trace‖≤transferSpectralRadius M+1 := by
    rw [ht]
    exact (norm_add_le _ _).trans (by rw [hnorm]; linarith)
  have hroot : transferSpectralRadius M≤‖M.trace‖+1 := by
    have he : ζ=M.trace-M.det/ζ := by rw [ht]; ring
    rw [← hnorm,he]
    exact (norm_sub_le _ _).trans (by linarith)
  constructor
  · exact max_le (by linarith) (by linarith)
  · have hm1 : (1:ℝ)≤max 1 ‖M.trace‖ := le_max_left _ _
    have hmt : ‖M.trace‖≤max 1 ‖M.trace‖ := le_max_right _ _
    linarith

theorem transferSpectralRadius_log_trace_bound (M : TransferMatrix) (hd : ‖M.det‖=1) :
    |Real.log (transferSpectralRadius M)-Real.log (max 1 ‖M.trace‖)|≤Real.log 2 := by
  have hr : 0<transferSpectralRadius M := zero_lt_one.trans_le (transferSpectralRadius_ge_one M hd)
  have ht : 0<max (1:ℝ) ‖M.trace‖ := zero_lt_one.trans_le (le_max_left _ _)
  obtain ⟨h₁,h₂⟩ := transferSpectralRadius_trace_bounds M hd
  have hl₁ := Real.log_le_log ht h₁
  have hl₂ := Real.log_le_log hr h₂
  rw [Real.log_mul (by norm_num : (2:ℝ)≠0) hr.ne'] at hl₁
  rw [Real.log_mul (by norm_num : (2:ℝ)≠0) ht.ne'] at hl₂
  exact abs_le.mpr ⟨by linarith,by linarith⟩

end UAMO.CMV

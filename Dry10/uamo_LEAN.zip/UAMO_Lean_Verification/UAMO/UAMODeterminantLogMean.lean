import UAMO.UAMOSpectralDeterminantRoot
import UAMO.CircleLogMeanAt

noncomputable section
namespace UAMO.CMV
open MeasureTheory CircleDOS
open scoped Matrix.L2OpNorm

theorem circle_linear_ne_zero_of_norm_ne_one (c : ℂ) (hc : ‖c‖≠1) (t : ℝ) :
    1+c*logFourierChar 1 t≠0 := by
  intro h
  have he : (1:ℂ)= -(c*logFourierChar 1 t) := eq_neg_of_add_eq_zero_left h
  have hn := congrArg norm he
  simp only [norm_one,norm_neg,norm_mul,logFourierChar_norm,mul_one] at hn
  exact hc hn.symm

theorem circle_quadratic_factor (c : ℂ) (t : ℝ) :
    1+(c*logFourierChar 1 t)^2=
      (1+(c*Complex.I)*logFourierChar 1 t)*(1+(-c*Complex.I)*logFourierChar 1 t) := by
  have hI := Complex.I_sq
  linear_combination (c*logFourierChar 1 t)^2*hI

theorem circle_quadratic_ne_zero (c : ℂ) (hc : ‖c‖≠1) (t : ℝ) :
    1+(c*logFourierChar 1 t)^2≠0 := by
  rw [circle_quadratic_factor]
  exact mul_ne_zero
    (circle_linear_ne_zero_of_norm_ne_one _ (by simpa using hc) t)
    (circle_linear_ne_zero_of_norm_ne_one _ (by simpa using hc) t)

theorem circle_quadratic_log (c : ℂ) (hc : ‖c‖≠1) (t : ℝ) :
    Real.log ‖1+(c*logFourierChar 1 t)^2‖=
      Real.log ‖1+(c*Complex.I)*logFourierChar 1 t‖+
      Real.log ‖1+(-c*Complex.I)*logFourierChar 1 t‖ := by
  rw [circle_quadratic_factor,norm_mul,Real.log_mul]
  · exact norm_ne_zero_iff.mpr
      (circle_linear_ne_zero_of_norm_ne_one _ (by simpa using hc) t)
  · exact norm_ne_zero_iff.mpr
      (circle_linear_ne_zero_of_norm_ne_one _ (by simpa using hc) t)

theorem circle_quadratic_log_integrable (c : ℂ) (hc : ‖c‖≠1) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖1+(c*logFourierChar 1 x)^2‖) volume s t := by
  simp_rw [circle_quadratic_log c hc]
  have hp := circle_affine_log_integrable 1 (c*Complex.I) 0 s t
  have hm := circle_affine_log_integrable 1 (-c*Complex.I) 0 s t
  simp only [sub_zero] at hp hm
  exact hp.add hm

theorem integral_circle_quadratic_log (c : ℂ) (hc : ‖c‖≠1) :
    (∫t in (0:ℝ)..1,Real.log ‖1+(c*logFourierChar 1 t)^2‖)=
      2*Real.log (max ‖c‖ 1) := by
  have hp := circle_affine_log_integrable 1 (c*Complex.I) 0 0 1
  have hm := circle_affine_log_integrable 1 (-c*Complex.I) 0 0 1
  simp only [sub_zero] at hp hm
  simp_rw [circle_quadratic_log c hc]
  rw [intervalIntegral.integral_add hp hm]
  have h₁ := integral_circle_affine_log 1 (c*Complex.I) 0
  have h₂ := integral_circle_affine_log 1 (-c*Complex.I) 0
  simp only [sub_zero,norm_mul,Complex.norm_I,mul_one,norm_neg,norm_one] at h₁ h₂
  rw [h₁,h₂]
  ring

theorem log_max_exp_one (b : ℝ) : Real.log (max (Real.exp b) 1)=max b 0 := by
  by_cases hb : 0≤b
  · rw [max_eq_left (Real.one_le_exp_iff.mpr hb),Real.log_exp,max_eq_left hb]
  · have hb' : b≤0 := le_of_not_ge hb
    rw [max_eq_right (Real.exp_le_one_iff.mpr hb'),Real.log_one,max_eq_right hb']

theorem complexified_phase_turns (y t : ℝ) :
    Complex.exp ((((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)*Complex.I)=
      (Real.exp (-y):ℂ)*logFourierChar 1 t := by
  rw [complexified_phase_eq_scaled,spectralPhase_two_pi]

theorem complexified_negative_phase_turns (y t : ℝ) :
    Complex.exp (-((((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)*Complex.I))=
      (Real.exp y:ℂ)*star (logFourierChar 1 t) := by
  have he : -((((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)*Complex.I)=
      (((-2*Real.pi*t:ℝ):ℂ)+(-y:ℂ)*Complex.I)*Complex.I := by push_cast; ring
  rw [he,← Complex.ofReal_neg,complexified_phase_eq_scaled,neg_neg]
  have hs : spectralPhase (-2*Real.pi*t)=star (logFourierChar 1 t) := by
    rw [show -2*Real.pi*t= -(2*Real.pi*t) by ring,spectralPhase_neg,
      spectralPhase_two_pi]
    exact Complex.inv_eq_conj (logFourierChar_norm 1 t)
  rw [hs]

theorem complexified_determinant_norm_turns {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : z≠0) (y t : ℝ) :
    ‖(complexifiedPhaseTransfer a r z y (2*Real.pi*t)).det‖=
      ‖1+((r*Real.exp (-y):ℝ):ℂ)^2*(logFourierChar 1 t)^2‖*
      ‖1+((r*Real.exp y:ℝ):ℂ)^2*(logFourierChar 1 t)^2‖ := by
  rw [complexifiedPhaseTransfer,complexifiedRegularizedTransfer_det_exp_factor ha r hz,
    norm_mul,complexified_phase_turns,complexified_negative_phase_turns]
  have hconj : 1+((r:ℂ)*((Real.exp y:ℂ)*star (logFourierChar 1 t)))^2=
      star (1+((r*Real.exp y:ℝ):ℂ)^2*(logFourierChar 1 t)^2) := by
    simp only [star_add,star_one,star_mul,star_pow,Complex.star_def,Complex.conj_ofReal,
      Complex.ofReal_mul]
    ring
  rw [hconj,norm_star]
  congr 2
  push_cast
  ring

theorem height_radii_ne_one {r : ℝ} (hr : 0<r) (hr1 : r≤1) (y : ℝ)
    (hexceptional : |y|≠ -Real.log r) :
    r*Real.exp (-y)≠1 ∧ r*Real.exp y≠1 := by
  have hlog : Real.log r≤0 := Real.log_nonpos hr.le hr1
  constructor
  · intro he
    have hh := congrArg Real.log he
    rw [Real.log_mul hr.ne' (Real.exp_pos _).ne',Real.log_exp,Real.log_one] at hh
    have hy : y=Real.log r := by linarith
    exact hexceptional (by rw [hy,abs_of_nonpos hlog])
  · intro he
    have hh := congrArg Real.log he
    rw [Real.log_mul hr.ne' (Real.exp_pos _).ne',Real.log_exp,Real.log_one] at hh
    have hy : y= -Real.log r := by linarith
    exact hexceptional (by rw [hy,abs_of_nonneg (neg_nonneg.mpr hlog)])

theorem norm_height_radius {r : ℝ} (hr : 0<r) (b : ℝ) :
    ‖((r*Real.exp b:ℝ):ℂ)‖=Real.exp (Real.log r+b) := by
  rw [Complex.norm_real,Real.norm_eq_abs,abs_of_pos (mul_pos hr (Real.exp_pos _)),
    Real.exp_add,Real.exp_log hr]

theorem complexified_determinant_log_turns {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) (y t : ℝ)
    (hexceptional : |y|≠ -Real.log r) :
    Real.log ‖(complexifiedPhaseTransfer a r z y (2*Real.pi*t)).det‖=
      Real.log ‖1+(((r*Real.exp (-y):ℝ):ℂ)*logFourierChar 1 t)^2‖+
      Real.log ‖1+(((r*Real.exp y:ℝ):ℂ)*logFourierChar 1 t)^2‖ := by
  have hradii := height_radii_ne_one hr hr1 y hexceptional
  have hnorm (b : ℝ) : ‖((r*Real.exp b:ℝ):ℂ)‖=r*Real.exp b := by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_of_pos (mul_pos hr (Real.exp_pos _))]
  have hp := circle_quadratic_ne_zero ((r*Real.exp (-y):ℝ):ℂ)
    (by rw [hnorm]; exact hradii.1) t
  have hm := circle_quadratic_ne_zero ((r*Real.exp y:ℝ):ℂ)
    (by rw [hnorm]; exact hradii.2) t
  rw [complexified_determinant_norm_turns ha r hz,← mul_pow,← mul_pow,
    Real.log_mul (norm_ne_zero_iff.mpr hp) (norm_ne_zero_iff.mpr hm)]

theorem max_log_radius_pair {b : ℝ} (hb : b≤0) (y : ℝ) :
    max (b-y) 0+max (b+y) 0=max 0 (b+|y|) := by
  by_cases hy : 0≤y
  · rw [abs_of_nonneg hy,max_eq_right (by linarith : b-y≤0),zero_add,max_comm]
  · have hy' : y≤0 := le_of_not_ge hy
    rw [abs_of_nonpos hy',max_eq_right (by linarith : b+y≤0),add_zero]
    simpa only [sub_eq_add_neg] using max_comm (b-y) 0

theorem complexified_determinant_log_integral {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) (y : ℝ)
    (hexceptional : |y|≠ -Real.log r) :
    (∫t in (0:ℝ)..1,Real.log ‖(complexifiedPhaseTransfer a r z y (2*Real.pi*t)).det‖)=
      2*max 0 (Real.log r+|y|) := by
  have hradii := height_radii_ne_one hr hr1 y hexceptional
  have hnorm (b : ℝ) : ‖((r*Real.exp b:ℝ):ℂ)‖=r*Real.exp b := by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_of_pos (mul_pos hr (Real.exp_pos _))]
  have hp : ‖((r*Real.exp (-y):ℝ):ℂ)‖≠1 := by rw [hnorm]; exact hradii.1
  have hm : ‖((r*Real.exp y:ℝ):ℂ)‖≠1 := by rw [hnorm]; exact hradii.2
  simp_rw [complexified_determinant_log_turns ha hr hr1 hz y _ hexceptional]
  rw [intervalIntegral.integral_add
    (circle_quadratic_log_integrable _ hp 0 1) (circle_quadratic_log_integrable _ hm 0 1),
    integral_circle_quadratic_log _ hp,integral_circle_quadratic_log _ hm,
    norm_height_radius hr,norm_height_radius hr,log_max_exp_one,log_max_exp_one,
    ← mul_add]
  congr 1
  simpa only [sub_eq_add_neg] using max_log_radius_pair (Real.log_nonpos hr.le hr1) y

theorem determinant_root_log_integral {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) (y : ℝ)
    (hexceptional : |y|≠ -Real.log r) (g : ℂ→ℂ)
    (hroot : ∀x:ℝ,g ((x:ℂ)+(y:ℂ)*Complex.I)^2=
      (complexifiedPhaseTransfer a r z y x).det) :
    (∫t in (0:ℝ)..1,Real.log ‖g (((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)‖)=
      max 0 (Real.log r+|y|) := by
  have he (t : ℝ) : Real.log ‖g (((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)‖=
      Real.log ‖(complexifiedPhaseTransfer a r z y (2*Real.pi*t)).det‖/2 := by
    rw [← hroot,norm_pow,Real.log_pow]
    ring
  simp_rw [he]
  rw [intervalIntegral.integral_div,
    complexified_determinant_log_integral ha hr hr1 hz y hexceptional]
  ring

end UAMO.CMV

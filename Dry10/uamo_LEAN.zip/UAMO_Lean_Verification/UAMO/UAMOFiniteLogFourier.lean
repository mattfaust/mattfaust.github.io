import UAMO.PolynomialCocycleFourier
import UAMO.UAMOSpectralDeterminantRoot
import UAMO.UAMOSpectralLyapunovNormalization

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial CircleDOS Filter
open scoped Topology

theorem clearedTransferPolynomial_natDegree_le (a r : ℝ) (z : ℂ) (t : ℝ) (i j : Fin 2) :
    (clearedTransferPolynomial a r z t i j).natDegree≤2 := by
  unfold clearedTransferPolynomial
  apply Polynomial.natDegree_add_le_of_degree_le
  · apply Polynomial.natDegree_add_le_of_degree_le
    · exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
    · exact Polynomial.natDegree_C_mul_X_pow_le _ _
  · simp only [Polynomial.natDegree_C]; omega

theorem clearedTransferProduct_natDegree_le (a r : ℝ) (z : ℂ) (ω : ℝ)
    (n : ℕ) (i j : Fin 2) :
    (clearedTransferProduct a r z ω n i j).natDegree≤2*n := by
  induction n generalizing i j with
  | zero => simp only [clearedTransferProduct,Matrix.one_apply]; split_ifs <;> simp
  | succ n ih =>
    rw [clearedTransferProduct,Matrix.mul_apply,Fin.sum_univ_two]
    apply Polynomial.natDegree_add_le_of_degree_le
    · exact (Polynomial.natDegree_mul_le_of_le
        (clearedTransferPolynomial_natDegree_le a r z _ i 0) (ih 0 j)).trans (by omega)
    · exact (Polynomial.natDegree_mul_le_of_le
        (clearedTransferPolynomial_natDegree_le a r z _ i 1) (ih 1 j)).trans (by omega)

def verticalClearedProduct (a r : ℝ) (z : ℂ) (ω y : ℝ) (n : ℕ) :
    TransferPolynomialMatrix :=
  fun i j => (clearedTransferProduct a r z ω n i j).comp (C (Real.exp (-y):ℂ)*X)

theorem verticalClearedProduct_natDegree_le (a r : ℝ) (z : ℂ) (ω y : ℝ)
    (n : ℕ) (i j : Fin 2) :
    (verticalClearedProduct a r z ω y n i j).natDegree≤2*n := by
  apply Polynomial.natDegree_comp_le.trans
  calc
    _ ≤ (2*n)*1 := Nat.mul_le_mul (clearedTransferProduct_natDegree_le a r z ω n i j)
      ((Polynomial.natDegree_C_mul_le _ _).trans (by simp))
    _ = _ := Nat.mul_one _

theorem verticalClearedProduct_eval (a r : ℝ) (z : ℂ) (ω x y : ℝ) (n : ℕ) :
    (verticalClearedProduct a r z ω y n).map (Polynomial.eval (spectralPhase x)) =
      Complex.exp (((x:ℂ)+(y:ℂ)*Complex.I)*Complex.I)^n •
        transferProduct (complexifiedPhaseTransfer a r z y) ω x n := by
  have h := clearedTransferProduct_eval_vertical a r z ω x y n
  rw [complexified_phase_eq_scaled] at h
  rw [complexified_phase_eq_scaled]
  convert h using 1
  ext i j
  simp [verticalClearedProduct,Polynomial.eval_comp]

theorem complexifiedPhaseTransfer_det_ne_zero {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) {y : ℝ}
    (hy : |y|≠ -Real.log r) (x : ℝ) :
    (complexifiedPhaseTransfer a r z y x).det≠0 := by
  obtain ⟨g,_,_,hg⟩ := exists_periodic_determinant_root_at ha hr hr1 hz
    ((x:ℂ)+(y:ℂ)*Complex.I) (by simpa using hy)
  have h := hg.self_of_nhds
  change (complexifiedRegularizedTransfer a r z ((x:ℂ)+(y:ℂ)*Complex.I)).det≠0
  rw [← h.2]
  exact pow_ne_zero 2 h.1

theorem transferProduct_det_ne_zero (A : ℝ→TransferMatrix)
    (hd : ∀x,(A x).det≠0) (ω x : ℝ) (n : ℕ) :
    (transferProduct A ω x n).det≠0 := by
  induction n with
  | zero => simp
  | succ n ih => rw [transferProduct_succ,Matrix.det_mul]; exact mul_ne_zero (hd _) ih

theorem uamo_normalizedFrobeniusLog_fourier_bound {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) {y : ℝ}
    (hy : |y|≠ -Real.log r) (ω : ℝ) {n : ℕ} (hn : 0<n)
    {k : ℤ} (hk : k≠0) :
    ‖logFourierCoeff (fun t => normalizedFrobeniusLog
      (transferProduct (complexifiedPhaseTransfer a r z y) ω (2*Real.pi*t) n) n) k‖≤
      2 / |(k:ℝ)| := by
  let P := verticalClearedProduct a r z ω y n
  have hdet (x : ℝ) := transferProduct_det_ne_zero (complexifiedPhaseTransfer a r z y)
    (complexifiedPhaseTransfer_det_ne_zero ha hr hr1 hz hy) ω x n
  have he (t : ℝ) :
      P.map (Polynomial.eval (logFourierChar 1 t)) =
      Complex.exp ((((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)*Complex.I)^n •
        transferProduct (complexifiedPhaseTransfer a r z y) ω (2*Real.pi*t) n := by
    simpa only [P,spectralPhase_two_pi] using verticalClearedProduct_eval a r z ω (2*Real.pi*t) y n
  have hc (t : ℝ) : Complex.exp ((((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)*Complex.I)^n≠0 :=
    pow_ne_zero n (Complex.exp_ne_zero _)
  have hpd (t : ℝ) : (P.map (Polynomial.eval (logFourierChar 1 t))).det≠0 := by
    rw [he,Matrix.det_smul,Fintype.card_fin]
    exact mul_ne_zero (pow_ne_zero 2 (hc t)) (hdet _)
  have h := normalizedFrobeniusLog_polynomial_fourier_bound P (2*n) n hn
    (verticalClearedProduct_natDegree_le a r z ω y n) hpd hk
  have heq (t : ℝ) : normalizedFrobeniusLog (P.map (Polynomial.eval (logFourierChar 1 t))) n =
      normalizedFrobeniusLog
        (transferProduct (complexifiedPhaseTransfer a r z y) ω (2*Real.pi*t) n) n := by
    rw [he,normalizedFrobeniusLog_smul _ (hc t) _ (hdet _) n]
  simp_rw [heq] at h
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast hn.ne'
  have hk0 : |(k:ℝ)|≠0 := abs_ne_zero.mpr (by exact_mod_cast hk)
  convert h using 1
  push_cast
  field_simp
  ring

end UAMO.CMV

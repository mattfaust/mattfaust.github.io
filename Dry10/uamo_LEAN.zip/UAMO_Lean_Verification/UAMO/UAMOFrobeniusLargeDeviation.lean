import UAMO.UAMOPhaseBadSetGeometry

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set CircleDOS BourgainJitomirskaya
open scoped Matrix.L2OpNorm

theorem frobeniusDeviation_subset_centered (A:ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (ω:ℝ) {n:ℕ} (hn:0<n) (κ:ℝ) (hscale:Real.log 2/(n:ℝ)≤κ/2) :
    finiteFrobeniusBadSet A hc hp hd ω n (finiteLyapunov A ω n) κ ⊆
      {x:AddCircle (1:ℝ)|κ/2<‖finiteFrobeniusCircle A hc hp hd ω n x-
        fourierCoeff (finiteFrobeniusCircle A hc hp hd ω n) 0‖} := by
  intro x
  induction x using QuotientAddGroup.induction_on with
  | H t =>
    rw [mem_finiteFrobeniusBadSet_coe]
    intro ht
    change κ/2<‖finiteFrobeniusCircle A hc hp hd ω n (t:AddCircle (1:ℝ))-
      fourierCoeff (finiteFrobeniusCircle A hc hp hd ω n) 0‖
    rw [finiteFrobeniusCircle_coe,fourierCoeff_finiteFrobeniusCircle_zero,
      ← Complex.ofReal_sub,Complex.norm_real,Real.norm_eq_abs]
    have hm := finiteFrobeniusLog_mean_bounds A hc hd ω hn
    have hmabs : |(∫s in (0:ℝ)..1,finiteFrobeniusLog A ω n s)-finiteLyapunov A ω n|≤
        Real.log 2/(2*(n:ℝ)) := by rw [abs_of_nonneg hm.1]; exact hm.2
    have habs := abs_sub_le (finiteFrobeniusLog A ω n t)
      (∫s in (0:ℝ)..1,finiteFrobeniusLog A ω n s) (finiteLyapunov A ω n)
    have htwo : Real.log 2/(n:ℝ)=2*(Real.log 2/(2*(n:ℝ))) := by ring
    have hnon : 0≤Real.log 2/(2*(n:ℝ)) := by positivity
    linarith

end UAMO.CMV

import Mathlib.Topology.Instances.AddCircle
import Mathlib.Data.Real.Irrational
import Mathlib.Tactic

noncomputable section
namespace UAMO

def uamoGapLabel (α : ℝ) (m ell : ℤ) : AddCircle (1 : ℝ) :=
  ((((m : ℝ) * α + (ell : ℝ)) / 2 : ℝ) : AddCircle (1 : ℝ))

theorem uamoGapLabel_eq_iff {α : ℝ} (hα : Irrational α) (m ell n k : ℤ) :
    uamoGapLabel α m ell = uamoGapLabel α n k ↔ m = n ∧ Even (ell-k) := by
  constructor
  · intro h
    have hz : (((((m : ℝ)*α+(ell : ℝ))/2-
        ((n : ℝ)*α+(k : ℝ))/2 : ℝ) : AddCircle (1 : ℝ))) = 0 := by
      rw [AddCircle.coe_sub]
      exact sub_eq_zero.mpr h
    obtain ⟨q,hq⟩ := (AddCircle.coe_eq_zero_iff (1 : ℝ)).mp hz
    simp only [zsmul_eq_mul, mul_one] at hq
    have hmn : m=n := by
      by_contra hne
      apply (hα.intCast_mul (sub_ne_zero.mpr hne)).ne_int (2*q-ell+k)
      push_cast
      nlinarith [hq]
    refine ⟨hmn,?_⟩
    subst n
    have he : (ell : ℝ)-(k : ℝ)=(q : ℝ)+(q : ℝ) := by linarith [hq]
    exact ⟨q,by exact_mod_cast he⟩
  · rintro ⟨rfl,q,hq⟩
    apply sub_eq_zero.mp
    change (((((m : ℝ)*α+(ell : ℝ))/2 : ℝ) : AddCircle (1 : ℝ))) -
      (((((m : ℝ)*α+(k : ℝ))/2 : ℝ) : AddCircle (1 : ℝ))) = 0
    rw [← AddCircle.coe_sub,AddCircle.coe_eq_zero_iff]
    refine ⟨q,?_⟩
    have hqr : (ell : ℝ)-(k : ℝ)=(q : ℝ)+(q : ℝ) := by exact_mod_cast hq
    simp only [zsmul_eq_mul,mul_one]
    linarith

theorem uamoGapLabel_reverse_frequency (α : ℝ) (m ell : ℤ) :
    uamoGapLabel (-α) m ell=uamoGapLabel α (-m) ell := by
  unfold uamoGapLabel
  push_cast
  congr 1
  ring

theorem uamoGapLabel_neg_winding (α : ℝ) (m ell : ℤ) :
    uamoGapLabel α (-m) ell = -uamoGapLabel α m ell := by
  apply add_eq_zero_iff_eq_neg.mp
  unfold uamoGapLabel
  rw [← AddCircle.coe_add,AddCircle.coe_eq_zero_iff]
  refine ⟨ell,?_⟩
  push_cast
  simp only [zsmul_eq_mul,mul_one]
  ring

theorem uamoGapLabel_ne_zero {α : ℝ} (hα : Irrational α)
    {m : ℤ} (hm : m≠0) (ell : ℤ) : uamoGapLabel α m ell≠0 := by
  intro h
  have hzero : uamoGapLabel α 0 0=0 := by simp [uamoGapLabel]
  exact hm ((uamoGapLabel_eq_iff hα m ell 0 0).mp (h.trans hzero.symm)).1

theorem uamoGapLabel_ne_half {α : ℝ} (hα : Irrational α)
    {m : ℤ} (hm : m≠0) (ell : ℤ) :
    uamoGapLabel α m ell≠((1/2 : ℝ) : AddCircle (1 : ℝ)) := by
  intro h
  have hhalf : uamoGapLabel α 0 1=((1/2 : ℝ) : AddCircle (1 : ℝ)) := by
    simp [uamoGapLabel]
  exact hm ((uamoGapLabel_eq_iff hα m ell 0 1).mp (h.trans hhalf.symm)).1

end UAMO

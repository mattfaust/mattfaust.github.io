import UAMO.CMVLogLargeDeviation
import UAMO.UAMOFiniteLogFourier

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set CircleDOS

theorem uamo_normalizedTransfer_fourier_bound {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) {y : ℝ}
    (hy : |y|≠ -Real.log r) (A : ℝ→TransferMatrix) (g : ℝ→ℂ)
    (hd : ∀x,‖(A x).det‖=1)
    (hrel : ∀x,g x • A x=complexifiedPhaseTransfer a r z y x)
    (ω : ℝ) {n : ℕ} (hn : 0<n) {k : ℤ} (hk : k≠0) :
    ‖logFourierCoeff (finiteFrobeniusLog A ω n) k‖≤2/|(k:ℝ)| := by
  have hg (x:ℝ) : g x≠0 := by
    intro hx
    have hzero : complexifiedPhaseTransfer a r z y x=0 := by
      rw [← hrel x,hx,zero_smul]
    have hne := complexifiedPhaseTransfer_det_ne_zero ha hr hr1 hz hy x
    simp [hzero] at hne
  have he (x:ℝ) : normalizedFrobeniusLog
      (transferProduct (complexifiedPhaseTransfer a r z y) ω x n) n=
      Real.log (transferFrobeniusSq (transferProduct A ω x n))/(2*(n:ℝ)) := by
    have hdet := transferProduct_det_norm A hd ω x n
    have hdet0 : (transferProduct A ω x n).det≠0 := by intro h; simp [h] at hdet
    have hprod := transferProduct_scalar_gauge A g ω x n
    rw [show (fun t => g t • A t)=complexifiedPhaseTransfer a r z y from funext hrel] at hprod
    have hgc : (∏j∈Finset.range n,g (x+(j:ℝ)*ω))≠0 :=
      Finset.prod_ne_zero_iff.mpr (fun j _ => hg (x+(j:ℝ)*ω))
    rw [hprod,normalizedFrobeniusLog_smul _ hgc _ hdet0 n,
      normalizedFrobeniusLog_of_det_norm_one _ hdet]
  have h := uamo_normalizedFrobeniusLog_fourier_bound ha hr hr1 hz hy ω hn hk
  simpa only [he,finiteFrobeniusLog] using h

end UAMO.CMV

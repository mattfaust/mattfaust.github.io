import UAMO.CMVThoulessClosed
import UAMO.PhysicalDualityDOS

noncomputable section
namespace UAMO.CMV
open PhysicalDOS PhysicalDuality

theorem log_coupling_normalization {a : ℝ} (ha : 0<a) :
    Real.log (coupling a) = Real.log 2 + Real.log a - Real.log (1+a^2) := by
  rw [coupling, Real.log_div (by positivity) (by positivity),
    Real.log_mul (by norm_num) ha.ne']

theorem uamoLyapunov_exchange {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr : 0<r) (hr1 : r≤1) (α : ℝ) {z : ℂ} (hz : z≠0) :
    uamoLyapunov a r (2*Real.pi*α) z =
      uamoLyapunov r a (2*Real.pi*(-α)) z + Real.log (r/a) := by
  rw [uamoLyapunov_thouless_closed ha ha1 hr.le hr1 α hz,
    uamoLyapunov_thouless_closed hr hr1 ha.le ha1 (-α) hz,
    physicalUnitaryDOS_exchange a r α ha.le ha1 hr.le hr1,
    log_coupling_normalization ha, log_coupling_normalization hr,
    Real.log_div hr.ne' ha.ne']
  ring

end UAMO.CMV

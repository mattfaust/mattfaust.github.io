import UAMO.CMVNearPeriodicStep
import UAMO.UAMOFrobeniusLargeDeviation

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set

def RecordBadMasses (A:ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (α κ C c:ℝ) (q:ℕ) : Prop :=
  ∀N:ℕ,C*(q:ℝ)≤N →
    (volume.restrict (Ioc (0:ℝ) 1)).real (avalancheBaseBadSet A α N κ)≤Real.exp (-c*q) ∧
    AddCircle.haarAddCircle.real (finiteFrobeniusBadSet A hc hp hd (2*Real.pi*α) N
      (finiteLyapunov A (2*Real.pi*α) N) κ)≤Real.exp (-c*q)

end UAMO.CMV

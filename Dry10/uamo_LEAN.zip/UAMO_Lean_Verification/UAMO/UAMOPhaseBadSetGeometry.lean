import UAMO.BJPolynomialRatioGeometry
import UAMO.UAMOLargeDeviation

noncomputable section
namespace UAMO.CMV
open MeasureTheory Set Polynomial CircleDOS BourgainJitomirskaya
open scoped ENNReal

def finiteFrobeniusBadSet (A : ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (ω:ℝ) (n:ℕ) (c κ:ℝ) : Set (AddCircle (1:ℝ)) :=
  phaseBadSet (fun x => (finiteFrobeniusCircle A hc hp hd ω n x).re) c κ

@[simp] theorem mem_finiteFrobeniusBadSet_coe (A : ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (ω:ℝ) (n:ℕ) (c κ t:ℝ) :
    (t:AddCircle (1:ℝ))∈finiteFrobeniusBadSet A hc hp hd ω n c κ ↔
      κ < |finiteFrobeniusLog A ω n t-c| := by
  simp [finiteFrobeniusBadSet,phaseBadSet]

theorem isOpen_finiteFrobeniusBadSet (A : ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (ω:ℝ) (n:ℕ) (c κ:ℝ) : IsOpen (finiteFrobeniusBadSet A hc hp hd ω n c κ) :=
  isOpen_phaseBadSet (Complex.continuous_re.comp (finiteFrobeniusCircle A hc hp hd ω n).continuous) c κ

theorem measurableSet_finiteFrobeniusBadHull (A : ℝ→TransferMatrix) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (ω:ℝ) (n:ℕ) (c κ δ:ℝ) :
    MeasurableSet (phaseBadHull (finiteFrobeniusBadSet A hc hp hd ω n c κ) δ) :=
  (isOpen_phaseBadHull (isOpen_finiteFrobeniusBadSet A hc hp hd ω n c κ) δ).measurableSet

theorem verticalClearedProduct_det_ne_zero {a r:ℝ} (ha:a≠0)
    (hr:0<r) (hr1:r≤1) {z:ℂ} (hz:z≠0) {y:ℝ} (hy:|y|≠ -Real.log r)
    (ω:ℝ) (n:ℕ) {w:ℂ} (hw:‖w‖=1) :
    ((verticalClearedProduct a r z ω y n).map (Polynomial.eval w)).det≠0 := by
  have he : spectralPhase w.arg=w := by
    simpa only [spectralPhase,hw,Complex.ofReal_one,one_mul] using Complex.norm_mul_exp_arg_mul_I w
  rw [← he,verticalClearedProduct_eval,Matrix.det_smul,Fintype.card_fin]
  exact mul_ne_zero (pow_ne_zero 2 (pow_ne_zero n (Complex.exp_ne_zero _)))
    (transferProduct_det_ne_zero _ (complexifiedPhaseTransfer_det_ne_zero ha hr hr1 hz hy) _ _ _)

theorem uamo_normalizedTransfer_polynomial_ratio {a r:ℝ} (ha:a≠0)
    (hr:0<r) (hr1:r≤1) {z:ℂ} (hz:z≠0) {y:ℝ} (hy:|y|≠ -Real.log r)
    (A:ℝ→TransferMatrix) (g:ℝ→ℂ) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (hrel:∀x,g x • A x=complexifiedPhaseTransfer a r z y x)
    (ω:ℝ) (n:ℕ) (x:AddCircle (1:ℝ)) :
    (finiteFrobeniusCircle A hc hp hd ω n x).re=
      phasePolynomialRatioLog
        (frobeniusPolynomial (verticalClearedProduct a r z ω y n) (2*n))
        (verticalClearedProduct a r z ω y n).det x/(2*(n:ℝ)) := by
  have hg (t:ℝ) : g t≠0 := by
    intro h
    have hzero : complexifiedPhaseTransfer a r z y t=0 := by rw [← hrel t,h,zero_smul]
    have hne := complexifiedPhaseTransfer_det_ne_zero ha hr hr1 hz hy t
    simp [hzero] at hne
  induction x using QuotientAddGroup.induction_on with
  | H t =>
    let P := verticalClearedProduct a r z ω y n
    have hdet := transferProduct_det_norm A hd ω (2*Real.pi*t) n
    have hdet0 : (transferProduct A ω (2*Real.pi*t) n).det≠0 := by intro h; simp [h] at hdet
    have hprod := transferProduct_scalar_gauge A g ω (2*Real.pi*t) n
    rw [show (fun x => g x • A x)=complexifiedPhaseTransfer a r z y from funext hrel] at hprod
    have hgc : (∏j∈Finset.range n,g (2*Real.pi*t+(j:ℝ)*ω))≠0 :=
      Finset.prod_ne_zero_iff.mpr (fun j _ => hg _)
    have hrawdet := transferProduct_det_ne_zero _
      (complexifiedPhaseTransfer_det_ne_zero ha hr hr1 hz hy) ω (2*Real.pi*t) n
    have heval : P.map (Polynomial.eval (logFourierChar 1 t))=
        Complex.exp ((((2*Real.pi*t:ℝ):ℂ)+(y:ℂ)*Complex.I)*Complex.I)^n •
          transferProduct (complexifiedPhaseTransfer a r z y) ω (2*Real.pi*t) n := by
      simpa only [P,spectralPhase_two_pi] using verticalClearedProduct_eval a r z ω (2*Real.pi*t) y n
    have heq := normalizedFrobeniusLog_polynomial_eq P (2*n) n
      (verticalClearedProduct_natDegree_le a r z ω y n) t
    rw [heval,normalizedFrobeniusLog_smul _ (pow_ne_zero n (Complex.exp_ne_zero _)) _ hrawdet n,
      hprod,normalizedFrobeniusLog_smul _ hgc _ hdet0 n,
      normalizedFrobeniusLog_of_det_norm_one _ hdet] at heq
    simpa only [finiteFrobeniusCircle_coe,Complex.ofReal_re,finiteFrobeniusLog,
      phasePolynomialRatioLog,phasePolynomialLog,fourier_coe_eq_logFourierChar,P] using heq

theorem uamo_finiteFrobeniusBadSet_eq_ratio {a r:ℝ} (ha:a≠0)
    (hr:0<r) (hr1:r≤1) {z:ℂ} (hz:z≠0) {y:ℝ} (hy:|y|≠ -Real.log r)
    (A:ℝ→TransferMatrix) (g:ℝ→ℂ) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (hrel:∀x,g x • A x=complexifiedPhaseTransfer a r z y x)
    (ω:ℝ) {n:ℕ} (hn:0<n) (c κ:ℝ) :
    finiteFrobeniusBadSet A hc hp hd ω n c κ=
      phaseBadSet (phasePolynomialRatioLog
        (frobeniusPolynomial (verticalClearedProduct a r z ω y n) (2*n))
        (verticalClearedProduct a r z ω y n).det) (2*(n:ℝ)*c) (2*(n:ℝ)*κ) := by
  ext x
  have hnp : (0:ℝ)<2*(n:ℝ) := by positivity
  simp only [finiteFrobeniusBadSet,phaseBadSet,Set.mem_setOf_eq,
    uamo_normalizedTransfer_polynomial_ratio ha hr hr1 hz hy A g hc hp hd hrel]
  have he (v:ℝ) : |v-2*(n:ℝ)*c|=(2*(n:ℝ))*|v/(2*(n:ℝ))-c| := by
    rw [← abs_of_pos hnp,← abs_mul]
    congr 1
    rw [abs_of_pos hnp]
    field_simp
  rw [he,mul_lt_mul_left hnp]

theorem measure_uamo_finiteFrobeniusBadHull_le {a r:ℝ} (ha:a≠0)
    (hr:0<r) (hr1:r≤1) {z:ℂ} (hz:z≠0) {y:ℝ} (hy:|y|≠ -Real.log r)
    (A:ℝ→TransferMatrix) (g:ℝ→ℂ) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (hrel:∀x,g x • A x=complexifiedPhaseTransfer a r z y x)
    (ω:ℝ) {n:ℕ} (hn:0<n) (c:ℝ) {κ δ:ℝ} (hκ:0≤κ) (hδ:0≤δ) :
    AddCircle.haarAddCircle (phaseBadHull (finiteFrobeniusBadSet A hc hp hd ω n c κ) δ)≤
      AddCircle.haarAddCircle (finiteFrobeniusBadSet A hc hp hd ω n c κ)+
        ENNReal.ofReal (32*(n:ℝ)*δ) := by
  let P := verticalClearedProduct a r z ω y n
  let F := frobeniusPolynomial P (2*n)
  have hP := verticalClearedProduct_natDegree_le a r z ω y n
  have hF (w:ℂ) (hw:‖w‖=1) : F.eval w≠0 := by
    apply norm_pos_iff.mp
    rw [norm_frobeniusPolynomial_eval P (2*n) hP hw]
    exact transferFrobeniusSq_pos_of_det_ne_zero _
      (verticalClearedProduct_det_ne_zero ha hr hr1 hz hy ω n hw)
  have hdP (w:ℂ) (hw:‖w‖=1) : P.det.eval w≠0 := by
    rw [polynomialMatrix_det_eval]
    exact verticalClearedProduct_det_ne_zero ha hr hr1 hz hy ω n hw
  rw [uamo_finiteFrobeniusBadSet_eq_ratio ha hr hr1 hz hy A g hc hp hd hrel ω hn c κ]
  have hb := measure_phaseBadHull_polynomial_ratio_le F P.det hF hdP
    (2*(n:ℝ)*c) (show 0≤2*(n:ℝ)*κ by positivity) hδ
  apply hb.trans
  apply add_le_add_left
  apply ENNReal.ofReal_le_ofReal
  have hdeg : max F.natDegree P.det.natDegree≤4*n := max_le
    ((frobeniusPolynomial_natDegree_le P (2*n) hP).trans (by omega))
    ((polynomialMatrix_det_natDegree_le P (2*n) hP).trans (by omega))
  have hdeg' : (max F.natDegree P.det.natDegree:ℕ)≤4*(n:ℝ) := by exact_mod_cast hdeg
  nlinarith

theorem measureReal_uamo_finiteFrobeniusBadHull_le {a r:ℝ} (ha:a≠0)
    (hr:0<r) (hr1:r≤1) {z:ℂ} (hz:z≠0) {y:ℝ} (hy:|y|≠ -Real.log r)
    (A:ℝ→TransferMatrix) (g:ℝ→ℂ) (hc:Continuous A)
    (hp:Function.Periodic A (2*Real.pi)) (hd:∀x,‖(A x).det‖=1)
    (hrel:∀x,g x • A x=complexifiedPhaseTransfer a r z y x)
    (ω:ℝ) {n:ℕ} (hn:0<n) (c:ℝ) {κ δ:ℝ} (hκ:0≤κ) (hδ:0≤δ) :
    AddCircle.haarAddCircle.real (phaseBadHull (finiteFrobeniusBadSet A hc hp hd ω n c κ) δ)≤
      AddCircle.haarAddCircle.real (finiteFrobeniusBadSet A hc hp hd ω n c κ)+32*(n:ℝ)*δ := by
  have hh := ENNReal.toReal_mono
    (show AddCircle.haarAddCircle (finiteFrobeniusBadSet A hc hp hd ω n c κ)+
        ENNReal.ofReal (32*(n:ℝ)*δ)≠∞ from
      ENNReal.add_ne_top.mpr ⟨measure_ne_top _ _,ENNReal.ofReal_ne_top⟩)
    (measure_uamo_finiteFrobeniusBadHull_le ha hr hr1 hz hy A g hc hp hd hrel ω hn c hκ hδ)
  rw [ENNReal.toReal_add (measure_ne_top _ _) ENNReal.ofReal_ne_top,
    ENNReal.toReal_ofReal (by positivity)] at hh
  exact hh

end UAMO.CMV

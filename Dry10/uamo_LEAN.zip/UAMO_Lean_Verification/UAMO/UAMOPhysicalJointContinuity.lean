import UAMO.CMVPhysicalNormalization

noncomputable section
set_option maxHeartbeats 1200000
namespace UAMO.CMV
open Set Filter
open scoped Topology Matrix.L2OpNorm

theorem uamoLyapunov_joint_continuousAt_circle {a r:ℝ} (ha:0<a)
    (hr:0<r) (hr1:r<1) {β:ℝ} (hβ:Irrational β) (z:Circle) :
    ContinuousAt (fun p:ℝ×Circle => uamoLyapunov a r (2*Real.pi*p.1) (p.2:ℂ)) (β,z) := by
  obtain ⟨K,hK⟩ := exists_physicalSL2Transfer_circleBounds ha hr.le hr1
  let A : (ℝ×Circle)→ℝ→TransferMatrix := fun p=>physicalSL2Transfer a r (p.2:ℂ)
  have hmap : Continuous (fun p:(ℝ×Circle)×ℝ => (p.1.2,p.2)) := by fun_prop
  have hc0 := (continuous_physicalSL2Transfer_circle a hr.le hr1).comp hmap
  have hc : Continuous (fun p:(ℝ×Circle)×ℝ => A p.1 p.2) := by
    exact hc0
  have hy : |(0:ℝ)|≠ -Real.log r := by
    have hl := Real.log_neg hr hr1
    rw [abs_zero]
    linarith
  have hdense : Dense {p:ℝ×Circle | Irrational p.1} := by
    simpa only [Set.prod_univ] using dense_irrational.prod (dense_univ: Dense (univ:Set Circle))
  have ht := uamo_normalizedTransfer_parametric_lyapunov_continuousAt
    A Prod.fst (fun _=>a) (fun _=>r) (fun _=>0) (fun p=>(p.2:ℂ))
    (fun _=>physicalSL2Scalar r) (fun p=>hK p.2) hc continuous_fst
    (fun p x=>physicalSL2Transfer_det ha hr.le hr1 (Circle.coe_ne_zero p.2) x)
    (fun _=>ha.ne') (fun _=>hr) (fun _=>hr1.le) (fun p=>(Circle.coe_ne_zero p.2))
    (fun _=>hy) (fun p x=>physicalSL2Transfer_regularized ha.ne' hr.le hr1 (p.2:ℂ) x)
    hdense (p₀:=(β,z)) hβ
  simpa only [A,physicalSL2Transfer_lyapunov hr.le hr1] using ht

end UAMO.CMV

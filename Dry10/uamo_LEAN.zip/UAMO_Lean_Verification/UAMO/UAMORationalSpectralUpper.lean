import UAMO.RationalTraceLyapunov
import UAMO.UAMOSpectralLyapunovFiniteFloquet

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory
open scoped Topology Matrix.L2OpNorm

theorem transferTraceLog_le_of_scalar_trace (M : TransferMatrix) {c : ℂ}
    (hc : c ≠ 0) {C : ℝ} (hC : 0 < C) (hscalar : ‖c‖ ≤ C)
    (htrace : ‖(c • M).trace‖ ≤ C) :
    transferTraceLog M ≤ Real.log C - Real.log ‖c‖ := by
  have hcpos : 0 < ‖c‖ := norm_pos_iff.mpr hc
  have ht : ‖M.trace‖ ≤ C / ‖c‖ := by
    rw [le_div_iff₀ hcpos]
    simpa only [Matrix.trace_smul, smul_eq_mul, norm_mul, mul_comm] using htrace
  have hm : max 1 ‖M.trace‖ ≤ C / ‖c‖ :=
    max_le ((le_div_iff₀ hcpos).mpr (by simpa using hscalar)) ht
  have hl := Real.log_le_log (zero_lt_one.trans_le (le_max_left (1:ℝ) ‖M.trace‖)) hm
  simpa only [transferTraceLog, Real.log_div hC.ne' hcpos.ne'] using hl

theorem rational_physical_trace_mean_le_of_finite_spectrum (n : ℕ)
    {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r < 1)
    (hra : r ≤ a) (p : ℤ) (hcop : p.natAbs.Coprime (n+1)) (y : ℝ) {z : ℂ}
    (hs : z ∈ spectrum ℂ (finiteCMV n a r (2*Real.pi*((p:ℝ)/(n+1:ℕ))) y)) :
    (∫ x in (0:ℝ)..(2*Real.pi), transferTraceLog
      (transferProduct (uamoTransfer a r z) (2*Real.pi*((p:ℝ)/(n+1:ℕ))) x (n+1))) /
        (2*Real.pi) ≤ Real.log 16 := by
  let ω := 2*Real.pi*((p:ℝ)/(n+1:ℕ))
  have hpoint (x : ℝ) : transferTraceLog
      (transferProduct (uamoTransfer a r z) ω x (n+1)) ≤
        Real.log 16 - ∑ j ∈ Finset.range (n+1),
          Real.log ‖regularizingScalar r (x+j*ω)‖ := by
    have hg (j : ℕ) : regularizingScalar r (x+j*ω) ≠ 0 :=
      regularizingScalar_ne_zero (physicalHopping_ne_zero hr hr1 _)
    have hprod : (∏ j ∈ Finset.range (n+1), regularizingScalar r (x+j*ω)) ≠ 0 :=
      Finset.prod_ne_zero_iff.mpr (fun j _ => hg j)
    have hbound := regularizingScalar_cycle_product_norm_le_four hr hr1.le ω x (n+1)
      (Nat.succ_pos n) (spectralPhase_rational_primitive p (n+1) (Nat.succ_pos n) hcop)
    have ht := regularized_rational_trace_le_sixteen_of_finite_spectrum_nonsingular
      n ha ha1 hr hr1 hra p hcop x y hs
    rw [regularizedTransfer_product_eq_scalar a r z ω x
      (fun _ => physicalHopping_ne_zero hr hr1 _)] at ht
    have h := transferTraceLog_le_of_scalar_trace
      (transferProduct (uamoTransfer a r z) ω x (n+1)) hprod
      (by norm_num : (0:ℝ) < 16) (hbound.trans (by norm_num)) ht
    rw [norm_prod, Real.log_prod _ _ (fun j _ => norm_ne_zero_iff.mpr (hg j))] at h
    exact h
  have hcont := continuous_transferTraceLog.comp
    (continuous_transferProduct _ (continuous_uamoTransfer a hr hr1 z) ω (n+1))
  have hi := intervalIntegral.integral_mono_on (μ := volume) Real.two_pi_pos.le
    (hcont.intervalIntegrable 0 (2*Real.pi))
    (intervalIntegrable_const.sub (regularizingScalar_sum_log_integrable hr hr1.le
      ω (n+1) 0 (2*Real.pi))) (fun x _ => hpoint x)
  rw [intervalIntegral.integral_sub intervalIntegrable_const
    (regularizingScalar_sum_log_integrable hr hr1.le ω (n+1) 0 (2*Real.pi)),
    regularizingScalar_sum_log_integral hr hr1.le, sub_zero,
    intervalIntegral.integral_const] at hi
  simp only [sub_zero, smul_eq_mul] at hi
  exact (div_le_iff₀ Real.two_pi_pos).mpr (by simpa only [ω, mul_comm] using hi)

theorem uamoLyapunov_rational_le_of_finite_spectrum (n : ℕ)
    {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r < 1)
    (hra : r ≤ a) (p : ℤ) (hcop : p.natAbs.Coprime (n+1)) (y : ℝ) {z : ℂ}
    (hs : z ∈ spectrum ℂ (finiteCMV n a r (2*Real.pi*((p:ℝ)/(n+1:ℕ))) y)) :
    uamoLyapunov a r (2*Real.pi*((p:ℝ)/(n+1:ℕ))) z ≤
      (Real.log 2 + Real.log 16) / (n+1:ℕ) := by
  have hz : z ≠ 0 := norm_ne_zero_iff.mp (by
    rw [finiteCMV_spectrum_norm n a r _ y hs]; norm_num)
  have hq : (0:ℝ) < (n+1:ℕ) := by positivity
  have hmean := rational_physical_trace_mean_le_of_finite_spectrum
    n ha ha1 hr hr1 hra p hcop y hs
  have herror := (abs_le.mp (rational_lyapunov_trace_error (uamoTransfer a r z)
    (continuous_uamoTransfer a hr hr1 z) (uamoTransfer_periodic a r z)
    (uamoTransfer_det_norm ha hr hr1 hz) p (Nat.succ_pos n))).2
  simp only [mul_div_assoc] at herror
  have hmean' := div_le_div_of_nonneg_right hmean hq.le
  change lyapunov (uamoTransfer a r z) _ ≤ _
  rw [add_div]
  linarith

end UAMO.CMV

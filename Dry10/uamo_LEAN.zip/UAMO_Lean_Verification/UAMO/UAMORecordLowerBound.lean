import UAMO.CMVRecordTransitionTheorem
import UAMO.CMVInitialRecordSeed
import UAMO.CMVUniformLargeDeviation
import UAMO.BJRotationRecords

noncomputable section
namespace UAMO.CMV
open Set Filter BourgainJitomirskaya
open scoped Topology

theorem uniform_uamo_lyapunov_record_lower_bound {K κ:ℝ} (hK:1≤K)
    (hκ:0<κ) (hκ1:κ≤1) :
    ∃Q:ℕ,∀(a r:ℝ)(z:ℂ)(y:ℝ)(A:ℝ→TransferMatrix)(g:ℝ→ℂ),TransferCircleBounds A K →
      a≠0 → 0<r → r≤1 → z≠0 → |y|≠ -Real.log r → (∀x,(A x).det=1) →
      (∀x,g x • A x=complexifiedPhaseTransfer a r z y x) →
      ∀(α:ℝ)(q₀:ℕ),Irrational α → Q≤q₀ → rotationRecord α q₀ →
      8000*κ≤finiteLyapunov A (2*Real.pi*α) (q₀^4) →
      recordGap A α (q₀^4)≤κ/100 →
      finiteLyapunov A (2*Real.pi*α) (q₀^4)-κ≤lyapunov A (2*Real.pi*α) := by
  obtain ⟨C,c,hC,hc,hCκ,Qd,_,hLDT⟩ := uniform_uamo_recordBadMasses hK hκ hκ1
  obtain ⟨Qt,htransition⟩ := finiteLyapunov_record_transition hK hκ hC hc hCκ
  obtain ⟨Qi,hprepare⟩ := finiteLyapunov_prepare_record_seed hK hκ hC hc hCκ
  have hγ : 0<c/2000 := by positivity
  obtain ⟨Qb,_,hbudget⟩ := exists_recordScale_budget
    (A:=recordTransitionConstant (Real.log K)) (H:=(6:ℝ)) (γ:=c/2000) (ε:=κ/2)
    hκ (recordTransitionConstant_pos _ (Real.log_nonneg hK)) (by norm_num) hγ
    (half_pos hκ) (by linarith)
  let Q := max 8 (max Qd (max Qt (max Qi Qb)))
  refine ⟨Q,?_⟩
  intro a r z y A g hA ha hr hr1 hz hy hdet hrel α q₀ hα hq₀ hrecord hheight hdrop
  have hQd0 : Qd≤q₀ := by dsimp [Q] at hq₀; omega
  have hQt0 : Qt≤q₀ := by dsimp [Q] at hq₀; omega
  have hQi0 : Qi≤q₀ := by dsimp [Q] at hq₀; omega
  have hQb0 : Qb≤q₀ := by dsimp [Q] at hq₀; omega
  have hbad0 : RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c q₀ :=
    hLDT a r z y A g hA ha hr hr1 hz hy hrel α (rotationNumerator α q₀) q₀ hQd0
      (rotationRecord_isCoprime hrecord) (rotationRecord_approx_lt hα hrecord)
  have hprepared := hprepare A hA hdet α q₀ hQi0 hbad0 hheight hdrop
  have hhull := uamo_normalizedTransfer_hullBound ha hr hr1 hz hy A g
    hA.continuous hA.periodic hA.determinant hrel
  let qs : ℕ→ℕ := rotationRecordSeq hα hrecord
  have hqs0 : qs 0=q₀ := rotationRecordSeq_zero hα hrecord
  have hqs : StrictMono qs := rotationRecordSeq_strictMono hα hrecord
  have hq₀qs (j:ℕ) : q₀≤qs j := by
    rw [← hqs0]
    exact hqs.monotone (Nat.zero_le j)
  have hbad (j:ℕ) : RecordBadMasses A hA.continuous hA.periodic hA.determinant α κ C c (qs j) :=
    hLDT a r z y A g hA ha hr hr1 hz hy hrel α (rotationNumerator α (qs j)) (qs j)
      (hQd0.trans (hq₀qs j)) (rotationRecordSeq_isCoprime hα hrecord j)
      (rotationRecordSeq_approx_lt hα hrecord j)
  have hstep : RecordScaleTransition κ (recordTransitionConstant (Real.log K)) 6 (c/2000)
      (finiteLyapunov A (2*Real.pi*α)) qs := by
    intro j N hNlo hNhi hdiv hLN hdN
    obtain ⟨M,hMd,hNM,hMlo,hMhi,hLM,hwM⟩ :=
      htransition A hA hdet hhull α (qs j) (qs (j+1)) N (rotationNumerator α (qs j))
        (hQt0.trans (hq₀qs j)) (hqs (Nat.lt_succ_self j)) hNlo hNhi hdiv
        (rotationRecordSeq_approx_le hα hrecord j) hLN hdN (hbad j) (hbad (j+1))
    exact ⟨M,hNM,hMlo,hMhi,hMd,hLM,hwM⟩
  have hinit : 4000*κ≤finiteLyapunov A (2*Real.pi*α) ((qs 0)^6) := by
    simpa only [hqs0] using hprepared.1
  have hweight : (((qs 0)^6:ℕ):ℝ)*recordScaleGap (finiteLyapunov A (2*Real.pi*α)) ((qs 0)^6)≤
      κ*(qs 0:ℝ)^4/50 := by
    simpa only [hqs0,recordScaleGap,recordGap] using hprepared.2.1
  obtain ⟨Ns,hNs⟩ := hbudget (finiteLyapunov A (2*Real.pi*α)) qs hqs
    (by simpa only [hqs0] using hQb0) hinit hweight hstep
  have hlower := hNs.limit_lower (tendsto_finiteLyapunov A hA.continuous hA.periodic hA.determinant _)
  rw [hqs0] at hlower
  have hprep := hprepared.2.2
  linarith

end UAMO.CMV

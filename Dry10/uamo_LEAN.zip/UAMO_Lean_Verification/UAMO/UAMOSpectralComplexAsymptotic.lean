import UAMO.UAMOSpectralComplexGrowth

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem complexificationErrorBound_nonneg (a r : ℝ) (z : ℂ) (y : ℝ) :
    0 ≤ complexificationErrorBound a r z y := by
  unfold complexificationErrorBound transferNorm
  positivity

theorem complexifiedTransfer_scaled_norm_upper {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (z : ℂ) (x y : ℝ) :
    Real.exp (-y)*transferNorm (complexifiedPhaseTransfer a r z y x) ≤
      r/a + complexificationErrorBound a r z y := by
  have h := complexifiedRegularizedTransfer_uniform_error a r z x y
  have ht := norm_le_norm_add_norm_sub'
    ((Real.exp (-y) : ℂ) • complexifiedPhaseTransfer a r z y x)
    ((Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a)
  have hlead : transferNorm ((Complex.I*(r : ℂ)*spectralPhase (-x)) •
      spectralLeadingMatrix a) ≤ r/a := by
    rw [transferNorm_smul]
    simp only [norm_mul, Complex.norm_I, Complex.norm_real, Real.norm_eq_abs,
      abs_of_pos hr, spectralPhase_norm, one_mul, mul_one]
    simpa only [div_eq_mul_inv] using mul_le_mul_of_nonneg_left
      (spectralLeadingMatrix_norm_le ha ha1) hr.le
  have hs : ‖(Real.exp (-y) : ℂ) • complexifiedPhaseTransfer a r z y x‖ =
      Real.exp (-y)*transferNorm (complexifiedPhaseTransfer a r z y x) := by
    rw [norm_smul]
    simp only [Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    rfl
  rw [hs] at ht
  change _ ≤ transferNorm ((Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a) +
    transferNorm ((Real.exp (-y) : ℂ) • complexifiedPhaseTransfer a r z y x -
      (Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a) at ht
  exact ht.trans (add_le_add hlead h)

theorem complexifiedTransfer_norm_upper {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (z : ℂ) (x y : ℝ) :
    transferNorm (complexifiedPhaseTransfer a r z y x) ≤
      Real.exp y*(r/a + complexificationErrorBound a r z y) := by
  have h := mul_le_mul_of_nonneg_left
    (complexifiedTransfer_scaled_norm_upper ha ha1 hr z x y) (Real.exp_pos y).le
  simpa only [← mul_assoc, ← Real.exp_add, add_neg_cancel, Real.exp_zero, one_mul] using h

theorem lyapunov_le_log_uniform_bound (A : ℝ → TransferMatrix) (hc : Continuous A)
    (hd : ∀x, 1≤‖(A x).det‖) (ω K : ℝ) (hbound : ∀x, transferNorm (A x)≤K) :
    lyapunov A ω ≤ Real.log K := by
  apply (lyapunov_le_finite_of_det_norm_ge_one A hd ω (n:=1) (by omega)).trans
  have hi := (continuous_transferLogNorm_of_det_norm_ge_one A hc hd ω 1).intervalIntegrable
    (μ:=volume) 0 (2*Real.pi)
  have hle : ∀x, transferLogNorm A ω x 1 ≤ Real.log K := by
    intro x
    have hn := transferProduct_norm_pos_of_det_norm_ge_one A hd ω x 1
    apply Real.log_le_log hn
    simpa [transferProduct_succ, transferProduct_zero] using hbound x
  have h := intervalIntegral.integral_mono (by positivity : (0:ℝ)≤2*Real.pi)
    hi intervalIntegrable_const hle
  rw [intervalIntegral.integral_const] at h
  simp only [sub_zero,smul_eq_mul] at h
  have hh := div_le_div_of_nonneg_right h (by positivity : 0≤2*Real.pi)
  simpa [finiteLyapunov,transferLogAverage, show (2*Real.pi:ℝ) ≠ 0 by positivity] using hh

theorem complexifiedLyapunov_upper {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (ω : ℝ) (z : ℂ) (y : ℝ)
    (hd : ∀x, 1≤‖(complexifiedPhaseTransfer a r z y x).det‖) :
    complexifiedLyapunov a r ω z y - y ≤
      Real.log (r/a + complexificationErrorBound a r z y) := by
  have hb : 0 < r/a + complexificationErrorBound a r z y :=
    add_pos_of_pos_of_nonneg (div_pos hr ha) (complexificationErrorBound_nonneg a r z y)
  have h := lyapunov_le_log_uniform_bound _ (continuous_complexifiedPhaseTransfer a r z y)
    hd ω _ (fun x => complexifiedTransfer_norm_upper ha ha1 hr z x y)
  rw [Real.log_mul (Real.exp_pos y).ne' hb.ne',Real.log_exp] at h
  change complexifiedLyapunov a r ω z y ≤ _ at h
  linarith

theorem complexifiedLyapunov_asymptotic {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (ω : ℝ) {z : ℂ} (hz : z≠0) :
    Tendsto (fun y : ℝ => complexifiedLyapunov a r ω z y - y) atTop
      (𝓝 (Real.log (r/a))) := by
  have herr : Tendsto (fun y : ℝ => r/a + complexificationErrorBound a r z y) atTop
      (𝓝 (r/a)) := by
    simpa only [add_zero] using tendsto_const_nhds.add (complexificationErrorBound_tendsto a r z)
  have hlog := (Real.continuousAt_log (div_pos hr ha).ne').tendsto.comp herr
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hlog
  · filter_upwards [complexifiedRegularizedTransfer_eventually_det_ge_one ha.ne' hr hz] with y hy
    have h := complexifiedLyapunov_lower ha hr ω z y hy
    linarith
  · filter_upwards [complexifiedRegularizedTransfer_eventually_det_ge_one ha.ne' hr hz] with y hy
    exact complexifiedLyapunov_upper ha ha1 hr ω z y hy

theorem complexifiedPhaseTransfer_zero {a : ℝ} (ha : a≠0) (r : ℝ) (z : ℂ) :
    complexifiedPhaseTransfer a r z 0 = regularizedTransfer a r z := by
  funext x
  simpa only [complexifiedPhaseTransfer,Complex.ofReal_zero,zero_mul,add_zero] using
    complexifiedRegularizedTransfer_real ha r z x

theorem complexifiedLyapunov_zero {a : ℝ} (ha : a≠0) (r ω : ℝ) (z : ℂ) :
    complexifiedLyapunov a r ω z 0 = lyapunov (regularizedTransfer a r z) ω := by
  simp only [complexifiedLyapunov,complexifiedPhaseTransfer_zero ha]

end UAMO.CMV

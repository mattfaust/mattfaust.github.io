import UAMO.UAMOSpectralComplexification

noncomputable section
namespace UAMO.CMV
open Matrix Filter
open scoped Topology Matrix.L2OpNorm

theorem complexifiedRegularizedTransfer_det {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) (w : ℂ) :
    (complexifiedRegularizedTransfer a r z w).det =
      (1+(r : ℂ)^2)^2 -
        (-Complex.I*(r : ℂ)*Complex.exp (w*Complex.I)+
          Complex.I*(r : ℂ)*Complex.exp (-(w*Complex.I)))^2 := by
  have hac : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  have hda : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2 ≠ 0 by positivity)
  have hl : (coupling a : ℂ) ≠ 0 := by
    apply Complex.ofReal_ne_zero.mpr
    simp only [coupling]
    exact div_ne_zero (mul_ne_zero (by norm_num) ha) (by positivity)
  have hc : (a : ℂ)⁻¹-(a : ℂ) =
      2*(complementaryCoupling a : ℂ)/(coupling a : ℂ) := by
    unfold coupling complementaryCoupling
    push_cast
    field_simp
    ring
  simp only [complexifiedRegularizedTransfer, Matrix.det_fin_two, Matrix.add_apply,
    Matrix.smul_apply, smul_eq_mul, regularizedConstant, regularizedTransfer,
    physicalTransfer, oddAlpha, Real.sin_zero, mul_zero, neg_zero,
    spectralLeadingMatrix, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_fin_one, inv_one, one_mul, Complex.ofReal_zero, add_zero]
  rw [hc]
  field_simp
  ring

theorem complexifiedRegularizedTransfer_det_vertical {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) (x y : ℝ) :
    (complexifiedRegularizedTransfer a r z ((x : ℂ)+(y : ℂ)*Complex.I)).det =
      (1+(r : ℂ)^4) +
        (r : ℂ)^2*(Real.exp (-2*y) : ℂ)*spectralPhase (2*x) +
        (r : ℂ)^2*(Real.exp (2*y) : ℂ)*spectralPhase (-2*x) := by
  rw [complexifiedRegularizedTransfer_det ha r hz]
  have h1 : ((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I =
      (x : ℂ)*Complex.I+(-y : ℝ) := by push_cast; rw [add_mul, mul_assoc, Complex.I_mul_I]; ring
  have h2 : -(((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I) =
      ((-x : ℝ) : ℂ)*Complex.I+(y : ℂ) := by rw [h1]; push_cast; ring
  rw [h2,h1,Complex.exp_add,Complex.exp_add]
  have hcross : Complex.exp ((x : ℂ)*Complex.I)*Complex.exp (((-x : ℝ) : ℂ)*Complex.I) = 1 := by
    rw [← Complex.exp_add]
    convert Complex.exp_zero using 1
    push_cast
    ring
  have hycross : Complex.exp ((-y : ℝ) : ℂ)*Complex.exp (y : ℂ) = 1 := by
    rw [← Complex.exp_add]
    convert Complex.exp_zero using 1
    push_cast
    ring
  have hxpow : Complex.exp ((x : ℂ)*Complex.I)^2 = spectralPhase (2*x) := by
    rw [sq, ← Complex.exp_add]
    unfold spectralPhase
    congr 1
    push_cast
    ring
  have hxnpow : Complex.exp (((-x : ℝ) : ℂ)*Complex.I)^2 = spectralPhase (-2*x) := by
    rw [sq, ← Complex.exp_add]
    unfold spectralPhase
    congr 1
    push_cast
    ring
  have hypow : Complex.exp (y : ℂ)^2 = (Real.exp (2*y) : ℂ) := by
    rw [sq, ← Complex.exp_add, ← Complex.ofReal_add, ← Complex.ofReal_exp]
    congr 2
    ring
  have hynpow : Complex.exp ((-y : ℝ) : ℂ)^2 = (Real.exp (-2*y) : ℂ) := by
    rw [sq, ← Complex.exp_add, ← Complex.ofReal_add, ← Complex.ofReal_exp]
    congr 2
    ring
  calc
    _ = 1+(r : ℂ)^4 + (r : ℂ)^2*
        (Complex.exp ((x : ℂ)*Complex.I)^2*Complex.exp ((-y : ℝ) : ℂ)^2) +
        (r : ℂ)^2*(Complex.exp (((-x : ℝ) : ℂ)*Complex.I)^2*Complex.exp (y : ℂ)^2) := by
      have hcprod : (Complex.exp ((x : ℂ)*Complex.I)*Complex.exp (((-x : ℝ) : ℂ)*Complex.I))*
          (Complex.exp ((-y : ℝ) : ℂ)*Complex.exp (y : ℂ)) = 1 := by rw [hcross,hycross,mul_one]
      ring_nf
      simp only [Complex.I_sq]
      simp only [mul_comm (x : ℂ) Complex.I, mul_comm ((-x : ℝ) : ℂ) Complex.I] at hcprod
      linear_combination -2*(r : ℂ)^2*hcprod
    _ = _ := by rw [hxpow,hxnpow,hypow,hynpow]; ring

theorem complexifiedRegularizedTransfer_det_lower {a r : ℝ} (ha : a ≠ 0)
    (hr : 0 ≤ r) {z : ℂ} (hz : z ≠ 0) (x y : ℝ) :
    r^2*Real.exp (2*y) ≤
      ‖(complexifiedRegularizedTransfer a r z ((x : ℂ)+(y : ℂ)*Complex.I)).det‖ +
        (1+r^4+r^2*Real.exp (-2*y)) := by
  have hsmall : ‖(1+(r : ℂ)^4)+(r : ℂ)^2*(Real.exp (-2*y) : ℂ)*spectralPhase (2*x)‖ ≤
      1+r^4+r^2*Real.exp (-2*y) := by
    refine (norm_add_le _ _).trans_eq ?_
    simp only [norm_mul, norm_pow, spectralPhase_norm, mul_one, Complex.norm_real,
      Real.norm_eq_abs, abs_of_nonneg hr, abs_of_pos (Real.exp_pos _)]
    rw [show (1 : ℂ)+(r : ℂ)^4 = ((1+r^4 : ℝ) : ℂ) by push_cast; rfl,
      Complex.norm_real, Real.norm_eq_abs, abs_of_pos (by positivity)]
  calc
    _ = ‖(r : ℂ)^2*(Real.exp (2*y) : ℂ)*spectralPhase (-2*x)‖ := by
      simp only [norm_mul, norm_pow, spectralPhase_norm, mul_one, Complex.norm_real,
        Real.norm_eq_abs, abs_of_nonneg hr, abs_of_pos (Real.exp_pos _)]
    _ = ‖(complexifiedRegularizedTransfer a r z ((x : ℂ)+(y : ℂ)*Complex.I)).det -
        ((1+(r : ℂ)^4)+(r : ℂ)^2*(Real.exp (-2*y) : ℂ)*spectralPhase (2*x))‖ := by
      rw [complexifiedRegularizedTransfer_det_vertical ha r hz]
      congr 1
      abel
    _ ≤ _ := (norm_sub_le _ _).trans (add_le_add_left hsmall _)

theorem complexifiedRegularizedTransfer_eventually_det_ge_one {a r : ℝ}
    (ha : a ≠ 0) (hr : 0 < r) {z : ℂ} (hz : z ≠ 0) :
    ∀ᶠ y : ℝ in atTop, ∀ x : ℝ,
      1 ≤ ‖(complexifiedRegularizedTransfer a r z ((x : ℂ)+(y : ℂ)*Complex.I)).det‖ := by
  have ht : Tendsto (fun y : ℝ => r^2*Real.exp (2*y)) atTop atTop :=
    (Real.tendsto_exp_atTop.comp (tendsto_id.const_mul_atTop (by norm_num : (0 : ℝ)<2))).const_mul_atTop
      (sq_pos_of_pos hr)
  filter_upwards [(tendsto_atTop.1 ht) (2+r^4+r^2), eventually_ge_atTop (0 : ℝ)] with y hy hy0 x
  have he : Real.exp (-2*y) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hb := complexifiedRegularizedTransfer_det_lower ha hr.le hz x y
  nlinarith [sq_nonneg r]

end UAMO.CMV

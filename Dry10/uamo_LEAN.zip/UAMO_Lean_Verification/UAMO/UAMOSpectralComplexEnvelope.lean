import Mathlib
import UAMO.ConvexRecessionEnvelope
import UAMO.UAMOSpectralComplexNormalization
import UAMO.UAMOSpectralComplexSymmetry

noncomputable section
namespace UAMO.CMV

theorem complexifiedLyapunov_envelope {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) {α : ℝ} (hα : Irrational α)
    {z : ℂ} (hz : ‖z‖=1) (y : ℝ) :
    max (complexifiedLyapunov a r (2*Real.pi*α) z 0) (|y|+Real.log (r/a))≤
      complexifiedLyapunov a r (2*Real.pi*α) z y ∧
    complexifiedLyapunov a r (2*Real.pi*α) z y≤
      complexifiedLyapunov a r (2*Real.pi*α) z 0+|y| := by
  have hz0 : z≠0 := norm_ne_zero_iff.mp (by rw [hz]; norm_num)
  exact ConvexAsymptote.envelope
    (convexOn_complexifiedLyapunov_univ ha hr hα hz0)
    (complexifiedLyapunov_neg ha.ne' r hz (2*Real.pi*α))
    (complexifiedLyapunov_asymptotic ha ha1 hr (2*Real.pi*α) hz0) y

theorem complexifiedLyapunov_physical_envelope {a r : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hr1 : r≤1)
    {α : ℝ} (hα : Irrational α) {z : ℂ} (hz : ‖z‖=1) (y : ℝ) :
    max (uamoLyapunov a r (2*Real.pi*α) z) (|y|+Real.log (r/a))≤
      complexifiedLyapunov a r (2*Real.pi*α) z y ∧
    complexifiedLyapunov a r (2*Real.pi*α) z y≤
      uamoLyapunov a r (2*Real.pi*α) z+|y| := by
  have hz0 : z≠0 := norm_ne_zero_iff.mp (by rw [hz]; norm_num)
  simpa only [complexifiedLyapunov_zero_eq_uamo ha hr.le hr1 _ hz0] using
    complexifiedLyapunov_envelope ha ha1 hr hα hz y

end UAMO.CMV

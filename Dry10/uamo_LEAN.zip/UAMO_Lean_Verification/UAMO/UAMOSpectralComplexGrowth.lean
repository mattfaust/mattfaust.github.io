import UAMO.UAMOSpectralComplexDeterminant
import UAMO.UAMOSpectralComplexPolynomial
import UAMO.UAMOSpectralLeadingNorm
import UAMO.CMVComplexLyapunov
import UAMO.UAMOSpectralLyapunovLower

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

def complexifiedPhaseTransfer (a r : ℝ) (z : ℂ) (y x : ℝ) : TransferMatrix :=
  complexifiedRegularizedTransfer a r z ((x : ℂ)+(y : ℂ)*Complex.I)

def complexifiedLyapunov (a r ω : ℝ) (z : ℂ) (y : ℝ) : ℝ :=
  lyapunov (complexifiedPhaseTransfer a r z y) ω

theorem continuous_complexifiedPhaseTransfer (a r : ℝ) (z : ℂ) (y : ℝ) :
    Continuous (complexifiedPhaseTransfer a r z y) := by
  exact (differentiable_complexifiedRegularizedTransfer a r z).continuous.comp (by fun_prop)

theorem complexifiedPhaseTransfer_periodic (a r : ℝ) (z : ℂ) (y : ℝ) :
    Function.Periodic (complexifiedPhaseTransfer a r z y) (2*Real.pi) := by
  have hp : spectralPhase (2*Real.pi) = 1 := by
    simp [spectralPhase, Complex.ofReal_mul, Complex.exp_two_pi_mul_I]
  intro x
  simp only [complexifiedPhaseTransfer, complexifiedRegularizedTransfer_vertical,
    spectralPhase_neg, spectralPhase_add, hp, mul_one]

theorem tendsto_complexifiedFiniteLyapunov (a r ω : ℝ) (z : ℂ) (y : ℝ)
    (hd : ∀ x, 1 ≤ ‖(complexifiedPhaseTransfer a r z y x).det‖) :
    Tendsto (finiteLyapunov (complexifiedPhaseTransfer a r z y) ω) atTop
      (𝓝 (complexifiedLyapunov a r ω z y)) :=
  tendsto_finiteLyapunov_of_det_norm_ge_one _ (continuous_complexifiedPhaseTransfer a r z y)
    (complexifiedPhaseTransfer_periodic a r z y) hd ω

theorem complexifiedTransfer_even_average_lower {a r : ℝ} (ha : 0<a) (hr : 0<r)
    (ω : ℝ) (z : ℂ) (y : ℝ)
    (hd : ∀ x, 1 ≤ ‖(complexifiedPhaseTransfer a r z y x).det‖) (n : ℕ) :
    (2*n : ℕ)*(y+Real.log (r/a)) ≤
      Real.log 2 + transferLogAverage (complexifiedPhaseTransfer a r z y) ω (2*n) := by
  let P := clearedTracePolynomial a r z ω (2*n)
  let Q := P.comp (C (Real.exp (-y) : ℂ)*X)
  have hQ0 : Q.eval 0 = P.eval 0 := by simp [Q]
  have hP0 : P.eval 0 ≠ 0 := clearedTracePolynomial_even_zero_ne ha hr z ω n
  have hQne : Q ≠ 0 := by intro h; have := hQ0; rw [h] at this; simp at this; exact hP0 this.symm
  have hQ0ne : Q.eval 0 ≠ 0 := hQ0.trans_ne hP0
  have hlow : (2*n : ℕ)*Real.log (r/a) ≤ Real.log ‖Q.eval 0‖ := by
    rw [hQ0]
    have h := Real.log_le_log (pow_pos (div_pos hr ha) (2*n))
      (clearedTracePolynomial_even_zero_lower ha hr z ω n)
    simpa only [Real.log_pow] using h
  have hJ := polynomial_phase_log_jensen Q hQ0ne
  have hqi := polynomial_phase_log_integrable Q hQne 0 (2*Real.pi)
  have hai := (continuous_transferLogNorm_of_det_norm_ge_one _
    (continuous_complexifiedPhaseTransfer a r z y) hd ω (2*n)).intervalIntegrable (μ := volume) 0 (2*Real.pi)
  have hle : (fun x => Real.log ‖Q.eval (spectralPhase x)‖) ≤ᵐ[volume]
      (fun x => -(2*n : ℕ)*y+Real.log 2+
        transferLogNorm (complexifiedPhaseTransfer a r z y) ω x (2*n)) := by
    filter_upwards [polynomial_eval_phase_ne_zero_ae Q hQne] with x hx
    have he : Q.eval (spectralPhase x) =
        Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I)^(2*n) *
          (transferProduct (complexifiedPhaseTransfer a r z y) ω x (2*n)).trace := by
      simpa only [Q, Polynomial.eval_comp, Polynomial.eval_mul, Polynomial.eval_C,
        Polynomial.eval_X, ← complexified_phase_eq_scaled, P, complexifiedPhaseTransfer]
        using clearedTracePolynomial_eval_vertical a r z ω x y (2*n)
    have hn := transferProduct_norm_pos_of_det_norm_ge_one _ hd ω x (2*n)
    have hb : ‖Q.eval (spectralPhase x)‖ ≤
        (Real.exp (-y))^(2*n)*(2*transferNorm (transferProduct
          (complexifiedPhaseTransfer a r z y) ω x (2*n))) := by
      rw [he,norm_mul,norm_pow,complexified_phase_norm]
      exact mul_le_mul_of_nonneg_left (transfer_trace_norm_le _) (by positivity)
    have hl := Real.log_le_log (norm_pos_iff.mpr hx) hb
    rw [Real.log_mul (pow_pos (Real.exp_pos _) _).ne' (mul_pos (by norm_num) hn).ne',
      Real.log_pow, Real.log_exp, Real.log_mul (by norm_num) hn.ne'] at hl
    unfold transferLogNorm
    nlinarith
  have hint := intervalIntegral.integral_mono_ae (by positivity : (0 : ℝ) ≤ 2*Real.pi)
    hqi (intervalIntegrable_const.add hai) hle
  rw [intervalIntegral.integral_add intervalIntegrable_const hai,intervalIntegral.integral_const] at hint
  simp only [sub_zero,smul_eq_mul] at hint
  have hdiv := div_le_div_of_nonneg_right hint (by positivity : 0 ≤ 2*Real.pi)
  rw [add_div,mul_div_cancel_left₀ _ (show 2*Real.pi ≠ 0 by positivity)] at hdiv
  have hh := hlow.trans (hJ.trans hdiv)
  change _ ≤ -(2*n : ℕ)*y+Real.log 2+
    transferLogAverage (complexifiedPhaseTransfer a r z y) ω (2*n) at hh
  nlinarith

theorem complexifiedFiniteLyapunov_even_lower {a r : ℝ} (ha : 0<a) (hr : 0<r)
    (ω : ℝ) (z : ℂ) (y : ℝ)
    (hd : ∀ x, 1 ≤ ‖(complexifiedPhaseTransfer a r z y x).det‖)
    {n : ℕ} (hn : 0<n) :
    y+Real.log (r/a)-Real.log 2/(2*n : ℕ) ≤
      finiteLyapunov (complexifiedPhaseTransfer a r z y) ω (2*n) := by
  have hp : (0 : ℝ)<(2*n : ℕ) := by exact_mod_cast (show 0<2*n by omega)
  have h := complexifiedTransfer_even_average_lower ha hr ω z y hd n
  unfold finiteLyapunov
  apply (le_div_iff₀ hp).mpr
  have hc := div_mul_cancel₀ (Real.log 2) hp.ne'
  nlinarith

theorem complexifiedLyapunov_lower {a r : ℝ} (ha : 0<a) (hr : 0<r)
    (ω : ℝ) (z : ℂ) (y : ℝ)
    (hd : ∀ x, 1 ≤ ‖(complexifiedPhaseTransfer a r z y x).det‖) :
    y+Real.log (r/a) ≤ complexifiedLyapunov a r ω z y := by
  have hdouble : Tendsto (fun n : ℕ => 2*n) atTop atTop :=
    tendsto_atTop_mono (fun n : ℕ => show n ≤ 2*n by omega) tendsto_id
  have hfinite := (tendsto_complexifiedFiniteLyapunov a r ω z y hd).comp hdouble
  have herr := (tendsto_const_div_atTop_nhds_zero_nat (Real.log 2)).comp hdouble
  have hleft : Tendsto (fun n : ℕ => y+Real.log (r/a)-Real.log 2/(2*n : ℕ)) atTop
      (𝓝 (y+Real.log (r/a))) := by
    simpa only [sub_zero] using tendsto_const_nhds.sub herr
  apply le_of_tendsto_of_tendsto hleft hfinite
  filter_upwards [eventually_ge_atTop (1 : ℕ)] with n hn
  exact complexifiedFiniteLyapunov_even_lower ha hr ω z y hd (by omega)

end UAMO.CMV

import UAMO.UAMOSpectralComplexAsymptotic

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology

theorem regularizedTransfer_logNorm_eq (a r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ)
    (hq : ∀ j : ℕ, physicalHopping r (x+j*ω) ≠ 0)
    (hd : ‖(transferProduct (uamoTransfer a r z) ω x n).det‖ = 1) :
    transferLogNorm (regularizedTransfer a r z) ω x n =
      (∑ j ∈ Finset.range n, Real.log ‖regularizingScalar r (x+j*ω)‖) +
        transferLogNorm (uamoTransfer a r z) ω x n := by
  have hprod : ∀ j ∈ Finset.range n, ‖regularizingScalar r (x+j*ω)‖ ≠ 0 :=
    fun j _ => norm_ne_zero_iff.mpr (regularizingScalar_ne_zero (hq j))
  have hn : 0 < transferNorm (transferProduct (uamoTransfer a r z) ω x n) :=
    zero_lt_one.trans_le (one_le_transferNorm_of_det_norm _ hd)
  unfold transferLogNorm
  rw [regularizedTransfer_product_eq_scalar a r z ω x hq,
    transferNorm_smul, norm_prod,
    Real.log_mul (Finset.prod_ne_zero_iff.mpr hprod) hn.ne', Real.log_prod _ _ hprod]

theorem regularizedTransfer_logNorm_ae {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (n : ℕ) :
    (fun x => transferLogNorm (regularizedTransfer a r z) ω x n) =ᵐ[volume]
      (fun x => (∑ j ∈ Finset.range n, Real.log ‖regularizingScalar r (x+j*ω)‖) +
        transferLogNorm (uamoTransfer a r z) ω x n) := by
  filter_upwards [physicalHopping_orbit_ne_zero_ae_closed hr0 hr1 ω,
    uamoTransfer_product_det_norm_ae_closed ha hr0 hr1 ω hz n] with x hq hd
  exact regularizedTransfer_logNorm_eq a r z ω x n hq hd

theorem regularizedTransfer_logAverage_eq {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (n : ℕ) :
    transferLogAverage (regularizedTransfer a r z) ω n =
      transferLogAverage (uamoTransfer a r z) ω n := by
  unfold transferLogAverage
  rw [intervalIntegral.integral_congr_ae_restrict
    (ae_restrict_of_ae (regularizedTransfer_logNorm_ae ha hr0 hr1 ω hz n)),
    intervalIntegral.integral_add
      (regularizingScalar_sum_log_integrable hr0 hr1 ω n 0 (2*Real.pi))
      (uamoTransfer_product_log_integrable_closed ha hr0 hr1 ω hz n 0 (2*Real.pi)),
    regularizingScalar_sum_log_integral hr0 hr1, zero_add]

theorem regularizedFiniteLyapunov_eq {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (n : ℕ) :
    finiteLyapunov (regularizedTransfer a r z) ω n =
      finiteLyapunov (uamoTransfer a r z) ω n := by
  simp only [finiteLyapunov, regularizedTransfer_logAverage_eq ha hr0 hr1 ω hz]

theorem regularizedLyapunov_eq_uamo {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    lyapunov (regularizedTransfer a r z) ω = uamoLyapunov a r ω z := by
  simp only [lyapunov, uamoLyapunov, regularizedFiniteLyapunov_eq ha hr0 hr1 ω hz]

theorem complexifiedLyapunov_zero_eq_uamo {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) :
    complexifiedLyapunov a r ω z 0 = uamoLyapunov a r ω z := by
  rw [complexifiedLyapunov_zero ha.ne', regularizedLyapunov_eq_uamo ha hr0 hr1 ω hz]

end UAMO.CMV

import UAMO.UAMOSpectralComplexification

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial

theorem clearedTransferPolynomial_eval_complex (a r : ℝ) (z w : ℂ) (t : ℝ) :
    (clearedTransferPolynomial a r z t).map (Polynomial.eval (Complex.exp (w*Complex.I))) =
      Complex.exp (w*Complex.I) • complexifiedRegularizedTransfer a r z (w+t) := by
  have he : Complex.exp ((w+(t : ℂ))*Complex.I) =
      Complex.exp (w*Complex.I)*spectralPhase t := by
    simp [add_mul, Complex.exp_add, spectralPhase]
  have hen : Complex.exp (-((w+(t : ℂ))*Complex.I)) =
      (Complex.exp (w*Complex.I))⁻¹*spectralPhase (-t) := by
    rw [add_mul, neg_add, Complex.exp_add, Complex.exp_neg]
    simp [spectralPhase, neg_mul]
  ext i j
  simp only [clearedTransferPolynomial, Matrix.map_apply, Polynomial.eval_add,
    Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_X, Polynomial.eval_pow,
    complexifiedRegularizedTransfer, Matrix.smul_apply, Matrix.add_apply, smul_eq_mul, he, hen]
  field_simp
  ring

theorem clearedTransferProduct_eval_vertical (a r : ℝ) (z : ℂ)
    (ω x y : ℝ) (n : ℕ) :
    (clearedTransferProduct a r z ω n).map
        (Polynomial.eval (Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I))) =
      Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I)^n •
        transferProduct (fun t : ℝ => complexifiedRegularizedTransfer a r z
          ((t : ℂ)+(y : ℂ)*Complex.I)) ω x n := by
  induction n with
  | zero => simp [clearedTransferProduct, Matrix.map_one]
  | succ n ih =>
    rw [clearedTransferProduct, evalPolynomialMatrix_mul,
      clearedTransferPolynomial_eval_complex, ih, smul_mul_smul_comm, transferProduct_succ]
    have he : (x : ℂ)+(y : ℂ)*Complex.I+(n*ω : ℝ) =
        ((x+n*ω : ℝ) : ℂ)+(y : ℂ)*Complex.I := by push_cast; ring
    rw [he, pow_succ']

theorem clearedTracePolynomial_eval_vertical (a r : ℝ) (z : ℂ)
    (ω x y : ℝ) (n : ℕ) :
    (clearedTracePolynomial a r z ω n).eval
        (Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I)) =
      Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I)^n *
        (transferProduct (fun t : ℝ => complexifiedRegularizedTransfer a r z
          ((t : ℂ)+(y : ℂ)*Complex.I)) ω x n).trace := by
  have ht := congrArg Matrix.trace (clearedTransferProduct_eval_vertical a r z ω x y n)
  simpa [clearedTracePolynomial, Matrix.trace_fin_two] using ht

theorem complexified_phase_eq_scaled (x y : ℝ) :
    Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I) =
      (Real.exp (-y) : ℂ)*spectralPhase x := by
  have he : ((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I =
      ((-y : ℝ) : ℂ)+(x : ℂ)*Complex.I := by
    push_cast
    rw [add_mul, mul_assoc, Complex.I_mul_I]
    ring
  rw [he, Complex.exp_add, ← Complex.ofReal_exp]
  rfl

theorem complexified_phase_norm (x y : ℝ) :
    ‖Complex.exp (((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I)‖ = Real.exp (-y) := by
  rw [complexified_phase_eq_scaled, norm_mul, spectralPhase_norm, mul_one,
    Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]

end UAMO.CMV

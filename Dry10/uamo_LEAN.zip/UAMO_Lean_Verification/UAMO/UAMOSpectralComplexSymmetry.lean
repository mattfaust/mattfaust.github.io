import UAMO.ComplexLyapunovGlobal

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem vectorNorm_star {ι : Type*} [Fintype ι] (v : ι → ℂ) :
    vectorNorm (fun i => star (v i)) = vectorNorm v := by
  unfold vectorNorm
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  simp only [PiLp.norm_sq_eq_of_L2]
  change (∑ i, ‖star (v i)‖^2) = ∑ i, ‖v i‖^2
  simp only [norm_star]

theorem transferNorm_map_star_le (M : TransferMatrix) :
    transferNorm (M.map star) ≤ transferNorm M := by
  unfold transferNorm
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro v
  change vectorNorm ((M.map star) *ᵥ (fun i => v i)) ≤ transferNorm M * vectorNorm (fun i => v i)
  have he : (M.map star) *ᵥ (fun i => v i) =
      fun i => star ((M *ᵥ (fun j => star (v j))) i) := by
    ext i
    simp [Matrix.mulVec, dotProduct, map_sum, StarMul.star_mul, mul_comm]
  rw [he, vectorNorm_star]
  have hm := Matrix.l2_opNorm_mulVec M
    ((EuclideanSpace.equiv (Fin 2) ℂ).symm (fun i => star (v i)))
  change vectorNorm (M *ᵥ (fun i => star (v i))) ≤ ‖M‖ * vectorNorm (fun i => star (v i)) at hm
  exact hm.trans_eq (by rw [vectorNorm_star]; rfl)

theorem transferNorm_map_star (M : TransferMatrix) :
    transferNorm (M.map star) = transferNorm M := by
  apply le_antisymm (transferNorm_map_star_le M)
  simpa only [Matrix.map_map, Function.comp_def, star_star, Matrix.map_id] using
    transferNorm_map_star_le (M.map star)

def phaseConjugationReflection (a : ℝ) : TransferMatrix :=
  !![(complementaryCoupling a : ℂ), -(coupling a : ℂ);
     -(coupling a : ℂ), -(complementaryCoupling a : ℂ)]

theorem phaseConjugationReflection_star (a : ℝ) :
    star (phaseConjugationReflection a) = phaseConjugationReflection a := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [phaseConjugationReflection, Matrix.star_apply]

theorem phaseConjugationReflection_square (a : ℝ) :
    phaseConjugationReflection a * phaseConjugationReflection a = 1 := by
  have hs : (coupling a : ℂ)^2 + (complementaryCoupling a : ℂ)^2 = 1 := by
    exact_mod_cast coupling_square_identity a
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [phaseConjugationReflection, Matrix.mul_apply, Fin.sum_univ_two]
  all_goals first | simpa [pow_two, add_comm] using hs | ring

theorem phaseConjugationReflection_unitary (a : ℝ) :
    phaseConjugationReflection a ∈ unitary TransferMatrix := by
  apply unitary.mem_iff.mpr
  rw [phaseConjugationReflection_star]
  exact ⟨phaseConjugationReflection_square a, phaseConjugationReflection_square a⟩

theorem phaseConjugationReflection_leading {a : ℝ} (ha : a ≠ 0) :
    phaseConjugationReflection a * spectralLeadingMatrix a * phaseConjugationReflection a =
      spectralLeadingMatrix a := by
  have hac : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  have hd : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2≠0 by positivity)
  have hc : phaseConjugationReflection a * spectralLeadingMatrix a =
      spectralLeadingMatrix a * phaseConjugationReflection a := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp only [phaseConjugationReflection, spectralLeadingMatrix,
        Matrix.mul_apply, Fin.sum_univ_two, Matrix.cons_val_zero, Matrix.cons_val_one,
        Matrix.head_cons, Matrix.head_fin_const] <;>
      simp only [coupling, complementaryCoupling] <;> push_cast <;>
      field_simp [hac, hd] <;> ring
  rw [hc, mul_assoc, phaseConjugationReflection_square, mul_one]

theorem phaseConjugationReflection_constant {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) {z : ℂ} (hz : ‖z‖=1) :
    phaseConjugationReflection a * (regularizedConstant a r z).map star *
      phaseConjugationReflection a = regularizedConstant a r z := by
  have hac : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  have hd : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2≠0 by positivity)
  have hzne : z ≠ 0 := by intro h; simp [h] at hz
  have hstar : star z = z⁻¹ := by
    rw [Complex.inv_def, Complex.normSq_eq_norm_sq, hz]
    simp [Complex.star_def]
  have hconj : (starRingEnd ℂ) z = z⁻¹ := hstar
  have hlam : (coupling a : ℂ) ≠ 0 := by
    rw [coupling]
    push_cast
    exact div_ne_zero (mul_ne_zero (by norm_num) hac) hd
  have hs : (complementaryCoupling a : ℂ)^2 = 1-(coupling a : ℂ)^2 := by
    have h : (coupling a : ℂ)^2+(complementaryCoupling a : ℂ)^2=1 := by
      exact_mod_cast coupling_square_identity a
    linear_combination h
  have hc : phaseConjugationReflection a * (regularizedConstant a r z).map star =
      regularizedConstant a r z * phaseConjugationReflection a := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp only [phaseConjugationReflection, regularizedConstant, regularizedTransfer,
        physicalTransfer, oddAlpha, Real.sin_zero, mul_zero, Matrix.mul_apply, Fin.sum_univ_two,
        Matrix.map_apply, Matrix.smul_apply, smul_eq_mul,
        Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons, Matrix.head_fin_const] <;>
      simp only [map_mul, map_add, map_neg, map_inv₀, map_pow, Complex.star_def,
        Complex.conj_ofReal, inv_one, one_mul, mul_zero, add_zero, neg_zero, zero_sub] <;>
      simp only [hconj, inv_inv, hs] <;>
      field_simp [hlam, hzne] <;> ring_nf
    all_goals (try simp only [hs]); ring_nf
    all_goals rw [hconj]; field_simp [hzne]; ring
  rw [hc, mul_assoc, phaseConjugationReflection_square, mul_one]

theorem spectralLeadingMatrix_map_star (a : ℝ) :
    (spectralLeadingMatrix a).map star = spectralLeadingMatrix a := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [spectralLeadingMatrix]

theorem complexifiedRegularizedTransfer_conjugation {a : ℝ} (ha : a≠0)
    (r : ℝ) {z : ℂ} (hz : ‖z‖=1) (w : ℂ) :
    complexifiedRegularizedTransfer a r z (star w) =
      phaseConjugationReflection a * (complexifiedRegularizedTransfer a r z w).map star *
        phaseConjugationReflection a := by
  have he : (complexifiedRegularizedTransfer a r z w).map star =
      (regularizedConstant a r z).map star +
        (Complex.I*(r : ℂ)*Complex.exp (-(star w*Complex.I))) • spectralLeadingMatrix a +
        (-Complex.I*(r : ℂ)*Complex.exp (star w*Complex.I)) • spectralLeadingMatrix a := by
    ext i j
    simp only [complexifiedRegularizedTransfer, Matrix.map_apply, Matrix.add_apply,
      Matrix.smul_apply, smul_eq_mul]
    have hL := congrFun (congrFun (spectralLeadingMatrix_map_star a) i) j
    change star (spectralLeadingMatrix a i j) = spectralLeadingMatrix a i j at hL
    simp only [map_add, map_mul, map_neg, Complex.star_def, ← Complex.exp_conj,
      map_mul, map_neg, Complex.conj_I, Complex.conj_ofReal]
    simp only [← Complex.star_def, starRingEnd_apply, hL]
    congr 1 <;> congr 1 <;> ring_nf
  rw [he, mul_add, mul_add, add_mul, add_mul,
    Matrix.mul_smul, Matrix.mul_smul, Matrix.smul_mul, Matrix.smul_mul,
    phaseConjugationReflection_constant ha r hz,
    phaseConjugationReflection_leading ha]
  unfold complexifiedRegularizedTransfer
  abel

theorem complexifiedPhaseTransfer_neg {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : ‖z‖=1) (y x : ℝ) :
    complexifiedPhaseTransfer a r z (-y) x =
      phaseConjugationReflection a * (complexifiedPhaseTransfer a r z y x).map star *
        phaseConjugationReflection a := by
  have h := complexifiedRegularizedTransfer_conjugation ha r hz ((x : ℂ)+(y : ℂ)*Complex.I)
  simpa only [complexifiedPhaseTransfer, map_add, map_mul, Complex.star_def,
    Complex.conj_ofReal, Complex.conj_I, Complex.ofReal_neg, mul_neg, neg_mul] using h

theorem transferProduct_map_star (A : ℝ→TransferMatrix) (ω x : ℝ) (n : ℕ) :
    transferProduct (fun t => (A t).map star) ω x n = (transferProduct A ω x n).map star := by
  induction n with
  | zero => simp only [transferProduct_zero, Matrix.map_one, star_zero, star_one]
  | succ n ih =>
    rw [transferProduct_succ, transferProduct_succ, ih]
    exact (Matrix.map_mul (f := starRingEnd ℂ)).symm

theorem complexifiedTransferProduct_neg {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : ‖z‖=1) (ω x y : ℝ) (n : ℕ) :
    transferProduct (complexifiedPhaseTransfer a r z (-y)) ω x n =
      phaseConjugationReflection a *
        (transferProduct (complexifiedPhaseTransfer a r z y) ω x n).map star *
        phaseConjugationReflection a := by
  rw [transferProduct_conjugacy _ (fun t => (complexifiedPhaseTransfer a r z y t).map star)
    (phaseConjugationReflection a) (phaseConjugationReflection a)
    (phaseConjugationReflection_square a) (phaseConjugationReflection_square a)
    (fun t => complexifiedPhaseTransfer_neg ha r hz y t), transferProduct_map_star]

theorem complexifiedTransferProduct_norm_neg {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : ‖z‖=1) (ω x y : ℝ) (n : ℕ) :
    transferNorm (transferProduct (complexifiedPhaseTransfer a r z (-y)) ω x n) =
      transferNorm (transferProduct (complexifiedPhaseTransfer a r z y) ω x n) := by
  rw [complexifiedTransferProduct_neg ha r hz]
  change ‖phaseConjugationReflection a * _ * phaseConjugationReflection a‖ = _
  rw [CStarRing.norm_mul_mem_unitary _ (phaseConjugationReflection_unitary a),
    CStarRing.norm_mem_unitary_mul _ (phaseConjugationReflection_unitary a)]
  exact transferNorm_map_star _

theorem complexifiedFiniteLyapunov_neg {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : ‖z‖=1) (ω y : ℝ) (n : ℕ) :
    finiteLyapunov (complexifiedPhaseTransfer a r z (-y)) ω n =
      finiteLyapunov (complexifiedPhaseTransfer a r z y) ω n := by
  unfold finiteLyapunov transferLogAverage transferLogNorm
  simp_rw [complexifiedTransferProduct_norm_neg ha r hz]

theorem complexifiedLyapunov_neg {a : ℝ} (ha : a≠0) (r : ℝ)
    {z : ℂ} (hz : ‖z‖=1) (ω y : ℝ) :
    complexifiedLyapunov a r ω z (-y) = complexifiedLyapunov a r ω z y := by
  unfold complexifiedLyapunov lyapunov
  simp_rw [complexifiedFiniteLyapunov_neg ha r hz]

end UAMO.CMV

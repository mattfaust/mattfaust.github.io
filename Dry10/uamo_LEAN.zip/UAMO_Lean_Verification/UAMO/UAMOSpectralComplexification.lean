import UAMO.UAMOSpectralLyapunovPolynomial
import UAMO.CMVTransferDetGrowthComparison

noncomputable section
namespace UAMO.CMV
open Matrix Filter
open scoped Topology Matrix.L2OpNorm

def complexifiedRegularizedTransfer (a r : ℝ) (z w : ℂ) : TransferMatrix :=
  regularizedConstant a r z +
    (-Complex.I*(r : ℂ)*Complex.exp (w*Complex.I)) • spectralLeadingMatrix a +
    (Complex.I*(r : ℂ)*Complex.exp (-(w*Complex.I))) • spectralLeadingMatrix a

theorem complexifiedRegularizedTransfer_real {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) (z : ℂ) (x : ℝ) :
    complexifiedRegularizedTransfer a r z x = regularizedTransfer a r z x :=
  (regularizedTransfer_laurent ha r z x).symm

theorem differentiable_complexifiedRegularizedTransfer (a r : ℝ) (z : ℂ) :
    Differentiable ℂ (complexifiedRegularizedTransfer a r z) := by
  unfold complexifiedRegularizedTransfer
  fun_prop

theorem complexifiedRegularizedTransfer_vertical (a r : ℝ) (z : ℂ) (x y : ℝ) :
    complexifiedRegularizedTransfer a r z ((x : ℂ)+(y : ℂ)*Complex.I) =
      regularizedConstant a r z +
        (-Complex.I*(r : ℂ)*spectralPhase x*(Real.exp (-y) : ℂ)) • spectralLeadingMatrix a +
        (Complex.I*(r : ℂ)*spectralPhase (-x)*(Real.exp y : ℂ)) • spectralLeadingMatrix a := by
  have h1 : ((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I =
      (x : ℂ)*Complex.I+(-y : ℝ) := by push_cast; rw [add_mul, mul_assoc, Complex.I_mul_I]; ring
  have h2 : -(((x : ℂ)+(y : ℂ)*Complex.I)*Complex.I) =
      ((-x : ℝ) : ℂ)*Complex.I+(y : ℂ) := by rw [h1]; push_cast; ring
  rw [complexifiedRegularizedTransfer, h2, h1]
  simp only [Complex.exp_add,
    ← Complex.ofReal_exp, spectralPhase]
  simp only [mul_assoc]

theorem complexifiedRegularizedTransfer_scaled (a r : ℝ) (z : ℂ) (x y : ℝ) :
    (Real.exp (-y) : ℂ) • complexifiedRegularizedTransfer a r z
        ((x : ℂ)+(y : ℂ)*Complex.I) =
      (Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a +
      (Real.exp (-y) : ℂ) • regularizedConstant a r z +
      (-Complex.I*(r : ℂ)*spectralPhase x*(Real.exp (-2*y) : ℂ)) • spectralLeadingMatrix a := by
  have hprod : (Real.exp (-y) : ℂ)*(Real.exp y : ℂ) = 1 := by
    rw [← Complex.ofReal_mul, ← Real.exp_add, neg_add_cancel, Real.exp_zero, Complex.ofReal_one]
  have hsquare : (Real.exp (-y) : ℂ)*(Real.exp (-y) : ℂ) = (Real.exp (-2*y) : ℂ) := by
    rw [← Complex.ofReal_mul, ← Real.exp_add]
    congr 2
    ring
  rw [complexifiedRegularizedTransfer_vertical]
  ext i j
  simp only [Matrix.smul_apply, Matrix.add_apply, smul_eq_mul]
  linear_combination (Complex.I*(r : ℂ)*spectralPhase (-x)*spectralLeadingMatrix a i j)*hprod +
    (-Complex.I*(r : ℂ)*spectralPhase x*spectralLeadingMatrix a i j)*hsquare

def complexificationErrorBound (a r : ℝ) (z : ℂ) (y : ℝ) : ℝ :=
  Real.exp (-y)*transferNorm (regularizedConstant a r z) +
    |r| * Real.exp (-2*y)*transferNorm (spectralLeadingMatrix a)

theorem complexifiedRegularizedTransfer_uniform_error (a r : ℝ) (z : ℂ) (x y : ℝ) :
    transferNorm ((Real.exp (-y) : ℂ) • complexifiedRegularizedTransfer a r z
        ((x : ℂ)+(y : ℂ)*Complex.I) -
      (Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a) ≤
      complexificationErrorBound a r z y := by
  rw [complexifiedRegularizedTransfer_scaled]
  have he : (Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a +
      (Real.exp (-y) : ℂ) • regularizedConstant a r z +
      (-Complex.I*(r : ℂ)*spectralPhase x*(Real.exp (-2*y) : ℂ)) • spectralLeadingMatrix a -
      (Complex.I*(r : ℂ)*spectralPhase (-x)) • spectralLeadingMatrix a =
      (Real.exp (-y) : ℂ) • regularizedConstant a r z +
      (-Complex.I*(r : ℂ)*spectralPhase x*(Real.exp (-2*y) : ℂ)) • spectralLeadingMatrix a := by abel
  rw [he]
  calc
    _ ≤ ‖(Real.exp (-y) : ℂ) • regularizedConstant a r z‖ +
        ‖(-Complex.I*(r : ℂ)*spectralPhase x*(Real.exp (-2*y) : ℂ)) • spectralLeadingMatrix a‖ := norm_add_le _ _
    _ = _ := by
      simp only [norm_smul, norm_mul, norm_neg, Complex.norm_I, spectralPhase_norm,
        Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _), one_mul, mul_one,
        complexificationErrorBound, transferNorm]
      rfl

theorem complexificationErrorBound_tendsto (a r : ℝ) (z : ℂ) :
    Tendsto (complexificationErrorBound a r z) atTop (𝓝 0) := by
  unfold complexificationErrorBound
  have he := Real.tendsto_exp_neg_atTop_nhds_zero
  have he2 : Tendsto (fun y : ℝ => Real.exp (-2*y)) atTop (𝓝 0) := by
    have h := he.comp (tendsto_id.const_mul_atTop (by norm_num : (0 : ℝ)<2))
    simpa only [Function.comp_def, neg_mul] using h
  simpa only [complexificationErrorBound, zero_mul, mul_zero, add_zero] using
    (he.mul_const (transferNorm (regularizedConstant a r z))).add
      ((he2.const_mul |r|).mul_const (transferNorm (spectralLeadingMatrix a)))

end UAMO.CMV

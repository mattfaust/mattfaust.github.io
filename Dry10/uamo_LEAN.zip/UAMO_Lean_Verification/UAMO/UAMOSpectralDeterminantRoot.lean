import UAMO.ComplexTransferNonvanishing
import Mathlib.Analysis.SpecialFunctions.Complex.LogDeriv
import Mathlib.Analysis.SpecialFunctions.Complex.Analytic

noncomputable section
namespace UAMO.CMV
open Matrix Filter
open scoped Topology Matrix.L2OpNorm

def unitDiscBinomialRoot (u : ℂ) : ℂ :=
  Complex.exp (Complex.log (1+u^2)/2)

theorem one_add_sq_mem_slitPlane {u : ℂ} (hu : ‖u‖<1) :
    1+u^2∈Complex.slitPlane := by
  apply Complex.mem_slitPlane_of_norm_lt_one
  rw [norm_pow]
  nlinarith [norm_nonneg u]

theorem unitDiscBinomialRoot_sq {u : ℂ} (hu : ‖u‖<1) :
    unitDiscBinomialRoot u^2=1+u^2 := by
  rw [unitDiscBinomialRoot,sq,← Complex.exp_add]
  have he : Complex.log (1+u^2)/2+Complex.log (1+u^2)/2=Complex.log (1+u^2) := by ring
  rw [he,Complex.exp_log]
  exact (Complex.mem_slitPlane_iff_arg.mp (one_add_sq_mem_slitPlane hu)).2

theorem unitDiscBinomialRoot_ne_zero (u : ℂ) : unitDiscBinomialRoot u≠0 :=
  Complex.exp_ne_zero _

theorem differentiableAt_unitDiscBinomialRoot {u : ℂ} (hu : ‖u‖<1) :
    DifferentiableAt ℂ unitDiscBinomialRoot u := by
  have hpoly : DifferentiableAt ℂ (fun v:ℂ => 1+v^2) u := by fun_prop
  have hlog := (Complex.differentiableAt_log (one_add_sq_mem_slitPlane hu)).comp u hpoly
  exact (Complex.differentiable_exp _).comp u (hlog.div_const 2)

theorem complexifiedRegularizedTransfer_det_exp_factor {a : ℝ} (ha : a≠0)
    (r : ℝ) {z : ℂ} (hz : z≠0) (w : ℂ) :
    (complexifiedRegularizedTransfer a r z w).det=
      (1+((r:ℂ)*Complex.exp (w*Complex.I))^2)*
      (1+((r:ℂ)*Complex.exp (-(w*Complex.I)))^2) := by
  rw [complexifiedRegularizedTransfer_det ha r hz]
  have hp : Complex.exp (w*Complex.I)*Complex.exp (-(w*Complex.I))=1 := by
    rw [← Complex.exp_add,add_neg_cancel,Complex.exp_zero]
  have hp2 := congrArg (fun u:ℂ => u^2) hp
  simp only [one_pow] at hp2
  ring_nf
  simp only [Complex.I_sq]
  simp only [mul_comm w Complex.I] at hp hp2
  linear_combination -2*(r:ℂ)^2*hp-(r:ℂ)^4*hp2

def innerDeterminantRoot (r : ℝ) (w : ℂ) : ℂ :=
  unitDiscBinomialRoot ((r:ℂ)*Complex.exp (w*Complex.I))*
    unitDiscBinomialRoot ((r:ℂ)*Complex.exp (-(w*Complex.I)))

theorem innerDeterminantRoot_ne_zero (r : ℝ) (w : ℂ) : innerDeterminantRoot r w≠0 :=
  mul_ne_zero (unitDiscBinomialRoot_ne_zero _) (unitDiscBinomialRoot_ne_zero _)

theorem innerDeterminantRoot_sq {a r : ℝ} (ha : a≠0) {z : ℂ} (hz : z≠0) (w : ℂ)
    (hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1)
    (hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1) :
    innerDeterminantRoot r w^2=(complexifiedRegularizedTransfer a r z w).det := by
  rw [innerDeterminantRoot,mul_pow,unitDiscBinomialRoot_sq hp,unitDiscBinomialRoot_sq hm]
  exact (complexifiedRegularizedTransfer_det_exp_factor ha r hz w).symm

theorem differentiableAt_innerDeterminantRoot {r : ℝ} {w : ℂ}
    (hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1)
    (hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1) :
    DifferentiableAt ℂ (innerDeterminantRoot r) w := by
  have hplus : DifferentiableAt ℂ (fun v:ℂ => (r:ℂ)*Complex.exp (v*Complex.I)) w := by fun_prop
  have hminus : DifferentiableAt ℂ (fun v:ℂ => (r:ℂ)*Complex.exp (-(v*Complex.I))) w := by fun_prop
  exact ((differentiableAt_unitDiscBinomialRoot hp).comp w hplus).mul
    ((differentiableAt_unitDiscBinomialRoot hm).comp w hminus)

def upperDeterminantRoot (r : ℝ) (w : ℂ) : ℂ :=
  ((r:ℂ)*Complex.exp (-(w*Complex.I)))*
    unitDiscBinomialRoot ((r:ℂ)*Complex.exp (w*Complex.I))*
    unitDiscBinomialRoot ((r:ℂ)⁻¹*Complex.exp (w*Complex.I))

theorem upperDeterminantRoot_ne_zero {r : ℝ} (hr : r≠0) (w : ℂ) :
    upperDeterminantRoot r w≠0 :=
  mul_ne_zero (mul_ne_zero
    (mul_ne_zero (Complex.ofReal_ne_zero.mpr hr) (Complex.exp_ne_zero _))
    (unitDiscBinomialRoot_ne_zero _)) (unitDiscBinomialRoot_ne_zero _)

theorem upperDeterminantRoot_sq {a r : ℝ} (ha : a≠0) (hr : r≠0)
    {z : ℂ} (hz : z≠0) (w : ℂ)
    (hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1)
    (hi : ‖(r:ℂ)⁻¹*Complex.exp (w*Complex.I)‖<1) :
    upperDeterminantRoot r w^2=(complexifiedRegularizedTransfer a r z w).det := by
  have hrc : (r:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hr
  have hpair : ((r:ℂ)*Complex.exp (-(w*Complex.I)))*
      ((r:ℂ)⁻¹*Complex.exp (w*Complex.I))=1 := by
    calc
      _ = ((r:ℂ)*(r:ℂ)⁻¹)*(Complex.exp (-(w*Complex.I))*Complex.exp (w*Complex.I)) := by ring
      _ = 1 := by rw [mul_inv_cancel₀ hrc,← Complex.exp_add,neg_add_cancel,Complex.exp_zero,mul_one]
  have hfactor : ((r:ℂ)*Complex.exp (-(w*Complex.I)))^2*
      (1+((r:ℂ)⁻¹*Complex.exp (w*Complex.I))^2)=
      1+((r:ℂ)*Complex.exp (-(w*Complex.I)))^2 := by
    calc
      _ = ((r:ℂ)*Complex.exp (-(w*Complex.I)))^2+
        (((r:ℂ)*Complex.exp (-(w*Complex.I)))*
          ((r:ℂ)⁻¹*Complex.exp (w*Complex.I)))^2 := by ring
      _ = _ := by rw [hpair]; ring
  rw [upperDeterminantRoot,mul_pow,mul_pow,
    unitDiscBinomialRoot_sq hp,unitDiscBinomialRoot_sq hi,
    complexifiedRegularizedTransfer_det_exp_factor ha r hz]
  calc
    _ = (1+((r:ℂ)*Complex.exp (w*Complex.I))^2)*
      (((r:ℂ)*Complex.exp (-(w*Complex.I)))^2*
      (1+((r:ℂ)⁻¹*Complex.exp (w*Complex.I))^2)) := by ring
    _ = _ := by rw [hfactor]

theorem differentiableAt_upperDeterminantRoot {r : ℝ} {w : ℂ}
    (hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1)
    (hi : ‖(r:ℂ)⁻¹*Complex.exp (w*Complex.I)‖<1) :
    DifferentiableAt ℂ (upperDeterminantRoot r) w := by
  have hplus : DifferentiableAt ℂ (fun v:ℂ => (r:ℂ)*Complex.exp (v*Complex.I)) w := by fun_prop
  have hinv : DifferentiableAt ℂ (fun v:ℂ => (r:ℂ)⁻¹*Complex.exp (v*Complex.I)) w := by fun_prop
  have hminus : DifferentiableAt ℂ (fun v:ℂ => (r:ℂ)*Complex.exp (-(v*Complex.I))) w := by fun_prop
  exact (hminus.mul ((differentiableAt_unitDiscBinomialRoot hp).comp w hplus)).mul
    ((differentiableAt_unitDiscBinomialRoot hi).comp w hinv)

theorem complexPhase_periodic (w : ℂ) :
    Complex.exp ((w+(2*Real.pi:ℝ))*Complex.I)=Complex.exp (w*Complex.I) := by
  rw [add_mul,Complex.exp_add]
  have he : Complex.exp (((2*Real.pi:ℝ):ℂ)*Complex.I)=1 := by
    push_cast
    exact Complex.exp_two_pi_mul_I
  rw [he,mul_one]

theorem complexNegativePhase_periodic (w : ℂ) :
    Complex.exp (-((w+(2*Real.pi:ℝ))*Complex.I))=Complex.exp (-(w*Complex.I)) := by
  rw [Complex.exp_neg,complexPhase_periodic,Complex.exp_neg]

theorem innerDeterminantRoot_periodic (r : ℝ) :
    Function.Periodic (innerDeterminantRoot r) ((2*Real.pi:ℝ):ℂ) := by
  intro w
  simp only [innerDeterminantRoot,complexPhase_periodic,complexNegativePhase_periodic]

theorem upperDeterminantRoot_periodic (r : ℝ) :
    Function.Periodic (upperDeterminantRoot r) ((2*Real.pi:ℝ):ℂ) := by
  intro w
  simp only [upperDeterminantRoot,complexPhase_periodic,complexNegativePhase_periodic]

def lowerDeterminantRoot (r : ℝ) (w : ℂ) : ℂ := upperDeterminantRoot r (-w)

theorem complexifiedRegularizedTransfer_det_neg {a : ℝ} (ha : a≠0)
    (r : ℝ) {z : ℂ} (hz : z≠0) (w : ℂ) :
    (complexifiedRegularizedTransfer a r z (-w)).det=
      (complexifiedRegularizedTransfer a r z w).det := by
  rw [complexifiedRegularizedTransfer_det_exp_factor ha r hz,
    complexifiedRegularizedTransfer_det_exp_factor ha r hz]
  simp only [neg_mul,neg_neg]
  ring

theorem lowerDeterminantRoot_sq {a r : ℝ} (ha : a≠0) (hr : r≠0)
    {z : ℂ} (hz : z≠0) (w : ℂ)
    (hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1)
    (hi : ‖(r:ℂ)⁻¹*Complex.exp (-(w*Complex.I))‖<1) :
    lowerDeterminantRoot r w^2=(complexifiedRegularizedTransfer a r z w).det := by
  unfold lowerDeterminantRoot
  rw [upperDeterminantRoot_sq ha hr hz (-w)
    (by simpa only [neg_mul] using hm) (by simpa only [neg_mul] using hi)]
  exact complexifiedRegularizedTransfer_det_neg ha r hz w

theorem lowerDeterminantRoot_ne_zero {r : ℝ} (hr : r≠0) (w : ℂ) :
    lowerDeterminantRoot r w≠0 := upperDeterminantRoot_ne_zero hr (-w)

theorem differentiableAt_lowerDeterminantRoot {r : ℝ} {w : ℂ}
    (hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1)
    (hi : ‖(r:ℂ)⁻¹*Complex.exp (-(w*Complex.I))‖<1) :
    DifferentiableAt ℂ (lowerDeterminantRoot r) w := by
  exact (differentiableAt_upperDeterminantRoot
    (by simpa only [neg_mul] using hm) (by simpa only [neg_mul] using hi)).comp w
      differentiableAt_id.neg

theorem lowerDeterminantRoot_periodic (r : ℝ) :
    Function.Periodic (lowerDeterminantRoot r) ((2*Real.pi:ℝ):ℂ) := by
  intro w
  change upperDeterminantRoot r (-(w+((2*Real.pi:ℝ):ℂ)))=upperDeterminantRoot r (-w)
  rw [show -(w+((2*Real.pi:ℝ):ℂ))= -w-((2*Real.pi:ℝ):ℂ) by ring]
  exact (upperDeterminantRoot_periodic r).sub_eq (-w)

theorem norm_scaled_complexPhase {r : ℝ} (hr : 0<r) (w : ℂ) :
    ‖(r:ℂ)*Complex.exp (w*Complex.I)‖=Real.exp (Real.log r-w.im) := by
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hr,Complex.norm_exp]
  simp only [Complex.mul_re,Complex.I_re,mul_zero,Complex.I_im,mul_one,zero_sub]
  rw [Real.exp_sub,Real.exp_log hr]
  rw [Real.exp_neg]
  rfl

theorem norm_inv_scaled_complexPhase {r : ℝ} (hr : 0<r) (w : ℂ) :
    ‖(r:ℂ)⁻¹*Complex.exp (w*Complex.I)‖=Real.exp (-Real.log r-w.im) := by
  rw [norm_mul,norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hr,Complex.norm_exp]
  simp only [Complex.mul_re,Complex.I_re,mul_zero,Complex.I_im,mul_one,zero_sub]
  simp only [sub_eq_add_neg,Real.exp_add,Real.exp_neg,Real.exp_log hr]

private theorem mode_norm_eventually_lt {c w : ℂ} {sgn : ℝ}
    (h : ‖c*Complex.exp ((sgn:ℂ)*(w*Complex.I))‖<1) :
    ∀ᶠ v:ℂ in 𝓝 w,‖c*Complex.exp ((sgn:ℂ)*(v*Complex.I))‖<1 := by
  have hc : Continuous (fun v:ℂ => ‖c*Complex.exp ((sgn:ℂ)*(v*Complex.I))‖) := by fun_prop
  exact hc.continuousAt.eventually (gt_mem_nhds h)

theorem innerDeterminantRoot_germ {a r : ℝ} (ha : a≠0) {z w : ℂ} (hz : z≠0)
    (hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1)
    (hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1) :
    AnalyticAt ℂ (innerDeterminantRoot r) w ∧
      ∀ᶠ v:ℂ in 𝓝 w,innerDeterminantRoot r v≠0 ∧
        innerDeterminantRoot r v^2=(complexifiedRegularizedTransfer a r z v).det := by
  have hp' : ∀ᶠ v:ℂ in 𝓝 w,‖(r:ℂ)*Complex.exp (v*Complex.I)‖<1 := by
    simpa only [Complex.ofReal_one,one_mul] using
      mode_norm_eventually_lt (sgn:=1) (by simpa only [Complex.ofReal_one,one_mul] using hp)
  have hm' : ∀ᶠ v:ℂ in 𝓝 w,‖(r:ℂ)*Complex.exp (-(v*Complex.I))‖<1 := by
    simpa only [Complex.ofReal_neg,Complex.ofReal_one,neg_one_mul] using
      mode_norm_eventually_lt (sgn:= -1)
        (by simpa only [Complex.ofReal_neg,Complex.ofReal_one,neg_one_mul] using hm)
  constructor
  · apply Complex.analyticAt_iff_eventually_differentiableAt.mpr
    filter_upwards [hp',hm'] with v hvp hvm
    exact differentiableAt_innerDeterminantRoot hvp hvm
  · filter_upwards [hp',hm'] with v hvp hvm
    exact ⟨innerDeterminantRoot_ne_zero r v,innerDeterminantRoot_sq ha hz v hvp hvm⟩

theorem upperDeterminantRoot_germ {a r : ℝ} (ha : a≠0) (hr : r≠0)
    {z w : ℂ} (hz : z≠0)
    (hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1)
    (hi : ‖(r:ℂ)⁻¹*Complex.exp (w*Complex.I)‖<1) :
    AnalyticAt ℂ (upperDeterminantRoot r) w ∧
      ∀ᶠ v:ℂ in 𝓝 w,upperDeterminantRoot r v≠0 ∧
        upperDeterminantRoot r v^2=(complexifiedRegularizedTransfer a r z v).det := by
  have hp' : ∀ᶠ v:ℂ in 𝓝 w,‖(r:ℂ)*Complex.exp (v*Complex.I)‖<1 := by
    simpa only [Complex.ofReal_one,one_mul] using
      mode_norm_eventually_lt (sgn:=1) (by simpa only [Complex.ofReal_one,one_mul] using hp)
  have hi' : ∀ᶠ v:ℂ in 𝓝 w,‖(r:ℂ)⁻¹*Complex.exp (v*Complex.I)‖<1 := by
    simpa only [Complex.ofReal_one,one_mul] using
      mode_norm_eventually_lt (sgn:=1) (by simpa only [Complex.ofReal_one,one_mul] using hi)
  constructor
  · apply Complex.analyticAt_iff_eventually_differentiableAt.mpr
    filter_upwards [hp',hi'] with v hvp hvi
    exact differentiableAt_upperDeterminantRoot hvp hvi
  · filter_upwards [hp',hi'] with v hvp hvi
    exact ⟨upperDeterminantRoot_ne_zero hr v,upperDeterminantRoot_sq ha hr hz v hvp hvi⟩

theorem lowerDeterminantRoot_germ {a r : ℝ} (ha : a≠0) (hr : r≠0)
    {z w : ℂ} (hz : z≠0)
    (hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1)
    (hi : ‖(r:ℂ)⁻¹*Complex.exp (-(w*Complex.I))‖<1) :
    AnalyticAt ℂ (lowerDeterminantRoot r) w ∧
      ∀ᶠ v:ℂ in 𝓝 w,lowerDeterminantRoot r v≠0 ∧
        lowerDeterminantRoot r v^2=(complexifiedRegularizedTransfer a r z v).det := by
  have hm' : ∀ᶠ v:ℂ in 𝓝 w,‖(r:ℂ)*Complex.exp (-(v*Complex.I))‖<1 := by
    simpa only [Complex.ofReal_neg,Complex.ofReal_one,neg_one_mul] using
      mode_norm_eventually_lt (sgn:= -1)
        (by simpa only [Complex.ofReal_neg,Complex.ofReal_one,neg_one_mul] using hm)
  have hi' : ∀ᶠ v:ℂ in 𝓝 w,‖(r:ℂ)⁻¹*Complex.exp (-(v*Complex.I))‖<1 := by
    simpa only [Complex.ofReal_neg,Complex.ofReal_one,neg_one_mul] using
      mode_norm_eventually_lt (sgn:= -1)
        (by simpa only [Complex.ofReal_neg,Complex.ofReal_one,neg_one_mul] using hi)
  constructor
  · apply Complex.analyticAt_iff_eventually_differentiableAt.mpr
    filter_upwards [hm',hi'] with v hvm hvi
    exact differentiableAt_lowerDeterminantRoot hvm hvi
  · filter_upwards [hm',hi'] with v hvm hvi
    exact ⟨lowerDeterminantRoot_ne_zero hr v,lowerDeterminantRoot_sq ha hr hz v hvm hvi⟩

theorem exists_periodic_determinant_root_at {a r : ℝ} (ha : a≠0)
    (hr : 0<r) (hr1 : r≤1) {z : ℂ} (hz : z≠0) (w : ℂ)
    (hexceptional : |w.im|≠ -Real.log r) :
    ∃g:ℂ→ℂ,Function.Periodic g ((2*Real.pi:ℝ):ℂ) ∧
      AnalyticAt ℂ g w ∧ ∀ᶠ v:ℂ in 𝓝 w,g v≠0 ∧
        g v^2=(complexifiedRegularizedTransfer a r z v).det := by
  have hlog : Real.log r≤0 := Real.log_nonpos hr.le hr1
  by_cases hupper : -Real.log r<w.im
  · have hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1 := by
      rw [norm_scaled_complexPhase hr,Real.exp_lt_one_iff]
      linarith
    have hi : ‖(r:ℂ)⁻¹*Complex.exp (w*Complex.I)‖<1 := by
      rw [norm_inv_scaled_complexPhase hr,Real.exp_lt_one_iff]
      linarith
    exact ⟨upperDeterminantRoot r,upperDeterminantRoot_periodic r,
      upperDeterminantRoot_germ ha hr.ne' hz hp hi⟩
  by_cases hlower : w.im<Real.log r
  · have hp : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1 := by
      have h := norm_scaled_complexPhase hr (-w)
      simp only [neg_mul,Complex.neg_im] at h
      rw [h,Real.exp_lt_one_iff]
      linarith
    have hi : ‖(r:ℂ)⁻¹*Complex.exp (-(w*Complex.I))‖<1 := by
      have h := norm_inv_scaled_complexPhase hr (-w)
      simp only [neg_mul,Complex.neg_im] at h
      rw [h,Real.exp_lt_one_iff]
      linarith
    exact ⟨lowerDeterminantRoot r,lowerDeterminantRoot_periodic r,
      lowerDeterminantRoot_germ ha hr.ne' hz hp hi⟩
  have hb : Real.log r<w.im ∧ w.im< -Real.log r := by
    constructor
    · apply lt_of_le_of_ne (le_of_not_gt hlower)
      intro he
      apply hexceptional
      rw [← he,abs_of_nonpos hlog]
    · apply lt_of_le_of_ne (le_of_not_gt hupper)
      intro he
      apply hexceptional
      rw [he,abs_of_nonneg (neg_nonneg.mpr hlog)]
  have hp : ‖(r:ℂ)*Complex.exp (w*Complex.I)‖<1 := by
    rw [norm_scaled_complexPhase hr,Real.exp_lt_one_iff]
    linarith [hb.1]
  have hm : ‖(r:ℂ)*Complex.exp (-(w*Complex.I))‖<1 := by
    have h := norm_scaled_complexPhase hr (-w)
    simp only [neg_mul,Complex.neg_im] at h
    rw [h,Real.exp_lt_one_iff]
    linarith [hb.2]
  exact ⟨innerDeterminantRoot r,innerDeterminantRoot_periodic r,
    innerDeterminantRoot_germ ha hz hp hm⟩

theorem complexifiedRegularizedTransfer_periodic (a r : ℝ) (z : ℂ) :
    Function.Periodic (complexifiedRegularizedTransfer a r z) ((2*Real.pi:ℝ):ℂ) := by
  intro w
  simp only [complexifiedRegularizedTransfer,complexPhase_periodic,complexNegativePhase_periodic]

end UAMO.CMV

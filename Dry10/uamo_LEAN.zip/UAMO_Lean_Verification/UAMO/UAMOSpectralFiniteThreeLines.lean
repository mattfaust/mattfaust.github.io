import UAMO.FiniteProductHadamard
import UAMO.UAMOSpectralComplexGrowth

noncomputable section
namespace UAMO.CMV
open Matrix Set Complex Complex.HadamardThreeLines
open scoped BigOperators Matrix.L2OpNorm

def complexifiedStripBound (a r : ℝ) (z : ℂ) (l u : ℝ) : ℝ :=
  transferNorm (regularizedConstant a r z) +
    |r| *(Real.exp (-l)+Real.exp u)*transferNorm (spectralLeadingMatrix a)

theorem complexifiedStripBound_nonneg (a r : ℝ) (z : ℂ) (l u : ℝ) :
    0≤complexifiedStripBound a r z l u := by
  unfold complexifiedStripBound transferNorm
  positivity

theorem complexifiedTransfer_strip_norm_le (a r : ℝ) (z : ℂ) (x : ℝ) {y l u : ℝ}
    (hy : y∈Icc l u) :
    transferNorm (complexifiedPhaseTransfer a r z y x) ≤ complexifiedStripBound a r z l u := by
  have ht : transferNorm (complexifiedPhaseTransfer a r z y x) ≤
      transferNorm (regularizedConstant a r z) +
      |r| *Real.exp (-y)*transferNorm (spectralLeadingMatrix a) +
      |r| *Real.exp y*transferNorm (spectralLeadingMatrix a) := by
    unfold complexifiedPhaseTransfer
    rw [complexifiedRegularizedTransfer_vertical]
    calc
      _ ≤ (‖regularizedConstant a r z‖ +
            ‖(-Complex.I*(r : ℂ)*spectralPhase x*(Real.exp (-y) : ℂ)) • spectralLeadingMatrix a‖) +
            ‖(Complex.I*(r : ℂ)*spectralPhase (-x)*(Real.exp y : ℂ)) • spectralLeadingMatrix a‖ :=
        (norm_add_le _ _).trans (add_le_add_right (norm_add_le _ _) _)
      _ = _ := by
        simp only [norm_smul,norm_mul,norm_neg,Complex.norm_I,spectralPhase_norm,
          Complex.norm_real,Real.norm_eq_abs,abs_of_pos (Real.exp_pos _),one_mul,mul_one,transferNorm]
        rfl
  have hn : 0≤transferNorm (spectralLeadingMatrix a) := norm_nonneg _
  have h1 := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (neg_le_neg hy.1)) (abs_nonneg r)) hn
  have h2 := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hy.2) (abs_nonneg r)) hn
  unfold complexifiedStripBound
  nlinarith

def holomorphicTransferProduct (a r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ) (w : ℂ) : TransferMatrix :=
  transferProduct (fun t => complexifiedRegularizedTransfer a r z ((t : ℂ)+Complex.I*w)) ω x n

theorem differentiable_holomorphicTransferProduct (a r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ) :
    Differentiable ℂ (holomorphicTransferProduct a r z ω x n) := by
  induction n with
  | zero => exact differentiable_const _
  | succ n ih =>
    have hc : Differentiable ℂ (fun w : ℂ => complexifiedRegularizedTransfer a r z
        ((x+n*ω : ℝ) + Complex.I*w)) :=
      (differentiable_complexifiedRegularizedTransfer a r z).comp (by fun_prop)
    exact hc.mul ih

theorem holomorphicTransferProduct_eq (a r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ) (w : ℂ) :
    holomorphicTransferProduct a r z ω x n w =
      transferProduct (complexifiedPhaseTransfer a r z w.re) ω (x-w.im) n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [holomorphicTransferProduct,transferProduct_succ] at ih ⊢
    rw [ih]
    congr 1
    unfold complexifiedPhaseTransfer
    apply congrArg (complexifiedRegularizedTransfer a r z)
    apply Complex.ext
    all_goals simp
    all_goals ring

theorem holomorphicTransferProduct_real (a r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ) (y : ℝ) :
    holomorphicTransferProduct a r z ω x n y =
      transferProduct (complexifiedPhaseTransfer a r z y) ω x n := by
  simpa using holomorphicTransferProduct_eq a r z ω x n (y : ℂ)

theorem complexifiedTransferProduct_strip_norm_le (a r : ℝ) (z : ℂ) (ω x : ℝ)
    (n : ℕ) {y l u : ℝ} (hy : y∈Icc l u) :
    transferNorm (transferProduct (complexifiedPhaseTransfer a r z y) ω x n) ≤
      complexifiedStripBound a r z l u ^ n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ]
    apply (transferNorm_mul_le _ _).trans
    simpa only [pow_succ,mul_comm] using mul_le_mul
      (complexifiedTransfer_strip_norm_le a r z (x+n*ω) hy) ih
      (norm_nonneg _) (complexifiedStripBound_nonneg a r z l u)

theorem holomorphicTransferProduct_finite_bounded {ι : Type*} (s : Finset ι) (phase : ι→ℝ)
    (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) (l u : ℝ) :
    BddAbove ((fun w => ∏i∈s, ‖holomorphicTransferProduct a r z ω (phase i) n w‖) ''
      verticalClosedStrip l u) := by
  refine ⟨(complexifiedStripBound a r z l u ^ n)^s.card,?_⟩
  rintro _ ⟨w,hw,rfl⟩
  have h : ∀i∈s, ‖holomorphicTransferProduct a r z ω (phase i) n w‖ ≤
      complexifiedStripBound a r z l u ^ n := by
    intro i _
    rw [holomorphicTransferProduct_eq]
    exact complexifiedTransferProduct_strip_norm_le a r z ω (phase i-w.im) n hw
  simpa using Finset.prod_le_prod (fun i _ => norm_nonneg _) h

theorem complexifiedTransfer_finite_log_three_lines {ι : Type*} (s : Finset ι) (phase : ι→ℝ)
    (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) {l u y A B : ℝ}
    (hul : l<u) (hy : y∈Icc l u)
    (hne : ∀i∈s, transferProduct (complexifiedPhaseTransfer a r z y) ω (phase i) n ≠ 0)
    (hleft : ∀x : ℝ, ∑i∈s, transferLogNorm (complexifiedPhaseTransfer a r z l) ω (phase i+x) n ≤ A)
    (hright : ∀x : ℝ, ∑i∈s, transferLogNorm (complexifiedPhaseTransfer a r z u) ω (phase i+x) n ≤ B) :
    (∑i∈s, transferLogNorm (complexifiedPhaseTransfer a r z y) ω (phase i) n) ≤
      (1-(y-l)/(u-l))*A + ((y-l)/(u-l))*B := by
  have h := UAMO.ComplexGrowth.finite_log_norm_sum_three_lines s
    (fun i => holomorphicTransferProduct a r z ω (phase i) n)
    (fun i _ => differentiable_holomorphicTransferProduct a r z ω (phase i) n)
    hul (z:=(y : ℂ)) (by simpa [verticalClosedStrip] using hy)
    (holomorphicTransferProduct_finite_bounded s phase a r z ω n l u)
    (fun i hi => by simpa only [holomorphicTransferProduct_real] using hne i hi)
    (by
      intro w hw
      simpa only [holomorphicTransferProduct_eq,hw,sub_eq_add_neg,transferLogNorm] using hleft (-w.im))
    (by
      intro w hw
      simpa only [holomorphicTransferProduct_eq,hw,sub_eq_add_neg,transferLogNorm] using hright (-w.im))
  simpa only [holomorphicTransferProduct_real,Complex.ofReal_re,transferLogNorm] using h

end UAMO.CMV

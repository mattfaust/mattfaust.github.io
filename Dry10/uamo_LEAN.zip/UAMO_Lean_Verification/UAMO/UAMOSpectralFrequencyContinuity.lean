import UAMO.UAMORecordLowerBound
import UAMO.CMVRecordContinuity

noncomputable section
namespace UAMO.CMV
open Filter Set BourgainJitomirskaya
open scoped Topology

theorem uamo_normalizedTransfer_parametric_lyapunov_continuousAt
    {P:Type*} [TopologicalSpace P] [LocallyCompactSpace P] [FirstCountableTopology P]
    (A:P→ℝ→TransferMatrix) (α:P→ℝ) (a r y:P→ℝ) (z:P→ℂ) (g:P→ℝ→ℂ)
    {K:ℝ} (hA:∀p,TransferCircleBounds (A p) K)
    (hc:Continuous (fun p:P×ℝ => A p.1 p.2)) (hα:Continuous α)
    (hd:∀p x,(A p x).det=1)
    (ha:∀p,a p≠0) (hr:∀p,0<r p) (hr1:∀p,r p≤1) (hz:∀p,z p≠0)
    (hy:∀p,|y p|≠ -Real.log (r p))
    (hrel:∀p x,g p x • A p x=complexifiedPhaseTransfer (a p) (r p) (z p) (y p) x)
    (hdense:Dense {p:P | Irrational (α p)}) {p₀:P} (hirr:Irrational (α p₀)) :
    ContinuousAt (fun p => lyapunov (A p) (2*Real.pi*α p)) p₀ := by
  apply continuousAt_parametric_lyapunov_of_record_lower_bound A α hc hα
    (fun p => (hA p).determinant) (fun p => (hA p).periodic) hdense _ hirr
  intro κ hκ hκ1
  obtain ⟨Q,hQ⟩ := uniform_uamo_lyapunov_record_lower_bound (hA p₀).one_le hκ hκ1
  refine ⟨Q,?_⟩
  intro p q hp hq hrec hL hgap
  exact hQ (a p) (r p) (z p) (y p) (A p) (g p) (hA p) (ha p) (hr p) (hr1 p) (hz p)
    (hy p) (hd p) (hrel p) (α p) q hp hq hrec hL hgap

end UAMO.CMV

import UAMO.UAMOSpectralComplexification

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

theorem spectralLeadingMatrix_norm_le {a : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) :
    transferNorm (spectralLeadingMatrix a) ≤ a⁻¹ := by
  unfold transferNorm
  apply ContinuousLinearMap.opNorm_le_bound _ (inv_nonneg.mpr ha.le)
  intro v
  have hsq : ‖Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) (spectralLeadingMatrix a) v‖^2 ≤ (a⁻¹*‖v‖)^2 := by
    rw [PiLp.norm_sq_eq_of_L2, mul_pow, PiLp.norm_sq_eq_of_L2]
    simp only [Fin.sum_univ_two]
    have hv0 : (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) (spectralLeadingMatrix a) v) 0 =
        ((a : ℂ)⁻¹-(a : ℂ))*v 0-v 1 := by
      change (spectralLeadingMatrix a *ᵥ v) 0 = _
      simp [spectralLeadingMatrix, Matrix.mulVec, dotProduct, Fin.sum_univ_two, sub_eq_add_neg]
    have hv1 : (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) (spectralLeadingMatrix a) v) 1 = -v 0 := by
      change (spectralLeadingMatrix a *ᵥ v) 1 = _
      simp [spectralLeadingMatrix, Matrix.mulVec, dotProduct, Fin.sum_univ_two]
    rw [hv0,hv1]
    simp only [Complex.sq_norm, norm_neg, Complex.normSq_neg, Complex.normSq_apply,
      Complex.sub_re, Complex.sub_im, Complex.mul_re, Complex.mul_im,
      ← Complex.ofReal_inv, Complex.ofReal_re, Complex.ofReal_im,
      zero_mul, mul_zero, sub_zero, add_zero]
    have hfactor : 0 ≤ 1-a^2 := by nlinarith
    have hpos := mul_nonneg hfactor
      (add_nonneg (sq_nonneg (a*(v 0).re+(v 1).re)) (sq_nonneg (a*(v 0).im+(v 1).im)))
    field_simp
    rw [show a*a = a^2 by ring]
    apply (div_le_div_iff_of_pos_right (sq_pos_of_pos ha)).mpr
    nlinarith
  have hn : 0 ≤ a⁻¹*‖v‖ := mul_nonneg (inv_nonneg.mpr ha.le) (norm_nonneg _)
  nlinarith [norm_nonneg (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) (spectralLeadingMatrix a) v)]

end UAMO.CMV

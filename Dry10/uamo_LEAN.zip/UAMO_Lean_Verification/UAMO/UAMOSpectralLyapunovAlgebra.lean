import UAMO.CMVConjugacyGrowth
import Mathlib.LinearAlgebra.Matrix.Trace

noncomputable section
namespace UAMO.CMV
open Matrix

def spectralLeadingMatrix (a : ℝ) : TransferMatrix :=
  !![((a : ℂ)⁻¹-(a : ℂ)), -1; -1, 0]

def spectralEigenvectors (a : ℝ) : TransferMatrix := !![1,(a : ℂ); -(a : ℂ),1]

def spectralEigenvectorsInv (a : ℝ) : TransferMatrix :=
  (1+(a : ℂ)^2)⁻¹ • !![1,-(a : ℂ); (a : ℂ),1]

def spectralEigenvalues (a : ℝ) : TransferMatrix := !![(a : ℂ)⁻¹,0;0,-(a : ℂ)]

theorem spectralEigenvectors_mul_inv (a : ℝ) :
    spectralEigenvectors a * spectralEigenvectorsInv a = 1 := by
  have hd : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2 ≠ 0 by positivity)
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spectralEigenvectors, spectralEigenvectorsInv, Matrix.mul_apply, Fin.sum_univ_two]
  all_goals field_simp <;> ring

theorem spectralEigenvectors_inv_mul (a : ℝ) :
    spectralEigenvectorsInv a * spectralEigenvectors a = 1 := by
  have hd : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2 ≠ 0 by positivity)
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spectralEigenvectors, spectralEigenvectorsInv, Matrix.mul_apply, Fin.sum_univ_two]
  all_goals field_simp; ring

theorem spectralLeadingMatrix_diagonalization {a : ℝ} (ha : a ≠ 0) :
    spectralLeadingMatrix a =
      spectralEigenvectors a * spectralEigenvalues a * spectralEigenvectorsInv a := by
  have hac : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  have hd : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2 ≠ 0 by positivity)
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spectralLeadingMatrix, spectralEigenvectors, spectralEigenvectorsInv,
      spectralEigenvalues, Matrix.mul_apply, Fin.sum_univ_two]
  all_goals field_simp <;> ring

theorem spectralLeadingMatrix_pow {a : ℝ} (ha : a ≠ 0) (n : ℕ) :
    spectralLeadingMatrix a ^ n =
      spectralEigenvectors a * spectralEigenvalues a ^ n * spectralEigenvectorsInv a := by
  induction n with
  | zero => simp [spectralEigenvectors_mul_inv]
  | succ n ih =>
    rw [pow_succ, ih, spectralLeadingMatrix_diagonalization ha]
    simp only [mul_assoc, ← mul_assoc (spectralEigenvectorsInv a) (spectralEigenvectors a),
      spectralEigenvectors_inv_mul, one_mul, pow_succ, mul_assoc]

theorem spectralLeadingMatrix_trace_pow {a : ℝ} (ha : a ≠ 0) (n : ℕ) :
    (spectralLeadingMatrix a ^ n).trace = (a : ℂ)⁻¹ ^ n + (-(a : ℂ)) ^ n := by
  rw [spectralLeadingMatrix_pow ha, Matrix.trace_mul_cycle,
    spectralEigenvectors_inv_mul, one_mul]
  have hd : spectralEigenvalues a = Matrix.diagonal ![(a : ℂ)⁻¹,-(a : ℂ)] := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [spectralEigenvalues, Matrix.diagonal]
  rw [hd, Matrix.diagonal_pow]
  simp [Matrix.trace_fin_two]

def regularizedTransfer (a r : ℝ) (z : ℂ) (x : ℝ) : TransferMatrix :=
  ((1+r^2 : ℝ) : ℂ) •
    physicalTransfer (coupling a) (complementaryCoupling a) (oddAlpha r x) 1 z

def regularizedConstant (a r : ℝ) (z : ℂ) : TransferMatrix :=
  regularizedTransfer a r z 0

theorem regularizedTransfer_sine {a : ℝ} (ha : a ≠ 0) (r : ℝ) (z : ℂ) (x : ℝ) :
    regularizedTransfer a r z x = regularizedConstant a r z +
      ((2*r*Real.sin x : ℝ) : ℂ) • spectralLeadingMatrix a := by
  have hac : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  have hda : 1+(a : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+a^2 ≠ 0 by positivity)
  have hdr : 1+(r : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+r^2 ≠ 0 by positivity)
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [regularizedTransfer, regularizedConstant, physicalTransfer, oddAlpha,
      spectralLeadingMatrix, coupling, complementaryCoupling]
  all_goals field_simp; ring

theorem regularizedTransfer_laurent {a : ℝ} (ha : a ≠ 0) (r : ℝ) (z : ℂ) (x : ℝ) :
    regularizedTransfer a r z x = regularizedConstant a r z +
      (-Complex.I*(r : ℂ)*Complex.exp ((x : ℂ)*Complex.I)) • spectralLeadingMatrix a +
      (Complex.I*(r : ℂ)*Complex.exp (-((x : ℂ)*Complex.I))) • spectralLeadingMatrix a := by
  rw [regularizedTransfer_sine ha]
  have he : ((2*r*Real.sin x : ℝ) : ℂ) =
      -Complex.I*(r : ℂ)*Complex.exp ((x : ℂ)*Complex.I) +
      Complex.I*(r : ℂ)*Complex.exp (-((x : ℂ)*Complex.I)) := by
    rw [Complex.exp_mul_I, show -((x : ℂ)*Complex.I) = (-x : ℂ)*Complex.I by ring,
      Complex.exp_mul_I]
    simp only [Complex.cos_neg, Complex.sin_neg, ← Complex.ofReal_sin, ← Complex.ofReal_cos]
    push_cast
    ring_nf
    simp [Complex.I_sq]
  rw [he, add_smul]
  abel

theorem spectralLeadingMatrix_trace_pow_bound {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r)
    (n : ℕ) :
    ‖(Complex.I*(r : ℂ))^n * (spectralLeadingMatrix a ^ n).trace‖ ≤
      (r/a)^n + (r*a)^n := by
  rw [spectralLeadingMatrix_trace_pow ha.ne', mul_add]
  calc
    _ ≤ ‖(Complex.I*(r : ℂ))^n * (a : ℂ)⁻¹^n‖ +
        ‖(Complex.I*(r : ℂ))^n * (-(a : ℂ))^n‖ := norm_add_le _ _
    _ = _ := by
      simp only [norm_mul, norm_pow, Complex.norm_I, Complex.norm_real, Real.norm_eq_abs,
        abs_of_nonneg hr, abs_of_pos ha, norm_inv, norm_neg, one_mul, one_pow, div_eq_mul_inv, mul_pow]

end UAMO.CMV

import UAMO.PhysicalCouplingSpectralApproximation
import UAMO.UAMOUpperHeightContinuity
import UAMO.UAMOSpectralLyapunovNonsingular
import UAMO.UAMOSpectralComplexEnvelope

noncomputable section
namespace UAMO.CMV
open Filter Set PhysicalRepresentation PhysicalDOS
open scoped Topology

def cornerApproachingCoupling (n : ℕ) : ℝ := 1-1/((n:ℝ)+2)

theorem cornerApproachingCoupling_pos (n : ℕ) : 0<cornerApproachingCoupling n := by
  have hn : (1:ℝ)<(n:ℝ)+2 := by have hn0 := Nat.cast_nonneg (α:=ℝ) n; linarith
  have hh : 1/((n:ℝ)+2)<1 := (div_lt_one (by positivity)).mpr hn
  dsimp only [cornerApproachingCoupling]
  linarith

theorem cornerApproachingCoupling_lt_one (n : ℕ) : cornerApproachingCoupling n<1 := by
  have hh : 0<(1:ℝ)/((n:ℝ)+2) := by positivity
  dsimp only [cornerApproachingCoupling]
  linarith

theorem tendsto_cornerApproachingCoupling :
    Tendsto cornerApproachingCoupling atTop (𝓝 (1:ℝ)) := by
  have ht := (tendsto_add_atTop_iff_nat 2).2
    (tendsto_const_div_atTop_nhds_zero_nat (1:ℝ))
  have hs := (tendsto_const_nhds (x:=(1:ℝ))).sub ht
  simpa only [cornerApproachingCoupling,Nat.cast_add,Nat.cast_ofNat,sub_zero] using hs

def cornerApproachingClosedCoupling (n : ℕ) : Icc (0:ℝ) 1 :=
  ⟨cornerApproachingCoupling n,
    ⟨(cornerApproachingCoupling_pos n).le,(cornerApproachingCoupling_lt_one n).le⟩⟩

theorem tendsto_cornerApproachingClosedCoupling :
    Tendsto cornerApproachingClosedCoupling atTop
      (𝓝 (⟨1,by constructor <;> norm_num⟩:Icc (0:ℝ) 1)) :=
  tendsto_subtype_rng.mpr tendsto_cornerApproachingCoupling

theorem complexifiedLyapunov_corner_spectral_le_height {α : ℝ} (hα : Irrational α)
    (θ : ℝ) {z : ℂ}
    (hz : z∈spectrum ℂ (cstarWalk (coupling 1) (coupling 1) α θ))
    {y : ℝ} (hy : 0<y) :
    complexifiedLyapunov 1 1 (2*Real.pi*α) z y≤y := by
  have hnorm : ‖z‖=1 := by
    have h := spectrum.subset_circle_of_unitary (𝕜:=ℂ)
      (physicalCStarWalk_unitary 1 1 α θ (by norm_num) le_rfl (by norm_num) le_rfl) hz
    simpa only [Metric.mem_sphere,dist_zero_right] using h
  let zc : Circle := ⟨z,mem_sphere_zero_iff_norm.mpr hnorm⟩
  obtain ⟨w,hw,htw⟩ := exists_physical_circle_spectral_sequence 1 α (by norm_num) le_rfl
    hα cornerApproachingClosedCoupling tendsto_cornerApproachingClosedCoupling θ zc hz
  have hlim := tendsto_complexifiedLyapunov_at_corner (a:=1) (by norm_num) hy hα
    cornerApproachingCoupling w tendsto_cornerApproachingCoupling
      (Eventually.of_forall (fun n=>(cornerApproachingCoupling_lt_one n).le)) htw
  apply le_of_tendsto hlim
  apply Eventually.of_forall
  intro n
  have hzero := uamoLyapunov_spectral_zero_nonsingular (a:=1) (by norm_num) le_rfl
    (cornerApproachingCoupling_pos n) (cornerApproachingCoupling_lt_one n)
    (cornerApproachingCoupling_lt_one n).le hα θ (hw n)
  have hupper := (complexifiedLyapunov_physical_envelope (a:=1) (by norm_num) le_rfl
    (cornerApproachingCoupling_pos n) (cornerApproachingCoupling_lt_one n).le
    hα (w n).norm_coe y).2
  simpa only [hzero,zero_add,abs_of_pos hy] using hupper

theorem uamoLyapunov_corner_spectral_zero {α : ℝ} (hα : Irrational α)
    (θ : ℝ) {z : ℂ}
    (hz : z∈spectrum ℂ (cstarWalk (coupling 1) (coupling 1) α θ)) :
    uamoLyapunov 1 1 (2*Real.pi*α) z=0 := by
  have hnorm : ‖z‖=1 := by
    have h := spectrum.subset_circle_of_unitary (𝕜:=ℂ)
      (physicalCStarWalk_unitary 1 1 α θ (by norm_num) le_rfl (by norm_num) le_rfl) hz
    simpa only [Metric.mem_sphere,dist_zero_right] using h
  have hz0 : z≠0 := norm_ne_zero_iff.mp (by rw [hnorm]; norm_num)
  apply le_antisymm _ (uamoLyapunov_one_nonneg (by norm_num : (0:ℝ)<1) _ hz0)
  apply le_of_forall_pos_le_add
  intro y hy
  have hlow := (le_max_left (uamoLyapunov 1 1 (2*Real.pi*α) z)
      (|y|+Real.log ((1:ℝ)/1))).trans
    (complexifiedLyapunov_physical_envelope (a:=1) (r:=1) (by norm_num) le_rfl
      (by norm_num) le_rfl hα hnorm y).1
  simpa only [zero_add] using hlow.trans (complexifiedLyapunov_corner_spectral_le_height hα θ hz hy)

end UAMO.CMV

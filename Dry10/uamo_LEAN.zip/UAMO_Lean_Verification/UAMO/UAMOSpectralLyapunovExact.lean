import UAMO.UAMOSpectralLyapunovCorner

noncomputable section
namespace UAMO.CMV
open PhysicalRepresentation

theorem uamoLyapunov_spectral_eq {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hr1 : r≤1)
    (hα : Irrational α) (θ : ℝ) {z : ℂ}
    (hz : z∈spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ)) :
    uamoLyapunov a r (2*Real.pi*α) z=max 0 (Real.log (r/a)) := by
  by_cases hcorner : a<1 ∨ r<1
  · exact uamoLyapunov_spectral_eq_except_corner ha ha1 hr hr1 hcorner hα θ hz
  · have haeq : a=1 := le_antisymm ha1 (le_of_not_gt (fun h=>hcorner (Or.inl h)))
    have hreq : r=1 := le_antisymm hr1 (le_of_not_gt (fun h=>hcorner (Or.inr h)))
    subst a r
    simpa only [div_self (one_ne_zero: (1:ℝ)≠0),Real.log_one,max_self] using
      uamoLyapunov_corner_spectral_zero hα θ hz

end UAMO.CMV

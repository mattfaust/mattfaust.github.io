import UAMO.UAMOSpectralLyapunovRationalHopping
import UAMO.CMVSingularThoulessBounds
import UAMO.CMVSingularCellConjugacy

noncomputable section
namespace UAMO.CMV
open Matrix
open scoped Matrix.L2OpNorm

theorem transfer_trace_eq_one_add_det_of_fixed (M : TransferMatrix)
    (hfix : (1-M).det = 0) : M.trace = 1+M.det := by
  have hid : (1-M).det = 1-M.trace+M.det := by
    simp [Matrix.det_fin_two, Matrix.trace_fin_two, Matrix.sub_apply, Matrix.one_apply]
    ring
  rw [hid] at hfix
  linear_combination -hfix

theorem transfer_trace_norm_le_two_of_fixed (M : TransferMatrix)
    (hfix : (1-M).det = 0) (hdet : ‖M.det‖ = 1) : ‖M.trace‖ ≤ 2 := by
  rw [transfer_trace_eq_one_add_det_of_fixed M hfix]
  calc
    _ ≤ ‖(1 : ℂ)‖+‖M.det‖ := norm_add_le _ _
    _ = 2 := by rw [norm_one,hdet]; norm_num

theorem finiteCMV_det_zero_of_mem_spectrum (n : ℕ) (a r ω x : ℝ) {z : ℂ}
    (hz : z ∈ spectrum ℂ (finiteCMV n a r ω x)) :
    (z • (1 : FiniteMatrix n)-finiteCMV n a r ω x).det = 0 := by
  have hunit : ¬ IsUnit (z • (1 : FiniteMatrix n)-finiteCMV n a r ω x) := by
    simpa only [spectrum.mem_iff, Algebra.algebraMap_eq_smul_one] using hz
  by_contra hdet
  exact hunit ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hdet))

theorem finiteMonodromy_det_zero_of_mem_spectrum_regular (n : ℕ) {a r : ℝ}
    (ha : 0 < a) (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ}
    (hs : z ∈ spectrum ℂ (finiteCMV n a r ω x)) :
    (1-finiteMonodromy n a r ω x z).det = 0 := by
  have hz : z ≠ 0 := norm_ne_zero_iff.mp (by
    rw [finiteCMV_spectrum_norm n a r ω x hs]
    norm_num)
  have h := finiteCMV_det_norm_normalization_regular n ha ω x hq hz
  rw [finiteCMV_det_zero_of_mem_spectrum n a r ω x hs,norm_zero] at h
  have hc : (coupling a * ‖z‖)^(n+1) *
      (∏ j : ZMod (n+1), ‖physicalHopping r (x+j.val*ω)‖) ≠ 0 := by
    exact mul_ne_zero (pow_ne_zero _ (mul_ne_zero (coupling_pos ha).ne' (norm_ne_zero_iff.mpr hz)))
      (Finset.prod_ne_zero_iff.mpr (fun j _ => norm_ne_zero_iff.mpr (hq j)))
  exact norm_eq_zero.mp ((mul_eq_zero.mp h.symm).resolve_left hc)

theorem finiteMonodromy_trace_norm_le_two_of_mem_spectrum (n : ℕ) {a r : ℝ}
    (ha : 0 < a) (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ}
    (hs : z ∈ spectrum ℂ (finiteCMV n a r ω x)) :
    ‖(finiteMonodromy n a r ω x z).trace‖ ≤ 2 := by
  have hz : z ≠ 0 := norm_ne_zero_iff.mp (by
    rw [finiteCMV_spectrum_norm n a r ω x hs]
    norm_num)
  exact transfer_trace_norm_le_two_of_fixed _
    (finiteMonodromy_det_zero_of_mem_spectrum_regular n ha ω x hq hs)
    (finiteMonodromy_det_norm_regular n ha ω x hq hz)

theorem finiteMonodromy_trace_eq_physical (n : ℕ) {a : ℝ} (ha : 0 < a)
    (r ω x : ℝ) {z : ℂ} (hz : z ≠ 0) :
    (finiteMonodromy n a r ω x z).trace =
      (transferProduct (uamoTransfer a r z) ω x (n+1)).trace := by
  obtain ⟨C,D,hCD,hDC,hconj⟩ := exists_gz_physical_conjugators ha hz
  rw [finiteMonodromy_eq_transferProduct,
    transferProduct_conjugacy _ _ C D hCD hDC (hconj r),
    Matrix.trace_mul_cycle, hDC, Matrix.one_mul]

theorem physical_period_trace_norm_le_two_of_finite_spectrum (n : ℕ) {a r : ℝ}
    (ha : 0 < a) (ω x : ℝ) (hq : FiniteHoppingRegular n r ω x) {z : ℂ}
    (hs : z ∈ spectrum ℂ (finiteCMV n a r ω x)) :
    ‖(transferProduct (uamoTransfer a r z) ω x (n+1)).trace‖ ≤ 2 := by
  have hz : z ≠ 0 := norm_ne_zero_iff.mp (by
    rw [finiteCMV_spectrum_norm n a r ω x hs]
    norm_num)
  rw [← finiteMonodromy_trace_eq_physical n ha r ω x hz]
  exact finiteMonodromy_trace_norm_le_two_of_mem_spectrum n ha ω x hq hs

theorem regularizedTransfer_product_eq_scalar_finite (a r : ℝ) (z : ℂ) (ω x : ℝ)
    (N : ℕ) (hq : ∀ j : ℕ, j < N → physicalHopping r (x+j*ω) ≠ 0) :
    transferProduct (regularizedTransfer a r z) ω x N =
      (∏ j ∈ Finset.range N, regularizingScalar r (x+j*ω)) •
        transferProduct (uamoTransfer a r z) ω x N := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [transferProduct_succ, regularizedTransfer_eq_scalar _ _ _ _ (hq N (by omega)),
      ih (fun j hj => hq j (by omega)), smul_mul_smul_comm,
      Finset.prod_range_succ, transferProduct_succ]
    congr 1
    ring

theorem regularized_rational_trace_le_eight_of_finite_spectrum (n : ℕ) {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (hr1 : r ≤ 1) (p : ℤ)
    (hcop : p.natAbs.Coprime (n+1)) (x : ℝ) {z : ℂ}
    (hq : FiniteHoppingRegular n r (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) x)
    (hs : z ∈ spectrum ℂ (finiteCMV n a r (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) x)) :
    ‖(transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) x (n+1)).trace‖ ≤ 8 := by
  let ω := 2*Real.pi*((p : ℝ)/(n+1 : ℕ))
  have hfin : ∀ j : ℕ, j < n+1 → physicalHopping r (x+j*ω) ≠ 0 := by
    intro j hj
    have h := hq (j : ZMod (n+1))
    simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt hj] using h
  change ‖(transferProduct (regularizedTransfer a r z) ω x (n+1)).trace‖ ≤ 8
  rw [regularizedTransfer_product_eq_scalar_finite a r z ω x (n+1) hfin,
    Matrix.trace_smul, smul_eq_mul, norm_mul]
  have hg := regularizingScalar_cycle_product_norm_le_four hr hr1 ω x (n+1) (by omega)
    (spectralPhase_rational_primitive p (n+1) (by omega) hcop)
  have ht := physical_period_trace_norm_le_two_of_finite_spectrum n ha ω x hq hs
  nlinarith [norm_nonneg (∏ j ∈ Finset.range (n+1), regularizingScalar r (x+j*ω)),
    norm_nonneg (transferProduct (uamoTransfer a r z) ω x (n+1)).trace]

theorem regularized_rational_trace_le_sixteen_of_finite_spectrum (n : ℕ) {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hra : r ≤ a) (p : ℤ)
    (hcop : p.natAbs.Coprime (n+1)) (x y : ℝ) {z : ℂ}
    (hq : FiniteHoppingRegular n r (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) y)
    (hs : z ∈ spectrum ℂ (finiteCMV n a r (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) y)) :
    ‖(transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) x (n+1)).trace‖ ≤ 16 := by
  have hz : z ≠ 0 := norm_ne_zero_iff.mp (by
    rw [finiteCMV_spectrum_norm n a r _ y hs]
    norm_num)
  have hosc := regularizedTransfer_rational_trace_oscillation_subcritical
    ha ha1 hr hra p (n+1) (by omega) hcop hz x y
  have hy := regularized_rational_trace_le_eight_of_finite_spectrum n ha hr (hra.trans ha1) p hcop y hq hs
  have ht := norm_add_le
    ((transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) x (n+1)).trace-
      (transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) y (n+1)).trace)
    (transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) y (n+1)).trace
  rw [sub_add_cancel] at ht
  linarith

theorem regularized_rational_trace_le_sixteen_of_finite_spectrum_nonsingular (n : ℕ)
    {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r < 1) (hra : r ≤ a)
    (p : ℤ) (hcop : p.natAbs.Coprime (n+1)) (x y : ℝ) {z : ℂ}
    (hs : z ∈ spectrum ℂ (finiteCMV n a r (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) y)) :
    ‖(transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(n+1 : ℕ))) x (n+1)).trace‖ ≤ 16 :=
  regularized_rational_trace_le_sixteen_of_finite_spectrum n ha ha1 hr hra p hcop x y
    (fun _ => physicalHopping_ne_zero hr hr1 _) hs

end UAMO.CMV

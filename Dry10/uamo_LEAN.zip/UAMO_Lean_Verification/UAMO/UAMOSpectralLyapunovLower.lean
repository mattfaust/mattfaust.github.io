import UAMO.UAMOSpectralLyapunovNormalization
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter CircleDOS
open scoped Topology

theorem spectralPhase_eq_char (x : ℝ) :
    spectralPhase x = logFourierChar 1 ((2*Real.pi)⁻¹*x) := by
  unfold spectralPhase logFourierChar
  congr 1
  have hp : (Real.pi : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr Real.pi_ne_zero
  push_cast
  field_simp
  ring

theorem spectralPhase_two_pi (t : ℝ) :
    spectralPhase (2*Real.pi*t) = logFourierChar 1 t := by
  rw [spectralPhase_eq_char]
  congr 1
  field_simp

theorem polynomial_eval_char_ne_zero_ae (P : Polynomial ℂ) (hP : P ≠ 0) :
    ∀ᵐ t ∂volume, P.eval (logFourierChar 1 t) ≠ 0 := by
  have hall := ae_all_iff.mpr (fun i : Fin (polynomialRootList P).length =>
    logFourierChar_root_ne_zero_ae ((polynomialRootList P).get i))
  filter_upwards [hall] with t ht
  rw [polynomial_eval_root_product]
  exact mul_ne_zero (Polynomial.leadingCoeff_ne_zero.mpr hP)
    (Finset.prod_ne_zero_iff.mpr (fun i _ => ht i))

theorem polynomial_eval_phase_ne_zero_ae (P : Polynomial ℂ) (hP : P ≠ 0) :
    ∀ᵐ x ∂volume, P.eval (spectralPhase x) ≠ 0 := by
  have h := (Measure.quasiMeasurePreserving_smul (volume : Measure ℝ)
    (show (2*Real.pi)⁻¹ ≠ 0 by positivity)).ae (polynomial_eval_char_ne_zero_ae P hP)
  simpa only [smul_eq_mul, ← spectralPhase_eq_char] using h

theorem polynomial_phase_log_integrable (P : Polynomial ℂ) (hP : P ≠ 0) (s t : ℝ) :
    IntervalIntegrable (fun x => Real.log ‖P.eval (spectralPhase x)‖) volume s t := by
  have h := (polynomial_circle_log_integrable P hP
    ((2*Real.pi)⁻¹*s) ((2*Real.pi)⁻¹*t)).comp_mul_left ((2*Real.pi)⁻¹)
  simpa only [mul_div_cancel_left₀ _ (show (2*Real.pi)⁻¹ ≠ 0 by positivity),
    ← spectralPhase_eq_char] using h

theorem polynomial_phase_log_jensen (P : Polynomial ℂ) (hP0 : P.eval 0 ≠ 0) :
    Real.log ‖P.eval 0‖ ≤
      (∫ x in (0 : ℝ)..(2*Real.pi), Real.log ‖P.eval (spectralPhase x)‖)/(2*Real.pi) := by
  have h := polynomial_circle_log_ge_zero_value P hP0
  simp_rw [← spectralPhase_two_pi] at h
  rw [intervalIntegral.integral_comp_mul_left
    (fun x => Real.log ‖P.eval (spectralPhase x)‖) (show 2*Real.pi ≠ 0 by positivity)] at h
  simpa only [mul_zero, mul_one, zero_mul, one_mul, smul_eq_mul, div_eq_mul_inv, mul_comm] using h

theorem regularizingScalar_sum_log_integrable {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (ω : ℝ) (n : ℕ) (s t : ℝ) :
    IntervalIntegrable (fun x => ∑ j ∈ Finset.range n,
      Real.log ‖regularizingScalar r (x+j*ω)‖) volume s t := by
  have hi : ∀ j ∈ Finset.range n, IntervalIntegrable
      (fun x => Real.log ‖regularizingScalar r (x+j*ω)‖) volume s t := by
    intro j _
    have h := (regularizingScalar_log_integrable hr0 hr1 (s+j*ω) (t+j*ω)).comp_add_right (j*ω)
    simpa only [add_sub_cancel_right] using h
  convert IntervalIntegrable.sum (Finset.range n)
    (f := fun j x => Real.log ‖regularizingScalar r (x+j*ω)‖) hi using 1
  ext x
  simp only [Finset.sum_apply]

theorem regularizingScalar_sum_log_integral {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (ω : ℝ) (n : ℕ) :
    (∫ x in (0 : ℝ)..(2*Real.pi), ∑ j ∈ Finset.range n,
      Real.log ‖regularizingScalar r (x+j*ω)‖) = 0 := by
  rw [intervalIntegral.integral_finset_sum]
  · simp only [regularizingScalar_log_integral_shift hr0 hr1, Finset.sum_const_zero]
  · intro j _
    have h := (regularizingScalar_log_integrable hr0 hr1 (0+j*ω) (2*Real.pi+j*ω)).comp_add_right (j*ω)
    simpa only [add_sub_cancel_right] using h

end UAMO.CMV

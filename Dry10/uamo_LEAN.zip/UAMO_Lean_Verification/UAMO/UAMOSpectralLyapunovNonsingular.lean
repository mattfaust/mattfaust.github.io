import UAMO.UAMOSpectralUpperFromContinuity
import UAMO.UAMOPhysicalJointContinuity
import UAMO.UAMOLyapunovDuality

noncomputable section
namespace UAMO.CMV
open PhysicalRepresentation PhysicalDuality PhysicalDOS

theorem uamoLyapunov_spectral_zero_nonsingular {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hr1 : r<1) (hra : r≤a)
    (hα : Irrational α) (θ : ℝ) {z : ℂ}
    (hz : z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ)) :
    uamoLyapunov a r (2*Real.pi*α) z=0 := by
  have hnorm : ‖z‖=1 := by
    have h := spectrum.subset_circle_of_unitary (𝕜:=ℂ)
      (physicalCStarWalk_unitary a r α θ ha.le ha1 hr.le hr1.le) hz
    simpa only [Metric.mem_sphere, dist_zero_right] using h
  let zc : Circle := ⟨z,mem_sphere_zero_iff_norm.mpr hnorm⟩
  exact uamoLyapunov_spectral_zero_of_joint_continuity ha ha1 hr.le hr1 hra hα θ zc hz
    (uamoLyapunov_joint_continuousAt_circle ha hr hr1 hα zc)

theorem uamoLyapunov_spectral_eq_except_corner {a r α : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hr1 : r≤1)
    (hcorner : a<1 ∨ r<1) (hα : Irrational α) (θ : ℝ) {z : ℂ}
    (hz : z ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ)) :
    uamoLyapunov a r (2*Real.pi*α) z=max 0 (Real.log (r/a)) := by
  by_cases hra : r≤a
  · have hrlt : r<1 := hcorner.elim (fun h => hra.trans_lt h) id
    rw [uamoLyapunov_spectral_zero_nonsingular ha ha1 hr hrlt hra hα θ hz]
    symm
    exact max_eq_left (Real.log_nonpos (div_nonneg hr.le ha.le)
      ((div_le_one ha).mpr hra))
  · have har : a<r := lt_of_not_ge hra
    have halt : a<1 := har.trans_le hr1
    have hdual : z ∈ spectrum ℂ (cstarWalk (coupling r) (coupling a) (-α) θ) := by
      rwa [← physical_cstar_spectrum_exchange a r α ha.le ha1 hr.le hr1 hα θ θ]
    have hzero := uamoLyapunov_spectral_zero_nonsingular hr hr1 ha halt har.le hα.neg θ hdual
    have hnorm : ‖z‖=1 := by
      have h := spectrum.subset_circle_of_unitary (𝕜:=ℂ)
        (physicalCStarWalk_unitary a r α θ ha.le ha1 hr.le hr1) hz
      simpa only [Metric.mem_sphere, dist_zero_right] using h
    have hz0 : z≠0 := norm_ne_zero_iff.mp (by rw [hnorm]; norm_num)
    rw [uamoLyapunov_exchange ha ha1 hr hr1 α hz0,hzero,zero_add,
      max_eq_right (Real.log_nonneg ((one_le_div ha).mpr har.le))]

end UAMO.CMV

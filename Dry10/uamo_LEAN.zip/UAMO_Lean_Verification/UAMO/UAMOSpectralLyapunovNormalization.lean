import UAMO.UAMOSpectralLyapunovPolynomial
import UAMO.CMVSingularLyapunov

noncomputable section
namespace UAMO.CMV
open Matrix MeasureTheory Filter CircleDOS
open scoped Topology Matrix.L2OpNorm

theorem transfer_entry_norm_le (M : TransferMatrix) (i j : Fin 2) :
    ‖M i j‖ ≤ transferNorm M := by
  let v : EuclideanSpace ℂ (Fin 2) := EuclideanSpace.single j 1
  have hv : ‖v‖ = 1 := by simp [v]
  have he : (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M v) i = M i j := by
    change (M *ᵥ Pi.single j 1) i = _
    simp
  rw [← he]
  exact (PiLp.norm_apply_le _ _).trans (by
    simpa only [hv, mul_one, transferNorm] using (Matrix.toEuclideanCLM (n := Fin 2) (𝕜 := ℂ) M).le_opNorm v)

theorem transfer_trace_norm_le (M : TransferMatrix) : ‖M.trace‖ ≤ 2*transferNorm M := by
  rw [Matrix.trace_fin_two]
  exact (norm_add_le _ _).trans (by
    linarith [transfer_entry_norm_le M 0 0, transfer_entry_norm_le M 1 1])

def regularizingScalar (r x : ℝ) : ℂ :=
  ((1+r^2 : ℝ) : ℂ)*star (physicalHopping r x)

theorem regularizingScalar_norm (r x : ℝ) :
    ‖regularizingScalar r x‖ = (1+r^2)*‖physicalHopping r x‖ := by
  rw [regularizingScalar, norm_mul, norm_star, Complex.norm_real, Real.norm_eq_abs,
    abs_of_pos (show 0 < 1+r^2 by positivity)]

theorem regularizingScalar_ne_zero {r x : ℝ} (hq : physicalHopping r x ≠ 0) :
    regularizingScalar r x ≠ 0 := by
  exact mul_ne_zero (Complex.ofReal_ne_zero.mpr (by positivity)) (star_ne_zero.mpr hq)

theorem regularizedTransfer_eq_scalar (a r : ℝ) (z : ℂ) (x : ℝ)
    (hq : physicalHopping r x ≠ 0) :
    regularizedTransfer a r z x = regularizingScalar r x • uamoTransfer a r z x := by
  have hs : star (physicalHopping r x) ≠ 0 := star_ne_zero.mpr hq
  simp only [regularizedTransfer, regularizingScalar, uamoTransfer, physicalTransfer,
    inv_one, one_smul, smul_smul]
  simp only [mul_assoc, mul_inv_cancel₀ hs, mul_one]

theorem physicalHopping_ne_zero_ae_closed {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    ∀ᵐ x ∂volume, physicalHopping r x ≠ 0 := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact Filter.Eventually.of_forall (physicalHopping_ne_zero hr0 hlt)
  · filter_upwards [cos_ne_zero_ae] with x hx
    simpa only [physicalHopping_one, Complex.ofReal_ne_zero] using hx

theorem physicalHopping_orbit_ne_zero_ae_closed {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (ω : ℝ) : ∀ᵐ x ∂volume, ∀ j : ℕ, physicalHopping r (x+j*ω) ≠ 0 := by
  rw [ae_all_iff]
  intro j
  exact (quasiMeasurePreserving_add_right volume (j*ω)).ae
    (physicalHopping_ne_zero_ae_closed hr0 hr1)

theorem physicalHopping_log_integrable_all_closed {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (s t : ℝ) : IntervalIntegrable (fun x => Real.log ‖physicalHopping r x‖) volume s t := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · have hc : Continuous (physicalHopping r) := by unfold physicalHopping; fun_prop
    exact (hc.norm.log (fun x => norm_ne_zero_iff.mpr
      (physicalHopping_ne_zero hr0 hlt x))).intervalIntegrable s t
  · simpa only [physicalHopping_one_log] using log_cos_intervalIntegrable s t

theorem regularizingScalar_log_ae {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (fun x => Real.log ‖regularizingScalar r x‖) =ᵐ[volume]
      (fun x => Real.log (1+r^2)+Real.log ‖physicalHopping r x‖) := by
  filter_upwards [physicalHopping_ne_zero_ae_closed hr0 hr1] with x hx
  rw [regularizingScalar_norm, Real.log_mul (by positivity) (norm_ne_zero_iff.mpr hx)]

theorem regularizingScalar_log_integrable {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (s t : ℝ) : IntervalIntegrable (fun x => Real.log ‖regularizingScalar r x‖) volume s t :=
  (intervalIntegrable_const.add (physicalHopping_log_integrable_all_closed hr0 hr1 s t)).congr
    (ae_restrict_of_ae (regularizingScalar_log_ae hr0 hr1).symm)

theorem regularizingScalar_log_periodic (r : ℝ) :
    Function.Periodic (fun x => Real.log ‖regularizingScalar r x‖) (2*Real.pi) := by
  intro x
  simp [regularizingScalar, physicalHopping]

theorem regularizingScalar_log_integral {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (∫ x in (0 : ℝ)..(2*Real.pi), Real.log ‖regularizingScalar r x‖) = 0 := by
  have hp : 2*Real.pi ≠ 0 := by positivity
  have hh := physicalHopping_log_integral_closed hr0 hr1
  rw [intervalIntegral.integral_comp_mul_left (fun x => Real.log ‖physicalHopping r x‖) hp] at hh
  simp only [mul_zero, mul_one, smul_eq_mul] at hh
  rw [intervalIntegral.integral_congr_ae_restrict
    (ae_restrict_of_ae (regularizingScalar_log_ae hr0 hr1)),
    intervalIntegral.integral_add intervalIntegrable_const
      (physicalHopping_log_integrable_all_closed hr0 hr1 0 (2*Real.pi)),
    intervalIntegral.integral_const]
  simp only [sub_zero, smul_eq_mul]
  have hh' := congrArg (fun v : ℝ => (2*Real.pi)*v) hh
  simp only [← mul_assoc, mul_inv_cancel₀ hp, one_mul] at hh'
  linarith

theorem regularizingScalar_log_integral_shift {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (y : ℝ) :
    (∫ x in (0 : ℝ)..(2*Real.pi), Real.log ‖regularizingScalar r (x+y)‖) = 0 := by
  rw [intervalIntegral.integral_comp_add_right (fun x => Real.log ‖regularizingScalar r x‖) y]
  have h := (regularizingScalar_log_periodic r).intervalIntegral_add_eq y 0
  simp only [zero_add, add_zero] at h ⊢
  rw [add_comm (2*Real.pi) y, h, regularizingScalar_log_integral hr0 hr1]

theorem regularizedTransfer_product_eq_scalar (a r : ℝ) (z : ℂ) (ω x : ℝ)
    (hq : ∀ j : ℕ, physicalHopping r (x+j*ω) ≠ 0) (n : ℕ) :
    transferProduct (regularizedTransfer a r z) ω x n =
      (∏ j ∈ Finset.range n, regularizingScalar r (x+j*ω)) •
        transferProduct (uamoTransfer a r z) ω x n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [transferProduct_succ, regularizedTransfer_eq_scalar _ _ _ _ (hq n), ih,
      smul_mul_smul_comm, Finset.prod_range_succ, transferProduct_succ]
    congr 1
    ring

theorem uamoTransfer_product_log_integrable_closed {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0)
    (n : ℕ) (s t : ℝ) :
    IntervalIntegrable (fun x => transferLogNorm (uamoTransfer a r z) ω x n) volume s t := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact (continuous_transferLogNorm _ (continuous_uamoTransfer a hr0 hlt z)
      (fun x => uamoTransfer_det_norm ha hr0 hlt hz x) ω n).intervalIntegrable s t
  · exact uamoTransfer_one_product_log_integrable ha hz ω n s t

theorem uamoTransfer_product_det_norm_ae_closed {a r : ℝ} (ha : 0 < a)
    (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (ω : ℝ) {z : ℂ} (hz : z ≠ 0) (n : ℕ) :
    ∀ᵐ x ∂volume, ‖(transferProduct (uamoTransfer a r z) ω x n).det‖ = 1 := by
  rcases lt_or_eq_of_le hr1 with hlt | rfl
  · exact Filter.Eventually.of_forall (fun x => transferProduct_det_norm _
      (fun y => uamoTransfer_det_norm ha hr0 hlt hz y) ω x n)
  · exact uamoTransfer_one_product_det_norm_ae ha hz ω n

end UAMO.CMV

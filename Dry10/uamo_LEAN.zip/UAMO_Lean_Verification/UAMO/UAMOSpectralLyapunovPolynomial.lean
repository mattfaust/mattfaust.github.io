import UAMO.UAMOSpectralLyapunovAlgebra
import UAMO.CirclePolynomialJensen

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial

abbrev TransferPolynomialMatrix := Matrix (Fin 2) (Fin 2) (Polynomial ℂ)

def spectralPhase (x : ℝ) : ℂ := Complex.exp ((x : ℂ)*Complex.I)

@[simp] theorem spectralPhase_norm (x : ℝ) : ‖spectralPhase x‖ = 1 := by
  simp [spectralPhase, Complex.norm_exp]

@[simp] theorem spectralPhase_ne_zero (x : ℝ) : spectralPhase x ≠ 0 := Complex.exp_ne_zero _

theorem spectralPhase_add (x y : ℝ) : spectralPhase (x+y) = spectralPhase x*spectralPhase y := by
  simp [spectralPhase, add_mul, Complex.exp_add]

theorem spectralPhase_neg (x : ℝ) : spectralPhase (-x) = (spectralPhase x)⁻¹ := by
  simp [spectralPhase, neg_mul, Complex.exp_neg]

def clearedTransferPolynomial (a r : ℝ) (z : ℂ) (y : ℝ) : TransferPolynomialMatrix :=
  fun i j => C (regularizedConstant a r z i j)*X +
    C (-Complex.I*(r : ℂ)*spectralPhase y*spectralLeadingMatrix a i j)*X^2 +
    C (Complex.I*(r : ℂ)*spectralPhase (-y)*spectralLeadingMatrix a i j)

def clearedTransferProduct (a r : ℝ) (z : ℂ) (ω : ℝ) : ℕ → TransferPolynomialMatrix
  | 0 => 1
  | n+1 => clearedTransferPolynomial a r z (n*ω)*clearedTransferProduct a r z ω n

def clearedTracePolynomial (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) : Polynomial ℂ :=
  (clearedTransferProduct a r z ω n).trace

def extremePhaseCoefficient (r ω : ℝ) (n : ℕ) : ℂ :=
  ∏ j ∈ Finset.range n, Complex.I*(r : ℂ)*spectralPhase (-(j*ω))

theorem clearedTransferPolynomial_eval {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) (z : ℂ) (y x : ℝ) :
    (clearedTransferPolynomial a r z y).map (Polynomial.eval (spectralPhase x)) =
      spectralPhase x • regularizedTransfer a r z (x+y) := by
  rw [regularizedTransfer_laurent ha]
  ext i j
  simp only [clearedTransferPolynomial, Matrix.map_apply, Polynomial.eval_add,
    Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_X, Polynomial.eval_pow,
    Matrix.add_apply, Matrix.smul_apply, smul_eq_mul]
  rw [show -((↑(x+y) : ℂ)*Complex.I) = ((-(x+y) : ℝ) : ℂ)*Complex.I by push_cast; ring]
  change _ = spectralPhase x * (regularizedConstant a r z i j +
    -Complex.I*(r : ℂ)*spectralPhase (x+y)*spectralLeadingMatrix a i j +
    Complex.I*(r : ℂ)*spectralPhase (-(x+y))*spectralLeadingMatrix a i j)
  rw [spectralPhase_add, neg_add, spectralPhase_add, spectralPhase_neg x]
  field_simp
  ring

theorem clearedTransferPolynomial_eval_zero (a r : ℝ) (z : ℂ) (y : ℝ) :
    (clearedTransferPolynomial a r z y).map (Polynomial.eval 0) =
      (Complex.I*(r : ℂ)*spectralPhase (-y)) • spectralLeadingMatrix a := by
  ext i j
  simp [clearedTransferPolynomial]

theorem evalPolynomialMatrix_mul (A B : TransferPolynomialMatrix) (w : ℂ) :
    (A*B).map (Polynomial.eval w) =
      A.map (Polynomial.eval w)*B.map (Polynomial.eval w) := by
  ext i j
  simp [Matrix.mul_apply]

theorem clearedTransferProduct_eval {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ) :
    (clearedTransferProduct a r z ω n).map (Polynomial.eval (spectralPhase x)) =
      spectralPhase x ^ n • transferProduct (regularizedTransfer a r z) ω x n := by
  induction n with
  | zero => simp [clearedTransferProduct, Matrix.map_one]
  | succ n ih =>
    rw [clearedTransferProduct, evalPolynomialMatrix_mul,
      clearedTransferPolynomial_eval ha, ih, smul_mul_smul_comm, transferProduct_succ]
    congr 1
    rw [pow_succ']

theorem clearedTransferProduct_eval_zero (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (clearedTransferProduct a r z ω n).map (Polynomial.eval 0) =
      extremePhaseCoefficient r ω n • spectralLeadingMatrix a ^ n := by
  induction n with
  | zero => simp [clearedTransferProduct, extremePhaseCoefficient, Matrix.map_one]
  | succ n ih =>
    rw [clearedTransferProduct, evalPolynomialMatrix_mul,
      clearedTransferPolynomial_eval_zero, ih, smul_mul_smul_comm, ← pow_succ']
    congr 1
    simp [extremePhaseCoefficient, Finset.prod_range_succ, mul_comm]

theorem clearedTracePolynomial_eval {a : ℝ} (ha : a ≠ 0)
    (r : ℝ) (z : ℂ) (ω x : ℝ) (n : ℕ) :
    (clearedTracePolynomial a r z ω n).eval (spectralPhase x) =
      spectralPhase x ^ n * (transferProduct (regularizedTransfer a r z) ω x n).trace := by
  have ht := congrArg Matrix.trace (clearedTransferProduct_eval ha r z ω x n)
  simpa [clearedTracePolynomial, Matrix.trace_fin_two] using ht

theorem clearedTracePolynomial_eval_zero (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (clearedTracePolynomial a r z ω n).eval 0 =
      extremePhaseCoefficient r ω n * (spectralLeadingMatrix a ^ n).trace := by
  have ht := congrArg Matrix.trace (clearedTransferProduct_eval_zero a r z ω n)
  simpa [clearedTracePolynomial, Matrix.trace_fin_two] using ht

theorem extremePhaseCoefficient_norm (r ω : ℝ) (n : ℕ) :
    ‖extremePhaseCoefficient r ω n‖ = |r|^n := by
  simp [extremePhaseCoefficient, norm_prod, norm_mul]

theorem clearedTracePolynomial_even_zero_norm {a r : ℝ} (ha : 0 < a)
    (hr : 0 ≤ r) (z : ℂ) (ω : ℝ) (n : ℕ) :
    ‖(clearedTracePolynomial a r z ω (2*n)).eval 0‖ =
      r^(2*n)*((a⁻¹)^(2*n)+a^(2*n)) := by
  rw [clearedTracePolynomial_eval_zero, norm_mul, extremePhaseCoefficient_norm,
    spectralLeadingMatrix_trace_pow ha.ne', neg_pow, (even_two_mul n).neg_one_pow, one_mul,
    ← Complex.ofReal_inv, ← Complex.ofReal_pow, ← Complex.ofReal_pow, ← Complex.ofReal_add,
    Complex.norm_real, Real.norm_eq_abs]
  rw [abs_of_nonneg hr, abs_of_nonneg (show 0 ≤ a⁻¹^(2*n)+a^(2*n) by positivity)]

theorem clearedTracePolynomial_even_zero_lower {a r : ℝ} (ha : 0 < a)
    (hr : 0 < r) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (r/a)^(2*n) ≤ ‖(clearedTracePolynomial a r z ω (2*n)).eval 0‖ := by
  rw [clearedTracePolynomial_even_zero_norm ha hr.le, div_eq_mul_inv, mul_pow]
  nlinarith [pow_nonneg ha.le (2*n), pow_nonneg hr.le (2*n)]

theorem clearedTracePolynomial_even_zero_ne {a r : ℝ} (ha : 0 < a)
    (hr : 0 < r) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (clearedTracePolynomial a r z ω (2*n)).eval 0 ≠ 0 := by
  exact norm_pos_iff.mp ((pow_pos (div_pos hr ha) _).trans_le
    (clearedTracePolynomial_even_zero_lower ha hr z ω n))

end UAMO.CMV

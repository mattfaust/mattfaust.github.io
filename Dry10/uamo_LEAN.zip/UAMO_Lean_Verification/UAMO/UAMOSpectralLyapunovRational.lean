import UAMO.UAMOSpectralLyapunovPolynomial
import Mathlib.RingTheory.RootsOfUnity.Complex

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial

theorem spectralPhase_nat_mul (ω : ℝ) (n : ℕ) :
    spectralPhase (n*ω) = spectralPhase ω^n := by
  rw [spectralPhase, spectralPhase, ← Complex.exp_nat_mul]
  congr 1
  push_cast
  ring

theorem spectralPhase_rational_primitive (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hcop : p.natAbs.Coprime q) :
    IsPrimitiveRoot (spectralPhase (2*Real.pi*((p : ℝ)/(q : ℝ)))) q := by
  have h := (Complex.isPrimitiveRoot_exp q hq.ne').zpow_of_gcd_eq_one p
    (by simpa [Int.gcd] using hcop)
  rw [← Complex.exp_int_mul] at h
  convert h using 1
  unfold spectralPhase
  congr 1
  push_cast
  ring

theorem clearedTransferPolynomial_comp (a r : ℝ) (z : ℂ) (ω y : ℝ) :
    (clearedTransferPolynomial a r z y).map
      (Polynomial.compRingHom (C (spectralPhase ω)*X)) =
        C (spectralPhase ω) • clearedTransferPolynomial a r z (y+ω) := by
  have hC : C (spectralPhase ω)*C ((spectralPhase ω)⁻¹) = (1 : Polynomial ℂ) := by
    rw [← C_mul, mul_inv_cancel₀ (spectralPhase_ne_zero ω), C_1]
  apply Matrix.ext
  intro i j
  simp only [clearedTransferPolynomial, Matrix.map_apply, Polynomial.coe_compRingHom_apply,
    Polynomial.add_comp, Polynomial.mul_comp, Polynomial.C_comp, Polynomial.X_comp,
    Polynomial.pow_comp, Matrix.smul_apply, smul_eq_mul,
    spectralPhase_add, neg_add, spectralPhase_neg ω, C_mul]
  linear_combination -C Complex.I*C (r : ℂ)*C (spectralPhase (-y))*C (spectralLeadingMatrix a i j)*hC

theorem clearedTransferProduct_comp_intertwine (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (clearedTransferProduct a r z ω n).map
      (Polynomial.compRingHom (C (spectralPhase ω)*X)) * clearedTransferPolynomial a r z 0 =
      C (spectralPhase ω)^n •
        (clearedTransferPolynomial a r z (n*ω)*clearedTransferProduct a r z ω n) := by
  induction n with
  | zero => simp [clearedTransferProduct, Matrix.map_one]
  | succ n ih =>
    have hs : (↑n : ℝ)*ω+ω = ↑(n+1)*ω := by push_cast; ring
    simp only [clearedTransferProduct, Matrix.map_mul, clearedTransferPolynomial_comp, hs]
    rw [Matrix.smul_mul, Matrix.smul_mul, Matrix.mul_assoc, ih,
      Matrix.mul_smul, smul_smul, pow_succ']

theorem clearedTransferPolynomial_period (a r : ℝ) (z : ℂ) (ω : ℝ) (q : ℕ)
    (hξ : spectralPhase ω^q = 1) :
    clearedTransferPolynomial a r z (q*ω) = clearedTransferPolynomial a r z 0 := by
  ext i j
  simp only [clearedTransferPolynomial, spectralPhase_neg, spectralPhase_nat_mul, hξ]
  simp [spectralPhase]

theorem evalPolynomialMatrix_det (A : TransferPolynomialMatrix) (w : ℂ) :
    A.det.eval w = (A.map (Polynomial.eval w)).det := by
  simp [Matrix.det_fin_two]

theorem clearedTransferPolynomial_zero_det_ne {a : ℝ} (ha : 0 < a)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) :
    (clearedTransferPolynomial a r z 0).det ≠ 0 := by
  intro h
  have hv := congrArg (fun P : Polynomial ℂ => P.eval (spectralPhase 0)) h
  dsimp only at hv
  rw [evalPolynomialMatrix_det, clearedTransferPolynomial_eval ha.ne'] at hv
  simp only [spectralPhase, Complex.ofReal_zero, zero_mul, Complex.exp_zero,
    one_smul, add_zero, Polynomial.eval_zero] at hv
  rw [regularizedTransfer, Matrix.det_smul, Fintype.card_fin,
    physicalTransfer_det _ _ _ _ _ (coupling_pos ha).ne' hz] at hv
  simp [oddAlpha] at hv
  have hd : ((1+r^2 : ℝ) : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (by positivity)
  exact hd (by simpa only [Complex.ofReal_add, Complex.ofReal_one, Complex.ofReal_pow] using hv)

theorem polynomialMatrix_trace_of_intertwine
    (A B S : TransferPolynomialMatrix) (h : A*S = S*B) (hS : S.det ≠ 0) :
    A.trace = B.trace := by
  apply mul_left_cancel₀ hS
  calc
    S.det*A.trace = (A*S*S.adjugate).trace := by
      rw [Matrix.mul_assoc, Matrix.mul_adjugate, Matrix.mul_smul,
        Matrix.mul_one, Matrix.trace_smul, smul_eq_mul]
    _ = (S*B*S.adjugate).trace := by rw [h]
    _ = S.det*B.trace := by
      rw [Matrix.trace_mul_cycle, Matrix.adjugate_mul, Matrix.smul_mul,
        Matrix.one_mul, Matrix.trace_smul, smul_eq_mul]

theorem clearedTracePolynomial_comp {a : ℝ} (ha : 0 < a)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) (ω : ℝ) (q : ℕ)
    (hξ : spectralPhase ω^q = 1) :
    (clearedTracePolynomial a r z ω q).comp (C (spectralPhase ω)*X) =
      clearedTracePolynomial a r z ω q := by
  have h := clearedTransferProduct_comp_intertwine a r z ω q
  rw [← C_pow, hξ, C_1, one_smul, clearedTransferPolynomial_period a r z ω q hξ] at h
  have ht := polynomialMatrix_trace_of_intertwine _ _ _ h
    (clearedTransferPolynomial_zero_det_ne ha r hz)
  simpa only [clearedTracePolynomial, Matrix.trace_fin_two, Matrix.map_apply,
    Polynomial.coe_compRingHom_apply, Polynomial.add_comp] using ht

theorem clearedTransferPolynomial_degree (a r : ℝ) (z : ℂ) (y : ℝ) (i j : Fin 2) :
    (clearedTransferPolynomial a r z y i j).natDegree ≤ 2 := by
  unfold clearedTransferPolynomial
  apply Polynomial.natDegree_add_le_of_degree_le
  · apply Polynomial.natDegree_add_le_of_degree_le
    · exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
    · exact Polynomial.natDegree_C_mul_X_pow_le _ _
  · simp only [Polynomial.natDegree_C]
    omega

theorem clearedTransferProduct_degree (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) (i j : Fin 2) :
    (clearedTransferProduct a r z ω n i j).natDegree ≤ 2*n := by
  induction n generalizing i j with
  | zero => simp [clearedTransferProduct, Matrix.one_apply]; split <;> simp
  | succ n ih =>
    simp only [clearedTransferProduct, Matrix.mul_apply, Fin.sum_univ_two]
    apply Polynomial.natDegree_add_le_of_degree_le
    · exact (Polynomial.natDegree_mul_le_of_le
        (clearedTransferPolynomial_degree a r z (n*ω) i 0) (ih 0 j)).trans (by omega)
    · exact (Polynomial.natDegree_mul_le_of_le
        (clearedTransferPolynomial_degree a r z (n*ω) i 1) (ih 1 j)).trans (by omega)

theorem clearedTracePolynomial_degree (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (clearedTracePolynomial a r z ω n).natDegree ≤ 2*n := by
  rw [clearedTracePolynomial, Matrix.trace_fin_two]
  exact Polynomial.natDegree_add_le_of_degree_le
    (clearedTransferProduct_degree a r z ω n 0 0) (clearedTransferProduct_degree a r z ω n 1 1)

theorem clearedTracePolynomial_coeff_zero {a : ℝ} (ha : 0 < a)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) (ω : ℝ) (q : ℕ)
    (hξ : IsPrimitiveRoot (spectralPhase ω) q) (k : ℕ) (hk : ¬q ∣ k) :
    (clearedTracePolynomial a r z ω q).coeff k = 0 := by
  have h := congrArg (fun P : Polynomial ℂ => P.coeff k)
    (clearedTracePolynomial_comp ha r hz ω q hξ.pow_eq_one)
  simp only [Polynomial.comp_C_mul_X_coeff] at h
  have hn : spectralPhase ω^k ≠ 1 := mt (hξ.pow_eq_one_iff_dvd k).mp hk
  by_contra hc
  exact hn ((mul_eq_left₀ hc).mp h)

theorem clearedTracePolynomial_sparse {a : ℝ} (ha : 0 < a)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) (ω : ℝ) (q : ℕ) (hq : 0 < q)
    (hξ : IsPrimitiveRoot (spectralPhase ω) q) :
    clearedTracePolynomial a r z ω q =
      C ((clearedTracePolynomial a r z ω q).coeff 0) +
      C ((clearedTracePolynomial a r z ω q).coeff q)*X^q +
      C ((clearedTracePolynomial a r z ω q).coeff (2*q))*X^(2*q) := by
  have hq0 : q ≠ 0 := hq.ne'
  have h2q0 : 2*q ≠ 0 := by omega
  have h2q : q ≠ 2*q := by omega
  ext k
  by_cases hk0 : k = 0
  · subst k
    simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, hq0, hq0.symm, h2q0]
  by_cases hkq : k = q
  · subst k
    simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, hq0, h2q]
  by_cases hk2q : k = 2*q
  · subst k
    simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, h2q0, h2q.symm]
  have hz0 : (clearedTracePolynomial a r z ω q).coeff k = 0 := by
    by_cases hle : k ≤ 2*q
    · apply clearedTracePolynomial_coeff_zero ha r hz ω q hξ k
      rintro ⟨m, hm⟩
      have hm2 : m ≤ 2 := by nlinarith
      interval_cases m <;> simp_all [Nat.mul_comm]
    · exact Polynomial.coeff_eq_zero_of_natDegree_lt
        ((clearedTracePolynomial_degree a r z ω q).trans_lt (lt_of_not_ge hle))
  simp [Polynomial.coeff_C_mul_X_pow, Polynomial.coeff_C, hz0, hk0, hkq, hk2q]

def upperExtremePhaseCoefficient (r ω : ℝ) (n : ℕ) : ℂ :=
  ∏ j ∈ Finset.range n, -Complex.I*(r : ℂ)*spectralPhase (j*ω)

theorem upperExtremePhaseCoefficient_norm (r ω : ℝ) (n : ℕ) :
    ‖upperExtremePhaseCoefficient r ω n‖ = |r|^n := by
  simp [upperExtremePhaseCoefficient, norm_prod, norm_mul]

theorem clearedTransferProduct_top_coefficient (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ)
    (i j : Fin 2) :
    (clearedTransferProduct a r z ω n i j).coeff (2*n) =
      upperExtremePhaseCoefficient r ω n*(spectralLeadingMatrix a^n) i j := by
  induction n generalizing i j with
  | zero => simp [clearedTransferProduct, upperExtremePhaseCoefficient, Matrix.one_apply]; split <;> simp
  | succ n ih =>
    rw [show 2*(n+1) = 2+2*n by omega]
    simp only [clearedTransferProduct, Matrix.mul_apply, Fin.sum_univ_two, Polynomial.coeff_add]
    rw [Polynomial.coeff_mul_add_eq_of_natDegree_le
        (clearedTransferPolynomial_degree a r z (n*ω) i 0)
        (clearedTransferProduct_degree a r z ω n 0 j),
      Polynomial.coeff_mul_add_eq_of_natDegree_le
        (clearedTransferPolynomial_degree a r z (n*ω) i 1)
        (clearedTransferProduct_degree a r z ω n 1 j), ih, ih]
    have hc (u v : Fin 2) : (clearedTransferPolynomial a r z (n*ω) u v).coeff 2 =
        -Complex.I*(r : ℂ)*spectralPhase (n*ω)*spectralLeadingMatrix a u v := by
      simp only [clearedTransferPolynomial, Polynomial.coeff_add, Polynomial.coeff_C_mul,
        Polynomial.coeff_X, Polynomial.coeff_X_pow, Polynomial.coeff_C]
      norm_num
    rw [hc, hc]
    simp only [upperExtremePhaseCoefficient, Finset.prod_range_succ, pow_succ', Matrix.mul_apply,
      Fin.sum_univ_two]
    ring

theorem clearedTracePolynomial_top_coefficient (a r : ℝ) (z : ℂ) (ω : ℝ) (n : ℕ) :
    (clearedTracePolynomial a r z ω n).coeff (2*n) =
      upperExtremePhaseCoefficient r ω n*(spectralLeadingMatrix a^n).trace := by
  simp only [clearedTracePolynomial, Matrix.trace_fin_two, Polynomial.coeff_add,
    clearedTransferProduct_top_coefficient, mul_add]

theorem clearedTracePolynomial_extreme_norm_bound {a r : ℝ} (ha : 0 < a) (hr : 0 ≤ r)
    (z : ℂ) (ω : ℝ) (n : ℕ) :
    ‖(clearedTracePolynomial a r z ω n).coeff 0‖ ≤ (r/a)^n+(r*a)^n ∧
    ‖(clearedTracePolynomial a r z ω n).coeff (2*n)‖ ≤ (r/a)^n+(r*a)^n := by
  have hb := spectralLeadingMatrix_trace_pow_bound ha hr n
  simp only [norm_mul, norm_pow, Complex.norm_I, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg hr, one_mul] at hb
  constructor
  · rw [Polynomial.coeff_zero_eq_eval_zero, clearedTracePolynomial_eval_zero, norm_mul,
      extremePhaseCoefficient_norm, abs_of_nonneg hr]
    exact hb
  · rw [clearedTracePolynomial_top_coefficient, norm_mul,
      upperExtremePhaseCoefficient_norm, abs_of_nonneg hr]
    exact hb

theorem regularizedTransfer_rational_trace_laurent {a : ℝ} (ha : 0 < a)
    (r : ℝ) {z : ℂ} (hz : z ≠ 0) (ω : ℝ) (q : ℕ) (hq : 0 < q)
    (hξ : IsPrimitiveRoot (spectralPhase ω) q) (x : ℝ) :
    (transferProduct (regularizedTransfer a r z) ω x q).trace =
      (clearedTracePolynomial a r z ω q).coeff 0 / spectralPhase x^q +
      (clearedTracePolynomial a r z ω q).coeff q +
      (clearedTracePolynomial a r z ω q).coeff (2*q)*spectralPhase x^q := by
  have h := congrArg (fun P : Polynomial ℂ => P.eval (spectralPhase x))
    (clearedTracePolynomial_sparse ha r hz ω q hq hξ)
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C,
    Polynomial.eval_pow, Polynomial.eval_X, clearedTracePolynomial_eval ha.ne'] at h
  have hw : spectralPhase x^q ≠ 0 := pow_ne_zero q (spectralPhase_ne_zero x)
  apply mul_left_cancel₀ hw
  rw [h, show 2*q = q+q by omega, pow_add]
  field_simp
  ring

theorem regularizedTransfer_rational_trace_oscillation {a r : ℝ}
    (ha : 0 < a) (hr : 0 ≤ r) (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hcop : p.natAbs.Coprime q) {z : ℂ} (hz : z ≠ 0) (x y : ℝ) :
    ‖(transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(q : ℝ))) x q).trace -
      (transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(q : ℝ))) y q).trace‖ ≤
        4*((r/a)^q+(r*a)^q) := by
  let ω := 2*Real.pi*((p : ℝ)/(q : ℝ))
  have hξ := spectralPhase_rational_primitive p q hq hcop
  change ‖(transferProduct (regularizedTransfer a r z) ω x q).trace -
    (transferProduct (regularizedTransfer a r z) ω y q).trace‖ ≤ _
  rw [regularizedTransfer_rational_trace_laurent ha r hz ω q hq hξ x,
    regularizedTransfer_rational_trace_laurent ha r hz ω q hq hξ y]
  let c₀ := (clearedTracePolynomial a r z ω q).coeff 0
  let c₁ := (clearedTracePolynomial a r z ω q).coeff q
  let c₂ := (clearedTracePolynomial a r z ω q).coeff (2*q)
  let w := spectralPhase x^q
  let v := spectralPhase y^q
  have hw : ‖w‖ = 1 := by simp [w]
  have hv : ‖v‖ = 1 := by simp [v]
  have hc := clearedTracePolynomial_extreme_norm_bound ha hr z ω q
  change ‖c₀‖ ≤ (r/a)^q+(r*a)^q ∧ ‖c₂‖ ≤ (r/a)^q+(r*a)^q at hc
  change ‖(c₀/w+c₁+c₂*w)-(c₀/v+c₁+c₂*v)‖ ≤ _
  calc
    _ = ‖(c₀/w-c₀/v)+(c₂*w-c₂*v)‖ := by congr 1; ring
    _ ≤ (‖c₀/w‖+‖c₀/v‖)+(‖c₂*w‖+‖c₂*v‖) :=
      (norm_add_le _ _).trans (add_le_add (norm_sub_le _ _) (norm_sub_le _ _))
    _ ≤ _ := by
      rw [norm_div, norm_div, norm_mul, norm_mul, hw, hv]
      simp only [div_one, mul_one]
      linarith [hc.1, hc.2]

theorem regularizedTransfer_rational_trace_oscillation_subcritical {a r : ℝ}
    (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hra : r ≤ a)
    (p : ℤ) (q : ℕ) (hq : 0 < q) (hcop : p.natAbs.Coprime q)
    {z : ℂ} (hz : z ≠ 0) (x y : ℝ) :
    ‖(transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(q : ℝ))) x q).trace -
      (transferProduct (regularizedTransfer a r z) (2*Real.pi*((p : ℝ)/(q : ℝ))) y q).trace‖ ≤ 8 := by
  have hdiv : r/a ≤ 1 := (div_le_one ha).mpr hra
  have hmul : r*a ≤ 1 := by nlinarith
  exact (regularizedTransfer_rational_trace_oscillation ha hr p q hq hcop hz x y).trans
    (by nlinarith [pow_le_one₀ (n := q) (div_nonneg hr ha.le) hdiv,
      pow_le_one₀ (n := q) (mul_nonneg hr ha.le) hmul])

end UAMO.CMV

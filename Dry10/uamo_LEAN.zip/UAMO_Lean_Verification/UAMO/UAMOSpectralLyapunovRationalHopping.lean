import UAMO.UAMOSpectralLyapunovRational
import UAMO.UAMOSpectralLyapunovLower
import Mathlib.RingTheory.RootsOfUnity.Lemmas

noncomputable section
namespace UAMO.CMV
open Matrix Polynomial CircleDOS

theorem spectralPhase_star (x : ℝ) : star (spectralPhase x) = spectralPhase (-x) := by
  simp [spectralPhase, Complex.star_def, ← Complex.exp_conj]

theorem regularizingScalar_factorization (r x : ℝ) :
    regularizingScalar r x = -Complex.I *
      (1+Complex.I*(r : ℂ)*spectralPhase x) *
      (1+Complex.I*(r : ℂ)*spectralPhase (-x)) := by
  have hx : 2*Real.pi*((2*Real.pi)⁻¹*x) = x := by field_simp
  have h := physicalHopping_factorization r ((2*Real.pi)⁻¹*x)
  rw [hx, ← spectralPhase_eq_char, spectralPhase_star] at h
  rw [regularizingScalar, h]
  have hd : 1+(r : ℂ)^2 ≠ 0 := by exact_mod_cast (show 1+r^2 ≠ 0 by positivity)
  push_cast
  field_simp
  ring

theorem primitiveRoot_one_sub_product {ξ : ℂ} {q : ℕ}
    (hξ : IsPrimitiveRoot ξ q) (hq : 0 < q) (c : ℂ) :
    (∏ j ∈ Finset.range q, (1-c*ξ^j)) = 1-c^q := by
  have h := congrArg (fun P : Polynomial ℂ => P.eval 1)
    (X_pow_sub_C_eq_prod hξ hq (show c^q = c^q from rfl))
  simpa only [Polynomial.eval_sub, Polynomial.eval_pow, Polynomial.eval_X, Polynomial.eval_C,
    Polynomial.eval_prod, one_pow, mul_comm] using h.symm

theorem regularizingScalar_cycle_product (r ω x : ℝ) (q : ℕ) (hq : 0 < q)
    (hξ : IsPrimitiveRoot (spectralPhase ω) q) :
    (∏ j ∈ Finset.range q, regularizingScalar r (x+j*ω)) =
      (-Complex.I)^q * (1-(-Complex.I*(r : ℂ)*spectralPhase x)^q) *
        (1-(-Complex.I*(r : ℂ)*spectralPhase (-x))^q) := by
  have hstep (j : ℕ) : regularizingScalar r (x+j*ω) =
      (-Complex.I)*(1-(-Complex.I*(r : ℂ)*spectralPhase x)*spectralPhase ω^j)*
        (1-(-Complex.I*(r : ℂ)*spectralPhase (-x))*((spectralPhase ω)⁻¹)^j) := by
    rw [regularizingScalar_factorization, spectralPhase_add, spectralPhase_nat_mul,
      neg_add, spectralPhase_add, spectralPhase_neg (j*ω), spectralPhase_nat_mul, inv_pow]
    ring
  simp_rw [hstep]
  rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib,
    primitiveRoot_one_sub_product hξ hq, primitiveRoot_one_sub_product hξ.inv hq]
  simp

theorem regularizingScalar_cycle_product_norm_bound {r : ℝ} (hr : 0 ≤ r)
    (ω x : ℝ) (q : ℕ) (hq : 0 < q) (hξ : IsPrimitiveRoot (spectralPhase ω) q) :
    ‖∏ j ∈ Finset.range q, regularizingScalar r (x+j*ω)‖ ≤ (1+r^q)^2 := by
  rw [regularizingScalar_cycle_product r ω x q hq hξ, norm_mul, norm_mul,
    norm_pow, norm_neg, Complex.norm_I, one_pow, one_mul]
  have hleft : ‖1-(-Complex.I*(r : ℂ)*spectralPhase x)^q‖ ≤ 1+r^q := by
    simpa only [norm_one, norm_pow, norm_mul, norm_neg, Complex.norm_I, Complex.norm_real,
      Real.norm_eq_abs, abs_of_nonneg hr, spectralPhase_norm, one_mul, mul_one] using
      norm_sub_le (1 : ℂ) ((-Complex.I*(r : ℂ)*spectralPhase x)^q)
  have hright : ‖1-(-Complex.I*(r : ℂ)*spectralPhase (-x))^q‖ ≤ 1+r^q := by
    simpa only [norm_one, norm_pow, norm_mul, norm_neg, Complex.norm_I, Complex.norm_real,
      Real.norm_eq_abs, abs_of_nonneg hr, spectralPhase_norm, one_mul, mul_one] using
      norm_sub_le (1 : ℂ) ((-Complex.I*(r : ℂ)*spectralPhase (-x))^q)
  exact (mul_le_mul hleft hright (norm_nonneg _) (by positivity)).trans_eq (by ring)

theorem regularizingScalar_cycle_product_norm_le_four {r : ℝ} (hr : 0 ≤ r) (hr1 : r ≤ 1)
    (ω x : ℝ) (q : ℕ) (hq : 0 < q) (hξ : IsPrimitiveRoot (spectralPhase ω) q) :
    ‖∏ j ∈ Finset.range q, regularizingScalar r (x+j*ω)‖ ≤ 4 := by
  exact (regularizingScalar_cycle_product_norm_bound hr ω x q hq hξ).trans
    (by nlinarith [pow_le_one₀ (n := q) hr hr1, pow_nonneg hr q])

end UAMO.CMV

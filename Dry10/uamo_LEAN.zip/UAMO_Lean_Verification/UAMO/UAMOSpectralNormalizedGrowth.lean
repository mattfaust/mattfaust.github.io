import UAMO.UAMODeterminantLogMean
import UAMO.ComplexLyapunovGlobal
import UAMO.CMVConjugacyGrowth

noncomputable section
namespace UAMO.CMV
open MeasureTheory Filter Set
open scoped Topology Matrix.L2OpNorm

theorem transferLogNorm_scalar_factor (A : ℝ→TransferMatrix) (g : ℝ→ℂ)
    (hd : ∀x,‖(A x).det‖=1) (hg : ∀x,g x≠0) (ω x : ℝ) (n : ℕ) :
    transferLogNorm (fun v => g v • A v) ω x n=
      (∑j∈Finset.range n,Real.log ‖g (x+j*ω)‖)+transferLogNorm A ω x n := by
  have hprod : ∀j∈Finset.range n,‖g (x+j*ω)‖≠0 :=
    fun j _ => norm_ne_zero_iff.mpr (hg _)
  unfold transferLogNorm
  rw [transferProduct_scalar_gauge,transferNorm_smul,norm_prod,
    Real.log_mul (Finset.prod_ne_zero_iff.mpr hprod)
      (transferProduct_norm_pos A hd ω x n).ne',Real.log_prod _ _ hprod]

theorem finiteLyapunov_scalar_factor (A : ℝ→TransferMatrix) (g : ℝ→ℂ)
    (hcA : Continuous A) (hd : ∀x,‖(A x).det‖=1)
    (hcG : Continuous g) (hpG : Function.Periodic g (2*Real.pi)) (hg : ∀x,g x≠0)
    (ω : ℝ) {n : ℕ} (hn : 0<n) :
    finiteLyapunov (fun v => g v • A v) ω n=
      (∫x in (0:ℝ)..2*Real.pi,Real.log ‖g x‖)/(2*Real.pi)+finiteLyapunov A ω n := by
  have hc : Continuous (fun x => Real.log ‖g x‖) :=
    hcG.norm.log (fun x => norm_ne_zero_iff.mpr (hg x))
  have hp : Function.Periodic (fun x => Real.log ‖g x‖) (2*Real.pi) := by
    intro x; dsimp only; rw [hpG x]
  have hi (j : ℕ) : IntervalIntegrable (fun x => Real.log ‖g (x+j*ω)‖)
      volume 0 (2*Real.pi) :=
    (hc.comp (continuous_id.add continuous_const)).intervalIntegrable _ _
  have hisum : IntervalIntegrable (fun x => ∑j∈Finset.range n,Real.log ‖g (x+j*ω)‖)
      volume 0 (2*Real.pi) := by
    convert IntervalIntegrable.sum (Finset.range n)
      (f:=fun j x => Real.log ‖g (x+j*ω)‖) (fun j _ => hi j) using 1
    ext x; simp only [Finset.sum_apply]
  have hshift (t : ℝ) :
      (∫x in (0:ℝ)..2*Real.pi,Real.log ‖g (x+t)‖)=
        ∫x in (0:ℝ)..2*Real.pi,Real.log ‖g x‖ := by
    rw [intervalIntegral.integral_comp_add_right (fun x => Real.log ‖g x‖) t]
    simpa only [zero_add,add_comm (2*Real.pi) t] using hp.intervalIntegral_add_eq t 0
  have hsum : (∫x in (0:ℝ)..2*Real.pi,∑j∈Finset.range n,Real.log ‖g (x+j*ω)‖)=
      (n:ℝ)*(∫x in (0:ℝ)..2*Real.pi,Real.log ‖g x‖) := by
    rw [intervalIntegral.integral_finset_sum (fun j _ => hi j)]
    simp only [hshift,Finset.sum_const,Finset.card_range,nsmul_eq_mul]
  unfold finiteLyapunov transferLogAverage
  simp_rw [transferLogNorm_scalar_factor A g hd hg]
  rw [intervalIntegral.integral_add hisum
    ((continuous_transferLogNorm A hcA hd ω n).intervalIntegrable _ _),hsum]
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast hn.ne'
  field_simp
  ring

theorem complexifiedLyapunov_eq_normalized {a r : ℝ} (ha : 0<a)
    (hr : 0<r) (hr1 : r≤1) {α : ℝ} (hα : Irrational α) {z : ℂ} (hz : z≠0)
    (y : ℝ) (hexceptional : |y|≠ -Real.log r) (g : ℂ→ℂ) (N : ℂ→TransferMatrix)
    (hcG : Continuous (fun x:ℝ => g ((x:ℂ)+(y:ℂ)*Complex.I)))
    (hcN : Continuous (fun x:ℝ => N ((x:ℂ)+(y:ℂ)*Complex.I)))
    (hpG : Function.Periodic g ((2*Real.pi:ℝ):ℂ))
    (hpN : Function.Periodic N ((2*Real.pi:ℝ):ℂ))
    (hfact : ∀x:ℝ,g ((x:ℂ)+(y:ℂ)*Complex.I)≠0 ∧
      g ((x:ℂ)+(y:ℂ)*Complex.I)^2=(complexifiedPhaseTransfer a r z y x).det ∧
      (N ((x:ℂ)+(y:ℂ)*Complex.I)).det=1 ∧
      g ((x:ℂ)+(y:ℂ)*Complex.I) • N ((x:ℂ)+(y:ℂ)*Complex.I)=
        complexifiedPhaseTransfer a r z y x) :
    complexifiedLyapunov a r (2*Real.pi*α) z y=
      max 0 (Real.log r+|y|)+
        lyapunov (fun x:ℝ => N ((x:ℂ)+(y:ℂ)*Complex.I)) (2*Real.pi*α) := by
  let G : ℝ→ℂ := fun x => g ((x:ℂ)+(y:ℂ)*Complex.I)
  let B : ℝ→TransferMatrix := fun x => N ((x:ℂ)+(y:ℂ)*Complex.I)
  have hperiod (f : ℂ→ℂ) (hf : Function.Periodic f ((2*Real.pi:ℝ):ℂ)) :
      Function.Periodic (fun x:ℝ => f ((x:ℂ)+(y:ℂ)*Complex.I)) (2*Real.pi) := by
    intro x
    dsimp only
    rw [Complex.ofReal_add,add_right_comm]
    exact hf _
  have hpB : Function.Periodic B (2*Real.pi) := by
    intro x
    dsimp only [B]
    rw [Complex.ofReal_add,add_right_comm]
    exact hpN _
  have hdB (x : ℝ) : ‖(B x).det‖=1 := by rw [(hfact x).2.2.1,norm_one]
  have heA : complexifiedPhaseTransfer a r z y=(fun x => G x • B x) :=
    funext (fun x => (hfact x).2.2.2.symm)
  have hmean : (∫x in (0:ℝ)..2*Real.pi,Real.log ‖G x‖)/(2*Real.pi)=
      max 0 (Real.log r+|y|) := by
    have h := determinant_root_log_integral ha.ne' hr hr1 hz y hexceptional g
      (fun x => (hfact x).2.1)
    change (∫t in (0:ℝ)..1,Real.log ‖G (2*Real.pi*t)‖)=_ at h
    rw [intervalIntegral.integral_comp_mul_left (fun x => Real.log ‖G x‖)
      (show 2*Real.pi≠0 by positivity)] at h
    simpa only [mul_zero,mul_one,zero_mul,one_mul,smul_eq_mul,div_eq_mul_inv,mul_comm] using h
  have he : ∀ᶠ n:ℕ in atTop,finiteLyapunov (complexifiedPhaseTransfer a r z y)
      (2*Real.pi*α) n=max 0 (Real.log r+|y|)+finiteLyapunov B (2*Real.pi*α) n := by
    filter_upwards [eventually_ge_atTop (1:ℕ)] with n hn
    rw [heA,finiteLyapunov_scalar_factor B G hcN hdB hcG (hperiod g hpG)
      (fun x => (hfact x).1) _ (by omega),hmean]
  exact tendsto_nhds_unique (tendsto_complexifiedFiniteLyapunov_global ha hr hα hz y)
    (((tendsto_finiteLyapunov B hcN hpB hdB (2*Real.pi*α)).const_add _).congr' (he.mono (fun _ hn => hn.symm)))

end UAMO.CMV

import UAMO.CMVCyclicSpectralApproximation
import UAMO.UAMORationalSpectralUpper
import UAMO.ActualConvergentLimit

noncomputable section
namespace UAMO.CMV
open Filter Set PhysicalRepresentation ScalarGauge
open scoped Topology

theorem uamoLyapunov_spectral_zero_of_joint_continuity
    {a r α : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hr : 0 ≤ r) (hr1 : r < 1)
    (hra : r ≤ a) (hα : Irrational α) (θ : ℝ) (z : Circle)
    (hz : (z:ℂ) ∈ spectrum ℂ (cstarWalk (coupling a) (coupling r) α θ))
    (hcont : ContinuousAt
      (fun p : ℝ × Circle => uamoLyapunov a r (2*Real.pi*p.1) (p.2:ℂ)) (α,z)) :
    uamoLyapunov a r (2*Real.pi*α) (z:ℂ) = 0 := by
  have hz0 : (z:ℂ) ≠ 0 := norm_ne_zero_iff.mp (by rw [z.norm_coe]; norm_num)
  have hnonneg := uamoLyapunov_nonneg ha hr hr1 (2*Real.pi*α) hz0
  by_contra hne
  have hL : 0 < uamoLyapunov a r (2*Real.pi*α) (z:ℂ) := lt_of_le_of_ne hnonneg (Ne.symm hne)
  obtain ⟨δ,hδ,hnear⟩ := Metric.continuousAt_iff.mp hcont
    (uamoLyapunov a r (2*Real.pi*α) (z:ℂ)/2) (by positivity)
  let q : ℕ → ℕ := fun j => (α.convergent j).den
  let N : ℕ → ℕ := fun j => q j - 1
  let Φ : ℕ → ℝ := fun j => (α.convergent j:ℝ)
  have hq : Tendsto q atTop atTop := convergent_den_tendsto_atTop hα
  have hN : Tendsto N atTop atTop := (tendsto_sub_atTop_nat 1).comp hq
  have hΦ : Tendsto Φ atTop (𝓝 α) := actual_convergents_tendsto hα
  have hsize : ∀ j, N j + 1 = q j := fun j => Nat.sub_add_cancel (α.convergent j).pos
  have hspectral := eventually_exists_finite_spectrum_near a r ha.le ha1 hr hr1.le
    N Φ hN hΦ θ hz hδ
  have hfreq := Metric.tendsto_nhds.mp hΦ δ hδ
  have hsmall := ((tendsto_const_div_atTop_nhds_zero_nat
    (Real.log 2 + Real.log 16)).comp hq).eventually
      (Iio_mem_nhds (show (0:ℝ) < uamoLyapunov a r (2*Real.pi*α) (z:ℂ)/2 by positivity))
  obtain ⟨j,hsj,hfj,hsmallj⟩ := (hspectral.and (hfreq.and hsmall)).exists
  obtain ⟨x,w,hw,hwd⟩ := hsj
  let wc : Circle := ⟨w, mem_sphere_zero_iff_norm.mpr (finiteCMV_spectrum_norm (N j) a r _ x hw)⟩
  have hpair : dist (Φ j,wc) (α,z) < δ := by
    rw [Prod.dist_eq]
    exact max_lt hfj hwd
  have hclose := hnear hpair
  rw [Real.dist_eq] at hclose
  have hlow := (abs_lt.mp hclose).1
  have hupper := uamoLyapunov_rational_le_of_finite_spectrum (N j)
    ha ha1 hr hr1 hra (α.convergent j).num
    (by simpa only [hsize] using (α.convergent j).reduced) x
    (by simpa only [hsize, q, Φ, Rat.cast_def] using hw)
  simp only [hsize, q, ← Rat.cast_def] at hupper
  change uamoLyapunov a r (2*Real.pi*Φ j) w ≤
    (Real.log 2 + Real.log 16)/(q j:ℝ) at hupper
  change -(uamoLyapunov a r (2*Real.pi*α) (z:ℂ)/2) <
    uamoLyapunov a r (2*Real.pi*Φ j) w - uamoLyapunov a r (2*Real.pi*α) (z:ℂ) at hlow
  change (Real.log 2 + Real.log 16)/(q j:ℝ) <
    uamoLyapunov a r (2*Real.pi*α) (z:ℂ)/2 at hsmallj
  linarith only [hlow, hupper, hsmallj]

end UAMO.CMV

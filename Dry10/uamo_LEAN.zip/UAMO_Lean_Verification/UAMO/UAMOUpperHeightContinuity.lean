import UAMO.UAMOUpperHeightNormalization
import UAMO.UAMOSpectralFrequencyContinuity

noncomputable section
set_option maxHeartbeats 1000000
namespace UAMO.CMV
open Set Filter
open scoped Topology Matrix.L2OpNorm

theorem upperHeightSL2_lyapunov_joint_continuousAt {a y:ℝ} (ha:a≠0) (hy:0<y)
    {α:ℝ} (hα:Irrational α) (p:UpperHeightCoupling y×Circle) :
    ContinuousAt (fun q:ℝ×(UpperHeightCoupling y×Circle)=>
      lyapunov (fun x:ℝ=>upperHeightSL2 a q.2.1 q.2.2 ((x:ℂ)+(y:ℂ)*Complex.I))
        (2*Real.pi*q.1)) (α,p) := by
  obtain ⟨K,hK⟩ := exists_upperHeightSL2_circleBounds ha hy
  let A : (ℝ×(UpperHeightCoupling y×Circle))→ℝ→TransferMatrix :=
    fun q x=>upperHeightSL2 a q.2.1 q.2.2 ((x:ℂ)+(y:ℂ)*Complex.I)
  have hmap : Continuous (fun q:(ℝ×(UpperHeightCoupling y×Circle))×ℝ=>(q.1.2,q.2)) := by fun_prop
  have hc0 := (continuous_upperHeightSL2_slice a hy).comp hmap
  have hc : Continuous (fun q:(ℝ×(UpperHeightCoupling y×Circle))×ℝ=>A q.1 q.2) := hc0
  have hdense : Dense {q:ℝ×(UpperHeightCoupling y×Circle)|Irrational q.1} := by
    simpa only [Set.prod_univ] using dense_irrational.prod
      (dense_univ:Dense (univ:Set (UpperHeightCoupling y×Circle)))
  have ht := uamo_normalizedTransfer_parametric_lyapunov_continuousAt
    A Prod.fst (fun _=>a) (fun q=>(q.2.1:ℝ)) (fun _=>y) (fun q=>(q.2.2:ℂ))
    (fun q x=>upperDeterminantRoot (q.2.1:ℝ) ((x:ℂ)+(y:ℂ)*Complex.I))
    (fun q=>hK q.2) hc continuous_fst
    (fun q x=>(upperHeightSL2_factor ha hy q.2.1 (Circle.coe_ne_zero q.2.2) x).2.2.1)
    (fun _=>ha) (fun q=>upperHeightCoupling_pos q.2.1) (fun q=>q.2.1.property.2)
    (fun q=>Circle.coe_ne_zero q.2.2) (fun q=>upperHeightCoupling_nonexceptional hy q.2.1)
    (fun q x=>(upperHeightSL2_factor ha hy q.2.1 (Circle.coe_ne_zero q.2.2) x).2.2.2)
    hdense (p₀:=(α,p)) hα
  exact ht

theorem complexifiedLyapunov_eq_upperHeightSL2 {a y:ℝ} (ha:0<a) (hy:0<y)
    {α:ℝ} (hα:Irrational α) (r:UpperHeightCoupling y) (z:Circle) :
    complexifiedLyapunov a r (2*Real.pi*α) z y=
      Real.log (r:ℝ)+y+
        lyapunov (fun x:ℝ=>upperHeightSL2 a r z ((x:ℂ)+(y:ℂ)*Complex.I))
          (2*Real.pi*α) := by
  have hmapG : Continuous (fun x:ℝ=>(r,x)) := continuous_const.prodMk continuous_id
  have hcG0 := (continuous_upperDeterminantRoot_slice hy).comp hmapG
  have hcG : Continuous (fun x:ℝ=>upperDeterminantRoot (r:ℝ) ((x:ℂ)+(y:ℂ)*Complex.I)) := hcG0
  have hmapN : Continuous (fun x:ℝ=>((r,z),x)) := continuous_const.prodMk continuous_id
  have hcN0 := (continuous_upperHeightSL2_slice a hy).comp hmapN
  have hcN : Continuous (fun x:ℝ=>upperHeightSL2 a r z ((x:ℂ)+(y:ℂ)*Complex.I)) := hcN0
  have ht := complexifiedLyapunov_eq_normalized ha (upperHeightCoupling_pos r) r.property.2
    hα (Circle.coe_ne_zero z) y (upperHeightCoupling_nonexceptional hy r)
    (upperDeterminantRoot r) (upperHeightSL2 a r z) hcG hcN
    (upperDeterminantRoot_periodic r) (upperHeightSL2_periodic a r z)
    (fun x=>upperHeightSL2_factor ha.ne' hy r (Circle.coe_ne_zero z) x)
  have hpos : 0≤Real.log (r:ℝ)+y := by linarith [upperHeightCoupling_height hy r]
  simpa only [abs_of_pos hy,max_eq_right hpos] using ht

theorem complexifiedLyapunov_upperHeight_continuous {a y:ℝ} (ha:0<a) (hy:0<y)
    {α:ℝ} (hα:Irrational α) :
    Continuous (fun p:UpperHeightCoupling y×Circle=>
      complexifiedLyapunov a p.1 (2*Real.pi*α) p.2 y) := by
  apply continuous_iff_continuousAt.mpr
  intro p
  have hmap : Continuous (fun q:UpperHeightCoupling y×Circle=>(α,q)) :=
    continuous_const.prodMk continuous_id
  have ht0 := (upperHeightSL2_lyapunov_joint_continuousAt ha.ne' hy hα p).comp
    (f:=fun q:UpperHeightCoupling y×Circle=>(α,q)) hmap.continuousAt
  have ht : ContinuousAt (fun q:UpperHeightCoupling y×Circle=>
      lyapunov (fun x:ℝ=>upperHeightSL2 a q.1 q.2 ((x:ℂ)+(y:ℂ)*Complex.I))
        (2*Real.pi*α)) p := ht0
  have hc : Continuous (fun q:UpperHeightCoupling y×Circle=>Real.log (q.1:ℝ)+y) := by
    apply Continuous.add _ continuous_const
    exact (continuous_subtype_val.comp continuous_fst).log
      (fun q=>(upperHeightCoupling_pos q.1).ne')
  have hfinal := hc.continuousAt.add ht
  simpa only [complexifiedLyapunov_eq_upperHeightSL2 ha hy hα] using hfinal

def upperHeightCorner {y:ℝ} (hy:0<y) : UpperHeightCoupling y :=
  ⟨1,⟨(Real.exp_le_one_iff.mpr (by linarith)),le_rfl⟩⟩

theorem tendsto_complexifiedLyapunov_at_corner {a y:ℝ} (ha:0<a) (hy:0<y)
    {α:ℝ} (hα:Irrational α) {z:Circle} {ι:Type*} {l:Filter ι}
    (r:ι→ℝ) (w:ι→Circle) (hr:Tendsto r l (𝓝 1))
    (hr1:∀ᶠ i in l,r i≤1) (hw:Tendsto w l (𝓝 z)) :
    Tendsto (fun i=>complexifiedLyapunov a (r i) (2*Real.pi*α) (w i) y) l
      (𝓝 (complexifiedLyapunov a 1 (2*Real.pi*α) z y)) := by
  have hlower : Real.exp (-y/2)<1 := Real.exp_lt_one_iff.mpr (by linarith)
  have hevent : ∀ᶠ i in l, r i∈Icc (Real.exp (-y/2)) (1:ℝ) := by
    filter_upwards [hr.eventually (lt_mem_nhds hlower),hr1] with i hi hi1
    exact ⟨hi.le,hi1⟩
  let rr : ι→UpperHeightCoupling y := fun i=>
    if h:r i∈Icc (Real.exp (-y/2)) (1:ℝ) then ⟨r i,h⟩ else upperHeightCorner hy
  have heq : (fun i=>(rr i:ℝ))=ᶠ[l] r := hevent.mono (fun i hi=>by
    dsimp only [rr]
    rw [dif_pos hi])
  have hrt : Tendsto (fun i=>(rr i:ℝ)) l (𝓝 (1:ℝ)) := hr.congr' heq.symm
  have hrr : Tendsto rr l (𝓝 (upperHeightCorner hy)) :=
    tendsto_subtype_rng.mpr hrt
  have hp := hrr.prodMk_nhds hw
  have hc := (complexifiedLyapunov_upperHeight_continuous ha hy hα).continuousAt
    (x:=(upperHeightCorner hy,z))
  have ht := hc.tendsto.comp hp
  have heqf : (fun i=>complexifiedLyapunov a (rr i) (2*Real.pi*α) (w i) y)=ᶠ[l]
      (fun i=>complexifiedLyapunov a (r i) (2*Real.pi*α) (w i) y) := by
    filter_upwards [heq] with i hi
    rw [hi]
  exact ht.congr' heqf

end UAMO.CMV

import UAMO.UAMOSpectralNormalizedGrowth
import UAMO.CMVParametricCircleBounds

noncomputable section
set_option maxHeartbeats 800000
namespace UAMO.CMV
open Set Filter Matrix
open scoped Topology Matrix.L2OpNorm

abbrev UpperHeightCoupling (y : ℝ) := Set.Icc (Real.exp (-y/2)) (1:ℝ)

theorem upperHeightCoupling_pos {y : ℝ} (r : UpperHeightCoupling y) : 0<(r:ℝ) :=
  (Real.exp_pos _).trans_le r.property.1

theorem upperHeightCoupling_log_lower {y : ℝ} (r : UpperHeightCoupling y) :
    -y/2≤Real.log (r:ℝ) := by
  have h := Real.log_le_log (Real.exp_pos (-y/2)) r.property.1
  simpa only [Real.log_exp] using h

theorem upperHeightCoupling_height {y : ℝ} (hy : 0<y) (r : UpperHeightCoupling y) :
    -Real.log (r:ℝ)<y := by
  linarith [upperHeightCoupling_log_lower r]

theorem upperHeightCoupling_nonexceptional {y : ℝ} (hy : 0<y) (r : UpperHeightCoupling y) :
    |y|≠ -Real.log (r:ℝ) := by
  rw [abs_of_pos hy]
  exact (upperHeightCoupling_height hy r).ne'

theorem upperHeightCoupling_modes {y : ℝ} (hy : 0<y) (r : UpperHeightCoupling y) (x : ℝ) :
    ‖((r:ℝ):ℂ)*Complex.exp (((x:ℂ)+(y:ℂ)*Complex.I)*Complex.I)‖<1 ∧
    ‖((r:ℝ):ℂ)⁻¹*Complex.exp (((x:ℂ)+(y:ℂ)*Complex.I)*Complex.I)‖<1 := by
  have hr := upperHeightCoupling_pos r
  have hl := Real.log_nonpos hr.le r.property.2
  have hh := upperHeightCoupling_height hy r
  constructor
  · rw [norm_scaled_complexPhase hr,Real.exp_lt_one_iff]
    simp only [Complex.add_im,Complex.ofReal_im,Complex.mul_im,Complex.ofReal_re,
      Complex.I_im,mul_one,Complex.I_re,mul_zero,add_zero,zero_add]
    linarith
  · rw [norm_inv_scaled_complexPhase hr,Real.exp_lt_one_iff]
    simp only [Complex.add_im,Complex.ofReal_im,Complex.mul_im,Complex.ofReal_re,
      Complex.I_im,mul_one,Complex.I_re,mul_zero,add_zero,zero_add]
    linarith

def upperHeightSL2 (a r : ℝ) (z w : ℂ) : TransferMatrix :=
  (upperDeterminantRoot r w)⁻¹ • complexifiedRegularizedTransfer a r z w

theorem upperHeightSL2_periodic (a r : ℝ) (z : ℂ) :
    Function.Periodic (upperHeightSL2 a r z) ((2*Real.pi:ℝ):ℂ) := by
  intro w
  simp only [upperHeightSL2,upperDeterminantRoot_periodic r w,
    complexifiedRegularizedTransfer_periodic a r z w]

theorem upperHeightSL2_slice_periodic (a r : ℝ) (z : ℂ) (y : ℝ) :
    Function.Periodic (fun x:ℝ=>upperHeightSL2 a r z ((x:ℂ)+(y:ℂ)*Complex.I))
      (2*Real.pi) := by
  intro x
  dsimp only
  rw [Complex.ofReal_add,add_right_comm]
  exact upperHeightSL2_periodic a r z _

theorem upperHeightSL2_factor {a y : ℝ} (ha : a≠0) (hy : 0<y)
    (r : UpperHeightCoupling y) {z : ℂ} (hz : z≠0) (x : ℝ) :
    upperDeterminantRoot (r:ℝ) ((x:ℂ)+(y:ℂ)*Complex.I)≠0 ∧
    upperDeterminantRoot (r:ℝ) ((x:ℂ)+(y:ℂ)*Complex.I)^2=
      (complexifiedPhaseTransfer a r z y x).det ∧
    (upperHeightSL2 a r z ((x:ℂ)+(y:ℂ)*Complex.I)).det=1 ∧
    upperDeterminantRoot (r:ℝ) ((x:ℂ)+(y:ℂ)*Complex.I) •
      upperHeightSL2 a r z ((x:ℂ)+(y:ℂ)*Complex.I)=
      complexifiedPhaseTransfer a r z y x := by
  have hn := upperDeterminantRoot_ne_zero (upperHeightCoupling_pos r).ne'
    ((x:ℂ)+(y:ℂ)*Complex.I)
  have hs := upperDeterminantRoot_sq ha (upperHeightCoupling_pos r).ne' hz
    ((x:ℂ)+(y:ℂ)*Complex.I) (upperHeightCoupling_modes hy r x).1
      (upperHeightCoupling_modes hy r x).2
  refine ⟨hn,hs,?_,?_⟩
  · rw [upperHeightSL2,Matrix.det_smul,Fintype.card_fin,← hs]
    simp [hn]
  · rw [upperHeightSL2,smul_smul,mul_inv_cancel₀ hn,one_smul]
    rfl

theorem continuous_upperDeterminantRoot_slice {y : ℝ} (hy : 0<y) :
    Continuous (fun p:UpperHeightCoupling y×ℝ =>
      upperDeterminantRoot (p.1:ℝ) ((p.2:ℂ)+(y:ℂ)*Complex.I)) := by
  have hr : Continuous (fun p:UpperHeightCoupling y×ℝ=>((p.1:ℝ):ℂ)) := by fun_prop
  have hp : Continuous (fun p:UpperHeightCoupling y×ℝ=>((p.1:ℝ):ℂ)*
      Complex.exp (((p.2:ℂ)+(y:ℂ)*Complex.I)*Complex.I)) := by fun_prop
  have hi : Continuous (fun p:UpperHeightCoupling y×ℝ=>((p.1:ℝ):ℂ)⁻¹*
      Complex.exp (((p.2:ℂ)+(y:ℂ)*Complex.I)*Complex.I)) := by
    apply (hr.inv₀ (fun p=>Complex.ofReal_ne_zero.mpr (upperHeightCoupling_pos p.1).ne')).mul
    fun_prop
  apply continuous_iff_continuousAt.mpr
  intro p
  have hbp := (differentiableAt_unitDiscBinomialRoot
    (upperHeightCoupling_modes hy p.1 p.2).1).continuousAt.comp
      (f:=fun p:UpperHeightCoupling y×ℝ=>((p.1:ℝ):ℂ)*
        Complex.exp (((p.2:ℂ)+(y:ℂ)*Complex.I)*Complex.I)) (hp.continuousAt (x:=p))
  have hbi := (differentiableAt_unitDiscBinomialRoot
    (upperHeightCoupling_modes hy p.1 p.2).2).continuousAt.comp
      (f:=fun p:UpperHeightCoupling y×ℝ=>((p.1:ℝ):ℂ)⁻¹*
        Complex.exp (((p.2:ℂ)+(y:ℂ)*Complex.I)*Complex.I)) (hi.continuousAt (x:=p))
  have hm : Continuous (fun p:UpperHeightCoupling y×ℝ=>((p.1:ℝ):ℂ)*
      Complex.exp (-(((p.2:ℂ)+(y:ℂ)*Complex.I)*Complex.I))) := by fun_prop
  exact (hm.continuousAt.mul hbp).mul hbi

theorem continuous_upperHeightSL2_slice (a : ℝ) {y : ℝ} (hy : 0<y) :
    Continuous (fun p:(UpperHeightCoupling y×Circle)×ℝ =>
      upperHeightSL2 a (p.1.1:ℝ) (p.1.2:ℂ) ((p.2:ℂ)+(y:ℂ)*Complex.I)) := by
  have hmap : Continuous (fun p:(UpperHeightCoupling y×Circle)×ℝ => (p.1.1,p.2)) := by fun_prop
  have hg := (continuous_upperDeterminantRoot_slice hy).comp hmap
  have hgInv := hg.inv₀ (fun p=>upperDeterminantRoot_ne_zero
    (upperHeightCoupling_pos p.1.1).ne' _)
  have hz : Continuous (fun p:(UpperHeightCoupling y×Circle)×ℝ=>(p.1.2:ℂ)⁻¹) :=
    (continuous_subtype_val.comp (continuous_snd.comp continuous_fst)).inv₀
      (fun p=>Circle.coe_ne_zero p.1.2)
  have hconst : Continuous (fun p:(UpperHeightCoupling y×Circle)×ℝ=>
      regularizedConstant a (p.1.1:ℝ) (p.1.2:ℂ)) := by
    unfold regularizedConstant regularizedTransfer physicalTransfer
    apply Continuous.smul (by fun_prop)
    apply Continuous.smul (by fun_prop)
    apply continuous_matrix
    intro i j
    fin_cases i <;> fin_cases j <;> simp [oddAlpha] <;> fun_prop
  have hraw : Continuous (fun p:(UpperHeightCoupling y×Circle)×ℝ=>
      complexifiedRegularizedTransfer a (p.1.1:ℝ) (p.1.2:ℂ)
        ((p.2:ℂ)+(y:ℂ)*Complex.I)) := by
    unfold complexifiedRegularizedTransfer
    exact (hconst.add (Continuous.smul (by fun_prop) continuous_const)).add
      (Continuous.smul (by fun_prop) continuous_const)
  have hfinal := hgInv.smul hraw
  exact hfinal

theorem exists_upperHeightSL2_circleBounds {a y : ℝ} (ha : a≠0) (hy : 0<y) :
    ∃K:ℝ,∀p:UpperHeightCoupling y×Circle,
      TransferCircleBounds (fun x:ℝ=>upperHeightSL2 a p.1 p.2
        ((x:ℂ)+(y:ℂ)*Complex.I)) K := by
  let A : (UpperHeightCoupling y×Circle)→ℝ→TransferMatrix :=
    fun p x=>upperHeightSL2 a p.1 p.2 ((x:ℂ)+(y:ℂ)*Complex.I)
  have hc : Continuous (fun p:(UpperHeightCoupling y×Circle)×ℝ=>A p.1 p.2) :=
    continuous_upperHeightSL2_slice a hy
  have hp : ∀p:UpperHeightCoupling y×Circle,Function.Periodic (A p) (2*Real.pi) := by
    intro p
    exact upperHeightSL2_slice_periodic a p.1 p.2 y
  have hd : ∀p:UpperHeightCoupling y×Circle,∀x:ℝ,‖(A p x).det‖=1 := by
    intro p x
    rw [(upperHeightSL2_factor ha hy p.1 (Circle.coe_ne_zero p.2) x).2.2.1,norm_one]
  exact exists_uniform_transferCircleBounds A hc hp hd

end UAMO.CMV

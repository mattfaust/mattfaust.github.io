import UAMO.PhysicalMagneticSpectrum
import UAMO.ScalarThouless
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

noncomputable section
namespace UAMO

def scalarEnergyOfCircle (a r : ℝ) (z : ℂ) : ℝ :=
  ((1+a^2)*(1+r^2))/a*z.re

theorem scalarEnergyOfCircle_normalization {a : ℝ} (ha : a ≠ 0) (r : ℝ) (z : ℂ) :
    z.re = (a/((1+a^2)*(1+r^2)))*scalarEnergyOfCircle a r z := by
  have hM : (1+a^2)*(1+r^2) ≠ 0 := by positivity
  unfold scalarEnergyOfCircle
  field_simp
  ring

theorem physical_circle_resolvent_scalar {a r : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hr : 0 ≤ r) (hr1 : r ≤ 1) {Φ : ℝ} (hΦ : Irrational Φ)
    (θ : ℝ) (z : ℂ) (hz : ‖z‖ = 1) :
    z ∈ resolventSet ℂ (PhysicalRepresentation.walk (coupling a) (coupling r) Φ θ) ↔
      (scalarEnergyOfCircle a r z : ℂ) ∈
        resolventSet ℂ (scalarHamiltonian a r (-Real.pi*Φ)) := by
  have he : Complex.exp ((z.arg : ℂ)*Complex.I) = z := by
    simpa only [hz, Complex.ofReal_one, one_mul] using Complex.norm_mul_exp_arg_mul_I z
  have hc : Real.cos z.arg = z.re := by
    simpa only [hz, one_mul] using Complex.norm_mul_cos_arg z
  simpa only [he, hc, scalarEnergyOfCircle] using
    physical_walk_resolvent_scalar ha ha1 hr hr1 hΦ θ z.arg

end UAMO

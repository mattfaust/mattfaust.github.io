import UAMO.LatticeMultiplier
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.Normed.Ring.Units

noncomputable section
namespace UAMO.PhysicalRepresentation

local instance recurrenceOperatorNontrivial : Nontrivial Operator := by
  apply nontrivial_of_ne (1:Operator) 0
  intro h
  have hh := congrArg (fun T : Operator => T (lp.single 2 (0:ℤ) (1:ℂ)) 0) h
  simp at hh

theorem unitary_recurrence_inverse_inside (S : Operator) (hS : S∈unitary Operator)
    (c : ℂ) (hc : ‖c‖<1) :
    ∃ R : Operator,(S-c • (1:Operator))*R=1 ∧ R*(S-c • (1:Operator))=1 ∧
      ‖R‖≤(1-‖c‖)⁻¹ := by
  let t := c • star S
  let G := ∑' n : ℕ,t^n
  have hnS : ‖S‖=1 := CStarRing.norm_of_mem_unitary hS
  have hnt : ‖t‖=‖c‖ := by
    dsimp only [t]
    rw [norm_smul c (star S),norm_star S,hnS,mul_one]
  have ht : ‖t‖<1 := hnt ▸ hc
  have hG : ‖G‖≤(1-‖c‖)⁻¹ := by
    simpa only [norm_one,sub_self,zero_add,hnt] using tsum_geometric_le_of_norm_lt_one t ht
  have hQG : (1-t)*G=1 := mul_neg_geom_series t ht
  have hGQ : G*(1-t)=1 := geom_series_mul_neg t ht
  have hSS := unitary.mul_star_self_of_mem hS
  have hSS' := unitary.star_mul_self_of_mem hS
  have hD : S-c • (1:Operator)=S*(1-t) := by
    simp only [t,mul_sub,mul_one,mul_smul_comm,hSS]
  refine ⟨G*star S,?_,?_,?_⟩
  · rw [hD,mul_assoc,← mul_assoc (1-t) G,hQG,one_mul,hSS]
  · rw [hD,mul_assoc,← mul_assoc (star S) S,hSS',one_mul,hGQ]
  · calc
      ‖G*star S‖≤‖G‖*‖star S‖ := norm_mul_le _ _
      _ = ‖G‖ := by rw [norm_star S,hnS,mul_one]
      _ ≤ _ := hG

theorem unitary_recurrence_inverse_outside (S : Operator) (hS : S∈unitary Operator)
    (c : ℂ) (hc : 1<‖c‖) :
    ∃ R : Operator,(S-c • (1:Operator))*R=1 ∧ R*(S-c • (1:Operator))=1 ∧
      ‖R‖≤(‖c‖-1)⁻¹ := by
  have hc0 : c≠0 := norm_ne_zero_iff.mp (ne_of_gt (zero_lt_one.trans hc))
  let t := c⁻¹ • S
  let G := ∑' n : ℕ,t^n
  have hnS : ‖S‖=1 := CStarRing.norm_of_mem_unitary hS
  have hnt : ‖t‖=‖c‖⁻¹ := by
    dsimp only [t]
    rw [norm_smul c⁻¹ S,norm_inv,hnS,mul_one]
  have ht : ‖t‖<1 := by rw [hnt]; exact inv_lt_one_of_one_lt₀ hc
  have hG : ‖G‖≤(1-‖c‖⁻¹)⁻¹ := by
    simpa only [norm_one,sub_self,zero_add,hnt] using tsum_geometric_le_of_norm_lt_one t ht
  have hQG : (1-t)*G=1 := mul_neg_geom_series t ht
  have hGQ : G*(1-t)=1 := geom_series_mul_neg t ht
  have hD : S-c • (1:Operator)=(-c) • (1-t) := by
    simp only [t,smul_sub,smul_smul,neg_mul,neg_smul,mul_inv_cancel₀ hc0,
      one_smul,sub_neg_eq_add]
    abel
  refine ⟨(-c)⁻¹ • G,?_,?_,?_⟩
  · rw [hD,smul_mul_smul_comm,mul_inv_cancel₀ (neg_ne_zero.mpr hc0),hQG,one_smul]
  · rw [hD,smul_mul_smul_comm,inv_mul_cancel₀ (neg_ne_zero.mpr hc0),hGQ,one_smul]
  · rw [norm_smul ((-c)⁻¹) G,norm_inv,norm_neg]
    calc
      ‖c‖⁻¹*‖G‖≤‖c‖⁻¹*(1-‖c‖⁻¹)⁻¹ :=
        mul_le_mul_of_nonneg_left hG (inv_nonneg.mpr (norm_nonneg _))
      _ = (‖c‖-1)⁻¹ := by
        have hn : ‖c‖≠0 := norm_ne_zero_iff.mpr hc0
        have hsub : ‖c‖-1≠0 := sub_ne_zero.mpr hc.ne'
        field_simp

theorem signed_diagonal_recurrence_inverses (S : Operator) (hS : S∈unitary Operator)
    {s δ : ℝ} (hs : |s|=1) (hδ : 0<δ) (hδ1 : δ≤1) :
    ∃ Rp Rm : Operator,
      (S-((s*(1+δ):ℝ):ℂ) • (1:Operator))*Rp=1 ∧
      Rp*(S-((s*(1+δ):ℝ):ℂ) • (1:Operator))=1 ∧
      (S-((s*(1-δ):ℝ):ℂ) • (1:Operator))*Rm=1 ∧
      Rm*(S-((s*(1-δ):ℝ):ℂ) • (1:Operator))=1 ∧
      ‖Rp‖≤δ⁻¹ ∧ ‖Rm‖≤δ⁻¹ := by
  have hp : ‖((s*(1+δ):ℝ):ℂ)‖=1+δ := by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_mul,hs,one_mul,abs_of_nonneg (by linarith)]
  have hm : ‖((s*(1-δ):ℝ):ℂ)‖=1-δ := by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_mul,hs,one_mul,abs_of_nonneg (by linarith)]
  obtain ⟨Rp,hpR,hRp,hpbound⟩ := unitary_recurrence_inverse_outside S hS
    ((s*(1+δ):ℝ):ℂ) (by rw [hp]; linarith)
  obtain ⟨Rm,hmR,hRm,hmbound⟩ := unitary_recurrence_inverse_inside S hS
    ((s*(1-δ):ℝ):ℂ) (by rw [hm]; linarith)
  refine ⟨Rp,Rm,hpR,hRp,hmR,hRm,?_,?_⟩
  · simpa only [hp,add_sub_cancel_left] using hpbound
  · simpa only [hm,sub_sub_cancel] using hmbound

end UAMO.PhysicalRepresentation

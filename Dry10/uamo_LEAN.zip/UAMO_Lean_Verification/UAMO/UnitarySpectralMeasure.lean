import UAMO.SpectralMomentCorrespondence
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Unitary
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Unique

noncomputable section
namespace UAMO.UnitarySpectral
open SpectralMoments MeasureTheory CompactlySupported Set
open scoped ContinuousFunctionalCalculus Topology

section ContinuousMaps
variable {X : Type*} [TopologicalSpace X]

def realContinuousToComplex : C(X, ℝ) →ₗ[ℝ] C(X, ℂ) where
  toFun f := ⟨fun x => (f x : ℂ), Complex.continuous_ofReal.comp f.continuous⟩
  map_add' f g := by ext x; simp
  map_smul' c f := by ext x; simp [Complex.real_smul]

@[simp] theorem realContinuousToComplex_apply (f : C(X, ℝ)) (x : X) :
    realContinuousToComplex f x = (f x : ℂ) := rfl

def compactRealToComplex : C_c(X, ℝ) →ₗ[ℝ] C(X, ℂ) where
  toFun f := realContinuousToComplex f.toContinuousMap
  map_add' f g := by ext x; simp
  map_smul' c f := by ext x; simp [Complex.real_smul]

end ContinuousMaps

section SpectralConstruction
variable {A : Type*} [CStarAlgebra A]
variable (τ : FaithfulTracialState A) (U : A) (hU : IsStarNormal U)

abbrev ComplexSpectrum : Type _ := spectrum ℂ U

def normalSpectralFunctional : C_c(ComplexSpectrum U, ℝ) →ₗ[ℝ] ℝ :=
  τ.functional.toLinearMap.comp
    (((cfcL hU).restrictScalars ℝ).toLinearMap.comp compactRealToComplex)

theorem normalSpectralFunctional_nonneg (f : C_c(ComplexSpectrum U, ℝ)) (hf : 0 ≤ f) :
    0 ≤ normalSpectralFunctional τ U hU f := by
  let g : C(ComplexSpectrum U, ℂ) :=
    ⟨fun x => (Real.sqrt (f x) : ℂ),
      Complex.continuous_ofReal.comp (Real.continuous_sqrt.comp f.continuous)⟩
  have hsq : star g * g = compactRealToComplex f := by
    ext x
    change star (Real.sqrt (f x) : ℂ) * (Real.sqrt (f x) : ℂ) = (f x : ℂ)
    rw [Complex.star_def, Complex.conj_ofReal, ← Complex.ofReal_mul,
      Real.mul_self_sqrt (hf x)]
  change 0 ≤ τ.functional (cfcHom hU (compactRealToComplex f))
  rw [← hsq, map_mul, map_star]
  exact τ.positive _

def normalSpectralMeasure : Measure (ComplexSpectrum U) :=
  RealRMK.rieszMeasure (normalSpectralFunctional_nonneg τ U hU)

theorem normalSpectralMeasure_integral (f : C(ComplexSpectrum U, ℝ)) :
    ∫ x, f x ∂normalSpectralMeasure τ U hU =
      τ.functional (cfcHom hU (realContinuousToComplex f)) := by
  let fc : C_c(ComplexSpectrum U, ℝ) :=
    { toContinuousMap := f
      hasCompactSupport' := HasCompactSupport.of_compactSpace f }
  exact RealRMK.integral_rieszMeasure (normalSpectralFunctional_nonneg τ U hU) fc

instance normalSpectralMeasure_isProbabilityMeasure :
    IsProbabilityMeasure (normalSpectralMeasure τ U hU) := by
  constructor
  apply (ENNReal.toReal_eq_one_iff _).mp
  have h := normalSpectralMeasure_integral τ U hU (1 : C(ComplexSpectrum U, ℝ))
  have hone : realContinuousToComplex (1 : C(ComplexSpectrum U, ℝ)) = 1 := by ext; simp
  simpa only [ContinuousMap.one_apply, integral_const, smul_eq_mul, mul_one,
    hone, map_one, τ.normalized, measureReal_def] using h

def complexSpectralMeasure : Measure ℂ :=
  (normalSpectralMeasure τ U hU).map (fun x : ComplexSpectrum U => (x : ℂ))

instance complexSpectralMeasure_isProbabilityMeasure :
    IsProbabilityMeasure (complexSpectralMeasure τ U hU) :=
  isProbabilityMeasure_map continuous_subtype_val.measurable.aemeasurable

theorem complexSpectralMeasure_integral_eq_subtype (f : ℂ → ℝ) :
    ∫ z, f z ∂complexSpectralMeasure τ U hU =
      ∫ z : ComplexSpectrum U, f z ∂normalSpectralMeasure τ U hU := by
  rw [complexSpectralMeasure]
  exact (MeasurableEmbedding.subtype_coe (spectrum.isClosed (𝕜 := ℂ) U).measurableSet).integral_map f

theorem complexSpectralMeasure_integral_cfc (f : ℂ → ℝ) (hf : Continuous f) :
    ∫ z, f z ∂complexSpectralMeasure τ U hU =
      τ.functional (cfc (fun z => (f z : ℂ)) U) := by
  rw [complexSpectralMeasure_integral_eq_subtype,
    cfc_apply (fun z : ℂ => (f z : ℂ)) U hU
      (show ContinuousOn (fun z : ℂ => (f z : ℂ)) (spectrum ℂ U) from
        (Complex.continuous_ofReal.comp hf).continuousOn)]
  exact normalSpectralMeasure_integral τ U hU ⟨_, hf.comp continuous_subtype_val⟩

theorem complexSpectralMeasure_ae_mem_spectrum :
    ∀ᵐ z ∂complexSpectralMeasure τ U hU, z ∈ spectrum ℂ U := by
  rw [complexSpectralMeasure]
  exact (ae_map_iff continuous_subtype_val.measurable.aemeasurable
    (spectrum.isClosed (𝕜 := ℂ) U).measurableSet).mpr
      (Filter.Eventually.of_forall fun z => z.property)

theorem complexSpectralMeasure_ae_circle (hunit : U ∈ unitary A) :
    ∀ᵐ z ∂complexSpectralMeasure τ U hU, ‖z‖ = 1 := by
  filter_upwards [complexSpectralMeasure_ae_mem_spectrum τ U hU] with z hz
  exact mem_sphere_zero_iff_norm.mp (spectrum.subset_circle_of_unitary hunit hz)

end SpectralConstruction

section RealPart
variable {A : Type*} [CStarAlgebra A]

def operatorRealPart (U : A) : A := (1 / 2 : ℝ) • (U + star U)

theorem operatorRealPart_selfAdjoint (U : A) : IsSelfAdjoint (operatorRealPart U) :=
  (IsSelfAdjoint.all (1 / 2 : ℝ)).smul (IsSelfAdjoint.add_star_self U)

theorem cfc_complex_re (U : A) (hU : IsStarNormal U) :
    cfc (fun z : ℂ => (z.re : ℂ)) U = operatorRealPart U := by
  have hf : (fun z : ℂ => (z.re : ℂ)) =
      (fun z : ℂ => (1 / 2 : ℝ) • (z + star z)) := by
    funext z
    apply Complex.ext <;> simp [Complex.real_smul, Complex.star_def]
    ring
  rw [hf, cfc_smul (1 / 2 : ℝ) (fun z : ℂ => z + star z) U (by fun_prop),
    cfc_add U (fun z : ℂ => z) (star : ℂ → ℂ) (by fun_prop) (by fun_prop),
    cfc_id' ℂ U hU, cfc_star_id U hU]
  rfl

theorem cfc_realPart_comp (U : A) (hU : IsStarNormal U)
    (f : ℝ → ℝ) (hf : Continuous f) :
    cfc (fun z : ℂ => (f z.re : ℂ)) U = cfc f (operatorRealPart U) := by
  have h := cfc_comp (fun z : ℂ => (f z.re : ℂ)) (fun z : ℂ => (z.re : ℂ)) U hU
    (by fun_prop) (by fun_prop)
  rw [cfc_complex_re U hU, ← cfc_real_eq_complex f (operatorRealPart_selfAdjoint U)] at h
  simpa only [Function.comp_apply, Complex.ofReal_re] using h

theorem complexSpectralMeasure_map_re (τ : FaithfulTracialState A) (U : A)
    (hU : IsStarNormal U) :
    (complexSpectralMeasure τ U hU).map Complex.re =
      realSpectralMeasure τ (operatorRealPart U) (operatorRealPart_selfAdjoint U) := by
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  rw [integral_map Complex.continuous_re.measurable.aemeasurable
    f.continuous.aestronglyMeasurable,
    complexSpectralMeasure_integral_cfc τ U hU (fun z => f z.re)
      (f.continuous.comp Complex.continuous_re),
    realSpectralMeasure_integral_cfc τ (operatorRealPart U)
      (operatorRealPart_selfAdjoint U) f f.continuous,
    cfc_realPart_comp U hU f f.continuous]

end RealPart

section Conjugation
variable {A : Type*} [CStarAlgebra A]

theorem complexSpectralMeasure_map_conj (τ : FaithfulTracialState A) (U : A)
    (hU : IsStarNormal U) :
    (complexSpectralMeasure τ U hU).map (star : ℂ → ℂ) =
      complexSpectralMeasure τ (star U) (by letI := hU; infer_instance) := by
  letI := hU
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  rw [integral_map continuous_star.measurable.aemeasurable f.continuous.aestronglyMeasurable,
    complexSpectralMeasure_integral_cfc τ U hU (fun z => f (star z))
      (f.continuous.comp continuous_star),
    complexSpectralMeasure_integral_cfc τ (star U) _ f f.continuous]
  congr 1
  exact cfc_comp_star (fun z : ℂ => (f z : ℂ)) U (by fun_prop) hU

def unitaryConjugation (G : unitary A) : A →⋆ₐ[ℂ] A where
  toFun B := (G : A) * B * star (G : A)
  map_one' := by simp only [mul_one, unitary.mul_star_self_of_mem G.property]
  map_zero' := by simp
  map_add' := by intro B C; simp only [mul_add, add_mul]
  map_mul' := by
    intro B C
    symm
    calc
      _ = (G : A) * B * (star (G : A) * (G : A)) * C * star (G : A) := by noncomm_ring
      _ = _ := by rw [unitary.star_mul_self_of_mem G.property]; noncomm_ring
  commutes' := by
    intro c
    simp only [Algebra.algebraMap_eq_smul_one, mul_smul_comm, smul_mul_assoc, mul_one,
      unitary.mul_star_self_of_mem G.property]
  map_star' := by intro B; simp only [star_mul, star_star, mul_assoc]

theorem trace_unitaryConjugation (τ : FaithfulTracialState A) (G : unitary A) (B : A) :
    τ.functional (unitaryConjugation G B) = τ.functional B := by
  change τ.functional ((G : A) * B * star (G : A)) = _
  rw [τ.cyclic ((G : A) * B) (star (G : A)), ← mul_assoc,
    unitary.star_mul_self_of_mem G.property, one_mul]

theorem complexSpectralMeasure_eq_of_unitaryConjugation
    (τ : FaithfulTracialState A) (U V : A) (hU : IsStarNormal U) (hV : IsStarNormal V)
    (G : unitary A) (hconj : unitaryConjugation G U = V) :
    complexSpectralMeasure τ V hV = complexSpectralMeasure τ U hU := by
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  rw [complexSpectralMeasure_integral_cfc τ V hV f f.continuous,
    complexSpectralMeasure_integral_cfc τ U hU f f.continuous]
  have hcalc := (unitaryConjugation G).map_cfc (fun z : ℂ => (f z : ℂ)) U
    (by fun_prop) (by change Continuous (fun B : A => (G : A) * B * star (G : A)); fun_prop)
    hU (by rw [hconj]; exact hV)
  rw [hconj] at hcalc
  rw [← hcalc, trace_unitaryConjugation]

theorem complexSpectralMeasure_conj_invariant_of_conjugacy
    (τ : FaithfulTracialState A) (U : A) (hU : IsStarNormal U)
    (G : unitary A) (hconj : unitaryConjugation G U = star U) :
    (complexSpectralMeasure τ U hU).map (star : ℂ → ℂ) = complexSpectralMeasure τ U hU := by
  rw [complexSpectralMeasure_map_conj]
  exact complexSpectralMeasure_eq_of_unitaryConjugation τ U (star U) hU _ G hconj

end Conjugation
end UAMO.UnitarySpectral

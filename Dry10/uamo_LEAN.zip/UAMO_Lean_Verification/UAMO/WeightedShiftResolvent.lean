import UAMO.UnitaryRecurrenceInverse
import Mathlib.Algebra.GeomSum
import Mathlib.Algebra.Group.Commute.Units
import Mathlib.Algebra.BigOperators.Intervals

noncomputable section
namespace UAMO.PhysicalRepresentation
open scoped BigOperators

local instance weightedShift_operator_nontrivial : Nontrivial Operator := by
  apply nontrivial_of_ne (1:Operator) 0
  intro h
  have hh := congrArg (fun T:Operator => T (lp.single 2 (0:ℤ) (1:ℂ)) 0) h
  simp at hh

theorem one_sub_isUnit_of_power_norm_lt_one (T:Operator) (N:ℕ) (hT:‖T^N‖<1) :
    IsUnit (1-T) := by
  have hunit : IsUnit (1-T^N) := (Units.oneSub (T^N) hT).isUnit
  let G : Operator := ∑ k∈Finset.range N,T^k
  have hleft : (1-T)*G=1-T^N := mul_neg_geom_sum T N
  have hright : G*(1-T)=1-T^N := geom_sum_mul_neg T N
  have hc : Commute (1-T) G := hleft.trans hright.symm
  rw [← hleft] at hunit
  exact (hc.isUnit_mul_iff.mp hunit).1

private theorem shift_power_apply (N:ℕ) (ψ:Hilbert) (n:ℤ) :
    (shift^N) ψ n=ψ (n-(N:ℤ)) := by
  induction N generalizing ψ n with
  | zero => simp
  | succ N ih =>
    rw [pow_succ,ContinuousLinearMap.mul_apply,ih,shift_apply]
    rw [show n-(N:ℤ)-1=n-((N+1:ℕ):ℤ) by omega]

private theorem shift_star_power_apply (N:ℕ) (ψ:Hilbert) (n:ℤ) :
    ((star shift)^N) ψ n=ψ (n+(N:ℤ)) := by
  induction N generalizing ψ n with
  | zero => simp
  | succ N ih =>
    rw [pow_succ,ContinuousLinearMap.mul_apply,ih,shift_star_apply]
    rw [show n+(N:ℤ)+1=n+((N+1:ℕ):ℤ) by omega]

theorem weightedBackward_power_apply (d:ℤ→ℂ) (C:ℝ) (hC:0≤C)
    (hd:∀n,‖d n‖≤C) (N:ℕ) (ψ:Hilbert) (n:ℤ) :
    ((latticeMultiplier d C hC hd*shift)^N) ψ n=
      (∏k∈Finset.range N,d (n-(k:ℤ)))*ψ (n-(N:ℤ)) := by
  induction N generalizing ψ n with
  | zero => simp
  | succ N ih =>
    rw [pow_succ,ContinuousLinearMap.mul_apply,ih]
    simp only [ContinuousLinearMap.mul_apply,latticeMultiplier_apply,shift_apply,
      Finset.prod_range_succ]
    have he : n-(N:ℤ)-1=n-((N+1:ℕ):ℤ) := by omega
    rw [he,mul_assoc]

theorem weightedForward_power_apply (d:ℤ→ℂ) (C:ℝ) (hC:0≤C)
    (hd:∀n,‖d n‖≤C) (N:ℕ) (ψ:Hilbert) (n:ℤ) :
    ((latticeMultiplier d C hC hd*star shift)^N) ψ n=
      (∏k∈Finset.range N,d (n+(k:ℤ)))*ψ (n+(N:ℤ)) := by
  induction N generalizing ψ n with
  | zero => simp
  | succ N ih =>
    rw [pow_succ,ContinuousLinearMap.mul_apply,ih]
    simp only [ContinuousLinearMap.mul_apply,latticeMultiplier_apply,shift_star_apply,
      Finset.prod_range_succ]
    have he : n+(N:ℤ)+1=n+((N+1:ℕ):ℤ) := by omega
    rw [he,mul_assoc]

theorem backwardProduct_eq_forwardProduct (d:ℤ→ℂ) (N:ℕ) (n:ℤ) :
    (∏k∈Finset.range N,d (n-(k:ℤ)))=
      ∏k∈Finset.range N,d (n-(N:ℤ)+1+(k:ℤ)) := by
  rw [← Finset.prod_range_reflect (fun k:ℕ => d (n-(N:ℤ)+1+(k:ℤ))) N]
  apply Finset.prod_congr rfl
  intro k hk
  congr 1
  have hkn := Finset.mem_range.mp hk
  omega

theorem weightedBackward_power_norm_le (d:ℤ→ℂ) (C:ℝ) (hC:0≤C)
    (hd:∀n,‖d n‖≤C) (N:ℕ) (q:ℝ) (hq:0≤q)
    (hp:∀n:ℤ,‖∏k∈Finset.range N,d (n-(k:ℤ))‖≤q) :
    ‖(latticeMultiplier d C hC hd*shift)^N‖≤q := by
  have he : (latticeMultiplier d C hC hd*shift)^N=
      latticeMultiplier (fun n => ∏k∈Finset.range N,d (n-(k:ℤ))) q hq hp * shift^N := by
    ext ψ n
    simp only [weightedBackward_power_apply,ContinuousLinearMap.mul_apply,
      latticeMultiplier_apply,shift_power_apply]
  rw [he]
  have hs : ‖shift^N‖≤1 := by
    simpa only [CStarRing.norm_of_mem_unitary shift_unitary,one_pow] using norm_pow_le shift N
  calc
    _ ≤ ‖latticeMultiplier (fun n => ∏k∈Finset.range N,d (n-(k:ℤ))) q hq hp‖*‖shift^N‖ :=
      norm_mul_le _ _
    _ ≤ q*1 := mul_le_mul (latticeMultiplier_norm_le _ q hq hp) hs (norm_nonneg _) hq
    _ = q := mul_one q

theorem weightedForward_power_norm_le (d:ℤ→ℂ) (C:ℝ) (hC:0≤C)
    (hd:∀n,‖d n‖≤C) (N:ℕ) (q:ℝ) (hq:0≤q)
    (hp:∀n:ℤ,‖∏k∈Finset.range N,d (n+(k:ℤ))‖≤q) :
    ‖(latticeMultiplier d C hC hd*star shift)^N‖≤q := by
  have he : (latticeMultiplier d C hC hd*star shift)^N=
      latticeMultiplier (fun n => ∏k∈Finset.range N,d (n+(k:ℤ))) q hq hp * (star shift)^N := by
    ext ψ n
    simp only [weightedForward_power_apply,ContinuousLinearMap.mul_apply,
      latticeMultiplier_apply,shift_star_power_apply]
  rw [he]
  have hs : ‖(star shift)^N‖≤1 := by
    calc
      _ ≤ ‖star shift‖^N := norm_pow_le _ _
      _ = 1 := by rw [norm_star shift,CStarRing.norm_of_mem_unitary shift_unitary,one_pow]
  calc
    _ ≤ ‖latticeMultiplier (fun n => ∏k∈Finset.range N,d (n+(k:ℤ))) q hq hp‖*‖(star shift)^N‖ :=
      norm_mul_le _ _
    _ ≤ q*1 := mul_le_mul (latticeMultiplier_norm_le _ q hq hp) hs (norm_nonneg _) hq
    _ = q := mul_one q

theorem lattice_recurrence_isUnit_of_forward_product_contraction
    (d:ℤ→ℂ) (C:ℝ) (hC:0≤C) (hd:∀n,‖d n‖≤C)
    (N:ℕ) (q:ℝ) (hq:q<1)
    (hp:∀n:ℤ,‖∏k∈Finset.range N,d (n+(k:ℤ))‖≤q) :
    IsUnit (star shift-latticeMultiplier d C hC hd) := by
  have hq0 : 0≤q := (norm_nonneg _).trans (hp 0)
  have hback : ∀n:ℤ,‖∏k∈Finset.range N,d (n-(k:ℤ))‖≤q := by
    intro n
    rw [backwardProduct_eq_forwardProduct]
    exact hp (n-(N:ℤ)+1)
  have hpow := (weightedBackward_power_norm_le d C hC hd N q hq0 hback).trans_lt hq
  have hunit := one_sub_isUnit_of_power_norm_lt_one (latticeMultiplier d C hC hd*shift) N hpow
  have hS : IsUnit (star shift) :=
    ⟨⟨star shift,shift,unitary.star_mul_self_of_mem shift_unitary,
      unitary.mul_star_self_of_mem shift_unitary⟩,rfl⟩
  have he : (1-latticeMultiplier d C hC hd*shift)*star shift=
      star shift-latticeMultiplier d C hC hd := by
    rw [sub_mul,one_mul,mul_assoc,unitary.mul_star_self_of_mem shift_unitary,mul_one]
  rw [← he]
  exact hunit.mul hS

theorem lattice_recurrence_isUnit_of_inverse_product_contraction
    (d:ℤ→ℂ) (C D:ℝ) (hC:0≤C) (hD:0≤D)
    (hd:∀n,‖d n‖≤C) (hi:∀n,‖(d n)⁻¹‖≤D) (hne:∀n,d n≠0)
    (N:ℕ) (q:ℝ) (hq:q<1)
    (hp:∀n:ℤ,‖∏k∈Finset.range N,(d (n+(k:ℤ)))⁻¹‖≤q) :
    IsUnit (star shift-latticeMultiplier d C hC hd) := by
  have hq0 : 0≤q := (norm_nonneg _).trans (hp 0)
  have hpow := (weightedForward_power_norm_le (fun n => (d n)⁻¹) D hD hi N q hq0 hp).trans_lt hq
  have hunit := one_sub_isUnit_of_power_norm_lt_one
    (latticeMultiplier (fun n => (d n)⁻¹) D hD hi*star shift) N hpow
  have hM := latticeMultiplier_isUnit d (fun n => (d n)⁻¹) C D hC hD hd hi
    (fun n => mul_inv_cancel₀ (hne n))
  have hinv := latticeMultiplier_mul_eq_one d (fun n => (d n)⁻¹) C D hC hD hd hi
    (fun n => mul_inv_cancel₀ (hne n))
  have he : (-latticeMultiplier d C hC hd)*
      (1-latticeMultiplier (fun n => (d n)⁻¹) D hD hi*star shift)=
      star shift-latticeMultiplier d C hC hd := by
    rw [mul_sub,mul_one,neg_mul,← mul_assoc,hinv,one_mul]
    abel
  rw [← he]
  exact hM.neg.mul hunit

end UAMO.PhysicalRepresentation

import UAMODraft.AnalyticOpenSeed
import UAMODraft.GlobalSeedParity
import UAMODraft.AnalyticCouplingSeed
noncomputable section
namespace UAMODraft.OddSeed
open UAMO

theorem positive_odd_all_lift_open_gaps {α : ℝ} (hα : Irrational α)
    (m : ℕ) (hm : Odd m) :
    ∃ ε : ℝ,0<ε ∧ ε<1 ∧ ∀ (r : ℝ) (hr : 0<r),r<ε → ∃hr1:r<1,
      ∀ell:ℤ,OpenDOSGapLabel 1 r α (by norm_num) (by norm_num) hr.le hr1.le
        (uamoGapLabel α (m:ℤ) ell) :=by
  obtain ⟨ε0,hε0,h0⟩ :=UAMODraft.SeedLabel.analytic_odd_seed_openDOSGapLabel hα m hm 0
  obtain ⟨ε1,hε1,h1⟩ :=UAMODraft.SeedLabel.analytic_odd_seed_openDOSGapLabel hα m hm 1
  let ε:=min ε0 (min ε1 (1/2))
  have hε:0<ε :=by dsimp [ε];positivity
  refine ⟨ε,hε,?_,?_⟩
  · exact ((min_le_right _ _).trans (min_le_right _ _)).trans_lt (by norm_num)
  · intro r hr hre
    obtain ⟨hr0,hrtail⟩ :=lt_min_iff.mp hre
    obtain ⟨hr1,hhalf⟩ :=lt_min_iff.mp hrtail
    have hrl : r<1 :=by linarith
    obtain ⟨_,hg0⟩ :=h0 r hr hr0
    obtain ⟨_,hg1⟩ :=h1 r hr hr1
    refine ⟨hrl,all_gapLabel_lifts_of_two (by norm_num) (by norm_num) hr.le hrl.le hα (m:ℤ) ?_⟩
    intro e
    fin_cases e
    · exact hg0
    · exact hg1

theorem signed_odd_first_edge_open_gaps {α : ℝ} (hα : Irrational α)
    (m : ℤ) (hm : Odd m) :
    ∃ ε : ℝ,0<ε ∧ ε<1 ∧ ∀ (r : ℝ) (hr : 0<r),r<ε → ∃hr1:r<1,
      ∀ell:ℤ,OpenDOSGapLabel 1 r α (by norm_num) (by norm_num) hr.le hr1.le
        (uamoGapLabel α m ell) :=by
  obtain ⟨ε,hε,hε1,hseed⟩ :=positive_odd_all_lift_open_gaps hα m.natAbs hm.natAbs
  refine ⟨ε,hε,hε1,?_⟩
  intro r hr hre
  obtain ⟨hr1,hgap⟩ :=hseed r hr hre
  refine ⟨hr1,?_⟩
  intro ell
  rcases le_or_gt 0 m with hm0 | hm0
  · have he : (m.natAbs:ℤ)=m :=by simpa only [abs_of_nonneg hm0] using Int.natCast_natAbs m
    simpa only [he] using hgap ell
  · have he : -(m.natAbs:ℤ)=m :=by
      have hh:=Int.natCast_natAbs m
      rw [abs_of_neg hm0] at hh
      omega
    have hg:=openDOSGapLabel_neg_winding (a:=1) (by norm_num) (by norm_num)
      hr.le hr1.le hα (m.natAbs:ℤ) ell (hgap ell)
    simpa only [he] using hg

theorem all_odd_boundary_seed_gaps {α : ℝ} (hα : Irrational α)
    (m : ℤ) (hm : Odd m) :
    ∃ ε : ℝ,0<ε ∧ ε<1 ∧ ∀ (r : ℝ) (hr : 0<r),r<ε → ∃hr1:r<1,
      ∀ell:ℤ,
        OpenDOSGapLabel 1 r α (by norm_num) (by norm_num) hr.le hr1.le (uamoGapLabel α m ell) ∧
        OpenDOSGapLabel r 1 α hr.le hr1.le (by norm_num) (by norm_num) (uamoGapLabel α m ell) :=by
  obtain ⟨εp,hεp,hεp1,hp⟩ :=signed_odd_first_edge_open_gaps hα m hm
  obtain ⟨εn,hεn,_,hn⟩ :=signed_odd_first_edge_open_gaps hα.neg m hm
  refine ⟨min εp εn,lt_min hεp hεn,(min_le_left _ _).trans_lt hεp1,?_⟩
  intro r hr hre
  obtain ⟨hrp,hrn⟩ :=lt_min_iff.mp hre
  obtain ⟨hr1,hgp⟩ :=hp r hr hrp
  obtain ⟨_,hgn⟩ :=hn r hr hrn
  refine ⟨hr1,?_⟩
  intro ell
  exact ⟨hgp ell,openDOSGapLabel_other_edge hr.le hr1.le hα m ell (hgn ell)⟩

theorem all_odd_boundary_seed_gaps_physical_coupling {α : ℝ} (hα : Irrational α)
    (m : ℤ) (hm : Odd m) :
    ∃ ε : ℝ,0<ε ∧ ε<1 ∧ ∀ (lam : ℝ) (hlam : 0<lam),lam<ε →
      ∃hr1:inverseCoupling lam<1,∀ell:ℤ,
        OpenDOSGapLabel 1 (inverseCoupling lam) α (by norm_num) (by norm_num)
          (inverseCoupling_pos hlam).le hr1.le (uamoGapLabel α m ell) ∧
        OpenDOSGapLabel (inverseCoupling lam) 1 α (inverseCoupling_pos hlam).le hr1.le
          (by norm_num) (by norm_num) (uamoGapLabel α m ell) :=by
  obtain ⟨ε,hε,hε1,hseed⟩ :=all_odd_boundary_seed_gaps hα m hm
  refine ⟨ε,hε,hε1,?_⟩
  intro lam hlam hsmall
  exact hseed (inverseCoupling lam) (inverseCoupling_pos hlam)
    ((inverseCoupling_le hlam.le).trans_lt hsmall)

end UAMODraft.OddSeed

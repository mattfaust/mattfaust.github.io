import UAMODraft.FiniteSystem

noncomputable section
set_option maxHeartbeats 800000
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed
open scoped Topology

abbrev ParameterSpace (m : ℕ) := ℝ × Variables m

def baseCoefficient (k : ℤ) : ℂ := if k=0 then 1 else 0

def forcing (m : ℕ) (k : Mode m) : ℂ :=
  (2*Complex.I)⁻¹*(baseCoefficient ((k:ℤ)+1)-baseCoefficient ((k:ℤ)-1))

def coefficientDifferential (m : ℕ) (k : ℤ) : Variables m →L[ℝ] ℂ :=
  if k=0 then 0 else if hk : k∈Finset.Icc (-(m:ℤ)+1) (m:ℤ) then
    ContinuousLinearMap.proj ⟨k,hk⟩ else 0

theorem coefficient_base (m : ℕ) (k : ℤ) : coefficient m 0 k=baseCoefficient k := by
  simp [coefficient,baseCoefficient]

theorem coefficient_hasFDerivAt (m : ℕ) (k : ℤ) (x : Variables m) :
    HasFDerivAt (fun x : Variables m => coefficient m x k) (coefficientDifferential m k) x := by
  unfold coefficient coefficientDifferential
  split_ifs
  · exact hasFDerivAt_const _ _
  · exact (ContinuousLinearMap.proj _ : Variables m →L[ℝ] ℂ).hasFDerivAt
  · exact hasFDerivAt_const _ _

def parameterEvaluation (m : ℕ) (k : Mode m) : ParameterSpace m →L[ℝ] ℂ :=
  (ContinuousLinearMap.proj k).comp (ContinuousLinearMap.snd ℝ ℝ (Variables m))

def parameterComplex (m : ℕ) : ParameterSpace m →L[ℝ] ℂ :=
  Complex.ofRealCLM.comp (ContinuousLinearMap.fst ℝ ℝ (Variables m))

def fullDerivative (m : ℕ) (z q : ℂ) : ParameterSpace m →L[ℝ] Variables m :=
  ContinuousLinearMap.pi (fun k =>
    diagonal m z q k • parameterEvaluation m k + forcing m k • parameterComplex m)

theorem finiteSystem_hasFDerivAt (m : ℕ) (hm : 0<m) (z q : ℂ) :
    HasFDerivAt (fun p : ParameterSpace m => finiteSystem m hm z q p.1 p.2)
      (fullDerivative m z q) (0,0) := by
  let ev := parameterEvaluation m (zeroMode m hm)
  let im := Complex.ofRealCLM.comp (Complex.imCLM.comp ev)
  let re := Complex.ofRealCLM.comp (Complex.reCLM.comp ev)
  have hi := im.hasFDerivAt (x := (0:ParameterSpace m))
  have hr := re.hasFDerivAt (x := (0:ParameterSpace m))
  have heplus : HasFDerivAt (fun p : ParameterSpace m =>
      z*Complex.exp (Complex.I*(p.2 (zeroMode m hm)).im))
      (z • (Complex.I • im)) (0,0) := by
    simpa [im,ev,parameterEvaluation,ContinuousLinearMap.comp_apply] using
      (hi.const_mul Complex.I).cexp.const_mul z
  have heminus : HasFDerivAt (fun p : ParameterSpace m =>
      z⁻¹*Complex.exp (-Complex.I*(p.2 (zeroMode m hm)).im))
      (z⁻¹ • ((-Complex.I) • im)) (0,0) := by
    simpa [im,ev,parameterEvaluation,ContinuousLinearMap.comp_apply] using
      (hi.const_mul (-Complex.I)).cexp.const_mul z⁻¹
  have hc (k : ℤ) := (coefficient_hasFDerivAt m k (0:Variables m)).comp (0,0)
    (ContinuousLinearMap.snd ℝ ℝ (Variables m)).hasFDerivAt
  apply hasFDerivAt_pi.mpr
  intro k
  let Dp := if Even (k:ℤ) then z • (Complex.I • im) else z⁻¹ • ((-Complex.I) • im)
  have hp : HasFDerivAt (fun p : ParameterSpace m =>
      if Even (k:ℤ) then z*Complex.exp (Complex.I*(p.2 (zeroMode m hm)).im)
      else z⁻¹*Complex.exp (-Complex.I*(p.2 (zeroMode m hm)).im)) Dp (0,0) := by
    dsimp only [Dp]
    split_ifs <;> assumption
  have hA := hp.sub (((hasFDerivAt_const (1:ℂ) (0:ParameterSpace m)).sub hr).const_mul z |>.mul_const (q^(k:ℤ)))
  have hB := ((parameterComplex m).hasFDerivAt (x := (0:ParameterSpace m))).const_mul ((2*Complex.I)⁻¹)
  have h := (hA.mul (hc k)).add (hB.mul ((hc ((k:ℤ)+1)).sub (hc ((k:ℤ)-1))))
  convert h using 1
  apply ContinuousLinearMap.ext
  intro p
  by_cases hk : (k:ℤ)=0
  · have hkz : k=zeroMode m hm := Subtype.ext hk
    subst k
    simp [fullDerivative,diagonal,parameterEvaluation,parameterComplex,forcing,baseCoefficient,
      coefficientDifferential,coefficient,zeroMode,Dp,im,re,ev,
      ContinuousLinearMap.comp_apply,smul_eq_mul]
    all_goals
      have hx := Complex.re_add_im (p.2 (zeroMode m hm))
      dsimp [zeroMode] at hx
      linear_combination -z*hx
  · simp [fullDerivative,diagonal,hk,parameterEvaluation,parameterComplex,forcing,
      coefficientDifferential,coefficient_base,baseCoefficient,k.property,Dp,im,re,ev,
      ContinuousLinearMap.comp_apply,smul_eq_mul,divisor,diagonalValue,spin]
    split_ifs <;> ring_nf <;> simp

def graphEquiv (m : ℕ) (J : Variables m ≃L[ℝ] Variables m) (b : Variables m) :
    ParameterSpace m ≃L[ℝ] ParameterSpace m :=
  ({
    toFun := fun p => (p.1,J p.2+p.1 • b)
    invFun := fun p => (p.1,J.symm (p.2-p.1 • b))
    left_inv := by intro p; simp
    right_inv := by intro p; simp
    map_add' := by
      intro p q
      apply Prod.ext
      · rfl
      · simp only [Prod.fst_add,Prod.snd_add,map_add,add_smul]
        module
    map_smul' := by intro c p; apply Prod.ext <;> simp [smul_add,smul_smul]
  } : ParameterSpace m ≃ₗ[ℝ] ParameterSpace m).toContinuousLinearEquiv

theorem exact_finite_analytic_branch {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : z^2=q^m) :
    ∃ x : ℝ → Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      (∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0) ∧
      (∀ᶠ p in nhds (0,(0:Variables m)), finiteSystem m hm z q p.1 p.2=0 → p.2=x p.1) := by
  let J := finiteJacobianEquiv hz hq0 hq m hres
  let G := graphEquiv m J (forcing m)
  apply analytic_implicit_graph (fun p : ParameterSpace m => finiteSystem m hm z q p.1 p.2) 0
    (finiteSystem_base m hm z q) (finiteSystem_analytic m hm z q (0,0)) G
  have hd := (ContinuousLinearMap.fst ℝ ℝ (Variables m)).hasFDerivAt.prodMk
    (finiteSystem_hasFDerivAt m hm z q)
  apply Eq.trans hd.fderiv
  apply ContinuousLinearMap.ext
  intro p
  apply Prod.ext
  · rfl
  · funext k
    change diagonal m z q k*p.2 k+forcing m k*(p.1:ℂ)=
      diagonal m z q k*p.2 k+p.1 • forcing m k
    simp [Complex.real_smul,mul_comm]

end UAMODraft.OddSeed

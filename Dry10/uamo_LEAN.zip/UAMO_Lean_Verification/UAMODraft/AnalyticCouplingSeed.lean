import UAMODraft.AnalyticSeedJoint
noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.CMV UAMO.BoundarySeed
open scoped Topology

def inverseCoupling (lam : ℝ) : ℝ :=lam/(1+Real.sqrt (1-lam^2))

theorem inverseCoupling_pos {lam : ℝ} (hlam : 0<lam) : 0 < inverseCoupling lam :=by
  unfold inverseCoupling
  exact div_pos hlam (by positivity)

theorem inverseCoupling_le {lam : ℝ} (hlam : 0≤lam) : inverseCoupling lam≤lam :=by
  unfold inverseCoupling
  apply (div_le_iff₀ (show 0<1+Real.sqrt (1-lam^2) by positivity)).mpr
  nlinarith [mul_nonneg hlam (Real.sqrt_nonneg (1-lam^2))]

theorem coupling_inverseCoupling {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam≤1) :
    coupling (inverseCoupling lam)=lam :=by
  have hs : (Real.sqrt (1-lam^2))^2=1-lam^2 :=Real.sq_sqrt (by nlinarith)
  have hd : 1+Real.sqrt (1-lam^2)≠0 :=ne_of_gt (by positivity)
  unfold coupling inverseCoupling
  field_simp [hd]
  linear_combination -lam*(1+Real.sqrt (1-lam^2))*hs

end UAMODraft.OddSeed

import UAMODraft.RealConjugacy
import UAMODraft.FrameBounds
import UAMO.LatticeMatrixMultiplier

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix CMV PhysicalRepresentation

def analyticLatticeFrame (m : ℕ) (α : ℝ) (ell : ℤ) (x : Variables m) (θ : ℝ) : TransferMatrix :=
  analyticFrame m x θ*seedCayley (constantPhase (diagonalizingAngle α m ell))

def analyticLatticeFrameInverse (m : ℕ) (α : ℝ) (ell : ℤ) (x : Variables m) (θ : ℝ) : TransferMatrix :=
  seedCayleyInverse (constantPhase (diagonalizingAngle α m ell))*analyticFrameInverse m x θ

theorem analyticLatticeFrame_mul_inverse (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4) (θ : ℝ) :
    analyticLatticeFrame m α ell x θ*analyticLatticeFrameInverse m α ell x θ=1 :=by
  have hframe : analyticFrame m x θ*analyticFrameInverse m x θ=1 :=
    normalizedFrame_mul_inverse _ _ (halfPhase_norm m θ) (analyticProfile_signature_positive m hm x hx θ)
  unfold analyticLatticeFrame analyticLatticeFrameInverse
  rw [mul_assoc,← mul_assoc (seedCayley _),seedCayley_mul_inverse (constantPhase_norm _),one_mul,hframe]

theorem complex_matrix_entry_bound (A B : TransferMatrix) {K L : ℝ}
    (hK : 0≤K) (hA : ∀i j,‖A i j‖≤K) (hB : ∀i j,‖B i j‖≤L) (i j : Fin 2) :
    ‖(A*B) i j‖≤2*K*L :=by
  simp only [Matrix.mul_apply,Fin.sum_univ_two]
  calc
    _ ≤ ‖A i 0*B 0 j‖+‖A i 1*B 1 j‖ :=norm_add_le _ _
    _ ≤ K*L+K*L :=by
      simp only [norm_mul]
      exact add_le_add (mul_le_mul (hA i 0) (hB 0 j) (norm_nonneg _) hK)
        (mul_le_mul (hA i 1) (hB 1 j) (norm_nonneg _) hK)
    _ = _ :=by ring

theorem analyticLatticeFrame_entry_bound (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4) (θ : ℝ) (i j : Fin 2) :
    ‖analyticLatticeFrame m α ell x θ i j‖≤8 :=by
  have h:=complex_matrix_entry_bound _ _ (by norm_num : (0:ℝ)≤4)
    (fun i j=>(analyticFrame_bounds m hm x hx.le θ i j).1)
    (seedCayley_entry_norm (constantPhase_norm (diagonalizingAngle α m ell))) i j
  norm_num at h
  exact h

theorem analyticLatticeFrameInverse_entry_bound (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4) (θ : ℝ) (i j : Fin 2) :
    ‖analyticLatticeFrameInverse m α ell x θ i j‖≤4 :=by
  have h:=complex_matrix_entry_bound _ _ (by norm_num : (0:ℝ)≤1/2)
    (seedCayleyInverse_entry_norm (constantPhase_norm (diagonalizingAngle α m ell)))
    (fun i j=>(analyticFrame_bounds m hm x hx.le θ i j).2) i j
  norm_num at h
  exact h

theorem analyticLatticeFrame_conjugacy (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (θ : ℝ) :
    boundarySzego lam (phaseCenter m hm (resonantPhase α m ell) x) θ*
      analyticLatticeFrame m α ell x θ=
    analyticLatticeFrame m α ell x (θ+α)*(analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal :=by
  rw [analyticRealTransfer,seedRealConjugate_map _ _
    (analyticTransformed_SU11 m hm (resonantPhase_norm α m ell) α hlam hlam1 x θ
      (analyticProfile_signature_positive m hm x hx θ) (analyticProfile_signature_positive m hm x hx (θ+α)))]
  change boundarySzego lam (phaseCenter m hm (resonantPhase α m ell) x) θ*
    (analyticFrame m x θ*seedCayley (constantPhase (diagonalizingAngle α m ell)))=
    (analyticFrame m x (θ+α)*seedCayley (constantPhase (diagonalizingAngle α m ell)))*
    (seedCayleyInverse (constantPhase (diagonalizingAngle α m ell))*
      (analyticFrameInverse m x (θ+α)*boundarySzego lam (phaseCenter m hm (resonantPhase α m ell) x) θ*
        analyticFrame m x θ)*seedCayley (constantPhase (diagonalizingAngle α m ell)))
  simp only [mul_assoc]
  rw [← mul_assoc (seedCayley _),seedCayley_mul_inverse (constantPhase_norm _),one_mul]
  have hframe : analyticFrame m x (θ+α)*analyticFrameInverse m x (θ+α)=1 :=
    normalizedFrame_mul_inverse _ _ (halfPhase_norm m (θ+α)) (analyticProfile_signature_positive m hm x hx (θ+α))
  rw [← mul_assoc (analyticFrame m x (θ+α)),hframe,one_mul]

theorem analytic_boundarySzego_bound (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4)
    (hB : ∀θ i j,‖((analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal) i j‖≤3)
    (θ : ℝ) (i j : Fin 2) :
    ‖boundarySzego lam (phaseCenter m hm (resonantPhase α m ell) x) θ i j‖≤384 :=by
  have he:=congrArg (fun M=>M*analyticLatticeFrameInverse m α ell x θ)
    (analyticLatticeFrame_conjugacy m hm α ell hlam hlam1 x hx θ)
  dsimp only at he
  rw [mul_assoc,analyticLatticeFrame_mul_inverse m hm α ell x hx,mul_one] at he
  rw [he]
  have hl : ∀i j,‖(analyticLatticeFrame m α ell x (θ+α)*
      (analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal) i j‖≤48 :=by
    intro i j
    have h:=complex_matrix_entry_bound _ _ (by norm_num : (0:ℝ)≤8)
      (analyticLatticeFrame_entry_bound m hm α ell x hx (θ+α)) (hB θ) i j
    norm_num at h
    exact h
  have h:=complex_matrix_entry_bound _ _ (by norm_num : (0:ℝ)≤48) hl
    (analyticLatticeFrameInverse_entry_bound m hm α ell x hx θ) i j
  norm_num at h
  exact h

end UAMODraft.OddSeed

import UAMODraft.AnalyticSeedLabels
import UAMO.PhysicalOpenGapAllCuts

noncomputable section
namespace UAMODraft.SeedLabel
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open scoped Topology

theorem analytic_odd_seed_openDOSGapLabel {α:ℝ} (hα:Irrational α)
    (m:ℕ) (hm:Odd m) (ell:ℤ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ (r : ℝ) (hr : 0 < r), r < ε → ∃ hr1 : r < 1,
      OpenDOSGapLabel 1 r α (by norm_num) (by norm_num) hr.le hr1.le
        (uamoGapLabel α (m:ℤ) ell) :=by
  obtain ⟨x,_,_,ε,hε,hjoint⟩:=analytic_odd_seed_with_physical_labels hα m hm ell
  refine ⟨ε,hε,fun r hr hre=>?_⟩
  obtain ⟨hr1,hres,_,hlabel⟩:=hjoint r hr hre
  let z:=phaseCenter m (by obtain ⟨j,hj⟩:=hm;omega) (resonantPhase α m ell) (x (coupling r))
  have hz:‖z‖=1 :=by
    dsimp only [z]
    rw [phaseCenter_norm,resonantPhase_norm]
  have hphysical:z∈resolventSet ℂ (PhysicalRepresentation.walk (coupling 1) (coupling r) α 0) :=by
    have h:=hres 0
    simpa only [show coupling 1=1 by norm_num [coupling],spectrum,Set.mem_compl_iff,not_not] using h
  exact ⟨hr1,openDOSGapLabel_of_witness_all_cuts (by norm_num) (by norm_num)
    hr.le hr1.le hα 0 z hz hphysical (uamoGapLabel α (m:ℤ) ell) hlabel.symm⟩
end UAMODraft.SeedLabel

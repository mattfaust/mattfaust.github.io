import UAMODraft.BetaZeroScalarGauge
import UAMODraft.FiniteConvergentDivisors
import Mathlib.Analysis.Complex.CauchyIntegral
import Mathlib.Analysis.Fourier.AddCircle

noncomputable section
namespace UAMODraft.AnalyticPeriodicFourier
open UAMO.ScalarGauge UAMO.Wronskian
open scoped ComplexConjugate Interval
open Set MeasureTheory

def coefficient (φ : ℂ→ℂ) (k : ℤ) : ℂ :=
  ∫ x:ℝ in (0:ℝ)..1,φ (x:ℂ)*mode (-k) (x:ℂ)

private theorem abs_le_of_mem_uIcc_zero {y t : ℝ} (ht : t∈uIcc 0 y) : |t|≤|y| := by
  rcases le_total 0 y with hy|hy
  · rw [uIcc_of_le hy] at ht
    rw [abs_of_nonneg ht.1,abs_of_nonneg hy]
    exact ht.2
  · rw [uIcc_of_ge hy] at ht
    rw [abs_of_nonpos ht.2,abs_of_nonpos hy]
    exact neg_le_neg ht.1

theorem horizontal_integral_shift (F : ℂ→ℂ) {H y : ℝ}
    (hD : DifferentiableOn ℂ F (openStrip H)) (hP : Function.Periodic F 1)
    (hy : |y|<H) :
    (∫ x:ℝ in (0:ℝ)..1,F (x:ℂ))=
      ∫ x:ℝ in (0:ℝ)..1,F ((x:ℂ)+(y:ℂ)*Complex.I) := by
  have hbox : DifferentiableOn ℂ F
      (uIcc (0:ℝ) 1 ×ℂ uIcc (0:ℝ) y) := hD.mono (by
    intro z hz
    exact (abs_le_of_mem_uIcc_zero hz.2).trans_lt hy)
  have hi := Complex.integral_boundary_rect_eq_zero_of_differentiableOn F
    0 (1+(y:ℂ)*Complex.I) (by simpa using hbox)
  have he : (fun t:ℝ => F (1+(t:ℂ)*Complex.I))=
      (fun t:ℝ => F ((t:ℂ)*Complex.I)) := by
    funext t
    simpa only [add_comm] using hP ((t:ℂ)*Complex.I)
  simp only [Complex.zero_re,Complex.zero_im,Complex.add_re,Complex.add_im,
    Complex.one_re,Complex.one_im,Complex.mul_re,Complex.mul_im,
    Complex.ofReal_re,Complex.ofReal_im,Complex.I_re,Complex.I_im,
    mul_zero,mul_one,zero_mul,zero_add,add_zero,sub_zero,Complex.ofReal_zero,
    Complex.ofReal_one] at hi
  rw [he] at hi
  linear_combination hi

theorem coefficient_shift (φ : ℂ→ℂ) {H y : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hy : |y|<H) (k : ℤ) :
    coefficient φ k = ∫ x:ℝ in (0:ℝ)..1,
      φ ((x:ℂ)+(y:ℂ)*Complex.I)*mode (-k) ((x:ℂ)+(y:ℂ)*Complex.I) := by
  apply horizontal_integral_shift (fun z => φ z*mode (-k) z)
    (hD.mul (mode_differentiable (-k)).differentiableOn)
  · intro z
    dsimp only
    rw [hP z,mode_periodic]
  · exact hy

theorem coefficient_decay (φ : ℂ→ℂ) {H h A : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hh : 0≤h) (hhH : h<H)
    (hA : ∀ z:ℂ,|z.im|≤h→‖φ z‖≤A) (k : ℤ) :
    ‖coefficient φ k‖≤A*Real.exp (-2*Real.pi*h*|(k:ℝ)|) := by
  let y : ℝ := if 0≤k then -h else h
  have hyabs : |y|=h := by
    dsimp only [y]
    split <;> simp [abs_of_nonneg hh]
  have hm (x : ℝ) : ‖mode (-k) ((x:ℂ)+(y:ℂ)*Complex.I)‖=
      Real.exp (-2*Real.pi*h*|(k:ℝ)|) := by
    rw [mode_norm]
    congr 1
    simp only [Complex.add_im,Complex.ofReal_im,Complex.mul_im,
      Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,mul_zero,add_zero,
      zero_add,Int.cast_neg]
    dsimp only [y]
    split_ifs with hk
    · rw [abs_of_nonneg (by exact_mod_cast hk : (0:ℝ)≤(k:ℝ))]
      ring
    · have hk' : (k:ℝ)<0 := by exact_mod_cast lt_of_not_ge hk
      rw [abs_of_neg hk']
      ring
  rw [coefficient_shift φ hD hP (by rw [hyabs];exact hhH) k]
  have hi := intervalIntegral.norm_integral_le_of_norm_le_const (a:=(0:ℝ)) (b:=1)
    (f:=fun x:ℝ => φ ((x:ℂ)+(y:ℂ)*Complex.I)*mode (-k) ((x:ℂ)+(y:ℂ)*Complex.I))
    (C:=A*Real.exp (-2*Real.pi*h*|(k:ℝ)|)) (by
      intro x _
      rw [norm_mul,hm]
      exact mul_le_mul_of_nonneg_right (hA _ (by
        simpa only [Complex.add_im,Complex.ofReal_im,Complex.mul_im,
          Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,mul_zero,
          add_zero,zero_add,hyabs] using (le_refl h))) (Real.exp_pos _).le)
  simpa using hi

private theorem line_periodic (φ : ℂ→ℂ) (hP : Function.Periodic φ 1) (y : ℝ) :
    Function.Periodic (fun x:ℝ => φ ((x:ℂ)+(y:ℂ)*Complex.I)) 1 := by
  intro x
  simpa only [Complex.ofReal_add,Complex.ofReal_one,add_right_comm] using
    hP ((x:ℂ)+(y:ℂ)*Complex.I)

private theorem line_continuous (φ : ℂ→ℂ) {H y : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hy : |y|<H) :
    Continuous (fun x:ℝ => φ ((x:ℂ)+(y:ℂ)*Complex.I)) := by
  apply hD.continuousOn.comp_continuous (Complex.continuous_ofReal.add continuous_const)
  intro x
  simpa only [openStrip,mem_setOf_eq,Complex.add_im,Complex.ofReal_im,Complex.mul_im,
    Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,mul_zero,add_zero,zero_add] using hy

def lineMap (φ : ℂ→ℂ) {H y : ℝ} (hD : DifferentiableOn ℂ φ (openStrip H))
    (hP : Function.Periodic φ 1) (hy : |y|<H) : C(AddCircle (1:ℝ),ℂ) :=
  ⟨(line_periodic φ hP y).lift,
    continuous_coinduced_dom.mpr (line_continuous φ hD hy)⟩

@[simp] theorem lineMap_coe (φ : ℂ→ℂ) {H y : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hy : |y|<H) (x : ℝ) :
    lineMap φ hD hP hy (x:AddCircle (1:ℝ))=φ ((x:ℂ)+(y:ℂ)*Complex.I) :=
  (line_periodic φ hP y).lift_coe x

private theorem mode_neg_mul (k : ℤ) (z : ℂ) : mode (-k) z*mode k z=1 := by
  simp only [mode,←Complex.exp_add,Int.cast_neg]
  convert Complex.exp_zero using 1
  congr 1
  ring

theorem lineMap_fourierCoeff (φ : ℂ→ℂ) {H y : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hy : |y|<H) (k : ℤ) :
    fourierCoeff (lineMap φ hD hP hy) k=coefficient φ k*mode k ((y:ℂ)*Complex.I) := by
  have hc := coefficient_shift φ hD hP hy k
  simp only [mode_add] at hc
  rw [show (fun x:ℝ => φ ((x:ℂ)+(y:ℂ)*Complex.I)*
      (mode (-k) (x:ℂ)*mode (-k) ((y:ℂ)*Complex.I)))=
      (fun x:ℝ => (φ ((x:ℂ)+(y:ℂ)*Complex.I)*mode (-k) (x:ℂ))*
        mode (-k) ((y:ℂ)*Complex.I)) by funext x;ring,
    intervalIntegral.integral_mul_const] at hc
  rw [hc,mul_assoc,mode_neg_mul,mul_one,fourierCoeff_eq_intervalIntegral _ k 0]
  simp only [div_one,one_smul,zero_add,lineMap_coe,←mode_real,smul_eq_mul]
  congr 1
  funext x
  ring

theorem coefficient_exponential (φ : ℂ→ℂ) {H h A s : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hh : 0≤h) (hhH : h<H)
    (hA : ∀ z:ℂ,|z.im|≤h→‖φ z‖≤A) :
    ExponentialCoefficients (coefficient φ) A s (Real.pi*(h-s)) := by
  intro k
  have he : 2*Real.pi*s+2*(Real.pi*(h-s))=2*Real.pi*h := by ring
  rw [he]
  simpa only [neg_mul] using coefficient_decay φ hD hP hh hhH hA k

theorem fourierSeries_eq (φ : ℂ→ℂ) {H h A : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hh : 0<h) (hhH : h<H) (hA0 : 0≤A)
    (hA : ∀ z:ℂ,|z.im|≤h→‖φ z‖≤A) {z : ℂ} (hz : |z.im|<h) :
    fourierSeries (coefficient φ) z=φ z := by
  have hzH := hz.trans hhH
  have hb : 0<Real.pi*(h-|z.im|) := mul_pos Real.pi_pos (sub_pos.mpr hz)
  have hc := coefficient_exponential (s:=|z.im|) φ hD hP hh.le hhH hA
  have hs0 := fourierSeries_summable (coefficient φ) hA0 hb hc
    (z:=(z.im:ℂ)*Complex.I) (by simp)
  have hs : Summable (fourierCoeff (lineMap φ hD hP hzH)) :=
    hs0.congr (fun k => (lineMap_fourierCoeff φ hD hP hzH k).symm)
  have ht := has_pointwise_sum_fourier_series_of_summable hs
    (z.re:AddCircle (1:ℝ))
  have hterm (k : ℤ) :
      fourierCoeff (lineMap φ hD hP hzH) k*fourier k (z.re:AddCircle (1:ℝ))=
        coefficient φ k*mode k z := by
    rw [lineMap_fourierCoeff,←mode_real]
    calc coefficient φ k*mode k ((z.im:ℂ)*Complex.I)*mode k (z.re:ℂ)
        = coefficient φ k*(mode k (z.re:ℂ)*mode k ((z.im:ℂ)*Complex.I)) := by ring
      _ = coefficient φ k*mode k z := by rw [←mode_add,Complex.re_add_im]
  simpa only [smul_eq_mul,hterm,lineMap_coe,Complex.re_add_im,fourierSeries] using ht.tsum_eq

theorem exists_strip_bound (φ : ℂ→ℂ) {H h : ℝ}
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (_hh : 0≤h) (hhH : h<H) :
    ∃ A:ℝ,0≤A ∧ ∀ z:ℂ,|z.im|≤h→‖φ z‖≤A := by
  let K : Set ℂ := Icc (0:ℝ) 1 ×ℂ Icc (-h) h
  have hK : IsCompact K := isCompact_Icc.reProdIm isCompact_Icc
  have hsub : K⊆openStrip H := by
    intro z hz
    exact (abs_le.mpr hz.2).trans_lt hhH
  obtain ⟨A,hA⟩ := hK.exists_bound_of_continuousOn (hD.continuousOn.mono hsub)
  refine ⟨max A 0,le_max_right _ _,?_⟩
  intro z hz
  have hx0 : 0≤z.re-(Int.floor z.re:ℝ) := sub_nonneg.mpr (Int.floor_le _)
  have hx1 : z.re-(Int.floor z.re:ℝ)≤1 := by linarith [Int.lt_floor_add_one z.re]
  have hzK : z-(Int.floor z.re:ℂ)∈K := by
    constructor
    · simpa only [Complex.sub_re,Complex.intCast_re] using And.intro hx0 hx1
    · change -h≤(z-(Int.floor z.re:ℂ)).im ∧ (z-(Int.floor z.re:ℂ)).im≤h
      simpa only [Complex.sub_im,Complex.intCast_im,sub_zero] using abs_le.mp hz
  have he : φ (z-(Int.floor z.re:ℂ))=φ z := by
    simpa only [mul_one] using hP.sub_int_mul_eq (x:=z) (Int.floor z.re)
  rw [←he]
  exact (hA _ hzK).trans (le_max_left _ _)

theorem coefficient_zero (φ : ℂ→ℂ)
    (hmean : (∫ x:ℝ in (0:ℝ)..1,φ (x:ℂ))=0) : coefficient φ 0=0 := by
  simpa only [coefficient,neg_zero,mode_zero,mul_one] using hmean

theorem coefficient_conj (φ : ℂ→ℂ) (hreal : ∀x:ℝ,(φ (x:ℂ)).im=0) (k : ℤ) :
    coefficient φ (-k)=conj (coefficient φ k) := by
  simp only [coefficient,neg_neg,intervalIntegral.integral_of_le zero_le_one,
    ←integral_conj]
  apply integral_congr_ae
  filter_upwards [] with x
  rw [map_mul,Complex.conj_eq_iff_im.mpr (hreal x),mode_neg_real,Complex.conj_conj]

end UAMODraft.AnalyticPeriodicFourier

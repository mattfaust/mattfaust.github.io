import UAMODraft.AnalyticLatticeFrame
import UAMO.BoundarySeedResolvent

noncomputable section
set_option maxHeartbeats 1200000
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix CMV PhysicalRepresentation

def analyticPhysicalFrame (m : ℕ) (α : ℝ) (ell : ℤ) (x : Variables m) (r θ : ℝ)
    (n : ℤ) : TransferMatrix :=
  seedOrbitScalar r α θ n • (boundarySwap*analyticLatticeFrame m α ell x (θ+(n:ℝ)*α))

def analyticPhysicalFrameInverse (m : ℕ) (α : ℝ) (ell : ℤ) (x : Variables m) (r θ : ℝ)
    (n : ℤ) : TransferMatrix :=
  (seedOrbitScalar r α θ n)⁻¹ • (analyticLatticeFrameInverse m α ell x (θ+(n:ℝ)*α)*boundarySwap)

theorem analyticPhysicalFrame_mul_inverse (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4)
    {r : ℝ} (hr : 0≤r) (hr1 : r<1) (θ : ℝ) (n : ℤ) :
    analyticPhysicalFrame m α ell x r θ n*analyticPhysicalFrameInverse m α ell x r θ n=1 :=by
  have hs : seedOrbitScalar r α θ n≠0 :=norm_ne_zero_iff.mp (by rw [seedOrbitScalar_norm hr hr1];norm_num)
  unfold analyticPhysicalFrame analyticPhysicalFrameInverse
  rw [Matrix.smul_mul,Matrix.mul_smul,smul_smul,mul_inv_cancel₀ hs,one_smul]
  rw [mul_assoc,← mul_assoc (analyticLatticeFrame _ _ _ _ _),
    analyticLatticeFrame_mul_inverse m hm α ell x hx,one_mul,boundarySwap_square]

theorem analytic_swap_left_bound (A : TransferMatrix) {C : ℝ}
    (hA : ∀i j,‖A i j‖≤C) (i j : Fin 2) : ‖(boundarySwap*A) i j‖≤C :=by
  fin_cases i
  · simpa [boundarySwap,Matrix.mul_apply,Fin.sum_univ_two] using hA 1 j
  · simpa [boundarySwap,Matrix.mul_apply,Fin.sum_univ_two] using hA 0 j

theorem analytic_swap_right_bound (A : TransferMatrix) {C : ℝ}
    (hA : ∀i j,‖A i j‖≤C) (i j : Fin 2) : ‖(A*boundarySwap) i j‖≤C :=by
  fin_cases j
  · simpa [boundarySwap,Matrix.mul_apply,Fin.sum_univ_two] using hA i 1
  · simpa [boundarySwap,Matrix.mul_apply,Fin.sum_univ_two] using hA i 0

theorem analyticPhysicalFrame_entry_bound (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4)
    {r : ℝ} (hr : 0≤r) (hr1 : r<1) (θ : ℝ) (n : ℤ) (i j : Fin 2) :
    ‖analyticPhysicalFrame m α ell x r θ n i j‖≤8 :=by
  simp only [analyticPhysicalFrame,Matrix.smul_apply,smul_eq_mul,norm_mul,
    seedOrbitScalar_norm hr hr1,one_mul]
  exact analytic_swap_left_bound _ (analyticLatticeFrame_entry_bound m hm α ell x hx _) i j

theorem analyticPhysicalFrameInverse_entry_bound (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4)
    {r : ℝ} (hr : 0≤r) (hr1 : r<1) (θ : ℝ) (n : ℤ) (i j : Fin 2) :
    ‖analyticPhysicalFrameInverse m α ell x r θ n i j‖≤4 :=by
  simp only [analyticPhysicalFrameInverse,Matrix.smul_apply,smul_eq_mul,norm_mul,norm_inv,
    seedOrbitScalar_norm hr hr1,inv_one,one_mul]
  exact analytic_swap_right_bound _ (analyticLatticeFrameInverse_entry_bound m hm α ell x hx _) i j

theorem analyticPhysicalFrame_conjugacy (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4)
    {r : ℝ} (hr : 0≤r) (hr1 : r<1) (hlam1 : coupling r<1) (θ : ℝ) (n : ℤ) :
    uamoTransfer 1 r (phaseCenter m hm (resonantPhase α m ell) x) (phaseAngle α θ n)*
      analyticPhysicalFrame m α ell x r θ n=
    analyticPhysicalFrame m α ell x r θ (n+1)*
      (analyticRealTransfer m hm α (coupling r) ell x (θ+(n:ℝ)*α)).map Complex.ofReal :=by
  have hz : phaseCenter m hm (resonantPhase α m ell) x≠0 :=norm_ne_zero_iff.mp
    (by rw [phaseCenter_norm,resonantPhase_norm];norm_num)
  have hg : boundaryHoppingGauge r (2*Real.pi*(θ+(n:ℝ)*α))≠0 :=norm_ne_zero_iff.mp
    (by rw [boundaryHoppingGauge_norm hr hr1];norm_num)
  have h:=congrArg (fun M=>boundarySwap*M)
    (analyticLatticeFrame_conjugacy m hm α ell (by unfold coupling;positivity) hlam1 x hx (θ+(n:ℝ)*α))
  dsimp only at h
  rw [boundarySzego_physical_conjugacy hr hr1 hz] at h
  simp only [Matrix.smul_mul,Matrix.mul_smul,Matrix.mul_assoc] at h
  rw [← mul_assoc boundarySwap boundarySwap,boundarySwap_square,one_mul] at h
  have hh:=congrArg (fun M=>(boundaryHoppingGauge r (2*Real.pi*(θ+(n:ℝ)*α)))⁻¹ • M) h
  dsimp only at hh
  rw [smul_smul,inv_mul_cancel₀ hg,one_smul] at hh
  have hp : phaseAngle α θ n=2*Real.pi*(θ+(n:ℝ)*α) :=by unfold phaseAngle;ring
  have hnphase : θ+(n:ℝ)*α+α=θ+((n+1:ℤ):ℝ)*α :=by push_cast;ring
  rw [hnphase] at hh
  rw [hp]
  unfold analyticPhysicalFrame
  rw [Matrix.mul_smul,Matrix.smul_mul,seedOrbitScalar_succ hr hr1]
  rw [hh,smul_smul]
  simp only [Matrix.mul_assoc]
  congr 1
  ring

theorem analytic_physicalTransfer_entry_bound (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4)
    {r : ℝ} (hr : 0≤r) (hr1 : r<1) (hlam1 : coupling r<1)
    (hB : ∀θ i j,‖((analyticRealTransfer m hm α (coupling r) ell x θ).map Complex.ofReal) i j‖≤3)
    (θ : ℝ) (n : ℤ) (i j : Fin 2) :
    ‖uamoTransfer 1 r (phaseCenter m hm (resonantPhase α m ell) x) (phaseAngle α θ n) i j‖≤384 :=by
  have hz : phaseCenter m hm (resonantPhase α m ell) x≠0 :=norm_ne_zero_iff.mp
    (by rw [phaseCenter_norm,resonantPhase_norm];norm_num)
  have hS:=analytic_boundarySzego_bound m hm α ell (by unfold coupling;positivity) hlam1 x hx hB (θ+(n:ℝ)*α)
  simp only [boundarySzego_physical_conjugacy hr hr1 hz,Matrix.smul_apply,smul_eq_mul,
    norm_mul,boundaryHoppingGauge_norm hr hr1,one_mul] at hS
  have h:=analytic_swap_right_bound _ (analytic_swap_left_bound _ hS) i j
  have he (A:TransferMatrix) : boundarySwap*(boundarySwap*A*boundarySwap)*boundarySwap=A :=by
    simp only [Matrix.mul_assoc]
    rw [← Matrix.mul_assoc boundarySwap boundarySwap,boundarySwap_square,one_mul,mul_one]
  rw [he] at h
  have hp : phaseAngle α θ n=2*Real.pi*(θ+(n:ℝ)*α) :=by unfold phaseAngle;ring
  rw [hp]
  exact h

end UAMODraft.OddSeed

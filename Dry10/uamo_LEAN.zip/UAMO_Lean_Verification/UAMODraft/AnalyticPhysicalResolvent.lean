import UAMODraft.AnalyticRecurrence
noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix CMV PhysicalRepresentation Filter
open scoped Topology

theorem analytic_profile_physical_resolvent (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    (x : Variables m) (hx : profileBoundConstant m*‖x‖<1/4)
    {r : ℝ} (hr : 0≤r) (hr1 : r<1) (hlam1 : coupling r<1)
    {δ : ℝ} (hδ : 0<δ) (hδ1 : δ≤1)
    (hE : ∀θ i j,|liftSign ell*analyticRealTransfer m hm α (coupling r) ell x θ i j-
      (!![1+δ,0;0,1-δ]:StablePlane.PlaneMatrix) i j|≤δ/16) (θ : ℝ) :
    phaseCenter m hm (resonantPhase α m ell) x∉spectrum ℂ (PhysicalRepresentation.walk 1 (coupling r) α θ) :=by
  obtain ⟨herr,hB⟩ :=analytic_normal_coefficient_bounds m hm α (coupling r) ell x hδ hδ1 hE
  let A : ℤ→TransferMatrix :=fun n=>uamoTransfer 1 r
    (phaseCenter m hm (resonantPhase α m ell) x) (phaseAngle α θ n)
  let B : ℤ→TransferMatrix :=fun n=>(analyticRealTransfer m hm α (coupling r) ell x (θ+(n:ℝ)*α)).map Complex.ofReal
  have hA : ∀n i j,‖A n i j‖≤384 :=analytic_physicalTransfer_entry_bound m hm α ell x hx hr hr1 hlam1 hB θ
  have hBθ : ∀n i j,‖B n i j‖≤3 :=fun n=>hB (θ+(n:ℝ)*α)
  have huB : IsUnit (latticeDifference B 3 (by norm_num) hBθ) :=by
    exact near_signed_diagonal_lattice_recurrence_isUnit B (latticeMatrixMultiplier B 3 (by norm_num) hBθ)
      (by intro i j ψ n;rfl) (liftSign_abs ell) hδ hδ1 (fun n=>herr (θ+(n:ℝ)*α))
  have huA : IsUnit (latticeDifference A 384 (by norm_num) hA) :=
    (latticeDifference_isUnit_iff_frame A B
      (analyticPhysicalFrame m α ell x r θ) (analyticPhysicalFrameInverse m α ell x r θ)
      384 3 8 4 (by norm_num) (by norm_num) (by norm_num) (by norm_num) hA hBθ
      (analyticPhysicalFrame_entry_bound m hm α ell x hx hr hr1 θ)
      (analyticPhysicalFrameInverse_entry_bound m hm α ell x hx hr hr1 θ)
      (analyticPhysicalFrame_mul_inverse m hm α ell x hx hr hr1 θ)
      (analyticPhysicalFrame_conjugacy m hm α ell x hx hr hr1 hlam1 θ)).mpr huB
  have hz : phaseCenter m hm (resonantPhase α m ell) x≠0 :=norm_ne_zero_iff.mp
    (by rw [phaseCenter_norm,resonantPhase_norm];norm_num)
  have huD : IsUnit (physicalDifferenceOperator 1 r α θ
      (phaseCenter m hm (resonantPhase α m ell) x) (by norm_num) hr hr1 hz) :=by
    rw [physicalDifferenceOperator_eq_latticeDifference _ _ _ _ _ _ _ _ _ 384 (by norm_num) hA]
    exact huA
  have hs:=(physicalWalk_resolvent_iff_difference 1 r α θ
    (phaseCenter m hm (resonantPhase α m ell) x) (by norm_num) (by norm_num) hr hr1 hz).mpr huD
  have h1 : coupling 1=1 :=by norm_num [coupling]
  simpa only [h1] using hs

end UAMODraft.OddSeed

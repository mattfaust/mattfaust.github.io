import UAMODraft.AnalyticPhysicalFrame
import UAMO.NearDiagonalLatticeRecurrence

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix CMV PhysicalRepresentation

theorem unsigned_entry_error {s a d ε : ℝ} (hs : |s|=1)
    (h : |s*a-d|≤ε) : |a-s*d|≤ε := by
  have hs2 : s*s=1 := by nlinarith [sq_abs s]
  have he : a-s*d=s*(s*a-d) := by linear_combination -a*hs2
  rw [he,abs_mul,hs,one_mul]
  exact h

theorem scalarSignedDiagonal_ofReal (s δ : ℝ) (i j : Fin 2) :
    scalarSignedDiagonal s δ i j=
      ((s*(!![1+δ,0;0,1-δ] : StablePlane.PlaneMatrix) i j : ℝ):ℂ) := by
  fin_cases i <;> fin_cases j <;> simp [scalarSignedDiagonal]

theorem scalarSignedDiagonal_bound {s δ : ℝ} (hs : |s|=1)
    (hδ : 0<δ) (hδ1 : δ≤1) (i j : Fin 2) :
    ‖scalarSignedDiagonal s δ i j‖≤2 := by
  rw [scalarSignedDiagonal_ofReal,Complex.norm_real,Real.norm_eq_abs,abs_mul,hs,one_mul]
  fin_cases i <;> fin_cases j
  · change |1+δ|≤2
    rw [abs_of_pos (by linarith)]
    linarith
  · change |(0:ℝ)|≤2; norm_num
  · change |(0:ℝ)|≤2; norm_num
  · change |1-δ|≤2
    rw [abs_of_nonneg (by linarith)]
    linarith

theorem analytic_normal_coefficient_bounds (m : ℕ) (hm : 0<m) (α lam : ℝ) (ell : ℤ)
    (x : Variables m) {δ : ℝ} (hδ : 0<δ) (hδ1 : δ≤1)
    (hE : ∀θ i j,|liftSign ell*analyticRealTransfer m hm α lam ell x θ i j-
      (!![1+δ,0;0,1-δ]:StablePlane.PlaneMatrix) i j|≤δ/16) :
    (∀θ i j,‖((analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal) i j-
      scalarSignedDiagonal (liftSign ell) δ i j‖≤δ/16) ∧
    (∀θ i j,‖((analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal) i j‖≤3) :=by
  have herr (θ:ℝ) (i j:Fin 2) :
      ‖((analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal) i j-
        scalarSignedDiagonal (liftSign ell) δ i j‖≤δ/16 :=by
    rw [scalarSignedDiagonal_ofReal]
    change ‖((analyticRealTransfer m hm α lam ell x θ i j:ℝ):ℂ)-
      ((liftSign ell*(!![1+δ,0;0,1-δ]:StablePlane.PlaneMatrix) i j:ℝ):ℂ)‖≤δ/16
    rw [← Complex.ofReal_sub,Complex.norm_real,Real.norm_eq_abs]
    exact unsigned_entry_error (liftSign_abs ell) (hE θ i j)
  refine ⟨herr,?_⟩
  intro θ i j
  have hn:=norm_add_le
    (((analyticRealTransfer m hm α lam ell x θ).map Complex.ofReal) i j-
      scalarSignedDiagonal (liftSign ell) δ i j) (scalarSignedDiagonal (liftSign ell) δ i j)
  rw [sub_add_cancel] at hn
  have hd:=scalarSignedDiagonal_bound (liftSign_abs ell) hδ hδ1 i j
  have he:=herr θ i j
  linarith

end UAMODraft.OddSeed

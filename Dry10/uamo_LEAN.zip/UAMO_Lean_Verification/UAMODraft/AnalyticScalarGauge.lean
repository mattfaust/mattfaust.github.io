import UAMO.ScalarGaugeAnalytic

noncomputable section
namespace UAMODraft
open UAMO UAMO.ScalarGauge UAMO.Wronskian
open scoped BigOperators ComplexConjugate

theorem quotient_exponential_coefficients (α : ℝ) (c : ℤ → ℂ)
    {A s b D : ℝ} (hA : 0 ≤ A) (hD : 0 < D)
    (hc : ExponentialCoefficients c A s b)
    (hd : ∀ k : ℤ, k ≠ 0 → ‖(divisor α k)⁻¹‖ ≤ D * Real.exp (b*|(k:ℝ)|)) :
    ExponentialCoefficients (fun k => c k / divisor α k) (A*D) s (b/2) := by
  intro k
  change ‖c k / divisor α k‖ ≤ _
  by_cases hk : k=0
  · subst k
    simp only [divisor, mode_zero, sub_self, div_zero, norm_zero,
      Int.cast_zero, abs_zero, mul_zero, Real.exp_zero, mul_one]
    positivity
  · rw [div_eq_mul_inv, norm_mul]
    calc
      _ ≤ (A * Real.exp (-(2*Real.pi*s+2*b)*|(k:ℝ)|)) *
          (D * Real.exp (b*|(k:ℝ)|)) :=
        mul_le_mul (hc k) (hd k hk) (norm_nonneg _)
          (mul_nonneg hA (Real.exp_pos _).le)
      _ = (A*D) * (Real.exp (-(2*Real.pi*s+2*b)*|(k:ℝ)|) *
          Real.exp (b*|(k:ℝ)|)) := by ring
      _ = _ := by
        rw [← Real.exp_add]
        congr 2
        ring

theorem fullPotential_summable_of_subexponential (α : ℝ) (c : ℤ → ℂ)
    (hα : SubexponentialDivisors α) {A s b : ℝ}
    (hA : 0 ≤ A) (hb : 0 < b) (hc : ExponentialCoefficients c A s b)
    {z : ℂ} (hz : |z.im| ≤ s) :
    Summable (fun k : ℤ => (c k / divisor α k) * mode k z) := by
  obtain ⟨D,hD,hd⟩ := hα b hb
  exact fourierSeries_summable _ (mul_nonneg hA hD.le) (half_pos hb)
    (quotient_exponential_coefficients α c hA hD hc hd) hz

theorem fullPotential_differentiableOn_of_subexponential (α : ℝ) (c : ℤ → ℂ)
    (hα : SubexponentialDivisors α) {A s b : ℝ}
    (hA : 0 ≤ A) (hb : 0 < b) (hc : ExponentialCoefficients c A s b) :
    DifferentiableOn ℂ (fullPotential α c) (openStrip s) := by
  obtain ⟨D,hD,hd⟩ := hα b hb
  have hq := quotient_exponential_coefficients α c hA hD hc hd
  apply Complex.differentiableOn_tsum_of_summable_norm
    ((decay_summable (half_pos hb)).mul_left (A*D))
  · intro k
    exact ((differentiable_const _).mul (mode_differentiable k)).differentiableOn
  · exact isOpen_openStrip s
  · intro k z hz
    have h := weighted_mode_bound (fun k => c k / divisor α k)
      (mul_nonneg hA hD.le) hq (le_of_lt hz) k
    have hdle : decay b k ≤ decay (b/2) k := by
      unfold decay
      apply Real.exp_le_exp.mpr
      nlinarith [abs_nonneg (k:ℝ)]
    calc
      _ ≤ A*D*decay b k := by simpa only [show 2*(b/2)=b by ring] using h
      _ ≤ _ := mul_le_mul_of_nonneg_left hdle (mul_nonneg hA hD.le)

theorem fullPotential_periodic (α : ℝ) (c : ℤ → ℂ) (z : ℂ) :
    fullPotential α c (z+1)=fullPotential α c z := by
  apply tsum_congr
  intro k
  rw [mode_periodic]

theorem fullPotential_translation (α : ℝ) (hirr : Irrational α) (c : ℤ → ℂ)
    (hα : SubexponentialDivisors α) {A s b : ℝ}
    (hA : 0 ≤ A) (hb : 0 < b) (hc : ExponentialCoefficients c A s b)
    (hc0 : c 0=0) {z : ℂ} (hz : |z.im|≤s) :
    fullPotential α c (z+α)-fullPotential α c z=fourierSeries c z := by
  have hz' : |(z+(α:ℂ)).im| ≤ s := by simpa using hz
  have hs₁ := fullPotential_summable_of_subexponential α c hα hA hb hc hz'
  have hs₂ := fullPotential_summable_of_subexponential α c hα hA hb hc hz
  change (∑' k : ℤ, (c k/divisor α k)*mode k (z+α)) -
      (∑' k : ℤ, (c k/divisor α k)*mode k z) = _
  rw [← hs₁.tsum_sub hs₂]
  apply tsum_congr
  intro k
  by_cases hk : k=0
  · simp [hk,hc0]
  · rw [mode_add]
    have hd := divisor_ne_zero hirr hk
    unfold divisor at hd ⊢
    field_simp
    ring

theorem fullPotential_conj (α : ℝ) (c : ℤ → ℂ)
    (hc : ∀ k, c (-k)=conj (c k)) (x : ℝ) :
    conj (fullPotential α c (x:ℂ)) = fullPotential α c (x:ℂ) := by
  unfold fullPotential fourierSeries
  rw [Complex.conj_tsum]
  simp_rw [map_mul, map_div₀, ← hc, ← divisor_neg, ← mode_neg_real]
  exact (Equiv.neg ℤ).tsum_eq (fun k : ℤ => (c k / divisor α k)*mode k (x:ℂ))

theorem fullPotential_im_zero (α : ℝ) (c : ℤ → ℂ)
    (hc : ∀ k, c (-k)=conj (c k)) (x : ℝ) :
    (fullPotential α c (x:ℂ)).im=0 := by
  have h := congrArg Complex.im (fullPotential_conj α c hc x)
  simp only [Complex.conj_im] at h
  linarith

def fullExponentialGauge (α : ℝ) (c : ℤ → ℂ) (z : ℂ) : ℂ :=
  Complex.exp (Complex.I*fullPotential α c z)

theorem fullExponentialGauge_ne_zero (α : ℝ) (c : ℤ → ℂ) (z : ℂ) :
    fullExponentialGauge α c z ≠ 0 := Complex.exp_ne_zero _

theorem fullExponentialGauge_norm_real (α : ℝ) (c : ℤ → ℂ)
    (hc : ∀ k, c (-k)=conj (c k)) (x : ℝ) :
    ‖fullExponentialGauge α c (x:ℂ)‖=1 := by
  rw [fullExponentialGauge,Complex.norm_exp]
  simp [Complex.mul_re,fullPotential_im_zero α c hc x]

theorem fullExponentialGauge_differentiableOn (α : ℝ) (c : ℤ → ℂ)
    (hα : SubexponentialDivisors α) {A s b : ℝ}
    (hA : 0 ≤ A) (hb : 0 < b) (hc : ExponentialCoefficients c A s b) :
    DifferentiableOn ℂ (fullExponentialGauge α c) (openStrip s) := by
  exact Complex.differentiable_exp.comp_differentiableOn
    ((differentiableOn_const Complex.I).mul (fullPotential_differentiableOn_of_subexponential α c hα hA hb hc))

theorem fullExponentialGauge_correction (α : ℝ) (hirr : Irrational α) (c : ℤ → ℂ)
    (hα : SubexponentialDivisors α) {A s b : ℝ}
    (hA : 0 ≤ A) (hb : 0 < b) (hc : ExponentialCoefficients c A s b)
    (hc0 : c 0=0) {z : ℂ} (hz : |z.im|≤s) :
    (Complex.I*Complex.exp (Complex.I*fourierSeries c z))*fullExponentialGauge α c z /
      fullExponentialGauge α c (z+α)=Complex.I := by
  have he := fullPotential_translation α hirr c hα hA hb hc hc0 hz
  simp only [fullExponentialGauge,div_eq_mul_inv,← Complex.exp_neg]
  rw [mul_assoc,← Complex.exp_add,mul_assoc,← Complex.exp_add]
  have hzexp : Complex.I*fourierSeries c z+Complex.I*fullPotential α c z+
      -(Complex.I*fullPotential α c (z+α)) = 0 := by
    linear_combination -Complex.I*he
  rw [← add_assoc,hzexp,Complex.exp_zero,mul_one]

end UAMODraft

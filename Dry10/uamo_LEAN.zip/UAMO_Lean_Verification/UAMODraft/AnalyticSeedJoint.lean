import UAMODraft.PositiveConjugacy
import UAMODraft.PhysicalContinuity
import UAMODraft.AngleContinuity
import UAMODraft.AnalyticPhysicalResolvent
noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed UAMO.StablePlane UAMO.ProjectiveAngle Matrix Filter
open scoped Topology

def HasActualSeedRotation (m : ℕ) (hm : 0<m) (α lam : ℝ) (ell : ℤ) (x : Variables m) : Prop :=
  ∃ F : ℝ→ℝ→ℝ,
    Continuous (fun p:ℝ×ℝ=>F p.1 p.2) ∧
    (∀s,Function.Periodic (fun θ=>F θ s) 1) ∧
    (∀θ s,∃c:ℝ,0<c ∧ angleVector (F θ s)=c •
      (boundaryRealTransfer lam (phaseCenter m hm (resonantPhase α m ell) x) θ*ᵥangleVector s)) ∧
    (∀θ,StrictMono (F θ)) ∧
    (∀θ s,F θ (s+Real.pi)=F θ s+Real.pi) ∧
    (∀θ s,Tendsto (fun n:ℕ=>(angleIterate F α θ s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 ((m:ℝ)*α/2+(1-liftSign ell)/4)))

theorem analytic_profile_rotation (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    {lam : ℝ} (hlam : 0<lam) (hlam1 : lam<1) (x : Variables m)
    (hxsmall : profileBoundConstant m*‖x‖<1/4)
    {δ : ℝ} (hsep : 0<δ) (hsep1 : δ≤1)
    (hentries : ∀θ i j,|liftSign ell*analyticRealTransfer m hm α lam ell x θ i j-
      (!![1+δ,0;0,1-δ]:PlaneMatrix) i j|≤δ/16) :
    HasActualSeedRotation m hm α lam ell x :=by
  have hpos:=analyticProfile_signature_positive m hm x hxsmall
  have hdet (θ:ℝ) : (analyticRealTransfer m hm α lam ell x θ).det=1 :=
    seedRealConjugate_det _ _ (analyticTransformed_SU11 m hm (resonantPhase_norm α m ell)
      α hlam.le hlam1 x θ (hpos θ) (hpos (θ+α)))
  let γ:=diagonalizingAngle α m ell+Real.pi/4
  let A:=boundaryRealTransfer lam (phaseCenter m hm (resonantPhase α m ell) x)
  let B:=realAnalyticFrame m x γ
  let b:=realAnalyticFrameAngle m x γ
  let C:=positiveAnalyticTransfer m hm α lam ell x
  obtain ⟨hBc,hbc,hBd,hBa,hbw,hcol⟩ :=analytic_frame_degree_data m hm x hxsmall γ
  have hCc : Continuous C :=
    (continuous_const.mul (continuous_const.smul
      (continuous_analyticRealTransfer m hm α ell hlam.le hlam1 x hxsmall))).mul continuous_const
  have hCp : Function.Periodic C 1 :=by
    intro θ
    simp only [C,positiveAnalyticTransfer,analyticRealTransfer_periodic m hm α lam ell x θ]
  have hCd (θ:ℝ) : (C θ).det=1 :=positiveAnalyticTransfer_det m hm α lam ell x θ (hdet θ)
  have hCpos (θ:ℝ) (i j:Fin 2) : 0<C θ i j :=by
    apply strict_diagonal_to_positive _ hsep hsep1
    intro a b
    simpa only [Matrix.smul_apply,smul_eq_mul] using hentries θ a b
  have hQ : UAMODraft.PositiveAngle.quadrantReflection 1=(1:PlaneMatrix) :=by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [UAMODraft.PositiveAngle.quadrantReflection]
  have hconj (θ:ℝ) : C θ=UAMODraft.PositiveAngle.quadrantReflection 1*
      (liftSign ell • ((B (θ+α))⁻¹*A θ*B θ))*UAMODraft.PositiveAngle.quadrantReflection 1 :=by
    rw [hQ,one_mul,mul_one]
    exact positiveAnalyticTransfer_conjugacy m hm α ell hlam.le hlam1 x θ
      (hpos θ) (hpos (θ+α))
  simpa only [Int.cast_natCast] using UAMODraft.PositiveAngle.opening_rotation_full A B C b α
    (e:=1) (by norm_num) (liftSign_abs ell) hBc hbc hCc hCp hCd hCpos hBd hcol (m:ℤ)
    (by simpa only [Int.cast_natCast] using hbw)
    (by simpa only [zpow_natCast] using hBa) hconj

theorem analytic_odd_seed_joint {α : ℝ} (hα : Irrational α)
    (m : ℕ) (hm : Odd m) (ell : ℤ) :
    ∃ x : ℝ→Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      ∃ ε : ℝ,0<ε ∧ ∀ r : ℝ,0<r → r<ε → r<1 ∧
        (∀θ : ℝ,phaseCenter m (by obtain ⟨j,hj⟩ :=hm;omega)
          (resonantPhase α m ell) (x (coupling r))∉
          spectrum ℂ (PhysicalRepresentation.walk 1 (coupling r) α θ)) ∧
        HasActualSeedRotation m (by obtain ⟨j,hj⟩ :=hm;omega) α (coupling r) ell (x (coupling r)) :=by
  have hm0 : 0<m :=by obtain ⟨j,hj⟩ :=hm;omega
  obtain ⟨x,hx0,hxa,_,ε,hε,hform⟩ :=analytic_odd_seed_strict_normal_form hα m hm ell
  obtain ⟨δ,hδ,hsmall⟩ :=Metric.eventually_nhds_iff.mp (branch_uniform_frame_small x hx0 hxa)
  refine ⟨x,hx0,hxa,min (ε/2) (min (δ/2) (1/2)),by positivity,?_⟩
  intro r hr hsmallr
  obtain ⟨hre,hrsmall⟩ :=lt_min_iff.mp hsmallr
  obtain ⟨hrd,hrhalf⟩ :=lt_min_iff.mp hrsmall
  have hr1 : r<1 :=by linarith
  have hc : coupling r≤2*r :=by
    rw [coupling,div_le_iff₀ (show 0<1+r^2 by positivity)]
    nlinarith [sq_nonneg r]
  have hce : coupling r<ε :=by linarith
  have hcd : coupling r<δ :=by linarith
  have hcp : 0<coupling r :=coupling_pos hr
  have hxsmall : profileBoundConstant m*‖x (coupling r)‖<1/4 :=hsmall
    (by simpa only [Real.dist_eq,sub_zero,abs_of_pos hcp] using hcd)
  obtain ⟨hlam1,hsep,hsep1,_,_,hentries⟩ :=hform (coupling r) hcp hce
  exact ⟨hr1,analytic_profile_physical_resolvent m hm0 α ell (x (coupling r)) hxsmall
    hr.le hr1 hlam1 hsep hsep1 hentries,
    analytic_profile_rotation m hm0 α ell hcp hlam1 (x (coupling r)) hxsmall hsep hsep1 hentries⟩

end UAMODraft.OddSeed

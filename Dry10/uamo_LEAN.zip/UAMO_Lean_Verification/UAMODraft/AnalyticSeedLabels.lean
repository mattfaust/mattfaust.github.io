import UAMODraft.BoundaryGenuineLabel
import UAMODraft.AnalyticSeedJoint

noncomputable section
namespace UAMODraft.SeedLabel
open UAMO UAMO.BoundarySeed UAMODraft.OddSeed
open scoped Topology

theorem analytic_profile_has_physical_labels {r α:ℝ}
    (hr:0≤r) (hr1:r<1) (hα:Irrational α)
    (m : ℕ) (hm : 0 < m) (ell : ℤ) (x : Variables m)
    (hrot:HasActualSeedRotation m hm α (coupling r) ell x) :
    HasPhysicalRotationLabel 1 (coupling r)
      (phaseCenter m hm (resonantPhase α m ell) x).arg α (uamoGapLabel α (m:ℤ) ell) ∧
    uamoGapLabel α (m:ℤ) ell=
      ((CircleDOS.arcLabel (PhysicalDOS.physicalUnitaryDOS 1 r α (by norm_num) (by norm_num) hr hr1.le)
        (phaseCenter m hm (resonantPhase α m ell) x):ℝ):AddCircle (1:ℝ)) :=by
  obtain ⟨F,hF,_,hdir,_,_,hmean⟩:=hrot
  have hz:‖phaseCenter m hm (resonantPhase α m ell) x‖=1 :=by
    rw [phaseCenter_norm,resonantPhase_norm]
  exact boundary_seed_genuine_lift_has_labels hr hr1 hα hz m ell F hF hdir hmean

theorem analytic_odd_seed_with_physical_labels {α:ℝ} (hα:Irrational α)
    (m:ℕ) (hm:Odd m) (ell:ℤ) :
    ∃x:ℝ→Variables m,x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      ∃ ε : ℝ, 0 < ε ∧ ∀ (r : ℝ) (hr : 0 < r), r < ε → ∃ hr1 : r < 1,
        (∀θ:ℝ,phaseCenter m (by obtain ⟨j,hj⟩:=hm;omega)
          (resonantPhase α m ell) (x (coupling r))∉
          spectrum ℂ (PhysicalRepresentation.walk 1 (coupling r) α θ)) ∧
        HasPhysicalRotationLabel 1 (coupling r)
          (phaseCenter m (by obtain ⟨j,hj⟩:=hm;omega)
            (resonantPhase α m ell) (x (coupling r))).arg α (uamoGapLabel α (m:ℤ) ell) ∧
        uamoGapLabel α (m:ℤ) ell=
          ((CircleDOS.arcLabel (PhysicalDOS.physicalUnitaryDOS 1 r α (by norm_num) (by norm_num)
            hr.le hr1.le)
            (phaseCenter m (by obtain ⟨j,hj⟩:=hm;omega)
              (resonantPhase α m ell) (x (coupling r))):ℝ):AddCircle (1:ℝ)) :=by
  obtain ⟨x,hx0,hxa,ε,hε,hjoint⟩:=analytic_odd_seed_joint hα m hm ell
  refine ⟨x,hx0,hxa,ε,hε,fun r hr hre=>?_⟩
  obtain ⟨hr1,hres,hrot⟩:=hjoint r hr hre
  have hlabels:=analytic_profile_has_physical_labels hr.le hr1 hα m
    (by obtain ⟨j,hj⟩:=hm;omega) ell (x (coupling r)) hrot
  exact ⟨hr1,hres,hlabels⟩

end UAMODraft.SeedLabel

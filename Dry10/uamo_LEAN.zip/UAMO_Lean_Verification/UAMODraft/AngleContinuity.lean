import UAMODraft.OpeningRotation

noncomputable section
namespace UAMODraft.PositiveAngle
open Matrix UAMO.StablePlane UAMO.ProjectiveAngle
open Set Filter
open scoped Topology

variable {X:Type*} [TopologicalSpace X]

theorem continuous_angleLift_family (M:X→PlaneMatrix) (s:X→ℝ)
    (hM:Continuous M) (hs:Continuous s) (ht:∀x,0<M x 0 0+M x 1 1) :
    Continuous (fun x => angleLift (M x) (s x)) := by
  have hP : Continuous (fun x => polarForm (M x)) := by
    unfold polarForm
    fun_prop
  have ha : Continuous (fun x => polarAngle (M x)) := by
    unfold polarAngle
    apply Real.continuous_arctan.comp
    apply Continuous.div
    · fun_prop
    · fun_prop
    · exact fun x => (ht x).ne'
  exact ha.add (continuous_positiveAngleLift _ s hP hs
    (fun x => (polarForm_radial_pos (M x) (s x)).ne'))

theorem continuous_frameLift_family (B:X→PlaneMatrix) (b s:X→ℝ)
    (hB:Continuous B) (hb:Continuous b) (hs:Continuous s)
    (hd:∀x,(B x).det=1)
    (hc:∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x)) :
    Continuous (fun x => frameLift (B x) (b x) (s x)) := by
  have hrot : Continuous (fun x => rotatedFrame (B x) (b x)) := by
    unfold rotatedFrame
    apply Continuous.mul _ hB
    apply continuous_matrix
    intro i j
    fin_cases i <;> fin_cases j <;> simp [rotationFactor] <;> fun_prop
  have ht (x:X) : 0<rotatedFrame (B x) (b x) 0 0+rotatedFrame (B x) (b x) 1 1 := by
    obtain ⟨r,hr,hc⟩ := hc x
    exact rotatedFrame_trace_pos (hd x) hr hc
  exact hb.add (continuous_angleLift_family _ s hrot hs ht)

theorem continuous_orderIso_inverse (G:X→ℝ≃oℝ)
    (hG:Continuous (fun p:X×ℝ => G p.1 p.2)) :
    Continuous (fun p:X×ℝ => (G p.1).symm p.2) := by
  apply continuous_iff_continuousAt.mpr
  intro p
  apply tendsto_order.mpr
  constructor
  · intro a ha
    have hGa : Continuous (fun q:X×ℝ => G q.1 a) := hG.comp (continuous_fst.prodMk continuous_const)
    have hh := hGa.continuousAt.eventually_lt continuous_snd.continuousAt ((G p.1).lt_symm_apply.mp ha)
    filter_upwards [hh] with q hq
    exact (G q.1).lt_symm_apply.mpr hq
  · intro a ha
    have hGa : Continuous (fun q:X×ℝ => G q.1 a) := hG.comp (continuous_fst.prodMk continuous_const)
    have hh := continuous_snd.continuousAt.eventually_lt hGa.continuousAt ((G p.1).symm_apply_lt.mp ha)
    filter_upwards [hh] with q hq
    exact (G q.1).symm_apply_lt.mpr hq

theorem continuous_conjugatedLift (G:ℝ→ℝ≃oℝ) (F:ℝ→ℝ→ℝ)
    (hG:Continuous (fun p:ℝ×ℝ => G p.1 p.2))
    (hF:Continuous (fun p:ℝ×ℝ => F p.1 p.2)) (α:ℝ) (k:ℤ) :
    Continuous (fun p:ℝ×ℝ => conjugatedLift G F α k p.1 p.2) := by
  have hi := continuous_orderIso_inverse G hG
  have hf := hF.comp (continuous_fst.prodMk hi)
  exact (hG.comp ((continuous_fst.add continuous_const).prodMk hf)).add continuous_const

theorem opening_rotation_continuous_action (B C:ℝ→PlaneMatrix) (b:ℝ→ℝ)
    (hB:Continuous B) (hb:Continuous b) (hC:Continuous C)
    (hd:∀x,(B x).det=1)
    (hc:∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (hp:∀x i j,0<C x i j) (α e σ:ℝ) :
    Continuous (fun p:ℝ×ℝ =>
      conjugatedLift (fun x => frameOrderIso (B x) (b x) (hd x) (hc x))
        (reflectedLift e (fun x => angleLift (C x))) α (signIndex σ) p.1 p.2) := by
  have hG : Continuous (fun p:ℝ×ℝ => frameLift (B p.1) (b p.1) p.2) :=
    continuous_frameLift_family _ _ _ (hB.comp continuous_fst) (hb.comp continuous_fst)
      continuous_snd (fun p => hd p.1) (fun p => hc p.1)
  apply continuous_conjugatedLift _ _ hG _ α (signIndex σ)
  apply continuous_const.mul
  exact continuous_angleLift_family (fun p:ℝ×ℝ => C p.1) (fun p:ℝ×ℝ => e*p.2)
    (hC.comp continuous_fst) (by fun_prop)
    (fun p => add_pos (hp p.1 0 0) (hp p.1 1 1))

theorem opening_rotation_full (A B C:ℝ→PlaneMatrix) (b:ℝ→ℝ) (α:ℝ)
    {e σ:ℝ} (he:|e|=1) (hσ:|σ|=1)
    (hBcont:Continuous B) (hb:Continuous b) (hCcont:Continuous C)
    (hCper:Function.Periodic C 1)
    (hCdet:∀x,(C x).det=1) (hp:∀x i j,0<C x i j)
    (hB:∀x,(B x).det=1)
    (hcol:∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (m:ℤ) (hwind:∀x,b (x+1)=b x+(m:ℝ)*Real.pi)
    (hanti:∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hC:∀x,C x=quadrantReflection e*(σ • ((B (x+α))⁻¹*A x*B x))*quadrantReflection e) :
    ∃F:ℝ→ℝ→ℝ,
      Continuous (fun p:ℝ×ℝ => F p.1 p.2) ∧
      (∀s,Function.Periodic (fun x => F x s) 1) ∧
      (∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c • (A x*ᵥangleVector s)) ∧
      (∀x,StrictMono (F x)) ∧
      (∀x s,F x (s+Real.pi)=F x s+Real.pi) ∧
      (∀x s,Tendsto (fun n:ℕ => (angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
        atTop (𝓝 ((m:ℝ)*α/2+(1-σ)/4))) := by
  let G := fun x => frameOrderIso (B x) (b x) (hB x) (hcol x)
  let F := reflectedLift e (fun x => angleLift (C x))
  have hG : ∀x s,G x (s+Real.pi)=G x s+Real.pi := fun x s => frameLift_add_pi (B x) (b x) s
  have hF : ∀x s,F x (s+Real.pi)=F x s+Real.pi :=
    reflectedLift_add_pi he _ (fun x s => angleLift_add_pi (C x) s)
  refine ⟨conjugatedLift G F α (signIndex σ),?_,?_,?_,?_,?_,?_⟩
  · exact opening_rotation_continuous_action B C b hBcont hb hCcont hB hcol hp α e σ
  · exact opening_rotation_periodic_action B C b α e σ he m hB hcol hwind hanti hCper
  · intro x s
    have hd := conjugatedLift_direction_of_direction (fun x => reflectedMatrix e (C x)) B b F
      (reflectedLift_direction he C hCdet hp) hB hcol α (signIndex σ) x s
    rw [signed_quadrant_conjugacy_recover A B C α he hσ hB hC x] at hd
    exact hd
  · exact conjugatedLift_strictMono G F
      (reflectedLift_strictMono he _ (fun x =>
        angleLift_strictMono (hCdet x) (add_pos (hp x 0 0) (hp x 1 1)))) α (signIndex σ)
  · exact conjugatedLift_add_pi G F α (signIndex σ) hG hF
  · intro x s
    have ht := reflected_conjugated_rotation he C B b hCdet hp hB hcol hb m (signIndex σ) hwind α x s
    rw [signIndex_limit hσ] at ht
    exact ht

end UAMODraft.PositiveAngle

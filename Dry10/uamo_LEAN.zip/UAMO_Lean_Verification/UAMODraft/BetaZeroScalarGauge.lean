import UAMODraft.ContinuedFractionDivisors
import UAMODraft.AnalyticScalarGauge

noncomputable section
namespace UAMODraft.BetaZeroScalarGauge
open UAMO.ScalarGauge UAMODraft.ContinuedFractionDivisors
open scoped ComplexConjugate

theorem beta_zero_scalar_gauge (α : ℝ) (hα : Irrational α) (hβ : beta α=0)
    (c : ℤ→ℂ) {A s b : ℝ} (hA : 0≤A) (hb : 0<b)
    (hc : ExponentialCoefficients c A s b) (hc0 : c 0=0)
    (hconj : ∀ k,c (-k)=conj (c k)) :
    DifferentiableOn ℂ (fullPotential α c) (openStrip s) ∧
    (∀ z:ℂ,fullPotential α c (z+1)=fullPotential α c z) ∧
    (∀ x:ℝ,(fullPotential α c (x:ℂ)).im=0) ∧
    (∀ z:ℂ,|z.im|≤s→fullPotential α c (z+α)-fullPotential α c z=fourierSeries c z) ∧
    DifferentiableOn ℂ (UAMODraft.fullExponentialGauge α c) (openStrip s) ∧
    (∀ z:ℂ,UAMODraft.fullExponentialGauge α c z≠0) ∧
    (∀ x:ℝ,‖UAMODraft.fullExponentialGauge α c (x:ℂ)‖=1) ∧
    (∀ z:ℂ,|z.im|≤s→
      (Complex.I*Complex.exp (Complex.I*fourierSeries c z))*UAMODraft.fullExponentialGauge α c z /
        UAMODraft.fullExponentialGauge α c (z+α)=Complex.I) := by
  have hd := subexponentialDivisors_of_beta_zero α hα hβ
  refine ⟨UAMODraft.fullPotential_differentiableOn_of_subexponential α c hd hA hb hc,
    UAMODraft.fullPotential_periodic α c,UAMODraft.fullPotential_im_zero α c hconj,
    ?_,UAMODraft.fullExponentialGauge_differentiableOn α c hd hA hb hc,
    UAMODraft.fullExponentialGauge_ne_zero α c,
    UAMODraft.fullExponentialGauge_norm_real α c hconj,?_⟩
  · intro z hz
    exact UAMODraft.fullPotential_translation α hα c hd hA hb hc hc0 hz
  · intro z hz
    exact UAMODraft.fullExponentialGauge_correction α hα c hd hA hb hc hc0 hz

end UAMODraft.BetaZeroScalarGauge

import UAMODraft.BoundaryOddPersistence
import UAMO.PhysicalBoundaryParity

noncomputable section
namespace UAMODraft.BoundaryAssembly
open UAMO Set

theorem boundary_gap_iff_odd_by_height {a r α:ℝ}
    (ha:0<a) (ha1:a≤1) (hr:0<r) (hr1:r≤1)
    (hboundary:a=1 ∨ r=1) (hα:Irrational α) (m ell:ℤ) :
    OpenDOSGapLabel a r α ha.le ha1 hr.le hr1 (uamoGapLabel α m ell) ↔ Odd m :=by
  constructor
  · intro hgap
    by_contra hn
    exact physical_closed_boundary_not_open_even_DOS_gap ha.le ha1 hr.le hr1
      hboundary hα m ell (Int.not_odd_iff_even.mp hn) hgap
  · exact closed_boundary_odd_gap_by_height ha ha1 hr hr1 hboundary hα m ell

end UAMODraft.BoundaryAssembly

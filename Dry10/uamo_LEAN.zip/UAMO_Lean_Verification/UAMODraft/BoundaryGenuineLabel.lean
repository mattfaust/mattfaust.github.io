import UAMODraft.BoundaryRealIdentification
import UAMODraft.PhysicalLiftLabel
import UAMODraft.SeedLabelParity

noncomputable section
namespace UAMODraft.SeedLabel
open UAMO UAMO.BoundarySeed UAMO.StablePlane UAMO.ProjectiveAngle Matrix Filter
open UAMODraft.OddSeed
open scoped Topology

theorem boundary_genuine_lift_has_rotation_label {lam:ℝ}
    (hlam:0≤lam) (hlam1:lam<1) {z:ℂ} (hz:‖z‖=1)
    (α ρ:ℝ) (F:ℝ→ℝ→ℝ)
    (hF:Continuous (fun p:ℝ×ℝ=>F p.1 p.2))
    (hdir:∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c •
      (boundaryRealTransfer lam z x*ᵥangleVector s))
    (hmean:∀x s,Tendsto (fun n:ℕ=>(angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 ρ)) : HasPhysicalRotationLabel 1 lam z.arg α (ρ:AddCircle (1:ℝ)) :=by
  apply physicalRotationLabel_of_genuine_lift (by norm_num) hlam hlam1 z.arg α ρ F hF _ hmean
  intro x s
  simpa only [boundaryRealTransfer_arg lam hz x] using hdir x s

theorem boundary_genuine_lift_has_DOS_label {r α:ℝ}
    (hr:0≤r) (hr1:r<1) (hα:Irrational α) {z:ℂ} (hz:‖z‖=1)
    (ρ:ℝ) (F:ℝ→ℝ→ℝ)
    (hF:Continuous (fun p:ℝ×ℝ=>F p.1 p.2))
    (hdir:∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c •
      (boundaryRealTransfer (coupling r) z x*ᵥangleVector s))
    (hmean:∀x s,Tendsto (fun n:ℕ=>(angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 ρ)) :
    (ρ:AddCircle (1:ℝ))=
      ((CircleDOS.arcLabel (PhysicalDOS.physicalUnitaryDOS 1 r α (by norm_num) (by norm_num) hr hr1.le)
        z:ℝ):AddCircle (1:ℝ)) :=by
  have hLam:0≤coupling r :=by unfold coupling;positivity
  have hrot:=boundary_genuine_lift_has_rotation_label hLam (CMV.coupling_lt_one_of_lt_one hr1)
    hz α ρ F hF hdir hmean
  exact physicalRotationLabel_unique hrot
    (physicalRotationLabel_DOS_arg (by norm_num) (by norm_num) hr hr1 α hα hz)

theorem boundary_seed_genuine_lift_has_labels {r α:ℝ}
    (hr:0≤r) (hr1:r<1) (hα:Irrational α) {z:ℂ} (hz:‖z‖=1)
    (m:ℕ) (ell:ℤ) (F:ℝ→ℝ→ℝ)
    (hF:Continuous (fun p:ℝ×ℝ=>F p.1 p.2))
    (hdir:∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c •
      (boundaryRealTransfer (coupling r) z x*ᵥangleVector s))
    (hmean:∀x s,Tendsto (fun n:ℕ=>(angleIterate F α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 ((m:ℝ)*α/2+(1-liftSign ell)/4))) :
    HasPhysicalRotationLabel 1 (coupling r) z.arg α (uamoGapLabel α (m:ℤ) ell) ∧
      uamoGapLabel α (m:ℤ) ell=
        ((CircleDOS.arcLabel (PhysicalDOS.physicalUnitaryDOS 1 r α (by norm_num) (by norm_num) hr hr1.le)
          z:ℝ):AddCircle (1:ℝ)) :=by
  have hLam:0≤coupling r :=by unfold coupling;positivity
  constructor
  · have h:=boundary_genuine_lift_has_rotation_label hLam (CMV.coupling_lt_one_of_lt_one hr1)
      hz α _ F hF hdir hmean
    simpa only [seed_sign_rotation_label] using h
  · have h:=boundary_genuine_lift_has_DOS_label hr hr1 hα hz _ F hF hdir hmean
    simpa only [seed_sign_rotation_label] using h
end UAMODraft.SeedLabel

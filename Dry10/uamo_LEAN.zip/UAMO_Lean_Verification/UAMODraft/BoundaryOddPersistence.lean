import UAMODraft.DraftGapContinuation
import UAMODraft.AllOddBoundarySeeds

noncomputable section
namespace UAMODraft.BoundaryAssembly
open UAMO UAMODraft.OddSeed Set

theorem first_boundary_odd_gap_by_height {α:ℝ} (hα:Irrational α)
    (r:ℝ) (hr:0<r) (hr1:r≤1) (m ell:ℤ) (hm:Odd m) :
    OpenDOSGapLabel 1 r α (by norm_num) (by norm_num) hr.le hr1
      (uamoGapLabel α m ell) :=by
  obtain ⟨ε,hε,_hε1,hseed⟩:=all_odd_boundary_seed_gaps hα m hm
  let r₀:=min (r/2) (ε/2)
  have hr₀:0<r₀:=lt_min (half_pos hr) (half_pos hε)
  have hr₀r:r₀<r :=(min_le_left _ _).trans_lt (by linarith)
  have hr₀ε:r₀<ε :=(min_le_right _ _).trans_lt (by linarith)
  obtain ⟨hr₀1,hboth⟩:=hseed r₀ hr₀ hr₀ε
  have hm0:m≠0 :=by intro hh;subst m;simp at hm
  exact physical_gap_persists_by_height (by norm_num) (by norm_num)
    hα hr₀ hr₀1 hr₀r.le hr1 m ell hm0 (hboth ell).1

theorem second_boundary_odd_gap_by_height {α:ℝ} (hα:Irrational α)
    (r:ℝ) (hr:0<r) (hr1:r≤1) (m ell:ℤ) (hm:Odd m) :
    OpenDOSGapLabel r 1 α hr.le hr1 (by norm_num) (by norm_num)
      (uamoGapLabel α m ell) :=by
  exact openDOSGapLabel_other_edge hr.le hr1 hα m ell
    (first_boundary_odd_gap_by_height hα.neg r hr hr1 m ell hm)

theorem closed_boundary_odd_gap_by_height {a r α:ℝ}
    (ha:0<a) (ha1:a≤1) (hr:0<r) (hr1:r≤1)
    (hboundary:a=1 ∨ r=1) (hα:Irrational α) (m ell:ℤ) (hm:Odd m) :
    OpenDOSGapLabel a r α ha.le ha1 hr.le hr1 (uamoGapLabel α m ell) :=by
  rcases hboundary with rfl|rfl
  · exact first_boundary_odd_gap_by_height hα r hr hr1 m ell hm
  · exact second_boundary_odd_gap_by_height hα a ha ha1 m ell hm

end UAMODraft.BoundaryAssembly

import UAMODraft.RealConjugacy
import UAMO.RealTransferAngleLift

noncomputable section
namespace UAMODraft.SeedLabel
open UAMO UAMO.BoundarySeed UAMO.StablePlane Matrix UAMODraft.OddSeed

theorem boundaryRealTransfer_exp (lam t θ:ℝ) :
    boundaryRealTransfer lam (Complex.exp ((t:ℂ)*Complex.I)) θ=
      realTransfer 1 lam t (2*Real.pi*θ) :=by
  have hz:‖Complex.exp ((t:ℂ)*Complex.I)‖=1 :=Complex.norm_exp_ofReal_mul_I t
  unfold boundaryRealTransfer boundarySzego
  rw [boundaryNumerator_conjugateMatrix lam hz θ,Matrix.mul_smul,Matrix.smul_mul]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [seedCayleyInverse,seedCayley,conjugateMatrix,realTransfer,realTransferNumerator,
      Matrix.mul_apply,Fin.sum_univ_two,Matrix.map_apply,Matrix.smul_apply,smul_eq_mul,
      Complex.star_def,Complex.exp_re,Complex.exp_im,←Complex.ofReal_inv]
  all_goals simp only [←Complex.ofReal_mul,←Complex.ofReal_ofNat,←Complex.ofReal_sin,
    Complex.ofReal_re,Complex.ofReal_im]
  all_goals ring_nf
  all_goals simp

theorem boundaryRealTransfer_arg (lam:ℝ) {z:ℂ} (hz:‖z‖=1) (θ:ℝ) :
    boundaryRealTransfer lam z θ=realTransfer 1 lam z.arg (2*Real.pi*θ) :=by
  have he:Complex.exp ((z.arg:ℂ)*Complex.I)=z :=by
    simpa only [hz,Complex.ofReal_one,one_mul] using Complex.norm_mul_exp_arg_mul_I z
  calc
    _=boundaryRealTransfer lam (Complex.exp ((z.arg:ℂ)*Complex.I)) θ :=by rw [he]
    _=_ :=boundaryRealTransfer_exp lam z.arg θ

end UAMODraft.SeedLabel

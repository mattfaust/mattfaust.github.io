import UAMODraft.CoverProducts

noncomputable section
namespace UAMODraft.CoverHyperbolicity
open UAMODraft.PositiveCone Matrix Filter
open scoped Topology

theorem expanding_part_zero_of_bounded (M:ℕ→Mat) (u s:Vec) {C ρ:ℝ}
    (hC:0<C) (hρ:1<ρ)
    (hu:∀n,C⁻¹*ρ^n*‖u‖≤‖M n*ᵥu‖)
    (hs:∀n,‖M n*ᵥs‖≤C*(ρ⁻¹)^n*‖s‖)
    (hb:∃D:ℝ,∀n,‖M n*ᵥ(u+s)‖≤D) : u=0 := by
  obtain ⟨D,hD⟩:=hb
  have hρ0 : 0<ρ := lt_trans zero_lt_one hρ
  have hq : 0≤ρ⁻¹ := inv_nonneg.mpr hρ0.le
  have hq1 : ρ⁻¹<1 := (inv_lt_one₀ hρ0).mpr hρ
  have hh (n:ℕ) : ‖u‖≤C*(ρ⁻¹)^n*(D+C*‖s‖) := by
    have hs' : ‖M n*ᵥs‖≤C*‖s‖ := calc
      _≤C*(ρ⁻¹)^n*‖s‖ := hs n
      _≤C*1*‖s‖ := by gcongr;exact pow_le_one₀ hq hq1.le
      _=_ := by ring
    have hv : M n*ᵥu=M n*ᵥ(u+s)-M n*ᵥs := by rw [Matrix.mulVec_add,add_sub_cancel_right]
    have hu' : C⁻¹*ρ^n*‖u‖≤D+C*‖s‖ := calc
      _≤‖M n*ᵥu‖ := hu n
      _=‖M n*ᵥ(u+s)-M n*ᵥs‖ := by rw [hv]
      _≤‖M n*ᵥ(u+s)‖+‖M n*ᵥs‖ := norm_sub_le _ _
      _≤D+C*‖s‖ := add_le_add (hD n) hs'
    have hm:=mul_le_mul_of_nonneg_left hu' (show 0≤C*(ρ⁻¹)^n by positivity)
    have hc : C*(ρ⁻¹)^n*(C⁻¹*ρ^n)=1 := by rw [inv_pow];field_simp
    simpa only [←mul_assoc,hc,one_mul] using hm
  have ht : Tendsto (fun n:ℕ=>C*(ρ⁻¹)^n*(D+C*‖s‖)) atTop (𝓝 0) := by
    simpa using ((tendsto_pow_atTop_nhds_zero_of_lt_one hq hq1).const_mul C).mul_const (D+C*‖s‖)
  have hn : ‖u‖≤0 := ge_of_tendsto ht (Filter.Eventually.of_forall hh)
  exact norm_eq_zero.mp (le_antisymm hn (norm_nonneg u))

theorem contracting_line_bounded (M:ℕ→Mat) (v:Vec) {C ρ:ℝ}
    (hC:0≤C) (hρ:1<ρ)
    (h:∀n,‖M n*ᵥv‖≤C*(ρ⁻¹)^n*‖v‖) :
    ∃D:ℝ,∀n,‖M n*ᵥv‖≤D := by
  have hρ0 : 0<ρ := lt_trans zero_lt_one hρ
  refine ⟨C*‖v‖,fun n=>?_⟩
  calc
    _≤C*(ρ⁻¹)^n*‖v‖ := h n
    _≤C*1*‖v‖ := by gcongr;exact pow_le_one₀ (inv_nonneg.mpr hρ0.le) ((inv_lt_one₀ hρ0).mpr hρ).le
    _=_ := by ring
end UAMODraft.CoverHyperbolicity

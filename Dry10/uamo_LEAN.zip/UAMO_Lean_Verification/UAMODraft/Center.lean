import UAMODraft.Orders

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology

def zeroAdjustment (w : ℂ) : ℂ := Complex.exp (Complex.I*(w.im:ℂ))-1+(w.re:ℂ)

theorem zeroAdjustment_base : zeroAdjustment 0=0 := by simp [zeroAdjustment]

theorem zeroAdjustment_hasFDerivAt :
    HasFDerivAt zeroAdjustment (ContinuousLinearEquiv.refl ℝ ℂ : ℂ→L[ℝ]ℂ) 0 := by
  let im := Complex.ofRealCLM.comp Complex.imCLM
  let re := Complex.ofRealCLM.comp Complex.reCLM
  have h := (((im.hasFDerivAt (x:=0)).const_mul Complex.I).cexp.sub_const 1).add
    (re.hasFDerivAt (x:=0))
  convert h using 1
  apply ContinuousLinearMap.ext
  intro w
  simp [im,re,ContinuousLinearMap.comp_apply,smul_eq_mul]
  simpa [add_comm,mul_comm] using (Complex.re_add_im w).symm

theorem zeroAdjustment_analytic : AnalyticAt ℝ zeroAdjustment 0 := by
  exact ((analyticAt_cexp.restrictScalars.comp
    (analyticAt_const.mul ((Complex.ofRealCLM.analyticAt _).comp (Complex.imCLM.analyticAt _)))).sub
      analyticAt_const).add ((Complex.ofRealCLM.analyticAt _).comp (Complex.reCLM.analyticAt _))

theorem zeroAdjustment_reverse_bound :
    (fun w : ℂ => w) =O[nhds 0] zeroAdjustment := by
  have hs : HasStrictFDerivAt zeroAdjustment
      (ContinuousLinearEquiv.refl ℝ ℂ : ℂ→L[ℝ]ℂ) 0 := by
    rw [← zeroAdjustment_hasFDerivAt.fderiv]
    exact zeroAdjustment_analytic.hasStrictFDerivAt
  have h := hs.isBigO_sub_rev.comp_tendsto
    ((continuousAt_id : ContinuousAt (fun w : ℂ => w) 0).tendsto.prodMk_nhds
      (tendsto_const_nhds : Tendsto (fun _ : ℂ => (0:ℂ)) (nhds 0) (nhds 0)))
  simpa only [Function.comp_def,id_eq,sub_zero,zeroAdjustment_base] using h

theorem branch_zero_mode_order {z q : ℂ} (hz : z≠0) (m : ℕ) (hm : 0<m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0) :
    (fun lam => x lam (zeroMode m hm)) =O[nhds (0:ℝ)] (fun lam => lam^2) := by
  have hplus := branch_coefficient_isBigO x hx0 hxa 1 (by norm_num)
  have hminus := branch_coefficient_isBigO x hx0 hxa (-1) (by norm_num)
  have hlam : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
    isBigO_of_le _ (fun lam => by simp)
  have hbound := (hlam.mul (hplus.sub hminus)).const_mul_left (-(2*Complex.I)⁻¹/z)
  have heq : ∀ᶠ (lam : ℝ) in nhds 0,
      (-(2*Complex.I)⁻¹/z)*((lam:ℂ)*(coefficient m (x lam) 1-coefficient m (x lam) (-1)))=
        zeroAdjustment (x lam (zeroMode m hm)) := by
    filter_upwards [hxe] with lam he
    have h := congrFun he (zeroMode m hm)
    have hc0 : coefficient m (x lam) 0=1 := by simp [coefficient]
    simp only [finiteSystem,show (zeroMode m hm:ℤ)=0 from rfl,Even.zero,if_true,
      zpow_zero,mul_one,hc0,zero_add,zero_sub,Pi.zero_apply] at h
    rw [div_mul_eq_mul_div]
    apply (div_eq_iff hz).mpr
    unfold zeroAdjustment
    linear_combination -h
  have hg : (fun lam => zeroAdjustment (x lam (zeroMode m hm))) =O[nhds (0:ℝ)] (fun lam => lam^2) := by
    have hb := hbound.congr' heq EventuallyEq.rfl
    simpa only [pow_two] using hb
  have hw : Tendsto (fun lam => x lam (zeroMode m hm)) (nhds 0) (nhds 0) := by
    simpa only [Function.comp_def,hx0,Pi.zero_apply] using
      ((continuous_apply (zeroMode m hm)).continuousAt.comp hxa.continuousAt).tendsto
  exact (zeroAdjustment_reverse_bound.comp_tendsto hw).trans hg

end UAMODraft.OddSeed

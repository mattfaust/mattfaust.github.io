import UAMODraft.CoverDichotomy
import Mathlib

noncomputable section
namespace UAMODraft.CircleCover
open Function Topology

def periodicLift {E : Type*} {p : ℝ} (f : ℝ→E) (hp : Periodic f p) : AddCircle p→E :=
  hp.lift

theorem continuous_periodicLift {E : Type*} [TopologicalSpace E] {p : ℝ}
    (f : ℝ→E) (hp : Periodic f p) (hc : Continuous f) : Continuous (periodicLift f hp) := by
  apply (QuotientAddGroup.isQuotientMap_mk (AddSubgroup.zmultiples p)).continuous_iff.mpr
  exact hc

private theorem circle_one_period_two : Periodic (fun x:ℝ=>(x:AddCircle (1:ℝ))) 2 := by
  intro x
  have hp : ((2:ℝ):AddCircle (1:ℝ))=0 := by
    apply (AddCircle.coe_eq_zero_iff (1:ℝ)).mpr
    exact ⟨2,by norm_num⟩
  change ((x+2:ℝ):AddCircle (1:ℝ))=(x:AddCircle (1:ℝ))
  rw [AddCircle.coe_add,hp,add_zero]

def doubleCover : AddCircle (2:ℝ) → AddCircle (1:ℝ) :=
  periodicLift (fun x:ℝ=>(x:AddCircle (1:ℝ))) circle_one_period_two

theorem continuous_doubleCover : Continuous doubleCover :=
  continuous_periodicLift _ _ (AddCircle.continuous_mk' _)

theorem doubleCover_surjective : Surjective doubleCover := by
  intro y
  obtain ⟨x,rfl⟩ := QuotientAddGroup.mk_surjective y
  exact ⟨(x:AddCircle (2:ℝ)),rfl⟩

def translation (p α : ℝ) : AddCircle p ≃ₜ AddCircle p :=
  Homeomorph.addRight (α:AddCircle p)

@[simp] theorem translation_coe (p α x : ℝ) :
    translation p α (x:AddCircle p)=((x+α:ℝ):AddCircle p) := rfl

theorem doubleCover_translation (α : ℝ) (x : AddCircle (2:ℝ)) :
    doubleCover (translation 2 α x)=translation 1 α (doubleCover x) := by
  obtain ⟨x,rfl⟩ := QuotientAddGroup.mk_surjective x
  rfl

theorem antiperiodic_is_periodic_two {E : Type*} [AddCommGroup E] [Module ℝ E]
    (B : ℝ→E) (m : ℤ) (hb : ∀x,B (x+1)=((-1:ℝ)^m) • B x) : Periodic B 2 := by
  intro x
  have he : x+2=(x+1)+1 := by ring
  have hs : (-1:ℝ)^m*(-1:ℝ)^m=1 := by rw [←mul_zpow];norm_num
  rw [he,hb,hb,smul_smul,hs,one_smul]

theorem doubleCircle_uniformHyperbolic_descends
    (α : ℝ) (A : AddCircle (1:ℝ)→UAMODraft.CoverHyperbolicity.Mat)
    (hA : ∀y,IsUnit (A y))
    (hUH : UAMODraft.PositiveCone.IsUniformlyHyperbolic (translation 2 α) (A∘doubleCover)) :
    UAMODraft.CoverHyperbolicity.IsUniformlyHyperbolicOnLines (translation 1 α) A := by
  letI : Fact (0<(2:ℝ)) := ⟨by norm_num⟩
  exact UAMODraft.CoverHyperbolicity.compact_cover_uniformHyperbolic_descends
    (translation 2 α) (translation 1 α) doubleCover continuous_doubleCover
    doubleCover_surjective (doubleCover_translation α) A hA hUH

end UAMODraft.CircleCover

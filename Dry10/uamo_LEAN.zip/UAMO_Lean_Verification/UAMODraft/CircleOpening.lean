import UAMODraft.CircleFactor
import UAMODraft.OpeningUniformHyperbolicity

noncomputable section
namespace UAMODraft.CircleCover
open UAMODraft.QuantitativeOpening UAMODraft.OpeningAssembly UAMODraft.PositiveCone
open UAMODraft.CoverHyperbolicity Matrix Function
open scoped Matrix.L2OpNorm

theorem ordinaryCircle_uniformHyperbolic_of_opened_positive
    (α : ℝ) (A B : ℝ→Mat2) (m : ℤ)
    (hAcont : Continuous A) (hAper : Periodic A 1) (hBcont : Continuous B)
    (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hAdet : ∀x,(A x).det=1) (hBdet : ∀x,(B x).det=1)
    (σ e : ℝ) (hσ : σ^2=1) (he : e^2=1)
    (hpos : ∀x i j,0<openedCocycle (fun y:ℝ=>y+α) A B σ e x i j) :
    IsUniformlyHyperbolicOnLines (translation 1 α) (periodicLift A hAper) := by
  letI : Fact (0<(2:ℝ)) := ⟨by norm_num⟩
  let A₁ :=periodicLift A hAper
  let A₂ : AddCircle (2:ℝ)→Mat2 :=A₁∘doubleCover
  let B₂ :=periodicLift B (antiperiodic_is_periodic_two B m hanti)
  have hA₂ (x:ℝ) : A₂ (x:AddCircle (2:ℝ))=A x :=rfl
  have hB₂ (x:ℝ) : B₂ (x:AddCircle (2:ℝ))=B x :=rfl
  have hAc₂ : Continuous A₂ :=(continuous_periodicLift A hAper hAcont).comp continuous_doubleCover
  have hBc₂ : Continuous B₂ :=continuous_periodicLift B _ hBcont
  have hAd₂ (x:AddCircle (2:ℝ)) : (A₂ x).det=1 :=by
    obtain ⟨x,rfl⟩ :=QuotientAddGroup.mk_surjective x
    exact hAdet x
  have hBd₂ (x:AddCircle (2:ℝ)) : (B₂ x).det=1 :=by
    obtain ⟨x,rfl⟩ :=QuotientAddGroup.mk_surjective x
    exact hBdet x
  have hpos₂ (x:AddCircle (2:ℝ)) (i j:Fin 2) :
      0<openedCocycle (translation 2 α) A₂ B₂ σ e x i j :=by
    obtain ⟨x,rfl⟩ :=QuotientAddGroup.mk_surjective x
    simpa only [openedCocycle,translation_coe,hA₂,hB₂] using hpos x i j
  have hUH :=uniformlyHyperbolic_of_opened_positive (translation 2 α) A₂ B₂
    hAc₂ hBc₂ hAd₂ hBd₂ σ e hσ he hpos₂
  apply doubleCircle_uniformHyperbolic_descends α A₁ _ hUH
  intro y
  obtain ⟨x,rfl⟩ :=QuotientAddGroup.mk_surjective y
  apply (Matrix.isUnit_iff_isUnit_det _).mpr
  change IsUnit (A x).det
  rw [hAdet]
  exact isUnit_one

end UAMODraft.CircleCover

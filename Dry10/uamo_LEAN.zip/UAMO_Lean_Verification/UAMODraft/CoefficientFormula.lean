import UAMODraft.LeadingCoefficient

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed
open scoped BigOperators

def denominatorProduct (z q : ℂ) (j : ℕ) : ℂ :=
  ∏ l ∈ Finset.range j, divisor z q (spin (-((l+1:ℕ):ℤ))) (-((l+1:ℕ):ℤ))

theorem leadingCoefficient_formula (z q : ℂ) (j : ℕ) :
    leadingCoefficient z q j=(-(2*Complex.I)⁻¹)^j/denominatorProduct z q j := by
  induction j with
  | zero => simp [leadingCoefficient,denominatorProduct]
  | succ j ih =>
    simp only [leadingCoefficient,ih,denominatorProduct,Finset.prod_range_succ,pow_succ,
      div_eq_mul_inv,mul_inv_rev]
    ring

theorem denominatorProduct_eq (z q : ℂ) (j : ℕ) :
    denominatorProduct z q j =
      ∏ l : Fin j, divisor z q (spin (-(l:ℤ)-1)) (-(l:ℤ)-1) := by
  unfold denominatorProduct
  rw [← Fin.prod_univ_eq_prod_range]
  apply Finset.prod_congr rfl
  intro l _
  congr 2 <;> push_cast <;> ring

theorem survivingCoefficient_eq (z q : ℂ) (m : ℕ) (hm : Odd m) :
    (2*Complex.I)⁻¹*leadingCoefficient z q (m-1)=survivingCoefficient m z q := by
  have hm0 : 0<m := by obtain ⟨j,hj⟩ := hm; omega
  have he : Even (m-1) := (Nat.even_sub' hm0).mpr (by simp [hm])
  rw [leadingCoefficient_formula,he.neg_pow,denominatorProduct_eq,survivingCoefficient]
  rw [← mul_div_assoc,← pow_succ']
  congr 2
  omega

end UAMODraft.OddSeed

import UAMODraft.UniformNormalForm
import UAMO.BoundarySeedCone

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix
open scoped Topology

def analyticRealTransfer (m : ℕ) (hm : 0<m) (α lam : ℝ) (ell : ℤ)
    (x : Variables m) (θ : ℝ) : StablePlane.PlaneMatrix :=
  seedRealConjugate ((liftSign ell:ℂ)*analyticHermitianCoefficient α m ell)
    (analyticTransformed m hm (resonantPhase α m ell) α lam x θ)

theorem analytic_odd_seed_strict_normal_form {α : ℝ} (hα : Irrational α)
    (m : ℕ) (hm : Odd m) (ell : ℤ) :
    ∃ x : ℝ→Variables m, x 0=0 ∧ AnalyticAt ℝ x 0 ∧
      analyticHermitianCoefficient α m ell≠0 ∧
      ∃ ε : ℝ, 0<ε ∧ ∀ lam : ℝ, 0<lam → lam<ε →
        let δ:=‖analyticHermitianCoefficient α m ell‖*lam^m
        lam<1 ∧ 0<δ ∧ δ≤1 ∧
        (∀ θ : ℝ, 0<profileSignature (physicalProfile m (x lam) θ)) ∧
        (∀ θ : ℝ, (analyticRealTransfer m (by obtain ⟨j,hj⟩ :=hm;omega)
          α lam ell (x lam) θ).det=1) ∧
        ∀ (θ : ℝ) (i j : Fin 2),
          |liftSign ell*analyticRealTransfer m (by obtain ⟨j,hj⟩ :=hm;omega)
            α lam ell (x lam) θ i j-
            (!![1+δ,0;0,1-δ]:StablePlane.PlaneMatrix) i j|≤δ/16 := by
  have hm0 : 0<m :=by obtain ⟨j,hj⟩ :=hm;omega
  obtain ⟨x,hx0,hxa,hη,C,ε,hC,hε,hform⟩ :=analytic_odd_seed_normal_form hα m hm ell
  let η:=analyticHermitianCoefficient α m ell
  have hηp : 0<‖η‖:=norm_pos_iff.mpr hη
  let ε' :=min ε (min (1/(‖η‖+1)) (‖η‖/(32*C+1)))
  have hε' : 0<ε' :=by dsimp [ε'];positivity
  refine ⟨x,hx0,hxa,hη,ε',hε',?_⟩
  intro lam hlam hsmall
  obtain ⟨hsmall,hsmall'⟩ :=lt_min_iff.mp hsmall
  obtain ⟨hscale,herror⟩ :=lt_min_iff.mp hsmall'
  obtain ⟨hlam1,hpos,hSU,hentries⟩ :=hform lam hlam.le hsmall
  have hηlam : ‖η‖*lam≤1 :=by
    have hh :=(lt_div_iff₀ (show 0<‖η‖+1 by positivity)).mp hscale
    nlinarith only [hh,hlam]
  have hClam : 32*C*lam≤‖η‖ :=by
    have hh :=(lt_div_iff₀ (show 0<32*C+1 by positivity)).mp herror
    nlinarith only [hh,hlam]
  have hpow : lam^m≤lam :=by
    simpa only [pow_one] using pow_le_pow_of_le_one hlam.le hlam1.le hm0
  have hδ : ‖η‖*lam^m≤1 :=(mul_le_mul_of_nonneg_left hpow hηp.le).trans hηlam
  have hreal (θ:ℝ) :=seedRealConjugate_signed_near_diagonal (liftSign_abs ell) η
    (analyticTransformed m hm0 (resonantPhase α m ell) α lam (x lam) θ)
    (hSU θ) (lam^m) (mul_nonneg hC.le (pow_nonneg hlam.le _)) (hentries θ)
  refine ⟨hlam1,mul_pos hηp (pow_pos hlam m),hδ,hpos,fun θ=>(hreal θ).1,?_⟩
  intro θ i j
  have hb :=signed_real_entry_bound _ _ (liftSign_abs ell) (hreal θ).2 i j
  have hh :=mul_le_mul_of_nonneg_right hClam (pow_nonneg hlam.le m)
  have herr : 2*(C*lam^(m+1))≤(‖η‖*lam^m)/16 :=by
    rw [pow_succ]
    nlinarith only [hh]
  simpa only [analyticRealTransfer,mul_comm (lam^m) ‖η‖] using hb.trans herr

end UAMODraft.OddSeed

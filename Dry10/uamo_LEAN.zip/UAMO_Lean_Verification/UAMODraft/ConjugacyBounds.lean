import UAMODraft.OpeningParameters

noncomputable section
namespace UAMODraft.OpeningAssembly
open UAMODraft.QuantitativeOpening Matrix Set
open scoped Matrix.L2OpNorm

theorem sup_norm_mulVec_le (M : Mat2) (v : Vec2) : ‖M*ᵥv‖≤(2*‖M‖)*‖v‖ := by
  apply (pi_norm_le_iff_of_nonneg (by positivity : (0:ℝ)≤(2*‖M‖)*‖v‖)).mpr
  intro i
  rw [Real.norm_eq_abs]
  simp only [Matrix.mulVec,dotProduct,Fin.sum_univ_two]
  calc
    _ ≤ |M i 0*v 0|+|M i 1*v 1| := abs_add_le _ _
    _ = |M i 0| *|v 0|+|M i 1| *|v 1| := by rw [abs_mul,abs_mul]
    _ ≤ ‖M‖*‖v‖+‖M‖*‖v‖ := add_le_add
      (mul_le_mul (entry_le_norm M i 0) (by simpa only [Real.norm_eq_abs] using norm_le_pi_norm v 0)
        (abs_nonneg _) (norm_nonneg _))
      (mul_le_mul (entry_le_norm M i 1) (by simpa only [Real.norm_eq_abs] using norm_le_pi_norm v 1)
        (abs_nonneg _) (norm_nonneg _))
    _ = _ := by ring

variable {X : Type*} [TopologicalSpace X]

theorem continuous_inverse (H : X→Mat2) (hH : Continuous H)
    (hunit : ∀x,IsUnit (H x)) : Continuous (fun x => (H x)⁻¹) := by
  apply continuous_iff_continuousAt.mpr
  intro x
  have hd : (H x).det≠0 := isUnit_iff_ne_zero.mp
    ((Matrix.isUnit_iff_isUnit_det (H x)).mp (hunit x))
  apply (continuousAt_matrix_inv (H x) _).comp hH.continuousAt
  simpa only [Ring.inverse_eq_inv'] using (continuousAt_inv₀ hd)

theorem compact_frame_bounds [CompactSpace X] (H : X→Mat2) (hH : Continuous H)
    (hunit : ∀x,IsUnit (H x)) :
    ∃ L:ℝ,0<L ∧ ∀ x v,‖H x*ᵥv‖≤L*‖v‖ ∧ ‖(H x)⁻¹*ᵥv‖≤L*‖v‖ := by
  let F : C(X,Mat2) := ⟨H,hH⟩
  let G : C(X,Mat2) := ⟨fun x => (H x)⁻¹,continuous_inverse H hH hunit⟩
  let L := 1+2*(‖F‖+‖G‖)
  have hL : 0<L := by dsimp only [L];positivity
  refine ⟨L,hL,?_⟩
  intro x v
  have hF : ‖H x‖≤‖F‖ := F.norm_coe_le_norm x
  have hG : ‖(H x)⁻¹‖≤‖G‖ := G.norm_coe_le_norm x
  constructor
  · exact (sup_norm_mulVec_le (H x) v).trans (mul_le_mul_of_nonneg_right
      (by dsimp only [L];linarith [norm_nonneg G]) (norm_nonneg _))
  · exact (sup_norm_mulVec_le ((H x)⁻¹) v).trans (mul_le_mul_of_nonneg_right
      (by dsimp only [L];linarith [norm_nonneg F]) (norm_nonneg _))

theorem frame_norm_lower (H : Mat2) (hunit : IsUnit H) (L : ℝ)
    (hbound : ∀v:Vec2,‖H⁻¹*ᵥv‖≤L*‖v‖) (v : Vec2) : ‖v‖≤L*‖H*ᵥv‖ := by
  have h := hbound (H*ᵥv)
  rw [Matrix.mulVec_mulVec,Matrix.nonsing_inv_mul _
    ((Matrix.isUnit_iff_isUnit_det H).mp hunit),Matrix.one_mulVec] at h
  exact h

theorem signMatrix_isUnit (e : ℝ) (he : e^2=1) : IsUnit (signMatrix e) := by
  apply (Matrix.isUnit_iff_isUnit_det (signMatrix e)).mpr
  apply isUnit_iff_ne_zero.mpr
  have hn : e≠0 := by intro h;rw [h] at he;norm_num at he
  simpa [signMatrix,Matrix.det_fin_two] using hn

theorem signMatrix_self_mul (e : ℝ) (he : e^2=1) : signMatrix e*signMatrix e=1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [signMatrix,Matrix.mul_apply,Fin.sum_univ_two,←pow_two,he]

end UAMODraft.OpeningAssembly

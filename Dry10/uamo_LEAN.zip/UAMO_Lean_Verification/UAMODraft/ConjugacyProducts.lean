import UAMODraft.ConjugacyBounds
import UAMODraft.PositiveCocycle

noncomputable section
namespace UAMODraft.OpeningAssembly
open UAMODraft.QuantitativeOpening UAMODraft.PositiveCone Matrix
open scoped Matrix.L2OpNorm
variable {X : Type*}

theorem signed_product_intertwining (T : X→X) (A C H : X→Mat2) (σ : ℝ)
    (hstep : ∀x,A x*H x=σ • (H (T x)*C x)) (x : X) (n : ℕ) :
    cocycleProduct T A x n*H x=σ^n • (H (T^[n] x)*cocycleProduct T C x n) := by
  induction n with
  | zero => simp [cocycleProduct]
  | succ n ih =>
    rw [cocycleProduct,Matrix.mul_assoc,ih,mul_smul_comm,←Matrix.mul_assoc,
      hstep,smul_mul_assoc,smul_smul]
    rw [show σ^n*σ=σ^(n+1) by rw [pow_succ]]
    simp only [cocycleProduct,Function.iterate_succ_apply',Matrix.mul_assoc]

theorem signed_product_norm (T : X→X) (A C H : X→Mat2) (σ : ℝ)
    (hσ : |σ|=1) (hstep : ∀x,A x*H x=σ • (H (T x)*C x))
    (x:X) (n:ℕ) (v:Vec2) :
    ‖cocycleProduct T A x n*ᵥ(H x*ᵥv)‖=
      ‖H (T^[n] x)*ᵥ(cocycleProduct T C x n*ᵥv)‖ := by
  rw [Matrix.mulVec_mulVec,signed_product_intertwining T A C H σ hstep,
    Matrix.smul_mulVec_assoc,←Matrix.mulVec_mulVec,norm_smul,
    Real.norm_eq_abs,abs_pow,hσ,one_pow,one_mul]

theorem frameMatrix_mulVec (H : Mat2) (u s : Vec2) :
    frameMatrix (H*ᵥu) (H*ᵥs)=H*frameMatrix u s := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [frameMatrix,Matrix.mul_apply,Matrix.mulVec,dotProduct,Fin.sum_univ_two]

end UAMODraft.OpeningAssembly

import UAMODraft.FrameAngle

noncomputable section
namespace UAMODraft.PositiveAngle
open Matrix UAMO.StablePlane UAMO.ProjectiveAngle
open Set Filter
open scoped Topology

def conjugatedLift (G : ℝ→ℝ≃oℝ) (F : ℝ→ℝ→ℝ) (α : ℝ) (k : ℤ)
    (x s : ℝ) : ℝ := G (x+α) (F x ((G x).symm s))+(k:ℝ)*Real.pi

theorem orderIso_add_int_pi (G : ℝ≃oℝ)
    (hG : ∀s,G (s+Real.pi)=G s+Real.pi) (s : ℝ) (k : ℤ) :
    G (s+(k:ℝ)*Real.pi)=G s+(k:ℝ)*Real.pi :=
  angleMap_add_int_pi (fun _ => G) (fun _ => hG) 0 s k

theorem orderIso_symm_add_int_pi (G : ℝ≃oℝ)
    (hG : ∀s,G (s+Real.pi)=G s+Real.pi) (s : ℝ) (k : ℤ) :
    G.symm (s+(k:ℝ)*Real.pi)=G.symm s+(k:ℝ)*Real.pi := by
  apply G.injective
  rw [G.apply_symm_apply,orderIso_add_int_pi G hG,G.apply_symm_apply]

theorem conjugated_iterate (G : ℝ→ℝ≃oℝ) (F : ℝ→ℝ→ℝ) (α : ℝ) (k : ℤ)
    (hG : ∀x s,G x (s+Real.pi)=G x s+Real.pi)
    (hF : ∀x s,F x (s+Real.pi)=F x s+Real.pi) (x s : ℝ) (n : ℕ) :
    angleIterate (conjugatedLift G F α k) α x s n=
      G (x+(n:ℝ)*α) (angleIterate F α x ((G x).symm s) n)+(n:ℝ)*(k:ℝ)*Real.pi := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [angleIterate_succ,ih]
    dsimp only [conjugatedLift]
    have hint : (n:ℝ)*(k:ℝ)*Real.pi=((n:ℤ)*k:ℤ)*Real.pi := by push_cast;ring
    rw [hint,orderIso_symm_add_int_pi _ (hG _),OrderIso.symm_apply_apply,
      angleMap_add_int_pi F hF,orderIso_add_int_pi _ (hG _)]
    simp only [angleIterate_succ]
    push_cast
    rw [show x+(n:ℝ)*α+α=x+((n:ℝ)+1)*α by ring]
    ring

theorem conjugated_rotation_of_bounded (F : ℝ→ℝ→ℝ) (B : ℝ→PlaneMatrix) (b : ℝ→ℝ)
    (hF : ∀x s,F x (s+Real.pi)=F x s+Real.pi)
    (hB : ∀x,(B x).det=1)
    (hc : ∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (hb : Continuous b) (m k : ℤ) (hw : ∀x,b (x+1)=b x+(m:ℝ)*Real.pi)
    (α : ℝ) (hbounded : ∀x s,∃C:ℝ,0<C ∧ ∀n:ℕ,|angleIterate F α x s n-s|≤C)
    (x s : ℝ) :
    Tendsto (fun n:ℕ =>
      (angleIterate (conjugatedLift (fun x => frameOrderIso (B x) (b x) (hB x) (hc x))
        F α k) α x s n-s)/(2*Real.pi*(n:ℝ)))
      atTop (𝓝 (((m:ℝ)*α+(k:ℝ))/2)) := by
  let G := fun x => frameOrderIso (B x) (b x) (hB x) (hc x)
  let u := (G x).symm s
  have hG : ∀x s,G x (s+Real.pi)=G x s+Real.pi := fun x s => frameLift_add_pi (B x) (b x) s
  obtain ⟨C,hC,hbound⟩ := hbounded x u
  obtain ⟨D,hD,hwind⟩ := winding_remainder_bounded b m hb hw
  let E := Real.pi+C+D+|u+(m:ℝ)*Real.pi*x-s|
  have hE (n:ℕ) :
      |angleIterate (conjugatedLift G F α k) α x s n-s-
        Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ)|≤E := by
    rw [conjugated_iterate G F α k hG hF]
    have h1 := abs_le.mp (hbound n)
    have h2 := abs_le.mp (hwind (x+(n:ℝ)*α))
    have h3 := abs_le.mp (frameLift_displacement (B (x+(n:ℝ)*α))
      (b (x+(n:ℝ)*α)) (angleIterate F α x u n))
    have h4 := abs_le.mp (le_refl |u+(m:ℝ)*Real.pi*x-s|)
    change |frameLift (B (x+(n:ℝ)*α)) (b (x+(n:ℝ)*α))
      (angleIterate F α x u n)+(n:ℝ)*(k:ℝ)*Real.pi-s-
      Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ)|≤E
    dsimp [E]
    apply abs_le.mpr
    constructor <;> nlinarith [h1.1,h1.2,h2.1,h2.2,h3.1,h3.2,h4.1,h4.2]
  let err := fun n:ℕ => angleIterate (conjugatedLift G F α k) α x s n-s-
    Real.pi*((m:ℝ)*α+(k:ℝ))*(n:ℝ)
  have he : Tendsto (fun n:ℕ => err n/(n:ℝ)) atTop (𝓝 0) := by
    apply squeeze_zero_norm (a:=fun n:ℕ => E/(n:ℝ))
    · intro n
      simp only [norm_div,Real.norm_eq_abs,abs_of_nonneg (Nat.cast_nonneg n : (0:ℝ)≤n)]
      exact div_le_div_of_nonneg_right (hE n) (Nat.cast_nonneg n)
    · exact tendsto_const_div_atTop_nhds_zero_nat E
  have ht := (he.div_const (2*Real.pi)).add_const (((m:ℝ)*α+(k:ℝ))/2)
  simp only [zero_div,zero_add] at ht
  apply ht.congr'
  filter_upwards [eventually_ge_atTop (1:ℕ)] with n hn
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  dsimp [err]
  field_simp [Real.pi_ne_zero,hn0]
  ring

theorem angleVector_add_int_pi (s:ℝ) (k:ℤ) :
    angleVector (s+(k:ℝ)*Real.pi)=((-1:ℝ)^k) • angleVector s := by
  ext i
  fin_cases i <;> simp [angleVector,Real.cos_add_int_mul_pi,Real.sin_add_int_mul_pi]

def signedConjugate (M B : ℝ→PlaneMatrix) (α:ℝ) (k:ℤ) (x:ℝ) : PlaneMatrix :=
  ((-1:ℝ)^k) • (B (x+α)*M x*(B x)⁻¹)

theorem conjugatedLift_direction_of_direction (M B : ℝ→PlaneMatrix) (b : ℝ→ℝ)
    (F : ℝ→ℝ→ℝ)
    (hdir : ∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c • (M x*ᵥangleVector s))
    (hB : ∀x,(B x).det=1)
    (hc : ∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (α : ℝ) (k : ℤ) (x s : ℝ) :
    ∃c:ℝ,0<c ∧
      angleVector (conjugatedLift (fun x => frameOrderIso (B x) (b x) (hB x) (hc x))
        F α k x s)=c • (signedConjugate M B α k x*ᵥangleVector s) := by
  let G := fun x => frameOrderIso (B x) (b x) (hB x) (hc x)
  let u := (G x).symm s
  obtain ⟨r,hr,hcol⟩ := hc x
  obtain ⟨r',hr',hcol'⟩ := hc (x+α)
  obtain ⟨c1,hc1,h1⟩ := frameLift_direction (hB x) hr hcol u
  change angleVector (G x u)=c1 • (B x*ᵥangleVector u) at h1
  have hu : G x u=s := (G x).apply_symm_apply s
  rw [hu] at h1
  obtain ⟨c2,hc2,h2⟩ := hdir x u
  obtain ⟨c3,hc3,h3⟩ := frameLift_direction (hB (x+α)) hr' hcol' (F x u)
  change angleVector (G (x+α) (F x u))=_ at h3
  have hi : (B x)⁻¹*B x=1 := Matrix.nonsing_inv_mul _ (by rw [hB];exact isUnit_one)
  refine ⟨c3*c2/c1,by positivity,?_⟩
  change angleVector (G (x+α) (F x u)+(k:ℝ)*Real.pi)=_
  rw [angleVector_add_int_pi,h3,h2,h1]
  simp only [signedConjugate,Matrix.mulVec_smul,Matrix.smul_mulVec_assoc,
    Matrix.mulVec_mulVec,Matrix.smul_mul,smul_smul]
  rw [mul_assoc _ ((B x)⁻¹) (B x),hi,mul_one]
  congr 1
  field_simp
  ring

theorem conjugatedLift_strictMono (G : ℝ→ℝ≃oℝ) (F : ℝ→ℝ→ℝ)
    (hF : ∀x,StrictMono (F x)) (α : ℝ) (k : ℤ) (x : ℝ) :
    StrictMono (conjugatedLift G F α k x) := by
  intro s t hst
  exact add_lt_add_right ((G (x+α)).strictMono (hF x ((G x).symm.strictMono hst))) _

theorem conjugatedLift_add_pi (G : ℝ→ℝ≃oℝ) (F : ℝ→ℝ→ℝ) (α : ℝ) (k : ℤ)
    (hG : ∀x s,G x (s+Real.pi)=G x s+Real.pi)
    (hF : ∀x s,F x (s+Real.pi)=F x s+Real.pi) (x s : ℝ) :
    conjugatedLift G F α k x (s+Real.pi)=conjugatedLift G F α k x s+Real.pi := by
  have hi : (G x).symm (s+Real.pi)=(G x).symm s+Real.pi := by
    simpa using orderIso_symm_add_int_pi (G x) (hG x) s 1
  simp only [conjugatedLift,hi,hF,hG]
  ring

theorem conjugatedLift_periodic (G : ℝ→ℝ≃oℝ) (F : ℝ→ℝ→ℝ) (α : ℝ) (m k : ℤ)
    (hG : ∀x s,G x (s+Real.pi)=G x s+Real.pi)
    (hwind : ∀x s,G (x+1) s=G x s+(m:ℝ)*Real.pi)
    (hF : ∀x s,F x (s+Real.pi)=F x s+Real.pi)
    (hp : ∀x s,F (x+1) s=F x s) (s : ℝ) :
    Function.Periodic (fun x => conjugatedLift G F α k x s) 1 := by
  intro x
  have hi : (G (x+1)).symm s=(G x).symm s+((-m:ℤ):ℝ)*Real.pi := by
    apply (G (x+1)).injective
    rw [OrderIso.apply_symm_apply,hwind,orderIso_add_int_pi _ (hG _),OrderIso.apply_symm_apply]
    push_cast
    ring
  simp only [conjugatedLift,hi,hp,angleMap_add_int_pi F hF]
  rw [show x+1+α=(x+α)+1 by ring,hwind,orderIso_add_int_pi _ (hG _)]
  push_cast
  ring

end UAMODraft.PositiveAngle

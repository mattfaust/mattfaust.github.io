import UAMO.ScalarGaugeDenominators
import UAMO.ScalarGaugeAnalytic
import Mathlib.Topology.Instances.EReal.Lemmas
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Algebra.Order.Round
import Mathlib.Tactic

noncomputable section
namespace UAMODraft.ContinuedFractionDivisors
open Filter
open UAMO.ScalarGauge
open scoped Topology

def beta (α : ℝ) : EReal :=
  Filter.limsup (fun n:ℕ => ((Real.log ((α.convergent (n+1)).den:ℝ) /
    ((α.convergent n).den:ℝ) : ℝ):EReal)) atTop

theorem beta_zero_eventual_den_growth (α : ℝ) (hβ : beta α=0)
    (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ n:ℕ in atTop, ((α.convergent (n+1)).den:ℝ)≤
      Real.exp (ε*((α.convergent n).den:ℝ)) := by
  have he : beta α<(ε:EReal) := by rw [hβ]; exact_mod_cast hε
  have h := Filter.eventually_lt_of_limsup_lt he
  filter_upwards [h] with n hn
  have hn' : Real.log ((α.convergent (n+1)).den:ℝ) /
      ((α.convergent n).den:ℝ)<ε := by exact_mod_cast hn
  have hq : (0:ℝ)<((α.convergent n).den:ℝ) := by exact_mod_cast (α.convergent n).pos
  have hq' : (0:ℝ)<((α.convergent (n+1)).den:ℝ) := by exact_mod_cast (α.convergent (n+1)).pos
  exact (Real.log_le_iff_le_exp hq').mp ((div_lt_iff₀ hq).mp hn').le

theorem beta_zero_uniform_den_growth (α : ℝ) (hβ : beta α=0)
    (ε : ℝ) (hε : 0<ε) :
    ∃ D:ℝ,1≤D ∧ ∀ n:ℕ,((α.convergent (n+1)).den:ℝ)≤
      D*Real.exp (ε*((α.convergent n).den:ℝ)) := by
  obtain ⟨N,hN⟩ := Filter.eventually_atTop.mp (beta_zero_eventual_den_growth α hβ ε hε)
  let D := 1+∑ n∈Finset.range N,((α.convergent (n+1)).den:ℝ)
  have hsum : 0≤∑ n∈Finset.range N,((α.convergent (n+1)).den:ℝ) := by positivity
  have hD : 1≤D := by
    change 1≤1+∑ n∈Finset.range N,((α.convergent (n+1)).den:ℝ)
    linarith
  refine ⟨D,hD,?_⟩
  intro n
  have he : 1≤Real.exp (ε*((α.convergent n).den:ℝ)) := Real.one_le_exp_iff.mpr (by positivity)
  by_cases hn : N≤n
  · exact (hN n hn).trans (by simpa only [one_mul] using
      mul_le_mul_of_nonneg_right hD (Real.exp_pos (ε*((α.convergent n).den:ℝ))).le)
  · have hn' : n∈Finset.range N := Finset.mem_range.mpr (by omega)
    have hterm := Finset.single_le_sum (fun j _ => (Nat.cast_nonneg ((α.convergent (j+1)).den):
      (0:ℝ)≤((α.convergent (j+1)).den:ℝ))) hn'
    have hle : ((α.convergent (n+1)).den:ℝ)≤D := by
      change ((α.convergent (n+1)).den:ℝ)≤1+∑ n∈Finset.range N,((α.convergent (n+1)).den:ℝ)
      linarith
    exact hle.trans (le_mul_of_one_le_right (by linarith : 0≤D) he)

theorem convergent_den_unbounded (α : ℝ) (hα : Irrational α) (K : ℕ) :
    ∃ n:ℕ,K≤(α.convergent n).den := by
  refine ⟨K+5,?_⟩
  have h := convergent_den_fibonacci hα (K+5)
  have hf := Nat.le_fib_self (show 5≤K+5+1 by omega)
  omega

theorem first_den_crossing (α : ℝ) (hα : Irrational α) (k : ℕ) (hk : 0<k) :
    ∃ n:ℕ, (α.convergent n).den<2*k ∧ 2*k≤(α.convergent (n+1)).den := by
  let n := Nat.find (convergent_den_unbounded α hα (2*k))
  have hn : 2*k≤(α.convergent n).den := Nat.find_spec (convergent_den_unbounded α hα (2*k))
  have hn0 : n≠0 := by
    intro hzero
    rw [hzero,Real.convergent_zero,Rat.den_intCast] at hn
    omega
  refine ⟨n-1,?_,?_⟩
  · exact Nat.lt_of_not_ge (Nat.find_min (convergent_den_unbounded α hα (2*k)) (by omega))
  · simpa only [Nat.sub_add_cancel (show 1≤n by omega)] using hn

theorem integer_distance_from_large_convergent (α : ℝ) (hα : Irrational α)
    (k : ℕ) (hk : 0<k) (n : ℕ) (hlarge : 2*k≤(α.convergent n).den) (p : ℤ) :
    1/(2*((α.convergent n).den:ℝ))≤|(k:ℝ)*α-(p:ℝ)| := by
  let r := α.convergent n
  have hkR : (0:ℝ)<(k:ℝ) := by exact_mod_cast hk
  have hQ : (0:ℝ)<(r.den:ℝ) := by exact_mod_cast r.pos
  have hden : (Rat.divInt p (k:ℤ)).den≤k := by
    have h := Int.le_of_dvd (show (0:ℤ)<(k:ℤ) by exact_mod_cast hk) (Rat.den_dvd p (k:ℤ))
    exact_mod_cast h
  have hne : (k:ℤ)*r.num-p*(r.den:ℤ)≠0 := by
    intro hz
    have heq : r=Rat.divInt p (k:ℤ) := by
      apply Rat.cast_injective (α:=ℝ)
      rw [Rat.cast_def,Rat.divInt_eq_div,Rat.cast_div,Rat.cast_intCast,Rat.cast_intCast]
      apply (div_eq_div_iff hQ.ne' hkR.ne').mpr
      have hzR : (k:ℝ)*(r.num:ℝ)-(p:ℝ)*(r.den:ℝ)=0 := by exact_mod_cast hz
      nlinarith
    have hden' : r.den≤k := by rw [heq]; exact hden
    change 2*k≤r.den at hlarge
    omega
  have hsep : (1:ℝ)≤|(((k:ℤ)*r.num-p*(r.den:ℤ):ℤ):ℝ)| := by
    exact_mod_cast Int.one_le_abs hne
  have herr : |(r.den:ℝ)*α-(r.num:ℝ)|≤1/(r.den:ℝ) := by
    have h := convergent_quadratic_error hα n
    change |α-(r:ℝ)|≤1/(r.den:ℝ)^2 at h
    rw [Rat.cast_def] at h
    have hm := mul_le_mul_of_nonneg_left h hQ.le
    have he : (r.den:ℝ)*|α-(r.num:ℝ)/(r.den:ℝ)|=
        |(r.den:ℝ)*α-(r.num:ℝ)| := by
      rw [←abs_of_pos hQ,←abs_mul]
      congr 1
      field_simp
      ring
    rw [he] at hm
    convert hm using 1; field_simp; ring
  have hdecomp : (((k:ℤ)*r.num-p*(r.den:ℤ):ℤ):ℝ)=
      (k:ℝ)*((r.num:ℝ)-(r.den:ℝ)*α)+(r.den:ℝ)*((k:ℝ)*α-(p:ℝ)) := by
    push_cast
    ring
  rw [hdecomp] at hsep
  have habs := abs_add_le ((k:ℝ)*((r.num:ℝ)-(r.den:ℝ)*α))
    ((r.den:ℝ)*((k:ℝ)*α-(p:ℝ)))
  rw [abs_mul,abs_mul,abs_of_pos hkR,abs_of_pos hQ,abs_sub_comm (r.num:ℝ)] at habs
  have hh := hsep.trans habs
  have hb := mul_le_mul_of_nonneg_left herr hkR.le
  have hhalf : (k:ℝ)/(r.den:ℝ)≤1/2 := by
    apply (div_le_iff₀ hQ).mpr
    have hlargeR : 2*(k:ℝ)≤(r.den:ℝ) := by exact_mod_cast hlarge
    linarith
  apply (div_le_iff₀ (show 0<2*(r.den:ℝ) by positivity)).mpr
  rw [div_eq_mul_inv] at hhalf
  simp only [one_div] at hb
  nlinarith

theorem beta_zero_integer_distances (α : ℝ) (hα : Irrational α) (hβ : beta α=0)
    (ε : ℝ) (hε : 0<ε) :
    ∃ D:ℝ,0<D ∧ ∀ k:ℕ,0<k → ∀ p:ℤ,
      1/(D*Real.exp (ε*(k:ℝ)))≤|(k:ℝ)*α-(p:ℝ)| := by
  obtain ⟨D,hD,hgrowth⟩ := beta_zero_uniform_den_growth α hβ (ε/2) (by positivity)
  refine ⟨2*D,by positivity,?_⟩
  intro k hk p
  obtain ⟨n,hn,hnext⟩ := first_den_crossing α hα k hk
  have hnR : ((α.convergent n).den:ℝ)≤2*(k:ℝ) := by exact_mod_cast hn.le
  have he : Real.exp ((ε/2)*((α.convergent n).den:ℝ))≤Real.exp (ε*(k:ℝ)) := by
    apply Real.exp_le_exp.mpr
    nlinarith
  have hQ : ((α.convergent (n+1)).den:ℝ)≤D*Real.exp (ε*(k:ℝ)) :=
    (hgrowth n).trans (mul_le_mul_of_nonneg_left he (by linarith))
  have hQpos : (0:ℝ)<((α.convergent (n+1)).den:ℝ) := by
    exact_mod_cast (α.convergent (n+1)).pos
  have hlow := integer_distance_from_large_convergent α hα k hk (n+1) hnext p
  exact (one_div_le_one_div_of_le (by positivity : 0<2*((α.convergent (n+1)).den:ℝ))
    (by nlinarith : 2*((α.convergent (n+1)).den:ℝ)≤(2*D)*Real.exp (ε*(k:ℝ)))).trans hlow

theorem rotation_chord_norm (t : ℝ) :
    ‖Complex.exp (((2*t:ℝ):ℂ)*Complex.I)-1‖=2*|Real.sin t| := by
  have hfac : Complex.exp ((2*(t:ℂ))*Complex.I)-1=
      (2*Complex.sin (t:ℂ))*Complex.I*Complex.exp ((t:ℂ)*Complex.I) := by
    rw [Complex.exp_mul_I,Complex.exp_mul_I,Complex.cos_two_mul',Complex.sin_two_mul]
    have h := Complex.sin_sq_add_cos_sq (t:ℂ)
    ring_nf
    simp only [Complex.I_sq]
    linear_combination h
  push_cast
  rw [hfac,norm_mul,norm_mul,norm_mul]
  simp only [Complex.norm_ofNat,Complex.norm_I,Complex.norm_exp_ofReal_mul_I,
    mul_one,←Complex.ofReal_sin,Complex.norm_real,Real.norm_eq_abs]

theorem rotation_integer_translation (x : ℝ) (p : ℤ) :
    Complex.exp (2*Real.pi*Complex.I*((x-(p:ℝ):ℝ):ℂ))=
      Complex.exp (2*Real.pi*Complex.I*(x:ℂ)) := by
  have harg : 2*Real.pi*Complex.I*((x-(p:ℝ):ℝ):ℂ)=
      2*Real.pi*Complex.I*(x:ℂ)+(-p:ℂ)*(2*Real.pi*Complex.I) := by push_cast; ring
  rw [harg,Complex.exp_add]
  have h := Complex.exp_int_mul_two_pi_mul_I (-p)
  push_cast at h
  rw [h,mul_one]

theorem rotation_chord_lower (x : ℝ) :
    4*|x-(round x:ℝ)|≤‖Complex.exp (2*Real.pi*Complex.I*(x:ℂ))-1‖ := by
  let t := x-(round x:ℝ)
  have ht : |t|≤1/2 := abs_sub_round x
  rw [←rotation_integer_translation x (round x)]
  have harg : 2*Real.pi*Complex.I*((x-(round x:ℝ):ℝ):ℂ)=
      ((2*(Real.pi*t):ℝ):ℂ)*Complex.I := by dsimp [t]; push_cast; ring
  rw [harg,rotation_chord_norm]
  have hsin := Real.mul_abs_le_abs_sin (x:=Real.pi*t) (by
    rw [abs_mul,abs_of_pos Real.pi_pos]
    nlinarith [Real.pi_pos])
  rw [abs_mul,abs_of_pos Real.pi_pos] at hsin
  have hp : (2/Real.pi)*(Real.pi*|t|)=2*|t| := by field_simp; ring
  rw [hp] at hsin
  change 4*|t|≤2*|Real.sin (Real.pi*t)|
  linarith

theorem divisor_chord_lower_nat (α : ℝ) (k : ℕ) :
    4*|(k:ℝ)*α-(round ((k:ℝ)*α):ℝ)|≤‖divisor α (k:ℤ)‖ := by
  have he : 2*Real.pi*Complex.I*((k:ℤ):ℂ)*(α:ℂ)=
      2*Real.pi*Complex.I*(((k:ℝ)*α:ℝ):ℂ) := by push_cast; ring
  rw [divisor,mode,he]
  exact rotation_chord_lower ((k:ℝ)*α)

theorem beta_zero_nat_divisors (α : ℝ) (hα : Irrational α) (hβ : beta α=0)
    (ε : ℝ) (hε : 0<ε) :
    ∃ D:ℝ,0<D ∧ ∀ k:ℕ,0<k →
      ‖(divisor α (k:ℤ))⁻¹‖≤D*Real.exp (ε*(k:ℝ)) := by
  obtain ⟨D,hD,hdist⟩ := beta_zero_integer_distances α hα hβ ε hε
  refine ⟨D,hD,?_⟩
  intro k hk
  have hlow := hdist k hk (round ((k:ℝ)*α))
  have hchord := divisor_chord_lower_nat α k
  have hdistpos := abs_nonneg ((k:ℝ)*α-(round ((k:ℝ)*α):ℝ))
  have hnorm : 0<‖divisor α (k:ℤ)‖ := norm_pos_iff.mpr (divisor_ne_zero hα (by exact_mod_cast hk.ne'))
  have hden : 0<D*Real.exp (ε*(k:ℝ)) := by positivity
  have hm := (div_le_iff₀ hden).mp hlow
  rw [norm_inv,←one_div]
  apply (div_le_iff₀ hnorm).mpr
  nlinarith [mul_le_mul_of_nonneg_right (show |(k:ℝ)*α-(round ((k:ℝ)*α):ℝ)|≤‖divisor α (k:ℤ)‖ by linarith) hden.le]

theorem divisor_natAbs_norm (α : ℝ) (k : ℤ) :
    ‖divisor α k‖=‖divisor α (k.natAbs:ℤ)‖ := by
  cases k with
  | ofNat n => rfl
  | negSucc n =>
      change ‖divisor α (-((n+1:ℕ):ℤ))‖=‖divisor α ((n+1:ℕ):ℤ)‖
      rw [divisor_neg,Complex.norm_conj]

theorem subexponentialDivisors_of_beta_zero (α : ℝ) (hα : Irrational α)
    (hβ : beta α=0) : SubexponentialDivisors α := by
  intro ε hε
  obtain ⟨D,hD,hbound⟩ := beta_zero_nat_divisors α hα hβ ε hε
  refine ⟨D,hD,?_⟩
  intro k hk
  have h := hbound k.natAbs (Int.natAbs_pos.mpr hk)
  have habs : (k.natAbs:ℝ)=|(k:ℝ)| := by
    rw [←Int.cast_abs,←Int.natCast_natAbs k]
    rfl
  rw [norm_inv,divisor_natAbs_norm]
  simpa only [norm_inv,habs] using h

end UAMODraft.ContinuedFractionDivisors

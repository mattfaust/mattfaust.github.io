import UAMO.MagneticSector

noncomputable section
namespace UAMODraft
open UAMO UAMO.MagneticBoundary

def draftCoordinates : MagneticSite ≃ MagneticSite where
  toFun s := (s.2-s.1,s.1)
  invFun s := (s.2,s.1+s.2)
  left_inv := by intro s; ext <;> simp
  right_inv := by intro s; ext <;> simp

@[simp] theorem draftCoordinates_apply (s : MagneticSite) :
    draftCoordinates s = (s.2-s.1,s.1) := rfl

theorem draftCoordinates_sector (s : MagneticSite) :
    sector s = -intSign ((draftCoordinates s).1 * (draftCoordinates s).2) := by
  unfold sector
  rw [← intSign_neg]
  congr 1
  simp
  ring

private def coordinateVector (e : MagneticSite ≃ MagneticSite)
    (u : MagneticSpace) : MagneticSpace :=
  ⟨fun s => u (e s), by
    apply memℓp_gen
    simpa [Function.comp_def] using e.summable_iff.mpr (magneticSpace_summable_sq u)⟩

private theorem coordinateVector_norm (e : MagneticSite ≃ MagneticSite)
    (u : MagneticSpace) : ‖coordinateVector e u‖ = ‖u‖ := by
  apply (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp
  rw [magneticSpace_norm_sq, magneticSpace_norm_sq]
  exact e.tsum_eq (fun s => ‖u s‖ ^ (2 : ℕ))

def draftReindex : MagneticSpace ≃ₗᵢ[ℂ] MagneticSpace where
  toFun := coordinateVector draftCoordinates.symm
  invFun := coordinateVector draftCoordinates
  left_inv := by intro u; apply lp.ext; funext s; simp [coordinateVector, draftCoordinates]
  right_inv := by intro u; apply lp.ext; funext s; simp [coordinateVector, draftCoordinates]
  map_add' := by intro u v; apply lp.ext; rfl
  map_smul' := by intro c u; apply lp.ext; rfl
  norm_map' := coordinateVector_norm draftCoordinates.symm

@[simp] theorem draftReindex_apply (u : MagneticSpace) (s : MagneticSite) :
    draftReindex u s = u (s.2,s.1+s.2) := rfl

theorem draftReindex_shift (φ : ℝ) (ν : MagneticSite) (u : MagneticSpace) :
    draftReindex (magneticShift (-φ) ν u) =
      magneticShift φ (draftCoordinates ν) (draftReindex u) := by
  apply lp.ext
  funext s
  simp only [draftReindex_apply, magneticShift_apply, draftCoordinates_apply]
  congr 1
  · rw [latticePhase_neg_parameter]
    congr 1
    simp [wedge]
    ring
  · apply congrArg u
    ext <;> simp
    all_goals ring

theorem draftReindex_pair (φ : ℝ) (ν : MagneticSite) (c : ℂ) (u : MagneticSpace) :
    draftReindex (magneticPair (-φ) ν c u) =
      magneticPair φ (draftCoordinates ν) c (draftReindex u) := by
  have hn : draftCoordinates (-ν) = -draftCoordinates ν := by
    ext <;> simp
    all_goals ring
  simp only [magneticPair, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.smul_apply, map_add, map_smul, draftReindex_shift, hn]

def draftHamiltonian (a r α : ℝ) : MagneticOperator :=
  magneticPair (Real.pi*α) (1,-1) 1 +
    magneticPair (Real.pi*α) (0,1) ((r:ℂ)*diagonalHopping a (-Real.pi*α)) +
    magneticPair (Real.pi*α) (1,1) (-(r:ℂ)^2)

theorem draftReindex_hamiltonian (a r α : ℝ) (u : MagneticSpace) :
    draftReindex (scalarHamiltonian a r (-Real.pi*α) u) =
      draftHamiltonian a r α (draftReindex u) := by
  have hf : -Real.pi*α = -(Real.pi*α) := by ring
  simp only [scalarHamiltonian, magneticHamiltonianWith, draftHamiltonian,
    ContinuousLinearMap.add_apply, map_add, hf, draftReindex_pair]
  congr 2
  simp [magneticPair, add_comm]

theorem draftReindex_sector (u : MagneticSpace) (s : MagneticSite) :
    draftReindex (sectorOperator u) s =
      (-(intSign (s.1*s.2)) : ℂ) * draftReindex u s := by
  simp only [draftReindex_apply, sectorOperator_apply]
  congr 1
  rw [← Complex.ofReal_neg]
  congr 1
  have h := draftCoordinates_sector (draftCoordinates.symm s)
  simpa using h

end UAMODraft

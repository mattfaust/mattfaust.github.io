import UAMODraft.ProjectorBounds
import UAMODraft.ProjectorFibres

noncomputable section
namespace UAMODraft.CoverHyperbolicity
open UAMODraft.PositiveCone Matrix
open scoped Topology
variable {Y:Type*} [TopologicalSpace Y]

structure UniformExponentialDichotomy (S:Y≃ₜY) (A:Y→Mat) where
  invertible : ∀y,IsUnit (A y)
  projector : C(Y,Mat)
  C : ℝ
  ρ : ℝ
  C_pos : 0<C
  rate_gt : 1<ρ
  idempotent : ∀y,projector y*projector y=projector y
  rank_one : ∀y,∃u s:Vec,IsUnit (frameMatrix u s) ∧ projector y*ᵥu=0 ∧ projector y*ᵥs=s
  invariant : ∀y,A y*projector y=projector (S y)*A y
  stable : ∀(y:Y)(n:ℕ)(v:Vec),
    ‖cocycleProduct S A y n*ᵥ(projector y*ᵥv)‖≤C*(ρ⁻¹)^n*‖v‖
  unstable : ∀(y:Y)(n:ℕ)(v:Vec),
    ‖backwardProduct S A y n*ᵥ((1-projector y)*ᵥv)‖≤C*(ρ⁻¹)^n*‖v‖

def IsUniformlyHyperbolicOnLines (S:Y≃ₜY) (A:Y→Mat) : Prop :=
  Nonempty (UniformExponentialDichotomy S A)

variable {X:Type*} [TopologicalSpace X] [CompactSpace X] [T2Space Y]

theorem compact_cover_uniformHyperbolic_descends
    (T:X≃ₜX) (S:Y≃ₜY) (π:X→Y)
    (hcont:Continuous π) (honto:Function.Surjective π)
    (hπ:∀x,π (T x)=S (π x)) (A:Y→Mat) (hA:∀y,IsUnit (A y))
    (hUH:IsUniformlyHyperbolic T (A∘π)) : IsUniformlyHyperbolicOnLines S A := by
  obtain ⟨D⟩:=dichotomyFrame_of_uniformlyHyperbolic T (A∘π) (fun x=>hA (π x)) hUH
  let P : C(Y,Mat) := ⟨descendedProjector T π A D honto,
    continuous_descendedProjector T S π A hπ D hcont honto⟩
  have hP (x:X) : P (π x)=D.projector x := descendedProjector_comp T S π A hπ D honto x
  obtain ⟨C,hC,hbound⟩:=D.projector_exponential_bounds
  refine ⟨⟨hA,P,C,D.ρ,hC,D.rate_gt,?_,?_,?_,?_,?_⟩⟩
  · intro y
    obtain ⟨x,rfl⟩:=honto y
    rw [hP]
    exact stableProjector_idempotent _ _ (D.frame x)
  · intro y
    obtain ⟨x,rfl⟩:=honto y
    rw [hP]
    exact ⟨D.u x,D.s x,D.frame x,stableProjector_u _ _ (D.frame x),stableProjector_s _ _ (D.frame x)⟩
  · intro y
    obtain ⟨x,rfl⟩:=honto y
    rw [←hπ,hP,hP]
    exact D.projector_invariant x
  · intro y n v
    obtain ⟨x,rfl⟩:=honto y
    rw [hP,←product_factor T S π hπ]
    exact (hbound x n v).1
  · intro y n v
    obtain ⟨x,rfl⟩:=honto y
    rw [hP,←backwardProduct_factor T S π hπ]
    exact (hbound x n v).2
end UAMODraft.CoverHyperbolicity

import UAMODraft.PositiveProducts
import UAMODraft.ConjugacyBounds

noncomputable section
namespace UAMODraft.CoverHyperbolicity
open UAMODraft.PositiveCone Matrix
open scoped Topology
abbrev Vec := Fin 2→ℝ
abbrev Mat := Matrix (Fin 2) (Fin 2) ℝ
variable {X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]

def backwardProduct (T:X≃ₜX) (A:X→Mat) (x:X) (n:ℕ) : Mat :=
  (cocycleProduct T A (T.symm^[n] x) n)⁻¹

theorem iterate_symm_cancel (T:X≃ₜX) (x:X) (n:ℕ) : T^[n] (T.symm^[n] x)=x :=
  (show Function.LeftInverse T T.symm from T.apply_symm_apply).iterate n x

omit [TopologicalSpace X] in
theorem product_isUnit (T:X→X) (A:X→Mat) (hA:∀x,IsUnit (A x)) (x:X) (n:ℕ) :
    IsUnit (cocycleProduct T A x n) := by
  induction n with
  | zero => exact isUnit_one
  | succ n ih => exact (hA _).mul ih

theorem product_inverse_apply (T:X≃ₜX) (A:X→Mat) (hA:∀x,IsUnit (A x))
    (x:X) (n:ℕ) (v:Vec) :
    cocycleProduct T A (T.symm^[n] x) n*ᵥ(backwardProduct T A x n*ᵥv)=v := by
  rw [Matrix.mulVec_mulVec,backwardProduct,
    Matrix.mul_nonsing_inv _ ((Matrix.isUnit_iff_isUnit_det _).mp (product_isUnit T A hA _ n)),
    Matrix.one_mulVec]

omit [TopologicalSpace X] in
theorem product_line (T:X→X) (A:X→Mat) (v:X→Vec)
    (h:∀x,∃k:ℝ,k≠0 ∧ A x*ᵥv x=k • v (T x)) (x:X) (n:ℕ) :
    ∃k:ℝ,k≠0 ∧ cocycleProduct T A x n*ᵥv x=k • v (T^[n] x) := by
  induction n with
  | zero => exact ⟨1,one_ne_zero,by simp [cocycleProduct]⟩
  | succ n ih =>
    obtain ⟨k,hk,hh⟩:=ih
    obtain ⟨l,hl,hs⟩:=h (T^[n] x)
    refine ⟨k*l,mul_ne_zero hk hl,?_⟩
    rw [cocycleProduct,←Matrix.mulVec_mulVec,hh,Matrix.mulVec_smul,hs,smul_smul,
      Function.iterate_succ_apply']

theorem backward_line (T:X≃ₜX) (A:X→Mat) (hA:∀x,IsUnit (A x)) (v:X→Vec)
    (h:∀x,∃k:ℝ,k≠0 ∧ A x*ᵥv x=k • v (T x)) (x:X) (n:ℕ) (t:ℝ) :
    ∃k:ℝ,backwardProduct T A x n*ᵥ(t • v x)=k • v (T.symm^[n] x) := by
  obtain ⟨k,hk,he⟩:=product_line T A v h (T.symm^[n] x) n
  rw [iterate_symm_cancel] at he
  refine ⟨t*k⁻¹,?_⟩
  apply (Matrix.mulVec_injective_iff_isUnit.mpr (product_isUnit T A hA _ n))
  rw [product_inverse_apply T A hA,Matrix.mulVec_smul,he,smul_smul]
  congr 1
  field_simp

theorem backward_contracts_expanding (T:X≃ₜX) (A:X→Mat) (hA:∀x,IsUnit (A x))
    (v:X→Vec) (hline:∀x,∃k:ℝ,k≠0 ∧ A x*ᵥv x=k • v (T x))
    {C ρ:ℝ} (hC:0<C) (hρ:0<ρ)
    (hbound:∀(x:X) (n:ℕ) (t:ℝ),C⁻¹*ρ^n*‖t • v x‖≤‖cocycleProduct T A x n*ᵥ(t • v x)‖)
    (x:X) (n:ℕ) (t:ℝ) :
    ‖backwardProduct T A x n*ᵥ(t • v x)‖≤C*(ρ⁻¹)^n*‖t • v x‖ := by
  obtain ⟨k,hk⟩:=backward_line T A hA v hline x n t
  have hb:=hbound (T.symm^[n] x) n k
  rw [←hk,product_inverse_apply T A hA] at hb
  have hmul:=mul_le_mul_of_nonneg_left hb (show 0≤C*(ρ⁻¹)^n by positivity)
  have hc : C*(ρ⁻¹)^n*(C⁻¹*ρ^n)=1 := by
    rw [inv_pow]
    field_simp
  calc
    _=C*(ρ⁻¹)^n*(C⁻¹*ρ^n*‖backwardProduct T A x n*ᵥ(t • v x)‖) := by rw [←mul_assoc,hc,one_mul]
    _≤_ := hmul

theorem backward_expands_contracting (T:X≃ₜX) (A:X→Mat) (hA:∀x,IsUnit (A x))
    (v:X→Vec) (hline:∀x,∃k:ℝ,k≠0 ∧ A x*ᵥv x=k • v (T x))
    {C ρ:ℝ} (hC:0<C) (hρ:0<ρ)
    (hbound:∀(x:X) (n:ℕ) (t:ℝ),‖cocycleProduct T A x n*ᵥ(t • v x)‖≤C*(ρ⁻¹)^n*‖t • v x‖)
    (x:X) (n:ℕ) (t:ℝ) :
    C⁻¹*ρ^n*‖t • v x‖≤‖backwardProduct T A x n*ᵥ(t • v x)‖ := by
  obtain ⟨k,hk⟩:=backward_line T A hA v hline x n t
  have hb:=hbound (T.symm^[n] x) n k
  rw [←hk,product_inverse_apply T A hA] at hb
  have hmul:=mul_le_mul_of_nonneg_left hb (show 0≤C⁻¹*ρ^n by positivity)
  have hc : C⁻¹*ρ^n*(C*(ρ⁻¹)^n)=1 := by
    rw [inv_pow]
    field_simp
  calc
    _≤C⁻¹*ρ^n*(C*(ρ⁻¹)^n*‖backwardProduct T A x n*ᵥ(t • v x)‖) := hmul
    _=_ := by rw [←mul_assoc,hc,one_mul]

omit [TopologicalSpace X] [TopologicalSpace Y] in
theorem iterate_factor (T:X→X) (S:Y→Y) (π:X→Y) (hπ:∀x,π (T x)=S (π x))
    (x:X) (n:ℕ) : π (T^[n] x)=S^[n] (π x) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [Function.iterate_succ_apply',hπ,ih,Function.iterate_succ_apply']

omit [TopologicalSpace X] [TopologicalSpace Y] in
theorem product_factor (T:X→X) (S:Y→Y) (π:X→Y) (hπ:∀x,π (T x)=S (π x))
    (A:Y→Mat) (x:X) (n:ℕ) :
    cocycleProduct T (A∘π) x n=cocycleProduct S A (π x) n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [cocycleProduct,Function.comp_apply,iterate_factor T S π hπ,ih]

theorem factor_symm (T:X≃ₜX) (S:Y≃ₜY) (π:X→Y) (hπ:∀x,π (T x)=S (π x))
    (x:X) : π (T.symm x)=S.symm (π x) := by
  apply S.injective
  rw [←hπ,T.apply_symm_apply,S.apply_symm_apply]

theorem backwardProduct_factor (T:X≃ₜX) (S:Y≃ₜY) (π:X→Y)
    (hπ:∀x,π (T x)=S (π x)) (A:Y→Mat) (x:X) (n:ℕ) :
    backwardProduct T (A∘π) x n=backwardProduct S A (π x) n := by
  simp only [backwardProduct,product_factor T S π hπ,
    iterate_factor T.symm S.symm π (factor_symm T S π hπ)]
end UAMODraft.CoverHyperbolicity

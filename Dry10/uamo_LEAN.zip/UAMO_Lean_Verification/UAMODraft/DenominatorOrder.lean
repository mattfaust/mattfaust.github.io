import UAMODraft.Center

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology

def scalarDenominator (z q : ℂ) (k : ℤ) (w : ℂ) : ℂ :=
  (if Even k then z*Complex.exp (Complex.I*(w.im:ℂ))
    else z⁻¹*Complex.exp (-Complex.I*(w.im:ℂ))) - z*(1-(w.re:ℂ))*q^k

theorem scalarDenominator_analytic (z q : ℂ) (k : ℤ) :
    AnalyticAt ℝ (scalarDenominator z q k) 0 := by
  have hi : AnalyticAt ℝ (fun w : ℂ => (w.im:ℂ)) 0 :=
    (Complex.ofRealCLM.analyticAt _).comp (Complex.imCLM.analyticAt _)
  have hr : AnalyticAt ℝ (fun w : ℂ => (w.re:ℂ)) 0 :=
    (Complex.ofRealCLM.analyticAt _).comp (Complex.reCLM.analyticAt _)
  unfold scalarDenominator
  split_ifs
  all_goals
    exact (analyticAt_const.mul
      (analyticAt_cexp.restrictScalars.comp (analyticAt_const.mul hi))).sub
        ((analyticAt_const.mul (analyticAt_const.sub hr)).mul analyticAt_const)

theorem branch_denominator_order {z q : ℂ} (hz : z≠0) (m : ℕ) (hm : 0<m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0) (k : ℤ) :
    (fun lam => denominator m hm z q (x lam) k-divisor z q (spin k) k)
      =O[nhds (0:ℝ)] (fun lam => lam^2) := by
  have hw : Tendsto (fun lam => x lam (zeroMode m hm)) (nhds 0) (nhds 0) := by
    simpa only [Function.comp_def,hx0,Pi.zero_apply] using
      ((continuous_apply (zeroMode m hm)).continuousAt.comp hxa.continuousAt).tendsto
  have hsmall := (scalarDenominator_analytic z q k).differentiableAt.isBigO_sub.comp_tendsto hw
  simp only [Function.comp_def,sub_zero] at hsmall
  have h := hsmall.trans (branch_zero_mode_order hz m hm x hx0 hxa hxe)
  have hbase : scalarDenominator z q k 0=divisor z q (spin k) k :=
    denominator_base m hm z q k
  simpa only [Function.comp_def,sub_zero,hbase] using h

theorem branch_inverse_difference_order {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : z^2=q^m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0)
    (k : Mode m) (hk : (k:ℤ)≠0) :
    (fun lam => (denominator m hm z q (x lam) k)⁻¹-(divisor z q (spin k) k)⁻¹)
      =O[nhds (0:ℝ)] (fun lam => lam^2) := by
  let d := divisor z q (spin k) k
  have hd : d≠0 := by
    simpa only [diagonal,hk,if_false] using diagonal_ne_zero hz hq0 hq m hres k
  have hd0 : denominator m hm z q (x 0) k≠0 := by rw [hx0,denominator_base]; exact hd
  have hbound := ((branch_denominator_order hz m hm x hx0 hxa hxe k).const_mul_left (-d⁻¹)).mul
    (branch_inverse_isBigO hz hq0 hq m hm hres x hx0 hxa.continuousAt k hk)
  have heq : ∀ᶠ (lam : ℝ) in nhds 0,
      (-d⁻¹)*(denominator m hm z q (x lam) k-d)*(denominator m hm z q (x lam) k)⁻¹=
      (denominator m hm z q (x lam) k)⁻¹-d⁻¹ := by
    filter_upwards [(denominator_continuousAt hm z q x hxa.continuousAt k).eventually_ne hd0] with lam hden
    field_simp [hd,hden]
    ring_nf
    simp
  simpa only [mul_one] using hbound.congr' heq EventuallyEq.rfl

end UAMODraft.OddSeed

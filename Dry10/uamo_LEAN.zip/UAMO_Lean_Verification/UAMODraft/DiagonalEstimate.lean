import UAMODraft.ProfileEstimates

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix

theorem scalar_diagonal_near_sign {p u v R σ lam A P : ℝ}
    (hσ : |σ|=1) (hlam : 0≤lam) (hA : 0≤A) (hP : 0≤P)
    (hp : 1/2≤p) (hu : 1/2≤u) (huu : u≤2) (hv : 1/2≤v) (hvu : v≤2)
    (hpd : |p-1|≤lam) (hud : |u-1|≤3*(P*lam)) (hvd : |v-1|≤3*(P*lam))
    (hR : |R-1|≤A*lam) :
    |σ*R*v/(p*u)-σ|≤(8*A+24*P+8)*lam := by
  have hp0 : 0<p := by linarith
  have hu0 : 0<u := by linarith
  have hv0 : 0≤v := by linarith
  have hpu : 1/4≤p*u := by
    nlinarith [mul_nonneg (show 0≤p-1/2 by linarith) (show 0≤u-1/2 by linarith)]
  have hn : |R*v-p*u|≤(2*A+6*P+2)*lam := by
    have he : R*v-p*u=(R-1)*v+(v-1)-((p-1)*u+(u-1)) := by ring
    rw [he]
    calc
      _ ≤ |R-1| *|v|+|v-1|+(|p-1| *|u|+|u-1|) := by
        have ha := abs_sub ((R-1)*v+(v-1)) ((p-1)*u+(u-1))
        have hb := add_le_add (abs_add ((R-1)*v) (v-1)) (abs_add ((p-1)*u) (u-1))
        simpa only [abs_mul] using ha.trans hb
      _ ≤ A*lam*2+3*(P*lam)+(lam*2+3*(P*lam)) := by
        rw [abs_of_nonneg hv0,abs_of_nonneg hu0.le]
        exact add_le_add (add_le_add (mul_le_mul hR hvu hv0 (mul_nonneg hA hlam)) hvd)
          (add_le_add (mul_le_mul hpd huu hu0.le hlam) hud)
      _ = _ := by ring
  have he : σ*R*v/(p*u)-σ=σ*(R*v-p*u)/(p*u) := by field_simp;ring
  rw [he,abs_div,abs_mul,hσ,one_mul,abs_of_pos (mul_pos hp0 hu0)]
  apply (div_le_iff₀ (mul_pos hp0 hu0)).mpr
  have hb := mul_le_mul_of_nonneg_left hpu
    (mul_nonneg (show 0≤2*A+6*P+2 by positivity) hlam)
  nlinarith

theorem analyticDiagonal_near_sign (m : ℕ) (hm : 0<m) (α : ℝ) (ell : ℤ)
    {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam≤1/2) (x : Variables m) (θ : ℝ)
    {A P : ℝ} (hA : 0≤A) (hP : 0≤P) (hsmall : P*lam≤1/4)
    (hxe : profileBoundConstant m*‖x‖≤P*lam) (hx : ‖x‖≤A*lam) :
    |analyticDiagonal m hm α lam (liftSign ell) x θ-liftSign ell|≤
      (8*A+24*P+8)*lam := by
  have hv (y : ℝ) := sqrt_signature_bounds (physicalProfile m x y) (mul_nonneg hP hlam)
    hsmall (by simpa using (physicalProfile_near_e1 m hm x y 0).trans hxe)
    (by simpa using (physicalProfile_near_e1 m hm x y 1).trans hxe)
  have hp := transferDenominator_bounds hlam hlam1 (2*Real.pi*θ)
  exact scalar_diagonal_near_sign (liftSign_abs ell) hlam hA hP hp.1
    (hv θ).1 (hv θ).2.1 (hv (θ+α)).1 (hv (θ+α)).2.1 hp.2.2
    (hv θ).2.2 (hv (θ+α)).2.2 ((amplitude_distance m hm x).trans hx)

end UAMODraft.OddSeed

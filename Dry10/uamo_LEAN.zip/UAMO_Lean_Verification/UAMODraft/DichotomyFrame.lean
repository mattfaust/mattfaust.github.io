import UAMODraft.FrameProjector
import UAMODraft.BoundedOrbitUniqueness

noncomputable section
namespace UAMODraft.CoverHyperbolicity
open UAMODraft.PositiveCone Matrix
open scoped Topology
variable {X:Type*} [TopologicalSpace X]

structure DichotomyFrame (T:X≃ₜX) (A:X→Mat) where
  u : C(X,Vec)
  s : C(X,Vec)
  C : ℝ
  ρ : ℝ
  C_pos : 0<C
  rate_gt : 1<ρ
  frame : ∀x,IsUnit (frameMatrix (u x) (s x))
  invariant : ∀x,∃ku:ℝ,ku≠0 ∧ ∃ks:ℝ,ks≠0 ∧ A x*ᵥu x=ku • u (T x) ∧ A x*ᵥs x=ks • s (T x)
  stable : ∀(x:X)(n:ℕ)(t:ℝ),‖cocycleProduct T A x n*ᵥ(t • s x)‖≤C*(ρ⁻¹)^n*‖t • s x‖
  unstable : ∀(x:X)(n:ℕ)(t:ℝ),C⁻¹*ρ^n*‖t • u x‖≤‖cocycleProduct T A x n*ᵥ(t • u x)‖
  backward_stable : ∀(x:X)(n:ℕ)(t:ℝ),C⁻¹*ρ^n*‖t • s x‖≤‖backwardProduct T A x n*ᵥ(t • s x)‖
  backward_unstable : ∀(x:X)(n:ℕ)(t:ℝ),‖backwardProduct T A x n*ᵥ(t • u x)‖≤C*(ρ⁻¹)^n*‖t • u x‖

theorem dichotomyFrame_of_uniformlyHyperbolic (T:X≃ₜX) (A:X→Mat)
    (hA:∀x,IsUnit (A x)) (h:IsUniformlyHyperbolic T A) : Nonempty (DichotomyFrame T A) := by
  obtain ⟨u,s,C,hC,ρ,hρ,hframe,hline,hs,hu⟩:=h
  have hsu : ∀x,∃k:ℝ,k≠0 ∧ A x*ᵥu x=k • u (T x) := by
    intro x;obtain ⟨ku,hku,ks,hks,hu,hs⟩:=hline x;exact ⟨ku,hku,hu⟩
  have hss : ∀x,∃k:ℝ,k≠0 ∧ A x*ᵥs x=k • s (T x) := by
    intro x;obtain ⟨ku,hku,ks,hks,hu,hs⟩:=hline x;exact ⟨ks,hks,hs⟩
  exact ⟨⟨u,s,C,ρ,hC,hρ,hframe,hline,hs,hu,
    backward_expands_contracting T A hA s hss hC (lt_trans zero_lt_one hρ) hs,
    backward_contracts_expanding T A hA u hsu hC (lt_trans zero_lt_one hρ) hu⟩⟩

namespace DichotomyFrame
variable {T:X≃ₜX} {A:X→Mat} (D:DichotomyFrame T A)

def projector (x:X) : Mat := stableProjector (D.u x) (D.s x)

theorem stable_iff_bounded (x:X) (v:Vec) : D.projector x*ᵥv=v ↔
    ∃K:ℝ,∀n:ℕ,‖cocycleProduct T A x n*ᵥv‖≤K := by
  have hdec:=frame_decomposition (D.u x) (D.s x) v (D.frame x)
  constructor
  · intro hv
    have hs : v=stablePart (D.u x) (D.s x) v := by
      rw [←stableProjector_apply];exact hv.symm
    rw [hs]
    exact contracting_line_bounded _ _ D.C_pos.le D.rate_gt (fun n=>D.stable x n _)
  · intro hv
    have hu0 : unstablePart (D.u x) (D.s x) v=0 := by
      apply expanding_part_zero_of_bounded (fun n=>cocycleProduct T A x n)
        (unstablePart (D.u x) (D.s x) v) (stablePart (D.u x) (D.s x) v)
        D.C_pos D.rate_gt (fun n=>D.unstable x n _) (fun n=>D.stable x n _)
      rwa [←hdec]
    change stableProjector (D.u x) (D.s x)*ᵥv=v
    rw [stableProjector_apply]
    simpa only [hu0,zero_add] using hdec.symm

theorem unstable_iff_backward_bounded (x:X) (v:Vec) : D.projector x*ᵥv=0 ↔
    ∃K:ℝ,∀n:ℕ,‖backwardProduct T A x n*ᵥv‖≤K := by
  have hdec:=frame_decomposition (D.u x) (D.s x) v (D.frame x)
  constructor
  · intro hv
    have hs0 : stablePart (D.u x) (D.s x) v=0 := by
      rw [←stableProjector_apply];exact hv
    have hu : v=unstablePart (D.u x) (D.s x) v := by simpa [hs0] using hdec
    rw [hu]
    exact contracting_line_bounded _ _ D.C_pos.le D.rate_gt (fun n=>D.backward_unstable x n _)
  · intro hv
    have hs0 : stablePart (D.u x) (D.s x) v=0 := by
      apply expanding_part_zero_of_bounded (fun n=>backwardProduct T A x n)
        (stablePart (D.u x) (D.s x) v) (unstablePart (D.u x) (D.s x) v)
        D.C_pos D.rate_gt (fun n=>D.backward_stable x n _) (fun n=>D.backward_unstable x n _)
      rw [add_comm,←hdec]
      exact hv
    exact (stableProjector_apply _ _ _).trans hs0

theorem continuous_projector : Continuous D.projector := by
  have hH : Continuous (fun x=>frameMatrix (D.u x) (D.s x)) := by
    apply continuous_matrix
    intro i j
    fin_cases i <;> fin_cases j <;> simp [frameMatrix] <;> fun_prop
  have hi := UAMODraft.OpeningAssembly.continuous_inverse _ hH D.frame
  exact (hH.mul continuous_const).mul hi

end DichotomyFrame

omit [TopologicalSpace X] in
 theorem matrix_eq_of_frame_action {P Q:Mat} (u s:Vec) (h:IsUnit (frameMatrix u s))
    (hu:P*ᵥu=Q*ᵥu) (hs:P*ᵥs=Q*ᵥs) : P=Q := by
  apply matrix_eq_of_mulVec_eq
  intro v
  conv_lhs => rw [frame_decomposition u s v h]
  conv_rhs => rw [frame_decomposition u s v h]
  simp only [unstablePart,stablePart,Matrix.mulVec_add,Matrix.mulVec_smul,hu,hs]

namespace DichotomyFrame
variable {T:X≃ₜX} {A:X→Mat} (D:DichotomyFrame T A)

theorem projector_invariant (x:X) : A x*D.projector x=D.projector (T x)*A x := by
  obtain ⟨ku,_,ks,_,hu,hs⟩:=D.invariant x
  apply matrix_eq_of_frame_action (D.u x) (D.s x) (D.frame x)
  · rw [←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec]
    change A x*ᵥ(stableProjector (D.u x) (D.s x)*ᵥD.u x)=_
    rw [stableProjector_u _ _ (D.frame x),Matrix.mulVec_zero,hu,Matrix.mulVec_smul]
    change 0=ku • (stableProjector (D.u (T x)) (D.s (T x))*ᵥD.u (T x))
    rw [stableProjector_u _ _ (D.frame _),smul_zero]
  · rw [←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec]
    change A x*ᵥ(stableProjector (D.u x) (D.s x)*ᵥD.s x)=_
    rw [stableProjector_s _ _ (D.frame x),hs,Matrix.mulVec_smul]
    change _=ks • (stableProjector (D.u (T x)) (D.s (T x))*ᵥD.s (T x))
    rw [stableProjector_s _ _ (D.frame _)]

end DichotomyFrame
end UAMODraft.CoverHyperbolicity

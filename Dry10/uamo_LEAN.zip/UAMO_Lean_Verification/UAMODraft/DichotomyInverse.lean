import Mathlib

noncomputable section
namespace UAMODraft.SpectralBridge
open Filter
open scoped Topology

theorem isUnit_one_sub_of_powers_tendsto_zero {R : Type*} [NormedRing R]
    [CompleteSpace R] (a : R)
    (ha : Tendsto (fun n : ℕ => a^n) atTop (𝓝 0)) : IsUnit (1-a) := by
  have hn : ∀ᶠ n : ℕ in atTop, ‖a^n‖ < 1 := by
    simpa only [norm_zero] using ha.norm.eventually (gt_mem_nhds (by simp))
  obtain ⟨n,hn⟩ := hn.exists
  have hp := isUnit_one_sub_of_norm_lt_one hn
  let g := ∑ i ∈ Finset.range n, a^i
  have hc : Commute (1-a) g := by
    change (1-a)*g=g*(1-a)
    dsimp only [g]
    rw [mul_neg_geom_sum,geom_sum_mul_neg]
  apply (hc.isUnit_mul_iff.mp ?_).1
  rwa [show (1-a)*g=1-a^n from mul_neg_geom_sum a n]

theorem dichotomy_fold_power {R : Type*} [Ring R] (u v p : R)
    (hp : p*p=p) (hup : u*p=p*u) (hvp : v*p=p*v) :
    ∀ n : ℕ, (u*p+v*(1-p))^n=u^n*p+v^n*(1-p) := by
  intro n
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ,ih]
    have hpu : p*u=u*p := hup.symm
    have hpv : p*v=v*p := hvp.symm
    simp only [mul_add,add_mul,mul_sub,sub_mul,mul_one,one_mul]
    simp only [mul_assoc]
    simp only [←mul_assoc p u,←mul_assoc p v,hpu,hpv]
    simp only [mul_assoc,hp]
    noncomm_ring

theorem dichotomy_factorization {R : Type*} [Ring R] (u v p : R)
    (huv : u*v=1) :
    (1-u)*(p-v*(1-p))=1-(u*p+v*(1-p)) := by
  simp only [mul_sub,sub_mul,mul_one,one_mul]
  simp only [←mul_assoc,huv,one_mul]
  noncomm_ring

theorem isUnit_one_sub_of_dichotomy {R : Type*} [NormedRing R] [CompleteSpace R]
    (u v p : R) (huv : u*v=1) (hvu : v*u=1)
    (hp : p*p=p) (hup : u*p=p*u) (hvp : v*p=p*v)
    (hs : Tendsto (fun n : ℕ => u^n*p) atTop (𝓝 0))
    (hu : Tendsto (fun n : ℕ => v^n*(1-p)) atTop (𝓝 0)) :
    IsUnit (1-u) := by
  let a := u*p+v*(1-p)
  have ha : Tendsto (fun n : ℕ => a^n) atTop (𝓝 0) := by
    simpa only [a,dichotomy_fold_power u v p hp hup hvp,zero_add] using hs.add hu
  have hi := isUnit_one_sub_of_powers_tendsto_zero a ha
  have hf := dichotomy_factorization u v p huv
  have hc : Commute (1-u) (p-v*(1-p)) := by
    change (1-u)*(p-v*(1-p))=(p-v*(1-p))*(1-u)
    simp only [mul_sub,sub_mul,mul_one,one_mul]
    simp only [←mul_assoc,huv,hvu,one_mul]
    simp only [mul_assoc,hup.symm]
    simp only [←mul_assoc,hvu,one_mul]
    noncomm_ring
  apply (hc.isUnit_mul_iff.mp ?_).1
  rw [hf]
  exact hi

end UAMODraft.SpectralBridge

namespace UAMODraft.SpectralBridge
open Filter
open scoped Topology

theorem tendsto_zero_of_geometric_bound {E : Type*} [SeminormedAddCommGroup E]
    (f : ℕ → E) {C q : ℝ} (hq0 : 0 ≤ q) (hq : q < 1)
    (hbound : ∀ n, ‖f n‖ ≤ C*q^n) : Tendsto f atTop (𝓝 0) := by
  apply squeeze_zero_norm hbound
  simpa using tendsto_const_nhds.mul (tendsto_pow_atTop_nhds_zero_of_lt_one hq0 hq)

theorem isUnit_one_sub_of_exponential_dichotomy {R : Type*} [NormedRing R] [CompleteSpace R]
    (u v p : R) (huv : u*v=1) (hvu : v*u=1)
    (hp : p*p=p) (hup : u*p=p*u) (hvp : v*p=p*v)
    {C q : ℝ} (hq0 : 0 ≤ q) (hq : q < 1)
    (hs : ∀ n : ℕ, ‖u^n*p‖ ≤ C*q^n)
    (hu : ∀ n : ℕ, ‖v^n*(1-p)‖ ≤ C*q^n) :
    IsUnit (1-u) :=
  isUnit_one_sub_of_dichotomy u v p huv hvu hp hup hvp
    (tendsto_zero_of_geometric_bound _ hq0 hq hs)
    (tendsto_zero_of_geometric_bound _ hq0 hq hu)

end UAMODraft.SpectralBridge

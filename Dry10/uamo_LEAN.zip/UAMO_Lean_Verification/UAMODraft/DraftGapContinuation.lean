import UAMODraft.UnitaryGapPersistence

noncomputable section
namespace UAMODraft.BoundaryAssembly
open UAMO UAMODraft Set MeasureTheory UAMO.CircleDOS UAMO.PhysicalDOS

theorem physical_gap_persists_by_height {a α r₀ r₁ : ℝ}
    (ha : 0<a) (ha1 : a≤1) (hα : Irrational α)
    (hr₀ : 0<r₀) (hr₀a : r₀<a) (hr : r₀≤r₁) (hr₁ : r₁≤a)
    (m ell : ℤ) (hm : m≠0)
    (hgap : OpenDOSGapLabel a r₀ α ha.le ha1 hr₀.le
      (hr.trans (hr₁.trans ha1)) (uamoGapLabel α m ell)) :
    OpenDOSGapLabel a r₁ α ha.le ha1 (hr₀.trans_le hr).le
      (hr₁.trans ha1) (uamoGapLabel α m ell) :=by
  obtain ⟨t,δ,hδ,hinterval⟩ :=hgap
  obtain ⟨hres,hlabel⟩ :=hinterval t (by simpa only [sub_self,abs_zero] using hδ)
  let z:ℂ:=Complex.exp ((t:ℂ)*Complex.I)
  let u:ℝ:=arcLabel (physicalUnitaryDOS a r₀ α ha.le ha1 hr₀.le
    (hr.trans (hr₁.trans ha1))) z
  have hz:‖z‖=1 :=by simp [z,Complex.norm_exp]
  have hu:=arcLabel_internal_of_nonzero_nonhalf _ z (uamoGapLabel α m ell)
    (uamoGapLabel_ne_zero hα hm ell) (uamoGapLabel_ne_half hα hm ell) hlabel
  change u∈Ioo (0:ℝ) 1 ∧ u≠1/2 at hu
  have hIDS:=physical_scalarIDS_eq_abs_arcLabel ha ha1 hr₀.le
    (hr.trans (hr₁.trans ha1)) α z
  change scalarIDS a r₀ (-Real.pi*α) (scalarEnergyOfCircle a r₀ z)=|1-2*u| at hIDS
  have hE:=(physical_circle_resolvent_scalar ha ha1 hr₀.le
    (hr.trans (hr₁.trans ha1)) hα 0 z hz).mp (hres 0)
  have hinternal:scalarIDS a r₀ (-Real.pi*α) (scalarEnergyOfCircle a r₀ z)∈Ioo (0:ℝ) 1 :=by
    rw [hIDS]
    exact ⟨abs_pos.mpr (by intro h;apply hu.2;linarith),
      abs_lt.mpr ⟨by linarith [hu.1.2],by linarith [hu.1.1]⟩⟩
  obtain ⟨l₀,u₀,hl₀,hu₀,hcut,hinterval₀⟩ :=scalar_internal_gap_endpoints
    a r₀ (-Real.pi*α) (scalarEnergyOfCircle a r₀ z) hE hinternal
  have hg₀:IsScalarGap a r₀ (-Real.pi*α) l₀ u₀ :=
    ⟨hcut.1.trans hcut.2,hl₀,hu₀,hinterval₀⟩
  have hfield:Real.pi*(-α) = -Real.pi*α :=by ring
  have hg₀':IsScalarGap a r₀ (Real.pi*(-α)) l₀ u₀ :=by
    simpa only [hfield] using hg₀
  obtain ⟨_hpositive,hpersist⟩ :=scalarGap_supremum_persists
    a (-α) r₀ l₀ u₀ ha ha1 hα.neg hr₀ hr₀a hg₀'
  obtain ⟨l₁,u₁,hg₁,_hheight,hids⟩ :=hpersist r₁ ⟨hr,hr₁⟩
  rw [hfield] at hg₁ hids
  let E₁:=(l₁+u₁)/2
  have hc₁:E₁∈Ioo l₁ u₁ :=by dsimp [E₁];constructor <;> linarith [hg₁.lt]
  have hnew:=scalar_internal_cut_unitary_label ha ha1 (hr₀.trans_le hr).le
    (hr₁.trans ha1) hα (hg₁.resolvent E₁ hc₁) u hu.1 hu.2
    ((hids E₁ hc₁ (scalarEnergyOfCircle a r₀ z) hcut).trans hIDS)
  change (u:AddCircle (1:ℝ))=uamoGapLabel α m ell at hlabel
  rwa [hlabel] at hnew

end UAMODraft.BoundaryAssembly

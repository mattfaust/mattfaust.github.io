import UAMODraft.DraftRadialGauge

noncomputable section
namespace UAMODraft.RadialGauge
open UAMO UAMO.OverlapGauge UAMODraft.ScalarBlocks
set_option maxHeartbeats 2000000

theorem physical_factoredHopping (r φ : ℝ) :
    factoredHopping r (walkUOperator φ) (walkVOperator φ) =
      denominator r (magneticV φ)*(1-(r:ℂ) • magneticV φ)*magneticU φ := by
  change Complex.I • ((1-(Complex.I*(r:ℂ)) • star ((-Complex.I) • magneticV φ))*
    (1-(Complex.I*(r:ℂ)) • ((-Complex.I) • magneticV φ))*((-Complex.I) • magneticU φ)) = _
  simp only [star_smul,Complex.star_def,map_neg,Complex.conj_I,neg_neg,smul_smul]
  have h₁ : Complex.I*(r:ℂ)*Complex.I = -(r:ℂ) := by
    calc _ = (Complex.I*Complex.I)*(r:ℂ) := by ring
         _ = _ := by rw [Complex.I_mul_I,neg_one_mul]
  have h₂ : Complex.I*(r:ℂ)*(-Complex.I) = (r:ℂ) := by
    rw [mul_neg,h₁,neg_neg]
  rw [h₁,h₂,neg_smul,sub_neg_eq_add,mul_smul_comm,smul_smul,
    mul_neg,Complex.I_mul_I,neg_neg,one_smul]
  rfl

theorem draftGauge_hopping {r : ℝ} (hr0 : 0≤r) (hr1 : r≤1) (φ : ℝ) :
    draftGaugeHom hr0 hr1 φ (factoredHopping r (walkUOperator φ) (walkVOperator φ)) =
      magneticU φ-(r:ℂ)^2 • (magneticV φ^2*magneticU φ) := by
  rw [physical_factoredHopping]
  have hU : draftGaugeHom hr0 hr1 φ (magneticU φ) = magneticOmega r φ*magneticU φ :=
    overlapGauge_conjugates_U hr0 hr1 φ
  have hV : draftGaugeHom hr0 hr1 φ (magneticV φ) = magneticV φ :=
    overlapGauge_conjugates_V hr0 hr1 φ
  simp only [denominator,map_mul,map_add,map_sub,map_one,map_smul,map_star,hU,hV]
  change denominator r (magneticV φ)*(1-(r:ℂ) • magneticV φ)*
    (omega r (magneticV φ)*magneticU φ) = _
  rw [←mul_assoc,fixedV_hopping_cancellation r (magneticV φ) (magneticV_unitary φ)
    (fun hn => denominator_isUnit hr0 (lt_of_le_of_ne hr1 hn) _ (magneticV_unitary φ)),
    sub_mul,one_mul,smul_mul_assoc,←pow_two]

theorem draftGauge_intermediateHarper {a r : ℝ} (ha : a≠0)
    (hr0 : 0≤r) (hr1 : r≤1) (φ : ℝ) :
    ((((1+a^2)*(1+r^2)/a:ℝ):ℂ) •
      draftGaugeHom hr0 hr1 φ (intermediateHarper a r φ)) = scalarHamiltonian a r φ := by
  rw [←weylEffectiveHamiltonian_eq_scalarHamiltonian]
  simp only [intermediateHarper,map_add,map_smul,map_star,draftGauge_hopping hr0 hr1 φ,
    map_sub,draftGauge_fixes_v hr0 hr1 φ,weylEffectiveHamiltonian]
  change _ = magneticU φ+star (magneticU φ)+
    r • (((a:ℂ)⁻¹-(a:ℂ)*latticePhase φ (-2)) • magneticV φ+
      ((a:ℂ)⁻¹-(a:ℂ)*latticePhase φ 2) • star (magneticV φ))-
    r^2 • (magneticV φ^2*magneticU φ+star (magneticU φ)*star (magneticV φ)^2)
  simp only [show walkVOperator φ = (-Complex.I) • magneticV φ from rfl,
    star_smul,star_sub,star_mul,star_pow,Complex.star_def,Complex.conj_ofReal,map_neg,
    Complex.conj_I,neg_neg,smul_sub,smul_add,smul_smul,
    RCLike.real_smul_eq_coe_smul (K:=ℂ),Complex.ofReal_pow,Complex.ofReal_div,
    Complex.ofReal_mul,Complex.ofReal_add,Complex.ofReal_one]
  have ha' : (a:ℂ)≠0 := Complex.ofReal_ne_zero.mpr ha
  have hma : (1+(a:ℂ)^2)≠0 := by exact_mod_cast (show (1+a^2:ℝ)≠0 by positivity)
  have hmr : (1+(r:ℂ)^2)≠0 := by exact_mod_cast (show (1+r^2:ℝ)≠0 by positivity)
  match_scalars <;> field_simp [ha',hma,hmr] <;> ring_nf <;> simp [Complex.I_sq,pow_succ] <;> ring

end UAMODraft.RadialGauge

import UAMODraft.DraftGaugeHarper
import UAMODraft.DraftRadialGauge

noncomputable section
namespace UAMODraft.RadialGauge
open UAMO UAMO.OverlapGauge UAMODraft.ScalarBlocks

theorem literal_gauge_scaled_spectrum {a r : ℝ} (ha : a≠0)
    (hr0 : 0≤r) (hr1 : r≤1) (φ : ℝ) :
    spectrum ℂ (((((1+a^2)*(1+r^2)/a:ℝ):ℂ)) • intermediateHarper a r φ) =
      spectrum ℂ (scalarHamiltonian a r φ) := by
  rw [← draftGauge_intermediateHarper ha hr0 hr1 φ]
  have hc := map_smul (draftGaugeHom hr0 hr1 φ)
    ((((1+a^2)*(1+r^2)/a:ℝ):ℂ)) (intermediateHarper a r φ)
  rw [← hc]
  exact (unitary.spectrum.unitary_conjugate (R:=ℂ)
    (u:=overlapGaugeUnitary hr0 hr1 φ)).symm

theorem literal_gauge_energy_spectrum {a r : ℝ} (ha : a≠0)
    (hr0 : 0≤r) (hr1 : r≤1) (φ E : ℝ) :
    (E:ℂ)∈spectrum ℂ (intermediateHarper a r φ) ↔
      ((((1+a^2)*(1+r^2)/a)*E:ℝ):ℂ)∈spectrum ℂ (scalarHamiltonian a r φ) := by
  rw [← literal_gauge_scaled_spectrum ha hr0 hr1 φ]
  have hs : ((((1+a^2)*(1+r^2)/a:ℝ):ℂ))≠0 := by
    apply Complex.ofReal_ne_zero.mpr
    exact div_ne_zero (by positivity) ha
  let c : ℂˣ := Units.mk0 ((((1+a^2)*(1+r^2)/a:ℝ):ℂ)) hs
  rw [Complex.ofReal_mul]
  change (E:ℂ)∈spectrum ℂ (intermediateHarper a r φ) ↔
    ((c:ℂ)*(E:ℂ))∈spectrum ℂ (c • intermediateHarper a r φ)
  exact spectrum.smul_mem_smul_iff.symm

theorem literal_walk_scalar_spectrum {a r : ℝ} (ha : 0<a) (ha1 : a≤1)
    (hr0 : 0≤r) (hr1 : r≤1) (φ : ℝ) (z : ℂ) (hz : ‖z‖=1) :
    z∈spectrum ℂ (cstarMagneticWalk a r φ) ↔
      ((((1+a^2)*(1+r^2)/a)*z.re:ℝ):ℂ)∈spectrum ℂ (scalarHamiltonian a r φ) := by
  rw [unitary_realPart_mem_iff _ (cstarMagneticWalk_unitary a r φ ha.le ha1 hr0 hr1)
    (magnetic_walk_star_spectrum a r φ ha.le ha1 hr0 hr1) z hz,
    magnetic_realPart_spectrum_intermediateHarper a r φ ha.le ha1 hr0 hr1]
  exact literal_gauge_energy_spectrum ha.ne' hr0 hr1 φ z.re

end UAMODraft.RadialGauge

import UAMODraft.ScalarBlocksHarper
import UAMO.OverlapGaugeSquare

noncomputable section
namespace UAMODraft.RadialGauge
open UAMO UAMO.OverlapGauge UAMODraft.ScalarBlocks
open scoped InnerProductSpace
set_option maxHeartbeats 2000000

section Algebra
variable {A : Type*} [Ring A] [StarRing A] [Algebra ℂ A] [StarModule ℂ A]

theorem denominator_omega (r : ℝ) (V : A) (hV : V∈unitary A)
    (hInv : r≠1 → IsUnit (denominator r V)) :
    denominator r V * omega r V = numerator r V := by
  by_cases hr : r=1
  · subst r
    simp [denominator,numerator,mul_add,add_mul,unitary.star_mul_self_of_mem hV,add_comm]
  · rw [omega_of_ne_one hr,←mul_assoc]
    have hc : Commute (denominator r V) (numerator r V) := by
      simpa only [denominator_star] using denominator_normal r V hV
    rw [hc.eq,mul_assoc,Ring.mul_inverse_cancel _ (hInv hr),mul_one]

theorem fixedV_hopping_cancellation (r : ℝ) (V : A) (hV : V∈unitary A)
    (hInv : r≠1 → IsUnit (denominator r V)) :
    denominator r V * (1-(r:ℂ) • V) * omega r V =
      1-((r:ℂ)^2) • (V*V) := by
  have hc : Commute (denominator r V) V :=
    (Commute.one_left V).add_left (((unitary_commute_star V hV).symm).smul_left (r:ℂ))
  have hc' : Commute (denominator r V) (1-(r:ℂ) • V) :=
    (Commute.one_right _).sub_right (hc.smul_right (r:ℂ))
  rw [hc'.eq,mul_assoc,denominator_omega r V hV hInv]
  simp only [numerator,mul_add,mul_sub,sub_mul,one_mul,mul_one,
    mul_smul_comm,smul_mul_assoc,smul_smul,pow_two]
  module

end Algebra

def draftGaugeHom {r : ℝ} (hr0 : 0≤r) (hr1 : r≤1) (φ : ℝ) :
    MagneticOperator →⋆ₐ[ℂ] MagneticOperator :=
  conjugateStarAlgHom (overlapGaugeUnitary hr0 hr1 φ)

theorem draftGauge_fixes_v {r : ℝ} (hr0 : 0≤r) (hr1 : r≤1) (φ : ℝ) :
    draftGaugeHom hr0 hr1 φ (walkVOperator φ) = walkVOperator φ := by
  change draftGaugeHom hr0 hr1 φ ((-Complex.I) • magneticV φ) = _
  rw [map_smul]
  change (-Complex.I) • (overlapGauge hr0 hr1 φ*magneticV φ*star (overlapGauge hr0 hr1 φ)) = _
  rw [overlapGauge_conjugates_V]
  rfl

end UAMODraft.RadialGauge

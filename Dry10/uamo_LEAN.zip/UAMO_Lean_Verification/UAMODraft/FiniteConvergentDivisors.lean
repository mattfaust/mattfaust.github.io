import UAMODraft.ContinuedFractionDivisors

noncomputable section
namespace UAMODraft.FiniteConvergentDivisors
open UAMO.ScalarGauge UAMODraft.ContinuedFractionDivisors GenContFract

theorem den_monotone (α : ℝ) (hα : Irrational α) :
    Monotone (fun n:ℕ => (α.convergent n).den) := by
  apply monotone_nat_of_le_succ
  intro n
  have h := GenContFract.of_den_mono (v:=α) (n:=n)
  rw [←convergent_den_eq_continuant hα n,←convergent_den_eq_continuant hα (n+1)] at h
  exact_mod_cast h

theorem den_two_step (α : ℝ) (hα : Irrational α) (n : ℕ) :
    (α.convergent n).den+(α.convergent (n+1)).den≤(α.convergent (n+2)).den := by
  let g := GenContFract.of α
  have hnot : g.s.get? (n+1)≠none := irrational_continuedFraction_not_terminated hα (n+1)
  obtain ⟨gp,hgp⟩ := Option.ne_none_iff_exists'.mp hnot
  have ha := GenContFract.of_partNum_eq_one (GenContFract.partNum_eq_s_a hgp)
  have hb := GenContFract.of_one_le_get?_partDen (GenContFract.partDen_eq_s_b hgp)
  have hrec := GenContFract.dens_recurrence hgp rfl rfl
  rw [ha,one_mul] at hrec
  have hd : g.dens n+g.dens (n+1)≤g.dens (n+2) := by
    rw [hrec]
    nlinarith [GenContFract.zero_le_of_den (v:=α) (n:=n+1)]
  change (GenContFract.of α).dens n+(GenContFract.of α).dens (n+1)≤
    (GenContFract.of α).dens (n+2) at hd
  rw [←convergent_den_eq_continuant hα n,←convergent_den_eq_continuant hα (n+1),
    ←convergent_den_eq_continuant hα (n+2)] at hd
  exact_mod_cast hd

theorem numerator_eq_continuant (α : ℝ) (hα : Irrational α) (n : ℕ) :
    ((α.convergent n).num:ℝ)=(GenContFract.of α).nums n := by
  have h := Real.convs_eq_convergent α n
  rw [GenContFract.conv_eq_num_div_den,←convergent_den_eq_continuant hα n,Rat.cast_def] at h
  have hq : ((α.convergent n).den:ℝ)≠0 := by positivity
  exact ((div_left_inj' hq).mp h).symm

theorem consecutive_determinant_abs (α : ℝ) (hα : Irrational α) (n : ℕ) :
    |((α.convergent n).num:ℝ)*((α.convergent (n+1)).den:ℝ)-
      ((α.convergent n).den:ℝ)*((α.convergent (n+1)).num:ℝ)|=1 := by
  have h := (SimpContFract.of α).determinant (irrational_continuedFraction_not_terminated hα n)
  change (GenContFract.of α).nums n*(GenContFract.of α).dens (n+1)-
    (GenContFract.of α).dens n*(GenContFract.of α).nums (n+1)=(-1:ℝ)^(n+1) at h
  rw [←numerator_eq_continuant α hα n,←numerator_eq_continuant α hα (n+1),
    ←convergent_den_eq_continuant hα n,←convergent_den_eq_continuant hα (n+1)] at h
  rw [h,abs_pow]
  norm_num

theorem rational_rescaled_error (α : ℝ) (r : ℚ) :
    |(r.den:ℝ)*α-(r.num:ℝ)|=(r.den:ℝ)*|α-(r:ℝ)| := by
  have hq : (0:ℝ)<(r.den:ℝ) := by exact_mod_cast r.pos
  rw [Rat.cast_def,←abs_of_pos hq,←abs_mul]
  congr 1
  field_simp
  ring

theorem convergent_scaled_error_upper (α : ℝ) (hα : Irrational α) (n : ℕ) :
    |((α.convergent n).den:ℝ)*α-((α.convergent n).num:ℝ)|≤
      1/((α.convergent (n+1)).den:ℝ) := by
  have h := GenContFract.abs_sub_convs_le (irrational_continuedFraction_not_terminated hα n)
  rw [Real.convs_eq_convergent,←convergent_den_eq_continuant hα n,
    ←convergent_den_eq_continuant hα (n+1)] at h
  have hq : (0:ℝ)<((α.convergent n).den:ℝ) := by exact_mod_cast (α.convergent n).pos
  have hq' : (0:ℝ)<((α.convergent (n+1)).den:ℝ) := by exact_mod_cast (α.convergent (n+1)).pos
  rw [rational_rescaled_error]
  have hh := mul_le_mul_of_nonneg_left h hq.le
  convert hh using 1; field_simp

theorem convergent_scaled_error_lower (α : ℝ) (hα : Irrational α) (n : ℕ) :
    1/(2*((α.convergent (n+1)).den:ℝ))≤
      |((α.convergent n).den:ℝ)*α-((α.convergent n).num:ℝ)| := by
  let q := fun j:ℕ => ((α.convergent j).den:ℝ)
  let p := fun j:ℕ => ((α.convergent j).num:ℝ)
  have hq (j:ℕ) : 0<q j := by dsimp only [q]; exact_mod_cast (α.convergent j).pos
  have h2 : 2*q n≤q (n+2) := by
    have h := den_two_step α hα n
    have hm := den_monotone α hα (show n≤n+1 by omega)
    have hR : q n+q (n+1)≤q (n+2) := by dsimp only [q]; exact_mod_cast h
    have hmR : q n≤q (n+1) := by dsimp only [q]; exact_mod_cast hm
    linarith
  have hdet : |p n*q (n+1)-q n*p (n+1)|=1 := consecutive_determinant_abs α hα n
  have he := convergent_scaled_error_upper α hα (n+1)
  change |q (n+1)*α-p (n+1)|≤1/q (n+2) at he
  have halgebra : p n*q (n+1)-q n*p (n+1)=
      q (n+1)*(p n-q n*α)+q n*(q (n+1)*α-p (n+1)) := by ring
  rw [halgebra] at hdet
  have hh := abs_add_le (q (n+1)*(p n-q n*α)) (q n*(q (n+1)*α-p (n+1)))
  rw [hdet,abs_mul,abs_mul,abs_of_pos (hq (n+1)),abs_of_pos (hq n),
    abs_sub_comm (p n)] at hh
  have hb := mul_le_mul_of_nonneg_left he (hq n).le
  have hhalf : q n*(1/q (n+2))≤1/2 := by
    rw [one_div,←div_eq_mul_inv,div_le_iff₀ (hq (n+2))]
    linarith
  apply (div_le_iff₀ (show 0<2*q (n+1) by positivity)).mpr
  nlinarith

theorem integer_rescaled_error (α : ℝ) (p : ℤ) (k : ℕ) (hk : 0<k) :
    |(k:ℝ)*α-(p:ℝ)|=(k:ℝ)*|α-(Rat.divInt p (k:ℤ):ℝ)| := by
  have hkR : (0:ℝ)<(k:ℝ) := by exact_mod_cast hk
  rw [Rat.divInt_eq_div,Rat.cast_div,Rat.cast_intCast,Rat.cast_intCast]
  rw [←abs_of_pos hkR,←abs_mul]
  congr 1
  field_simp
  ring

theorem integer_distance_before_convergent (α : ℝ) (hα : Irrational α)
    (k : ℕ) (hk : 0<k) (n : ℕ) (hkn : k<(α.convergent n).den) (p : ℤ) :
    1/(2*((α.convergent n).den:ℝ))≤|(k:ℝ)*α-(p:ℝ)| := by
  by_contra! hd
  let r := Rat.divInt p (k:ℤ)
  have hkR : (0:ℝ)<(k:ℝ) := by exact_mod_cast hk
  have hq : (0:ℝ)<((α.convergent n).den:ℝ) := by exact_mod_cast (α.convergent n).pos
  have hr : (0:ℝ)<(r.den:ℝ) := by exact_mod_cast r.pos
  have hden : r.den≤k := by
    have h := Int.le_of_dvd (show (0:ℤ)<(k:ℤ) by exact_mod_cast hk) (Rat.den_dvd p (k:ℤ))
    exact_mod_cast h
  have hdenR : (r.den:ℝ)≤(k:ℝ) := by exact_mod_cast hden
  have hknR : (k:ℝ)≤((α.convergent n).den:ℝ) := by exact_mod_cast hkn.le
  have he := integer_rescaled_error α p k hk
  change |(k:ℝ)*α-(p:ℝ)|=(k:ℝ)*|α-(r:ℝ)| at he
  have h1 : |α-(r:ℝ)|<(1/(2*((α.convergent n).den:ℝ)))/(k:ℝ) := by
    apply (lt_div_iff₀ hkR).mpr
    nlinarith
  have hsq : (r.den:ℝ)^2≤(k:ℝ)^2 := (sq_le_sq₀ hr.le hkR.le).mpr hdenR
  have h2 : (1/(2*((α.convergent n).den:ℝ)))/(k:ℝ)≤1/(2*(r.den:ℝ)^2) := by
    rw [div_div]
    apply one_div_le_one_div_of_le (by positivity)
    nlinarith [mul_nonneg hkR.le (sub_nonneg.mpr hknR)]
  obtain ⟨j,hj⟩ := Real.exists_rat_eq_convergent (h1.trans_le h2)
  have hdenj : (α.convergent j).den<(α.convergent n).den := by rw [←hj]; exact hden.trans_lt hkn
  have hjn : j<n := by
    by_contra! hn
    exact (not_le_of_gt hdenj) (den_monotone α hα hn)
  have hnext : ((α.convergent (j+1)).den:ℝ)≤((α.convergent n).den:ℝ) := by
    exact_mod_cast den_monotone α hα (show j+1≤n by omega)
  have hnpos : (0:ℝ)<((α.convergent (j+1)).den:ℝ) := by exact_mod_cast (α.convergent (j+1)).pos
  have hlow : 1/(2*((α.convergent n).den:ℝ))≤
      |((α.convergent j).den:ℝ)*α-((α.convergent j).num:ℝ)| :=
    (one_div_le_one_div_of_le (by positivity : 0<2*((α.convergent (j+1)).den:ℝ))
      (by linarith)).trans (convergent_scaled_error_lower α hα j)
  have hle : |((α.convergent j).den:ℝ)*α-((α.convergent j).num:ℝ)|≤|(k:ℝ)*α-(p:ℝ)| := by
    rw [rational_rescaled_error,←hj,he]
    exact mul_le_mul_of_nonneg_right hdenR (abs_nonneg _)
  exact (not_le_of_gt hd) (hlow.trans hle)

theorem inverse_divisor_before_convergent (α : ℝ) (hα : Irrational α)
    (n : ℕ) (k : ℤ) (hk : k≠0) (hkn : k.natAbs<(α.convergent n).den) :
    ‖(divisor α k)⁻¹‖≤((α.convergent n).den:ℝ) := by
  have hkpos : 0<k.natAbs := Int.natAbs_pos.mpr hk
  have hdist := integer_distance_before_convergent α hα k.natAbs hkpos n hkn
    (round ((k.natAbs:ℝ)*α))
  have hc := divisor_chord_lower_nat α k.natAbs
  have hq : (0:ℝ)<((α.convergent n).den:ℝ) := by exact_mod_cast (α.convergent n).pos
  have hm := (div_le_iff₀ (show 0<2*((α.convergent n).den:ℝ) by positivity)).mp hdist
  have hnorm : 0<‖divisor α (k.natAbs:ℤ)‖ :=
    norm_pos_iff.mpr (divisor_ne_zero hα (by exact_mod_cast hkpos.ne'))
  rw [norm_inv,divisor_natAbs_norm,←one_div]
  apply (div_le_iff₀ hnorm).mpr
  have hmul := mul_le_mul_of_nonneg_right hc hq.le
  nlinarith

theorem inverse_divisor_half_convergent (α : ℝ) (hα : Irrational α)
    (n : ℕ) (k : ℤ) (hk : k≠0) (hkn : 2*k.natAbs≤(α.convergent n).den) :
    ‖(divisor α k)⁻¹‖≤((α.convergent n).den:ℝ) := by
  have hkpos : 0<k.natAbs := Int.natAbs_pos.mpr hk
  have hdist := integer_distance_from_large_convergent α hα k.natAbs hkpos n hkn
    (round ((k.natAbs:ℝ)*α))
  have hc := divisor_chord_lower_nat α k.natAbs
  have hq : (0:ℝ)<((α.convergent n).den:ℝ) := by exact_mod_cast (α.convergent n).pos
  have hm := (div_le_iff₀ (show 0<2*((α.convergent n).den:ℝ) by positivity)).mp hdist
  have hnorm : 0<‖divisor α (k.natAbs:ℤ)‖ :=
    norm_pos_iff.mpr (divisor_ne_zero hα (by exact_mod_cast hkpos.ne'))
  rw [norm_inv,divisor_natAbs_norm,←one_div]
  apply (div_le_iff₀ hnorm).mpr
  have hmul := mul_le_mul_of_nonneg_right hc hq.le
  nlinarith

open UAMO.Wronskian

theorem weighted_inverse_divisor_bound (α : ℝ) (hα : Irrational α) (n : ℕ)
    (b : ℝ) (hb : 0<b) (k : ℤ) (hk : k∈halfModes ((α.convergent (n+1)).den)) :
    ‖(divisor α k)⁻¹‖*decay (2*b) k ≤
      (((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*
        Real.exp (-b*((α.convergent n).den:ℝ)))*decay b k := by
  obtain ⟨hk0,hkhalf⟩ := (mem_halfModes _ _).mp hk
  have hd0 : 0≤decay b k := (Real.exp_pos _).le
  have hd20 : 0≤decay (2*b) k := (Real.exp_pos _).le
  have hq0 : (0:ℝ)≤((α.convergent n).den:ℝ) := Nat.cast_nonneg _
  have hQ0 : (0:ℝ)≤((α.convergent (n+1)).den:ℝ) := Nat.cast_nonneg _
  by_cases hsmall : k.natAbs<(α.convergent n).den
  · have hi := inverse_divisor_before_convergent α hα n k hk0 hsmall
    have he : decay (2*b) k≤decay b k := by
      unfold decay
      apply Real.exp_le_exp.mpr
      nlinarith [abs_nonneg (k:ℝ)]
    exact (mul_le_mul hi he hd20 hq0).trans
      (mul_le_mul_of_nonneg_right (le_add_of_nonneg_right (mul_nonneg hQ0 (Real.exp_pos _).le)) hd0)
  · have hi := inverse_divisor_half_convergent α hα (n+1) k hk0 hkhalf.le
    have habs : (k.natAbs:ℝ)=|(k:ℝ)| := by
      rw [←Int.cast_abs,←Int.natCast_natAbs k]
      rfl
    have hqabs : ((α.convergent n).den:ℝ)≤|(k:ℝ)| := by
      rw [←habs]
      exact_mod_cast Nat.le_of_not_gt hsmall
    have he : decay (2*b) k≤Real.exp (-b*((α.convergent n).den:ℝ))*decay b k := by
      unfold decay
      rw [←Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith
    exact (mul_le_mul hi he hd20 hQ0).trans ((by
      have h := mul_le_mul_of_nonneg_right
        (show ((α.convergent (n+1)).den:ℝ)*Real.exp (-b*((α.convergent n).den:ℝ))≤
          ((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*Real.exp (-b*((α.convergent n).den:ℝ)) by linarith) hd0
      simpa only [mul_assoc] using h))

theorem finite_gauge_convergent_bound (α : ℝ) (hα : Irrational α) (n : ℕ)
    (c : ℤ→ℂ) {A s b : ℝ} (hA : 0≤A) (hb : 0<b)
    (hc : ExponentialCoefficients c A s b) {z : ℂ} (hz : |z.im|≤s) :
    ‖gaugePotential ((α.convergent (n+1)).den) α c z‖≤
      A*decayMass b*(((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*
        Real.exp (-b*((α.convergent n).den:ℝ))) := by
  let F := ((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*Real.exp (-b*((α.convergent n).den:ℝ))
  have hF : 0≤F := by dsimp only [F]; positivity
  have hterm (k:ℤ) (hk:k∈halfModes ((α.convergent (n+1)).den)) :
      ‖(c k/divisor α k)*mode k z‖≤(A*F)*decay b k := by
    have hw := weighted_mode_bound c hA hc hz k
    have hi := weighted_inverse_divisor_bound α hα n b hb k hk
    calc
      _ = ‖c k*mode k z‖*‖(divisor α k)⁻¹‖ := by
        rw [div_eq_mul_inv,norm_mul,norm_mul,norm_mul]
        ring
      _ ≤ (A*decay (2*b) k)*‖(divisor α k)⁻¹‖ :=
        mul_le_mul_of_nonneg_right hw (norm_nonneg _)
      _ = A*(‖(divisor α k)⁻¹‖*decay (2*b) k) := by ring
      _ ≤ A*(F*decay b k) := mul_le_mul_of_nonneg_left hi hA
      _ = _ := by ring
  change ‖∑ k∈halfModes ((α.convergent (n+1)).den),(c k/divisor α k)*mode k z‖≤_
  calc
    _ ≤ ∑ k∈halfModes ((α.convergent (n+1)).den),‖(c k/divisor α k)*mode k z‖ := norm_sum_le _ _
    _ ≤ ∑ k∈halfModes ((α.convergent (n+1)).den),(A*F)*decay b k := Finset.sum_le_sum hterm
    _ = (A*F)*(∑ k∈halfModes ((α.convergent (n+1)).den),decay b k) := by rw [Finset.mul_sum]
    _ ≤ (A*F)*decayMass b := mul_le_mul_of_nonneg_left
      (Summable.sum_le_tsum _ (fun _ _ => (Real.exp_pos _).le) (decay_summable hb)) (mul_nonneg hA hF)
    _ = _ := by dsimp only [F]; ring

theorem finite_gauge_convergent_residual (α : ℝ) (hα : Irrational α) (n : ℕ)
    (c : ℤ→ℂ) {A s b : ℝ} (hA : 0≤A) (hb : 0<b)
    (hc : ExponentialCoefficients c A s b) (hc0 : c 0=0)
    {z : ℂ} (hz : |z.im|≤s) :
    ‖fourierSeries c z-(gaugePotential ((α.convergent (n+1)).den) α c (z+α)-
      gaugePotential ((α.convergent (n+1)).den) α c z)‖ ≤
      A*decayMass b*Real.exp (-b*((α.convergent (n+1)).den:ℝ)/2) := by
  rw [gaugePotential_translation _ hα]
  exact fourierSeries_tail_bound _ c hA hb hc hc0 hz

end UAMODraft.FiniteConvergentDivisors

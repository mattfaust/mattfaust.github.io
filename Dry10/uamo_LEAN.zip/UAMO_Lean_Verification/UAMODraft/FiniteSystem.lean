import UAMO.BoundaryFourierSeed
import Mathlib.Analysis.Calculus.FDeriv.Analytic
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.Analysis.SpecialFunctions.Complex.Analytic

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed
open scoped BigOperators Topology

abbrev Mode (m : ℕ) := {k : ℤ // k ∈ Finset.Icc (-(m:ℤ)+1) (m:ℤ)}
abbrev Variables (m : ℕ) := Mode m → ℂ

def zeroMode (m : ℕ) (hm : 0<m) : Mode m :=
  ⟨0,Finset.mem_Icc.mpr ⟨by omega,by omega⟩⟩

def spin (k : ℤ) : Fin 2 := if Even k then 0 else 1

def coefficient (m : ℕ) (x : Variables m) (k : ℤ) : ℂ :=
  if k=0 then 1 else if hk : k ∈ Finset.Icc (-(m:ℤ)+1) (m:ℤ) then x ⟨k,hk⟩ else 0

def finiteSystem (m : ℕ) (hm : 0<m) (z q : ℂ) (lam : ℝ) (x : Variables m) : Variables m :=
  fun k =>
    ((if Even (k:ℤ) then z*Complex.exp (Complex.I*(x (zeroMode m hm)).im)
      else z⁻¹*Complex.exp (-Complex.I*(x (zeroMode m hm)).im)) -
      z*(1-(x (zeroMode m hm)).re)*q^(k:ℤ))*coefficient m x k +
    (2*Complex.I)⁻¹*(lam:ℂ)*(coefficient m x ((k:ℤ)+1)-coefficient m x ((k:ℤ)-1))

def diagonal (m : ℕ) (z q : ℂ) (k : Mode m) : ℂ :=
  if (k:ℤ)=0 then z else divisor z q (spin k) k

theorem diagonal_ne_zero {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : z^2=q^m) (k : Mode m) :
    diagonal m z q k ≠ 0 := by
  unfold diagonal
  split_ifs with hk
  · exact hz
  apply divisor_ne_zero hz hq0 hq m hres
  constructor
  · exact fun h => hk h.2
  · intro h
    have hb := (Finset.mem_Icc.mp k.property).1
    have hk' := h.2
    omega

theorem finiteJacobian_bijective {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : z^2=q^m) :
    Function.Bijective (fun x : Variables m => fun k => diagonal m z q k*x k) := by
  constructor
  · intro x y h
    funext k
    exact mul_left_cancel₀ (diagonal_ne_zero hz hq0 hq m hres k) (congrFun h k)
  · intro y
    refine ⟨fun k => y k / diagonal m z q k,?_⟩
    funext k
    exact mul_div_cancel₀ _ (diagonal_ne_zero hz hq0 hq m hres k)

def finiteJacobianLinear (m : ℕ) (z q : ℂ) : Variables m →ₗ[ℂ] Variables m where
  toFun x k := diagonal m z q k*x k
  map_add' x y := by funext k; exact mul_add _ _ _
  map_smul' c x := by funext k; simp only [Pi.smul_apply,smul_eq_mul,RingHom.id_apply]; ring

def finiteJacobianEquiv {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : z^2=q^m) :
    Variables m ≃L[ℝ] Variables m :=
  ((LinearEquiv.ofBijective (finiteJacobianLinear m z q)
    (finiteJacobian_bijective hz hq0 hq m hres)).restrictScalars ℝ).toContinuousLinearEquiv

def survivingCoefficient (m : ℕ) (z q : ℂ) : ℂ :=
  ((2*Complex.I)⁻¹)^m / ∏ j : Fin (m-1),
    divisor z q (spin (-(j:ℤ)-1)) (-(j:ℤ)-1)

theorem survivingCoefficient_ne_zero {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hres : z^2=q^m) :
    survivingCoefficient m z q ≠ 0 := by
  apply div_ne_zero
  · exact pow_ne_zero _ (inv_ne_zero (mul_ne_zero (by norm_num) Complex.I_ne_zero))
  · apply Finset.prod_ne_zero_iff.mpr
    intro j _
    have hj := j.isLt
    apply divisor_ne_zero hz hq0 hq m hres
    constructor
    · intro h
      have := h.2
      omega
    · intro h
      have := h.2
      omega

theorem finiteSystem_base (m : ℕ) (hm : 0<m) (z q : ℂ) :
    finiteSystem m hm z q 0 0 = 0 := by
  funext k
  by_cases hk : (k:ℤ)=0
  · have he : Even (k:ℤ) := hk ▸ Even.zero
    simp [finiteSystem,coefficient,hk,he]
  · simp [finiteSystem,coefficient,hk]

theorem finiteSystem_analytic (m : ℕ) (hm : 0<m) (z q : ℂ)
    (p : ℝ × Variables m) :
    AnalyticAt ℝ (fun p : ℝ × Variables m => finiteSystem m hm z q p.1 p.2) p := by
  have he (k : Mode m) : AnalyticAt ℝ (fun p : ℝ × Variables m => p.2 k) p :=
    ((ContinuousLinearMap.proj k : Variables m →L[ℝ] ℂ).analyticAt p.2).comp (analyticAt_snd (p := p))
  have hc (k : ℤ) : AnalyticAt ℝ (fun p : ℝ × Variables m => coefficient m p.2 k) p := by
    unfold coefficient
    split_ifs
    · exact analyticAt_const
    · exact he _
    · exact analyticAt_const
  have hi : AnalyticAt ℝ (fun p : ℝ × Variables m => ((p.2 (zeroMode m hm)).im:ℂ)) p :=
    (Complex.ofRealCLM.analyticAt _).comp ((Complex.imCLM.analyticAt _).comp (he _))
  have hr : AnalyticAt ℝ (fun p : ℝ × Variables m => ((p.2 (zeroMode m hm)).re:ℂ)) p :=
    (Complex.ofRealCLM.analyticAt _).comp ((Complex.reCLM.analyticAt _).comp (he _))
  apply AnalyticAt.pi
  intro k
  have hp : AnalyticAt ℝ (fun p : ℝ × Variables m =>
      if Even (k:ℤ) then z*Complex.exp (Complex.I*(p.2 (zeroMode m hm)).im)
      else z⁻¹*Complex.exp (-Complex.I*(p.2 (zeroMode m hm)).im)) p := by
    split_ifs
    · exact analyticAt_const.mul (analyticAt_cexp.restrictScalars.comp (analyticAt_const.mul hi))
    · exact analyticAt_const.mul (analyticAt_cexp.restrictScalars.comp (analyticAt_const.mul hi))
  exact ((hp.sub ((analyticAt_const.mul (analyticAt_const.sub hr)).mul analyticAt_const)).mul (hc _)).add
    ((analyticAt_const.mul ((Complex.ofRealCLM.analyticAt _).comp analyticAt_fst)).mul
      ((hc _).sub (hc _)))

theorem analytic_implicit_graph
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [CompleteSpace F]
    (F₀ : ℝ × E → F) (x₀ : E)
    (hzero : F₀ (0,x₀)=0)
    (ha : AnalyticAt ℝ F₀ (0,x₀))
    (J : (ℝ × E) ≃L[ℝ] (ℝ × F))
    (hJ : fderiv ℝ (fun p : ℝ × E => (p.1,F₀ p)) (0,x₀)=J) :
    ∃ x : ℝ → E, x 0=x₀ ∧ AnalyticAt ℝ x 0 ∧
      (∀ᶠ lam in nhds 0, F₀ (lam,x lam)=0) ∧
      (∀ᶠ p in nhds (0,x₀), F₀ p=0 → p.2=x p.1) := by
  let G : ℝ × E → ℝ × F := fun p => (p.1,F₀ p)
  have hG : AnalyticAt ℝ G (0,x₀) := analyticAt_fst.prod ha
  have hd : HasStrictFDerivAt G (J : (ℝ × E) →L[ℝ] (ℝ × F)) (0,x₀) := by
    rw [← hJ]
    exact hG.hasStrictFDerivAt
  let Ψ := hd.toPartialHomeomorph G
  let x : ℝ → E := fun lam => (Ψ.symm (lam,0)).2
  have hbase : G (0,x₀)=(0,0) := by simp [G,hzero]
  have hinv : Ψ.symm (0,0)=(0,x₀) := by
    simpa only [Ψ,← HasStrictFDerivAt.localInverse_def,hbase] using hd.localInverse_apply_image
  have ht : (0,0)∈Ψ.target := by
    simpa only [Ψ,hbase] using hd.image_mem_toPartialHomeomorph_target
  have hai : AnalyticAt ℝ Ψ.symm (0,0) := by
    rw [← hbase]
    exact Ψ.analyticAt_symm' hd.mem_toPartialHomeomorph_source hG hJ
  have hembed : AnalyticAt ℝ (fun lam : ℝ => (lam,(0:F))) 0 :=
    analyticAt_id.prod analyticAt_const
  have hcomp : AnalyticAt ℝ (fun lam : ℝ => Ψ.symm (lam,(0:F))) 0 :=
    hai.comp_of_eq' hembed rfl
  have hax : AnalyticAt ℝ x 0 := analyticAt_snd.comp hcomp
  refine ⟨x,congrArg Prod.snd hinv,hax,?_,?_⟩
  · have hn : ∀ᶠ lam : ℝ in nhds 0, (lam,(0:F))∈Ψ.target :=
      (continuousAt_id.prodMk continuousAt_const).eventually (Ψ.open_target.mem_nhds ht)
    filter_upwards [hn] with lam hlam
    have hi : G (Ψ.symm (lam,0))=(lam,0) := Ψ.right_inv hlam
    have hfst : (Ψ.symm (lam,0)).1=lam := congrArg Prod.fst hi
    have hsnd : F₀ (Ψ.symm (lam,0))=0 := congrArg Prod.snd hi
    have hx : (lam,x lam)=Ψ.symm (lam,0) := Prod.ext hfst.symm rfl
    rw [hx]
    exact hsnd
  · filter_upwards [Ψ.open_source.mem_nhds hd.mem_toPartialHomeomorph_source] with p hp hz
    have hi : Ψ.symm (p.1,0)=p := by
      simpa only [Ψ,HasStrictFDerivAt.toPartialHomeomorph_coe,G,hz] using Ψ.left_inv hp
    exact (congrArg Prod.snd hi).symm

end UAMODraft.OddSeed

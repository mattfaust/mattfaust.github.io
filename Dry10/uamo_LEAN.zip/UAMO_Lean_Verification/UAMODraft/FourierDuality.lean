import UAMO.PhysicalProfileWalk

noncomputable section
namespace UAMODraft.FourierDuality
open UAMO UAMO.ProfileFourier UAMO.PhysicalRepresentation
open UAMO.PhysicalRealPart UAMO.PhysicalWalk UAMO.PhysicalDuality
open Matrix
open scoped InnerProductSpace

theorem fourier_profile_shift (α ξ : ℝ) :
    fourierOperatorMap (profileShift α ξ) = phase (-α) (-ξ) := by
  apply ContinuousLinearMap.ext
  intro ψ
  rw [fourierOperatorMap_apply]
  change scalarFourier ((blochMultiplier ξ)⁻¹ •
    circleTranslation ((-α:ℝ):ProfileCircle) (scalarFourier.symm ψ)) = _
  rw [map_smul,scalarFourier_translation (-α),LinearIsometryEquiv.apply_symm_apply]
  ext n
  simp only [lp.coeFn_smul,Pi.smul_apply,smul_eq_mul,phase_apply,
    blochMultiplier,phaseValue,phaseAngle,← Complex.exp_neg,← mul_assoc,← Complex.exp_add]
  congr 2
  push_cast
  ring

theorem fourier_profile_walk (a r α ξ : ℝ) :
    fourierOperatorMap.toAlgHom.mapMatrix (profileWalk a r α ξ) =
      PhysicalWalk.walk (coupling a) (coupling r) (phase (-α) (-ξ)) shift := by
  rw [profileWalk, PhysicalRepresentation.map_walk,
    fourier_profile_shift, fourierOperatorMap_profilePhase]

def normalizedSpin : TwoByTwo Operator :=
  (((Real.sqrt 2)⁻¹:ℝ):ℂ) • spinChange

theorem spinChange_selfAdjoint : star (spinChange : TwoByTwo Operator) = spinChange := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [spinChange,Matrix.star_apply,star_smul,Complex.star_def]

theorem spin_normalization_square :
    (((Real.sqrt 2)⁻¹:ℝ):ℂ) * (((Real.sqrt 2)⁻¹:ℝ):ℂ) * (2:ℂ) = 1 := by
  have h : (Real.sqrt 2)⁻¹ * (Real.sqrt 2)⁻¹ * (2:ℝ) = 1 := by
    rw [← mul_inv, Real.mul_self_sqrt (by norm_num : (0:ℝ)≤2)]
    norm_num
  exact_mod_cast h

theorem normalizedSpin_selfAdjoint : star normalizedSpin = normalizedSpin := by
  rw [normalizedSpin,star_smul,spinChange_selfAdjoint]
  simp only [Complex.star_def,Complex.conj_ofReal]

theorem normalizedSpin_square : normalizedSpin * normalizedSpin = 1 := by
  rw [normalizedSpin,smul_mul_smul_comm,spinChange_square,smul_smul,
    spin_normalization_square,one_smul]

theorem normalizedSpin_unitary : normalizedSpin ∈ unitary (TwoByTwo Operator) := by
  apply unitary.mem_iff.mpr
  rw [normalizedSpin_selfAdjoint,normalizedSpin_square]
  exact ⟨rfl,rfl⟩

def dualityMatrix (r : ℝ) : TwoByTwo Operator :=
  exchangeShift r shift * normalizedSpin

theorem dualityMatrix_unitary (r : ℝ) : dualityMatrix r ∈ unitary (TwoByTwo Operator) :=
  (unitary (TwoByTwo Operator)).mul_mem (shiftFactor_unitary r shift shift_unitary)
    normalizedSpin_unitary

theorem unnormalized_exchange_intertwines (a r : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (u : Operator) :
    (exchangeShift r shift * spinChange) *
      PhysicalWalk.walk (coupling a) (coupling r) u shift =
    PhysicalWalk.walk (coupling r) (coupling a) shift u *
      (exchangeShift r shift * spinChange) := by
  have h := walk_exchange_conjugacy a r ha0 ha1 hr0 hr1 u shift shift_unitary
  have hDC : (spinChangeInv * star (exchangeShift r shift)) *
      (exchangeShift r shift * spinChange : TwoByTwo Operator) = 1 := by
    have hS : exchangeShift r shift ∈ unitary (TwoByTwo Operator) :=
      shiftFactor_unitary r shift shift_unitary
    calc
      _ = spinChangeInv * (star (exchangeShift r shift) * exchangeShift r shift) *
        spinChange := by simp only [mul_assoc]
      _ = spinChangeInv * 1 * spinChange := by
        rw [unitary.star_mul_self_of_mem hS]
      _ = 1 := by rw [mul_one,spinChange_inv_mul]
  have hh := congrArg (fun M : TwoByTwo Operator => M *
    (exchangeShift r shift * spinChange)) h
  dsimp only at hh
  rw [mul_assoc _ (spinChangeInv * star (exchangeShift r shift))
    (exchangeShift r shift * spinChange),hDC,mul_one] at hh
  exact hh

theorem dualityMatrix_intertwines (a r α ξ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) :
    dualityMatrix r * fourierOperatorMap.toAlgHom.mapMatrix (profileWalk a r α ξ) =
      PhysicalRepresentation.walk (coupling r) (coupling a) (-α) (-ξ) * dualityMatrix r := by
  have h := unnormalized_exchange_intertwines a r ha0 ha1 hr0 hr1 (phase (-α) (-ξ))
  rw [fourier_profile_walk]
  change (exchangeShift r shift * ((((Real.sqrt 2)⁻¹:ℝ):ℂ) • spinChange)) * _ =
    PhysicalWalk.walk (coupling r) (coupling a) shift (phase (-α) (-ξ)) *
      (exchangeShift r shift * ((((Real.sqrt 2)⁻¹:ℝ):ℂ) • spinChange))
  rw [mul_smul_comm,smul_mul_assoc,mul_smul_comm]
  exact congrArg (fun M : TwoByTwo Operator => (((Real.sqrt 2)⁻¹:ℝ):ℂ) • M) h

theorem profileFourier_action (M : TwoByTwo ProfileOperator) (f : SpinProfile) :
    profileFourier (profileAction M f) =
      spinAction (fourierOperatorMap.toAlgHom.mapMatrix M) (profileFourier f) := by
  apply PiLp.ext
  intro i
  simp only [profileFourier_apply,profileAction,spinAction_apply,
    AlgHom.mapMatrix,RingHom.mapMatrix,Matrix.map_apply,map_add]
  change scalarFourier ((M i 0) (f 0)) + scalarFourier ((M i 1) (f 1)) =
    fourierOperatorMap (M i 0) (scalarFourier (f 0)) +
      fourierOperatorMap (M i 1) (scalarFourier (f 1))
  rw [fourierOperatorMap_intertwine,fourierOperatorMap_intertwine]

def profileDuality (r : ℝ) : SpinProfile ≃ₗᵢ[ℂ] SpinHilbert :=
  profileFourier.trans (spinUnitaryEquiv (dualityMatrix r) (dualityMatrix_unitary r))

@[simp] theorem profileDuality_apply (r : ℝ) (f : SpinProfile) :
    profileDuality r f = spinAction (dualityMatrix r) (profileFourier f) := rfl

theorem physical_fourier_duality (a r α ξ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1) (f : SpinProfile) :
    profileDuality r (profileAction (profileWalk a r α ξ) f) =
      spinAction (PhysicalRepresentation.walk (coupling r) (coupling a) (-α) (-ξ))
        (profileDuality r f) := by
  rw [profileDuality_apply,profileFourier_action,← spinAction_mul,
    dualityMatrix_intertwines a r α ξ ha0 ha1 hr0 hr1,spinAction_mul,
    ← profileDuality_apply]

theorem physical_fourier_residual (a r α ξ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (z : ℂ) (f : SpinProfile) :
    spinAction (PhysicalRepresentation.walk (coupling r) (coupling a) (-α) (-ξ))
        (profileDuality r f) - z • profileDuality r f =
      profileDuality r (profileAction (profileWalk a r α ξ) f - z • f) := by
  rw [map_sub,map_smul,physical_fourier_duality a r α ξ ha0 ha1 hr0 hr1]

theorem physical_fourier_residual_norm (a r α ξ : ℝ)
    (ha0 : 0≤a) (ha1 : a≤1) (hr0 : 0≤r) (hr1 : r≤1)
    (z : ℂ) (f : SpinProfile) :
    ‖spinAction (PhysicalRepresentation.walk (coupling r) (coupling a) (-α) (-ξ))
        (profileDuality r f) - z • profileDuality r f‖ =
      ‖profileAction (profileWalk a r α ξ) f - z • f‖ := by
  rw [physical_fourier_residual a r α ξ ha0 ha1 hr0 hr1]
  exact (profileDuality r).norm_map _

theorem physical_fourier_gram (r : ℝ) (f g : SpinProfile) :
    ⟪profileDuality r f,profileDuality r g⟫_ℂ = ⟪f,g⟫_ℂ :=
  (profileDuality r).inner_map_map f g

theorem staggered_physical_fourier_gram (r α ξ : ℝ) (f g : SpinProfile) :
    ⟪profileDuality r (sameSiteProfile α (blochMultiplier ξ) (blochMultiplier_norm ξ) f),
      profileDuality r (sameSiteProfile α (blochMultiplier ξ) (blochMultiplier_norm ξ) g)⟫_ℂ =
      ⟪f,g⟫_ℂ := by
  rw [physical_fourier_gram]
  exact (sameSiteProfile α (blochMultiplier ξ) (blochMultiplier_norm ξ)).inner_map_map f g

end UAMODraft.FourierDuality

import UAMODraft.PositiveAngle
import UAMO.StableAngleDynamics

noncomputable section
namespace UAMODraft.PositiveAngle
open Matrix UAMO.StablePlane UAMO.ProjectiveAngle
open Set Filter
open scoped Topology

def rotatedFrame (B : PlaneMatrix) (b : ℝ) : PlaneMatrix := rotationFactor (-b)*B
def frameLift (B : PlaneMatrix) (b s : ℝ) : ℝ := b+angleLift (rotatedFrame B b) s

theorem rotatedFrame_det {B : PlaneMatrix} (hB : B.det=1) (b : ℝ) :
    (rotatedFrame B b).det=1 := by
  rw [rotatedFrame,Matrix.det_mul,rotationFactor_det,hB,mul_one]

theorem rotatedFrame_column {B : PlaneMatrix} {b r : ℝ}
    (hc : B 0 0=r*Real.cos b ∧ B 1 0=r*Real.sin b) :
    rotatedFrame B b 0 0=r ∧ rotatedFrame B b 1 0=0 := by
  simp only [rotatedFrame,Matrix.mul_apply,Fin.sum_univ_two,rotationFactor,
    Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one,
    Real.cos_neg,Real.sin_neg,hc.1,hc.2]
  constructor
  · linear_combination r*(Real.sin_sq_add_cos_sq b)
  · ring

theorem rotatedFrame_trace_pos {B : PlaneMatrix} (hB : B.det=1) {b r : ℝ}
    (hr : 0<r) (hc : B 0 0=r*Real.cos b ∧ B 1 0=r*Real.sin b) :
    0<rotatedFrame B b 0 0+rotatedFrame B b 1 1 := by
  obtain ⟨h0,h1⟩ := rotatedFrame_column hc
  have hd := rotatedFrame_det hB b
  rw [Matrix.det_fin_two,h0,h1,mul_zero,sub_zero] at hd
  have hdiag : 0<rotatedFrame B b 1 1 := by nlinarith
  rw [h0]
  exact add_pos hr hdiag

theorem rotationFactor_mul (a b : ℝ) :
    rotationFactor a*rotationFactor b=rotationFactor (a+b) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [rotationFactor,Matrix.mul_apply,Fin.sum_univ_two,Real.cos_add,Real.sin_add] <;> ring

theorem rotationFactor_zero : rotationFactor 0=1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [rotationFactor]

theorem frameLift_direction {B : PlaneMatrix} (hB : B.det=1) {b r : ℝ}
    (hr : 0<r) (hc : B 0 0=r*Real.cos b ∧ B 1 0=r*Real.sin b) (s : ℝ) :
    ∃c:ℝ,0<c ∧ angleVector (frameLift B b s)=c • (B*ᵥangleVector s) := by
  obtain ⟨c,hc0,hdir⟩ := angleLift_direction (rotatedFrame_det hB b)
    (rotatedFrame_trace_pos hB hr hc) s
  refine ⟨c,hc0,?_⟩
  rw [frameLift,← rotationFactor_mulVec,hdir,Matrix.mulVec_smul,
    Matrix.mulVec_mulVec,rotatedFrame,← mul_assoc,rotationFactor_mul,
    add_neg_cancel,rotationFactor_zero,one_mul]

theorem frameLift_add_pi (B : PlaneMatrix) (b s : ℝ) :
    frameLift B b (s+Real.pi)=frameLift B b s+Real.pi := by
  simp only [frameLift,angleLift_add_pi]
  ring

theorem frameLift_strictMono {B : PlaneMatrix} (hB : B.det=1) {b r : ℝ}
    (hr : 0<r) (hc : B 0 0=r*Real.cos b ∧ B 1 0=r*Real.sin b) :
    StrictMono (frameLift B b) := by
  intro s t hst
  exact add_lt_add_left (angleLift_strictMono (rotatedFrame_det hB b)
    (rotatedFrame_trace_pos hB hr hc) hst) b

theorem frameLift_displacement (B : PlaneMatrix) (b s : ℝ) :
    |frameLift B b s-s-b|≤Real.pi := by
  obtain ⟨hl,hu⟩ := angleLift_range (rotatedFrame B b) s
  dsimp only [frameLift]
  exact abs_le.mpr ⟨by linarith,by linarith⟩

theorem continuous_frameLift (B : PlaneMatrix) (b : ℝ) : Continuous (frameLift B b) := by
  exact continuous_const.add (continuous_const.add
    (continuous_positiveAngleLift (fun _ => polarForm (rotatedFrame B b))
      (fun s:ℝ => s) continuous_const continuous_id
      (fun s => (polarForm_radial_pos _ s).ne')))

theorem frameLift_surjective (B : PlaneMatrix) (b : ℝ) : Function.Surjective (frameLift B b) := by
  intro y
  let lo := y-b-Real.pi-1
  let hi := y-b+Real.pi+1
  have hlo := (abs_le.mp (frameLift_displacement B b lo)).2
  have hhi := (abs_le.mp (frameLift_displacement B b hi)).1
  have hh : lo≤hi := by dsimp [lo,hi];linarith [Real.pi_pos]
  have hy : y∈Icc (frameLift B b lo) (frameLift B b hi) := by
    dsimp [lo,hi] at hlo hhi
    constructor <;> linarith
  obtain ⟨s,_,hs⟩ := intermediate_value_Icc hh (continuous_frameLift B b).continuousOn hy
  exact ⟨s,hs⟩

noncomputable def frameOrderIso (B : PlaneMatrix) (b : ℝ)
    (hB : B.det=1) (hc : ∃r:ℝ,0<r ∧ B 0 0=r*Real.cos b ∧ B 1 0=r*Real.sin b) : ℝ≃oℝ := by
  have hf : StrictMono (frameLift B b) := by
    obtain ⟨r,hr,hc⟩ := hc
    exact frameLift_strictMono hB hr hc
  exact { Equiv.ofBijective (frameLift B b) ⟨hf.injective,frameLift_surjective B b⟩ with
    map_rel_iff' := by intro x y;exact hf.le_iff_le }

theorem frameLift_degree_shift (B : PlaneMatrix) (b s : ℝ) (m : ℤ) :
    frameLift (((-1:ℝ)^m) • B) (b+(m:ℝ)*Real.pi) s=
      frameLift B b s+(m:ℝ)*Real.pi := by
  have hR : rotationFactor (-(b+(m:ℝ)*Real.pi))=
      ((-1:ℝ)^m) • rotationFactor (-b) := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp only [rotationFactor,Matrix.of_apply,Matrix.cons_val_zero,Matrix.cons_val_one,
        Matrix.cons_val_fin_one,Matrix.smul_apply,smul_eq_mul,Real.cos_neg,Real.sin_neg,
        Real.cos_add_int_mul_pi,Real.sin_add_int_mul_pi] <;> norm_num
  have hsgn : (-1:ℝ)^m*(-1:ℝ)^m=1 := by rw [← mul_zpow];norm_num
  have hrot : rotatedFrame (((-1:ℝ)^m) • B) (b+(m:ℝ)*Real.pi)=rotatedFrame B b := by
    simp only [rotatedFrame,hR,Matrix.smul_mul,Matrix.mul_smul,smul_smul,hsgn,one_smul]
  simp only [frameLift,hrot]
  ring

end UAMODraft.PositiveAngle

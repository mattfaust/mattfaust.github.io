import UAMODraft.ProfileEstimates

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix Filter
open scoped Topology

theorem analyticFrame_bounds (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖≤1/4) (θ : ℝ) (i j : Fin 2) :
    ‖analyticFrame m x θ i j‖≤4 ∧ ‖analyticFrameInverse m x θ i j‖≤4 := by
  have hs :=sqrt_signature_bounds (physicalProfile m x θ)
    (show 0≤profileBoundConstant m*‖x‖ by unfold profileBoundConstant;positivity) hx
    (by simpa using physicalProfile_near_e1 m hm x θ 0)
    (by simpa using physicalProfile_near_e1 m hm x θ 1)
  have hs0 : 0<Real.sqrt (profileSignature (physicalProfile m x θ)) :=by linarith [hs.1]
  have hsInv : ‖(Real.sqrt (profileSignature (physicalProfile m x θ)):ℂ)⁻¹‖≤2 :=by
    rw [norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hs0,inv_eq_one_div]
    apply (div_le_iff₀ hs0).mpr
    linarith [hs.1]
  have hv (s:Fin 2) : ‖physicalProfile m x θ s‖≤2 :=by
    have hh:=physicalProfile_near_e1 m hm x θ s
    have ht:=norm_add_le (physicalProfile m x θ s-(if s=0 then 1 else 0))
      (if s=0 then (1:ℂ) else 0)
    have hb : ‖(if s=0 then (1:ℂ) else 0)‖≤1 :=by split_ifs <;> norm_num
    rw [sub_add_cancel] at ht
    linarith
  have hr : ‖frameRaw (physicalProfile m x θ) (halfPhase m θ) i j‖≤2 :=by
    fin_cases i <;> fin_cases j <;> simpa [frameRaw,norm_mul,halfPhase_norm] using hv _
  have ha : ‖frameAdjugate (physicalProfile m x θ) (halfPhase m θ) i j‖≤2 :=by
    fin_cases i <;> fin_cases j <;> simpa [frameAdjugate,norm_mul,halfPhase_norm] using hv _
  constructor
  · simp only [analyticFrame,normalizedFrame,Matrix.smul_apply,smul_eq_mul,norm_mul]
    nlinarith [mul_le_mul hsInv hr (norm_nonneg _) (by norm_num : (0:ℝ)≤2)]
  · simp only [analyticFrameInverse,normalizedFrameInverse,Matrix.smul_apply,smul_eq_mul,norm_mul]
    nlinarith [mul_le_mul hsInv ha (norm_nonneg _) (by norm_num : (0:ℝ)≤2)]

theorem branch_uniform_frame_small {m : ℕ} (x : ℝ→Variables m)
    (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0) :
    ∀ᶠ lam in nhds 0, profileBoundConstant m*‖x lam‖<1/4 := by
  have hc : ContinuousAt (fun lam=>profileBoundConstant m*‖x lam‖) 0 :=
    hxa.continuousAt.norm.const_mul _
  exact hc.eventually (gt_mem_nhds (by simp [hx0]))

end UAMODraft.OddSeed

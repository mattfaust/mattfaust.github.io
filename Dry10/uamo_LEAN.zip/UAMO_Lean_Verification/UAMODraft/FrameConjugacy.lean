import UAMODraft.ProfileFrame
import UAMO.BoundarySeedNormalForm

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix Filter
open scoped Topology

def analyticResidual (m : ℕ) (hm : 0<m) (z : ℂ) (α lam : ℝ)
    (x : Variables m) (θ : ℝ) : Fin 2→ℂ :=
  boundaryNumerator lam (phaseCenter m hm z x) θ*ᵥphysicalProfile m x θ-
    (z*(amplitude m hm x:ℂ)) • physicalProfile m x (θ+α)

def analyticTransformed (m : ℕ) (hm : 0<m) (z : ℂ) (α lam : ℝ)
    (x : Variables m) (θ : ℝ) : CMV.TransferMatrix :=
  analyticFrameInverse m x (θ+α)*boundarySzego lam (phaseCenter m hm z x) θ*
    analyticFrame m x θ

def analyticDiagonal (m : ℕ) (hm : 0<m) (α lam σ : ℝ)
    (x : Variables m) (θ : ℝ) : ℝ :=
  σ*amplitude m hm x*Real.sqrt (profileSignature (physicalProfile m x (θ+α)))/
    (realTransferDenominator lam (2*Real.pi*θ)*
      Real.sqrt (profileSignature (physicalProfile m x θ)))

theorem phaseCenter_norm (m : ℕ) (hm : 0<m) (z : ℂ) (x : Variables m) :
    ‖phaseCenter m hm z x‖=‖z‖ := by
  simp only [phaseCenter,norm_mul,mul_comm Complex.I,
    Complex.norm_exp_ofReal_mul_I,mul_one]

theorem analyticTransformed_residual (m : ℕ) (hm : 0<m) (α lam : ℝ) (ell : ℤ)
    (x : Variables m) (θ : ℝ)
    (hp : 0<profileSignature (physicalProfile m x (θ+α))) :
    analyticTransformed m hm (resonantPhase α m ell) α lam x θ=
      (analyticDiagonal m hm α lam (liftSign ell) x θ:ℂ) • 1+
      ((realTransferDenominator lam (2*Real.pi*θ)*
        Real.sqrt (profileSignature (physicalProfile m x θ)):ℝ):ℂ)⁻¹ •
      (analyticFrameInverse m x (θ+α)*
        frameRaw (analyticResidual m hm (resonantPhase α m ell) α lam x θ) (halfPhase m θ)) := by
  have hz : ‖phaseCenter m hm (resonantPhase α m ell) x‖=1 := by
    rw [phaseCenter_norm,resonantPhase_norm]
  have he : conjugateMatrix (phaseCenter m hm (resonantPhase α m ell) x)
      (-(lam*Real.sin (2*Real.pi*θ):ℝ))*ᵥphysicalProfile m x θ=
      ((resonantPhase α m ell)*(amplitude m hm x:ℂ)) • physicalProfile m x (θ+α)+
        analyticResidual m hm (resonantPhase α m ell) α lam x θ := by
    rw [← boundaryNumerator_conjugateMatrix lam hz θ]
    unfold analyticResidual
    abel
  have h := normalizedFrame_residual_conjugacy
    (phaseCenter m hm (resonantPhase α m ell) x) (-(lam*Real.sin (2*Real.pi*θ):ℝ))
    (physicalProfile m x θ) (physicalProfile m x (θ+α))
    (analyticResidual m hm (resonantPhase α m ell) α lam x θ)
    (halfPhase m θ) (halfPhase m (θ+α))
    (resonantPhase α m ell*(amplitude m hm x:ℂ))
    (liftSign ell*amplitude m hm x) (realTransferDenominator lam (2*Real.pi*θ))
    (halfPhase_norm m (θ+α)) hp he
    (halfPhase_center_cancellation α m ell (amplitude m hm x) θ)
  simpa only [analyticTransformed,analyticDiagonal,analyticFrame,analyticFrameInverse,
    boundarySzego,← boundaryNumerator_conjugateMatrix lam hz θ] using h

theorem analyticFrameInverse_SU11 (m : ℕ) (x : Variables m) (θ : ℝ)
    (hp : 0<profileSignature (physicalProfile m x θ)) :
    SU11Form (analyticFrameInverse m x θ) := by
  refine ⟨?_,?_,?_⟩
  · simp [analyticFrameInverse,normalizedFrameInverse,frameAdjugate,Complex.star_def]
  · simp [analyticFrameInverse,normalizedFrameInverse,frameAdjugate,Complex.star_def]
  · have h := congrArg Matrix.det (normalizedFrame_mul_inverse
      (physicalProfile m x θ) (halfPhase m θ) (halfPhase_norm m θ) hp)
    rw [Matrix.det_mul,normalizedFrame_det _ _ (halfPhase_norm m θ) hp,
      one_mul,Matrix.det_one] at h
    exact h

theorem analyticTransformed_SU11 (m : ℕ) (hm : 0<m) {z : ℂ} (hz : ‖z‖=1)
    (α : ℝ) {lam : ℝ} (hlam : 0≤lam) (hlam1 : lam<1)
    (x : Variables m) (θ : ℝ)
    (hp : 0<profileSignature (physicalProfile m x θ))
    (hpp : 0<profileSignature (physicalProfile m x (θ+α))) :
    SU11Form (analyticTransformed m hm z α lam x θ) := by
  exact SU11Form_mul (SU11Form_mul (analyticFrameInverse_SU11 m x (θ+α) hpp)
    (boundarySzego_SU11 hlam hlam1 (by rw [phaseCenter_norm];exact hz) θ))
    (normalizedFrame_SU11 _ _ (halfPhase_norm m θ) hp)

end UAMODraft.OddSeed

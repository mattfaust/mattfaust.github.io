import UAMODraft.FrameDegree

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix
open scoped Topology

theorem analyticProfile_signature_positive (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (θ : ℝ) :
    0<profileSignature (physicalProfile m x θ) := by
  have hh :=(profileSignature_bounds (physicalProfile m x θ)
    (show 0≤profileBoundConstant m*‖x‖ by unfold profileBoundConstant;positivity) hx.le
    (by simpa using physicalProfile_near_e1 m hm x θ 0)
    (by simpa using physicalProfile_near_e1 m hm x θ 1)).1
  linarith

theorem continuous_analyticFrame (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) : Continuous (analyticFrame m x) := by
  have hv :=continuous_physicalProfile m hm x
  have hv0 :=(continuous_apply 0).comp hv
  have hv1 :=(continuous_apply 1).comp hv
  have hg :=continuous_halfPhase m
  have hs : Continuous (fun θ=>Real.sqrt (profileSignature (physicalProfile m x θ))) :=by
    unfold profileSignature
    fun_prop
  have hsi : Continuous (fun θ=>(Real.sqrt (profileSignature (physicalProfile m x θ)):ℂ)⁻¹) :=
    (Complex.continuous_ofReal.comp hs).inv₀ (fun θ=>Complex.ofReal_ne_zero.mpr
      (Real.sqrt_pos.mpr (analyticProfile_signature_positive m hm x hx θ)).ne')
  have hr : Continuous (fun θ=>frameRaw (physicalProfile m x θ) (halfPhase m θ)) :=by
    apply continuous_pi
    intro i
    apply continuous_pi
    intro j
    fin_cases i <;> fin_cases j <;>
      simp only [frameRaw,Matrix.of_apply,Fin.zero_eta,Fin.mk_one,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one]
    all_goals fun_prop
  exact hsi.smul hr

theorem continuous_realAnalyticFrame (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (γ : ℝ) : Continuous (realAnalyticFrame m x γ) := by
  have hb : Continuous (fun θ=>seedCayleyInverse 1*analyticFrame m x θ*seedCayley (constantPhase γ)) :=
    (continuous_const.mul (continuous_analyticFrame m hm x hx)).mul continuous_const
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  exact Complex.continuous_re.comp ((continuous_apply j).comp ((continuous_apply i).comp hb))

theorem analyticFrame_add_one (m : ℕ) (x : Variables m) (θ : ℝ) :
    analyticFrame m x (θ+1)=(((-1:ℝ)^m:ℝ):ℂ) • analyticFrame m x θ := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [analyticFrame,normalizedFrame,frameRaw,physicalProfile_periodic,halfPhase_add_one,
      Complex.star_def,map_mul,map_pow] <;> ring

theorem realAnalyticFrame_add_one (m : ℕ) (x : Variables m) (γ θ : ℝ) :
    realAnalyticFrame m x γ (θ+1)=(-1:ℝ)^m • realAnalyticFrame m x γ θ := by
  change (seedCayleyInverse 1*analyticFrame m x (θ+1)*seedCayley (constantPhase γ)).map Complex.re=_
  rw [analyticFrame_add_one,Matrix.mul_smul,Matrix.smul_mul]
  ext i j
  simp only [realAnalyticFrame,realFrameOf,analyticFrame,Matrix.map_apply,Matrix.smul_apply,
    smul_eq_mul,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]

theorem analytic_frame_degree_data (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (γ : ℝ) :
    Continuous (realAnalyticFrame m x γ) ∧ Continuous (realAnalyticFrameAngle m x γ) ∧
    (∀ θ:ℝ,(realAnalyticFrame m x γ θ).det=1) ∧
    (∀ θ:ℝ, realAnalyticFrame m x γ (θ+1)=(-1:ℝ)^m • realAnalyticFrame m x γ θ) ∧
    (∀ θ:ℝ, realAnalyticFrameAngle m x γ (θ+1)=realAnalyticFrameAngle m x γ θ+(m:ℝ)*Real.pi) ∧
    ∀ θ:ℝ,∃ r:ℝ,0<r ∧
      realAnalyticFrame m x γ θ 0 0=r*Real.cos (realAnalyticFrameAngle m x γ θ) ∧
      realAnalyticFrame m x γ θ 1 0=r*Real.sin (realAnalyticFrameAngle m x γ θ) := by
  exact ⟨continuous_realAnalyticFrame m hm x hx γ,continuous_realAnalyticFrameAngle m hm x hx γ,
    fun θ=>realFrameOf_det _ (halfPhase_norm m θ) (constantPhase_norm γ)
      (analyticProfile_signature_positive m hm x hx θ),
    realAnalyticFrame_add_one m x γ,realAnalyticFrameAngle_degree m x γ,
    realAnalyticFrame_first_column m hm x hx γ⟩

end UAMODraft.OddSeed

import UAMODraft.RealFrameAlgebra

noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Matrix
open scoped Topology

def constantPhase (γ : ℝ) : ℂ :=Complex.exp ((γ:ℂ)*Complex.I)

theorem constantPhase_norm (γ : ℝ) : ‖constantPhase γ‖=1 :=
  Complex.norm_exp_ofReal_mul_I γ

def correctedColumn (m : ℕ) (x : Variables m) (γ θ : ℝ) : ℂ :=
  physicalProfile m x θ 0+star (halfPhase m θ)^2*constantPhase γ^2*star (physicalProfile m x θ 1)

def realAnalyticFrame (m : ℕ) (x : Variables m) (γ θ : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  realFrameOf (physicalProfile m x θ) (halfPhase m θ) (constantPhase γ)

def realAnalyticFrameAngle (m : ℕ) (x : Variables m) (γ θ : ℝ) : ℝ :=
  Real.pi*(m:ℝ)*θ-γ+Complex.arg (correctedColumn m x γ θ)

theorem correctedColumn_periodic (m : ℕ) (x : Variables m) (γ θ : ℝ) :
    correctedColumn m x γ (θ+1)=correctedColumn m x γ θ := by
  simp only [correctedColumn,physicalProfile_periodic,halfPhase_add_one,
    Complex.star_def,map_mul,map_pow,map_neg,map_one,mul_pow]
  have he : ((-1:ℂ)^m)^2=1 := by rw [← pow_mul,mul_comm m 2,pow_mul];norm_num
  rw [he,one_mul]

theorem continuous_correctedColumn (m : ℕ) (hm : 0<m) (x : Variables m) (γ : ℝ) :
    Continuous (correctedColumn m x γ) := by
  exact ((continuous_apply 0).comp (continuous_physicalProfile m hm x)).add
    ((((continuous_halfPhase m).star.pow 2).mul continuous_const).mul
      (((continuous_apply 1).comp (continuous_physicalProfile m hm x)).star))

theorem correctedColumn_near_one (m : ℕ) (hm : 0<m) (x : Variables m) (γ θ : ℝ) :
    ‖correctedColumn m x γ θ-1‖≤2*(profileBoundConstant m*‖x‖) := by
  have he : correctedColumn m x γ θ-1=(physicalProfile m x θ 0-1)+
    star (halfPhase m θ)^2*constantPhase γ^2*star (physicalProfile m x θ 1) := by
    unfold correctedColumn;ring
  rw [he]
  have h0 :=physicalProfile_near_e1 m hm x θ 0
  have h1 :=physicalProfile_near_e1 m hm x θ 1
  simp only [if_true] at h0
  simp only [show (1:Fin 2)≠0 by decide,if_false,sub_zero] at h1
  have hh :=norm_add_le (physicalProfile m x θ 0-1)
    (star (halfPhase m θ)^2*constantPhase γ^2*star (physicalProfile m x θ 1))
  simp only [norm_mul,norm_pow,norm_star,halfPhase_norm,constantPhase_norm,one_pow,one_mul] at hh
  linarith

theorem correctedColumn_re_pos (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (γ θ : ℝ) :
    0<(correctedColumn m x γ θ).re := by
  have hh :=(Complex.abs_re_le_norm (correctedColumn m x γ θ-1)).trans
    (correctedColumn_near_one m hm x γ θ)
  simp only [Complex.sub_re,Complex.one_re] at hh
  have hl :=(abs_le.mp hh).1
  linarith

theorem continuous_realAnalyticFrameAngle (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (γ : ℝ) :
    Continuous (realAnalyticFrameAngle m x γ) := by
  apply Continuous.add (by fun_prop)
  apply continuous_iff_continuousAt.mpr
  intro θ
  exact (Complex.continuousAt_arg (Or.inl (correctedColumn_re_pos m hm x hx γ θ))).comp
    (continuous_correctedColumn m hm x γ).continuousAt

theorem realAnalyticFrameAngle_degree (m : ℕ) (x : Variables m) (γ θ : ℝ) :
    realAnalyticFrameAngle m x γ (θ+1)=realAnalyticFrameAngle m x γ θ+(m:ℝ)*Real.pi := by
  simp only [realAnalyticFrameAngle,correctedColumn_periodic]
  ring

theorem firstColumn_factorization (v : Fin 2→ℂ) {g ξ : ℂ} (hg : ‖g‖=1) (hξ : ‖ξ‖=1) :
    firstColumnComplex v g ξ=g*star ξ*(v 0+star g^2*ξ^2*star (v 1)) := by
  have hgg : g*star g=1 :=by simp [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq,hg]
  have hξξ : ξ*star ξ=1 :=by simp [Complex.star_def,Complex.mul_conj,Complex.normSq_eq_norm_sq,hξ]
  simp only [firstColumnComplex,Complex.star_def,map_mul] at ⊢ hgg hξξ
  linear_combination -starRingEnd ℂ g*ξ*starRingEnd ℂ (v 1)*hgg-
    g*starRingEnd ℂ g^2*ξ*starRingEnd ℂ (v 1)*hξξ

theorem firstColumn_polar (m : ℕ) (x : Variables m) (γ θ : ℝ) :
    firstColumnComplex (physicalProfile m x θ) (halfPhase m θ) (constantPhase γ)=
      (‖correctedColumn m x γ θ‖:ℂ)*
        Complex.exp ((realAnalyticFrameAngle m x γ θ:ℂ)*Complex.I) := by
  rw [firstColumn_factorization _ (halfPhase_norm m θ) (constantPhase_norm γ)]
  change halfPhase m θ*star (constantPhase γ)*correctedColumn m x γ θ=_
  conv_lhs => rw [← Complex.norm_mul_exp_arg_mul_I (correctedColumn m x γ θ)]
  have he : halfPhase m θ*star (constantPhase γ)*
      Complex.exp ((Complex.arg (correctedColumn m x γ θ):ℂ)*Complex.I)=
      Complex.exp ((realAnalyticFrameAngle m x γ θ:ℂ)*Complex.I) := by
    simp only [halfPhase,constantPhase,Complex.star_def,← Complex.exp_conj,map_mul,
      Complex.conj_ofReal,Complex.conj_I,← Complex.exp_add]
    congr 1
    unfold realAnalyticFrameAngle
    push_cast
    ring
  calc
    _ = (‖correctedColumn m x γ θ‖:ℂ)*(halfPhase m θ*star (constantPhase γ)*
      Complex.exp ((Complex.arg (correctedColumn m x γ θ):ℂ)*Complex.I)) :=by ring
    _ = _ :=by rw [he]

theorem realAnalyticFrame_first_column (m : ℕ) (hm : 0<m) (x : Variables m)
    (hx : profileBoundConstant m*‖x‖<1/4) (γ θ : ℝ) :
    ∃ r : ℝ, 0<r ∧
      realAnalyticFrame m x γ θ 0 0=r*Real.cos (realAnalyticFrameAngle m x γ θ) ∧
      realAnalyticFrame m x γ θ 1 0=r*Real.sin (realAnalyticFrameAngle m x γ θ) := by
  have hc : correctedColumn m x γ θ≠0 :=by
    intro hc
    have hh :=correctedColumn_re_pos m hm x hx γ θ
    simp only [hc,Complex.zero_re,lt_self_iff_false] at hh
  have hp : 0<profileSignature (physicalProfile m x θ) :=by
    have hh :=(profileSignature_bounds (physicalProfile m x θ)
      (show 0≤profileBoundConstant m*‖x‖ by unfold profileBoundConstant;positivity) hx.le
      (by simpa using physicalProfile_near_e1 m hm x θ 0)
      (by simpa using physicalProfile_near_e1 m hm x θ 1)).1
    linarith
  let r:=‖correctedColumn m x γ θ‖/Real.sqrt (profileSignature (physicalProfile m x θ))
  refine ⟨r,div_pos (norm_pos_iff.mpr hc) (Real.sqrt_pos.mpr hp),?_,?_⟩
  all_goals
    have hh :=realFrameOf_first_column (physicalProfile m x θ) (halfPhase m θ) (constantPhase γ)
    rw [firstColumn_polar] at hh
    simp only [Complex.mul_re,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,
      zero_mul,sub_zero,add_zero,Complex.exp_mul_I,Complex.add_re,Complex.add_im,
      Complex.ofReal_re,Complex.ofReal_im,Complex.mul_re,Complex.mul_im,
      Complex.I_re,Complex.I_im,mul_zero,mul_one,sub_zero,zero_add,
      ← Complex.ofReal_cos,← Complex.ofReal_sin,Complex.ofReal_re,Complex.ofReal_im,
      sub_zero,add_zero,zero_add] at hh
  · change _=r*_
    unfold realAnalyticFrame
    rw [hh.1]
    dsimp [r]
    ring
  · change _=r*_
    unfold realAnalyticFrame
    rw [hh.2]
    dsimp [r]
    ring

end UAMODraft.OddSeed

import UAMODraft.CoverProducts

noncomputable section
namespace UAMODraft.CoverHyperbolicity
open UAMODraft.PositiveCone Matrix

def stableProjector (u s:Vec) : Mat :=
  frameMatrix u s * !![0,0;0,1] * (frameMatrix u s)⁻¹

def unstablePart (u s v:Vec) : Vec := ((frameMatrix u s)⁻¹*ᵥv) 0 • u
def stablePart (u s v:Vec) : Vec := ((frameMatrix u s)⁻¹*ᵥv) 1 • s

theorem frameMatrix_mulVec' (u s v:Vec) : frameMatrix u s*ᵥv=v 0 • u+v 1 • s := by
  ext i
  fin_cases i <;> simp [frameMatrix,Matrix.mulVec,dotProduct,Fin.sum_univ_two] <;> ring

theorem frame_decomposition (u s v:Vec) (h:IsUnit (frameMatrix u s)) :
    v=unstablePart u s v+stablePart u s v := by
  have hi:=Matrix.mul_nonsing_inv (frameMatrix u s) ((Matrix.isUnit_iff_isUnit_det _).mp h)
  unfold unstablePart stablePart
  rw [←frameMatrix_mulVec',Matrix.mulVec_mulVec,hi,Matrix.one_mulVec]

theorem stableProjector_apply (u s v:Vec) : stableProjector u s*ᵥv=stablePart u s v := by
  rw [stableProjector,←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec,frameMatrix_mulVec']
  simp [stablePart,Matrix.mulVec,dotProduct,Fin.sum_univ_two]

theorem stableProjector_u (u s:Vec) (h:IsUnit (frameMatrix u s)) : stableProjector u s*ᵥu=0 := by
  have hcol : frameMatrix u s*ᵥ(![1,0]:Vec)=u := by simp [frameMatrix_mulVec']
  calc
    _=stableProjector u s*ᵥ(frameMatrix u s*ᵥ(![1,0]:Vec)) := by rw [hcol]
    _=0 := by
      rw [stableProjector,Matrix.mulVec_mulVec]
      have hi:=Matrix.nonsing_inv_mul (frameMatrix u s) ((Matrix.isUnit_iff_isUnit_det _).mp h)
      rw [mul_assoc,hi,mul_one,←Matrix.mulVec_mulVec]
      have hz : (!![0,0;0,1]:Mat)*ᵥ(![1,0]:Vec)=0 := by
        ext i;fin_cases i <;> simp [Matrix.mulVec,dotProduct,Fin.sum_univ_two]
      rw [hz,Matrix.mulVec_zero]

theorem stableProjector_s (u s:Vec) (h:IsUnit (frameMatrix u s)) : stableProjector u s*ᵥs=s := by
  have hcol : frameMatrix u s*ᵥ(![0,1]:Vec)=s := by simp [frameMatrix_mulVec']
  calc
    _=stableProjector u s*ᵥ(frameMatrix u s*ᵥ(![0,1]:Vec)) := by rw [hcol]
    _=s := by
      rw [stableProjector,Matrix.mulVec_mulVec]
      have hi:=Matrix.nonsing_inv_mul (frameMatrix u s) ((Matrix.isUnit_iff_isUnit_det _).mp h)
      rw [mul_assoc,hi,mul_one,←Matrix.mulVec_mulVec]
      simpa [Matrix.mulVec,dotProduct,Fin.sum_univ_two] using hcol

theorem matrix_eq_of_mulVec_eq {P Q:Mat} (h:∀v:Vec,P*ᵥv=Q*ᵥv) : P=Q := by
  ext i j
  have hh:=congrFun (h (Pi.single j 1)) i
  simpa using hh

theorem stableProjector_idempotent (u s:Vec) (h:IsUnit (frameMatrix u s)) :
    stableProjector u s*stableProjector u s=stableProjector u s := by
  apply matrix_eq_of_mulVec_eq
  intro v
  have hs:=stableProjector_apply u s v
  rw [←Matrix.mulVec_mulVec,hs]
  dsimp only [stablePart]
  rw [Matrix.mulVec_smul,stableProjector_s u s h]

end UAMODraft.CoverHyperbolicity

import UAMODraft.RealConjugacy
import UAMODraft.PositiveQuarterTurn
noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed UAMO.ProjectiveAngle Matrix

theorem seedCayley_phase_rotation (γ t : ℝ) :
    seedCayley (constantPhase γ)*(rotationFactor t).map Complex.ofReal=
      seedCayley (constantPhase (γ-t)) := by
  ext i j
  fin_cases i <;> fin_cases j <;> apply Complex.ext <;>
    simp [seedCayley,constantPhase,rotationFactor,Matrix.mul_apply,Fin.sum_univ_two,
      Complex.star_def,Complex.exp_mul_I,← Complex.ofReal_cos,← Complex.ofReal_sin,
      Real.cos_sub,Real.sin_sub,Complex.cos_sub,Complex.sin_sub] <;> ring

theorem realAnalyticFrame_rotation (m : ℕ) (x : Variables m) (γ t θ : ℝ) :
    realAnalyticFrame m x (γ-t) θ=realAnalyticFrame m x γ θ*rotationFactor t :=by
  have hmap : (realAnalyticFrame m x (γ-t) θ).map Complex.ofReal=
      (realAnalyticFrame m x γ θ*rotationFactor t).map Complex.ofReal :=by
    change (realAnalyticFrame m x (γ-t) θ).map Complex.ofRealHom=
      (realAnalyticFrame m x γ θ*rotationFactor t).map Complex.ofRealHom
    rw [Matrix.map_mul]
    change (realFrameOf (physicalProfile m x θ) (halfPhase m θ) (constantPhase (γ-t))).map Complex.ofReal=
      (realFrameOf (physicalProfile m x θ) (halfPhase m θ) (constantPhase γ)).map Complex.ofReal*
        (rotationFactor t).map Complex.ofReal
    rw [realFrameOf_map,realFrameOf_map,mul_assoc,mul_assoc,seedCayley_phase_rotation]
    simp only [mul_assoc]
  ext i j
  exact Complex.ofReal_injective (congrFun (congrFun hmap i) j)

theorem realAnalyticFrame_quarterTurn (m : ℕ) (x : Variables m) (γ θ : ℝ) :
    realAnalyticFrame m x (γ+Real.pi/4) θ=realAnalyticFrame m x γ θ*quarterTurn :=by
  simpa only [sub_neg_eq_add,quarterTurn] using
    realAnalyticFrame_rotation m x γ (-(Real.pi/4)) θ

end UAMODraft.OddSeed

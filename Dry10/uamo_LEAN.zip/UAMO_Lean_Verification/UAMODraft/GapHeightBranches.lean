import UAMODraft.GapHeightComponents

noncomputable section
namespace UAMODraft
set_option maxHeartbeats 2000000
open UAMO Set Filter
open scoped Topology ContDiff

theorem IsScalarGap.component_eq {a r φ l u E : ℝ}
    (hgap : IsScalarGap a r φ l u) (hE : E ∈ Ioo l u) :
    connectedComponentIn {x : ℝ | (x:ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)} E =
      Ioo l u := by
  let R := {x : ℝ | (x:ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)}
  have hEin : E ∈ connectedComponentIn R E :=
    mem_connectedComponentIn (hgap.resolvent E hE)
  apply Set.Subset.antisymm
  · intro x hx
    constructor
    · by_contra hn
      have hxl : x≤l := le_of_not_gt hn
      have hl := isPreconnected_connectedComponentIn.Icc_subset hx hEin
        (show l ∈ Icc x E from ⟨hxl,hE.1.le⟩)
      exact hgap.left_spectral (connectedComponentIn_subset R E hl)
    · by_contra hn
      have hux : u≤x := le_of_not_gt hn
      have hu := isPreconnected_connectedComponentIn.Icc_subset hEin hx
        (show u ∈ Icc E x from ⟨hE.2.le,hux⟩)
      exact hgap.right_spectral (connectedComponentIn_subset R E hu)
  · exact (convex_Ioo l u).isPreconnected.subset_connectedComponentIn hE hgap.resolvent

theorem contDiffAt_infty_of_hasDerivAt {F g : ℝ → ℝ} {r : ℝ}
    (hd : ∀ᶠ t in 𝓝 r, HasDerivAt F (g t) t)
    (hg : ContDiffAt ℝ ∞ g r) : ContDiffAt ℝ ∞ F r := by
  rw [contDiffAt_infty]
  intro n
  have hn : ContDiffAt ℝ (n+1) F r := by
    apply contDiffAt_succ_iff_hasFDerivAt.mpr
    refine ⟨fun t => (1 : ℝ →L[ℝ] ℝ).smulRight (g t),?_,?_⟩
    · exact ⟨{t | HasDerivAt F (g t) t},hd,fun t ht => ht.hasFDerivAt⟩
    · exact contDiffAt_const.smulRight (hg.of_le (by exact_mod_cast (le_top : (n:ℕ∞) ≤ ⊤)))
  exact hn.of_le (by exact_mod_cast Nat.le_succ n)

theorem analytic_deriv_continuousAt {e : ℝ → ℝ} {r : ℝ}
    (he : ContDiffAt ℝ ⊤ e r) : ContinuousAt (deriv e) r := by
  have hD := (he.fderiv_right (m:=0) (by simp)).continuousAt
  simpa only [fderiv_deriv] using (ContinuousLinearMap.apply ℝ ℝ (1:ℝ)).continuous.continuousAt.comp hD

theorem centered_height_contDiffAt (a φ r : ℝ) (e : ℝ → ℝ)
    (he : ContDiffAt ℝ ⊤ e r)
    (hnear : ∀ᶠ t in 𝓝 r,
      (e t : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t φ) ∧
      scalarGreen a t φ (e t) = 0) :
    ContDiffAt ℝ ∞ (fun t => scalarLogPotential a t φ (e t)) r := by
  let g : ℝ → ℝ := fun t => -rootTraceReal
    (Ring.inverse (scalarJointPencil a φ (t,e t)) * scalarHamiltonianDerivative a t φ)
  have heNear : ∀ᶠ t in 𝓝 r, ContDiffAt ℝ ⊤ e t := he.eventually (by simp)
  have hd : ∀ᶠ t in 𝓝 r, HasDerivAt e (deriv e t) t := by
    filter_upwards [heNear] with t ht
    exact (ht.differentiableAt (by simp)).hasDerivAt
  have hheight : ∀ᶠ t in 𝓝 r,
      HasDerivAt (fun v => scalarLogPotential a v φ (e v)) (g t) t := by
    filter_upwards [hnear,heNear,hd.eventually_nhds] with t ht hs hdt
    have hh := scalarLogPotential_centered_branch_hasDerivAt a φ e (deriv e) t
      ht.1 ht.2 hdt (analytic_deriv_continuousAt hs)
    simpa only [(scalarLogPotential_coupling_hasDerivAt a t φ (e t) ht.1).deriv,
      g,scalarJointPencil_eq] using hh
  have hunit : IsUnit (scalarJointPencil a φ (r,e r)) := by
    rw [scalarJointPencil_eq]
    exact hnear.self_of_nhds.1
  have hinv : ContDiffAt ℝ ⊤ (Ring.inverse : MagneticOperator → MagneticOperator)
      (scalarJointPencil a φ (r,e r)) := by
    simpa only [hunit.unit_spec] using
      (contDiffAt_ringInverse ℝ (n:=(⊤ : WithTop ℕ∞)) hunit.unit)
  have hp : ContDiffAt ℝ ⊤ (fun t => scalarJointPencil a φ (t,e t)) r :=
    (scalarJointPencil_contDiff a φ).contDiffAt.comp r (contDiffAt_id.prodMk he)
  have hD : ContDiff ℝ ⊤ (fun t => scalarHamiltonianDerivative a t φ) := by
    unfold scalarHamiltonianDerivative
    fun_prop
  have hri : ContDiffAt ℝ ⊤ (fun t => Ring.inverse (scalarJointPencil a φ (t,e t))) r :=
    ContDiffAt.comp (f := fun t : ℝ => scalarJointPencil a φ (t,e t))
      (g := fun A : MagneticOperator => Ring.inverse A) r hinv hp
  have hg : ContDiffAt ℝ ⊤ g r := by
    simpa only [g,Function.comp_def] using
      (rootTraceReal.contDiff.contDiffAt.comp r (hri.mul hD.contDiffAt)).neg
  exact contDiffAt_infty_of_hasDerivAt hheight (hg.of_le le_top)

structure ScalarGapBranch (a φ : ℝ) (S : Set ℝ) where
  lower : ℝ → ℝ
  upper : ℝ → ℝ
  gap : ∀ r ∈ S, IsScalarGap a r φ (lower r) (upper r)
  local_cut : ∀ r ∈ S, ∃ c ∈ Ioo (lower r) (upper r),
    ∀ᶠ t in 𝓝[S] r, c ∈ Ioo (lower t) (upper t)

def ScalarGapBranch.height {a φ : ℝ} {S : Set ℝ} (B : ScalarGapBranch a φ S) (r : ℝ) : ℝ :=
  scalarGapHeight a r φ (B.lower r) (B.upper r)

theorem ScalarGapBranch.local_maximum_and_height {a α : ℝ} {S : Set ℝ}
    (B : ScalarGapBranch a (Real.pi*α) S) (hS : IsOpen S)
    (hparam : S ⊆ Ioo 0 a) (ha : 0<a) (ha1 : a≤1) (hα : Irrational α)
    {r : ℝ} (hrS : r ∈ S) :
    ∃ e : ℝ → ℝ, ContDiffAt ℝ ⊤ e r ∧
      (∀ᶠ t in 𝓝 r, e t ∈ Ioo (B.lower t) (B.upper t) ∧
        scalarGreen a t (Real.pi*α) (e t) = 0 ∧
        B.height t = scalarLogPotential a t (Real.pi*α) (e t)) ∧
      ContDiffAt ℝ ∞ B.height r ∧
      HasDerivAt B.height
        (deriv (fun t => scalarLogPotential a t (Real.pi*α) (e r)) r) r ∧
      r * deriv B.height r ∈ Icc (0:ℝ) 2 := by
  have hr := hparam hrS
  obtain ⟨E,hE,hzero,_,_,_,_⟩ := physical_scalarGap_maximum a r α
    (B.lower r) (B.upper r) ha ha1 hr.1 hr.2.le hα (B.gap r hrS)
  obtain ⟨e,he,hsmooth,hnear,_⟩ := scalarGreen_local_smooth_zero_branch a r (Real.pi*α) E
    ((B.gap r hrS).resolvent E hE) hzero
  obtain ⟨c,hc,hcut⟩ := B.local_cut r hrS
  have hnhds : 𝓝[S] r = 𝓝 r := nhdsWithin_eq_nhds.mpr (hS.mem_nhds hrS)
  rw [hnhds] at hcut
  have hneargap : ∀ᶠ t in 𝓝 r, IsScalarGap a t (Real.pi*α) (B.lower t) (B.upper t) := by
    filter_upwards [hS.mem_nhds hrS] with t ht
    exact B.gap t ht
  have hein : ∀ᶠ t in 𝓝 r, e t ∈ Ioo (B.lower t) (B.upper t) :=
    continuous_energy_stays_in_gap a r (Real.pi*α) B.lower B.upper e (B.gap r hrS)
      hneargap c hc hcut (by simpa only [he] using hE) hsmooth.continuousAt
  have hheight : ∀ᶠ t in 𝓝 r,
      B.height t = scalarLogPotential a t (Real.pi*α) (e t) := by
    filter_upwards [hS.mem_nhds hrS,hein,hnear] with t ht het hzt
    have hp := hparam ht
    exact scalarGap_height_eq_at_center a t (Real.pi*α) (B.lower t) (B.upper t) (e t)
      (B.gap t ht)
      (scalarTotalLogPotential_spectral_zero_pos_field ha ha1 hp.1 hp.2.le hα _
        (B.gap t ht).left_spectral)
      (scalarTotalLogPotential_spectral_zero_pos_field ha ha1 hp.1 hp.2.le hα _
        (B.gap t ht).right_spectral) het hzt.2
  have hd : ∀ᶠ t in 𝓝 r, HasDerivAt e (deriv e t) t := by
    filter_upwards [hsmooth.eventually (by simp)] with t ht
    exact (ht.differentiableAt (by simp)).hasDerivAt
  have hh := scalarLogPotential_centered_branch_hasDerivAt a (Real.pi*α) e (deriv e) r
    hnear.self_of_nhds.1 hnear.self_of_nhds.2 hd (analytic_deriv_continuousAt hsmooth)
  have hB := hh.congr_of_eventuallyEq hheight
  refine ⟨e,hsmooth,?_,?_,hB,?_⟩
  · filter_upwards [hein,hnear,hheight] with t hit hzt hht
    exact ⟨hit,hzt.2,hht⟩
  · exact (centered_height_contDiffAt a (Real.pi*α) r e hsmooth hnear).congr_of_eventuallyEq hheight
  · rw [hB.deriv]
    exact actual_scalarLogPotential_radial_derivative_bound a r α (e r) hα
      hnear.self_of_nhds.1 hnear.self_of_nhds.2

end UAMODraft

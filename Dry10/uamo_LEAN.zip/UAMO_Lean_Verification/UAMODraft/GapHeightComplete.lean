import UAMODraft.GapHeightMaximumByIntegration

noncomputable section
namespace UAMODraft
open UAMO Set Filter
open scoped Topology ContDiff InnerProductSpace
set_option maxHeartbeats 2000000

theorem ScalarGapBranch.full_height_theorem {a α : ℝ} {S : Set ℝ}
    (B : ScalarGapBranch a (Real.pi*α) S) (hS : IsOpen S)
    (hparam : S ⊆ Ioo 0 a) (ha : 0<a) (ha1 : a≤1) (hα : Irrational α)
    {r : ℝ} (hrS : r ∈ S) :
    ∃ e : ℝ → ℝ, ContDiffAt ℝ ⊤ e r ∧
      (∀ᶠ t in 𝓝 r, e t ∈ Ioo (B.lower t) (B.upper t) ∧
        scalarGreen a t (Real.pi*α) (e t) = 0 ∧
        0 < B.height t ∧
        B.height t = scalarLogPotential a t (Real.pi*α) (e t) ∧
        ∀ x ∈ Ioo (B.lower t) (B.upper t),
          scalarLogPotential a t (Real.pi*α) x ≤ B.height t ∧
          (scalarLogPotential a t (Real.pi*α) x = B.height t ↔ x=e t) ∧
          (scalarGreen a t (Real.pi*α) x = 0 ↔ x=e t)) ∧
      ContDiffAt ℝ ∞ B.height r ∧
      HasDerivAt B.height
        (deriv (fun t => scalarLogPotential a t (Real.pi*α) (e r)) r) r ∧
      r * deriv B.height r ∈ Icc (0:ℝ) 2 ∧
      ((r * deriv B.height r : ℝ) : ℂ) =
        -⟪magneticOrigin,resolvent (scalarHamiltonian a r (Real.pi*α)) (e r:ℂ)
          ((r • scalarHamiltonianDerivative a r (Real.pi*α)) magneticOrigin)⟫_ℂ := by
  have hr := hparam hrS
  obtain ⟨E,hE,hzero,_,_,_,_⟩ := physical_scalarGap_maximum_by_integration a r α
    (B.lower r) (B.upper r) ha ha1 hr.1 hr.2.le hα (B.gap r hrS)
  obtain ⟨e,he,hsmooth,hnear,_⟩ := scalarGreen_local_smooth_zero_branch a r (Real.pi*α) E
    ((B.gap r hrS).resolvent E hE) hzero
  obtain ⟨c,hc,hcut⟩ := B.local_cut r hrS
  have hnhds : 𝓝[S] r = 𝓝 r := nhdsWithin_eq_nhds.mpr (hS.mem_nhds hrS)
  rw [hnhds] at hcut
  have hneargap : ∀ᶠ t in 𝓝 r, IsScalarGap a t (Real.pi*α) (B.lower t) (B.upper t) := by
    filter_upwards [hS.mem_nhds hrS] with t ht
    exact B.gap t ht
  have hein : ∀ᶠ t in 𝓝 r, e t ∈ Ioo (B.lower t) (B.upper t) :=
    continuous_energy_stays_in_gap a r (Real.pi*α) B.lower B.upper e (B.gap r hrS)
      hneargap c hc hcut (by simpa only [he] using hE) hsmooth.continuousAt
  have hmax : ∀ᶠ t in 𝓝 r, e t ∈ Ioo (B.lower t) (B.upper t) ∧
      scalarGreen a t (Real.pi*α) (e t) = 0 ∧
      0 < B.height t ∧ B.height t = scalarLogPotential a t (Real.pi*α) (e t) ∧
      ∀ x ∈ Ioo (B.lower t) (B.upper t),
        scalarLogPotential a t (Real.pi*α) x ≤ B.height t ∧
        (scalarLogPotential a t (Real.pi*α) x = B.height t ↔ x=e t) ∧
        (scalarGreen a t (Real.pi*α) x = 0 ↔ x=e t) := by
    filter_upwards [hS.mem_nhds hrS,hein,hnear] with t ht het hzt
    have hp := hparam ht
    obtain ⟨Et,hEt,_,hpos,hheight,hbound,hchar⟩ := physical_scalarGap_maximum_by_integration
      a t α (B.lower t) (B.upper t) ha ha1 hp.1 hp.2.le hα (B.gap t ht)
    have heq : e t=Et := (hchar (e t) het).2.mp hzt.2
    refine ⟨het,hzt.2,hpos,?_,?_⟩
    · exact hheight.trans (congrArg (scalarLogPotential a t (Real.pi*α)) heq.symm)
    · intro x hx
      exact ⟨hbound x hx,by simpa only [heq] using hchar x hx⟩
  have hheight : ∀ᶠ t in 𝓝 r,
      B.height t = scalarLogPotential a t (Real.pi*α) (e t) := by
    filter_upwards [hmax] with t ht
    exact ht.2.2.2.1
  have hd : ∀ᶠ t in 𝓝 r, HasDerivAt e (deriv e t) t := by
    filter_upwards [hsmooth.eventually (by simp)] with t ht
    exact (ht.differentiableAt (by simp)).hasDerivAt
  have hh := scalarLogPotential_centered_branch_hasDerivAt a (Real.pi*α) e (deriv e) r
    hnear.self_of_nhds.1 hnear.self_of_nhds.2 hd (analytic_deriv_continuousAt hsmooth)
  have hB := hh.congr_of_eventuallyEq hheight
  refine ⟨e,hsmooth,hmax,?_,hB,?_,?_⟩
  · exact (centered_height_contDiffAt a (Real.pi*α) r e hsmooth hnear).congr_of_eventuallyEq hheight
  · rw [hB.deriv]
    exact actual_scalarLogPotential_radial_derivative_bound a r α (e r) hα
      hnear.self_of_nhds.1 hnear.self_of_nhds.2
  · rw [hB.deriv,Complex.ofReal_mul,
      scalarLogPotential_coupling_deriv_complex a r (Real.pi*α) (e r)
        hnear.self_of_nhds.1]
    simp only [ContinuousLinearMap.smul_apply,←Complex.coe_smul,map_smul,
      inner_smul_right,mul_neg]

end UAMODraft

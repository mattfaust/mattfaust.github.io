import UAMO.ScalarInternalSeed
import UAMO.ScalarSpectralBaseline
import UAMODraft.SmoothBranch
import Mathlib.Topology.Compactness.Compact

noncomputable section
namespace UAMODraft
open UAMO Set Filter
open scoped Topology

structure IsScalarGap (a r φ l u : ℝ) : Prop where
  lt : l < u
  left_spectral : (l : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)
  right_spectral : (u : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)
  resolvent : ∀ E ∈ Ioo l u, (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)

def scalarGapHeight (a r φ l u : ℝ) : ℝ :=
  sSup (scalarLogPotential a r φ '' Ioo l u)

theorem scalarGap_maximum (a r φ l u : ℝ) (hgap : IsScalarGap a r φ l u)
    (hl : scalarTotalLogPotential a φ (r,l) = 0)
    (hu : scalarTotalLogPotential a φ (r,u) = 0) :
    ∃ E ∈ Ioo l u, scalarGreen a r φ E = 0 ∧
      0 < scalarLogPotential a r φ E ∧
      scalarGapHeight a r φ l u = scalarLogPotential a r φ E ∧
      (∀ x ∈ Ioo l u, scalarLogPotential a r φ x ≤ scalarLogPotential a r φ E) ∧
      (∀ x ∈ Ioo l u, scalarGreen a r φ x = 0 → x = E) := by
  have heq : ∀ x ∈ Ioo l u,
      scalarPositiveLogPotential a φ (r,x) = scalarLogPotential a r φ x := by
    intro x hx
    rw [scalarPositiveLogPotential_eq_max a φ r x (hgap.resolvent x hx),
      max_eq_right (scalarLogPotential_nonneg_on_gap a φ r hgap.lt hgap.resolvent hl hu hx)]
  obtain ⟨E,hE,hpos,hzero,hmax,_,huniq⟩ := scalar_seed_gap_unique_positive_maximum
    a r φ hgap.lt hgap.resolvent (fun x => scalarPositiveLogPotential a φ (r,x)) heq
    (scalarPositiveLogPotential_continuousOn_gap a φ r hgap.resolvent hl hu)
    (scalarPositiveLogPotential_eq_zero_of_total_eq_zero a φ (r,l) hl)
    (scalarPositiveLogPotential_eq_zero_of_total_eq_zero a φ (r,u) hu)
  have hbound : ∀ x ∈ Ioo l u,
      scalarLogPotential a r φ x ≤ scalarLogPotential a r φ E := by
    intro x hx
    have hh := hmax ⟨hx.1.le,hx.2.le⟩
    change scalarPositiveLogPotential a φ (r,x) ≤ scalarPositiveLogPotential a φ (r,E) at hh
    simpa only [heq x hx,heq E hE] using hh
  refine ⟨E,hE,hzero,hpos,?_,hbound,huniq⟩
  exact (show IsGreatest (scalarLogPotential a r φ '' Ioo l u)
      (scalarLogPotential a r φ E) from
    ⟨⟨E,hE,rfl⟩,by rintro _ ⟨x,hx,rfl⟩; exact hbound x hx⟩).csSup_eq

theorem scalarGap_height_eq_at_center (a r φ l u E : ℝ)
    (hgap : IsScalarGap a r φ l u)
    (hl : scalarTotalLogPotential a φ (r,l) = 0)
    (hu : scalarTotalLogPotential a φ (r,u) = 0)
    (hE : E ∈ Ioo l u) (hzero : scalarGreen a r φ E = 0) :
    scalarGapHeight a r φ l u = scalarLogPotential a r φ E := by
  obtain ⟨F,hF,_,_,hheight,_,huniq⟩ := scalarGap_maximum a r φ l u hgap hl hu
  simpa only [huniq E hE hzero] using hheight

theorem physical_scalarGap_maximum (a r α l u : ℝ)
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hra : r≤a) (hα : Irrational α)
    (hgap : IsScalarGap a r (Real.pi*α) l u) :
    ∃ E ∈ Ioo l u, scalarGreen a r (Real.pi*α) E = 0 ∧
      0 < scalarLogPotential a r (Real.pi*α) E ∧
      scalarGapHeight a r (Real.pi*α) l u = scalarLogPotential a r (Real.pi*α) E ∧
      (∀ x ∈ Ioo l u, scalarLogPotential a r (Real.pi*α) x ≤
        scalarLogPotential a r (Real.pi*α) E) ∧
      (∀ x ∈ Ioo l u, scalarGreen a r (Real.pi*α) x = 0 → x = E) :=
  scalarGap_maximum a r (Real.pi*α) l u hgap
    (scalarTotalLogPotential_spectral_zero_pos_field ha ha1 hr hra hα l hgap.left_spectral)
    (scalarTotalLogPotential_spectral_zero_pos_field ha ha1 hr hra hα u hgap.right_spectral)

theorem resolvent_interval_persists (a r φ p q : ℝ)
    (hres : ∀ E ∈ Icc p q, (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    ∀ᶠ t in 𝓝 r, ∀ E ∈ Icc p q,
      (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t φ) := by
  have hsub : ({r} : Set ℝ) ×ˢ Icc p q ⊆ scalarJointResolventDomain a φ := by
    rintro ⟨t,E⟩ ⟨ht,hE⟩
    rcases Set.mem_singleton_iff.mp ht with rfl
    exact hres E hE
  obtain ⟨s,v,hs,_,hrs,hiv,hprod⟩ := generalized_tube_lemma
    isCompact_singleton isCompact_Icc (scalarJointResolventDomain_isOpen a φ) hsub
  filter_upwards [hs.mem_nhds (hrs (by simp))] with t ht
  intro E hE
  exact @hprod (t,E) ⟨ht,hiv hE⟩

theorem continuous_energy_stays_in_gap (a r φ : ℝ) (l u e : ℝ → ℝ)
    (hgap : IsScalarGap a r φ (l r) (u r))
    (hneargap : ∀ᶠ t in 𝓝 r, IsScalarGap a t φ (l t) (u t))
    (c : ℝ) (hc : c ∈ Ioo (l r) (u r))
    (hcut : ∀ᶠ t in 𝓝 r, c ∈ Ioo (l t) (u t))
    (he : e r ∈ Ioo (l r) (u r)) (hcont : ContinuousAt e r) :
    ∀ᶠ t in 𝓝 r, e t ∈ Ioo (l t) (u t) := by
  let p := (l r + min c (e r))/2
  let q := (max c (e r) + u r)/2
  have hp : l r < p ∧ p < c ∧ p < e r := by
    dsimp [p]
    constructor
    · linarith [lt_min hc.1 he.1]
    · constructor <;> linarith [hc.1,he.1,min_le_left c (e r),min_le_right c (e r)]
  have hq : c < q ∧ e r < q ∧ q < u r := by
    dsimp [q]
    constructor
    · linarith [le_max_left c (e r),max_lt hc.2 he.2]
    · constructor <;> linarith [le_max_right c (e r),max_lt hc.2 he.2]
  have hres : ∀ E ∈ Icc p q,
      (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ) := by
    intro E hE
    exact hgap.resolvent E ⟨hp.1.trans_le hE.1,hE.2.trans_lt hq.2.2⟩
  have hevent : ∀ᶠ t in 𝓝 r, e t ∈ Ioo p q :=
    hcont.eventually (isOpen_Ioo.mem_nhds ⟨hp.2.2,hq.2.1⟩)
  filter_upwards [hneargap,hcut,hevent,resolvent_interval_persists a r φ p q hres]
    with t ht hct het hrt
  constructor
  · by_contra hn
    have hle : e t ≤ l t := le_of_not_gt hn
    exact ht.left_spectral (hrt (l t) ⟨het.1.le.trans hle,le_trans hct.1.le hq.1.le⟩)
  · by_contra hn
    have hle : u t ≤ e t := le_of_not_gt hn
    exact ht.right_spectral (hrt (u t) ⟨le_trans hp.2.1.le hct.2.le,hle.trans het.2.le⟩)

end UAMODraft

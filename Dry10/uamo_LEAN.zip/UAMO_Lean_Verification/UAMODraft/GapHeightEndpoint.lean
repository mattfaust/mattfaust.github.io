import UAMODraft.GapHeightComponents
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Topology.Order.Monotone

noncomputable section
namespace UAMODraft
open UAMO Set Filter MeasureTheory
open scoped Topology

theorem scalar_log_integrable_of_finite (a r φ E b : ℝ)
    [NoAtoms (scalarRealSpectralMeasure a r φ)]
    (hb : scalarTotalLogPotential a φ (r,E) = (b:EReal)) :
    Integrable (fun x : ℝ => Real.log |E-x|) (scalarRealSpectralMeasure a r φ) := by
  letI : Nontrivial MagneticSpace := ⟨⟨magneticOrigin,0,by
    intro h
    have hn := congrArg norm h
    rw [magneticOrigin_norm,norm_zero] at hn
    exact one_ne_zero hn⟩⟩
  let μ := scalarRealSpectralMeasure a r φ
  let C := Real.log (|E|+‖scalarHamiltonian a r φ‖+2)
  let f : ℕ → ℝ → ℝ := fun n x => C-Real.log (|E-x|+logRegularizationScale n)
  let F : ℝ → ℝ := fun x => C-Real.log |E-x|
  have hsupp : ∀ᵐ (x : ℝ) ∂μ, (x:ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) :=
    ae_iff.mpr (scalarRealSpectralMeasure_spectrum_compl a r φ)
  have hne : ∀ᵐ x ∂μ, E-x ≠ 0 := by
    apply ae_iff.mpr
    have heq : {x : ℝ | ¬ E-x ≠ 0} = {E} := by ext x; simp [sub_eq_zero,eq_comm]
    rw [heq]
    exact measure_singleton E
  have hfi (n : ℕ) : Integrable (f n) μ :=
    (integrable_const C).sub (scalar_continuousLog_integrable a r φ E _ (logRegularizationScale_pos n))
  have hfn (n : ℕ) : 0 ≤ᵐ[μ] f n := by
    filter_upwards [hsupp] with x hx
    have hxnorm : |x| ≤ ‖scalarHamiltonian a r φ‖ := by
      simpa only [Complex.norm_real,Real.norm_eq_abs] using spectrum.norm_le_norm_of_mem hx
    have hn : logRegularizationScale n ≤ 1 := by
      simpa only [logRegularizationScale,Nat.cast_zero,zero_add,div_one] using
        logRegularizationScale_antitone (Nat.zero_le n)
    apply sub_nonneg.mpr
    apply Real.log_le_log (add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos n))
    dsimp [C]
    linarith [abs_sub E x]
  have hFt : ∀ᵐ x ∂μ, Tendsto (fun n => f n x) atTop (𝓝 (F x)) := by
    filter_upwards [hne] with x hx
    apply tendsto_const_nhds.sub
    apply (Real.continuousAt_log (abs_ne_zero.mpr hx)).tendsto.comp
    simpa only [add_zero] using (tendsto_const_nhds (x:=|E-x|)).add logRegularizationScale_tendsto
  have hFn : 0 ≤ᵐ[μ] F := by
    filter_upwards [hFt,ae_all_iff.mpr hfn] with x hx hn
    exact le_of_tendsto_of_tendsto' tendsto_const_nhds hx hn
  have hbound (n : ℕ) : (∫ x, f n x ∂μ) ≤ C-b := by
    have hl : b ≤ scalarRegularizedLogPotential a φ n (r,E) := by
      apply EReal.coe_le_coe_iff.mp
      rw [←hb]
      exact iInf_le _ n
    change (∫ x, C-Real.log (|E-x|+logRegularizationScale n) ∂μ) ≤ _
    rw [integral_sub (integrable_const C)
      (scalar_continuousLog_integrable a r φ E _ (logRegularizationScale_pos n))]
    simp only [integral_const,measureReal_def,measure_univ,ENNReal.toReal_one,one_smul]
    change C-scalarContinuousRegularization a r φ E (logRegularizationScale n) ≤ C-b
    rw [scalarContinuousRegularization_discrete]
    linarith
  have hfl (n : ℕ) : (∫⁻ x, ENNReal.ofReal (f n x) ∂μ) ≤ ENNReal.ofReal (C-b) := by
    rw [←ofReal_integral_eq_lintegral_ofReal (hfi n) (hfn n)]
    exact ENNReal.ofReal_le_ofReal (hbound n)
  have hfatou : (∫⁻ x, ENNReal.ofReal (F x) ∂μ) ≤ ENNReal.ofReal (C-b) := by
    calc
      _ = ∫⁻ x, liminf (fun n => ENNReal.ofReal (f n x)) atTop ∂μ := by
        apply lintegral_congr_ae
        filter_upwards [hFt] with x hx
        exact ((ENNReal.continuous_ofReal.tendsto _).comp hx).liminf_eq.symm
      _ ≤ liminf (fun n => ∫⁻ x, ENNReal.ofReal (f n x) ∂μ) atTop :=
        lintegral_liminf_le' (fun n => (hfi n).aemeasurable.ennreal_ofReal)
      _ ≤ ENNReal.ofReal (C-b) := by
        simpa only [liminf_const] using liminf_le_liminf (f:=atTop) (Eventually.of_forall hfl)
  have hFm : AEStronglyMeasurable F μ :=
    (measurable_const.sub (Real.measurable_log.comp
      (continuous_const.sub continuous_id).abs.measurable)).aestronglyMeasurable
  have hFI : Integrable F μ := ⟨hFm,(hasFiniteIntegral_iff_ofReal hFn).mpr
    (hfatou.trans_lt ENNReal.ofReal_lt_top)⟩
  have h := (integrable_const C).sub hFI
  change Integrable (fun x => C-(C-Real.log |E-x|)) μ at h
  simpa only [sub_sub_cancel] using h

theorem scalar_finite_potential_eq_integral (a r φ E b : ℝ)
    [NoAtoms (scalarRealSpectralMeasure a r φ)]
    (hb : scalarTotalLogPotential a φ (r,E) = (b:EReal)) :
    (∫ x : ℝ, Real.log |E-x| ∂scalarRealSpectralMeasure a r φ) = b := by
  have hne : ∀ᵐ x ∂scalarRealSpectralMeasure a r φ, E-x ≠ 0 := by
    apply ae_iff.mpr
    have heq : {x : ℝ | ¬ E-x ≠ 0} = {E} := by ext x; simp [sub_eq_zero,eq_comm]
    rw [heq]
    exact measure_singleton E
  have hm : ∀ᵐ x ∂scalarRealSpectralMeasure a r φ,
      Antitone (fun n => Real.log (|E-x|+logRegularizationScale n)) := by
    apply Eventually.of_forall
    intro x n m hnm
    exact Real.log_le_log (add_pos_of_nonneg_of_pos (abs_nonneg _) (logRegularizationScale_pos m))
      (add_le_add_left (logRegularizationScale_antitone hnm) _)
  have ht : ∀ᵐ x ∂scalarRealSpectralMeasure a r φ,
      Tendsto (fun n => Real.log (|E-x|+logRegularizationScale n)) atTop (𝓝 (Real.log |E-x|)) := by
    filter_upwards [hne] with x hx
    apply (Real.continuousAt_log (abs_ne_zero.mpr hx)).tendsto.comp
    simpa only [add_zero] using (tendsto_const_nhds (x:=|E-x|)).add logRegularizationScale_tendsto
  have hi := integral_tendsto_of_tendsto_of_antitone
    (fun n => scalar_continuousLog_integrable a r φ E _ (logRegularizationScale_pos n))
    (scalar_log_integrable_of_finite a r φ E b hb) hm ht
  have he := scalarContinuousRegularization_tendsto a r φ E
  rw [hb] at he
  apply EReal.coe_injective
  exact tendsto_nhds_unique (continuous_coe_real_ereal.continuousAt.tendsto.comp hi) he

end UAMODraft

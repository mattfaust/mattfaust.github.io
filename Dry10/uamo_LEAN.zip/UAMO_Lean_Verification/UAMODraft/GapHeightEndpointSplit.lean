import UAMODraft.GapHeightEndpoint
import UAMODraft.OffSpectrumHeights

noncomputable section
namespace UAMODraft
open UAMO Set Filter MeasureTheory
open scoped Topology

theorem log_left_part_tendsto (μ : Measure ℝ) [IsFiniteMeasure μ] [NoAtoms μ]
    (l u : ℝ) (hlu : l<u)
    (hl : Integrable (fun x : ℝ => Real.log |l-x|) μ)
    (hinterior : ∀ E ∈ Ioo l u, Integrable (fun x : ℝ => Real.log |E-x|) μ) :
    Tendsto (fun E => ∫ x in Iic l, Real.log |E-x| ∂μ) (𝓝[>] l)
      (𝓝 (∫ x in Iic l, Real.log |l-x| ∂μ)) := by
  let L : ℝ → ℝ := fun E => ∫ x in Iic l, Real.log |E-x| ∂μ
  have hne : ∀ᵐ x ∂μ.restrict (Iic l), x≠l := by
    apply ae_restrict_of_ae
    apply ae_iff.mpr
    simp
  have hmono : MonotoneOn L (Ioo l u) := by
    intro E hE F hF hEF
    apply integral_mono_ae (hinterior E hE).integrableOn (hinterior F hF).integrableOn
    filter_upwards [ae_restrict_mem measurableSet_Iic] with x hx
    change x ≤ l at hx
    have hp : 0<E-x := by linarith [hx,hE.1]
    rw [abs_of_pos hp,abs_of_pos (show 0<F-x by linarith)]
    exact Real.log_le_log hp (by linarith)
  have hbelow (E : ℝ) (hE : E ∈ Ioo l u) : L l ≤ L E := by
    apply integral_mono_ae hl.integrableOn (hinterior E hE).integrableOn
    filter_upwards [ae_restrict_mem measurableSet_Iic,hne] with x hx hxl
    have hp : 0<l-x := sub_pos.mpr (lt_of_le_of_ne hx hxl)
    rw [abs_of_pos hp,abs_of_pos (show 0<E-x by linarith [hE.1])]
    exact Real.log_le_log hp (by linarith [hE.1])
  have hlim := hmono.tendsto_nhdsWithin_Ioo_right (nonempty_Ioo.mpr hlu)
    (show BddBelow (L '' Ioo l u) from ⟨L l,by rintro _ ⟨E,hE,rfl⟩; exact hbelow E hE⟩)
  let e : ℕ → ℝ := fun n => l+(u-l)/2*logRegularizationScale n
  have hen (n : ℕ) : e n ∈ Ioo l u := by
    have hp := logRegularizationScale_pos n
    have hb : logRegularizationScale n ≤ 1 := by
      simpa only [logRegularizationScale,Nat.cast_zero,zero_add,div_one] using
        logRegularizationScale_antitone (Nat.zero_le n)
    dsimp [e]
    constructor <;> nlinarith
  have heanti : Antitone e := by
    intro n m hnm
    exact add_le_add_left (mul_le_mul_of_nonneg_left (logRegularizationScale_antitone hnm)
      (div_nonneg (sub_nonneg.mpr hlu.le) (by norm_num))) l
  have he : Tendsto e atTop (𝓝 l) := by
    simpa only [e,mul_zero,add_zero] using
      (tendsto_const_nhds (x:=l)).add (logRegularizationScale_tendsto.const_mul ((u-l)/2))
  have heGT : Tendsto e atTop (𝓝[>] l) :=
    tendsto_nhdsWithin_iff.mpr ⟨he,Eventually.of_forall (fun n => (hen n).1)⟩
  have hanti : ∀ᵐ x ∂μ.restrict (Iic l),
      Antitone (fun n => Real.log |e n-x|) := by
    filter_upwards [ae_restrict_mem measurableSet_Iic] with x hx
    intro n m hnm
    change x ≤ l at hx
    change Real.log |e m-x| ≤ Real.log |e n-x|
    have hn : 0<e n-x := by linarith [(hen n).1]
    have hm : 0<e m-x := by linarith [(hen m).1]
    rw [abs_of_pos hn,abs_of_pos hm]
    exact Real.log_le_log hm (sub_le_sub_right (heanti hnm) x)
  have ht : ∀ᵐ x ∂μ.restrict (Iic l),
      Tendsto (fun n => Real.log |e n-x|) atTop (𝓝 (Real.log |l-x|)) := by
    filter_upwards [hne] with x hx
    exact (Real.continuousAt_log (abs_ne_zero.mpr (sub_ne_zero.mpr hx.symm))).tendsto.comp
      (he.sub_const x).abs
  have hMCT := integral_tendsto_of_tendsto_of_antitone
    (fun n => (hinterior (e n) (hen n)).integrableOn) hl.integrableOn hanti ht
  have heq : sInf (L '' Ioo l u) = L l := tendsto_nhds_unique (hlim.comp heGT) hMCT
  simpa only [heq,L] using hlim

theorem log_right_part_tendsto (μ : Measure ℝ) [IsFiniteMeasure μ]
    (l u : ℝ) (hlu : l<u)
    (hsupport : ∀ᵐ x ∂μ, x≤l ∨ u≤x)
    (hl : Integrable (fun x : ℝ => Real.log |l-x|) μ)
    (hm : Integrable (fun x : ℝ => Real.log |(l+u)/2-x|) μ) :
    Tendsto (fun E => ∫ x in Ioi l, Real.log |E-x| ∂μ) (𝓝[>] l)
      (𝓝 (∫ x in Ioi l, Real.log |l-x| ∂μ)) := by
  let m := (l+u)/2
  have hlm : l < m := by dsimp [m]; linarith
  have hmu : m < u := by dsimp [m]; linarith
  have hs : ∀ᵐ x ∂μ.restrict (Ioi l), u≤x := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi,ae_restrict_of_ae hsupport] with x hx hsx
    exact hsx.resolve_left (not_le_of_gt hx)
  have hc : ContinuousWithinAt (fun E => ∫ x in Ioi l, Real.log |E-x| ∂μ) (Icc l m) l := by
    apply continuousWithinAt_of_dominated
      (bound:=fun x : ℝ => |Real.log (|l-x|)|+|Real.log (|m-x|)|)
    · apply Eventually.of_forall
      intro E
      exact (Real.measurable_log.comp (continuous_const.sub continuous_id).abs.measurable).aestronglyMeasurable
    · filter_upwards [self_mem_nhdsWithin] with E hE
      filter_upwards [hs] with x hx
      have hmpos : 0<x-m := by linarith
      have hEpos : 0<x-E := by linarith [hE.2]
      have hlpos : 0<x-l := by linarith
      have hlo : Real.log |m-x| ≤ Real.log |E-x| := by
        rw [abs_of_neg (by linarith : m-x<0),abs_of_neg (by linarith : E-x<0)]
        exact Real.log_le_log (by linarith) (by linarith [hE.2])
      have hhi : Real.log |E-x| ≤ Real.log |l-x| := by
        rw [abs_of_neg (by linarith : E-x<0),abs_of_neg (by linarith : l-x<0)]
        exact Real.log_le_log (by linarith) (by linarith [hE.1])
      rw [Real.norm_eq_abs]
      apply abs_le.mpr
      constructor <;> linarith [neg_abs_le (Real.log |m-x|),le_abs_self (Real.log |l-x|),
        abs_nonneg (Real.log |m-x|),abs_nonneg (Real.log |l-x|)]
    · exact hl.abs.integrableOn.add hm.abs.integrableOn
    · filter_upwards [hs] with x hx
      apply ContinuousAt.continuousWithinAt
      exact (continuousAt_id.sub continuousAt_const).abs.log (abs_ne_zero.mpr (by linarith : l-x≠0))
  have hci := hc.mono (show Ioo l m ⊆ Icc l m from Ioo_subset_Icc_self)
  simpa only [ContinuousWithinAt,nhdsWithin_Ioo_eq_nhdsGT hlm] using hci

theorem split_log_endpoint_tendsto (μ : Measure ℝ) [IsFiniteMeasure μ] [NoAtoms μ]
    (l u : ℝ) (hlu : l<u)
    (hsupport : ∀ᵐ x ∂μ, x≤l ∨ u≤x)
    (hl : Integrable (fun x : ℝ => Real.log |l-x|) μ)
    (hinterior : ∀ E ∈ Ioo l u, Integrable (fun x : ℝ => Real.log |E-x|) μ) :
    Tendsto (fun E => ∫ x, Real.log |E-x| ∂μ) (𝓝[>] l)
      (𝓝 (∫ x, Real.log |l-x| ∂μ)) := by
  have hmid : (l+u)/2 ∈ Ioo l u := by constructor <;> linarith
  have h := (log_left_part_tendsto μ l u hlu hl hinterior).add
    (log_right_part_tendsto μ l u hlu hsupport hl (hinterior _ hmid))
  have heq (E : ℝ) (hi : Integrable (fun x : ℝ => Real.log |E-x|) μ) :
      (∫ x in Iic l, Real.log |E-x| ∂μ)+(∫ x in Ioi l, Real.log |E-x| ∂μ) =
        ∫ x, Real.log |E-x| ∂μ := by
    simpa only [compl_Iic] using integral_add_compl measurableSet_Iic hi
  rw [heq l hl] at h
  apply h.congr'
  filter_upwards [Ioo_mem_nhdsGT hlu] with E hE
  exact heq E (hinterior E hE)

theorem scalarGap_left_endpoint_tendsto (a r φ l u b : ℝ)
    [NoAtoms (scalarRealSpectralMeasure a r φ)]
    (hgap : IsScalarGap a r φ l u)
    (hl : scalarTotalLogPotential a φ (r,l) = (b:EReal)) :
    Tendsto (scalarLogPotential a r φ) (𝓝[>] l) (𝓝 b) := by
  have hs : ∀ᵐ x : ℝ ∂scalarRealSpectralMeasure a r φ, x≤l ∨ u≤x := by
    filter_upwards [ae_iff.mpr (scalarRealSpectralMeasure_spectrum_compl a r φ)] with x hx
    by_contra hn
    push_neg at hn
    exact hx (hgap.resolvent x ⟨hn.1,hn.2⟩)
  have hI := scalar_log_integrable_of_finite a r φ l b hl
  have h := split_log_endpoint_tendsto (scalarRealSpectralMeasure a r φ) l u hgap.lt hs hI
    (fun E hE => scalar_log_integrable_off_spectrum a r φ E (hgap.resolvent E hE))
  rw [scalar_finite_potential_eq_integral a r φ l b hl] at h
  apply h.congr'
  filter_upwards [Ioo_mem_nhdsGT hgap.lt] with E hE
  rw [scalarRealSpectralMeasure_integral_eq_subtype]
  exact (scalarTraceLog_eq_spectralIntegral a r φ E (hgap.resolvent E hE)).symm

theorem split_log_right_endpoint_tendsto (μ : Measure ℝ) [IsFiniteMeasure μ] [NoAtoms μ]
    (l u : ℝ) (hlu : l<u)
    (hsupport : ∀ᵐ x ∂μ, x≤l ∨ u≤x)
    (hu : Integrable (fun x : ℝ => Real.log |u-x|) μ)
    (hinterior : ∀ E ∈ Ioo l u, Integrable (fun x : ℝ => Real.log |E-x|) μ) :
    Tendsto (fun E => ∫ x, Real.log |E-x| ∂μ) (𝓝[<] u)
      (𝓝 (∫ x, Real.log |u-x| ∂μ)) := by
  let ν := Measure.map (fun x : ℝ => -x) μ
  have hneg : Measurable (fun x : ℝ => -x) := continuous_neg.measurable
  letI : NoAtoms ν := ⟨fun x => by
    change Measure.map (fun x : ℝ => -x) μ {x} = 0
    rw [Measure.map_apply hneg (measurableSet_singleton x)]
    have heq : (fun x : ℝ => -x) ⁻¹' {x} = {-x} := by ext y; simp
    rw [heq,measure_singleton]⟩
  have habs (E x : ℝ) : |E-(-x)| = |-E-x| := by
    rw [show -E-x = -(E-(-x)) by ring,abs_neg]
  have hi (E : ℝ) (hint : Integrable (fun x : ℝ => Real.log |-E-x|) μ) :
      Integrable (fun x : ℝ => Real.log |E-x|) ν := by
    apply (integrable_map_measure
      (Real.measurable_log.comp (continuous_const.sub continuous_id).abs.measurable).aestronglyMeasurable
      hneg.aemeasurable).mpr
    simpa only [Function.comp_def,id_eq,habs] using hint
  have heq (E : ℝ) : (∫ x, Real.log |E-x| ∂ν) = ∫ x, Real.log |-E-x| ∂μ := by
    have hm : Measurable (fun x : ℝ => Real.log |E-x|) :=
      Real.measurable_log.comp (continuous_const.sub continuous_id).abs.measurable
    change (∫ x, Real.log |E-x| ∂Measure.map (fun x : ℝ => -x) μ) = _
    rw [integral_map hneg.aemeasurable hm.aestronglyMeasurable]
    simp only [habs]
  have hs : ∀ᵐ x ∂ν, x≤-u ∨ -l≤x := by
    apply (ae_map_iff hneg.aemeasurable (measurableSet_Iic.union measurableSet_Ici)).mpr
    filter_upwards [hsupport] with x hx
    rcases hx with hx|hx
    · exact Or.inr (neg_le_neg hx)
    · exact Or.inl (neg_le_neg hx)
  have h := split_log_endpoint_tendsto ν (-u) (-l) (neg_lt_neg hlu) hs
    (hi (-u) (by simpa only [neg_neg] using hu)) (fun E hE => hi E
      (hinterior (-E) ⟨by linarith [hE.2],by linarith [hE.1]⟩))
  have hh := h.comp (tendsto_neg_nhdsLT (a:=u))
  simpa only [Function.comp_def,heq,neg_neg] using hh

theorem scalarGap_right_endpoint_tendsto (a r φ l u b : ℝ)
    [NoAtoms (scalarRealSpectralMeasure a r φ)]
    (hgap : IsScalarGap a r φ l u)
    (hu : scalarTotalLogPotential a φ (r,u) = (b:EReal)) :
    Tendsto (scalarLogPotential a r φ) (𝓝[<] u) (𝓝 b) := by
  have hs : ∀ᵐ x : ℝ ∂scalarRealSpectralMeasure a r φ, x≤l ∨ u≤x := by
    filter_upwards [ae_iff.mpr (scalarRealSpectralMeasure_spectrum_compl a r φ)] with x hx
    by_contra hn
    push_neg at hn
    exact hx (hgap.resolvent x ⟨hn.1,hn.2⟩)
  have hI := scalar_log_integrable_of_finite a r φ u b hu
  have h := split_log_right_endpoint_tendsto (scalarRealSpectralMeasure a r φ) l u hgap.lt hs hI
    (fun E hE => scalar_log_integrable_off_spectrum a r φ E (hgap.resolvent E hE))
  rw [scalar_finite_potential_eq_integral a r φ u b hu] at h
  apply h.congr'
  filter_upwards [Ioo_mem_nhdsLT hgap.lt] with E hE
  rw [scalarRealSpectralMeasure_integral_eq_subtype]
  exact (scalarTraceLog_eq_spectralIntegral a r φ E (hgap.resolvent E hE)).symm

end UAMODraft

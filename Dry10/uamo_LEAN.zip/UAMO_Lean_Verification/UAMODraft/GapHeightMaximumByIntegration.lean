import UAMODraft.GapHeightEndpointSplit
import UAMODraft.GapHeightPairing

noncomputable section
namespace UAMODraft
open UAMO Set Filter MeasureTheory
open scoped Topology ContDiff InnerProductSpace

def scalarGapZeroExtension (a r φ l u E : ℝ) : ℝ :=
  if E ∈ Ioo l u then scalarLogPotential a r φ E else 0

theorem scalarGapZeroExtension_continuousOn (a r φ l u : ℝ)
    [NoAtoms (scalarRealSpectralMeasure a r φ)]
    (hgap : IsScalarGap a r φ l u)
    (hl : scalarTotalLogPotential a φ (r,l) = 0)
    (hu : scalarTotalLogPotential a φ (r,u) = 0) :
    ContinuousOn (scalarGapZeroExtension a r φ l u) (Icc l u) := by
  let L := scalarGapZeroExtension a r φ l u
  have hleft : L l = 0 := by simp [L,scalarGapZeroExtension]
  have hright : L u = 0 := by simp [L,scalarGapZeroExtension]
  have hin (E : ℝ) (hE : E ∈ Ioo l u) : L E = scalarLogPotential a r φ E := by
    simp only [L,scalarGapZeroExtension,if_pos hE]
  intro E hE
  by_cases hEl : E=l
  · subst E
    have h := scalarGap_left_endpoint_tendsto a r φ l u 0 hgap (by simpa using hl)
    have hLt : Tendsto L (𝓝[>] l) (𝓝 0) := by
      apply h.congr'
      filter_upwards [Ioo_mem_nhdsGT hgap.lt] with E hE
      exact (hin E hE).symm
    have hc : ContinuousWithinAt L (Ioi l) l := by
      simpa only [ContinuousWithinAt,hleft] using hLt
    apply hc.insert.mono
    intro x hx
    rcases eq_or_lt_of_le hx.1 with h|h
    · exact Or.inl h.symm
    · exact Or.inr h
  by_cases hEu : E=u
  · subst E
    have h := scalarGap_right_endpoint_tendsto a r φ l u 0 hgap (by simpa using hu)
    have hLt : Tendsto L (𝓝[<] u) (𝓝 0) := by
      apply h.congr'
      filter_upwards [Ioo_mem_nhdsLT hgap.lt] with E hE
      exact (hin E hE).symm
    have hc : ContinuousWithinAt L (Iio u) u := by
      simpa only [ContinuousWithinAt,hright] using hLt
    apply hc.insert.mono
    intro x hx
    rcases eq_or_lt_of_le hx.2 with h|h
    · exact Or.inl h
    · exact Or.inr h
  have hEin : E ∈ Ioo l u :=
    ⟨lt_of_le_of_ne hE.1 (Ne.symm hEl),lt_of_le_of_ne hE.2 hEu⟩
  apply ContinuousAt.continuousWithinAt
  apply (scalarLogPotential_energy_hasDerivAt a r φ E (hgap.resolvent E hEin)).continuousAt.congr_of_eventuallyEq
  filter_upwards [isOpen_Ioo.mem_nhds hEin] with x hx
  exact hin x hx

theorem physical_scalarGap_maximum_by_integration (a r α l u : ℝ)
    (ha : 0<a) (ha1 : a≤1) (hr : 0<r) (hra : r≤a) (hα : Irrational α)
    (hgap : IsScalarGap a r (Real.pi*α) l u) :
    ∃ E ∈ Ioo l u, scalarGreen a r (Real.pi*α) E = 0 ∧
      0 < scalarGapHeight a r (Real.pi*α) l u ∧
      scalarGapHeight a r (Real.pi*α) l u = scalarLogPotential a r (Real.pi*α) E ∧
      (∀ x ∈ Ioo l u, scalarLogPotential a r (Real.pi*α) x ≤ scalarGapHeight a r (Real.pi*α) l u) ∧
      (∀ x ∈ Ioo l u,
        (scalarLogPotential a r (Real.pi*α) x = scalarGapHeight a r (Real.pi*α) l u ↔ x=E) ∧
        (scalarGreen a r (Real.pi*α) x = 0 ↔ x=E)) := by
  letI := scalarRealSpectralMeasure_noAtoms ha ha1 hr.le (hra.trans ha1) (Real.pi*α)
  have hl := scalarTotalLogPotential_spectral_zero_pos_field ha ha1 hr hra hα l hgap.left_spectral
  have hu := scalarTotalLogPotential_spectral_zero_pos_field ha ha1 hr hra hα u hgap.right_spectral
  let L := scalarGapZeroExtension a r (Real.pi*α) l u
  have hL (x : ℝ) (hx : x ∈ Ioo l u) : L x = scalarLogPotential a r (Real.pi*α) x := by
    simp only [L,scalarGapZeroExtension,if_pos hx]
  obtain ⟨E,hE,hpos,hzero,hmax,_,huniq⟩ := scalar_seed_gap_unique_positive_maximum
    a r (Real.pi*α) hgap.lt hgap.resolvent L hL
    (scalarGapZeroExtension_continuousOn a r (Real.pi*α) l u hgap hl hu)
    (by simp [L,scalarGapZeroExtension]) (by simp [L,scalarGapZeroExtension])
  have hbound (x : ℝ) (hx : x ∈ Ioo l u) :
      scalarLogPotential a r (Real.pi*α) x ≤ scalarLogPotential a r (Real.pi*α) E := by
    have h := hmax ⟨hx.1.le,hx.2.le⟩
    change L x ≤ L E at h
    simpa only [hL x hx,hL E hE] using h
  have hsup : scalarGapHeight a r (Real.pi*α) l u = scalarLogPotential a r (Real.pi*α) E :=
    (show IsGreatest (scalarLogPotential a r (Real.pi*α) '' Ioo l u)
      (scalarLogPotential a r (Real.pi*α) E) from
      ⟨⟨E,hE,rfl⟩,by rintro _ ⟨x,hx,rfl⟩; exact hbound x hx⟩).csSup_eq
  refine ⟨E,hE,hzero,by simpa only [hsup] using hpos,hsup,?_,?_⟩
  · intro x hx
    simpa only [hsup] using hbound x hx
  · intro x hx
    have hiff : scalarLogPotential a r (Real.pi*α) x = scalarGapHeight a r (Real.pi*α) l u → x=E := by
      intro hvalue
      have hxmax : IsMaxOn (scalarLogPotential a r (Real.pi*α)) (Ioo l u) x := by
        intro y hy
        change scalarLogPotential a r (Real.pi*α) y ≤ scalarLogPotential a r (Real.pi*α) x
        rw [hvalue,hsup]
        exact hbound y hy
      have hz := (hxmax.isLocalMax (isOpen_Ioo.mem_nhds hx)).hasDerivAt_eq_zero
        (scalarLogPotential_energy_hasDerivAt a r (Real.pi*α) x (hgap.resolvent x hx))
      exact huniq x hx hz
    exact ⟨⟨hiff,fun heq => heq ▸ hsup.symm⟩,⟨huniq x hx,fun heq => heq ▸ hzero⟩⟩

end UAMODraft

import UAMODraft.GapHeightBranches

noncomputable section
namespace UAMODraft
open UAMO Set Filter
open scoped Topology InnerProductSpace

theorem rootTrace_star (A : MagneticOperator) : rootTrace (star A) = star (rootTrace A) := by
  rw [rootTrace_eq_inner,rootTrace_eq_inner,ContinuousLinearMap.star_eq_adjoint,
    ContinuousLinearMap.adjoint_inner_right]
  exact (inner_conj_symm (𝕜:=ℂ) (A magneticOrigin) magneticOrigin).symm

theorem rootTrace_product_im_zero (φ : ℝ) (A B : magneticAlgebra φ)
    (hA : IsSelfAdjoint A) (hB : IsSelfAdjoint B) :
    (rootTrace ((A*B : magneticAlgebra φ) : MagneticOperator)).im = 0 := by
  have hconj : star (rootTrace ((A*B : magneticAlgebra φ) : MagneticOperator)) =
      rootTrace ((A*B : magneticAlgebra φ) : MagneticOperator) := by
    rw [←rootTrace_star]
    change rootTrace ((star (A*B) : magneticAlgebra φ) : MagneticOperator) = _
    rw [star_mul,hA.star_eq,hB.star_eq]
    exact rootTrace_magneticAlgebra_cyclic φ B.property A.property
  have hi := congrArg Complex.im hconj
  simp only [Complex.star_def,Complex.conj_im] at hi
  linarith

theorem scalarHamiltonianDerivative_selfAdjoint (a r φ : ℝ) :
    IsSelfAdjoint (scalarHamiltonianDerivative a r φ) := by
  simp only [IsSelfAdjoint,scalarHamiltonianDerivative,star_add,star_smul,
    (magneticPair_selfAdjoint φ (1,1) (diagonalHopping a φ)).star_eq,
    (magneticPair_selfAdjoint φ (1,2) (-1)).star_eq,star_trivial]

theorem scalar_radial_trace_im_zero (a r φ E : ℝ)
    (hE : (E:ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    (rootTrace (resolvent (scalarHamiltonian a r φ) (E:ℂ) *
      scalarHamiltonianDerivative a r φ)).im = 0 := by
  let A := Ring.inverse (scalarAlgebraPencil a r φ E)
  let B := scalarAlgebraHamiltonianDerivative a r φ
  have hA : IsSelfAdjoint A := by
    change star (Ring.inverse (scalarAlgebraPencil a r φ E)) = _
    rw [←Ring.inverse_star,(scalarAlgebraPencil_isSelfAdjoint a r φ E).star_eq]
  have hB : IsSelfAdjoint B := by
    apply Subtype.ext
    exact (scalarHamiltonianDerivative_selfAdjoint a r φ).star_eq
  have h := rootTrace_product_im_zero φ A B hA hB
  change (rootTrace
    (((Ring.inverse (scalarAlgebraPencil a r φ E) : magneticAlgebra φ) : MagneticOperator) *
      (scalarAlgebraHamiltonianDerivative a r φ : MagneticOperator))).im = 0 at h
  simpa only [scalarAlgebraPencil_inverse_coe a r φ E hE,
    scalarAlgebraHamiltonianDerivative_coe] using h

theorem scalarLogPotential_coupling_deriv_complex (a r φ E : ℝ)
    (hE : (E:ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    ((deriv (fun t => scalarLogPotential a t φ E) r : ℝ) : ℂ) =
      -⟪magneticOrigin,resolvent (scalarHamiltonian a r φ) (E:ℂ)
        (scalarHamiltonianDerivative a r φ magneticOrigin)⟫_ℂ := by
  rw [(scalarLogPotential_coupling_hasDerivAt a r φ E hE).deriv,
    rootTraceReal_apply,←ContinuousLinearMap.mul_apply,←rootTrace_eq_inner]
  apply Complex.ext
  · simp
  · simp only [Complex.ofReal_im,Complex.neg_im]
    rw [scalar_radial_trace_im_zero a r φ E hE]
    simp

theorem ScalarGapBranch.radial_derivative_pairing {a α : ℝ} {S : Set ℝ}
    (B : ScalarGapBranch a (Real.pi*α) S) (hS : IsOpen S)
    (hparam : S ⊆ Ioo 0 a) (ha : 0<a) (ha1 : a≤1) (hα : Irrational α)
    {r : ℝ} (hrS : r ∈ S) :
    ∃ E ∈ Ioo (B.lower r) (B.upper r), scalarGreen a r (Real.pi*α) E = 0 ∧
      B.height r = scalarLogPotential a r (Real.pi*α) E ∧
      ((r * deriv B.height r : ℝ) : ℂ) =
        -⟪magneticOrigin,resolvent (scalarHamiltonian a r (Real.pi*α)) (E:ℂ)
          ((r • scalarHamiltonianDerivative a r (Real.pi*α)) magneticOrigin)⟫_ℂ := by
  obtain ⟨e,_,hn,_,hd,_⟩ := B.local_maximum_and_height hS hparam ha ha1 hα hrS
  have h := hn.self_of_nhds
  refine ⟨e r,h.1,h.2.1,h.2.2,?_⟩
  rw [hd.deriv,Complex.ofReal_mul,
    scalarLogPotential_coupling_deriv_complex a r (Real.pi*α) (e r)
      ((B.gap r hrS).resolvent (e r) h.1)]
  simp only [ContinuousLinearMap.smul_apply,←Complex.coe_smul,map_smul,
    inner_smul_right,mul_neg]

end UAMODraft

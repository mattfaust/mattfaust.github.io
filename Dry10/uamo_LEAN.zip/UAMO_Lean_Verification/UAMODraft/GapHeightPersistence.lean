import UAMODraft.GapHeightMaximumByIntegration
import UAMODraft.OffSpectrumHeights

noncomputable section
namespace UAMODraft
open UAMO Set Filter
open scoped Topology

theorem IsScalarGap.ids_eq {a r φ l u x y : ℝ} (hgap : IsScalarGap a r φ l u)
    (hx : x ∈ Ioo l u) (hy : y ∈ Ioo l u) :
    scalarIDS a r φ x = scalarIDS a r φ y :=
  scalarIDS_constant_on_connected_gap a r φ (Ioo l u) (convex_Ioo l u).isPreconnected
    (fun E hE hs => hs (hgap.resolvent E hE)) hx hy

theorem IsScalarGap.ids_internal {a r φ l u E : ℝ} (hgap : IsScalarGap a r φ l u)
    (hE : E ∈ Ioo l u) : scalarIDS a r φ E ∈ Ioo (0:ℝ) 1 :=
  (scalar_internal_resolvent_iff_IDS a r φ E (hgap.resolvent E hE)).mp
    ⟨l,u,hgap.left_spectral,hgap.right_spectral,hE.1,hE.2⟩

theorem scalarGap_supremum_persists (a α r₀ l₀ u₀ : ℝ)
    (ha : 0<a) (ha1 : a≤1) (hα : Irrational α) (hr₀ : 0<r₀) (hr₀a : r₀<a)
    (hgap₀ : IsScalarGap a r₀ (Real.pi*α) l₀ u₀) :
    0 < scalarGapHeight a r₀ (Real.pi*α) l₀ u₀ ∧
    ∀ r ∈ Icc r₀ a, ∃ l u : ℝ, IsScalarGap a r (Real.pi*α) l u ∧
      scalarGapHeight a r₀ (Real.pi*α) l₀ u₀ ≤ scalarGapHeight a r (Real.pi*α) l u ∧
      ∀ x ∈ Ioo l u, ∀ y ∈ Ioo l₀ u₀,
        scalarIDS a r (Real.pi*α) x = scalarIDS a r₀ (Real.pi*α) y := by
  obtain ⟨E₀,hE₀,hgreen₀,hpos₀,hheight₀,_,_⟩ := physical_scalarGap_maximum_by_integration
    a r₀ α l₀ u₀ ha ha1 hr₀ hr₀a.le hα hgap₀
  refine ⟨hpos₀,?_⟩
  have hpositive₀ : 0 < scalarLogPotential a r₀ (Real.pi*α) E₀ := by
    simpa only [hheight₀] using hpos₀
  have hbaseline : ∀ r ∈ Icc r₀ a, ∀ E : ℝ,
      (E:ℂ) ∈ spectrum ℂ (scalarHamiltonian a r (Real.pi*α)) →
      scalarTotalLogPotential a (Real.pi*α) (r,E) = 0 := by
    intro r hr E hE
    exact scalarTotalLogPotential_spectral_zero_pos_field ha ha1
      (hr₀.trans_le hr.1) hr.2 hα E hE
  have hcontinue := scalar_positive_seed_global_continuation a α r₀ a E₀ ha.ne' hα
    hr₀ hr₀a.le ha1 (hgap₀.resolvent E₀ hE₀) hgreen₀ hpositive₀ hbaseline
  intro r hr
  obtain ⟨E,hE,hgreen,hh,hIDS⟩ := hcontinue r hr
  have hinternal : scalarIDS a r (Real.pi*α) E ∈ Ioo (0:ℝ) 1 := by
    rw [hIDS]
    exact hgap₀.ids_internal hE₀
  obtain ⟨l,u,hl,hu,hEu,hres⟩ := scalar_internal_gap_endpoints a r (Real.pi*α) E hE hinternal
  have hgap : IsScalarGap a r (Real.pi*α) l u :=
    ⟨hEu.1.trans hEu.2,hl,hu,hres⟩
  obtain ⟨Em,hEm,_,_,hhm,_,hcharacter⟩ := physical_scalarGap_maximum_by_integration
    a r α l u ha ha1 (hr₀.trans_le hr.1) hr.2 hα hgap
  have heq : E=Em := (hcharacter E hEu).2.mp hgreen
  have hheight : scalarGapHeight a r (Real.pi*α) l u = scalarLogPotential a r (Real.pi*α) E :=
    hhm.trans (congrArg (scalarLogPotential a r (Real.pi*α)) heq.symm)
  refine ⟨l,u,hgap,?_,?_⟩
  · simpa only [hheight₀,hheight] using hh
  · intro x hx y hy
    exact (hgap.ids_eq hx hEu).trans (hIDS.trans (hgap₀.ids_eq hE₀ hy))

theorem scalarGap_global_branch_persistence (a α r₀ l₀ u₀ : ℝ)
    (ha : 0<a) (ha1 : a≤1) (hα : Irrational α) (hr₀ : 0<r₀) (hr₀a : r₀<a)
    (hgap₀ : IsScalarGap a r₀ (Real.pi*α) l₀ u₀) :
    ∃ B : ScalarGapBranch a (Real.pi*α) (Icc r₀ a),
      Ioo (B.lower r₀) (B.upper r₀) = Ioo l₀ u₀ ∧
      0 < scalarGapHeight a r₀ (Real.pi*α) l₀ u₀ ∧
      (∀ r ∈ Icc r₀ a,
        scalarGapHeight a r₀ (Real.pi*α) l₀ u₀ ≤ B.height r) ∧
      ∀ r ∈ Icc r₀ a, ∀ x ∈ Ioo (B.lower r) (B.upper r), ∀ y ∈ Ioo l₀ u₀,
        scalarIDS a r (Real.pi*α) x = scalarIDS a r₀ (Real.pi*α) y := by
  classical
  obtain ⟨hpos,hall⟩ := scalarGap_supremum_persists a α r₀ l₀ u₀
    ha ha1 hα hr₀ hr₀a hgap₀
  choose l u hg hh hlabel using fun t : Icc r₀ a => hall t t.property
  let lower : ℝ → ℝ := fun r => if hr : r ∈ Icc r₀ a then l ⟨r,hr⟩ else l₀
  let upper : ℝ → ℝ := fun r => if hr : r ∈ Icc r₀ a then u ⟨r,hr⟩ else u₀
  have hselected (r : ℝ) (hr : r ∈ Icc r₀ a) :
      IsScalarGap a r (Real.pi*α) (lower r) (upper r) ∧
      scalarGapHeight a r₀ (Real.pi*α) l₀ u₀ ≤ scalarGapHeight a r (Real.pi*α) (lower r) (upper r) ∧
      ∀ x ∈ Ioo (lower r) (upper r), ∀ y ∈ Ioo l₀ u₀,
        scalarIDS a r (Real.pi*α) x = scalarIDS a r₀ (Real.pi*α) y := by
    simpa only [lower,upper,dif_pos hr] using ⟨hg ⟨r,hr⟩,hh ⟨r,hr⟩,hlabel ⟨r,hr⟩⟩
  let y₀ := (l₀+u₀)/2
  have hy₀ : y₀ ∈ Ioo l₀ u₀ := by dsimp [y₀]; constructor <;> linarith [hgap₀.lt]
  have hlocal : ∀ r ∈ Icc r₀ a, ∃ c ∈ Ioo (lower r) (upper r),
      ∀ᶠ t in 𝓝[Icc r₀ a] r, c ∈ Ioo (lower t) (upper t) := by
    intro r hr
    let c := (lower r+upper r)/2
    have hc : c ∈ Ioo (lower r) (upper r) := by
      dsimp [c]; constructor <;> linarith [(hselected r hr).1.lt]
    have hcres := (hselected r hr).1.resolvent c hc
    have hrnear : ∀ᶠ t in 𝓝 r,
        (c:ℂ) ∈ resolventSet ℂ (scalarHamiltonian a t (Real.pi*α)) :=
      (continuousAt_id.prodMk continuousAt_const).eventually
        ((scalarJointResolventDomain_isOpen a (Real.pi*α)).mem_nhds hcres)
    have hnnear : ∀ᶠ t in 𝓝 r,
        scalarIDS a t (Real.pi*α) c = scalarIDS a r (Real.pi*α) c := by
      have h : ContinuousAt (fun t : ℝ => ((a,t),c)) r :=
        (continuousAt_const.prodMk continuousAt_id).prodMk continuousAt_const
      exact h.eventually (scalarLowerSpectralMass_eventually_eq a r (Real.pi*α) c ha.ne' hcres)
    refine ⟨c,hc,?_⟩
    filter_upwards [self_mem_nhdsWithin,hrnear.filter_mono nhdsWithin_le_nhds,
      hnnear.filter_mono nhdsWithin_le_nhds] with t ht htr htn
    let d := (lower t+upper t)/2
    have hd : d ∈ Ioo (lower t) (upper t) := by
      dsimp [d]; constructor <;> linarith [(hselected t ht).1.lt]
    apply equal_scalarIDS_resolvent_mem_endpoint_interval a t (Real.pi*α)
      (lower t) (upper t) d c (hselected t ht).1.left_spectral
      (hselected t ht).1.right_spectral hd (fun hs => hs htr)
    exact htn.trans (((hselected r hr).2.2 c hc y₀ hy₀).trans
      ((hselected t ht).2.2 d hd y₀ hy₀).symm)
  let B : ScalarGapBranch a (Real.pi*α) (Icc r₀ a) :=
    ⟨lower,upper,fun r hr => (hselected r hr).1,hlocal⟩
  have hr₀in : r₀ ∈ Icc r₀ a := ⟨le_rfl,hr₀a.le⟩
  have hychosen : y₀ ∈ Ioo (lower r₀) (upper r₀) := by
    let c := (lower r₀+upper r₀)/2
    have hc : c ∈ Ioo (lower r₀) (upper r₀) := by
      dsimp [c]; constructor <;> linarith [(hselected r₀ hr₀in).1.lt]
    exact equal_scalarIDS_resolvent_mem_endpoint_interval a r₀ (Real.pi*α)
      (lower r₀) (upper r₀) c y₀ (hselected r₀ hr₀in).1.left_spectral
      (hselected r₀ hr₀in).1.right_spectral hc
      (fun hs => hs (hgap₀.resolvent y₀ hy₀))
      ((hselected r₀ hr₀in).2.2 c hc y₀ hy₀).symm
  refine ⟨B,?_,hpos,fun r hr => (hselected r hr).2.1,fun r hr => (hselected r hr).2.2⟩
  exact ((hselected r₀ hr₀in).1.component_eq hychosen).symm.trans (hgap₀.component_eq hy₀)

end UAMODraft

import UAMODraft.AnalyticPeriodicFourier
import UAMODraft.BetaZeroScalarGauge
import UAMODraft.FiniteConvergentDivisors
import Mathlib
import UAMO.ScalarGaugeAnalytic
import UAMO.CMVHoppingIntegral
import UAMO.RealCocycleConjugacy

noncomputable section
namespace UAMODraft.GeneralScalarGauge
open UAMO.ScalarGauge UAMO.Wronskian
open UAMODraft.AnalyticPeriodicFourier UAMODraft.FiniteConvergentDivisors
open UAMODraft.ContinuedFractionDivisors

def HasHolomorphicStripExtension (φ : ℝ→ℝ) : Prop :=
  ∃ H:ℝ,0<H ∧ ∃ Φ:ℂ→ℂ,
    DifferentiableOn ℂ Φ (openStrip H) ∧ Function.Periodic Φ 1 ∧
      ∀x:ℝ,Φ (x:ℂ)=(φ x:ℂ)

theorem finite_scalar_gauge (φ : ℂ→ℂ) {H : ℝ} (hH : 0<H)
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hreal : ∀x:ℝ,(φ (x:ℂ)).im=0)
    (hmean : (∫ x:ℝ in (0:ℝ)..1,φ (x:ℂ))=0) :
    ∃ c:ℝ,0<c ∧ ∃ C:ℝ,0<C ∧ ∀ α:ℝ,Irrational α→∀ n:ℕ,
      (∀ z:ℂ,|z.im|≤H/4→
        ‖gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) z‖≤
          C*(((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*
            Real.exp (-c*((α.convergent n).den:ℝ)))) ∧
      (∀ z:ℂ,|z.im|≤H/4→
        ‖φ z-(gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) (z+α)-
          gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) z)‖≤
            C*Real.exp (-c*((α.convergent (n+1)).den:ℝ))) ∧
      (∀ x:ℝ,(gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) (x:ℂ)).im=0) := by
  obtain ⟨A,hA0,hA⟩ := exists_strip_bound φ hD hP (show 0≤H/2 by positivity)
    (show H/2<H by linarith)
  let b := Real.pi*(H/2-H/4)
  have hb : 0<b := mul_pos Real.pi_pos (by linarith)
  have hc : ExponentialCoefficients (coefficient φ) A (H/4) b :=
    coefficient_exponential φ hD hP (by positivity) (by linarith) hA
  let F := A*decayMass b
  have hF : 0≤F := mul_nonneg hA0 (tsum_nonneg (fun k => (Real.exp_pos _).le))
  refine ⟨b/2,by positivity,max F 1,lt_of_lt_of_le zero_lt_one (le_max_right _ _),?_⟩
  intro α hα n
  have hq0 : (0:ℝ)≤((α.convergent n).den:ℝ) := Nat.cast_nonneg _
  have hQ0 : (0:ℝ)≤((α.convergent (n+1)).den:ℝ) := Nat.cast_nonneg _
  have hc0 := coefficient_zero φ hmean
  refine ⟨?_,?_,?_⟩
  · intro z hz
    have hu := finite_gauge_convergent_bound α hα n (coefficient φ) hA0 hb hc hz
    have he : Real.exp (-b*((α.convergent n).den:ℝ))≤
        Real.exp (-(b/2)*((α.convergent n).den:ℝ)) := by
      apply Real.exp_le_exp.mpr
      nlinarith
    exact hu.trans (mul_le_mul (le_max_left _ _)
      (add_le_add_left (mul_le_mul_of_nonneg_left he hQ0) _)
      (by positivity) (le_trans hF (le_max_left _ _)))
  · intro z hz
    have hu := finite_gauge_convergent_residual α hα n (coefficient φ) hA0 hb hc hc0 hz
    rw [fourierSeries_eq φ hD hP (by positivity) (by linarith) hA0 hA (by linarith)] at hu
    have he : -b*((α.convergent (n+1)).den:ℝ)/2=
        -(b/2)*((α.convergent (n+1)).den:ℝ) := by ring
    rw [he] at hu
    exact hu.trans (mul_le_mul_of_nonneg_right (le_max_left _ _) (Real.exp_pos _).le)
  · intro x
    exact gaugePotential_real _ α (coefficient φ) (coefficient_conj φ hreal) x

theorem beta_zero_scalar_gauge_actual (φ : ℂ→ℂ) {H : ℝ} (hH : 0<H)
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hreal : ∀x:ℝ,(φ (x:ℂ)).im=0)
    (hmean : (∫ x:ℝ in (0:ℝ)..1,φ (x:ℂ))=0)
    (α : ℝ) (hα : Irrational α) (hβ : beta α=0) :
    DifferentiableOn ℂ (fullPotential α (coefficient φ)) (openStrip (H/4)) ∧
    (∀ z:ℂ,fullPotential α (coefficient φ) (z+1)=fullPotential α (coefficient φ) z) ∧
    (∀ x:ℝ,(fullPotential α (coefficient φ) (x:ℂ)).im=0) ∧
    (∀ z:ℂ,|z.im|≤H/4→
      fullPotential α (coefficient φ) (z+α)-fullPotential α (coefficient φ) z=φ z) := by
  obtain ⟨A,hA0,hA⟩ := exists_strip_bound φ hD hP (show 0≤H/2 by positivity)
    (show H/2<H by linarith)
  let b := Real.pi*(H/2-H/4)
  have hb : 0<b := mul_pos Real.pi_pos (by linarith)
  have hc : ExponentialCoefficients (coefficient φ) A (H/4) b :=
    coefficient_exponential φ hD hP (by positivity) (by linarith) hA
  have hg := UAMODraft.BetaZeroScalarGauge.beta_zero_scalar_gauge α hα hβ
    (coefficient φ) hA0 hb hc (coefficient_zero φ hmean) (coefficient_conj φ hreal)
  refine ⟨hg.1,hg.2.1,hg.2.2.1,?_⟩
  intro z hz
  exact (hg.2.2.2.1 z hz).trans
    (fourierSeries_eq φ hD hP (by positivity) (by linarith) hA0 hA (by linarith))

theorem scalar_gauge (φ : ℂ→ℂ) {H : ℝ} (hH : 0<H)
    (hD : DifferentiableOn ℂ φ (openStrip H)) (hP : Function.Periodic φ 1)
    (hreal : ∀x:ℝ,(φ (x:ℂ)).im=0)
    (hmean : (∫ x:ℝ in (0:ℝ)..1,φ (x:ℂ))=0) :
    ∃ s:ℝ,0<s ∧ ∃ c:ℝ,0<c ∧ ∃ C:ℝ,0<C ∧ ∀ α:ℝ,Irrational α→
      (∀ n:ℕ,
        (∀ z:ℂ,|z.im|≤s→
          ‖gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) z‖≤
            C*(((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*
              Real.exp (-c*((α.convergent n).den:ℝ)))) ∧
        (∀ z:ℂ,|z.im|≤s→
          ‖φ z-(gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) (z+α)-
            gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) z)‖≤
              C*Real.exp (-c*((α.convergent (n+1)).den:ℝ))) ∧
        (∀ x:ℝ,(gaugePotential ((α.convergent (n+1)).den) α (coefficient φ) (x:ℂ)).im=0)) ∧
      (beta α=0→
        DifferentiableOn ℂ (fullPotential α (coefficient φ)) (openStrip s) ∧
        (∀ z:ℂ,fullPotential α (coefficient φ) (z+1)=fullPotential α (coefficient φ) z) ∧
        (∀ x:ℝ,(fullPotential α (coefficient φ) (x:ℂ)).im=0) ∧
        (∀ z:ℂ,|z.im|≤s→
          fullPotential α (coefficient φ) (z+α)-fullPotential α (coefficient φ) z=φ z)) := by
  obtain ⟨c,hc,C,hC,hfinite⟩ := finite_scalar_gauge φ hH hD hP hreal hmean
  refine ⟨H/4,by positivity,c,hc,C,hC,?_⟩
  intro α hα
  exact ⟨hfinite α hα,fun hβ => beta_zero_scalar_gauge_actual φ hH hD hP hreal hmean α hα hβ⟩

theorem scalar_gauge_of_strip_extension (φ : ℝ→ℝ)
    (hφ : HasHolomorphicStripExtension φ)
    (hmean : (∫ x:ℝ in (0:ℝ)..1,φ x)=0) :
    ∃ Φ:ℂ→ℂ,(∀x:ℝ,Φ (x:ℂ)=(φ x:ℂ)) ∧
      ∃ s:ℝ,0<s ∧ ∃ c:ℝ,0<c ∧ ∃ C:ℝ,0<C ∧ ∀ α:ℝ,Irrational α→
        (∀ n:ℕ,
          (∀ z:ℂ,|z.im|≤s→
            ‖gaugePotential ((α.convergent (n+1)).den) α (coefficient Φ) z‖≤
              C*(((α.convergent n).den:ℝ)+((α.convergent (n+1)).den:ℝ)*
                Real.exp (-c*((α.convergent n).den:ℝ)))) ∧
          (∀ z:ℂ,|z.im|≤s→
            ‖Φ z-(gaugePotential ((α.convergent (n+1)).den) α (coefficient Φ) (z+α)-
              gaugePotential ((α.convergent (n+1)).den) α (coefficient Φ) z)‖≤
                C*Real.exp (-c*((α.convergent (n+1)).den:ℝ))) ∧
          (∀ x:ℝ,(gaugePotential ((α.convergent (n+1)).den) α (coefficient Φ) (x:ℂ)).im=0)) ∧
        (beta α=0→
          DifferentiableOn ℂ (fullPotential α (coefficient Φ)) (openStrip s) ∧
          (∀ z:ℂ,fullPotential α (coefficient Φ) (z+1)=fullPotential α (coefficient Φ) z) ∧
          (∀ x:ℝ,(fullPotential α (coefficient Φ) (x:ℂ)).im=0) ∧
          (∀ z:ℂ,|z.im|≤s→
            fullPotential α (coefficient Φ) (z+α)-fullPotential α (coefficient Φ) z=Φ z)) := by
  obtain ⟨H,hH,Φ,hD,hP,hrestrict⟩ := hφ
  have hreal : ∀x:ℝ,(Φ (x:ℂ)).im=0 := by intro x;rw [hrestrict];rfl
  have hmean' : (∫ x:ℝ in (0:ℝ)..1,Φ (x:ℂ))=0 := by
    simp only [hrestrict,intervalIntegral.integral_ofReal,hmean,Complex.ofReal_zero]
  exact ⟨Φ,hrestrict,scalar_gauge Φ hH hD hP hreal hmean'⟩

end UAMODraft.GeneralScalarGauge

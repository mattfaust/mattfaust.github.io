import UAMO.PhysicalRotationDOS
import UAMO.RealTransferAngleLift

noncomputable section
namespace UAMODraft.SeedLabel
open UAMO UAMO.StablePlane UAMO.ProjectiveAngle Matrix Filter
open scoped Topology

theorem angleVector_eq_of_positive_scales {f g c d:ℝ} {v:Plane}
    (hc:0<c) (hd:0<d) (hf:angleVector f=c • v) (hg:angleVector g=d • v) :
    angleVector f=angleVector g := by
  let k:=c/d
  have hk:0<k :=div_pos hc hd
  have he:angleVector f=k • angleVector g :=by
    rw [hf,hg,smul_smul]
    congr 1
    dsimp [k]
    field_simp
  have h0:=congrFun he 0
  have h1:=congrFun he 1
  change Real.cos f=k*Real.cos g at h0
  change Real.sin f=k*Real.sin g at h1
  have hsq:k^2=1 :=by
    calc
      _=k^2*(Real.sin g^2+Real.cos g^2) :=by rw [Real.sin_sq_add_cos_sq,mul_one]
      _=Real.sin f^2+Real.cos f^2 :=by rw [h0,h1];ring
      _=1 :=Real.sin_sq_add_cos_sq f
  have hk1:k=1 :=by nlinarith
  simpa only [hk1,one_smul] using he

theorem angleVector_eq_iff_int_turn (f g:ℝ) :
    angleVector f=angleVector g ↔ ∃k:ℤ,f=g+(k:ℝ)*(2*Real.pi) := by
  constructor
  · intro he
    have h0:=congrFun he 0
    have h1:=congrFun he 1
    change Real.cos f=Real.cos g at h0
    change Real.sin f=Real.sin g at h1
    have hc:Real.cos (f-g)=1 :=by
      rw [Real.cos_sub,h0,h1]
      nlinarith [Real.sin_sq_add_cos_sq g]
    obtain ⟨k,hk⟩:=(Real.cos_eq_one_iff _).mp hc
    exact ⟨k,by linarith⟩
  · rintro ⟨k,rfl⟩
    ext i
    fin_cases i <;> simp [angleVector,Real.cos_add_int_mul_two_pi,Real.sin_add_int_mul_two_pi]

theorem continuous_integer_valued_constant_connected {X:Type*}
    [TopologicalSpace X] [PreconnectedSpace X] [Nonempty X]
    (f:X→ℝ) (hf:Continuous f) (hint:∀x,∃k:ℤ,f x=(k:ℝ)) :
    ∃k:ℤ,∀x,f x=(k:ℝ) := by
  choose k hk using hint
  have hc:Continuous (fun x=>(k x:ℝ)) :=by
    have he:(fun x=>(k x:ℝ))=f :=funext (fun x=>(hk x).symm)
    rw [he]
    exact hf
  have hkc:Continuous k :=Int.isClosedEmbedding_coe_real.isEmbedding.isInducing.continuous_iff.mpr hc
  let x₀:X:=Classical.choice inferInstance
  refine ⟨k x₀,fun x=>?_⟩
  rw [hk x,TotallyDisconnectedSpace.eq_of_continuous k hkc x x₀]

theorem genuine_lifts_differ_by_integer_turn
    (A:ℝ→PlaneMatrix) (F G:ℝ→ℝ→ℝ)
    (hF:Continuous (fun p:ℝ×ℝ=>F p.1 p.2))
    (hG:Continuous (fun p:ℝ×ℝ=>G p.1 p.2))
    (hFd:∀x s,∃c:ℝ,0<c ∧ angleVector (F x s)=c • (A x*ᵥangleVector s))
    (hGd:∀x s,∃c:ℝ,0<c ∧ angleVector (G x s)=c • (A x*ᵥangleVector s)) :
    ∃k:ℤ,∀x s,F x s=G x s+(k:ℝ)*(2*Real.pi) := by
  let d:ℝ×ℝ→ℝ:=fun p=>(F p.1 p.2-G p.1 p.2)/(2*Real.pi)
  have hd:Continuous d :=(hF.sub hG).div_const _
  have hint (p:ℝ×ℝ):∃k:ℤ,d p=(k:ℝ) :=by
    obtain ⟨c,hc,hfc⟩:=hFd p.1 p.2
    obtain ⟨e,he,hge⟩:=hGd p.1 p.2
    obtain ⟨k,hk⟩:=(angleVector_eq_iff_int_turn _ _).mp
      (angleVector_eq_of_positive_scales hc he hfc hge)
    refine ⟨k,?_⟩
    dsimp [d]
    rw [hk]
    field_simp
  obtain ⟨k,hk⟩:=continuous_integer_valued_constant_connected d hd hint
  refine ⟨k,fun x s=>?_⟩
  have hh:=(div_eq_iff (show 2*Real.pi≠0 by positivity)).mp (hk (x,s))
  dsimp [d] at hh
  linarith

theorem angleIterate_integer_turn_shift (F G:ℝ→ℝ→ℝ)
    (hG:∀x s,G x (s+Real.pi)=G x s+Real.pi) (k:ℤ)
    (hFG:∀x s,F x s=G x s+(k:ℝ)*(2*Real.pi)) (α x s:ℝ) (n:ℕ) :
    angleIterate F α x s n=angleIterate G α x s n+(n:ℝ)*(k:ℝ)*(2*Real.pi) :=by
  induction n with
  | zero=>simp
  | succ n ih=>
    rw [angleIterate_succ,ih,hFG]
    have he:(n:ℝ)*(k:ℝ)*(2*Real.pi)=((2*(n:ℤ)*k:ℤ):ℝ)*Real.pi :=by push_cast;ring
    rw [he,angleMap_add_int_pi G hG,angleIterate_succ]
    push_cast
    ring

end UAMODraft.SeedLabel

import UAMODraft.SeedGapReflection
noncomputable section
namespace UAMODraft.OddSeed
open UAMO

theorem gapLabel_lift_representative {α : ℝ} (hα : Irrational α) (m ell : ℤ) :
    ∃ e : Fin 2,uamoGapLabel α m ell=uamoGapLabel α m (e:ℤ) :=by
  by_cases he : Even ell
  · refine ⟨0,(uamoGapLabel_eq_iff hα m ell m 0).mpr ⟨rfl,?_⟩⟩
    simpa using he
  · have ho : Odd ell :=Int.not_even_iff_odd.mp he
    refine ⟨1,(uamoGapLabel_eq_iff hα m ell m 1).mpr ⟨rfl,?_⟩⟩
    obtain ⟨k,hk⟩ :=ho
    exact ⟨k,by omega⟩

theorem all_gapLabel_lifts_of_two {a r α : ℝ}
    (ha : 0≤a) (ha1 : a≤1) (hr : 0≤r) (hr1 : r≤1) (hα : Irrational α) (m : ℤ)
    (hboth : ∀ e : Fin 2,OpenDOSGapLabel a r α ha ha1 hr hr1 (uamoGapLabel α m (e:ℤ))) :
    ∀ell : ℤ,OpenDOSGapLabel a r α ha ha1 hr hr1 (uamoGapLabel α m ell) :=by
  intro ell
  obtain ⟨e,he⟩ :=gapLabel_lift_representative hα m ell
  rw [he]
  exact hboth e

end UAMODraft.OddSeed

import UAMODraft.SignedOpeningWindow
import UAMODraft.OrientedCircleOpening
import UAMODraft.OrientedOpeningRotation

noncomputable section
namespace UAMODraft.OneSidedOpening
open UAMODraft.QuantitativeOpening UAMODraft.OpeningAssembly UAMODraft.PositiveCone
open UAMODraft.CoverHyperbolicity UAMODraft.CircleCover UAMODraft.PositiveAngle
open UAMO.StablePlane UAMO.ProjectiveAngle Matrix Filter Set
open scoped Matrix.L2OpNorm Topology

theorem quantitative_opening_on_interval
    (I : Set ℝ) (hI : OrdConnected I)
    (α q₀ q₁ K d σ t₀ : ℝ) (hq₀ : 0<q₀) (hK : 2≤K)
    (hd : 0 < |d|) (hd1 : |d|≤1) (hσ : |σ|=1) (ht₀ : t₀∈I)
    (A Q D : ℝ → ℝ → Mat2) (B E : ℝ → Mat2)
    (hAcont : ∀t∈I, Continuous (A t))
    (hAper : ∀t∈I, Function.Periodic (A t) 1)
    (hBcont : Continuous B) (hBdet : ∀x,(B x).det=1) (hB : ∀x,‖B x‖≤K)
    (hE : ∀x,‖E x‖≤openingC0 q₀ q₁*|d|/K^4)
    (hnormal : ∀x,σ • ((B (x+α))⁻¹*A t₀ x*B x)=shear d+E x)
    (hAdet : ∀t∈I,∀x,(A t x).det=1)
    (hder : ∀t∈I,∀x,HasDerivAt (fun u=>A u x) (D t x) t)
    (hgen : ∀t∈I,∀x,(A t x)⁻¹*D t x=UAMODraft.QuantitativeOpening.J*Q t x)
    (hsym : ∀t∈I,∀x,(Q t x).transpose=Q t x)
    (hlo : ∀t∈I,∀x,∀v:Vec2,
      q₀*(∑ i,(v i)^2)≤∑ i,v i*(Q t x*ᵥv) i)
    (hup : ∀t∈I,∀x,∀v:Vec2,
      (∑ i,v i*(Q t x*ᵥv) i)≤q₁*(∑ i,(v i)^2))
    (b : ℝ → ℝ) (hb : Continuous b)
    (hcol : ∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (m:ℤ) (hwind : ∀x,b (x+1)=b x+(m:ℝ)*Real.pi)
    (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hwindow : ∀s,Real.sign s=Real.sign d →
      (openingC1 q₁*|d|/K^2)/2 < |s| → |s|<openingC1 q₁*|d|/K^2 → t₀+s∈I)
    (s : ℝ) (hsign : Real.sign s=Real.sign d)
    (hslo : (openingC1 q₁*|d|/K^2)/2 < |s|)
    (hshi : |s|<openingC1 q₁*|d|/K^2) :
    IsUniformlyHyperbolicOnLines (translation 1 α)
      (periodicLift (A (t₀+s)) (hAper (t₀+s) (hwindow s hsign hslo hshi))) ∧
    ∃F:ℝ → ℝ → ℝ,
      Continuous (fun p:ℝ×ℝ => F p.1 p.2) ∧
      (∀θ,Function.Periodic (fun x => F x θ) 1) ∧
      (∀x θ,∃c:ℝ,0<c ∧ angleVector (F x θ)=c • (A (t₀+s) x*ᵥangleVector θ)) ∧
      (∀x,StrictMono (F x)) ∧
      (∀x θ,F x (θ+Real.pi)=F x θ+Real.pi) ∧
      (∀x θ,Tendsto (fun n:ℕ => (angleIterate F α x θ n-θ)/(2*Real.pi*(n:ℝ)))
        atTop (𝓝 ((m:ℝ)*α/2+(1-σ)/4))) :=by
  let T:=openingC1 q₁*|d|/K^2
  have hT:0<T := (opening_scale_bounds q₀ q₁ K d hq₀ hK hd).1
  have horiented:T/2<Real.sign d*s ∧ Real.sign d*s<T :=
    (printed_window_iff_oriented hd).mp ⟨hsign,hslo,hshi⟩
  have hs:orientedWindow (Real.sign d) T s :=⟨by linarith [horiented.1],horiented.2⟩
  have hmem : ∀t,orientedWindow (Real.sign d) T t → t₀+t∈I :=by
    intro t ht
    apply interval_contains_oriented_window_segment I hI (sign_d_abs d hd) hT ht₀ ?_ ht
    intro u hu₁ hu₂
    obtain ⟨he,hlo,hhi⟩ := (printed_window_iff_oriented hd).mpr ⟨hu₁,hu₂⟩
    exact hwindow u he hlo hhi
  constructor
  · exact quantitative_opening_ordinaryCircle_oriented α m q₀ q₁ K d σ t₀ hq₀ hK hd hd1
      (sign_sq_one hσ) A Q D B E
      (fun t ht=>hAcont (t₀+t) (hmem t ht)) (fun t ht=>hAper (t₀+t) (hmem t ht))
      hBcont hanti hBdet hB hE hnormal
      (fun x t ht=>hAdet (t₀+t) (hmem t ht) x)
      (fun x t ht=>hder (t₀+t) (hmem t ht) x)
      (fun x t ht=>hgen (t₀+t) (hmem t ht) x)
      (fun x t ht=>hsym (t₀+t) (hmem t ht) x)
      (fun x t ht=>hlo (t₀+t) (hmem t ht) x)
      (fun x t ht=>hup (t₀+t) (hmem t ht) x) s hs horiented.1.le
  · exact original_family_opening_rotation_oriented α q₀ q₁ K d σ t₀ hq₀ hK hd hd1 hσ
      A Q D B E (fun t ht=>hAcont (t₀+t) (hmem t ht))
      (fun t ht=>hAper (t₀+t) (hmem t ht)) hBcont hBdet hB hE hnormal
      (fun x t ht=>hAdet (t₀+t) (hmem t ht) x)
      (fun x t ht=>hder (t₀+t) (hmem t ht) x)
      (fun x t ht=>hgen (t₀+t) (hmem t ht) x)
      (fun x t ht=>hsym (t₀+t) (hmem t ht) x)
      (fun x t ht=>hlo (t₀+t) (hmem t ht) x)
      (fun x t ht=>hup (t₀+t) (hmem t ht) x)
      b hb hcol m hwind hanti s hs horiented.1.le

end UAMODraft.OneSidedOpening

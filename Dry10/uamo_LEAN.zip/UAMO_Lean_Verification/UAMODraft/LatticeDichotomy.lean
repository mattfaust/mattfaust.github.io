import UAMODraft.WeightedLattice
import UAMODraft.DichotomyInverse
noncomputable section
namespace UAMODraft.SpectralBridge
open UAMO UAMO.PhysicalWalk UAMO.PhysicalRepresentation UAMO.PhysicalRealPart UAMO.CMV Matrix

def forwardProjected (A P : ℤ → Mat) (n : ℤ) : ℕ → Mat
  | 0 => P n
  | k+1 => A (n-1) * forwardProjected A P (n-1) k

def backwardProjected (B P : ℤ → Mat) (n : ℤ) : ℕ → Mat
  | 0 => 1-P n
  | k+1 => B n * backwardProjected B P (n+1) k

structure LatticeDichotomy where
  A : ℤ → Mat
  B : ℤ → Mat
  P : ℤ → Mat
  CA : ℝ
  CB : ℝ
  CP : ℝ
  CA_nonneg : 0 ≤ CA
  CB_nonneg : 0 ≤ CB
  CP_nonneg : 0 ≤ CP
  A_bound : ∀ n i j, ‖A n i j‖ ≤ CA
  B_bound : ∀ n i j, ‖B n i j‖ ≤ CB
  P_bound : ∀ n i j, ‖P n i j‖ ≤ CP
  inverse : ∀ n, A n * B n=1
  idempotent : ∀ n, P n * P n=P n
  invariant : ∀ n, A n * P n=P (n+1) * A n
  K : ℝ
  q : ℝ
  K_nonneg : 0 ≤ K
  q_nonneg : 0 ≤ q
  q_lt_one : q < 1
  forward_bound : ∀ n k i j, ‖forwardProjected A P n k i j‖ ≤ K*q^k
  backward_bound : ∀ n k i j, ‖backwardProjected B P n k i j‖ ≤ K*q^k

namespace LatticeDichotomy
variable (D : LatticeDichotomy)

def evolution : OperatorMatrix :=
  weightedLattice (fun n => D.A (n-1)) (Equiv.subRight 1) D.CA D.CA_nonneg (fun n => D.A_bound (n-1))
def inverseEvolution : OperatorMatrix :=
  weightedLattice D.B (Equiv.addRight 1) D.CB D.CB_nonneg D.B_bound
def projection : OperatorMatrix :=
  weightedLattice D.P (Equiv.refl ℤ) D.CP D.CP_nonneg D.P_bound

@[simp] theorem evolution_apply (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction D.evolution ψ) n=D.A (n-1) *ᵥ siteVector ψ (n-1) := by
  simpa only [evolution,Equiv.subRight_apply] using
    weightedLattice_apply (fun n => D.A (n-1)) (Equiv.subRight 1) D.CA D.CA_nonneg
      (fun n => D.A_bound (n-1)) ψ n

@[simp] theorem inverseEvolution_apply (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction D.inverseEvolution ψ) n=D.B n *ᵥ siteVector ψ (n+1) := by
  simpa only [inverseEvolution] using
    weightedLattice_apply D.B (Equiv.addRight 1) D.CB D.CB_nonneg D.B_bound ψ n

@[simp] theorem projection_apply (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction D.projection ψ) n=D.P n *ᵥ siteVector ψ n := by
  simpa only [projection,Equiv.refl_apply] using
    weightedLattice_apply D.P (Equiv.refl ℤ) D.CP D.CP_nonneg D.P_bound ψ n

theorem evolution_inverse : D.evolution * D.inverseEvolution=1 := by
  apply operatorMatrix_eq_of_site
  intro ψ n
  rw [spinAction_mul,D.evolution_apply,D.inverseEvolution_apply]
  simp only [sub_add_cancel,Matrix.mulVec_mulVec,D.inverse,Matrix.one_mulVec,spinAction_one]

theorem inverse_evolution : D.inverseEvolution * D.evolution=1 := by
  apply operatorMatrix_eq_of_site
  intro ψ n
  rw [spinAction_mul,D.inverseEvolution_apply,D.evolution_apply]
  simp only [add_sub_cancel_right,Matrix.mulVec_mulVec,
    Matrix.mul_eq_one_comm.mp (D.inverse n),Matrix.one_mulVec,spinAction_one]

theorem projection_idempotent : D.projection * D.projection=D.projection := by
  apply operatorMatrix_eq_of_site
  intro ψ n
  rw [spinAction_mul,D.projection_apply,D.projection_apply,
    Matrix.mulVec_mulVec,D.idempotent]

theorem evolution_projection : D.evolution * D.projection=D.projection * D.evolution := by
  apply operatorMatrix_eq_of_site
  intro ψ n
  rw [spinAction_mul,spinAction_mul,D.evolution_apply,D.projection_apply,
    D.projection_apply,D.evolution_apply,Matrix.mulVec_mulVec,Matrix.mulVec_mulVec,D.invariant]
  simp only [sub_add_cancel]

theorem inverse_projection : D.inverseEvolution * D.projection=D.projection * D.inverseEvolution := by
  calc
    D.inverseEvolution * D.projection = D.inverseEvolution * D.projection *
        (D.evolution * D.inverseEvolution) := by rw [D.evolution_inverse,mul_one]
    _ = D.inverseEvolution * (D.projection * D.evolution) * D.inverseEvolution := by noncomm_ring
    _ = D.inverseEvolution * (D.evolution * D.projection) * D.inverseEvolution := by
      rw [←D.evolution_projection]
    _ = D.projection * D.inverseEvolution := by
      rw [←mul_assoc D.inverseEvolution D.evolution,D.inverse_evolution,one_mul]

theorem forward_power_apply (k : ℕ) (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction (D.evolution^k*D.projection) ψ) n=
      forwardProjected D.A D.P n k *ᵥ siteVector ψ (n-(k:ℤ)) := by
  induction k generalizing n with
  | zero => simp only [pow_zero,one_mul,D.projection_apply,forwardProjected,Nat.cast_zero,sub_zero]
  | succ k ih =>
    rw [pow_succ',mul_assoc,spinAction_mul,D.evolution_apply,ih,Matrix.mulVec_mulVec]
    change (D.A (n-1)*forwardProjected D.A D.P (n-1) k) *ᵥ siteVector ψ (n-1-(k:ℤ)) = _
    rw [forwardProjected]
    push_cast
    ring

theorem backward_power_apply (k : ℕ) (ψ : SpinHilbert) (n : ℤ) :
    siteVector (spinAction (D.inverseEvolution^k*(1-D.projection)) ψ) n=
      backwardProjected D.B D.P n k *ᵥ siteVector ψ (n+(k:ℤ)) := by
  induction k generalizing n with
  | zero =>
    simp only [pow_zero,one_mul,spinAction_matrix_sub,spinAction_one,siteVector_sub,
      D.projection_apply,backwardProjected,Nat.cast_zero,add_zero,Matrix.sub_mulVec,Matrix.one_mulVec]
  | succ k ih =>
    rw [pow_succ',mul_assoc,spinAction_mul,D.inverseEvolution_apply,ih,Matrix.mulVec_mulVec]
    rw [backwardProjected]
    push_cast
    ring

theorem forward_power_norm (k : ℕ) :
    ‖cstarMatrix D.evolution^k*cstarMatrix D.projection‖ ≤ (4*D.K)*D.q^k := by
  have hK : 0 ≤ D.K*D.q^k := mul_nonneg D.K_nonneg (pow_nonneg D.q_nonneg k)
  have he : D.evolution^k*D.projection=
      weightedLattice (fun n => forwardProjected D.A D.P n k) (Equiv.subRight (k:ℤ))
        (D.K*D.q^k) hK (fun n i j => D.forward_bound n k i j) := by
    apply operatorMatrix_eq_of_site
    intro ψ n
    rw [D.forward_power_apply,weightedLattice_apply]
    rfl
  rw [←map_pow,←map_mul,he]
  exact (weightedLattice_norm _ _ _ _ _).trans_eq (by ring)

theorem backward_power_norm (k : ℕ) :
    ‖cstarMatrix D.inverseEvolution^k*(1-cstarMatrix D.projection)‖ ≤ (4*D.K)*D.q^k := by
  have hK : 0 ≤ D.K*D.q^k := mul_nonneg D.K_nonneg (pow_nonneg D.q_nonneg k)
  have he : D.inverseEvolution^k*(1-D.projection)=
      weightedLattice (fun n => backwardProjected D.B D.P n k) (Equiv.addRight (k:ℤ))
        (D.K*D.q^k) hK (fun n i j => D.backward_bound n k i j) := by
    apply operatorMatrix_eq_of_site
    intro ψ n
    rw [D.backward_power_apply,weightedLattice_apply]
    rfl
  rw [←map_pow,←map_one cstarMatrix,←map_sub,←map_mul,he]
  exact (weightedLattice_norm _ _ _ _ _).trans_eq (by ring)

theorem one_sub_evolution_isUnit : IsUnit (1-D.evolution) := by
  have hi := isUnit_one_sub_of_exponential_dichotomy
    (cstarMatrix D.evolution) (cstarMatrix D.inverseEvolution) (cstarMatrix D.projection)
    (by rw [←map_mul,D.evolution_inverse,map_one])
    (by rw [←map_mul,D.inverse_evolution,map_one])
    (by rw [←map_mul,D.projection_idempotent])
    (by simp only [←map_mul,D.evolution_projection])
    (by simp only [←map_mul,D.inverse_projection])
    D.q_nonneg D.q_lt_one D.forward_power_norm D.backward_power_norm
  have h : IsUnit (cstarMatrix (1-D.evolution)) := by simpa only [map_sub,map_one] using hi
  simpa using h.map cstarMatrix.symm.toMonoidHom

theorem latticeDifference_isUnit :
    IsUnit (latticeDifference D.A D.CA D.CA_nonneg D.A_bound) := by
  have hs : IsUnit latticeForwardShift := by
    refine ⟨⟨latticeForwardShift,Matrix.diagonal (fun _ : Fin 2 => shift),?_,?_⟩,rfl⟩
    · ext i j
      fin_cases i <;> fin_cases j <;>
        simp [latticeForwardShift,Matrix.mul_apply,Fin.sum_univ_two,
          unitary.star_mul_self_of_mem shift_unitary]
    · ext i j
      fin_cases i <;> fin_cases j <;>
        simp [latticeForwardShift,Matrix.mul_apply,Fin.sum_univ_two,
          unitary.mul_star_self_of_mem shift_unitary]
  have he : latticeDifference D.A D.CA D.CA_nonneg D.A_bound =
      latticeForwardShift*(1-D.evolution) := by
    apply operatorMatrix_eq_of_site
    intro ψ n
    rw [latticeDifference_apply,spinAction_mul,latticeForwardShift_apply,
      spinAction_matrix_sub,siteVector_sub,spinAction_one,D.evolution_apply]
    simp only [add_sub_cancel_right]
  rw [he]
  exact hs.mul D.one_sub_evolution_isUnit

end LatticeDichotomy
end UAMODraft.SpectralBridge

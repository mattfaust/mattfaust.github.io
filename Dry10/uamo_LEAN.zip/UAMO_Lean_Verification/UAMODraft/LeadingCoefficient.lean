import UAMODraft.DenominatorOrder
import UAMODraft.LeadingStep

noncomputable section
set_option maxHeartbeats 1000000
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology

def leadingCoefficient (z q : ℂ) : ℕ → ℂ
  | 0 => 1
  | j+1 => -(2*Complex.I)⁻¹ *
      (divisor z q (spin (-((j+1:ℕ):ℤ))) (-((j+1:ℕ):ℤ)))⁻¹ * leadingCoefficient z q j

theorem branch_negative_leading {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : z^2=q^m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0)
    (j : ℕ) (hj : j<m) :
    (fun lam => coefficient m (x lam) (-(j:ℤ))-leadingCoefficient z q j*(lam:ℂ)^j)
      =O[nhds (0:ℝ)] (fun lam => lam^(j+2)) := by
  revert hj
  induction j with
  | zero =>
    intro _
    simpa [coefficient,leadingCoefficient] using
      (isBigO_zero (fun lam : ℝ => lam^(0+2)) (nhds (0:ℝ)) :
        (fun _ : ℝ => (0:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam^(0+2)))
  | succ j ih =>
    intro hj
    let k : Mode m := ⟨-((j+1:ℕ):ℤ),by simp only [Finset.mem_Icc]; constructor <;> omega⟩
    have hk : (k:ℤ)≠0 := by dsimp [k]; omega
    have hkp : (k:ℤ)+1=-(j:ℤ) := by dsimp [k]; omega
    have hkm : (k:ℤ)-1=-((j+2:ℕ):ℤ) := by dsimp [k]; omega
    have hrec : ∀ᶠ (lam : ℝ) in nhds 0,
        coefficient m (x lam) (k:ℤ)=-(2*Complex.I)⁻¹*(lam:ℂ)*
          (denominator m hm z q (x lam) k)⁻¹*
          (coefficient m (x lam) (-(j:ℤ))-coefficient m (x lam) (-((j+2:ℕ):ℤ))) := by
      filter_upwards [branch_recurrence hz hq0 hq m hm hres x hx0 hxa.continuousAt hxe k hk] with lam h
      simpa only [hkp,hkm,div_eq_mul_inv,mul_assoc,mul_left_comm,mul_comm] using h
    have hc := branch_coefficient_order hz hq0 hq m hm hres x hx0 hxa hxe (j+2) (-((j+2:ℕ):ℤ))
      (by rw [abs_neg,abs_of_nonneg (by positivity)])
    have hstep := leading_recurrence_step
      (fun lam => coefficient m (x lam) (k:ℤ))
      (fun lam => coefficient m (x lam) (-(j:ℤ)))
      (fun lam => coefficient m (x lam) (-((j+2:ℕ):ℤ)))
      (fun lam => (denominator m hm z q (x lam) k)⁻¹)
      ((2*Complex.I)⁻¹) ((divisor z q (spin k) k)⁻¹) (leadingCoefficient z q j) j
      hrec (ih (by omega)) hc
      (branch_inverse_isBigO hz hq0 hq m hm hres x hx0 hxa.continuousAt k hk)
      (branch_inverse_difference_order hz hq0 hq m hm hres x hx0 hxa hxe k hk)
    simpa only [k,leadingCoefficient,Nat.succ_eq_add_one,Nat.add_assoc] using hstep

end UAMODraft.OddSeed

import UAMODraft.Orders

noncomputable section
namespace UAMODraft.OddSeed
open Asymptotics Filter
open scoped Topology

theorem complex_monomial_isBigO (L : ℂ) (j : ℕ) :
    (fun lam : ℝ => L*(lam:ℂ)^j) =O[nhds (0:ℝ)] (fun lam => lam^j) := by
  apply IsBigO.const_mul_left
  exact isBigO_of_le _ (fun lam => by simp [norm_pow])

theorem leading_recurrence_step (a b c d : ℝ → ℂ) (κ D L : ℂ) (j : ℕ)
    (hrec : ∀ᶠ (lam : ℝ) in nhds 0, a lam=-κ*(lam:ℂ)*d lam*(b lam-c lam))
    (hb : (fun lam => b lam-L*(lam:ℂ)^j) =O[nhds (0:ℝ)] (fun lam => lam^(j+2)))
    (hc : c =O[nhds (0:ℝ)] (fun lam => lam^(j+2)))
    (hd : d =O[nhds (0:ℝ)] (fun _ => (1:ℝ)))
    (hdiff : (fun lam => d lam-D) =O[nhds (0:ℝ)] (fun lam => lam^2)) :
    (fun lam => a lam-(-κ*D*L)*(lam:ℂ)^(j+1)) =O[nhds (0:ℝ)]
      (fun lam => lam^(j+3)) := by
  have h₁ : (fun lam => d lam*(b lam-L*(lam:ℂ)^j)) =O[nhds (0:ℝ)]
      (fun lam => lam^(j+2)) := by simpa only [one_mul] using hd.mul hb
  have h₂ : (fun lam => (d lam-D)*(L*(lam:ℂ)^j)) =O[nhds (0:ℝ)]
      (fun lam => lam^(j+2)) := by
    simpa only [pow_add,mul_comm] using hdiff.mul (complex_monomial_isBigO L j)
  have h₃ : (fun lam => d lam*c lam) =O[nhds (0:ℝ)]
      (fun lam => lam^(j+2)) := by simpa only [one_mul] using hd.mul hc
  have hlam : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
    isBigO_of_le _ (fun lam => by simp)
  have hbnd := (hlam.mul ((h₁.add h₂).sub h₃)).const_mul_left (-κ)
  have heq : ∀ᶠ (lam : ℝ) in nhds 0,
      -κ*((lam:ℂ)*(d lam*(b lam-L*(lam:ℂ)^j)+(d lam-D)*(L*(lam:ℂ)^j)-d lam*c lam))=
      a lam-(-κ*D*L)*(lam:ℂ)^(j+1) := by
    filter_upwards [hrec] with lam h
    rw [h,pow_succ]
    ring
  have h := hbnd.congr' heq EventuallyEq.rfl
  convert h using 1
  funext lam
  rw [show j+3=(j+2)+1 by omega,pow_succ]
  ring

end UAMODraft.OddSeed

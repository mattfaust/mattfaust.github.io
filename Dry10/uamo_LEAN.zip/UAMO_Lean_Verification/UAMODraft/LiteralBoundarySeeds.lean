import UAMODraft.AllOddBoundarySeeds
noncomputable section
namespace UAMODraft.OddSeed
open UAMO UAMO.CircleDOS UAMO.PhysicalDOS

theorem literal_all_odd_boundary_seed_gaps {α : ℝ} (hα : Irrational α)
    (m : ℤ) (hm : Odd m) :
    ∃ ε : ℝ, 0 < ε ∧ ε < 1 ∧ ∀ (lam : ℝ) (hlam : 0 < lam), lam < ε →
      ∃ hr1 : inverseCoupling lam < 1, ∀ ell : ℤ,
        (∃ t δ : ℝ, 0 < δ ∧ ∀ s : ℝ, |s-t| < δ →
          (∀ θ : ℝ, Complex.exp ((s:ℂ)*Complex.I) ∈ resolventSet ℂ
            (PhysicalRepresentation.walk 1 lam α θ)) ∧
          ((arcLabel (physicalUnitaryDOS 1 (inverseCoupling lam) α
            (by norm_num) (by norm_num) (inverseCoupling_pos hlam).le hr1.le)
            (Complex.exp ((s:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ))=uamoGapLabel α m ell) ∧
        (∃ t δ : ℝ, 0 < δ ∧ ∀ s : ℝ, |s-t| < δ →
          (∀ θ : ℝ, Complex.exp ((s:ℂ)*Complex.I) ∈ resolventSet ℂ
            (PhysicalRepresentation.walk lam 1 α θ)) ∧
          ((arcLabel (physicalUnitaryDOS (inverseCoupling lam) 1 α
            (inverseCoupling_pos hlam).le hr1.le (by norm_num) (by norm_num))
            (Complex.exp ((s:ℂ)*Complex.I)):ℝ):AddCircle (1:ℝ))=uamoGapLabel α m ell) := by
  obtain ⟨ε,hε,hε1,hseed⟩ := all_odd_boundary_seed_gaps_physical_coupling hα m hm
  refine ⟨ε,hε,hε1,?_⟩
  intro lam hlam hlame
  obtain ⟨hr1,hg⟩ := hseed lam hlam hlame
  refine ⟨hr1,?_⟩
  intro ell
  have h := hg ell
  have hc : coupling 1 = 1 := by norm_num [coupling]
  have hi := coupling_inverseCoupling hlam.le (hlame.trans hε1).le
  simpa only [OpenDOSGapLabel,hc,hi] using h

end UAMODraft.OddSeed

import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Data.Matrix.Notation
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic

noncomputable section
namespace UAMODraft
open Matrix

theorem wronskian_determinant_step
    (T X R : Matrix (Fin 2) (Fin 2) ℂ) :
    (T*X+R).det-T.det*X.det =
      ((T*X) 0 0*R 1 1-(T*X) 1 0*R 0 1) +
      (R 0 0*(T*X) 1 1-R 1 0*(T*X) 0 1) + R.det := by
  rw [← Matrix.det_mul]
  simp only [Matrix.det_fin_two, Matrix.add_apply]
  ring

theorem opening_riccati_derivative
    (r u : ℝ→ℝ) (a b c s : ℝ)
    (hr : HasDerivAt r (a*u s-b*r s) s)
    (hu : HasDerivAt u (b*u s-c*r s) s) (hu0 : u s ≠ 0) :
    HasDerivAt (fun t => r t/u t)
      (a-2*b*(r s/u s)+c*(r s/u s)^2) s := by
  convert hr.div hu hu0 using 1
  field_simp
  ring

end UAMODraft

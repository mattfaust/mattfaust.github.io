import UAMODraft.TwistDerivative

noncomputable section
namespace UAMODraft
open UAMO

theorem twistedTerm_hasDerivAt_y (A : MagneticOperator) (j k x y : ℝ) (c : ℂ) :
    HasDerivAt (fun t : ℝ => twistedTerm A j k c x t)
      ((twistCharacter j k x y*((k : ℂ)*Complex.I)*c) • A) y :=
  ((twistCharacter_hasDerivAt_y j k x y).mul_const c).smul_const A

theorem twistedTerm_reverse_mixed_at_zero (A : MagneticOperator) (j k : ℝ) (c : ℂ) :
    HasDerivAt (fun x : ℝ => deriv (fun y : ℝ => twistedTerm A j k c x y) 0)
      ((-((j*k : ℝ) : ℂ)*c) • A) 0 := by
  have he (x : ℝ) := (twistedTerm_hasDerivAt_y A j k x 0 c).deriv
  simp_rw [he]
  have h := (((twistCharacter_hasDerivAt_x j k 0 0).mul_const
    ((k : ℂ)*Complex.I)).mul_const c).smul_const A
  convert h using 1
  simp only [twistCharacter_zero, one_mul, Complex.ofReal_mul]
  congr 1
  ring_nf
  simp

theorem twistedPair_reverse_mixed_at_zero (φ : ℝ) (ν : MagneticSite)
    (j k : ℝ) (c : ℂ) :
    HasDerivAt (fun x : ℝ => deriv (fun y : ℝ => twistedPair φ ν j k c x y) 0)
      ((-((j*k : ℝ) : ℂ)) • magneticPair φ ν c) 0 := by
  have he (x : ℝ) := ((twistedTerm_hasDerivAt_y (magneticShift φ ν) j k x 0 c).add
    (twistedTerm_hasDerivAt_y (magneticShift φ (-ν)) (-j) (-k) x 0 (star c))).deriv
  have hm := (twistedTerm_reverse_mixed_at_zero (magneticShift φ ν) j k c).add
    (twistedTerm_reverse_mixed_at_zero (magneticShift φ (-ν)) (-j) (-k) (star c))
  convert hm using 1
  · funext x
    unfold twistedPair
    rw [he]
    rw [(twistedTerm_hasDerivAt_y (magneticShift φ ν) j k x 0 c).deriv,
      (twistedTerm_hasDerivAt_y (magneticShift φ (-ν)) (-j) (-k) x 0 (star c)).deriv]
  · simp [magneticPair, smul_add, smul_smul]

theorem twistedDraftHamiltonian_reverse_mixed_at_zero (a r α : ℝ) :
    HasDerivAt (fun x : ℝ => deriv (fun y : ℝ => twistedDraftHamiltonian a r α x y) 0)
      (magneticPair (Real.pi*α) (1,-1) 1 -
        magneticPair (Real.pi*α) (1,1) (-(r:ℂ)^2)) 0 := by
  let φ := Real.pi*α
  let b := (r:ℂ)*diagonalHopping a (-Real.pi*α)
  have he (x : ℝ) :
      deriv (fun y : ℝ => twistedDraftHamiltonian a r α x y) 0 =
        deriv (fun y : ℝ => twistedPair φ (1,-1) 1 (-1) 1 x y) 0 +
        deriv (fun y : ℝ => twistedPair φ (0,1) 0 1 b x y) 0 +
        deriv (fun y : ℝ => twistedPair φ (1,1) 1 1 (-(r:ℂ)^2) x y) 0 := by
    have hd (ν : MagneticSite) (j k : ℝ) (c : ℂ) :
        DifferentiableAt ℝ (fun y => twistedPair φ ν j k c x y) 0 :=
      ((twistedTerm_hasDerivAt_y (magneticShift φ ν) j k x 0 c).add
        (twistedTerm_hasDerivAt_y (magneticShift φ (-ν)) (-j) (-k) x 0 (star c))).differentiableAt
    change deriv (fun y => twistedPair φ (1,-1) 1 (-1) 1 x y +
      twistedPair φ (0,1) 0 1 b x y +
      twistedPair φ (1,1) 1 1 (-(r:ℂ)^2) x y) 0 = _
    rw [deriv_add ((hd (1,-1) 1 (-1) 1).add (hd (0,1) 0 1 b))
      (hd (1,1) 1 1 (-(r:ℂ)^2)),
      deriv_add (hd (1,-1) 1 (-1) 1) (hd (0,1) 0 1 b)]
  simp_rw [he]
  have h := ((twistedPair_reverse_mixed_at_zero φ (1,-1) 1 (-1) 1).add
    (twistedPair_reverse_mixed_at_zero φ (0,1) 0 1 b)).add
    (twistedPair_reverse_mixed_at_zero φ (1,1) 1 1 (-(r:ℂ)^2))
  simpa [φ, sub_eq_add_neg] using h

theorem twistedDraftHamiltonian_mixed_derivatives_commute (a r α : ℝ) :
    deriv (fun x : ℝ => deriv (fun y : ℝ => twistedDraftHamiltonian a r α x y) 0) 0 =
      deriv (fun y : ℝ => deriv (fun x : ℝ => twistedDraftHamiltonian a r α x y) 0) 0 := by
  rw [(twistedDraftHamiltonian_reverse_mixed_at_zero a r α).deriv,
    (twistedDraftHamiltonian_mixed_at_zero a r α).deriv]

theorem radial_eq_identity_sub_printed_mixed_twist (a r α : ℝ) :
    r • deriv (fun t : ℝ => draftHamiltonian a t α) r =
      draftHamiltonian a r α -
        deriv (fun x : ℝ => deriv (fun y : ℝ =>
          twistedDraftHamiltonian a r α x y) 0) 0 := by
  rw [twistedDraftHamiltonian_mixed_derivatives_commute]
  exact radial_eq_identity_sub_mixed_twist a r α

end UAMODraft

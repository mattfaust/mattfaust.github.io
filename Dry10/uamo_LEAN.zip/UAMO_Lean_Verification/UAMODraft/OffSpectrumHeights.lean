import UAMO.MagneticDOSSpectralSupport
import UAMO.PhysicalDOSLabels
import UAMO.CircleLogOffCircle
import Mathlib.Topology.Order.IntermediateValue

noncomputable section
namespace UAMODraft
open UAMO UAMO.CircleDOS UAMO.UnitarySpectral MeasureTheory Set Filter
open scoped Topology

theorem continuousOn_log_distance {S : Set ℂ} {z : ℂ} (hz : z ∉ S) :
    ContinuousOn (fun w : ℂ => Real.log ‖z-w‖) S := by
  apply (continuous_const.sub continuous_id).norm.continuousOn.log
  intro w hw
  exact norm_ne_zero_iff.mpr (sub_ne_zero.mpr (fun h => hz (h ▸ hw)))

theorem log_distance_integrable_of_compact_support
    (ν : Measure ℂ) [IsFiniteMeasure ν] (S : Set ℂ) (hS : IsCompact S)
    (hs : ∀ᵐ w ∂ν, w ∈ S) (z : ℂ) (hz : z ∉ S) :
    Integrable (fun w => Real.log ‖z-w‖) ν := by
  have hi := (continuousOn_log_distance hz).integrableOn_compact (μ := ν) hS
  simpa only [IntegrableOn, Measure.restrict_eq_self_of_ae_mem hs] using hi

theorem continuousOn_integrable_of_compact_support
    {X : Type*} [TopologicalSpace X] [MeasurableSpace X] [BorelSpace X] [T2Space X]
    (ν : Measure X) [IsFiniteMeasure ν] (S : Set X) (hS : IsCompact S)
    (hs : ∀ᵐ w ∂ν, w ∈ S) (f : X → ℝ) (hf : ContinuousOn f S) : Integrable f ν := by
  have hi := hf.integrableOn_compact (μ := ν) hS
  simpa only [IntegrableOn, Measure.restrict_eq_self_of_ae_mem hs] using hi

theorem circleRegularizedPotential_tendsto_off_compact_support
    (ν : Measure ℂ) [IsFiniteMeasure ν] (S : Set ℂ) (hS : IsCompact S)
    (hs : ∀ᵐ w ∂ν, w ∈ S) (z : ℂ) (hz : z ∉ S) :
    Tendsto (fun n => circleRegularizedPotential ν z (logRegularizationScale n))
      atTop (𝓝 (∫ w, Real.log ‖z-w‖ ∂ν)) := by
  have hi := log_distance_integrable_of_compact_support ν S hS hs z hz
  have hi1 : Integrable (fun w => Real.log (‖z-w‖+1)) ν :=
    continuousOn_integrable_of_compact_support ν S hS hs _
      (((continuous_const.sub continuous_id).norm.add continuous_const).log
        (fun w => (by positivity : ‖z-w‖+(1:ℝ) ≠ 0))).continuousOn
  apply tendsto_integral_of_dominated_convergence
    (fun w => |Real.log ‖z-w‖| + |Real.log (‖z-w‖+1)|)
  · intro n
    exact (regularizedCircleLog_continuous _ (logRegularizationScale_pos n) z).aestronglyMeasurable
  · exact hi.abs.add hi1.abs
  · intro n
    filter_upwards [hs] with w hw
    have hd : 0 < ‖z-w‖ := norm_pos_iff.mpr (sub_ne_zero.mpr (fun h => hz (h ▸ hw)))
    have hn : logRegularizationScale n ≤ 1 := by
      simpa only [logRegularizationScale, Nat.cast_zero, zero_add, div_one] using
        logRegularizationScale_antitone (Nat.zero_le n)
    have hlo := Real.log_le_log hd (le_add_of_nonneg_right (logRegularizationScale_pos n).le)
    have hhi := Real.log_le_log (add_pos hd (logRegularizationScale_pos n))
      (add_le_add_left hn ‖z-w‖)
    change |Real.log (‖z-w‖+logRegularizationScale n)| ≤ _
    apply abs_le.mpr
    constructor
    · linarith [neg_abs_le (Real.log ‖z-w‖), abs_nonneg (Real.log (‖z-w‖+1))]
    · linarith [le_abs_self (Real.log (‖z-w‖+1)), abs_nonneg (Real.log ‖z-w‖)]
  · filter_upwards [hs] with w hw
    have hn : ‖z-w‖ ≠ 0 := norm_ne_zero_iff.mpr
      (sub_ne_zero.mpr (fun h => hz (h ▸ hw)))
    exact (Real.continuousAt_log hn).tendsto.comp
      (by simpa using logRegularizationScale_tendsto.const_add ‖z-w‖)

theorem magnetic_unitary_height_off_spectrum (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (z : ℂ) (hz : z ∉ spectrum ℂ (cstarMagneticWalk a r φ)) :
    Integrable (fun w => Real.log ‖z-w‖) (magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1) ∧
      circleTotalPotential (magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1) z =
        ((∫ w, Real.log ‖z-w‖ ∂magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1 : ℝ) : EReal) := by
  let ν := magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1
  have hs : ∀ᵐ w ∂ν, w ∈ spectrum ℂ (cstarMagneticWalk a r φ) :=
    complexSpectralMeasure_ae_mem_spectrum _ _ _
  have hS := spectrum.isCompact (𝕜 := ℂ) (cstarMagneticWalk a r φ)
  refine ⟨log_distance_integrable_of_compact_support ν _ hS hs z hz, ?_⟩
  apply tendsto_nhds_unique
    (tendsto_regularization_inf _ (circleRegularizedPotential_monotone ν
      (magneticUnitaryDOS_ae_circle a r φ ha0 ha1 hr0 hr1) z)
      logRegularizationScale logRegularizationScale_pos logRegularizationScale_tendsto)
  exact continuous_coe_real_ereal.continuousAt.tendsto.comp
    (circleRegularizedPotential_tendsto_off_compact_support ν _ hS hs z hz)

theorem scalar_log_integrable_off_spectrum (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    Integrable (fun x : ℝ => Real.log |E-x|) (scalarRealSpectralMeasure a r φ) := by
  rw [scalarRealSpectralMeasure]
  apply (integrable_map_measure
    (Real.measurable_log.comp (continuous_const.sub continuous_id).abs.measurable).aestronglyMeasurable
    continuous_subtype_val.measurable.aemeasurable).mpr
  exact (scalar_log_kernel_continuous a r φ E hE).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

theorem scalar_height_off_spectrum (a r φ E : ℝ)
    (hE : (E : ℂ) ∈ resolventSet ℂ (scalarHamiltonian a r φ)) :
    Integrable (fun x : ℝ => Real.log |E-x|) (scalarRealSpectralMeasure a r φ) ∧
      scalarTotalLogPotential a φ (r,E) =
        ((∫ x : ℝ, Real.log |E-x| ∂scalarRealSpectralMeasure a r φ : ℝ) : EReal) := by
  refine ⟨scalar_log_integrable_off_spectrum a r φ E hE, ?_⟩
  rw [scalarTotalLogPotential_eq_magneticLogPotential a φ r E hE,
    scalarRealSpectralMeasure_integral_eq_subtype]
  congr 1
  exact scalarTraceLog_eq_spectralIntegral a r φ E hE

theorem scalarIDS_eq_closed_cut_off_spectrum (a r φ E : ℝ)
    (hE : (E : ℂ) ∉ spectrum ℂ (scalarHamiltonian a r φ)) :
    scalarIDS a r φ E = (scalarRealSpectralMeasure a r φ).real (Iic E) := by
  have hzero : scalarRealSpectralMeasure a r φ {E} = 0 := by
    apply le_antisymm _ (zero_le _)
    calc
      _ ≤ scalarRealSpectralMeasure a r φ
          {x : ℝ | (x : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ)}ᶜ := by
        apply measure_mono
        intro x hx
        simpa only [mem_singleton_iff.mp hx, mem_compl_iff, mem_setOf_eq] using hE
      _ = 0 := scalarRealSpectralMeasure_spectrum_compl a r φ
  exact measureReal_congr (Iio_ae_eq_Iic' hzero)

theorem scalarIDS_constant_on_connected_gap (a r φ : ℝ) (G : Set ℝ)
    (hG : IsPreconnected G)
    (hgap : ∀ E ∈ G, (E : ℂ) ∉ spectrum ℂ (scalarHamiltonian a r φ))
    {E₁ E₂ : ℝ} (h₁ : E₁ ∈ G) (h₂ : E₂ ∈ G) :
    scalarIDS a r φ E₁ = scalarIDS a r φ E₂ := by
  have hs : ∀ᵐ x : ℝ ∂scalarRealSpectralMeasure a r φ,
      (x : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ) :=
    ae_iff.mpr (scalarRealSpectralMeasure_spectrum_compl a r φ)
  suffices h : ∀ {p q : ℝ}, p ∈ G → q ∈ G → p ≤ q →
      scalarIDS a r φ p = scalarIDS a r φ q by
    rcases le_total E₁ E₂ with hle | hle
    · exact h h₁ h₂ hle
    · exact (h h₂ h₁ hle).symm
  intro p q hp hq hpq
  apply measureReal_congr
  filter_upwards [hs] with x hx
  apply propext
  constructor
  · exact fun hxp => hxp.trans_le hpq
  · intro hxq
    by_contra hxp
    have hxG : x ∈ G := hG.ordConnected.out hp hq ⟨le_of_not_gt hxp,hxq.le⟩
    exact hgap x hxG hx

theorem closed_scalarIDS_constant_on_connected_gap (a r φ : ℝ) (G : Set ℝ)
    (hG : IsPreconnected G)
    (hgap : ∀ E ∈ G, (E : ℂ) ∉ spectrum ℂ (scalarHamiltonian a r φ))
    {E₁ E₂ : ℝ} (h₁ : E₁ ∈ G) (h₂ : E₂ ∈ G) :
    (scalarRealSpectralMeasure a r φ).real (Iic E₁) =
      (scalarRealSpectralMeasure a r φ).real (Iic E₂) := by
  rw [← scalarIDS_eq_closed_cut_off_spectrum a r φ E₁ (hgap E₁ h₁),
    ← scalarIDS_eq_closed_cut_off_spectrum a r φ E₂ (hgap E₂ h₂)]
  exact scalarIDS_constant_on_connected_gap a r φ G hG hgap h₁ h₂

theorem normalized_unitary_height_off_spectrum (a r φ : ℝ)
    (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (z : ℂ) (hz : z ∉ spectrum ℂ (cstarMagneticWalk a r φ)) :
    (2 : EReal) * circleTotalPotential (magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1) z +
        (Real.log (((1+a^2)*(1+r^2))/(2*a)) : EReal) =
      ((2 * (∫ w, Real.log ‖z-w‖ ∂magneticUnitaryDOS a r φ ha0 ha1 hr0 hr1) +
        Real.log (((1+a^2)*(1+r^2))/(2*a)) : ℝ) : EReal) := by
  rw [(magnetic_unitary_height_off_spectrum a r φ ha0 ha1 hr0 hr1 z hz).2]
  norm_cast

theorem no_spectrum_between_equal_scalarIDS (a r φ p q : ℝ) (hpq : p < q)
    (hids : scalarIDS a r φ p = scalarIDS a r φ q)
    {x : ℝ} (hx : x ∈ Ioo p q) :
    (x : ℂ) ∉ spectrum ℂ (scalarHamiltonian a r φ) := by
  intro hspec
  let ε := min (x-p) (q-x) / 2
  have hε : 0 < ε := by
    have h₁ := sub_pos.mpr hx.1
    have h₂ := sub_pos.mpr hx.2
    dsimp [ε]
    positivity
  have hball := scalarRealSpectralMeasure_ball_pos_of_mem a r φ x hspec hε
  have hzeroReal : (scalarRealSpectralMeasure a r φ).real (Iio q \ Iio p) = 0 := by
    rw [measureReal_diff (Iio_subset_Iio hpq.le) measurableSet_Iio]
    exact sub_eq_zero.mpr hids.symm
  have hzero : scalarRealSpectralMeasure a r φ (Iio q \ Iio p) = 0 :=
    (measureReal_eq_zero_iff (by finiteness)).mp hzeroReal
  have hsub : Metric.ball x ε ⊆ Iio q \ Iio p := by
    intro y hy
    have habs : |y-x| < ε := by simpa only [Metric.mem_ball,Real.dist_eq] using hy
    have hleft := min_le_left (x-p) (q-x)
    have hright := min_le_right (x-p) (q-x)
    have heq : 2*ε = min (x-p) (q-x) := by dsimp [ε]; ring
    constructor
    · change y < q
      linarith [(abs_lt.mp habs).2]
    · change ¬ y < p
      linarith [(abs_lt.mp habs).1]
  exact (not_lt_of_ge ((measure_mono hsub).trans_eq hzero)) hball

theorem equal_scalarIDS_resolvent_mem_endpoint_interval (a r φ l u c E : ℝ)
    (hl : (l : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ))
    (hu : (u : ℂ) ∈ spectrum ℂ (scalarHamiltonian a r φ))
    (hc : c ∈ Ioo l u)
    (hE : (E : ℂ) ∉ spectrum ℂ (scalarHamiltonian a r φ))
    (hids : scalarIDS a r φ E = scalarIDS a r φ c) : E ∈ Ioo l u := by
  constructor
  · by_contra h
    have hEl : E < l := lt_of_le_of_ne (le_of_not_gt h) (by
      intro he
      exact hE (he ▸ hl))
    exact no_spectrum_between_equal_scalarIDS a r φ E c (hEl.trans hc.1) hids
      ⟨hEl,hc.1⟩ hl
  · by_contra h
    have huE : u < E := lt_of_le_of_ne (le_of_not_gt h) (by
      intro he
      exact hE (he ▸ hu))
    exact no_spectrum_between_equal_scalarIDS a r φ c E (hc.2.trans huE) hids.symm
      ⟨hc.2,huE⟩ hu

end UAMODraft

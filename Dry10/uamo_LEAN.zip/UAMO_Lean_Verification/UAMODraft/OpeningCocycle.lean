import UAMODraft.ConjugacyBounds

noncomputable section
namespace UAMODraft.OpeningAssembly
open UAMODraft.QuantitativeOpening Matrix Set
open scoped Matrix.L2OpNorm
variable {X : Type*} [TopologicalSpace X]

def openedCocycle (T : X→X) (A B : X→Mat2) (σ e : ℝ) (x : X) : Mat2 :=
  signMatrix e*(σ • ((B (T x))⁻¹*A x*B x))*signMatrix e

def openingFrame (B : X→Mat2) (e : ℝ) (x : X) : Mat2 := B x*signMatrix e

theorem openingFrame_continuous (B : X→Mat2) (hB : Continuous B) (e : ℝ) :
    Continuous (openingFrame B e) := hB.mul continuous_const

omit [TopologicalSpace X] in
theorem openingFrame_isUnit (B : X→Mat2) (hB : ∀x,(B x).det=1)
    (e : ℝ) (he : e^2=1) (x : X) : IsUnit (openingFrame B e x) := by
  apply IsUnit.mul _ (signMatrix_isUnit e he)
  apply (Matrix.isUnit_iff_isUnit_det (B x)).mpr
  rw [hB]
  exact isUnit_one

theorem openedCocycle_continuous (T : X→X) (hT : Continuous T)
    (A B : X→Mat2) (hA : Continuous A) (hB : Continuous B)
    (hdet : ∀x,(B x).det=1) (σ e : ℝ) : Continuous (openedCocycle T A B σ e) := by
  have hunit (x:X) : IsUnit (B x) := by
    apply (Matrix.isUnit_iff_isUnit_det _).mpr
    rw [hdet]
    exact isUnit_one
  have hi := (continuous_inverse B hB hunit).comp hT
  exact (continuous_const.mul ((hi.mul hA).mul hB |>.const_smul σ)).mul continuous_const

omit [TopologicalSpace X] in
theorem openedCocycle_det (T : X→X) (A B : X→Mat2)
    (hA : ∀x,(A x).det=1) (hB : ∀x,(B x).det=1)
    (σ e : ℝ) (hσ : σ^2=1) (he : e^2=1) (x:X) :
    (openedCocycle T A B σ e x).det=1 := by
  have hd : (signMatrix e).det=e := by simp [signMatrix,Matrix.det_fin_two]
  simp only [openedCocycle,Matrix.det_mul,Matrix.det_smul,Fintype.card_fin,
    Matrix.det_nonsing_inv,hA,hB,Ring.inverse_one,hd,one_mul,mul_one,hσ]
  simpa only [pow_two] using he

omit [TopologicalSpace X] in

theorem opening_intertwining (T : X→X) (A B : X→Mat2)
    (hB : ∀x,(B x).det=1) (σ e : ℝ) (hσ : σ^2=1) (he : e^2=1) (x:X) :
    A x*openingFrame B e x=σ • (openingFrame B e (T x)*openedCocycle T A B σ e x) := by
  have hb : IsUnit (B (T x)).det := by rw [hB];exact isUnit_one
  have hh : openingFrame B e (T x)*openedCocycle T A B σ e x=
      σ • (A x*openingFrame B e x) := by
    simp only [openingFrame,openedCocycle,mul_smul_comm,smul_mul_assoc]
    congr 1
    calc
      _ = ((B (T x)*(signMatrix e*signMatrix e))*(B (T x))⁻¹)*
          (A x*(B x*signMatrix e)) := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [signMatrix_self_mul e he,mul_one,Matrix.mul_nonsing_inv _ hb,one_mul]
  rw [hh,smul_smul,←pow_two,hσ,one_smul]

end UAMODraft.OpeningAssembly

import UAMODraft.QuantitativeOpening

noncomputable section
namespace UAMODraft.QuantitativeOpening
open Matrix Set
open scoped Matrix.L2OpNorm

theorem J_unitary : J∈unitary Mat2 := by
  apply unitary.mem_iff.mpr
  constructor <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [J,Matrix.mul_apply,Fin.sum_univ_two,Matrix.star_apply]

theorem inverse_eq_symplectic_adjoint (B : Mat2) (hB : B.det=1) :
    B⁻¹ = -J*B.transpose*J := by
  rw [Matrix.inv_def,hB,Ring.inverse_one,one_smul,Matrix.adjugate_fin_two]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [J,Matrix.mul_apply,Matrix.vecMul,dotProduct,Fin.sum_univ_two]

theorem inverse_mul_J (B : Mat2) (hB : B.det=1) :
    B⁻¹*J=J*B.transpose := by
  rw [inverse_eq_symplectic_adjoint B hB]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [J,Matrix.mul_apply,Matrix.vecMul,dotProduct,Fin.sum_univ_two]

theorem inverse_norm_det_one (B : Mat2) (hB : B.det=1) : ‖B⁻¹‖=‖B‖ := by
  rw [inverse_eq_symplectic_adjoint B hB,neg_mul,neg_mul,norm_neg,
    CStarRing.norm_mul_mem_unitary _ J_unitary,
    CStarRing.norm_mem_unitary_mul _ J_unitary]
  change ‖star B‖=‖B‖
  exact norm_star B

def frameRatio (A : ℝ→Mat2) (B : Mat2) (t₀ s : ℝ) : Mat2 :=
  B⁻¹*(A t₀)⁻¹*A (t₀+s)*B

def frameForm (Q : ℝ→Mat2) (B : Mat2) (t₀ s : ℝ) : Mat2 :=
  B.transpose*Q (t₀+s)*B

theorem frameRatio_zero (A : ℝ→Mat2) (B : Mat2) (t₀ : ℝ)
    (hA : (A t₀).det=1) (hB : B.det=1) : frameRatio A B t₀ 0=1 := by
  have ha : IsUnit (A t₀).det := by rw [hA]; exact isUnit_one
  have hb : IsUnit B.det := by rw [hB]; exact isUnit_one
  simp only [frameRatio,add_zero,Matrix.mul_assoc]
  rw [← Matrix.mul_assoc (A t₀)⁻¹,Matrix.nonsing_inv_mul _ ha,one_mul,
    Matrix.nonsing_inv_mul _ hb]

theorem frameRatio_hasDerivAt (A Q : ℝ→Mat2) (B : Mat2) (t₀ s : ℝ)
    (hB : B.det=1)
    (hder : HasDerivAt A (A (t₀+s)*J*Q (t₀+s)) (t₀+s)) :
    HasDerivAt (frameRatio A B t₀)
      (frameRatio A B t₀ s*J*frameForm Q B t₀ s) s := by
  have hd := hder.scomp s ((hasDerivAt_id s).const_add t₀)
  have h := ((hd.const_mul ((A t₀)⁻¹)).const_mul B⁻¹).mul_const B
  have hb : IsUnit B.det := by rw [hB]; exact isUnit_one
  have hid : B*J*B.transpose=J := by
    calc
      _ = B*(B⁻¹*J) := by rw [inverse_mul_J B hB,Matrix.mul_assoc]
      _ = J := by rw [←Matrix.mul_assoc,Matrix.mul_nonsing_inv _ hb,one_mul]
  convert h using 1
  · funext t
    simp only [frameRatio,Function.comp_apply,Matrix.mul_assoc]
  · simp only [frameRatio,frameForm,one_smul]
    calc
      _ = B⁻¹*(A t₀)⁻¹*A (t₀+s)*(B*J*B.transpose)*Q (t₀+s)*B := by
        simp only [Matrix.mul_assoc]
      _ = _ := by rw [hid];simp only [Matrix.mul_assoc]

theorem frameForm_symmetric (Q : ℝ→Mat2) (B : Mat2) (t₀ s : ℝ)
    (hQ : (Q (t₀+s)).transpose=Q (t₀+s)) :
    (frameForm Q B t₀ s).transpose=frameForm Q B t₀ s := by
  simp only [frameForm,Matrix.transpose_mul,Matrix.transpose_transpose,hQ,Matrix.mul_assoc]

theorem frameForm_norm_bound (Q : ℝ→Mat2) (B : Mat2) (t₀ s q₁ K : ℝ)
    (hq : 0≤q₁) (hK : 0≤K) (hQ : ‖Q (t₀+s)‖≤q₁) (hB : ‖B‖≤K) :
    ‖frameForm Q B t₀ s‖≤q₁*K^2 := by
  have hBT : ‖B.transpose‖=‖B‖ := norm_star B
  calc
    _ ≤ ‖B.transpose‖*‖Q (t₀+s)‖*‖B‖ := (norm_mul_le _ _).trans
      (mul_le_mul_of_nonneg_right (norm_mul_le _ _) (norm_nonneg _))
    _ ≤ K*q₁*K := by rw [hBT]; gcongr
    _ = _ := by ring

end UAMODraft.QuantitativeOpening

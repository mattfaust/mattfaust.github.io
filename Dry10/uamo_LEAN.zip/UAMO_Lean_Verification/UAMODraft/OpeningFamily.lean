import UAMODraft.OpeningCoordinates

noncomputable section
namespace UAMODraft.QuantitativeOpening
open Matrix Set
open scoped Matrix.L2OpNorm

theorem hasDerivAt_of_generator (A : ℝ→Mat2) (D Q : Mat2) (t : ℝ)
    (hdet : (A t).det=1) (hder : HasDerivAt A D t)
    (hgen : (A t)⁻¹*D=J*Q) : HasDerivAt A (A t*J*Q) t := by
  have hunit : IsUnit (A t).det := by rw [hdet];exact isUnit_one
  have he := congrArg (fun M:Mat2 => A t*M) hgen
  dsimp only at he
  rw [←Matrix.mul_assoc,Matrix.mul_nonsing_inv _ hunit,one_mul] at he
  simpa only [he,Matrix.mul_assoc] using hder

def conjugatedFamily (A : ℝ→Mat2) (B Bplus : Mat2) (σ t₀ s : ℝ) : Mat2 :=
  σ • (Bplus⁻¹*A (t₀+s)*B)

theorem conjugatedFamily_factorization (A : ℝ→Mat2) (B Bplus E : Mat2)
    (σ t₀ d s : ℝ) (hA : (A t₀).det=1) (hB : B.det=1)
    (hnormal : conjugatedFamily A B Bplus σ t₀ 0=shear d+E) :
    conjugatedFamily A B Bplus σ t₀ s=(shear d+E)*frameRatio A B t₀ s := by
  have ha : IsUnit (A t₀).det := by rw [hA];exact isUnit_one
  have hb : IsUnit B.det := by rw [hB];exact isUnit_one
  rw [←hnormal]
  symm
  simp only [conjugatedFamily,frameRatio,add_zero,smul_mul_assoc]
  congr 1
  calc
    _ = Bplus⁻¹*(A t₀*((B*B⁻¹)*((A t₀)⁻¹*(A (t₀+s)*B)))) := by
      simp only [Matrix.mul_assoc]
    _ = _ := by
      rw [Matrix.mul_nonsing_inv _ hb,one_mul,←Matrix.mul_assoc (A t₀),
        Matrix.mul_nonsing_inv _ ha,one_mul]
      simp only [Matrix.mul_assoc]

theorem conjugatedFamily_det (A : ℝ→Mat2) (B Bplus : Mat2) (σ t₀ s : ℝ)
    (hσ : σ^2=1) (hA : (A (t₀+s)).det=1) (hB : B.det=1) (hBplus : Bplus.det=1) :
    (conjugatedFamily A B Bplus σ t₀ s).det=1 := by
  simp only [conjugatedFamily,Matrix.det_smul,Fintype.card_fin,Matrix.det_mul,
    Matrix.det_nonsing_inv,hA,hB,hBplus,Ring.inverse_one,one_mul,mul_one,hσ]

end UAMODraft.QuantitativeOpening

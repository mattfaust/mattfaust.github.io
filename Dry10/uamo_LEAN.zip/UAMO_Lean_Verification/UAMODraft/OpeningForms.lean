import UAMODraft.OpeningCoordinates
import Mathlib.LinearAlgebra.Matrix.Spectrum

noncomputable section
namespace UAMODraft.QuantitativeOpening
open Matrix Set
open scoped Matrix.L2OpNorm

abbrev Euc2 := EuclideanSpace ℝ (Fin 2)

def euc (v : Vec2) : Euc2 := (EuclideanSpace.equiv (Fin 2) ℝ).symm v

@[simp] theorem euc_apply (v : Vec2) (i : Fin 2) : euc v i=v i := rfl

@[simp] theorem real_euclidean_norm_sq (v : Euc2) : ‖v‖^2=∑ i,(v i)^2 := by
  simpa only [Real.norm_eq_abs,sq_abs] using PiLp.norm_sq_eq_of_L2 (fun _:Fin 2 => ℝ) v

theorem diagonal_norm_bound (a : Fin 2→ℝ) (q : ℝ) (hq : 0≤q)
    (ha : ∀i,|a i|≤q) : ‖Matrix.diagonal a‖≤q := by
  change ‖Matrix.toEuclideanCLM (𝕜:=ℝ) (n:=Fin 2) (Matrix.diagonal a)‖≤q
  apply ContinuousLinearMap.opNorm_le_bound _ hq
  intro v
  have hm (i : Fin 2) :
      (Matrix.toEuclideanCLM (𝕜:=ℝ) (n:=Fin 2) (Matrix.diagonal a) v) i=a i*v i := by
    change (Matrix.diagonal a*ᵥ(⇑v)) i=a i*v i
    fin_cases i <;> simp [Matrix.diagonal,Matrix.mulVec,dotProduct,Fin.sum_univ_two,WithLp.equiv_pi_apply]
  have hsq : ‖Matrix.toEuclideanCLM (𝕜:=ℝ) (n:=Fin 2) (Matrix.diagonal a) v‖^2≤
      (q*‖v‖)^2 := by
    rw [real_euclidean_norm_sq,mul_pow,real_euclidean_norm_sq,Fin.sum_univ_two,Fin.sum_univ_two]
    simp only [hm,mul_pow]
    have h0 := mul_le_mul_of_nonneg_right
      ((sq_le_sq₀ (abs_nonneg _) hq).mpr (ha 0)) (sq_nonneg (v 0))
    have h1 := mul_le_mul_of_nonneg_right
      ((sq_le_sq₀ (abs_nonneg _) hq).mpr (ha 1)) (sq_nonneg (v 1))
    simp only [sq_abs] at h0 h1
    nlinarith
  exact (sq_le_sq₀ (norm_nonneg _) (mul_nonneg hq (norm_nonneg _))).mp hsq

theorem norm_bound_of_quadratic_bounds (Q : Mat2) (q₀ q₁ : ℝ)
    (hq₀ : 0≤q₀) (hq₁ : 0≤q₁) (hsym : Q.transpose=Q)
    (hlo : ∀v:Vec2,q₀*(∑ i,(v i)^2)≤∑ i,v i*(Q*ᵥv) i)
    (hup : ∀v:Vec2,(∑ i,v i*(Q*ᵥv) i)≤q₁*(∑ i,(v i)^2)) : ‖Q‖≤q₁ := by
  have hH : Q.IsHermitian := by exact hsym
  have he (j : Fin 2) : |hH.eigenvalues j|≤q₁ := by
    have hn : (∑ i,(hH.eigenvectorBasis j i)^2)=1 := by
      rw [←real_euclidean_norm_sq,hH.eigenvectorBasis.norm_eq_one]
      norm_num
    have hl := hlo (⇑(hH.eigenvectorBasis j))
    have hu := hup (⇑(hH.eigenvectorBasis j))
    simp only [WithLp.equiv_pi_apply] at hl hu
    rw [hn,mul_one] at hl hu
    have heq : hH.eigenvalues j=∑ i,hH.eigenvectorBasis j i*
        (Q*ᵥ(⇑(hH.eigenvectorBasis j))) i := by
      simpa [dotProduct] using hH.eigenvalues_eq j
    rw [←heq] at hl hu
    rw [abs_of_nonneg (hq₀.trans hl)]
    exact hu
  have hU : (hH.eigenvectorUnitary:Mat2)∈unitary Mat2 := hH.eigenvectorUnitary.property
  have hUstar : star (hH.eigenvectorUnitary:Mat2)∈unitary Mat2 :=
    (star hH.eigenvectorUnitary).property
  conv_lhs => rw [hH.spectral_theorem]
  rw [CStarRing.norm_mul_mem_unitary _ hUstar,CStarRing.norm_mem_unitary_mul _ hU]
  exact diagonal_norm_bound _ q₁ hq₁ he

theorem frameForm_quadratic_identity (Q : ℝ→Mat2) (B : Mat2) (t₀ s : ℝ) (v : Vec2) :
    (∑ i,v i*(frameForm Q B t₀ s*ᵥv) i)=
      ∑ i,(B*ᵥv) i*(Q (t₀+s)*ᵥ(B*ᵥv)) i := by
  simp only [frameForm,Matrix.mulVec_mulVec,Matrix.mulVec,Matrix.mul_apply,
    Matrix.transpose_apply,dotProduct,Fin.sum_univ_two]
  ring

theorem frame_mass_lower (B : Mat2) (hdet : B.det=1) (K : ℝ)
    (hK : 0<K) (hB : ‖B‖≤K) (v : Vec2) :
    (∑ i,(v i)^2)≤K^2*(∑ i,((B*ᵥv) i)^2) := by
  have hb : IsUnit B.det := by rw [hdet];exact isUnit_one
  have hn := Matrix.l2_opNorm_mulVec B⁻¹ (euc (B*ᵥv))
  have hcancel : B⁻¹*ᵥ(B*ᵥv)=v := by
    rw [Matrix.mulVec_mulVec,Matrix.nonsing_inv_mul _ hb,Matrix.one_mulVec]
  change ‖euc (B⁻¹*ᵥ(B*ᵥv))‖≤‖B⁻¹‖*‖euc (B*ᵥv)‖ at hn
  rw [hcancel,inverse_norm_det_one B hdet] at hn
  have ht := hn.trans (mul_le_mul_of_nonneg_right hB (norm_nonneg _))
  have hs := (sq_le_sq₀ (norm_nonneg _) (mul_nonneg hK.le (norm_nonneg _))).mpr ht
  simpa only [mul_pow,real_euclidean_norm_sq,euc_apply] using hs

theorem frameForm_quadratic_lower (Q : ℝ→Mat2) (B : Mat2) (t₀ s q₀ K : ℝ)
    (hdet : B.det=1) (hK : 0<K) (hq₀ : 0≤q₀) (hB : ‖B‖≤K)
    (hlo : ∀v:Vec2,q₀*(∑ i,(v i)^2)≤∑ i,v i*(Q (t₀+s)*ᵥv) i) (v : Vec2) :
    (q₀/K^2)*(∑ i,(v i)^2)≤∑ i,v i*(frameForm Q B t₀ s*ᵥv) i := by
  rw [frameForm_quadratic_identity]
  have hm := frame_mass_lower B hdet K hK hB v
  have hq := hlo (B*ᵥv)
  have hm' : (∑ i,(v i)^2)/K^2≤∑ i,((B*ᵥv) i)^2 :=
    (div_le_iff₀ (sq_pos_of_pos hK)).mpr (by nlinarith [hm])
  have hh := mul_le_mul_of_nonneg_left hm' hq₀
  have he : (q₀/K^2)*(∑ i,(v i)^2)=q₀*((∑ i,(v i)^2)/K^2) := by ring
  rw [he]
  exact hh.trans hq

end UAMODraft.QuantitativeOpening

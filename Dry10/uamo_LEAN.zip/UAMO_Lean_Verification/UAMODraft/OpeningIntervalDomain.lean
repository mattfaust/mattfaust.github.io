import UAMODraft.OrientedGronwall

noncomputable section
namespace UAMODraft.OneSidedOpening
open Set

theorem interval_contains_oriented_window_segment (I:Set ℝ) (hI:OrdConnected I)
    {e T t₀:ℝ} (he:|e|=1) (hT:0<T) (ht₀:t₀∈I)
    (hwindow:∀s:ℝ,T/2<e*s→e*s<T→t₀+s∈I)
    {t:ℝ} (ht:orientedWindow e T t) : t₀+t∈I :=by
  let τ:=(max (e*t) (T/2)+T)/2
  have hmax:max (e*t) (T/2)<T :=max_lt ht.2 (by linarith)
  have hτt:e*t<τ :=by dsimp [τ];linarith [le_max_left (e*t) (T/2)]
  have hτlo:T/2<τ :=by dsimp [τ];linarith [le_max_right (e*t) (T/2)]
  have hτhi:τ<T :=by dsimp [τ];linarith
  have hprod:e*(e*τ)=τ :=by rw [←mul_assoc,sign_square he,one_mul]
  have hu:t₀+e*τ∈I :=hwindow (e*τ) (by rw [hprod];exact hτlo) (by rw [hprod];exact hτhi)
  rcases (abs_eq (by norm_num:(0:ℝ)≤1)).mp he with he|he
  · subst e
    simp only [one_mul] at ht hτt hu
    exact hI.out ht₀ hu ⟨by linarith [ht.1],by linarith⟩
  · subst e
    simp only [neg_one_mul] at ht hτt hu
    exact hI.out hu ht₀ ⟨by linarith,by linarith [ht.1]⟩
end UAMODraft.OneSidedOpening

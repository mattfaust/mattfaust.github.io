import UAMODraft.OpeningForms
import UAMODraft.OpeningFamily
import Mathlib.Data.Real.Sign

noncomputable section
namespace UAMODraft.QuantitativeOpening
open Matrix Set
open scoped Matrix.L2OpNorm

def openingC1 (q₁ : ℝ) : ℝ := 1/(64*max q₁ 1)

def openingC0 (q₀ q₁ : ℝ) : ℝ := min (3*q₀*openingC1 q₁/32) (1/16)

theorem openingC1_pos (q₁ : ℝ) : 0<openingC1 q₁ := by
  unfold openingC1
  have : 0<max q₁ 1 := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  positivity

theorem openingC0_pos (q₀ q₁ : ℝ) (hq₀ : 0<q₀) : 0<openingC0 q₀ q₁ := by
  unfold openingC0
  apply lt_min
  · have := openingC1_pos q₁
    positivity
  · norm_num

theorem opening_scale_bounds (q₀ q₁ K d : ℝ) (hq₀ : 0<q₀)
    (hK : 2≤K) (hd : 0 < |d|) :
    let T := openingC1 q₁*|d|/K^2
    let Q := max q₁ 1*K^2
    let q := q₀/K^2
    let η := openingC0 q₀ q₁*|d|/K^4
    0<T ∧ 0<Q ∧ 0<q ∧ Q*T≤|d|/64 ∧ 0≤η ∧ η≤3*q*T/32 ∧ η≤|d|/16 := by
  have hKp : 0<K := by linarith
  have hK0 : K≠0 := ne_of_gt hKp
  have hbar : 0<max q₁ 1 := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  have hbar0 : max q₁ 1≠0 := ne_of_gt hbar
  have hc1 := openingC1_pos q₁
  have hc0 := openingC0_pos q₀ q₁ hq₀
  dsimp only
  refine ⟨by positivity,by positivity,by positivity,?_,by positivity,?_,?_⟩
  · have he : max q₁ 1*K^2*(openingC1 q₁*|d|/K^2)=|d|/64 := by
      unfold openingC1
      field_simp
      ring
    exact he.le
  · have he : 3*(q₀/K^2)*(openingC1 q₁*|d|/K^2)/32=
        (3*q₀*openingC1 q₁/32)*|d|/K^4 := by field_simp;ring
    rw [he]
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (min_le_left _ _) hd.le) (pow_nonneg hKp.le _)
  · have hden : (1:ℝ)≤K^4 := one_le_pow₀ (by linarith : (1:ℝ)≤K)
    calc
      openingC0 q₀ q₁*|d|/K^4 ≤ openingC0 q₀ q₁*|d| :=
        div_le_self (mul_nonneg hc0.le hd.le) hden
      _ ≤ |d|/16 := by
        have h := mul_le_mul_of_nonneg_right (min_le_right (3*q₀*openingC1 q₁/32) (1/16)) hd.le
        simpa only [openingC0,div_eq_mul_inv,one_mul,mul_comm] using h

private theorem sign_abs_one (d : ℝ) (hd : 0 < |d|) : |Real.sign d|=1 := by
  have hd0 : d≠0 := abs_pos.mp hd
  rcases Real.sign_apply_eq_of_ne_zero d hd0 with he|he <;> simp [he]

theorem signed_conjugatedFamily_det (A : ℝ→Mat2) (B Bplus : Mat2)
    (σ t₀ s d : ℝ) (hd : 0 < |d|) (hσ : σ^2=1)
    (hA : (A (t₀+s)).det=1) (hB : B.det=1) (hBplus : Bplus.det=1) :
    (signMatrix (Real.sign d)*conjugatedFamily A B Bplus σ t₀ s*
      signMatrix (Real.sign d)).det=1 := by
  have hs : (Real.sign d)^2=1 := by
    nlinarith [sq_abs (Real.sign d),sign_abs_one d hd]
  rw [Matrix.det_mul,Matrix.det_mul,
    conjugatedFamily_det A B Bplus σ t₀ s hσ hA hB hBplus]
  have he : (signMatrix (Real.sign d)).det=Real.sign d := by
    simp [signMatrix,Matrix.det_fin_two]
  rw [he,mul_one,←pow_two,hs]

end UAMODraft.QuantitativeOpening

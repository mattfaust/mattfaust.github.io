import UAMODraft.OpeningCocycle
import UAMODraft.AngleContinuity

noncomputable section
namespace UAMODraft.OpeningRotationAssembly
open UAMODraft.QuantitativeOpening UAMODraft.OpeningAssembly UAMODraft.PositiveAngle
open Matrix
open scoped Matrix.L2OpNorm

theorem inverse_frame_antiperiodic (B : ℝ→Mat2) (m:ℤ)
    (hB : ∀x,(B x).det=1) (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x) (x:ℝ) :
    (B (x+1))⁻¹=((-1:ℝ)^m) • (B x)⁻¹ := by
  rw [inverse_eq_symplectic_adjoint (B (x+1)) (hB (x+1)),hanti,
    Matrix.transpose_smul,mul_smul_comm,smul_mul_assoc,
    ←inverse_eq_symplectic_adjoint (B x) (hB x)]

theorem openedCocycle_periodic (A B : ℝ→Mat2) (α σ e:ℝ) (m:ℤ)
    (hA : Function.Periodic A 1) (hB : ∀x,(B x).det=1)
    (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x) :
    Function.Periodic (openedCocycle (fun x:ℝ=>x+α) A B σ e) 1 := by
  have hsgn : (-1:ℝ)^m*(-1:ℝ)^m=1 := by rw [←mul_zpow];norm_num
  intro x
  have hshift : x+1+α=(x+α)+1 := by ring
  have hr : (B (x+1+α))⁻¹*A (x+1)*B (x+1)=(B (x+α))⁻¹*A x*B x := by
    rw [hshift,inverse_frame_antiperiodic B m hB hanti,hA,hanti]
    simp only [smul_mul_assoc,mul_smul_comm,smul_smul,hsgn,one_smul]
  simp only [openedCocycle,hr]

end UAMODraft.OpeningRotationAssembly

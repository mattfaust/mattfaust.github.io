import UAMODraft.ReflectedRotation

noncomputable section
namespace UAMODraft.PositiveAngle
open Matrix UAMO.StablePlane UAMO.ProjectiveAngle
open Set Filter
open scoped Topology

def signIndex (σ : ℝ) : ℤ := if σ=1 then 0 else 1

theorem signIndex_scalar {σ : ℝ} (hσ : |σ|=1) : (-1:ℝ)^(signIndex σ)=σ := by
  rcases (abs_eq (by norm_num : (0:ℝ)≤1)).mp hσ with h | h
  all_goals subst σ; norm_num [signIndex]

theorem signIndex_limit {σ : ℝ} (hσ : |σ|=1) (m : ℤ) (α : ℝ) :
    ((m:ℝ)*α+(signIndex σ:ℝ))/2=(m:ℝ)*α/2+(1-σ)/4 := by
  rcases (abs_eq (by norm_num : (0:ℝ)≤1)).mp hσ with h | h
  all_goals subst σ; norm_num [signIndex] <;> ring

theorem quadrantReflection_square {e : ℝ} (he : |e|=1) :
    quadrantReflection e*quadrantReflection e=1 := by
  have hsq := sign_sq_one he
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [quadrantReflection,Matrix.mul_apply,Fin.sum_univ_two,← pow_two,hsq]

theorem signed_quadrant_conjugacy_recover (A B C : ℝ→PlaneMatrix) (α : ℝ)
    {e σ : ℝ} (he : |e|=1) (hσ : |σ|=1) (hB : ∀x,(B x).det=1)
    (hC : ∀x,C x=quadrantReflection e*(σ • ((B (x+α))⁻¹*A x*B x))*quadrantReflection e)
    (x : ℝ) :
    signedConjugate (fun x => reflectedMatrix e (C x)) B α (signIndex σ) x=A x := by
  have hD := quadrantReflection_square he
  have hR : reflectedMatrix e (C x)=σ • ((B (x+α))⁻¹*A x*B x) := by
    rw [reflectedMatrix,hC]
    calc
      _=(quadrantReflection e*quadrantReflection e)*
          (σ • ((B (x+α))⁻¹*A x*B x))*(quadrantReflection e*quadrantReflection e) := by noncomm_ring
      _=_ := by rw [hD,one_mul,mul_one]
  have hi : B (x+α)*(B (x+α))⁻¹=1 :=
    Matrix.mul_nonsing_inv _ (by rw [hB];exact isUnit_one)
  have hi' : B x*(B x)⁻¹=1 :=
    Matrix.mul_nonsing_inv _ (by rw [hB];exact isUnit_one)
  have hσ2 : σ*σ=1 := by nlinarith [sign_sq_one hσ]
  simp only [signedConjugate,signIndex_scalar hσ,hR,Matrix.mul_smul,Matrix.smul_mul,smul_smul,hσ2,one_smul]
  calc
    _=(B (x+α)*(B (x+α))⁻¹)*A x*(B x*(B x)⁻¹) := by noncomm_ring
    _=_ := by rw [hi,hi',one_mul,mul_one]

theorem opening_rotation_periodic_action (B C : ℝ→PlaneMatrix) (b : ℝ→ℝ)
    (α e σ : ℝ) (he : |e|=1) (m : ℤ)
    (hB : ∀x,(B x).det=1)
    (hcol : ∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (hwind : ∀x,b (x+1)=b x+(m:ℝ)*Real.pi)
    (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hper : Function.Periodic C 1) (s : ℝ) :
    Function.Periodic (fun x =>
      conjugatedLift (fun x => frameOrderIso (B x) (b x) (hB x) (hcol x))
        (reflectedLift e (fun x => angleLift (C x))) α (signIndex σ) x s) 1 := by
  let G := fun x => frameOrderIso (B x) (b x) (hB x) (hcol x)
  have hG : ∀x s,G x (s+Real.pi)=G x s+Real.pi := fun x s => frameLift_add_pi (B x) (b x) s
  have hGw : ∀x s,G (x+1) s=G x s+(m:ℝ)*Real.pi := by
    intro x s
    change frameLift (B (x+1)) (b (x+1)) s=frameLift (B x) (b x) s+(m:ℝ)*Real.pi
    rw [hanti,hwind,frameLift_degree_shift]
  apply conjugatedLift_periodic G _ α m (signIndex σ) hG hGw
    (reflectedLift_add_pi he _ (fun x s => angleLift_add_pi (C x) s)) _ s
  intro x s
  simp only [reflectedLift,hper x]

end UAMODraft.PositiveAngle

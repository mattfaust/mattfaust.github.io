import UAMODraft.OpeningCocycle
import UAMODraft.UniformHyperbolicityConjugacy
import UAMODraft.PositiveHyperbolicity

noncomputable section
namespace UAMODraft.OpeningAssembly
open UAMODraft.QuantitativeOpening UAMODraft.PositiveCone Matrix
open scoped Matrix.L2OpNorm
variable {X : Type*} [TopologicalSpace X] [CompactSpace X] [Nonempty X]

theorem uniformlyHyperbolic_of_opened_positive (T : X≃ₜX) (A B : X→Mat2)
    (hAcont : Continuous A) (hBcont : Continuous B)
    (hAdet : ∀x,(A x).det=1) (hBdet : ∀x,(B x).det=1)
    (σ e : ℝ) (hσ : σ^2=1) (he : e^2=1)
    (hpos : ∀x i j,0<openedCocycle T A B σ e x i j) : IsUniformlyHyperbolic T A := by
  have hσabs : |σ|=1 := by nlinarith [sq_abs σ,abs_nonneg σ]
  have hUH := compact_positive_SL2_uniformlyHyperbolic T (openedCocycle T A B σ e)
    (openedCocycle_continuous T T.continuous A B hAcont hBcont hBdet σ e) hpos
    (openedCocycle_det T A B hAdet hBdet σ e hσ he)
  exact uniformlyHyperbolic_of_signed_conjugacy T A (openedCocycle T A B σ e)
    (openingFrame B e) σ hσabs (openingFrame_continuous B hBcont e)
    (openingFrame_isUnit B hBdet e he) (opening_intertwining T A B hBdet σ e hσ he) hUH

end UAMODraft.OpeningAssembly

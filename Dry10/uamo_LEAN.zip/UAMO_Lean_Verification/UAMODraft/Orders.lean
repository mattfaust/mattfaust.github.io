import UAMODraft.Residual
import Mathlib.Analysis.Asymptotics.Lemmas

noncomputable section
set_option maxHeartbeats 800000
namespace UAMODraft.OddSeed
open UAMO UAMO.BoundarySeed Asymptotics Filter
open scoped Topology

def denominator (m : ℕ) (hm : 0<m) (z q : ℂ) (x : Variables m) (k : ℤ) : ℂ :=
  (if Even k then z*Complex.exp (Complex.I*(x (zeroMode m hm)).im)
    else z⁻¹*Complex.exp (-Complex.I*(x (zeroMode m hm)).im)) -
    z*(1-(x (zeroMode m hm)).re)*q^k

theorem denominator_base (m : ℕ) (hm : 0<m) (z q : ℂ) (k : ℤ) :
    denominator m hm z q 0 k=divisor z q (spin k) k := by
  simp [denominator,divisor,diagonalValue,spin]

theorem denominator_continuousAt {m : ℕ} (hm : 0<m) (z q : ℂ)
    (x : ℝ → Variables m) (hx : ContinuousAt x 0) (k : ℤ) :
    ContinuousAt (fun lam => denominator m hm z q (x lam) k) 0 := by
  have he : ContinuousAt (fun lam => x lam (zeroMode m hm)) 0 :=
    (continuous_apply _).continuousAt.comp hx
  unfold denominator
  split_ifs <;> fun_prop

theorem branch_coefficient_continuousAt {m : ℕ} (x : ℝ → Variables m)
    (hx : ContinuousAt x 0) (k : ℤ) :
    ContinuousAt (fun lam => coefficient m (x lam) k) 0 :=
  (coefficient_hasFDerivAt m k (x 0)).continuousAt.comp hx

theorem branch_inverse_isBigO {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : z^2=q^m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hx : ContinuousAt x 0)
    (k : Mode m) (hk : (k:ℤ)≠0) :
    (fun lam => (denominator m hm z q (x lam) k)⁻¹) =O[nhds (0:ℝ)] (fun _ => (1:ℝ)) := by
  have hd : denominator m hm z q (x 0) k≠0 := by
    rw [hx0,denominator_base]
    simpa only [diagonal,hk,if_false] using diagonal_ne_zero hz hq0 hq m hres k
  exact ((denominator_continuousAt hm z q x hx k).inv₀ hd).isBigO_one ℝ

theorem branch_recurrence {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : z^2=q^m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hx : ContinuousAt x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0)
    (k : Mode m) (hk : (k:ℤ)≠0) :
    ∀ᶠ lam in nhds 0, coefficient m (x lam) k=
      -(2*Complex.I)⁻¹*(lam:ℂ)*
        (coefficient m (x lam) ((k:ℤ)+1)-coefficient m (x lam) ((k:ℤ)-1)) /
        denominator m hm z q (x lam) k := by
  have hd : denominator m hm z q (x 0) k≠0 := by
    rw [hx0,denominator_base]
    simpa only [diagonal,hk,if_false] using diagonal_ne_zero hz hq0 hq m hres k
  filter_upwards [hxe,(denominator_continuousAt hm z q x hx k).eventually_ne hd] with lam he hd'
  have h := congrFun he k
  change denominator m hm z q (x lam) k*coefficient m (x lam) k+
    (2*Complex.I)⁻¹*(lam:ℂ)*(coefficient m (x lam) ((k:ℤ)+1)-coefficient m (x lam) ((k:ℤ)-1))=0 at h
  apply (eq_div_iff hd').mpr
  linear_combination h

theorem branch_coefficient_order {z q : ℂ} (hz : z≠0) (hq0 : q≠0)
    (hq : NoIntegerResonance q) (m : ℕ) (hm : 0<m) (hres : z^2=q^m)
    (x : ℝ → Variables m) (hx0 : x 0=0) (hxa : AnalyticAt ℝ x 0)
    (hxe : ∀ᶠ lam in nhds 0, finiteSystem m hm z q lam (x lam)=0)
    (j : ℕ) (k : ℤ) (hj : (j:ℤ)≤|k|) :
    (fun lam => coefficient m (x lam) k) =O[nhds (0:ℝ)] (fun lam => lam^j) := by
  induction j generalizing k with
  | zero =>
    simpa only [pow_zero] using (branch_coefficient_continuousAt x hxa.continuousAt k).isBigO_one ℝ
  | succ j ih =>
    by_cases hki : k∈Finset.Icc (-(m:ℤ)+1) (m:ℤ)
    · have hk : k≠0 := by
        rintro rfl
        simp only [abs_zero] at hj
        omega
      have hplus := ih (k+1) (by
        have h := abs_sub (k+1) 1
        norm_num at h
        omega)
      have hminus := ih (k-1) (by
        have h := abs_add (k-1) 1
        norm_num at h
        omega)
      have hlam : (fun lam : ℝ => (lam:ℂ)) =O[nhds (0:ℝ)] (fun lam => lam) :=
        isBigO_of_le _ (fun lam => by simp)
      have hInv := branch_inverse_isBigO hz hq0 hq m hm hres x hx0 hxa.continuousAt ⟨k,hki⟩ hk
      have hbound := ((hlam.mul (hplus.sub hminus)).const_mul_left (-(2*Complex.I)⁻¹)).mul hInv
      have hbound' : (fun lam => -(2*Complex.I)⁻¹*(lam:ℂ)*
          (coefficient m (x lam) (k+1)-coefficient m (x lam) (k-1)) /
          denominator m hm z q (x lam) k) =O[nhds (0:ℝ)] (fun lam => lam^(j+1)) := by
        simpa only [div_eq_mul_inv,mul_one,pow_succ,mul_assoc,mul_left_comm,mul_comm] using hbound
      have hrec := branch_recurrence hz hq0 hq m hm hres x hx0 hxa.continuousAt hxe ⟨k,hki⟩ hk
      exact hbound'.congr' (hrec.mono fun _ he => he.symm) EventuallyEq.rfl
    · have heq : (fun lam => coefficient m (x lam) k)=(fun _ : ℝ => (0:ℂ)) := by
        funext lam
        exact coefficient_outside m hm (x lam) k hki
      rw [heq]
      exact isBigO_zero _ _

end UAMODraft.OddSeed

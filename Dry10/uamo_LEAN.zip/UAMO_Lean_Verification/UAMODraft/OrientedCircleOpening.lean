import UAMODraft.OrientedOriginalFamily
import UAMODraft.CircleOpening

noncomputable section
namespace UAMODraft.OneSidedOpening
open UAMODraft.QuantitativeOpening UAMODraft.OpeningAssembly UAMODraft.PositiveCone
open UAMODraft.CoverHyperbolicity UAMODraft.CircleCover Matrix Function
open scoped Matrix.L2OpNorm
theorem quantitative_opening_ordinaryCircle_oriented
    (α : ℝ) (m : ℤ) (q₀ q₁ K d σ t₀ : ℝ) (hq₀ : 0<q₀) (hK : 2≤K)
    (hd : 0 < |d|) (hd1 : |d|≤1) (hσ : σ^2=1)
    (A Q D : ℝ → ℝ → Mat2) (B E : ℝ → Mat2)
    (hAcont : ∀t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → Continuous (A (t₀+t)))
    (hAper : ∀t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → Periodic (A (t₀+t)) 1)
    (hBcont : Continuous B) (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (hBdet : ∀x,(B x).det=1) (hB : ∀x,‖B x‖≤K)
    (hE : ∀x,‖E x‖≤openingC0 q₀ q₁*|d|/K^4)
    (hnormal : ∀x,σ • ((B (x+α))⁻¹*A t₀ x*B x)=shear d+E x)
    (hAdet : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → (A (t₀+t) x).det=1)
    (hder : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → HasDerivAt (fun u=>A u x) (D (t₀+t) x) (t₀+t))
    (hgen : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → (A (t₀+t) x)⁻¹*D (t₀+t) x=UAMODraft.QuantitativeOpening.J*Q (t₀+t) x)
    (hsym : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → (Q (t₀+t) x).transpose=Q (t₀+t) x)
    (hlo : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → ∀v:Vec2,
      q₀*(∑ i,(v i)^2)≤∑ i,v i*(Q (t₀+t) x*ᵥv) i)
    (hup : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → ∀v:Vec2,
      (∑ i,v i*(Q (t₀+t) x*ᵥv) i)≤q₁*(∑ i,(v i)^2))
    (s : ℝ) (hs : orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) s)
    (hslo : (openingC1 q₁*|d|/K^2)/2≤Real.sign d*s) :
    IsUniformlyHyperbolicOnLines (translation 1 α) (periodicLift (A (t₀+s)) (hAper s hs)) := by
  have he : (Real.sign d)^2=1 :=by
    rcases Real.sign_apply_eq_of_ne_zero d (abs_pos.mp hd) with h|h <;> rw [h] <;> norm_num
  apply ordinaryCircle_uniformHyperbolic_of_opened_positive α (A (t₀+s)) B m
    (hAcont s hs) (hAper s hs) hBcont hanti (fun x=>hAdet x s hs) hBdet σ (Real.sign d) hσ he
  intro x
  exact original_family_positive_entries_oriented q₀ q₁ K d σ t₀ hq₀ hK hd hd1
    (fun t=>A t x) (fun t=>Q t x) (fun t=>D t x) (B x) (B (x+α)) (E x)
    (hBdet x) (hB x) (hE x) (by simpa [conjugatedFamily] using hnormal x)
    (hAdet x) (hder x) (hgen x) (hsym x) (hlo x) (hup x) s hs hslo

end UAMODraft.OneSidedOpening

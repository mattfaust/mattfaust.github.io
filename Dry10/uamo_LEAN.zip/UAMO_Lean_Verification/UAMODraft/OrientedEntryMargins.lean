import UAMODraft.OrientedRiccati

noncomputable section
namespace UAMODraft.OneSidedOpening
open UAMODraft.QuantitativeOpening Matrix Set
open scoped Matrix.L2OpNorm

theorem flow_opening_positive_entries_oriented (R S:ℝ→Mat2) (E:Mat2)
    (T Q q d e η:ℝ) (hQ:0<Q) (hq:0<q)
    (hd:0 < |d|) (hd1:|d|≤1) (he:|e|=1) (hed:e*d=|d|)
    (hQT:Q*T≤|d|/64) (hη:0≤η) (hηq:η≤3*q*T/32)
    (hηd:η≤|d|/16) (hE:‖E‖≤η)
    (h0:R 0=1)
    (hder:∀t,orientedWindow e T t→HasDerivAt R (R t*J*S t) t)
    (hS:∀t,orientedWindow e T t→‖S t‖≤Q)
    (hsym:∀t,orientedWindow e T t→S t 1 0=S t 0 1)
    (hform:∀t,orientedWindow e T t→∀v:Vec2,q*(∑i,(v i)^2)≤∑i,v i*(S t*ᵥv) i)
    (s:ℝ) (hs:orientedWindow e T s) (hslo:T/2≤e*s) :
    ∀i j,0<(signMatrix e*((shear d+E)*R s)*signMatrix e) i j :=by
  have hT:0<T :=lt_of_le_of_lt hs.1 hs.2
  have hQT':Q*T≤1/8 :=by linarith
  have hm:=flow_oriented_bottom_row R S e T Q q he hQ hq hQT' h0 hder hS hsym hform s hs
  have hrlow:(3/8)*q*T≤e*R s 1 0 :=by nlinarith
  have hgen (t:ℝ) (ht:orientedWindow e T t):‖J*S t‖≤Q :=
    (norm_mul_le J (S t)).trans (by simpa only [J_norm,one_mul] using hS t ht)
  have hsabs:|s|≤T :=(oriented_abs he hs.1).trans_le hs.2.le
  have hclose:‖R s-1‖≤|d|/32 :=by
    have hh:=flow_near_identity_linear_oriented R (fun t=>J*S t) e T Q he hQ h0
      (fun t ht=>by simpa only [Matrix.mul_assoc] using hder t ht) hgen s hs
      (by nlinarith [mul_le_mul_of_nonneg_left hsabs hQ.le])
    nlinarith [mul_le_mul_of_nonneg_left hsabs hQ.le]
  obtain ⟨ha,hb,hc,hd'⟩:=perturbed_shear_margins (R s) E d e ((3/8)*q*T) η
    hd hd1 he hed hη (by nlinarith) hηd hclose hE hrlow
  apply positive_sign_conjugate _ e he (by linarith) (by linarith) (by linarith) (by nlinarith)
end UAMODraft.OneSidedOpening

import UAMODraft.OpeningParameters

noncomputable section
namespace UAMODraft.OneSidedOpening
open UAMODraft.QuantitativeOpening Matrix Set
open scoped Matrix.L2OpNorm

def orientedWindow (e T t:ℝ) : Prop := 0≤e*t ∧ e*t<T

theorem sign_square {e:ℝ} (he:|e|=1) : e*e=1 :=by nlinarith [sq_abs e]

theorem oriented_abs {e t:ℝ} (he:|e|=1) (ht:0≤e*t) : |t|=e*t :=by
  have h:=abs_mul e t
  rw [he,one_mul,abs_of_nonneg ht] at h
  exact h.symm

theorem oriented_parameter_mem {e T s:ℝ} (he:|e|=1) (hs:orientedWindow e T s)
    {t:ℝ} (ht:t∈Icc 0 (e*s)) : orientedWindow e T (e*t) :=by
  have hsq:=sign_square he
  unfold orientedWindow
  rw [←mul_assoc,hsq,one_mul]
  exact ⟨ht.1,lt_of_le_of_lt ht.2 hs.2⟩

theorem flow_near_identity_oriented (R H:ℝ→Mat2) (e T Q:ℝ)
    (he:|e|=1) (hQ:0<Q) (h0:R 0=1)
    (hder:∀t,orientedWindow e T t→HasDerivAt R (R t*H t) t)
    (hH:∀t,orientedWindow e T t→‖H t‖≤Q)
    (s:ℝ) (hs:orientedWindow e T s) :
    ‖R s-1‖≤Real.exp (Q*|s|)-1 :=by
  have hsq:=sign_square he
  have hd:∀t∈Icc 0 (e*s),HasDerivAt (fun u=>R (e*u))
      (R (e*t)*(e • H (e*t))) t :=by
    intro t ht
    have hh:=(hder (e*t) (oriented_parameter_mem he hs ht)).scomp t ((hasDerivAt_id t).const_mul e)
    simpa only [mul_one,Matrix.mul_smul] using hh
  have hh:∀t∈Icc 0 (e*s),‖e • H (e*t)‖≤Q :=by
    intro t ht
    rw [norm_smul,Real.norm_eq_abs,he,one_mul]
    exact hH (e*t) (oriented_parameter_mem he hs ht)
  have hg:=flow_near_identity_forward (fun u=>R (e*u)) (fun u=>e • H (e*u))
    (e*s) Q hs.1 hQ (by simpa using h0) hd hh
  simpa only [←mul_assoc,hsq,one_mul,oriented_abs he hs.1] using hg

theorem flow_near_identity_linear_oriented (R H:ℝ→Mat2) (e T Q:ℝ)
    (he:|e|=1) (hQ:0<Q) (h0:R 0=1)
    (hder:∀t,orientedWindow e T t→HasDerivAt R (R t*H t) t)
    (hH:∀t,orientedWindow e T t→‖H t‖≤Q)
    (s:ℝ) (hs:orientedWindow e T s) (hsmall:Q*|s|≤1) :
    ‖R s-1‖≤2*Q*|s| :=by
  have hq:0≤Q*|s|:=mul_nonneg hQ.le (abs_nonneg _)
  have hex:=Real.abs_exp_sub_one_le (show |Q*(|s|)|≤1 by simpa only [abs_of_nonneg hq] using hsmall)
  have hb:=(flow_near_identity_oriented R H e T Q he hQ h0 hder hH s hs).trans (le_abs_self _)
  exact hb.trans (by simpa only [abs_of_nonneg hq,mul_assoc] using hex)
end UAMODraft.OneSidedOpening

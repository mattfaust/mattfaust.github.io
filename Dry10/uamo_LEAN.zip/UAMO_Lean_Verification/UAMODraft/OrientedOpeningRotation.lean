import UAMODraft.OrientedOriginalFamily
import UAMODraft.OpeningPhasePeriodicity

noncomputable section
namespace UAMODraft.OneSidedOpening
open UAMODraft.QuantitativeOpening UAMODraft.OpeningAssembly UAMODraft.PositiveAngle
open UAMODraft.OpeningRotationAssembly UAMO.StablePlane UAMO.ProjectiveAngle Matrix Filter
open scoped Matrix.L2OpNorm Topology
theorem original_family_opening_rotation_oriented
    (α q₀ q₁ K d σ t₀ : ℝ) (hq₀ : 0<q₀) (hK : 2≤K)
    (hd : 0 < |d|) (hd1 : |d|≤1) (hσ : |σ|=1)
    (A Q D : ℝ → ℝ → Mat2) (B E : ℝ → Mat2)
    (hAcont : ∀t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → Continuous (A (t₀+t)))
    (hAper : ∀t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → Function.Periodic (A (t₀+t)) 1)
    (hBcont : Continuous B) (hBdet : ∀x,(B x).det=1) (hB : ∀x,‖B x‖≤K)
    (hE : ∀x,‖E x‖≤openingC0 q₀ q₁*|d|/K^4)
    (hnormal : ∀x,σ • ((B (x+α))⁻¹*A t₀ x*B x)=shear d+E x)
    (hAdet : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → (A (t₀+t) x).det=1)
    (hder : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → HasDerivAt (fun u=>A u x) (D (t₀+t) x) (t₀+t))
    (hgen : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → (A (t₀+t) x)⁻¹*D (t₀+t) x=J*Q (t₀+t) x)
    (hsym : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → (Q (t₀+t) x).transpose=Q (t₀+t) x)
    (hlo : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → ∀v:Vec2,
      q₀*(∑ i,(v i)^2)≤∑ i,v i*(Q (t₀+t) x*ᵥv) i)
    (hup : ∀x t,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t → ∀v:Vec2,
      (∑ i,v i*(Q (t₀+t) x*ᵥv) i)≤q₁*(∑ i,(v i)^2))
    (b : ℝ → ℝ) (hb : Continuous b)
    (hcol : ∀x,∃r:ℝ,0<r ∧ B x 0 0=r*Real.cos (b x) ∧ B x 1 0=r*Real.sin (b x))
    (m:ℤ) (hwind : ∀x,b (x+1)=b x+(m:ℝ)*Real.pi)
    (hanti : ∀x,B (x+1)=((-1:ℝ)^m) • B x)
    (s : ℝ) (hs : orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) s)
    (hslo : (openingC1 q₁*|d|/K^2)/2≤Real.sign d*s) :
    ∃F:ℝ → ℝ → ℝ,
      Continuous (fun p:ℝ×ℝ => F p.1 p.2) ∧
      (∀θ,Function.Periodic (fun x => F x θ) 1) ∧
      (∀x θ,∃c:ℝ,0<c ∧ angleVector (F x θ)=c • (A (t₀+s) x*ᵥangleVector θ)) ∧
      (∀x,StrictMono (F x)) ∧
      (∀x θ,F x (θ+Real.pi)=F x θ+Real.pi) ∧
      (∀x θ,Tendsto (fun n:ℕ => (angleIterate F α x θ n-θ)/(2*Real.pi*(n:ℝ)))
        atTop (𝓝 ((m:ℝ)*α/2+(1-σ)/4))) := by
  let C := openedCocycle (fun x:ℝ=>x+α) (A (t₀+s)) B σ (Real.sign d)
  have he : |Real.sign d|=1 := by
    rcases Real.sign_apply_eq_of_ne_zero d (abs_pos.mp hd) with h|h <;> simp [h]
  have hCcont : Continuous C := openedCocycle_continuous _
    (continuous_id.add continuous_const) _ B (hAcont s hs) hBcont hBdet σ _
  have hCper : Function.Periodic C 1 := openedCocycle_periodic _ B α σ _ m (hAper s hs) hBdet hanti
  have hCdet : ∀x,(C x).det=1 := by
    intro x
    exact signed_conjugatedFamily_det (fun t=>A t x) (B x) (B (x+α)) σ t₀ s d
      hd (sign_sq_one hσ) (hAdet x s hs) (hBdet x) (hBdet (x+α))
  have hpos : ∀x i j,0<C x i j := by
    intro x
    exact original_family_positive_entries_oriented q₀ q₁ K d σ t₀ hq₀ hK hd hd1
      (fun t=>A t x) (fun t=>Q t x) (fun t=>D t x) (B x) (B (x+α)) (E x)
      (hBdet x) (hB x) (hE x) (by simpa [conjugatedFamily] using hnormal x)
      (hAdet x) (hder x) (hgen x) (hsym x) (hlo x) (hup x) s hs hslo
  exact opening_rotation_full (A (t₀+s)) B C b α he hσ hBcont hb hCcont hCper
    hCdet hpos hBdet hcol m hwind hanti (fun _=>rfl)

end UAMODraft.OneSidedOpening

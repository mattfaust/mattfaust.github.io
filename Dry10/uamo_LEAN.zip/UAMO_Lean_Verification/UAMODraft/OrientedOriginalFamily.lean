import UAMODraft.OrientedEntryMargins

noncomputable section
namespace UAMODraft.OneSidedOpening
open UAMODraft.QuantitativeOpening Matrix Set
open scoped Matrix.L2OpNorm

theorem sign_d_abs (d:ℝ) (hd:0 < |d|) : |Real.sign d|=1 :=by
  rcases Real.sign_apply_eq_of_ne_zero d (abs_pos.mp hd) with h|h <;> simp [h]

theorem sign_d_mul (d:ℝ) : Real.sign d*d=|d| :=by
  rcases lt_trichotomy d 0 with h|h|h
  · rw [Real.sign_of_neg h,neg_one_mul,abs_of_neg h]
  · subst d;simp
  · rw [Real.sign_of_pos h,one_mul,abs_of_pos h]

theorem original_family_positive_entries_oriented
    (q₀ q₁ K d σ t₀ : ℝ) (hq₀ : 0<q₀) (hK : 2≤K) (hd : 0 < |d|) (hd1 : |d|≤1)
    (A Q D : ℝ→Mat2) (B Bplus E : Mat2)
    (hBdet : B.det=1) (hB : ‖B‖≤K)
    (hE : ‖E‖≤openingC0 q₀ q₁*|d|/K^4)
    (hnormal : conjugatedFamily A B Bplus σ t₀ 0=shear d+E)
    (hAdet : ∀t:ℝ,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t→(A (t₀+t)).det=1)
    (hder : ∀t:ℝ,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t→HasDerivAt A (D (t₀+t)) (t₀+t))
    (hgen : ∀t:ℝ,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t→(A (t₀+t))⁻¹*D (t₀+t)=J*Q (t₀+t))
    (hsym : ∀t:ℝ,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t→(Q (t₀+t)).transpose=Q (t₀+t))
    (hlo : ∀t:ℝ,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t→∀v:Vec2,
      q₀*(∑ i,(v i)^2)≤∑ i,v i*(Q (t₀+t)*ᵥv) i)
    (hup : ∀t:ℝ,orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) t→∀v:Vec2,
      (∑ i,v i*(Q (t₀+t)*ᵥv) i)≤q₁*(∑ i,(v i)^2))
    (s : ℝ) (hs : orientedWindow (Real.sign d) (openingC1 q₁*|d|/K^2) s)
    (hslo : (openingC1 q₁*|d|/K^2)/2≤Real.sign d*s) :
    ∀i j,0<(signMatrix (Real.sign d)*conjugatedFamily A B Bplus σ t₀ s*
      signMatrix (Real.sign d)) i j := by
  let T := openingC1 q₁*|d|/K^2
  obtain ⟨hT,hQ,hq,hQT,hη,hηq,hηd⟩ := opening_scale_bounds q₀ q₁ K d hq₀ hK hd
  have hKp : 0<K := by linarith
  have hA₀ : (A t₀).det=1 := by simpa using hAdet 0 (by exact ⟨by simp,by simpa using hT⟩)
  rw [conjugatedFamily_factorization A B Bplus E σ t₀ d s hA₀ hBdet hnormal]
  apply flow_opening_positive_entries_oriented (frameRatio A B t₀) (frameForm Q B t₀) E T
    (max q₁ 1*K^2) (q₀/K^2) d (Real.sign d) (openingC0 q₀ q₁*|d|/K^4)
    hQ hq hd hd1 (sign_d_abs d hd) (sign_d_mul d)
    hQT hη hηq hηd hE (frameRatio_zero A B t₀ hA₀ hBdet)
  · intro t ht
    exact frameRatio_hasDerivAt A Q B t₀ t hBdet
      (hasDerivAt_of_generator A _ _ _ (hAdet t ht) (hder t ht) (hgen t ht))
  · intro t ht
    apply frameForm_norm_bound Q B t₀ t (max q₁ 1) K
      (le_trans zero_le_one (le_max_right _ _)) hKp.le _ hB
    apply norm_bound_of_quadratic_bounds _ q₀ (max q₁ 1) hq₀.le
      (le_trans zero_le_one (le_max_right _ _)) (hsym t ht) (hlo t ht)
    intro v
    exact (hup t ht v).trans (mul_le_mul_of_nonneg_right (le_max_left _ _)
      (Finset.sum_nonneg (fun i _ => sq_nonneg (v i))))
  · intro t ht
    exact congrArg (fun M:Mat2 => M 0 1) (frameForm_symmetric Q B t₀ t (hsym t ht))
  · intro t ht v
    exact frameForm_quadratic_lower Q B t₀ t q₀ K hBdet hKp hq₀.le hB (hlo t ht) v
  · exact hs
  · exact hslo

end UAMODraft.OneSidedOpening
